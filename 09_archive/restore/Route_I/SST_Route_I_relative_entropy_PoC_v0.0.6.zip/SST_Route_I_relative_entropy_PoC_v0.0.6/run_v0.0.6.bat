@echo off
python sst_route1_common_foundation_v0.0.6.py --output-dir output_v0.0.6
pause
