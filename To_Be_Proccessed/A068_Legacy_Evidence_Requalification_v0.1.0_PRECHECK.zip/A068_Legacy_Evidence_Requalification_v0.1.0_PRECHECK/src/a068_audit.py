#!/usr/bin/env python3
"""A068 v0.1.0 read-only, conservative SST-Workbench historical evidence inventory.

This is NOT a replacement for an SST Falsifier Framework v1.0.7 instance,
and it never upgrades scientific evidence automatically.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

FAMILY_RE = re.compile(r'^(A\d{3})(?:_|$)', re.I)
VERSION_RE = re.compile(r'^(A\d{3}-v\d+\.\d+(?:\.\d+)?(?:[-_].*)?)$', re.I)
SOURCE_FILES = ('FAMILY.yaml','project.json','science_contract.json','source_contract.json','VERSION.json',
                'PREREGISTRATION.md','README.md','CONCLUSIONS.md','FALSIFIER_REPORT.pdf')
STATUS = ('NOT_AUDITED','REQUALIFICATION_REQUIRED',
          'DIAGNOSTIC_ONLY','OUT_OF_SCOPE_PKLSA','UNKNOWN')


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def discover(root: Path, profiles: dict) -> dict:
    root = root.resolve()
    home = root / '01_research' / 'A_falsifiers'
    if not home.is_dir():
        raise ValueError('Expected Workbench subtree 01_research/A_falsifiers not found')
    by_id = defaultdict(list)
    dirs = sorted((p for p in home.iterdir() if p.is_dir()), key=lambda p:p.name.casefold())
    extras = []
    for d in dirs:
        m = FAMILY_RE.match(d.name)
        if m:
            by_id[m.group(1).upper()].append(d)
        else:
            extras.append(relative(d, root))
    registry_paths = [root/'10_docs'/'registry'/'catalog_index.json',
                      root/'10_docs'/'registry'/'family_hierarchy.json']
    registry = {relative(p,root):{'present':p.is_file(), 'sha256':sha256_file(p) if p.is_file() else None}
                for p in registry_paths}
    entries = []
    for family_id in sorted(by_id):
        for d in by_id[family_id]:
            versions = sorted([x for x in d.iterdir() if x.is_dir() and VERSION_RE.match(x.name)])
            anchors = []
            for p in [d, *versions]:
                for s in SOURCE_FILES:
                    f = p/s
                    if f.is_file():
                        anchors.append({'file':relative(f,root),'sha256':sha256_file(f)})
            profile = profiles.get(family_id, {})
            scope = profile.get('claim_scope','UNKNOWN')
            if scope not in ('KNOT_PHYSICS','GEOMETRY_ONLY','ANALYTIC_NON_KNOT','CROSS_FALSIFIER','UNKNOWN'):
                raise ValueError('Invalid claim scope for '+family_id)
            observations = profile.get('observations',[])
            if not isinstance(observations,list):
                raise ValueError('Observations must be a list')
            # A profile is a review queue, NOT evidence of physical validity.
            status = ('OUT_OF_SCOPE_PKLSA' if scope == 'ANALYTIC_NON_KNOT'
                      else 'DIAGNOSTIC_ONLY' if scope == 'GEOMETRY_ONLY'
                      else 'REQUALIFICATION_REQUIRED' if scope in ('KNOT_PHYSICS','CROSS_FALSIFIER')
                      else 'NOT_AUDITED')
            known = profile.get('known_failed_claim_gates',[])
            # Known FAILs belong to individual historical claims/gates, not a whole family.
            entries.append({
                'family_id':family_id,'folder':relative(d,root),
                'versions':[v.name for v in versions],
                'versions_seen':len(versions),'scope':scope,'status':status,
                'known_failed_claim_gates':known,'contains_known_failed_claims':bool(known),
                'observations':observations,
                'pinned_metadata_hashes':anchors,
                'source_native_verified':False,
                'geometry_certified':False,
                'physical_claim_requalified':False,
                'requires_human_review':True,
            })
    conflicts = {k:[relative(d,root) for d in v] for k,v in by_id.items() if len(v)>1}
    return {'schema':'A068-READONLY-LEGACY-INVENTORY-1','generated_utc':datetime.now(timezone.utc).isoformat(),
            'workbench_root':str(root),'auditor_version':'0.1.0','scientific_status':'DEVELOPMENT_NOT_CERTIFIED',
            'framework_target':'v1.0.7 CANONICAL_FROZEN (not imported/executed)',
            'registry_files':registry,'family_directory_count':len(entries),
            'unique_family_id_count':len(by_id),'duplicate_id_folders':conflicts,
            'non_family_directories':extras,'families':entries,
            'guardrails':[
                'All old outputs and verdicts remain immutable.',
                'A new framework version alone never upgrades scientific claims.',
                'No geometry or physical gate is declared PASS from names or file existence.',
                'Missing data is UNRESOLVED/NOT_AUDITED, not physical FAIL.',
                'Unrelated analytical non-knot claims are not failed for lacking PKLSA.',
                'No upstream independence is inferred from file count, run count or resolution.'
            ]}


def write_outputs(payload:dict, outdir:Path) -> None:
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/'REQUALIFICATION_LEDGER.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    with (outdir/'AUDIT_INDEX.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f)
        w.writerow(['family_id','folder','version_count','versions','claim_scope','preliminary_review_status',
                    'known_failed_claim_gates','source_native_verified','physical_claim_requalified'])
        for x in payload['families']:
            w.writerow([x['family_id'],x['folder'],x['versions_seen'],';'.join(x['versions']),x['scope'],
                        x['status'],';'.join(x['known_failed_claim_gates']),False,False])
    (outdir/'IDENTITY_CONFLICTS.json').write_text(json.dumps(payload['duplicate_id_folders'],indent=2)+'\n',encoding='utf-8')
    st=Counter(x['status'] for x in payload['families'])
    lines=['# A068 v0.1.0 — read-only historical preflight','',
           '**DEVELOPMENT / NOT CERTIFIED.** No historical science rerun or v1.0.7 FREEZE performed.','',
           f"- Folders discovered: {payload['family_directory_count']}",
           f"- Distinct A-IDs: {payload['unique_family_id_count']}",
           f"- Duplicate family IDs: {', '.join(payload['duplicate_id_folders']) or 'none'}",'']
    lines += ['## Preliminary queue (not PASS/FAIL decisions)','']
    lines += [f'- {k}: {v}' for k,v in sorted(st.items())]
    lines += ['', '## Important constraints', '']
    lines += [f'- {v}' for v in payload['guardrails']]
    lines += ['', '## Next scientifically valid step','',
              'Authenticate one historical run per selected family, classify each *claim* by its actual',
              'dependency gates and existing verdict, and re-run only missing geometry, core,',
              'Euler/finite-core dynamics or cross-provider gates. Do not change old verdicts.', '']
    (outdir/'AUDIT_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workbench',type=Path,required=True)
    parser.add_argument('--profiles',type=Path,default=Path(__file__).resolve().parents[1]/'config'/'review_profiles.json')
    parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'outputs'/'local_audit')
    ns=parser.parse_args(argv)
    profiles=json.loads(ns.profiles.read_text(encoding='utf-8'))
    payload=discover(ns.workbench,profiles)
    write_outputs(payload,ns.out)
    print(f"PRECHECK ONLY: {payload['unique_family_id_count']} IDs in {payload['family_directory_count']} folders")
    print('NO scientific gate promoted. Outputs:',ns.out)
    return 0

if __name__=='__main__':
    raise SystemExit(main())
