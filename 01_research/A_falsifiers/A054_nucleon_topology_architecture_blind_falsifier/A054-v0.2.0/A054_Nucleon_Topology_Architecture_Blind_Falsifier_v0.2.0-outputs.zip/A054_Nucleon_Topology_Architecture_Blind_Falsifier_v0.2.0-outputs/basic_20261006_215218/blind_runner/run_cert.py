from pathlib import Path
import argparse
from a054_blind.certify_v020 import run_certification
p=argparse.ArgumentParser(); p.add_argument('--campaign',required=True); p.add_argument('--config',required=True); a=p.parse_args(); run_certification(Path(a.campaign),Path(a.config))
