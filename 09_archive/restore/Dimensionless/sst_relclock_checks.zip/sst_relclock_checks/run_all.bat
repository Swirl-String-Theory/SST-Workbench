@echo off
REM ---------------------------------------------------------------------------
REM SST relational-clock pre-canonisation checks - Windows launcher
REM   run_all.bat              standard profile, all six checks, with plots
REM   run_all.bat quick        fast smoke run
REM   run_all.bat full         high-resolution run
REM ---------------------------------------------------------------------------
setlocal
cd /d "%~dp0"

set PROFILE=%1
if "%PROFILE%"=="" set PROFILE=standard

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] python not found on PATH.
  exit /b 1
)

echo.
echo === installing requirements (quiet) ===
python -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo [WARN] pip install failed; continuing with whatever is installed.
)

echo.
echo === self-test ===
python -m pytest -q tests 2>nul
if errorlevel 1 echo [WARN] pytest unavailable or tests failed; continuing.

echo.
echo === running suite: profile=%PROFILE% ===
python main.py --profile %PROFILE% --out results_%PROFILE%
if errorlevel 1 (
  echo [ERROR] suite failed.
  exit /b 1
)

echo.
echo Done. Open results_%PROFILE%\REPORT.md
endlocal
