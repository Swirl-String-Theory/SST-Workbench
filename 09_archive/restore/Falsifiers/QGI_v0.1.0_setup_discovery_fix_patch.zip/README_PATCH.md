# Patch: setuptools flat-layout package discovery fix

Target:
`SST_Quantum_Galileo_Action_Gauge_Closure_Falsifier_v0.1.0`

Fixes:

1. `setup.py`
   - adds `find_packages`
   - explicitly limits package discovery to:
     `sst_qgi` and `sst_qgi.*`
   - prevents `cpp/` and `configs/` from being interpreted as top-level Python packages.

2. `run_02_build_native.cmd`
   - removes the misleading unconditional Visual Studio Build Tools diagnosis
   - tells the user to inspect the actual setuptools/compiler error
   - adds a specific hint for the `Multiple top-level packages discovered` failure.

## Apply manually

Copy the replacement `setup.py` and `run_02_build_native.cmd`
into the project root and overwrite the existing files.

Then run:

```bat
run_02_build_native.cmd
```

or the full chain:

```bat
run_all.cmd
```

## Apply with Git

From the project root, if `patch`/Git patch tooling is available:

```bat
git apply SST_Quantum_Galileo_Action_Gauge_Closure_Falsifier_v0.1.0_setup_discovery_fix.diff
```
