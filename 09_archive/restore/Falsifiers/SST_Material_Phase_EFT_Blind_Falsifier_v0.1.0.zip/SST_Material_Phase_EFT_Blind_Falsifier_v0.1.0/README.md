# SST Material-Coordinate / Phase-Shift EFT Blind Falsifier v0.1.0

A blind Python/C++17/pybind11 workbench motivated by Dubovsky, Hui, Nicolis & Son's EFT formulation of nondissipative hydrodynamics, adapted **methodologically** to SST's incompressible-vortex research program.

## What is source-derived vs SST-specific

Source-derived methodological ingredients:

- comoving material labels `phi^I`;
- volume-preserving relabeling symmetry as the organizing principle of a fluid EFT;
- the identically conserved material current `J^mu`;
- the chemical-shift symmetry `psi -> psi + f(phi)` and the invariant material derivative `u^mu partial_mu psi`;
- derivative expansion;
- removal of redundant operators by field redefinitions / equations of motion.

SST-specific hypotheses tested or scaffolded here:

- applying relabeling robustness to relaxed vortex-knot centerlines;
- treating a possible phase variable as a swirl/phase-clock candidate;
- using `r_c` as a candidate microscopic derivative-expansion scale for SI mode tables;
- testing even-power low-k dispersion (`k^2 + k^4`) as an EFT-style diagnostic.

The paper does **not** identify `psi` with time or a vortex clock, and it does not derive SST gravity.

## Gates

### G1 — Material-coordinate / reparameterization proxy

For a closed centerline, fixed geometry should not depend on the numerical material label. The code applies cyclic, orientation, and smooth monotone label warps, re-arclength-resamples, then compares dimensionless curvature invariants and approximate Gauss writhe.

This is a centerline proxy, not the full three-dimensional volume-preserving diffeomorphism test of the fluid EFT.

### G2 — Phase-shift / holonomy estimator

Tests numerically that a time-independent comoving gauge addition

`psi(label,t) -> psi(label,t) + f(label)`

cancels from the discrete material time derivative. A static centerline contains no physical phase data, so this gate is deliberately reported as `STRUCTURAL_PASS`, never as empirical SST support.

### G3 — Derivative hierarchy / continuum convergence

At increasing arclength resolution the package evaluates

`D0 = L * integral(kappa^2 ds)`

and

`D2 = L^3 * integral((d kappa/ds)^2 ds)`.

Both are dimensionless, so KnotPlot's arbitrary geometry scale does not contaminate this gate. High-wavenumber curvature power is also measured. Failure means the geometry is too discretization-sensitive/noisy to support a controlled higher-derivative interpretation at the chosen thresholds.

### G4 — Operator redundancy

For a closed loop it checks the discrete integration-by-parts equivalence

`integral kappa kappa'' ds = - integral (kappa')^2 ds`

and verifies that an integrated total derivative vanishes. This prevents counting numerically different but action-equivalent operator representations as independent evidence.

### G5 — Low-k mode dispersion

No frequencies are invented from static geometry. If a sidecar file `<curve>.modes.csv` is present with

```text
k_m_inv,omega_rad_s
...
```

the blind runner fits nested EFT-like models

`omega^2 = a2 k^2`

and

`omega^2 = a2 k^2 + a4 k^4`,

using leave-one-out relative RMSE and the dimensionless expansion variable `epsilon = k r_c` with the canonical `r_c = 1.40897017e-15 m`.

## Run on Windows

From the extracted package root:

```bat
run_all.cmd
```

Default dataset:

```text
..\..\KnotPlot\knots\final
```

Or pass it explicitly:

```bat
run_all.cmd "C:\workspace\projects\SST-Workbench\KnotPlot\knots\final"
```

Individual ladders:

```bat
run_selftest.cmd
run_basic.cmd "..\..\KnotPlot\knots\final"
run_extended.cmd "..\..\KnotPlot\knots\final"
```

`run_all.cmd` performs venv creation, dependency installation, native C++ build, self-test, pre-analysis lock, blind analysis, lock of verdicts, and only then reveal.

## Accepted geometry

Single closed centerlines in `.txt`, `.xyz`, `.dat`, `.csv`, or single-component `.vect`. Numeric text files must contain XYZ rows. Binary KnotPlot `.k` files are not parsed in v0.1.0; export `coords ...txt` for this campaign.

## Outputs

- `PREANALYSIS_LOCK.json`
- `blind_summary.csv`
- `LOCKED_VERDICTS.json`
- `BLIND_REPORT.md`
- `per_blind/Bxxxx.json`
- `REVEALED_SUMMARY.csv`
- `private/blind_map.csv`
- `private/rejected.csv`

## Canonical constants used

- `v_swirl = 1.09384563e6 m s^-1`
- `r_c = 1.40897017e-15 m`
- `rho_f = 7.0e-7 kg m^-3`
- `Omega_core = v_swirl/r_c`

Only `r_c` enters G5's dimensionless `k r_c` hierarchy check. Static centerline gates remain scale-free.

## Reference

```latex
\begin{thebibliography}{99}
\bibitem{Dubovsky2012HydroEFT}
S.~Dubovsky, L.~Hui, A.~Nicolis, and D.~T.~Son,
``Effective field theory for hydrodynamics: Thermodynamics, and the derivative expansion,''
Phys.\ Rev.\ D \textbf{85}, 085029 (2012).
doi:10.1103/PhysRevD.85.085029.
\url{https://arxiv.org/abs/1107.0731}
\end{thebibliography}
```
