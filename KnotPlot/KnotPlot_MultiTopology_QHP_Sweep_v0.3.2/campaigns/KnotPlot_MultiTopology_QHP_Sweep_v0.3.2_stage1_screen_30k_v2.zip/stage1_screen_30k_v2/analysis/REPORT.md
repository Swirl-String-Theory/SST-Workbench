# MultiTopology QHP Sweep Report

- QHP mode: **line**
- Topologies: **15**
- QHP states/topology: **6**
- Planned runs: **90**
- Max ago: **30000**

| topology | kind | best q | best h | best p | late E | drift/1000 | direct eq | zero crossings |
|---|---|---:|---:|---:|---:|---:|---:|---:|

## Interpretation guardrail

The sweep searches for a geometric expansion/contraction balance in KnotPlot dynamics.
A near-zero E state is not by itself proof of a mechanical restoring equilibrium or TBK/RPO stability.
