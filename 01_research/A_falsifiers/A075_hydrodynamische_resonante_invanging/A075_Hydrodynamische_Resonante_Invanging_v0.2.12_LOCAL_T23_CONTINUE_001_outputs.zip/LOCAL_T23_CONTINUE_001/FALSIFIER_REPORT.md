# A075-v0.2.12 — Gauge-fixed free normal-graph Newton–Krylov

**Research status: `DEVELOPMENT_ONLY`; `CONTINUUM_EQUILIBRIUM_UNRESOLVED`; `LINEAR_STABILITY_NOT_RUN`.**

## Scientific question

Does the A007 T(2,3) with B0=77/500 admit a nearby, freely deformed, moving relative equilibrium of the regularized Ruban filament equation?

## Method

2N independent normal graph coordinates; two unknown axial speeds U/Omega; two phase-gauge constraints; instantaneous tangential component removed. No finite Fourier family constraint. GMRES finite-difference Jacobian-vector products with Newton backtracking. Compare unmodified shape on 2N points and trapezoid versus midpoint quadrature.

| N | initial epsilon | solved epsilon | unchanged shape 2N epsilon | midpoint epsilon | midpoint 2N epsilon | segment/delta | status |
|---:|---:|---:|---:|---:|---:|---:|---|
| 128 | 0.056477355 | 1.4427681e-09 | 0.013718223 | 0.040314819 | 0.0056873051 | 2.2815 | FINITE_N_CANDIDATE |
| 256 | 0.013718223 | 2.1714118e-06 | 0.0012119994 | 0.019453618 | 0.004371654 | 1.1501 | MAX_NEWTON |
| 512 | 0.0012119994 | 7.9574299e-07 | 6.4281081e-06 | 0.0055405375 | 0.001382421 | 0.5752 | LINESEARCH_STALLED |
| 1024 | 6.4281081e-06 | 7.9241962e-07 | 7.9242254e-07 | 0.0013880555 | 0.00034701295 | 0.2876 | LINESEARCH_STALLED |

## Scientific boundaries

Numerical near-zero finite-N residual is NOT proof of an exact continuous equilibrium. A finite-N root is not a spectral stability result; compare independently discretized operators and run at least three well resolved core levels. Midpoint and trapezoid are different finite-N schemes; cross-scheme mismatch is expected when core underresolved.
No Ruban-author random perturbation, physical lifetime, reconnection, or 3D Euler check reproduced. A007 source is hash verified, not author simulation vertices. Source A075-v0.2.9 and prior source releases remain immutable.

## Sources

Ruban, *Long-lived quantum vortex knots* (2018), DOI 10.1134/S0021364018050120. A007 primary SHA-256: 127de915c8eaae59325b8bd2697a0ab50c71eb1c5cf0a91fc55ed44de70fcc89.
A075-v0.2.9 Eq9 SHA-256: 27cad14f87262d496b1f3b3cb0d13b63fff0163e8face210d3463f053f860411.
