#include "../classes/resolved_tube_geometry.h"

#include <cassert>
#include <cmath>
#include <vector>

int main() {
    using sst::Vec3;
    const std::vector<Vec3> square = {
        {1.0, 1.0, 0.0},
        {-1.0, 1.0, 0.0},
        {-1.0, -1.0, 0.0},
        {1.0, -1.0, 0.0},
    };

    const auto metrics = sst::ResolvedTubeGeometry::analyze(square, 1, 1e-9, 1e-12);
    assert(std::abs(metrics.length - 8.0) < 1e-12);
    assert(std::abs(metrics.thickness_rad - 1.0) < 1e-12);
    assert(std::abs(metrics.ropelength_rad - 8.0) < 1e-12);
    assert(std::abs(metrics.ropelength_diam - 4.0) < 1e-12);
    assert(metrics.kinks.size() == 4);

    const auto diag = sst::ContactStressMap::diagnose_length_criticality(square, metrics, false);
    assert(diag.kink_count == metrics.kinks.size());
    assert(diag.contact_residual >= 0.0);

    const double lower = sst::ResolvedTubeGeometry::nontrivial_knot_lower_bound_rad();
    assert(std::abs(lower - (4.0 * 3.14159265358979323846 + 2.0 * 3.14159265358979323846 * std::sqrt(2.0))) < 1e-12);
    return 0;
}
