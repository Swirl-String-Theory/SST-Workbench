# Data and code for dynamic similarity of vortex shedding

This repository accompanies:

**Dynamic similarity of vortex shedding in a superfluid flowing past a penetrable obstacle**  
Junhwan Kwon and Yong-il Shin, *Physical Review Research* (2026).  
Article DOI: <https://doi.org/10.1103/wlft-tc8w>

The public release is organized so that a reader can:

1. regenerate several paper-style figures directly from compact processed data,
2. inspect the structure of the raw simulation outputs,
3. rerun a representative Gross-Pitaevskii equation simulation using the included JSON config,
4. extend the plotting scripts by adding more output cases under `outputs/`.

The full raw trajectory archive used during the paper workflow is much larger and is not distributed here.

## Repository layout

```text
260507_public_release/
  data/
    processed/
      arr_data/
        250903_a_merged_obs=100.npy        # merged scalar observables for summary plots
        250903_a_merged_obs=100.csv
        250909_D_eff_list_obs=100_server2.csv
        freq_outlier.csv
      fig1_wave_pattern/                   # optional cached helper data from the original workflow
      fig3_time_averaged_flow_field/       # optional cached helper data from the original workflow
      threshold_reynolds_table.csv
  figures/                                # generated figures are written here
  input/
    shedding_V0=0.9_sigma=20_v=0.550.json # included example run configuration
  outputs/
    Nx = 1000 Ny = 500 dt=0.010 obstacle=100/
      spec.txt
      V0=0.9 sigma=20 v=0.550 dt = 0.0100 GPU/
        Force/
        Image/
        Psi/
        Vortex/
  plotting/                               # figure-generation scripts
  scripts/
    run_shedding.py                       # main GPU run entry point
    check_repository.py                   # lightweight internal package check
  src/gpe_dynamics/                       # simulation and analysis source code
```

## What is included

This package contains two kinds of data:

- **Processed summary data** in `data/processed/arr_data/`
  - used for multi-configuration summary figures,
- **One example raw output case** in `outputs/.../V0=0.9 sigma=20 v=0.550 .../`
  - contains a short trajectory from `t = 0` to `t = 100 tau`,
  - shows the on-disk layout expected by the analysis code.

The current packaged raw output case is:

- `V0 = 0.9`
- `sigma = 20`
- `v = 0.550`

If you add more production outputs under the same `outputs/Nx = ... obstacle=100/` directory, the plotting scripts can be extended to use them.

The packaged `outputs/` directory is intentionally small. It contains only a short 100 tau example trajectory, not the full time window used for the paper-scale time-averaged plots. To generate longer raw outputs, run `scripts/run_shedding.py` with the included config or with your own JSON config.

## Requirements

For processed-data plotting only:

```bash
pip install -r requirements.txt
```

For rerunning the GPU simulations:

```bash
pip install -r requirements-gpu.txt
```

The GPU run path requires a CUDA-capable environment with CuPy.

## Quick start

If you only want to reproduce the compact summary figures from processed data:

```bash
python plotting/plot_drag_lift_response.py
python plotting/plot_drag_coefficient.py
python plotting/plot_st_vs_re.py
```

These scripts read only `data/processed/...` and write output figures to `figures/`.

If you want to reproduce the field-based figures, provide or generate raw output cases under `outputs/` and then run:

```bash
python plotting/plot_wake_pattern.py
python plotting/plot_time_averaged_flow_field.py
python plotting/plot_time_averaged_vorticity_field.py
```

All generated figures are written to:

```text
figures/
```

## Plotting scripts and what they use

### Summary plots from processed data only

- `plot_drag_lift_response.py`
  - reads `data/processed/arr_data/250903_a_merged_obs=100.npy`
  - recreates the drag/lift response summary for a selected `(V0, sigma)` series.

- `plot_drag_coefficient.py`
  - reads `data/processed/arr_data/250903_a_merged_obs=100.npy`
  - recreates the drag-coefficient summary versus Reynolds number.

- `plot_st_vs_re.py`
  - reads:
    - `data/processed/arr_data/250903_a_merged_obs=100.npy`
    - `data/processed/arr_data/freq_outlier.csv`
    - `data/processed/threshold_reynolds_table.csv`
  - recreates the Strouhal-number versus Reynolds-number summary plot.

### Field plots from raw output directories

The included raw output is a short 100 tau example. It is useful for checking file structure and loading logic. For the default time windows in the time-averaged plotting scripts, generate a longer trajectory first with `scripts/run_shedding.py`, or adjust the time-window settings near the top of the plotting scripts.

- `plot_wake_pattern.py`
  - reads `Psi/` snapshots and the corresponding `Force/force_dt=0.02.txt`
  - currently configured for the included example case
    `V0=0.9, sigma=20, v=0.55`.

- `plot_time_averaged_flow_field.py`
  - reads `Psi/psi_time:*.npy`
  - computes time-averaged density, mean velocity, irrotational speed, and a Mach-like field
    over the configured time window.

- `plot_time_averaged_vorticity_field.py`
  - left panel:
    - reads `Psi/psi_time:*.npy` for the cases listed in `PARAM_SETS`
    - computes the time-averaged `D`-field / vorticity-style field.
  - right panel:
    - reads `D_eff` from the merged summary array,
    - reads raw `Psi` outputs from the case directories that actually exist under `outputs/`,
    - measures the nucleation width from the available time-averaged fields,
    - then plots the comparison.
  - In other words, this script no longer depends on a hard-coded speed list for the right panel; it uses the output cases you have actually packaged.

## Running a simulation

The main simulation entry point in this public release is:

```bash
python scripts/run_shedding.py --config input/shedding_V0=0.9_sigma=20_v=0.550.json
```

Use this command to generate raw outputs beyond the short 100 tau example packaged in `outputs/`.

This writes production-style output directories of the form:

```text
outputs/Nx = 1000 Ny = 500 dt=0.010 obstacle=100/
  spec.txt
  V0=<...> sigma=<...> v=<...> dt = 0.0100 GPU/
    Force/force_dt=0.02.txt
    Vortex/vortex.txt
    Psi/psi_time:<t>.npy
```

The included JSON config contains two sections:

```json
{
  "run": {
    "V0": 0.9,
    "sigma": 20,
    "v_init": 0.0,
    "v_fin": 0.55,
    "t_final": 10000.0,
    "force_every_tau": 0.1,
    "vortex_every_tau": 5.0,
    "psi_every_tau": 10.0,
    "init": "imaginary",
    "output_root": "outputs"
  },
  "variables": {
    "Nx": 1000,
    "Ny": 500,
    "dt": 0.01,
    "tau_": 1000,
    "dtau": 0.04
  }
}
```

- `run` controls the case parameters and output cadence.
- `variables` overrides the defaults in `src/gpe_dynamics/variable.py`.

Selected run values can also be overridden from the command line. For example:

```bash
python scripts/run_shedding.py \
  --config input/shedding_V0=0.9_sigma=20_v=0.550.json \
  --sigma 25 \
  --v-fin 0.60 \
  --t-final 4000
```

## Notes on reproducibility

- The summary-plot scripts are the most portable part of this release. They require only the processed data and CPU-friendly Python packages.
- The raw-field plots require matching output directories under `outputs/`.
- The included example raw output demonstrates the expected directory structure but is only a short 100 tau trajectory.
- For paper-scale time-averaged field plots, generate longer raw trajectories with `scripts/run_shedding.py` or add matching output cases produced elsewhere.
- If you add more output cases, the plotting scripts can be expanded by editing the parameter blocks near the top of each file. The right panel of `plot_time_averaged_vorticity_field.py` already adapts automatically to the output-case directories that are present.

## Citation

If you use this dataset or analysis scripts, please cite both the paper and this archived dataset.

Paper:
J. Kwon and Y. Shin, "Dynamic similarity of vortex shedding in a superfluid flowing past a penetrable obstacle," Physical Review Research, accepted, 2026. DOI: 10.1103/wlft-tc8w.

Dataset:
J. Kwon and Y. Shin, "Data and analysis scripts for Dynamic similarity of vortex shedding in a superfluid flowing past a penetrable obstacle," Zenodo, v1.0.0, 2026. DOI: 10.5281/zenodo.20068724.

```bibtex
@dataset{kwon_shin_vortex_shedding_2026,
  author = {Kwon, Junhwan and Shin, Yong-il},
  title = {Data and code for Dynamic similarity of vortex shedding in a superfluid flowing past a penetrable obstacle},
  year = {2026},
  publisher = {Zenodo},
  doi = {10.5281/zenodo.20068724},
  url = {https://doi.org/10.5281/zenodo.20068724}
}
```

## License

Code is released under the MIT License. Processed data are intended to be reusable with attribution under CC BY 4.0.
