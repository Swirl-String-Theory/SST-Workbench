from pathlib import Path
import argparse,subprocess,os,re,json,time
ROOT=Path(__file__).resolve().parent
SHORTCUT=ROOT.parent/"KnotPlot.lnk"
REJECT=("unknown command","unknown parameter","invalid parameter","illegal parameter","not a parameter","obsolete")
HARD=("can't open file","cannot open file","failed to open","freeglut error")

def resolve():
    sc=Path(os.environ.get("KNOTPLOT_LNK","").strip() or SHORTCUT)
    if not sc.is_file():raise FileNotFoundError(sc)
    ps="$s=(New-Object -ComObject WScript.Shell).CreateShortcut('"+str(sc).replace("'","''")+"'); Write-Output $s.TargetPath; Write-Output $s.WorkingDirectory"
    cp=subprocess.run(["powershell","-NoProfile","-Command",ps],capture_output=True,text=True)
    a=[x.strip() for x in cp.stdout.splitlines() if x.strip()]
    if not a:raise RuntimeError("Could not resolve KnotPlot shortcut")
    return Path(a[0]),Path(a[1]) if len(a)>1 and a[1] else ROOT.parent

def render(src,cwd,stage):
    rel=os.path.relpath(ROOT,cwd).replace("\\","/")
    d=ROOT/"runtime_kpc"/stage;d.mkdir(parents=True,exist_ok=True)
    p=d/src.name;p.write_text(src.read_text(encoding="utf-8").replace("__BUNDLE_ROOT__",rel),encoding="utf-8",newline="\n")
    return p

def outputs(rt,cwd):
    ans=[]
    for line in rt.read_text(encoding="utf-8",errors="replace").splitlines():
        m=re.match(r"^\s*(?:save|coords)\s+(\S+)",line,re.I)
        if m:ans.append((cwd/Path(m.group(1))).resolve())
    return ans

def fmt(sec):
    sec=int(sec);h,r=divmod(sec,3600);m,s=divmod(r,60);return f"{h:02d}:{m:02d}:{s:02d}"

def iteration_of(path):
    m=re.search(r"_i(\d+)\.(?:k|txt)$",path.name)
    return int(m.group(1)) if m else -1

def complete(expected):
    if not expected:return False
    mx=max(iteration_of(p) for p in expected)
    finals=[p for p in expected if iteration_of(p)==mx]
    return finals and all(p.is_file() and p.stat().st_size>0 for p in finals)

def one(exe,cwd,src,stage,i,n,avg,progress_every):
    rt=render(src,cwd,stage);exp=outputs(rt,cwd)
    for p in exp:p.parent.mkdir(parents=True,exist_ok=True)
    if complete(exp):
        print(f"[{i:02d}/{n:02d}] SKIP {src.stem} stage={stage} final output already complete",flush=True)
        return {"run_id":src.stem,"status":"SKIP","elapsed_seconds":0.0}

    # A partial interrupted setting is restarted, but earlier completed settings are preserved.
    for p in exp:
        try:
            if p.is_file():p.unlink()
        except OSError:pass

    log=ROOT/"logs"/f"{stage}__{src.stem}.log";log.parent.mkdir(parents=True,exist_ok=True)
    print(f"[{i:02d}/{n:02d}] START {src.stem} stage={stage}",flush=True)
    start=time.monotonic()
    with rt.open("rb") as fin,log.open("wb") as fout:
        proc=subprocess.Popen([str(exe),"-nog"],cwd=str(cwd),stdin=fin,stdout=fout,stderr=subprocess.STDOUT)
        lastbeat=0.0
        while proc.poll() is None:
            elapsed=time.monotonic()-start
            if elapsed-lastbeat>=progress_every:
                made=[iteration_of(p) for p in exp if p.is_file() and p.stat().st_size>0 and iteration_of(p)>=0]
                latest=max(made) if made else 0
                eta=(avg if avg else 0.0)*(n-i) if avg else None
                msg=f"[{i:02d}/{n:02d}] HEARTBEAT {src.stem} elapsed={fmt(elapsed)} latest={latest}"
                if eta is not None:msg+=f" campaignETA={fmt(eta)}"
                print(msg,flush=True);lastbeat=elapsed
            time.sleep(min(5,max(1,progress_every/4)))
        rc=proc.returncode
    elapsed=time.monotonic()-start
    txt=log.read_text(encoding="utf-8",errors="replace")
    rej=[x.strip() for x in txt.splitlines() if any(k in x.lower() for k in REJECT)]
    hard=[x.strip() for x in txt.splitlines() if any(k in x.lower() for k in HARD)]
    missing=[str(p) for p in exp if not p.is_file() or p.stat().st_size==0]
    status="PASS" if rc==0 and not rej and not hard and not missing else "FAIL"
    eta=(avg if avg else elapsed)*(n-i)
    print(f"[{i:02d}/{n:02d}] DONE {src.stem} {status} elapsed={fmt(elapsed)} remainingETA={fmt(eta)}",flush=True)
    if status=="FAIL":
        for x in (hard+rej)[:5]:print("   ERROR:",x,flush=True)
        for x in missing[:5]:print("   MISSING:",x,flush=True)
    a={"run_id":src.stem,"stage":stage,"status":status,"elapsed_seconds":elapsed,"process_exit":rc,
       "rejections":rej[:50],"hard_errors":hard[:50],"missing_outputs":missing}
    (ROOT/"logs"/f"{stage}__{src.stem}_audit.json").write_text(json.dumps(a,indent=2)+"\n",encoding="utf-8")
    return a

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage",choices=["cold_overlap","cold_extension","continuation"],required=True)
    ap.add_argument("--progress-every",type=float,default=60.0)
    a=ap.parse_args()
    folder={"cold_overlap":"kpc_cold_overlap","cold_extension":"kpc_cold_extension","continuation":"kpc_continuation"}[a.stage]
    exe,cwd=resolve();scripts=sorted((ROOT/folder).glob("*.kpc"));times=[];bad=0
    print("Executable:",exe);print("CWD:",cwd);print("Stage:",a.stage);print("Scripts:",len(scripts))
    for i,p in enumerate(scripts,1):
        avg=sum(times)/len(times) if times else None
        r=one(exe,cwd,p,a.stage,i,len(scripts),avg,a.progress_every)
        if r["status"]=="PASS":times.append(r["elapsed_seconds"])
        elif r["status"]=="FAIL":bad+=1
    print(f"{a.stage.upper()} COMPLETE: FAIL={bad}")
    return 1 if bad else 0
if __name__=="__main__":raise SystemExit(main())
