# E012 v0.1.0 run report

Verdict: **DYNAMIC_EIGENBRANCH_NOT_CONVERGED**

E011 seed: `SEED_25f0195c1c823d27` (gilbert)
C006: `v0.3.0`
Preset: `full`
Resolved mode samples: `5`
Dimensionless branch converged: `False`

The branch is a frozen-local C006 Kelvin-generator result.  It is not a true Floquet branch and is not identified as a photon.

A052 SI handoff: **A052_PHYSICAL_HANDOFF_BLOCKED**

Physical handoff blockers:
- NO_PHYSICAL_SCALE_CONTRACT
