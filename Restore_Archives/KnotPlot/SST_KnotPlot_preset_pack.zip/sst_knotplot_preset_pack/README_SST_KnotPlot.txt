SST KnotPlot preset pack
========================

Files
-----
1. sst_knotplotrc_user_block.kps
   Paste this under USER CUSTOMIZATIONS in:
   C:\Users\oscar\AppData\Roaming\KnotPlot\knotplotrc.kps

2. make_trefoil_relaxed.kps
   Standalone script that creates:
   - trefoil_relaxed.txt
   - trefoil_relaxed.eps

3. reexport_uploaded_trefoil.kps
   Loads an existing trefoil_relaxed.txt from the working folder, runs the SST gate report,
   and regenerates trefoil_relaxed_reexport.eps.

4. sst_batch_candidates.kps
   Runs identical intake for:
   3_1, 4_1, 5_1, 5_2, 6_2, 7_4.

5. trefoil_relaxed_stats.json
   Independent numerical summary of the uploaded trefoil_relaxed.txt geometry.

Recommended workflow
--------------------
Make a separate KnotPlot project folder, for example:
C:\Users\oscar\Documents\SST_KnotPlot_runs

Copy the .kps scripts there.

Interactive run from KnotPlot Command Window:
< make_trefoil_relaxed.kps

Batch run from terminal:
knotplot -nog < make_trefoil_relaxed.kps

After adding the rc block, these commands become available in every KnotPlot session:
- sstbase
- sstreport
- ssttrefoil
- sstgo100
- sstgo1000
- sstmake_trefoil_relaxed
- k31, k41, k51, k52, k62, k74
- sstmirrorx, sstmirrory, sstmirrorz

Notes
-----
The scripts are designed as SST geometry intake, not as a physics solver.
They preserve topology by reporting safety, Dowker code, extended Gauss code,
length, minimum distance, angle diagnostics, average crossing number, and writhe.

Exact coordinates may vary with KnotPlot version, catalogue embedding, and relaxation settings.
Use the TXT output as input for SSTcore/Biot-Savart/BEM after topology gates pass.
