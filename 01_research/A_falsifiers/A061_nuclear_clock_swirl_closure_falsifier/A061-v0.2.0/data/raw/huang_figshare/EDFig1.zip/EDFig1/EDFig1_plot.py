#!/usr/bin/env python3
"""Reproduce EDFig1 from the packaged B-line source data only."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import ticker
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit, least_squares


PACKAGE_DIR = Path(__file__).resolve().parent
DATA_FILE = PACKAGE_DIR / "source_data" / "EDFig1_B_line_source_data.csv"
DERIVED_DIR = PACKAGE_DIR / "derived_data"
RESULTS_DIR = PACKAGE_DIR / "results"
DERIVED_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

BLUE = "#2196F3"
BLACK = "#000000"
GRAY = "#555555"


def unit_lorentzian(x, center, fwhm):
    return 1.0 / (1.0 + 4.0 * ((x - center) / fwhm) ** 2)


def double_model(x, parameters):
    offset, cn, hn, gn, cb, hb, gb = parameters
    return offset + hn * unit_lorentzian(x, cn, gn) + hb * unit_lorentzian(x, cb, gb)


def single_model(x, amplitude, center, fwhm, offset):
    return offset + amplitude * unit_lorentzian(x, center, fwhm)


def core_model(x, amplitude, center, fwhm):
    return amplitude * unit_lorentzian(x, center, fwhm)


def numerical_jacobian(model, x, parameters):
    parameters = np.asarray(parameters, float)
    jacobian = np.empty((len(x), len(parameters)))
    relative_step = np.cbrt(np.finfo(float).eps)
    for index, value in enumerate(parameters):
        step = relative_step * max(1.0, abs(value))
        delta = np.zeros_like(parameters)
        delta[index] = step
        jacobian[:, index] = (
            model(x, parameters + delta) - model(x, parameters - delta)
        ) / (2.0 * step)
    return jacobian


def ols_errors(model, x, y, parameters):
    residual = model(x, parameters) - y
    dof = len(x) - len(parameters)
    rss = float(np.sum(residual**2))
    jacobian = numerical_jacobian(model, x, parameters)
    covariance = (rss / dof) * np.linalg.pinv(jacobian.T @ jacobian)
    return np.sqrt(np.clip(np.diag(covariance), 0, np.inf)), rss, dof


def fit_double_unweighted(x, y):
    baseline_seed = float(np.quantile(y, 0.08))
    center_seed = float(x[np.argmax(y)])
    peak = max(float(y.max() - baseline_seed), 1e-10)
    best = None

    for narrow_center_seed in [center_seed, 0.0, center_seed - 10.0, center_seed + 10.0]:
        for broad_shift in [-80.0, -40.0, 0.0, 40.0, 80.0]:
            for narrow_width_seed in [15.0, 25.0, 40.0, 70.0, 120.0]:
                for broad_width_seed in [180.0, 250.0, 320.0, 450.0, 700.0, 1000.0]:
                    if broad_width_seed <= narrow_width_seed:
                        continue
                    z0 = np.array([
                        baseline_seed,
                        narrow_center_seed,
                        narrow_center_seed + broad_shift,
                        np.log(0.7 * peak),
                        np.log(narrow_width_seed),
                        np.log(0.3 * peak),
                        np.log(broad_width_seed - narrow_width_seed),
                    ])
                    lower = np.array([
                        -5.0, x.min() - 1500.0, x.min() - 1500.0,
                        np.log(1e-12), np.log(5.0), np.log(1e-12), np.log(5.0),
                    ])
                    upper = np.array([
                        5.0, x.max() + 1500.0, x.max() + 1500.0,
                        np.log(100.0), np.log(500.0), np.log(100.0), np.log(5000.0),
                    ])

                    def unpack(z):
                        hn = np.exp(z[3])
                        gn = np.exp(z[4])
                        hb = np.exp(z[5])
                        gb = gn + np.exp(z[6])
                        return np.array([z[0], z[1], hn, gn, z[2], hb, gb])

                    def residual(z):
                        return double_model(x, unpack(z)) - y

                    result = least_squares(residual, z0, bounds=(lower, upper), max_nfev=150000)
                    rss = float(np.sum(residual(result.x) ** 2))
                    if best is None or rss < best[0]:
                        best = (rss, unpack(result.x))

    parameters = best[1]
    errors, rss, dof = ols_errors(double_model, x, y, parameters)
    return parameters, errors, rss, dof


def fit_single_unweighted(x, y):
    peak_index = int(np.argmax(y))
    offset_seed = float(np.mean(y[np.abs(x) > 80])) if np.any(np.abs(x) > 80) else 0.0
    p0 = [y[peak_index] - offset_seed, x[peak_index], 22.0, offset_seed]
    bounds = ([0, -30, 1.0, -0.1], [2, 30, 200.0, 0.5])
    parameters, _ = curve_fit(single_model, x, y, p0=p0, bounds=bounds, maxfev=20000)
    wrapped = lambda values, params: single_model(values, *params)
    errors, rss, dof = ols_errors(wrapped, x, y, parameters)
    return parameters, errors, rss, dof


def fit_core_unweighted(x, y):
    peak_index = int(np.argmax(y))
    parameters, _ = curve_fit(
        core_model,
        x,
        y,
        p0=[y[peak_index], x[peak_index], 20.0],
        bounds=([0, -10, 1.0], [2, 10, 100.0]),
        maxfev=20000,
    )
    wrapped = lambda values, params: core_model(values, *params)
    errors, rss, dof = ols_errors(wrapped, x, y, parameters)
    return parameters, errors, rss, dof


def main():
    data = pd.read_csv(DATA_FILE).sort_values("detuning_kHz")
    x_input = data["detuning_kHz"].to_numpy(float)
    x_nominal = np.rint(x_input)
    if np.max(np.abs(x_input - x_nominal)) > 1e-6:
        raise ValueError("A detuning differs from its nominal integer setpoint by >1e-6 kHz")
    x = x_nominal.astype(int)
    y_raw = data["normalized_signal"].to_numpy(float)
    error_raw = data["statistical_error"].to_numpy(float)
    normalization = float(np.max(y_raw))
    y = y_raw / normalization
    error = error_raw / normalization

    double_p, double_e, double_rss, double_dof = fit_double_unweighted(x, y)
    single_mask = np.abs(x) <= 102.0
    core_mask = np.abs(x) <= 25.0
    single_p, single_e, single_rss, single_dof = fit_single_unweighted(
        x[single_mask], y[single_mask]
    )
    core_p, core_e, core_rss, core_dof = fit_core_unweighted(
        x[core_mask], y[core_mask]
    )

    pd.DataFrame({
        "detuning_kHz": x,
        "peak_normalized_signal": y,
        "peak_normalized_statistical_error": error,
    }).to_csv(
        DERIVED_DIR / "EDFig1_B_line_plot_points.csv",
        index=False,
        float_format="%.17g",
    )

    parameter_rows = []
    double_names = ["offset", "narrow_center", "narrow_height", "narrow_FWHM",
                    "broad_center", "broad_height", "broad_FWHM"]
    for name, value, standard_error in zip(double_names, double_p, double_e):
        parameter_rows.append({
            "model": "double_Lorentzian_independent_centers",
            "parameter": name,
            "value": value,
            "standard_error_OLS": standard_error,
            "unit": "kHz" if "center" in name or "FWHM" in name else "normalized_signal",
            "rss": double_rss,
            "dof": double_dof,
        })
    single_names = ["height", "center", "FWHM", "offset"]
    for name, value, standard_error in zip(single_names, single_p, single_e):
        parameter_rows.append({
            "model": "single_Lorentzian",
            "parameter": name,
            "value": value,
            "standard_error_OLS": standard_error,
            "unit": "kHz" if name in {"center", "FWHM"} else "normalized_signal",
            "rss": single_rss,
            "dof": single_dof,
        })
    pd.DataFrame(parameter_rows).to_csv(
        DERIVED_DIR / "EDFig1_B_line_fit_parameters.csv",
        index=False,
        float_format="%.17g",
    )

    fit_x = np.arange(-1100, 1101, dtype=int)
    pd.DataFrame({
        "detuning_kHz": fit_x,
        "double_Lorentzian": double_model(fit_x, double_p),
        "single_Lorentzian": single_model(fit_x, *single_p),
        "core_Lorentzian": core_model(fit_x, *core_p),
    }).to_csv(
        DERIVED_DIR / "EDFig1_B_line_fit_curves.csv",
        index=False,
        float_format="%.17g",
    )

    plt.rcParams.update({
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "font.family": "DejaVu Sans", "font.size": 7,
        "axes.labelsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
        "legend.fontsize": 6.2, "figure.dpi": 150, "savefig.dpi": 600,
        "savefig.bbox": "tight", "axes.linewidth": 0.5,
        "xtick.major.width": 0.5, "ytick.major.width": 0.5,
        "xtick.direction": "in", "ytick.direction": "in",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "path.simplify": False,
    })

    fig = plt.figure(figsize=(3.386, 3.0))
    grid = fig.add_gridspec(2, 1, height_ratios=[2.5, 1.0], left=0.16,
                            right=0.95, top=0.96, bottom=0.10, hspace=0.06)
    ax_main = fig.add_subplot(grid[0, 0])
    ax_residual = fig.add_subplot(grid[1, 0], sharex=ax_main)

    ax_main.errorbar(x, y, yerr=error, fmt="o", ms=3.4, capsize=0,
                     color=BLUE, ecolor=BLUE, elinewidth=0.5, mew=0.5,
                     mfc="none", zorder=3)
    ax_main.plot(fit_x, double_model(fit_x, double_p), "--", color=BLACK,
                 lw=1.0, alpha=0.85, label="Double-Lorentzian")
    ax_main.plot([], [], "--", color=BLUE, lw=0.9, label="Single-Lorentzian")
    ax_main.plot(fit_x, core_model(fit_x, *core_p), "--", color=GRAY,
                 lw=0.7, alpha=0.7, label="Core-Lorentzian")
    ax_main.set_xlim(-1100, 1100)
    ax_main.set_ylim(-0.07, 1.07)
    ax_main.set_yticks([0.0, 0.5, 1.0])
    ax_main.set_ylabel("Norm. fluorescence", labelpad=2)
    ax_main.yaxis.set_label_coords(-0.15, 0.5)
    ax_main.tick_params(labelbottom=False)
    ax_main.legend(loc="upper left", bbox_to_anchor=(0.02, 0.95), frameon=True,
                   handlelength=1.2, borderpad=0.35, labelspacing=0.25)

    inset = ax_main.inset_axes([0.60, 0.49, 0.36, 0.45])
    inset_mask = (x >= -135) & (x <= 135)
    inset.errorbar(x[inset_mask], y[inset_mask], yerr=error[inset_mask],
                   fmt="o", ms=2.7, capsize=0, color=BLUE, ecolor=BLUE,
                   elinewidth=0.4, mew=0.45, mfc="none", zorder=3)
    inset_x = np.linspace(-135, 135, 500)
    inset.plot(inset_x, single_model(inset_x, *single_p), "--", color=BLUE, lw=0.9)
    inset.set_xlim(-135, 135)
    inset.set_ylim(0.0, 1.1)
    inset.set_xticks([-100, 0, 100])
    inset.set_yticks([0, 0.5, 1.0])
    inset.tick_params(labelsize=7, length=2.2, pad=1.0)

    residual = y - double_model(x, double_p)
    ax_residual.errorbar(x, residual, yerr=error, fmt="o", ms=3.4,
                         capsize=0, color=BLUE, ecolor=BLUE, elinewidth=0.5,
                         mew=0.5, mfc="none", zorder=3)
    ax_residual.axhline(0, color=GRAY, lw=0.7, ls="--", alpha=0.7)
    ax_residual.set_xlim(-1100, 1100)
    ax_residual.set_ylim(-0.07, 0.07)
    ax_residual.set_yticks([-0.05, 0.0, 0.05])
    ax_residual.set_xlabel("Freq. offset (kHz)", labelpad=2)
    ax_residual.set_ylabel("Residual", labelpad=2)
    ax_residual.yaxis.set_label_coords(-0.15, 0.5)

    for axis in (ax_main, ax_residual):
        axis.xaxis.set_major_locator(ticker.FixedLocator([-1000, -500, 0, 500, 1000]))
        axis.xaxis.set_minor_locator(ticker.AutoMinorLocator(2))
        axis.tick_params(which="both", width=0.5)
        axis.tick_params(which="minor", length=1.5)

    fig.savefig(RESULTS_DIR / "EDFig1.pdf")
    fig.savefig(RESULTS_DIR / "EDFig1.png")
    fig.savefig(RESULTS_DIR / "EDFig1.jpeg")
    plt.close(fig)

    print(
        f"Narrow FWHM = {double_p[3]:.3f} +/- {double_e[3]:.3f} kHz; "
        f"broad FWHM = {double_p[6]:.3f} +/- {double_e[6]:.3f} kHz"
    )
    print(f"Saved source-derived tables to {DERIVED_DIR}")
    print(f"Saved reproduced figure to {RESULTS_DIR}")


if __name__ == "__main__":
    main()
