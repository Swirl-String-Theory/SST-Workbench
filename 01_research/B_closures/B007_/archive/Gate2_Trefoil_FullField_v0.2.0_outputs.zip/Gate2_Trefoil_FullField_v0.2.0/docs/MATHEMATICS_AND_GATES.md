# Mathematical construction and qualification gates

## Topology-preserving whole-field action

For an original divergence-free compact smooth trefoil vorticity field `w0`,
let `Phi` be a composition of three smooth **elementary shears**

    S_i: (x_i,x_j,x_k) -> (x_i + f_i(x_j,x_k), x_j, x_k).

For each step, `det D S_i = 1`, and its smooth inverse is obtained by reversing
the sign of `f_i`. Consequently `Phi` is a global orientation-preserving
volume-preserving diffeomorphism for every finite real coefficient vector.

The transported vorticity is defined at the *exact continuum level* by

    w_a(Phi(X)) = D Phi(X) w0(X).

The Piola identity implies `div w_a = 0` whenever `div w0 = 0`; the field-line
image is homeomorphic to the original trefoil, and the flux over a material
cross-section is identical (Jacobian cofactor identity). Helicity is invariant
under this volume-preserving push-forward under the usual smooth/decay
assumptions, but it is not computed here as a separate numerical gate.

**Important:** finite Cartesian sampling breaks exact continuum identities:
its divergence is measured, not presumed zero. No projection/filter is applied.

## Residual and fitting

Let `U`, `Omega` be free axial translation/rotation speeds and `K` the
free-space Biot-Savart operator. We compute

    R = curl((K[w_a] - U ez - Omega (ez × x)) × w_a)

and use least squares to eliminate `U`, `Omega` for each candidate. Modal
Gauss-Newton steps perturb the actual full 3D transported field, not just a
centerline. We minimize the sampled L2 residual. The modeled variation space
has at most 15 finite modes in this version, and is **not** the full
infinite-dimensional volume-preserving diffeomorphism group.

Units: `R0=1`, `Gamma0=1`; `L0` from trefoil geometry. `R* =
L0^4/Gamma0^2 sqrt(integral |R|^2 / (4.4)^3)` uses one common reference
volume to compare boxes of different size. Raw `div w` has dimension
`L^-1 T^-1` before dimensionalization; `D* = L0^3/|Gamma0| rms(div w)`.

## Independent validation, not mere solver convergence

Holdouts re-evaluate the exact analytically transformed field at frozen
coefficients and frozen rigid-frame velocities without using optimizer state,
at `24³`, `32³`, `40³`, `48³`, and `64³`. Comparison measures:

- The original free-space **vector** Biot-Savart midpoint convolution.
- An independently constructed **scalar Newton-potential** convolution
  followed by numerical curl (same physical free-space target but a different
  discrete Green-function quadrature).
- The residual computed with independent 2nd and 4th-order finite-difference
  curls.
- Raw discrete divergence before any projection.
- One enlarged physical box at matching cell size (`32³,4.4` vs `40³,5.5`).

Residuals on available grids are **not** compatible with established zero;
no convergence proof is claimed. A significant discrepancy between the two
Green-function approaches and large raw divergence preclude a qualified root.

## Gates

- **S0** volume-preserving invertible exact map and analytic topology/flux
  invariance: software + geometric identity tests **PASS**.
- **S1** search with a reproducible fixed twist leaf: **PASS (operational)**.
- **S2** independent holdout runs/box test: **PASS (executed)**.
- **G2** stationary Euler residual tends to zero under genuine independent
  spatial refinement: **NOT ESTABLISHED**.
- **G3** linear/Arnold stability: **NOT RUN**.
- **BG** dynamical background filaments: **NOT RUN**.

Do not claim G2 success from finite-grid residual reduction, discrete
volume conservation, preserved topology, or absence of numerical crash.

## Limits and next needed mathematical advances

1. Improve core quadrature and compatible divergence-preserving spatial
   discretization *without* numerically suppressing physical residual.
2. Increase admissible displacement basis toward a complete family of smooth
   compactly supported divergence-free generator fields, with new gauge-fixed
   modes and quantified spatial approximation.
3. Add full-field Jacobian-vector products on isovortical tangent directions
   and a matrix-free Newton-Krylov solver (current solver is modal Gauss-Newton).
4. Implement independent free-space Poisson/velocity benchmarks and qualified
   ring equilibria before asserting the trefoil root.
5. Quantify the continuum residual on held-out higher resolutions and test
   sensitivity to core profile, twist leaf, and box extent separately.

## References for mathematical comparison

- V. I. Arnold (1966), *Annales de l'Institut Fourier* 16, 319–361.
  DOI: 10.5802/aif.233.
- A. Enciso and D. Peralta-Salas (2015), *Acta Mathematica* 214, 61–134.
  DOI: 10.1007/s11511-015-0123-z.
- O. Gonzalez and J. H. Maddocks (1999), *PNAS* 96, 4769–4773.
  DOI: 10.1073/pnas.96.9.4769.
