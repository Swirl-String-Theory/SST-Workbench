# High-resolution audit — SST dimensionless dynamic predictions v0.3.0 outputs

## Executive verdict

The uploaded package contains the full B0–B8 ladder with **2726 official result rows**, plus smoke tests, continuum validation scans, earlier controls and deterministic reruns.

\[
\boxed{
\begin{array}{c}
\texttt{B0-RING-CONTROL-PASS}\\
\texttt{B1-RIGID-ROTATION-INVARIANCE-PASS}\\
\texttt{B4-CHIRAL-PARITY-RELATION-PASS}\\
\texttt{B6A-PHYSICAL-FLUX-SCALING-PASS}\\
\texttt{B6B/B7-DISCRETIZATION-CONVERGENCE-PASS}\\
\texttt{B8-CLOCK-KINEMATICS-PASS}\\
\texttt{FROZEN-STRAIGHT-BUNDLE-STABILIZATION-FAIL}\\
\texttt{FULL-3D-BACKREACTION-OPEN}
\end{array}
}
\]

The straight, frozen axial vortex-bundle implementation is internally consistent and numerically convergent. It does **not** stabilize the static trefoil or figure-eight centerlines. The strongest positive result is the clean separation between physical-tube scaling, numerical discretization convergence, chirality and circulation-clock bookkeeping.

## 1. Inventory and integrity

| Gate | Runs |
|---|---:|
| B0 isolated control | 32 |
| B1 large-radius uniform control | 16 |
| B2 hole-matched continuum | 64 |
| B3 radius-ratio sweep | 48 |
| B4 chirality sweep | 384 |
| B5 topology sweep | 128 |
| B6 physical tubes | 512 |
| B6 numerical discretization | 768 |
| B7 discretization convergence | 756 |
| B8 circulation clock | 18 |

All official rows have `valid_geometry = true`.

The separately named `bundle_physical_tubes` and `bundle_numerical_discretization` directories are deterministic reruns of B6. Their largest numeric differences from the canonical B6 summaries are respectively

\[
nan
\quad\text{and}\quad
nan.
\]

These are floating-point-level differences, not independent physical replications.

## 2. B0 isolated controls

| Topology | Mean intrinsic residual | Minimum | Maximum | Gate |
|---|---:|---:|---:|---|
| Ring $0_1$ | 8.51384e-05 | 1.45841e-15 | 0.000243668 | PASS |
| Trefoil $3_1$ | 0.226306 | 0.220538 | 0.233747 | FAIL |
| Mirror trefoil | 0.226306 | 0.220538 | 0.233747 | FAIL |
| Figure-eight $4_1$ | 0.464808 | 0.453947 | 0.47691 | FAIL |

The preregistered gate is

\[
\epsilon_{m intrinsic}<0.05.
\]

The ring is a valid numerical control. The static ideal-knot trefoil and figure-eight are not relative equilibria of the selected regularized filament dynamics.

## 3. B1 uniform-vorticity control

The large-radius Rankine limit behaves as rigid solid-body rotation. The maximum difference between the intrinsic residual and the isolated baseline is

\[
1.110e-16.
\]

This verifies that the corrected intrinsic gate is invariant under a purely rigid background rotation. A uniform infinite-radius vortex changes the laboratory-frame angular rate, but not intrinsic shape stability.

## 4. B2–B3 frozen continuum bundle

No hole-matched continuum run passes the \(5\%\) gate. The best B2 result is

\[
\epsilon_{\rm intrinsic}=0.221893.
\]

The B3 radius sweep with \(\Gamma_{\rm hole}=1\) improves as the bundle becomes wider, but remains above the isolated baseline:

| \(R_{\rm bundle}/R_{\rm hole}\) | Mean residual |
|---:|---:|
| 0.5 | 0.309938 |
| 0.75 | 0.309938 |
| 1 | 0.309938 |
| 1.25 | 0.307798 |
| 1.5 | 0.281784 |
| 2 | 0.258472 |

The broader validation scan found one weak improvement:

\[
R_{\rm bundle}/R_{\rm hole}=2,
\qquad
\Gamma_{\rm hole}=-0.25,
\]

\[
\epsilon_{\rm intrinsic}=0.219211,
\qquad
rac{\epsilon_0-\epsilon}{\epsilon_0}
=0.602\%.
\]

This is only a \(0.6\%\)-level reduction and is far from the required \(<0.05\) residual. It is a small response, not stabilization.

## 5. B4 chirality result

The strongest symmetry result in the package is exact:

\[
oxed{
\epsilon_{3_1}(\Gamma)
=
\epsilon_{\overline{3_1}}(-\Gamma)
}
\]

for every matched B4 protocol. The maximum numerical violation is

\[
0.000e+00.
\]

At the same circulation sign, trefoil and mirror trefoil differ. The largest same-sign residual difference is

\[
0.042519.
\]

Thus the bundle produces a real chirality-sensitive response while preserving exact parity under simultaneous mirror and circulation reversal. This is a valid dimensionless Research-Track observable, although it does not create a stable state.

## 6. B5 topology sweep
| Topology | Minimum residual | Mean residual | Pass fraction |
|---|---:|---:|---:|
| ring | 1.69108e-15 | 0.000085 | 1.000 |
| trefoil | 0.237601 | 0.282508 | 0.000 |
| mirror_trefoil | 0.237601 | 0.282508 | 0.000 |
| figure_eight | 0.497085 | 0.553312 | 0.000 |

Only the ring survives the topology sweep. The background bundle worsens the trefoil and figure-eight residuals in the tested B5 range.

## 7. B6A physical tubes

Physical tubes obey

\[
\Gamma_{m hole}=N\Gamma_{m tube}.
\]

The implementation passes this scaling identity. Increasing \(N\) increases total flux, clock rate and deformation. For \(|\Gamma_{m tube}|=0.25\), the mean residual grows approximately as:

| \(N\) | Mean residual |
|---:|---:|
| 1 | 0.232748 |
| 7 | 0.442625 |
| 19 | 1.056637 |
| 37 | 2.023822 |

The minimum B6A residual is

\[
0.221893,
\]

and the best residual-reduction fraction is still negative:

\[
-0.006142.
\]

Therefore no tested physical straight-tube configuration improves on the isolated trefoil baseline.

## 8. B6B/B7 numerical discretization

Numerical discretization obeys

\[
\Gamma_{\rm tube}=rac{\Gamma_{\rm hole}}{N},
\]

so total flux and clock rate remain fixed as \(N\) changes.

Against the continuous Rankine reference, B7 gives:

| \(N\) | Mean velocity relative error | Mean residual relative error | Mean residual absolute difference |
|---:|---:|---:|---:|
| 1 | 0.000e+00 | 5.056e-17 | 1.542e-17 |
| 7 | 1.445e-04 | 8.807e-04 | 3.291e-04 |
| 19 | 1.933e-04 | 8.299e-04 | 3.206e-04 |
| 37 | 1.112e-04 | 4.768e-04 | 1.843e-04 |
| 61 | 8.578e-05 | 3.681e-04 | 1.422e-04 |
| 91 | 7.436e-05 | 3.193e-04 | 1.234e-04 |

The \(N=1\) identity is a degenerate centered-tube construction and should not be interpreted as a general convergence order. From \(N=7\) onward, the error decreases toward the continuum. At \(N=91\):

\[
\langle\delta uangle=7.436e-05,
\qquad
\langle\delta\epsilonangle=3.193e-04.
\]

The clock rate is exactly independent of \(N\) at fixed total circulation.

This is a successful numerical continuum test. It certifies the frozen straight-tube representation, not full three-dimensional vortex-bundle dynamics.

## 9. B8 circulation phase clock

The implemented clock is kinematic:

\[
\Omega_\Gamma
=
rac{\Gamma_{\rm hole}}{2\pi R_{\rm bundle}^2},
\qquad
T_\Gamma
=
rac{2\pi}{|\Omega_\Gamma|}.
\]

Across the official ladder the maximum clock-frequency identity error is

\[
1.421e-13,
\]

and the maximum period identity error is

\[
8.327e-17.
\]

For physical tubes with fixed \(\Gamma_{\rm tube}\),

\[
|\Omega_\Gamma|\propto N.
\]

For numerical discretization with fixed \(\Gamma_{\rm hole}\),

\[
\Omega_\Gamma=	ext{constant in }N.
\]

This cleanly separates physical tube count from numerical resolution.

However, the result is not yet an emergent-time theorem. The formula is a declared turnover-phase clock derived from prescribed circulation and radius. To establish emergent proper time, the project still needs a dynamically selected bundle radius, a stable recurrent state and a derived bridge from circulation phase to the canonical Swirl-Clock rate.

## 10. Final scientific interpretation

### Established by v0.3.0

\[
oxed{
egin{aligned}
&	ext{straight-tube flux scaling is correct;}\\
&	ext{fixed-total-flux discretization converges;}\\
&	ext{the circulation clock is dimensionally and numerically consistent;}\\
&	ext{the trefoil has an exact chirality/parity response;}\\
&	ext{uniform rigid rotation leaves intrinsic stability unchanged.}
\end{aligned}
}
\]

### Falsified within the tested model

\[
oxed{
	ext{A static ideal trefoil is not stabilized by a frozen, straight,}
\atop
	ext{finite-radius axial Rankine bundle over the scanned parameter domain.}
}
\]

### Still open

\[
oxed{
	ext{Dynamic tube bending, Kelvin modes, density redistribution,}
\atop
	ext{mutual induction and full 3D backreaction remain untested.}
}
\]

The next release should target B6C rather than merely enlarging the frozen-parameter sweep. The minimum useful B6C model should evolve the trefoil and a small symmetric bundle of periodic axial filaments together, track reconnection-free topology, and compare the coupled Floquet spectrum against the frozen-bundle null model.
