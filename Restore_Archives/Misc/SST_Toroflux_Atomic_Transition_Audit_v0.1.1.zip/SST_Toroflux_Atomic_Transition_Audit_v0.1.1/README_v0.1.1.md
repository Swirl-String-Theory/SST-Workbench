# SST Toroflux Atomic Transition Audit v0.1.1

This package tests the literal hypothesis that a bound electron is a flattened Toroflux-like core
at an atomic radius and that atomic jumps are single sprite/giant-jet-like circulation events.

Run:

```bash
python sst_toroflux_atomic_transition_gates_v0.1.1.py
```

Key verdict:

`LITERAL-CORE-ORBIT-FALSIFIED / FIXED-CIRCULATION-LADDER-FALSIFIED /
CANON-GAMMA0-ATOMIC-NORMALIZATION-FALSIFIED / CORE-PLUS-EXTERNAL-ENVELOPE-REMAINS-OPEN`
