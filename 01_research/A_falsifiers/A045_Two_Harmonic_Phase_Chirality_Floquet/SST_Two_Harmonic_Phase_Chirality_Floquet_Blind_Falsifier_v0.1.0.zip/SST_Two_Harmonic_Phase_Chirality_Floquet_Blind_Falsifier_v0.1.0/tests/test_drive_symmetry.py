from sst_thpcf.drive import c3_dynamic_symmetry_residual

def test_cnr_has_c3_dynamic_symmetry():
    r = c3_dynamic_symmetry_residual(1.0, 1.0, 0.65, 0.37, "CNR")
    assert r < 1e-10

def test_cor_is_control():
    r = c3_dynamic_symmetry_residual(1.0, 1.0, 0.65, 0.37, "COR")
    assert r > 1e-2
