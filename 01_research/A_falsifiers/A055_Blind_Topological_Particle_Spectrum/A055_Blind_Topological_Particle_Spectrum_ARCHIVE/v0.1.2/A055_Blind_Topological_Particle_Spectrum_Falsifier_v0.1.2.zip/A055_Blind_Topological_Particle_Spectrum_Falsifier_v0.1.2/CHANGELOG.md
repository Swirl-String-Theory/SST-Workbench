# Changelog

## v0.1.2 — 2026-10-06

- Replaces random-lane PD embeddings with a planarity-preserving realization of the PD rotation system.
- Adds periodic Fourier smoothing before resolution sampling.
- Replaces vertex-only contact distance by exact segment-segment distance with fixed component-arclength exclusion.
- Removes finite-core regularization from Gauss writhe/linking integrals; Neumann energy remains regularized.
- Adds integer-residual qualification for link observables.
- Adds hard topology calibrations: `L2a1` |Lk|=1, `L4a1` |Lk|=2, `L6a4` pairwise Lk=0.
- Corrects the global look-elsewhere statistic by comparing familywise empirical p-values instead of raw log-RMS errors across unequal mass spans.
- Adds a registered mass-fit effect-size gate `log_rms <= 0.25`.
- Retains 35 knots + 47 links, blind HMAC IDs, resolution/CV qualification, 10,000 null trials, and strict feature-domain masks.
