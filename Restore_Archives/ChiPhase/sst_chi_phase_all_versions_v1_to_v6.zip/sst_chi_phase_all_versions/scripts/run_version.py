#!/usr/bin/env python3
"""Run one packaged chi-phase version from this combined archive.

Examples:
  python scripts/run_version.py v6 --python
  python scripts/run_version.py v5 --sweep --python

This script changes into the selected version folder and runs its simulate_*.py file.
"""
from __future__ import annotations
import os, sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION_MAP = {
    "v1": ("versions/v1_shared_moment_consistency", "simulate_chi_phase.py"),
    "v2": ("versions/v2_shape_robustness_consistency", "simulate_chi_phase_v2.py"),
    "v3": ("versions/v3_profile_derived_stiffness", "simulate_chi_phase_v3.py"),
    "v4": ("versions/v4_four_profile_admissibility", "simulate_chi_phase_v4.py"),
    "v5": ("versions/v5_profile_zoo_selector", "simulate_chi_phase_v5.py"),
    "v6": ("versions/v6_smooth_matched_root_selector", "simulate_chi_phase_v6.py"),
}

def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in VERSION_MAP:
        print("Usage: python scripts/run_version.py {v1|v2|v3|v4|v5|v6} [extra args]")
        return 2
    key = sys.argv[1]
    rel_dir, script = VERSION_MAP[key]
    workdir = ROOT / rel_dir
    script_path = workdir / script
    if not script_path.exists():
        print(f"Missing script: {script_path}")
        return 1
    cmd = [sys.executable, str(script_path)] + sys.argv[2:]
    print(f"[*] Running {' '.join(cmd)}")
    return subprocess.call(cmd, cwd=str(workdir))

if __name__ == "__main__":
    raise SystemExit(main())
