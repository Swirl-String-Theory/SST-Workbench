# Theorem Target v0.0.8 - Three-Path Selection Audit for \(\beta_Q\)

## Release verdict

\[
\boxed{
\begin{array}{c}
\texttt{THREE-PATH-AUDIT-PASS}\\
\texttt{UNIQUE-BETA-NOT-DERIVED}\\
\texttt{SELF-DUAL-CANDIDATE-REJECTED-FOR-CURRENT-WILSON-SECTOR}
\end{array}}
\]

Version 0.0.8 tests all three mechanisms proposed in v0.0.7:

\[
\text{vacuum free-energy stationarity},\qquad
\text{electric--magnetic duality},\qquad
\text{knot--link impedance matching}.
\]

The audit deliberately distinguishes numerical coincidence from independent
provenance. Neither \(G\), \(L_p\), the GR area density, nor the previous
hierarchy factor is used to select \(\beta_Q\). The observed value of \(c\) is
retained only as a post-selection comparator.

## 1. Frozen v0.0.7 family

The nonlinear neck model gives

\[
I_\ell=\frac{\pi}{2}\rho_\star r_c^4a_\star,
\]

\[
K_\ell=
\frac{\rho_\star\Gamma_0^2a_\star}{2\pi^3}
\Lambda(a_\star),
\qquad
\Lambda(a_\star)=
\ln\!\left(\frac{a_\star}{2r_c}\right)+\frac14,
\]

and

\[
\boxed{
\beta_Q=\frac{\sqrt{I_\ell K_\ell}}{\hbar}.}
\]

The propagation speed is

\[
\boxed{
c_T=\frac{2\beta_Q\hbar}{\pi\rho_\star r_c^4}.}
\]

The problem is therefore to select one member of this family without using the
validation targets.

# Route A - Vacuum free-energy stationarity

## 2. Raw Wilson free energy

For the Wilson partition function

\[
Z_W(\beta)=
\int\mathcal D\vartheta\,
\exp\!\left[\beta\sum_p\cos\theta_p\right],
\]

define the free-energy density per plaquette

\[
f_W(\beta)=-\frac{1}{N_p}\ln Z_W(\beta).
\]

Then

\[
\boxed{
\frac{df_W}{d\beta}
=-\left\langle\cos\theta_p\right\rangle_\beta.}
\]

At the candidate \(\beta=1/(2\pi)\), the deterministic \(4^4\) hot/cold
simulation gives

\[
\left\langle\cos\theta_p\right\rangle
=7.71527308759\times10^{-2},
\]

so that

\[
\frac{df_W}{d\beta}
=-7.71527308759\times10^{-2}\neq0.
\]

Thus the raw Wilson free energy has no stationary point at the proposed
self-dual value. More generally, for positive coupling the plaquette expectation
is positive and the raw free energy is monotonic.

## 3. Zero-point stationarity in the adjacency length

For the two transverse harmonic branches, the cell zero-point energy scales as

\[
E_{0,\mathrm{cell}}(a_\star)
\propto\sqrt{\Lambda(a_\star)}.
\]

Consequently,

\[
\frac{d\ln E_{0,\mathrm{cell}}}{d\ln a_\star}
=\frac{1}{2\Lambda}>0.
\]

The corresponding energy density scales as

\[
u_0(a_\star)
\propto
\frac{\sqrt{\Lambda(a_\star)}}{a_\star^3},
\]

with

\[
\frac{d\ln u_0}{d\ln a_\star}
=\frac{1}{2\Lambda}-3.
\]

On the declared Rankine domain \(a_\star\geq2r_c\), one has
\(\Lambda\geq1/4\), hence

\[
\frac{d\ln u_0}{d\ln a_\star}\leq-1.
\]

The cell energy increases while the energy density decreases. Neither has an
interior stationary point, and they prefer opposite boundaries. A stabilizing
adjacency chemical potential, pressure term, or edge-formation energy is
therefore missing.

## 4. Duality-normalized free energy

An exactly self-dual modified Villain theory satisfies

\[
Z(\beta)
=(2\pi\beta)^{-3V}Z(\widetilde\beta),
\qquad
\widetilde\beta=\frac{1}{4\pi^2\beta}.
\]

If

\[
f(\beta)=-\frac1V\ln Z(\beta),
\]

then

\[
\widehat f(\beta)
:=f(\beta)-\frac32\ln(2\pi\beta)
\]

is invariant under \(\beta\leftrightarrow\widetilde\beta\). In terms of
\(x=\ln(2\pi\beta)\), \(\widehat f(x)=\widehat f(-x)\), so

\[
\left.\frac{d\widehat f}{dx}\right|_{x=0}=0.
\]

This gives

\[
\boxed{\beta_Q^{\rm sd}=\frac{1}{2\pi}.}
\]

However, this is not an independent free-energy mechanism: the stationary point
is a direct consequence of the duality imposed in Route B. It also concerns a
modified Villain action, not the Wilson action simulated in v0.0.7.

### Route-A verdict

\[
\boxed{
\text{Raw vacuum free-energy stationarity is rejected as a standalone selector.}}
\]

The duality-normalized variant is retained only as a reformulation of Route B.

# Route B - Electric--magnetic duality

## 5. Weak-field duality does not select a coupling

In the quadratic photon sector, every normal mode is a harmonic oscillator.
Its ground state has equal mean electric and magnetic energies. This
virial/equipartition statement holds for every positive \(I_\ell\) and
\(K_\ell\); it cannot select \(\beta_Q\).

The field rescaling freedom also changes the continuum impedance while leaving
\(c_T\) invariant. Therefore a formal interchange of \(\mathcal E\) and
\(\mathcal B\) in the linear equations is insufficient.

## 6. Exact modified-Villain duality

For the exact electric--magnetic lattice duality,

\[
\widetilde\beta
=\frac{1}{4\pi^2\beta}.
\]

The unique positive fixed point is

\[
\boxed{
\beta_Q^{\rm sd}=\frac{1}{2\pi}
=0.159154943091895\ldots .}
\]

In the v0.0.7 neck family, using the horn-envelope sensitivity branch, this
value gives

\[
\boxed{
a_\star=2r_c
=2.81794043\times10^{-15}\ \mathrm m,}
\]

\[
\Lambda=\frac14,
\qquad
c_T=\frac{2}{\pi}\mathbf v_{\!\circlearrowleft}
=6.96363822\times10^5\ \mathrm{m\,s^{-1}},
\]

\[
\eta_{\rm cap}^{(2)}
=1.74578935\times10^{29}\ \mathrm{m^{-2}}.
\]

The same point is strongly confining in the current Wilson theory:

\[
\left\langle\cos\theta_p\right\rangle
\simeq0.07715,
\qquad
\rho_{\rm monopole}\simeq0.43182.
\]

The exact self-dual formulation removes lattice monopoles through a closedness
constraint, or restores electric--magnetic symmetry by adding matched electric
and magnetic matter. It is therefore a different microscopic theory.

### Route-B verdict

\[
\boxed{
\text{Exact duality selects }\beta_Q=1/(2\pi)
\text{ only after a model change.}}
\]

It does not select an admissible member of the current Wilson compact-link
sector.

# Route C - Knot--link impedance matching

## 7. Link action impedance

From the continuum coefficients

\[
\epsilon_\ell\simeq\frac{I_\ell}{a_\star},
\qquad
\mu_\ell^{-1}\simeq K_\ell a_\star,
\]

one obtains

\[
Z_\ell
=\sqrt{\frac{\mu_\ell}{\epsilon_\ell}}
=\frac{1}{\sqrt{I_\ell K_\ell}}
=\frac{1}{\hbar\beta_Q}.
\]

It is useful to define the reciprocal action impedance

\[
\boxed{
\mathcal J_\ell:=\sqrt{I_\ell K_\ell}=\hbar\beta_Q.}
\]

Matching to a resolved knot action \(\mathcal J_K\) would give

\[
\boxed{
\beta_Q=\frac{\mathcal J_K}{\hbar}.}
\]

This is a valid selection principle only when \(\mathcal J_K\) is independently
computed from a certified knot eigenmode and a local tube profile.

## 8. Why the apparent impedance closure is circular

The current horn-envelope calibration obeys numerically

\[
\boxed{
\rho_{\rm horn}\Gamma_0r_c^3
=0.999999904882\,\hbar.}
\]

Defining a phase action per radian by

\[
\mathcal J_{K,\mathrm{phase}}
=\frac{\rho_{\rm horn}\Gamma_0r_c^3}{2\pi}
\]

therefore gives

\[
\beta_Q^{\rm phase}
=\frac{\mathcal J_{K,\mathrm{phase}}}{\hbar}
\simeq\frac{1}{2\pi}.
\]

But defining the action of the complete \(2\pi\) cycle gives

\[
\mathcal J_{K,\mathrm{cycle}}
=\rho_{\rm horn}\Gamma_0r_c^3
\]

and hence

\[
\beta_Q^{\rm cycle}\simeq1.
\]

The two candidates differ by exactly \(2\pi\). The present action does not
specify which quantity is to be matched.

More importantly, the current Canon states that \(\rho_{\rm horn}\) is a
horn-envelope normalization density, not a measured local density of the
resolved vortex tube. It was obtained through the calibrated electron/Compton
chain and already contains the action scale. Thus the equality above is a
reparameterized calibration identity, not a new microscopic derivation.

### Route-C verdict

\[
\boxed{
\text{Impedance matching remains open and has a }2\pi
\text{ normalization ambiguity.}}
\]

A valid calculation requires

\[
\mathcal J_K
=\frac{E_K}{\omega_K}
\]

or the complete phase-space cycle

\[
\oint p_K\,dq_K
\]

from a resolved tube with independently derived \(a_{\rm core}\), local density,
mode shape, and eigenfrequency.

# 9. Dependency collapse

Three paths appear to meet at

\[
\beta_Q=\frac1{2\pi}.
\]

They are not three independent derivations:

1. the duality-normalized free-energy stationary point is mathematically caused
   by exact electric--magnetic duality;
2. exact duality selects the fixed point only for a modified Villain/electric--
   magnetic-completed theory;
3. the phase-action impedance value uses the calibrated identity
   \(\rho_{\rm horn}\Gamma_0r_c^3=\hbar\) and an unproved per-radian
   normalization.

Thus the common value is a dependency collapse, not a multiple-route theorem.

# 10. Current position of Route I

Closed or strongly supported:

- the analytic family \((a_\star,I_\ell,K_\ell)(\beta_Q)\);
- the Hamiltonian-to-Wilson map;
- the finite-volume Coulomb window of the current Wilson model;
- rejection of raw free-energy stationarity;
- identification of the exact-duality model change;
- identification of the impedance normalization/provenance failure.

Still open:

- a unique non-circular \(\beta_Q\);
- a resolved local tube density and radius;
- a certified knot action \(\mathcal J_K\);
- species-independent knot--link impedance matching;
- thermodynamic-limit phase certification;
- blind reproduction of \(c_T=c\);
- the absolute Route-I area density.

## Falsifiable v0.0.9 target

The next valid target is

\[
\boxed{
\text{compute }\mathcal J_K=E_K/\omega_K
\text{ from resolved knot modes and test }
\beta_Q=\mathcal J_K/\hbar.}
\]

The preregistered geometry ladder is

\[
\text{round ring}\rightarrow
\text{axisymmetric torus}\rightarrow
3_1\rightarrow\overline{3_1}\rightarrow4_1.
\]

One common \(\beta_Q\) must emerge without per-carrier retuning. If the values
remain geometry-dependent, knot--link impedance matching is rejected as a
universal selector.
