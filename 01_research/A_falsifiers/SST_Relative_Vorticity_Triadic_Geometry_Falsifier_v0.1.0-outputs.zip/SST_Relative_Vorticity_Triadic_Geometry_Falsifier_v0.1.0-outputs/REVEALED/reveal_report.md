# A045 reveal report

Blind seal: **VERIFIED**

Blind numerical status: **PIPELINE_QUALIFIED**

HWC basis: **REJECTED_AS_LOCAL_COMPLETE_BASIS**

UWS basis: **STRUCTURALLY_ADMISSIBLE_NOT_VALIDATED_AS_GRAVITY**

## Canonical scale evaluation

- beta = 3.648676278574e-03
- Swirl-Clock = 9.999933435586e-01
- n_gamma - 1 (exact) = 6.656485755485e-06
- delta p_swirl = -4.187743917945e+05 Pa
- n_gamma - 1 (leading pressure lock) = 6.656419292914e-06
- Gamma_0 = 9.683619203489e-09 m^2 s^-1
- F_swirl_max / F_gr_max = 9.602465271695e-43

These values were inserted after the blind result was sealed.
