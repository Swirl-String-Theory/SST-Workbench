# BEMv18 extended local scan report

Target policy: all knots up to and including 7 crossings, plus requested selected higher knots if present in `ideal.txt`.

## Selected targets

- `3_1` / `3:1:1`: `L_cert=16.371637`
- `4_1` / `4:1:1`: `L_cert=21.043322`
- `5_1` / `5:1:1`: `L_cert=23.598564`
- `5_2` / `5:1:2`: `L_cert=24.734148`
- `6_1` / `6:1:1`: `L_cert=28.354929`
- `6_2` / `6:1:2`: `L_cert=28.508783`
- `6_3` / `6:1:3`: `L_cert=28.915367`
- `7_1` / `7:1:1`: `L_cert=30.700289`
- `7_2` / `7:1:2`: `L_cert=31.931015`
- `7_3` / `7:1:3`: `L_cert=31.964205`
- `7_4` / `7:1:4`: `L_cert=32.130192`
- `7_5` / `7:1:5`: `L_cert=32.627506`
- `7_6` / `7:1:6`: `L_cert=32.82069`
- `7_7` / `7:1:7`: `L_cert=32.800343`
- `8_1` / `8:1:1`: `L_cert=35.491375`
- `9_1` / `9:1:1`: `L_cert=37.744167`
- `9_2` / `9:1:2`: `L_cert=39.016441`
- `10_1` / `10:1:1`: `L_cert=42.58107`

## Missing requested extras

- `11_1` -> `11:1:1`: `MISSING_FROM_IDEAL`
- `11_2` -> `11:1:2`: `MISSING_FROM_IDEAL`

## Run status

- successful/available BEMv13 runs: `0/18`
- aggregate status: `NOT_RUN`

## Main aggregate output

After a run, inspect:

```text
aggregate/bemv18_exponent_certificate.csv
aggregate/bemv18_length_exponent_scan.csv
aggregate/bemv18_raw_multiknot_budget.csv
```