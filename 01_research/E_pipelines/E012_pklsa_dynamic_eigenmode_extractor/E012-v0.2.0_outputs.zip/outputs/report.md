# E012 v0.2.0 run report

Verdict: **DYNAMIC_EIGENBRANCH_NOT_QUALIFIED**

Preset: `quick`

## Provider results

- `gilbert`: qualified modes `0`, RPO accepted `False`, numerical branch `False`
- `knotplot`: qualified modes `0`, RPO accepted `False`, numerical branch `False`

Cross-provider dynamic agreement: `False`
Dimensionless branch qualified: `False`

v0.2.0 uses a same-generator RPO qualification and eigenvector-overlap branch tracking. An accepted RPO is conditioning evidence only; no true Floquet/monodromy claim is made.

A052 SI handoff: **A052_PHYSICAL_HANDOFF_BLOCKED**

A052 handoff blockers:
- PROVIDER_NUMERICAL_BRANCH_NOT_QUALIFIED:gilbert
- RPO_BACKGROUND_NOT_QUALIFIED:gilbert
- PROVIDER_NUMERICAL_BRANCH_NOT_QUALIFIED:knotplot
- RPO_BACKGROUND_NOT_QUALIFIED:knotplot
- CROSS_PROVIDER_DYNAMIC_AGREEMENT_FAILED
- NO_PHYSICAL_SCALE_CONTRACT
