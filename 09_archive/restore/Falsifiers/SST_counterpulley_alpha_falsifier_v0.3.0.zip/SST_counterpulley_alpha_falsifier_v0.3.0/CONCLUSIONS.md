# CONCLUSIONS — v0.3.0

## Status

**Current route: falsified / unsupported as a global Floquet explanation of alpha.**

The failure is informative rather than merely numerical.

## [DERIVED POSITIVE] A non-topological dynamic phase exists

The temporal Biot–Savart linearisation projected onto the pre-registered `m=1` Kelvin subspace produces a dimensionless counter-propagating eigenphase that is distinct from the v0.2 clock-free normal-bundle holonomy.

At the resolved control point:

- dynamic phase: `-0.1311765177` turns (`N=1024`);
- v0.2 director holonomy: `+0.4179999745` turns;
- ribbon `Tw=Lk-Wr`: `+0.4179161061` turns.

Therefore the v0.3 observable does **not** reduce to the ribbon topology identity that closed the pure-holonomy route.

## [DERIVED NEGATIVE] The current pair is not a relative equilibrium

At `N=2048` the best rigid translation+rotation removes only a tiny fraction of the Biot–Savart velocity field:

```text
relative_equilibrium_residual = 0.9989498433
```

The full preregistered limit is `0.15`. H3 fails by a very large margin.

Consequently

```text
M = exp(J T_F)
```

is a frozen local monodromy diagnostic, not the variational monodromy of a demonstrated periodic base orbit.

## [DERIVED NEGATIVE] The attractive N=768 alpha proximity is not converged

The blind ladder contains

```text
N=768:  h_F = -0.1197034353 turns
```

which post-hoc is only about `2.06%` away from the required alpha correction. However the predeclared higher-resolution sequence moves monotonically away:

```text
N=1024: -0.1311765177
N=1536: -0.1402860038
N=2048: -0.1436561389
```

The `N=768` agreement is therefore classified as a false-positive discretisation coincidence.

## [DERIVED NEGATIVE] Canonical alpha miss

After unblinding:

```text
alpha0^-1              = 137.1532832132
required correction    = -0.1172840362
v0.3 h_F (N=2048)      = -0.1436561389
predicted alpha^-1     = 137.0096270743
correction-unit error  = 0.2248567113
```

The canonical result misses the required correction by about `22.49%`.

## [DERIVED NEGATIVE] Nuisance dependence remains large

H10 fails. In the preregistered sweeps the phase spans approximately

```text
regularisation spread        = 0.46955 turns
channel-orientation spread   = 0.39962 turns
```

so no parameter-free universal phase has yet emerged.

## [DERIVED NEGATIVE] The doublet is not a clean oscillatory clock

For the full canonical result:

```text
|Re lambda+|/|Im lambda+| = 0.00758
|Re lambda-|/|Im lambda-| = 0.26266
```

The positive-frequency member is nearly neutral, but the counter-propagating member has substantial growth/decay. H11 fails the full `0.10` threshold.

## Next route

The correct next target is upstream of alpha:

1. solve a `+Gamma/-Gamma` trefoil pair as a **relative equilibrium** or **relative periodic orbit** of the same regularised Biot–Savart dynamics;
2. verify recurrence after removing rigid Euclidean motion;
3. integrate the full variational equation along that orbit,
   `dPhi/dt = J(t) Phi`, `Phi(0)=I`;
4. obtain the true monodromy `M=Phi(T)`;
5. extract robust Floquet multipliers and mode phases;
6. keep alpha closed until all numerical, topology, symmetry, core-model and recurrence gates pass.

That would convert the current frozen-spectrum diagnostic into an actual Floquet test.
