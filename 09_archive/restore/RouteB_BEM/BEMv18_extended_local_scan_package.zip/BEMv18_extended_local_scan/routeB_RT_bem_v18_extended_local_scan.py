#!/usr/bin/env python3
r"""
routeB_RT_bem_v18_extended_local_scan.py
========================================

Extended local scanner for the BEMv18 multi-knot length-exponent test.

Default target policy
---------------------
1. include all knots in ideal.txt up to and including 7 crossings;
2. then add selected higher targets:
       8_1, 9_1, 9_2, 10_1, 11_1, 11_2
   but only if they exist in ideal.txt.

The script writes:
  target_catalog_available.csv
  target_catalog_missing.csv
  targets_available.json
  targets_missing.json
  run_manifest.csv

If --run is supplied, it runs BEMv13 once per target with resume/skip support,
then calls BEMv18 in reuse mode to aggregate the exponent scan.

No observed alpha is used.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: List[str] = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def parse_attrs(tag: str) -> Dict[str, str]:
    return {m.group(1): m.group(2) for m in re.finditer(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"([^"]*)"', tag)}


def ideal_id_to_name(bid: str) -> str:
    """Map Brian Gilbert ideal IDs to standard knot table names.

    ID convention in ideal.txt is crossing:component:index, e.g.
    5:1:2 -> 5_2 and 7:1:4 -> 7_4.
    """
    parts = str(bid).split(":")
    if len(parts) >= 3:
        return f"{parts[0]}_{parts[2]}"
    if len(parts) >= 2:
        return f"{parts[0]}_{parts[1]}"
    return str(bid).replace(":", "_")


def name_to_id(name: str) -> str:
    m = re.match(r"^(\d+)_(\d+)$", name)
    if m:
        return f"{m.group(1)}:1:{m.group(2)}"
    return name


def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.+-]+", "_", str(s)).strip("_")


def parse_ideal(path: Path) -> Dict[str, Dict[str, Any]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    out: Dict[str, Dict[str, Any]] = {}
    for m in re.finditer(r"<AB\b([^>]*)>", text, flags=re.I):
        attrs = parse_attrs(m.group(1))
        bid = attrs.get("Id", "")
        if not bid:
            continue
        parts = bid.split(":")
        if len(parts) < 3:
            continue
        try:
            crossing = int(parts[0])
            index = int(parts[2])
        except Exception:
            continue
        name = ideal_id_to_name(bid)
        rec = {
            "id": bid,
            "name": name,
            "crossing": crossing,
            "index": index,
            "conway": attrs.get("Conway", ""),
            "L_cert": float(attrs["L"]) if attrs.get("L") else "",
            "D_database": float(attrs["D"]) if attrs.get("D") else "",
            "n_components": int(attrs.get("n", "1").strip() or "1"),
        }
        out[bid] = rec
        out[name] = rec
    return out


def select_targets(catalog: Dict[str, Dict[str, Any]], max_crossing: int, extras_csv: str, only_single_component: bool = True) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    selected: List[Dict[str, Any]] = []
    seen = set()

    # First all knots up to max_crossing, sorted by crossing then index.
    base_recs = []
    for rec in catalog.values():
        # catalog has id and name duplicate keys; use id key only.
        if rec["id"] in seen:
            continue
        if 3 <= int(rec["crossing"]) <= max_crossing:
            if only_single_component and int(rec.get("n_components", 1)) != 1:
                continue
            base_recs.append(rec)
    base_recs.sort(key=lambda r: (int(r["crossing"]), int(r["index"])))

    for rec in base_recs:
        if rec["id"] not in seen:
            seen.add(rec["id"])
            selected.append(rec)

    missing = []
    for token in [x.strip() for x in extras_csv.split(",") if x.strip()]:
        key = token if token in catalog else name_to_id(token)
        rec = catalog.get(key)
        if rec is None:
            missing.append({
                "requested": token,
                "resolved_id": key,
                "status": "MISSING_FROM_IDEAL",
            })
            continue
        if only_single_component and int(rec.get("n_components", 1)) != 1:
            missing.append({
                "requested": token,
                "resolved_id": key,
                "status": "SKIP_NON_SINGLE_COMPONENT",
            })
            continue
        if rec["id"] not in seen:
            seen.add(rec["id"])
            selected.append(rec)

    return selected, missing


def resolve_script(primary: str, local_name: str, fallback: str) -> Path:
    if primary:
        p = Path(primary)
        if p.exists():
            return p
        raise FileNotFoundError(p)
    p = Path(__file__).with_name(local_name)
    if p.exists():
        return p
    p = Path(fallback)
    if p.exists():
        return p
    raise FileNotFoundError(f"could not find {local_name} or {fallback}")


def run_target(args, target: Dict[str, Any], run_dir: Path) -> Dict[str, Any]:
    run_dir.mkdir(parents=True, exist_ok=True)
    done = run_dir / "alpha_component_budget_v13.csv"
    if done.exists() and not args.force:
        return {
            "target": target["name"],
            "target_id": target["id"],
            "run_dir": str(run_dir),
            "returncode": 0,
            "mode": "skip_existing",
            "status": "SKIP_EXISTING",
        }

    v13 = resolve_script(args.v13_script, "routeB_RT_bem_v13_certified_length_budget.py", "/mnt/data/routeB_RT_bem_v13_certified_length_budget.py")
    v8 = resolve_script(args.v8_script, "routeB_RT_bem_v8_pair_length_budget.py", "/mnt/data/routeB_RT_bem_v8_pair_length_budget.py")
    ids = f"0:1:1,{target['id']}"

    cmd = [
        sys.executable, str(v13),
        "--ideal", str(args.ideal),
        "--v8-script", str(v8),
        "--outdir", str(run_dir),
        "--ideal-xml-knot-ids", ids,
        "--target", target["name"],
        "--reference", "0_1",
        "--n-center", str(args.n_center),
        "--n-theta", str(args.n_theta),
        "--n-sphere", str(args.n_sphere),
        "--tube-fraction", str(args.tube_fraction),
        "--outer-factor", str(args.outer_factor),
        "--pair-fit-min-M", str(args.pair_fit_min_M),
        "--pair-fit-tail-frac", str(args.pair_fit_tail_frac),
        "--length-samples", str(args.length_samples),
        "--normalizers", args.normalizers,
        "--preferred-normalizer", args.preferred_normalizer,
        "--subrun-timeout", str(args.subrun_timeout),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=args.target_run_timeout)
    (run_dir / "bemv13_stdout.txt").write_text(proc.stdout, encoding="utf-8", errors="replace")
    (run_dir / "bemv13_stderr.txt").write_text(proc.stderr, encoding="utf-8", errors="replace")

    return {
        "target": target["name"],
        "target_id": target["id"],
        "run_dir": str(run_dir),
        "returncode": proc.returncode,
        "mode": "run_bemv13",
        "status": "PASS" if proc.returncode == 0 else "FAIL",
        "command": " ".join(cmd),
    }


def run_aggregate(args, run_dirs: List[Path], aggregate_dir: Path) -> int:
    v18 = resolve_script(args.v18_script, "routeB_RT_bem_v18_multiknot_exponent_test.py", "/mnt/data/routeB_RT_bem_v18_multiknot_exponent_test.py")
    aggregate_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable, str(v18),
        "--ideal", str(args.ideal),
        "--from-bemv13-outdirs", ",".join(str(p) for p in run_dirs),
        "--outdir", str(aggregate_dir),
        "--preferred-normalizer", args.preferred_normalizer,
        "--scan-a", args.scan_a,
        "--scan-b", args.scan_b,
        "--ratio-threshold", str(args.ratio_threshold),
        "--min-knots", str(args.min_knots),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=args.aggregate_timeout)
    (aggregate_dir / "aggregate_stdout.txt").write_text(proc.stdout, encoding="utf-8", errors="replace")
    (aggregate_dir / "aggregate_stderr.txt").write_text(proc.stderr, encoding="utf-8", errors="replace")
    return proc.returncode


def write_report(outdir: Path, selected: List[Dict[str, Any]], missing: List[Dict[str, Any]], manifest: List[Dict[str, Any]], aggregate_status: str) -> None:
    lines = [
        "# BEMv18 extended local scan report",
        "",
        "Target policy: all knots up to and including 7 crossings, plus requested selected higher knots if present in `ideal.txt`.",
        "",
        "## Selected targets",
        "",
    ]
    for r in selected:
        lines.append(f"- `{r['name']}` / `{r['id']}`: `L_cert={r['L_cert']}`")
    lines += ["", "## Missing requested extras", ""]
    if missing:
        for r in missing:
            lines.append(f"- `{r['requested']}` -> `{r['resolved_id']}`: `{r['status']}`")
    else:
        lines.append("- none")
    lines += ["", "## Run status", ""]
    if manifest:
        ok = sum(1 for r in manifest if str(r.get("returncode")) == "0")
        lines.append(f"- successful/available BEMv13 runs: `{ok}/{len(manifest)}`")
        lines.append(f"- aggregate status: `{aggregate_status}`")
    else:
        lines.append("- dry-run plan only; no BEMv13 runs executed")
    lines += [
        "",
        "## Main aggregate output",
        "",
        "After a run, inspect:",
        "",
        "```text",
        "aggregate/bemv18_exponent_certificate.csv",
        "aggregate/bemv18_length_exponent_scan.csv",
        "aggregate/bemv18_raw_multiknot_budget.csv",
        "```",
    ]
    (outdir / "EXTENDED_SCAN_REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ideal", default="ideal.txt")
    ap.add_argument("--outdir", default="outputs_routeB_BEM_v18_upto7_plus")
    ap.add_argument("--max-crossing", type=int, default=7)
    ap.add_argument("--extras", default="8_1,9_1,9_2,10_1,11_1,11_2")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--dry-run-plan", action="store_true")
    ap.add_argument("--force", action="store_true")

    ap.add_argument("--v13-script", default="")
    ap.add_argument("--v8-script", default="")
    ap.add_argument("--v18-script", default="")

    # Defaults deliberately moderate; override locally for production.
    ap.add_argument("--n-center", type=int, default=24)
    ap.add_argument("--n-theta", type=int, default=5)
    ap.add_argument("--n-sphere", type=int, default=96)
    ap.add_argument("--tube-fraction", type=float, default=0.30)
    ap.add_argument("--outer-factor", type=float, default=3.0)
    ap.add_argument("--pair-fit-min-M", type=int, default=8)
    ap.add_argument("--pair-fit-tail-frac", type=float, default=0.75)
    ap.add_argument("--length-samples", type=int, default=12000)
    ap.add_argument("--normalizers", default="raw,Mmax,Lcert,Lcert2,Lcert3,M_Lcert,M_Lcert2")
    ap.add_argument("--preferred-normalizer", default="M_Lcert2")
    ap.add_argument("--subrun-timeout", type=int, default=1800)
    ap.add_argument("--target-run-timeout", type=int, default=2400)

    # Aggregate exponent scan.
    ap.add_argument("--scan-a", default="1")
    ap.add_argument("--scan-b", default="0,1,2,3,4")
    ap.add_argument("--ratio-threshold", type=float, default=0.05)
    ap.add_argument("--min-knots", type=int, default=3)
    ap.add_argument("--aggregate-timeout", type=int, default=1200)

    args = ap.parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    catalog = parse_ideal(Path(args.ideal))
    selected, missing = select_targets(catalog, args.max_crossing, args.extras)

    write_csv(outdir / "target_catalog_available.csv", selected)
    write_csv(outdir / "target_catalog_missing.csv", missing)
    (outdir / "targets_available.json").write_text(json.dumps([r["id"] for r in selected], indent=2), encoding="utf-8")
    (outdir / "targets_missing.json").write_text(json.dumps(missing, indent=2), encoding="utf-8")

    manifest: List[Dict[str, Any]] = []
    aggregate_status = "NOT_RUN"

    if args.run and not args.dry_run_plan:
        runs_dir = outdir / "runs"
        runs_dir.mkdir(parents=True, exist_ok=True)
        for target in selected:
            rd = runs_dir / target["name"]
            result = run_target(args, target, rd)
            manifest.append(result)
            write_csv(outdir / "run_manifest.csv", manifest)

        ok_dirs = [Path(r["run_dir"]) for r in manifest if str(r.get("returncode")) == "0"]
        if ok_dirs:
            rc = run_aggregate(args, ok_dirs, outdir / "aggregate")
            aggregate_status = "PASS" if rc == 0 else f"FAIL_RETURN_{rc}"
        else:
            aggregate_status = "FAIL_NO_SUCCESSFUL_RUNS"
    else:
        for target in selected:
            manifest.append({
                "target": target["name"],
                "target_id": target["id"],
                "L_cert": target["L_cert"],
                "mode": "dry_run_plan",
                "status": "PLANNED",
            })
        write_csv(outdir / "run_manifest.csv", manifest)

    write_report(outdir, selected, missing, manifest, aggregate_status)
    (outdir / "run_config_extended_scan.json").write_text(json.dumps({"args": vars(args)}, indent=2, sort_keys=True), encoding="utf-8")

    print("=" * 78)
    print("BEMv18 extended local scan setup complete")
    print("=" * 78)
    print(f"outdir: {outdir}")
    print(f"selected targets: {len(selected)}")
    print(f"missing requested extras: {len(missing)}")
    for r in missing:
        print(f"missing: {r['requested']} -> {r['resolved_id']} [{r['status']}]")
    print(f"aggregate_status: {aggregate_status}")
    print("wrote: target_catalog_available.csv, target_catalog_missing.csv, targets_available.json, run_manifest.csv")


if __name__ == "__main__":
    main()
