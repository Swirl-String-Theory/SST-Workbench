#!/usr/bin/env python3
"""
Build helper for the optional C++ v10A.0 benchmark executable.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys


def find_compiler():
    for exe in ["c++", "g++", "clang++"]:
        path = shutil.which(exe)
        if path:
            return path
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    src = root / "sst_chi_phase_v10A0.cpp"
    out = root / ("sst_chi_phase_v10A0.exe" if os.name == "nt" else "sst_chi_phase_v10A0")

    if out.exists() and not args.force:
        print(f"Already built: {out}")
    else:
        compiler = find_compiler()
        if not compiler:
            raise SystemExit("No C++ compiler found (tried c++, g++, clang++).")
        cmd = [compiler, "-O3", "-std=c++17", str(src), "-o", str(out)]
        print(" ".join(cmd))
        subprocess.check_call(cmd)
        print(f"Built: {out}")

    if args.run:
        subprocess.check_call([str(out)])


if __name__ == "__main__":
    main()
