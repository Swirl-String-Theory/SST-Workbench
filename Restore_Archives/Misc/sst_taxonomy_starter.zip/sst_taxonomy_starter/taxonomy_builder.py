
from __future__ import annotations
import argparse, csv, io, json, os, re, zipfile
from pathlib import Path
from collections import defaultdict

CORE_IDS = [
    "1_1","3_1","4_1","5_1","5_2","6_1","7_1","7_2","8_1","9_1","9_2","10_1","11_1","11_2",
    "Hopf","Solomon","Borromean","triple_gear_realization"
]

IDENTITY_FIELDS = [
    "id","standard_name","components","is_prime","object_class","geometry_class",
    "crossing_number","braid_index","genus","determinant","signature","arf",
    "chirality_label","reversible","amphichiral","amphichiral_type","symmetry_group",
    "pd_code","dt_code","source","notes"
]
EMBED_FIELDS = [
    "embedding_id","id","variant","source_file","representation","ideal_or_relaxed","sample_count",
    "curve_length","bbox_xmin","bbox_xmax","bbox_ymin","bbox_ymax","bbox_zmin","bbox_zmax",
    "normalization","fourier_block_count","provenance","notes"
]
COMP_FIELDS = [
    "id","vol_hyperbolic","vol_ref","hvol_norm","method","backend","tolerance","status","provenance","notes"
]
FIELD_FIELDS = [
    "embedding_id","id","grid_size","spacing","interior","polyline_samples","Hc","Hm","a_mu",
    "descriptor_backend","status","provenance","notes"
]
VALID_FIELDS = [
    "run_id","id","backend","N_geom","N_int","A_K","A_ratio_1_over_4pi","a_nc_over_rc","a_star_over_rc",
    "contact_model","fit_window","lambda_K","root_choice","jump","postcheck_status","continuation_status",
    "source_script","notes"
]

def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fieldnames})

def read_csv_from_zip(zf: zipfile.ZipFile, name: str) -> list[dict]:
    data = zf.read(name).decode("utf-8", errors="ignore")
    return list(csv.DictReader(io.StringIO(data)))

def norm_id(raw: str) -> str:
    raw = raw.strip()
    raw = raw.replace("knot.", "").replace(".fseries", "")
    raw = raw.replace("knot_", "").replace("_sst", "")
    raw = raw.replace("L2a1", "Hopf").replace("L4a1", "Solomon").replace("L6a4", "Borromean")
    raw = raw.replace("11.1","11_1").replace("11.2","11_2")
    return raw

def split_variant(kid: str) -> tuple[str, str | None]:
    m = re.match(r"^((?:\d+_\d+)|(?:\d+[an]_\d+)|(?:\d+_\d+[an]?\d*))([a-z])$", kid)
    if m:
        return m.group(1), m.group(2)
    # handle common base ids like 3_1p / 8_10s
    m = re.match(r"^(\d+_\d+)([a-z])$", kid)
    if m:
        return m.group(1), m.group(2)
    return kid, None

def seed_identity() -> list[dict]:
    rows = []
    for kid in CORE_IDS:
        row = {
            "id": kid,
            "standard_name": kid,
            "components": 1,
            "is_prime": True,
            "object_class": "knot",
            "geometry_class": "unknown",
            "crossing_number": None,
            "braid_index": None,
            "genus": None,
            "determinant": None,
            "signature": None,
            "arf": None,
            "chirality_label": "unknown",
            "reversible": None,
            "amphichiral": None,
            "amphichiral_type": "unknown",
            "symmetry_group": None,
            "pd_code": None,
            "dt_code": None,
            "source": "seeded_starter",
            "notes": None,
        }
        if kid == "1_1":
            row["geometry_class"] = "unknot"
        elif kid in {"3_1","5_1","7_1"}:
            row["geometry_class"] = "torus"
        elif kid in {"4_1","5_2","6_1","7_2","8_1","9_1","9_2","10_1","11_1","11_2"}:
            row["geometry_class"] = "hyperbolic_or_unknown"
        elif kid in {"Hopf","Solomon","Borromean"}:
            row["components"] = 2 if kid in {"Hopf","Solomon"} else 3
            row["object_class"] = "link"
            row["is_prime"] = None
            row["geometry_class"] = "link"
        elif kid == "triple_gear_realization":
            row["components"] = 3
            row["object_class"] = "mechanical_realization"
            row["is_prime"] = None
            row["geometry_class"] = "linked_mechanical_hopf_type"
            row["notes"] = "Mechanical realization; not a standard knot-table object."
        if re.match(r"^\d+_\d+$", kid):
            row["crossing_number"] = int(kid.split("_")[0])
        rows.append(row)
    return rows

def extract_embeddings(resources_zip: Path | None, dashboard_zip: Path | None) -> list[dict]:
    seen = set()
    rows = []

    def add_row(src_zip: Path, internal_name: str):
        base_name = Path(internal_name).name
        if not base_name.endswith(".fseries"):
            return
        kid_raw = norm_id(base_name)
        kid_raw = kid_raw.replace("knot.", "").replace(".fseries", "")
        base_id, variant = split_variant(kid_raw)
        emb_id = f"{base_id}::{base_name}"
        if emb_id in seen:
            return
        seen.add(emb_id)
        rows.append({
            "embedding_id": emb_id,
            "id": base_id,
            "variant": variant or "base",
            "source_file": internal_name,
            "representation": "fseries",
            "ideal_or_relaxed": "resource_embedding",
            "sample_count": None,
            "curve_length": None,
            "bbox_xmin": None, "bbox_xmax": None,
            "bbox_ymin": None, "bbox_ymax": None,
            "bbox_zmin": None, "bbox_zmax": None,
            "normalization": None,
            "fourier_block_count": None,
            "provenance": src_zip.name,
            "notes": None,
        })

    for zpath in [resources_zip, dashboard_zip]:
        if not zpath:
            continue
        with zipfile.ZipFile(zpath) as zf:
            for name in zf.namelist():
                if name.lower().endswith(".fseries"):
                    add_row(zpath, name)
    return sorted(rows, key=lambda r: (r["id"], r["embedding_id"]))

def extract_field_descriptors(dashboard_zip: Path | None) -> list[dict]:
    if not dashboard_zip:
        return []
    rows = []
    with zipfile.ZipFile(dashboard_zip) as zf:
        target = "SST_Dashboard/exports/SST_helicity_by_base.csv"
        if target not in zf.namelist():
            return []
        for r in read_csv_from_zip(zf, target):
            kid = norm_id(r["base"])
            rows.append({
                "embedding_id": f"{kid}::aggregate_base",
                "id": kid,
                "grid_size": None,
                "spacing": None,
                "interior": None,
                "polyline_samples": None,
                "Hc": None,
                "Hm": None,
                "a_mu": r.get("mean"),
                "descriptor_backend": "helicity_csv_aggregate",
                "status": "aggregated_from_export",
                "provenance": target,
                "notes": f"std={r.get('std')}; count={r.get('count')}; is_amphi={r.get('is_amphi')}; flag={r.get('flag')}",
            })
    return rows

def extract_complement_geometry(dashboard_zip: Path | None, resources_zip: Path | None) -> list[dict]:
    rows_by_id = {}
    candidates = []
    if dashboard_zip:
        candidates.append((dashboard_zip, "SST_Dashboard/exports/fseries_batch_results.csv", "dashboard_fseries_batch"))
    if resources_zip:
        candidates.append((resources_zip, "resources/fseries_batch_results.csv", "resources_fseries_batch"))

    for zpath, internal, label in candidates:
        with zipfile.ZipFile(zpath) as zf:
            if internal not in zf.namelist():
                continue
            for r in read_csv_from_zip(zf, internal):
                kid = norm_id(r.get("knot_id", "") or r.get("file", ""))
                base_id, _ = split_variant(kid)
                hv = r.get("hyperbolic_volume_meta") or r.get("Hvortex_Vol(Vol/Vol(4_1))")
                if not hv:
                    continue
                existing = rows_by_id.get(base_id, {
                    "id": base_id,
                    "vol_hyperbolic": None,
                    "vol_ref": None,
                    "hvol_norm": None,
                    "method": "export_lookup",
                    "backend": "csv_export",
                    "tolerance": None,
                    "status": "unknown",
                    "provenance": internal,
                    "notes": None,
                })
                # store normalized hvol if available
                try:
                    val = float(hv)
                    if existing["hvol_norm"] is None:
                        existing["hvol_norm"] = val
                        existing["status"] = "partial_from_export"
                except Exception:
                    pass
                rows_by_id[base_id] = existing

    # add known non-hyperbolic core cases if absent
    for kid in ["1_1","3_1","5_1","7_1","Hopf","Solomon"]:
        rows_by_id.setdefault(kid, {
            "id": kid,
            "vol_hyperbolic": 0.0 if kid in {"3_1","5_1","7_1","1_1"} else None,
            "vol_ref": None,
            "hvol_norm": None,
            "method": "seeded",
            "backend": "starter",
            "tolerance": None,
            "status": "seeded_nonhyperbolic" if kid in {"1_1","3_1","5_1","7_1"} else "seeded_link_unknown",
            "provenance": "starter_seed",
            "notes": None,
        })
    return sorted(rows_by_id.values(), key=lambda r: r["id"])

def extract_validation_stub() -> list[dict]:
    return []

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--resources", type=Path, default=None)
    ap.add_argument("--dashboard", type=Path, default=None)
    ap.add_argument("--sstcore", type=Path, default=None)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    out = args.out
    out.mkdir(parents=True, exist_ok=True)

    identity_rows = seed_identity()
    embed_rows = extract_embeddings(args.resources, args.dashboard)
    field_rows = extract_field_descriptors(args.dashboard)
    comp_rows = extract_complement_geometry(args.dashboard, args.resources)
    val_rows = extract_validation_stub()

    write_csv(out / "taxonomy_identity.csv", identity_rows, IDENTITY_FIELDS)
    write_csv(out / "taxonomy_embeddings.csv", embed_rows, EMBED_FIELDS)
    write_csv(out / "taxonomy_complement_geometry.csv", comp_rows, COMP_FIELDS)
    write_csv(out / "taxonomy_field_descriptors.csv", field_rows, FIELD_FIELDS)
    write_csv(out / "taxonomy_validation.csv", val_rows, VALID_FIELDS)

    summary = {
        "identity_rows": len(identity_rows),
        "embedding_rows": len(embed_rows),
        "complement_rows": len(comp_rows),
        "field_rows": len(field_rows),
        "validation_rows": len(val_rows),
        "inputs": {
            "resources": str(args.resources) if args.resources else None,
            "dashboard": str(args.dashboard) if args.dashboard else None,
            "sstcore": str(args.sstcore) if args.sstcore else None,
        }
    }
    (out / "build_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
