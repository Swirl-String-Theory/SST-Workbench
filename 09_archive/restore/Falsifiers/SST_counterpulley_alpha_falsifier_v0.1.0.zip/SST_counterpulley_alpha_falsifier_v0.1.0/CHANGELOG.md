# Changelog

## v0.1.0 — 2026-08-07

- Forked from `SST_cpp_pybind_audit_template` build/fallback architecture.
- Added C++17 pybind11 regularized Biot-Savart velocity and filament interaction Hamiltonian kernels.
- Added NumPy/Python reference implementation for parity and fallback.
- Added parser for the user's KnotPlot-style `ideal.txt` AB Fourier format.
- Bundled only the `3:1:1` trefoil block (`L=16.371637`, `D=1`).
- Added closed Bishop material frame and opposite `+Gamma/-Gamma` channels.
- Added independent arclength resampling of offset filaments for stable line quadrature.
- Added strict blind hydrodynamics / post-hoc alpha separation.
- Added H0-H10 gates, convergence, epsilon, frame-phase, imbalance, and in-core scans.
- Added Windows `.cmd` install/build/native-preflight/quick/full/blind runners.
- Hardened the template builder so Windows can fall through to `setuptools`/MSVC even when `c++`, `g++`, or `clang++` are absent from PATH.
- Added `requirements.txt` with explicit `setuptools` dependency.
