LIST {
	{ < knot_7.3_trial_015k_rr_010k_coarse_rr_050k_eqfinal.30000.vect }
	{ < knot_7.3_trial_015k_rr_010k_coarse_rr_050k_eqfinal.30000.struts.vect }
	{ < knot_7.3_trial_015k_rr_010k_coarse_rr_050k_eqfinal.30000.dlen.vect }
	{ < knot_7.3_trial_015k_rr_010k_coarse_rr_050k_eqfinal.30000.dVdt.vect }
}
