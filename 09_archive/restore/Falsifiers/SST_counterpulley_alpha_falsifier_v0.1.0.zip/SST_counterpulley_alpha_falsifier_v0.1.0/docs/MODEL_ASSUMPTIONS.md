# Model assumptions v0.1.0

1. The fluid model is incompressible, inviscid and unforced.
2. The centerline is the bundled ideal trefoil `3:1:1` Fourier curve.
3. `D=1` from the ideal-knot metadata is treated as the tube-diameter unit.
4. The two channels carry equal and opposite full circulation magnitudes: `+Gamma` and `-Gamma`.
5. The canonical channel centers are at `a/D=0.5`, i.e. opposite radial sides of the nominal core.
6. A closed discrete Bishop frame defines the material cross-section. Its arbitrary phase is scanned rather than silently fixed as a fit parameter.
7. The regularized line Hamiltonian uses a Rosenhead-type denominator `sqrt(r^2+epsilon^2)`.
8. Offset filaments are independently resampled in arclength before double-line quadrature.
9. The candidate alpha correction is the multiplicative energy factor `G_E=E_pair/E_self`.
10. The measured alpha value is excluded from the blind solver and appears only in `benchmark.py`.
11. Passing H8 is not sufficient: H7, H9 and H10 must also pass for this v0.1.0 explanation to survive.
12. A failure of this mapping leaves phase-holonomy, helicity-transfer, and constrained eigenmode hypotheses open; those require new pre-registered observables.
