@echo off
setlocal
cd /d "%~dp0"
if not exist .venv py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -U pip
python -m pip install numpy pytest
python -m pytest -q
python -m sst_thpcf.campaign --config configs\basic.json --backend python --root . --reveal --package
endlocal
