"""GPU helpers for time-averaged Mach-1 supersonic-region analysis.

This is a public-release port of the original
``Plot/mod_250828_supersonic_region_module_gpu.py`` helper. The main public
release change is that callers pass an explicit ``Psi`` directory instead of
relying on a hard-coded output root.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks

try:
    import cupy as cp
except Exception:  # pragma: no cover - raw-output workflows require CuPy.
    cp = None

from functions import atan2_GPU, velocity_field_gpu
from Helmholtz_decompose import H_decompos_gpu
from variable import dx, dy, obstacle_position, x, y


X, Y = np.meshgrid(x, y)
SNAPSHOT_RE = re.compile(r"psi_time:([+-]?\d+(?:\.\d+)?)\.npy$")


def _require_cupy():
    if cp is None:
        raise ImportError(
            "CuPy is required for MACH-1 raw-output analysis. "
            "Install the GPU requirements and rerun this script on a CUDA-capable machine."
        )


def parse_snapshot_time(path: str | Path) -> float:
    match = SNAPSHOT_RE.search(Path(path).name)
    if match is None:
        raise ValueError(f"Cannot parse snapshot time from filename: {path}")
    return float(match.group(1))


def list_snapshot_files(
    psi_dir: str | Path,
    *,
    time_min: float | None = None,
    time_max: float | None = None,
) -> list[Path]:
    psi_path = Path(psi_dir).expanduser().resolve()
    files = sorted(psi_path.glob("psi_time:*.npy"), key=parse_snapshot_time)

    if time_min is not None:
        files = [path for path in files if parse_snapshot_time(path) >= time_min]
    if time_max is not None:
        files = [path for path in files if parse_snapshot_time(path) <= time_max]

    if not files:
        raise FileNotFoundError(
            f"No psi_time snapshots found in {psi_path} within "
            f"time_min={time_min}, time_max={time_max}."
        )
    return files


def build_crop_slice_from_limits(
    xrel_lim: tuple[float, float],
    y_lim: tuple[float, float],
    *,
    obstacle_x: float = obstacle_position,
):
    x_rel = x - obstacle_x
    x_idx = np.where((x_rel >= xrel_lim[0]) & (x_rel <= xrel_lim[1]))[0]
    y_idx = np.where((y >= y_lim[0]) & (y <= y_lim[1]))[0]

    if x_idx.size == 0 or y_idx.size == 0:
        raise ValueError("Requested crop limits do not overlap the simulation grid.")

    return np.s_[y_idx[0] : y_idx[-1] + 1, x_idx[0] : x_idx[-1] + 1]


def crop_coordinate_axes(crop_slice=None):
    if crop_slice is None:
        return x.copy(), y.copy()

    y_slice, x_slice = crop_slice
    return x[x_slice].copy(), y[y_slice].copy()


def load_psi_snapshot(
    path: str | Path,
    *,
    crop_slice=None,
    prefer_complex64: bool = True,
):
    psi_np = np.load(path)
    if crop_slice is not None:
        psi_np = psi_np[crop_slice]
    if prefer_complex64 and np.iscomplexobj(psi_np) and psi_np.dtype != np.complex64:
        psi_np = np.asarray(psi_np, dtype=np.complex64)
    return psi_np


def iter_psi_snapshots(
    psi_dir: str | Path,
    *,
    crop_slice=None,
    time_min: float | None = None,
    time_max: float | None = None,
    prefer_complex64: bool = True,
):
    _require_cupy()

    for path in list_snapshot_files(psi_dir, time_min=time_min, time_max=time_max):
        psi_np = load_psi_snapshot(path, crop_slice=crop_slice, prefer_complex64=prefer_complex64)
        try:
            yield parse_snapshot_time(path), cp.asarray(psi_np)
        finally:
            del psi_np


def compute_TF_profile_gpu(Xg, Yg, V0, sigma, x0=100.0, y0=0.0):
    _require_cupy()

    r2 = (Xg - x0) ** 2 + (Yg - y0) ** 2
    V_obs = V0 * cp.exp(-2.0 * r2 / (sigma**2))
    return cp.maximum(1.0 - V_obs, 0.0)


def compute_time_averaged_mach1_field(
    psi_dir: str | Path,
    *,
    V0: float,
    sigma: float,
    background_speed: float,
    crop_slice=None,
    time_min: float | None = None,
    time_max: float | None = None,
    obstacle_x: float = obstacle_position,
    obstacle_y: float = 0.0,
):
    _require_cupy()

    sum_x_irr = None
    sum_y_irr = None
    times = []
    count = 0

    for time_value, psi in iter_psi_snapshots(
        psi_dir,
        crop_slice=crop_slice,
        time_min=time_min,
        time_max=time_max,
    ):
        phase = atan2_GPU(psi.imag, psi.real)
        vx, vy = velocity_field_gpu(phase, dx, dy)
        (vx_irr, vy_irr), _ = H_decompos_gpu(vx, vy, psi.shape[1], psi.shape[0], dx, dy)

        if sum_x_irr is None:
            sum_x_irr = cp.zeros_like(vx_irr)
            sum_y_irr = cp.zeros_like(vy_irr)

        sum_x_irr += vx_irr - background_speed
        sum_y_irr += vy_irr
        times.append(time_value)
        count += 1

        del psi, phase, vx, vy, vx_irr, vy_irr
        cp.get_default_memory_pool().free_all_blocks()

    if count == 0:
        raise RuntimeError("No psi snapshots were accumulated for the requested Mach-1 field.")

    mean_x_irr = sum_x_irr / count
    mean_y_irr = sum_y_irr / count
    irr_speed = cp.sqrt(mean_x_irr**2 + mean_y_irr**2)

    if crop_slice is None:
        Xg = cp.asarray(X)
        Yg = cp.asarray(Y)
    else:
        Xg = cp.asarray(X[crop_slice])
        Yg = cp.asarray(Y[crop_slice])

    n_tf = compute_TF_profile_gpu(Xg, Yg, V0, sigma, x0=obstacle_x, y0=obstacle_y)
    cs_tf = cp.sqrt(n_tf)
    field = irr_speed - cs_tf
    mask = (field > 0).astype(cp.float32)

    x_crop, y_crop = crop_coordinate_axes(crop_slice)
    return {
        "field": cp.asnumpy(field),
        "mask": cp.asnumpy(mask),
        "mean_irrotational_speed": cp.asnumpy(irr_speed),
        "sound_speed_tf": cp.asnumpy(cs_tf),
        "x": x_crop,
        "y": y_crop,
        "x_relative": x_crop - obstacle_x,
        "time_values": np.asarray(times, dtype=float),
    }


def mean_supersonic_mask_gpu(
    psi_dir: str | Path,
    *,
    V0: float,
    sigma: float,
    background_speed: float,
    crop_slice=None,
    time_min: float | None = None,
    time_max: float | None = None,
    obstacle_x: float = obstacle_position,
    obstacle_y: float = 0.0,
):
    result = compute_time_averaged_mach1_field(
        psi_dir,
        V0=V0,
        sigma=sigma,
        background_speed=background_speed,
        crop_slice=crop_slice,
        time_min=time_min,
        time_max=time_max,
        obstacle_x=obstacle_x,
        obstacle_y=obstacle_y,
    )
    return result["mask"]


def measure_width_from_mask(mask, threshold=0.5):
    bin_mask = np.asarray(mask) > threshold
    rows_active = np.any(bin_mask, axis=1)
    cols_active = np.any(bin_mask, axis=0)
    y_idxs = np.where(rows_active)[0]
    x_idxs = np.where(cols_active)[0]

    if not bin_mask.any():
        return 0, 0, None

    y_min, y_max = y_idxs[0], y_idxs[-1] + 1
    x_min, x_max = x_idxs[0], x_idxs[-1] + 1
    y_width = y_max - y_min
    x_width = x_max - x_min
    roi_slice = (slice(y_min, y_max), slice(x_min, x_max))
    return x_width, y_width, roi_slice


def compute_mean_vorticity(
    psi_dir: str | Path,
    *,
    crop_slice=None,
    time_min: float | None = None,
    time_max: float | None = None,
):
    _require_cupy()

    omega_sum = None
    count = 0
    times = []

    for time_value, psi in iter_psi_snapshots(
        psi_dir,
        crop_slice=crop_slice,
        time_min=time_min,
        time_max=time_max,
    ):
        phase = atan2_GPU(psi.imag, psi.real)
        vx, vy = velocity_field_gpu(phase, dx, dy)
        omega = cp.gradient(vy, dx, axis=1) - cp.gradient(vx, dy, axis=0)

        if omega_sum is None:
            omega_sum = cp.array(omega, dtype=cp.float32)
        else:
            omega_sum += omega
        count += 1
        times.append(time_value)

        del psi, phase, vx, vy, omega
        cp.get_default_memory_pool().free_all_blocks()

    if count == 0:
        raise RuntimeError("No psi snapshots were accumulated for the requested vorticity field.")

    return {
        "omega_mean": cp.asnumpy(omega_sum / count),
        "time_values": np.asarray(times, dtype=float),
    }


def measure_vorticity_profile_width(
    mean_omega,
    roi_slice,
    *,
    margin_y: int = 40,
    margin_x: int = 3,
    cutoff_frac: float = 0.5,
):
    if roi_slice is None:
        return {
            "profile": np.array([]),
            "y_indices": np.array([], dtype=int),
            "band_widths": [],
            "peak_distance": None,
        }

    ny, nx = mean_omega.shape
    ry0, ry1 = roi_slice[0].start, roi_slice[0].stop
    rx0, rx1 = roi_slice[1].start, roi_slice[1].stop

    abs_y0 = max(0, ry0 - margin_y)
    abs_y1 = min(ny, ry1 + margin_y)
    abs_x0 = max(0, rx0 - margin_x)
    abs_x1 = min(nx, rx1 + margin_x)

    strength = np.sum(mean_omega[abs_y0:abs_y1, abs_x0:abs_x1], axis=1)
    y_coords = np.arange(abs_y0, abs_y1)

    if strength.size == 0:
        return {
            "profile": strength,
            "y_indices": y_coords,
            "band_widths": [],
            "peak_distance": None,
        }

    peak_val = float(np.max(strength))
    mask = strength > peak_val * cutoff_frac
    diffs = np.diff(mask.astype(int))
    starts = np.where(diffs == 1)[0] + 1
    ends = np.where(diffs == -1)[0] + 1
    if mask[0]:
        starts = np.r_[0, starts]
    if mask[-1]:
        ends = np.r_[ends, mask.size]
    widths = (ends - starts).tolist()

    peaks_pos, _ = find_peaks(strength, prominence=peak_val * cutoff_frac if peak_val else 0.0)
    if peaks_pos.size:
        main_pos_idx = peaks_pos[np.argmax(strength[peaks_pos])]
        y_main_pos = y_coords[main_pos_idx]
    else:
        y_main_pos = None

    troughs_neg, _ = find_peaks(-strength, prominence=peak_val * cutoff_frac if peak_val else 0.0)
    if troughs_neg.size:
        main_neg_idx = troughs_neg[np.argmax((-strength)[troughs_neg])]
        y_main_neg = y_coords[main_neg_idx]
    else:
        y_main_neg = None

    peak_distance = None
    if y_main_pos is not None and y_main_neg is not None:
        peak_distance = abs(int(y_main_pos - y_main_neg))

    return {
        "profile": strength,
        "y_indices": y_coords,
        "band_widths": widths,
        "peak_distance": peak_distance,
    }


def run_effective_vs_vortex_region(
    psi_dir: str | Path,
    *,
    V0: float,
    sigma: float,
    background_speed: float,
    crop_slice,
    time_min: float | None = None,
    time_max: float | None = None,
    margin_y: int = 40,
    margin_x: int = 3,
    cutoff_frac: float = 0.5,
    obstacle_x: float = obstacle_position,
    obstacle_y: float = 0.0,
):
    mach1 = compute_time_averaged_mach1_field(
        psi_dir,
        V0=V0,
        sigma=sigma,
        background_speed=background_speed,
        crop_slice=crop_slice,
        time_min=time_min,
        time_max=time_max,
        obstacle_x=obstacle_x,
        obstacle_y=obstacle_y,
    )
    x_width, y_width, roi_slice = measure_width_from_mask(mach1["mask"])

    omega_result = compute_mean_vorticity(
        psi_dir,
        crop_slice=crop_slice,
        time_min=time_min,
        time_max=time_max,
    )
    profile = measure_vorticity_profile_width(
        omega_result["omega_mean"],
        roi_slice,
        margin_y=margin_y,
        margin_x=margin_x,
        cutoff_frac=cutoff_frac,
    )

    return {
        "mach1": mach1,
        "effective_diameter_x": x_width,
        "effective_diameter_y": y_width,
        "roi_slice": roi_slice,
        "mean_vorticity": omega_result["omega_mean"],
        "vorticity_profile": profile,
    }

