"""Require actual numerical and scientific closure after framework CERTIFY mode.

Framework emits a complete gate ledger even when scientific criteria fail; this wrapper
prevents a successful process return from being mistaken for certified SST evidence.
"""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'A061_Nuclear_Clock_Swirl_Closure_Falsifier_v0.2.0-outputs'
ledger=json.loads((out/'GATE_LEDGER.json').read_text())
st={x['gate_id']:x['status'] for x in ledger['records']}
required=['G0','G1','G2','G3','G4','G5','G8','G11','G12','G13','G14','G15','G16','G17','G18','G19','G20','G21']
fail={g:st.get(g) for g in required if st.get(g)!='PASS'}
print('A061 PHYSICAL_CERTIFICATION:', 'PASS' if not fail else 'WITHHELD')
print('blocking_gates:',json.dumps(fail,indent=2))
raise SystemExit(0 if not fail else 3)
