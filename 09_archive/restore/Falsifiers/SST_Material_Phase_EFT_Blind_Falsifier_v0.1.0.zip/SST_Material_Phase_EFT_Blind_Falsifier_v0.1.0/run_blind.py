from __future__ import annotations
import argparse,json,pathlib,hashlib
from sst_eft.io import load_coords
from sst_eft.gates import gate_g1_relabel,gate_g2_phase_shift,gate_g3_derivative_hierarchy,gate_g4_redundancy,gate_g5_modes,overall_verdict
from sst_eft.report import write_report
from sst_eft.blind import config_hash

def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--config",required=True); ap.add_argument("--out",required=True); a=ap.parse_args()
 out=pathlib.Path(a.out); cfg=json.loads(pathlib.Path(a.config).read_text(encoding="utf-8")); lock=json.loads((out/"PREANALYSIS_LOCK.json").read_text())
 if config_hash(cfg)!=lock["config_sha256"]: raise SystemExit("CONFIG HASH MISMATCH: thresholds/config changed after lock")
 files=sorted((out/"blind_input").glob("B*.coords*")); results=[]
 for p in files:
  bid=p.name.split(".")[0]; pts=load_coords(p); seed=int(hashlib.sha256(bid.encode()).hexdigest()[:16],16)
  mode=out/"blind_input"/f"{bid}.modes.csv"; mode=mode if mode.exists() else None
  gates=[gate_g1_relabel(pts,cfg,seed),gate_g2_phase_shift(pts,cfg,seed),gate_g3_derivative_hierarchy(pts,cfg),gate_g4_redundancy(pts,cfg),gate_g5_modes(mode,cfg)]
  r={"blind_id":bid,"n_input":len(pts),"gates":gates,"overall":overall_verdict(gates)}; results.append(r); print(bid,r["overall"])
 write_report(out,cfg,results,lock)
 print("LOCKED:",out/"LOCKED_VERDICTS.json")
if __name__=="__main__": main()
