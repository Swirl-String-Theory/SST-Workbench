"""Historical 2015 trefoil seed adapter for A068 v0.4.1.

40 archived XYZ files correspond to 2 analytic curve families x 4 symmetry/
circulation controls x 5 point samplings. These are NOT 40 independent
physical providers; source geometry has no validated dynamics or SI units.
"""
from __future__ import annotations
import hashlib,io,json
from pathlib import Path
import numpy as np
from .dynamics import simulation
from .rpo import best_translation
from .floquet import tangent_fd_test
from .euler3d import Euler3D

FAMILIES=('A_Fourier_2015_p32','B_Torus_2015_p66')
RESOLUTIONS=(600,1200,2400,4800,9600)
VARIANTS=('orig_ccw','orig_cw','mirrorX_ccw','mirrorX_cw')
INNER_VERSION='0.1.0'
ORIGINAL_SHA256={'manifest.json':'73fbb6e72c00ee44baab4cd963e33ef9966b571b0412e40cb51f92f7072e74f3',
 'README.md':'4a342ab8bf6f90a841374a6f5fd6dab6d8715c6ba6e2af606a7c10a6982d9d7b',
 'regenerate.py':'5c981921c582c0442ae3355d1c8e57f42a9eeaecb96f78c713ddf7fb7984a0ac'}
OUTER_ARCHIVE_VERSION='0.2.0'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def source_path(data_dir, family, variant, n):
    if family not in FAMILIES or variant not in VARIANTS or n not in RESOLUTIONS:
        raise ValueError('Unregistered historical geometry selection')
    return Path(data_dir)/f'{family}_{variant}_N{n}_arclength.xyz'

def audit(data_dir):
    root=Path(data_dir); man_path=root/'manifest.json'
    if not man_path.is_file():return {'valid':False,'reason':'MISSING_MANIFEST','files':{}}
    man=json.loads(man_path.read_text(encoding='utf8'))
    required={f'{family}_{tag}_N{n}_arclength.xyz' for family in FAMILIES for tag in VARIANTS for n in RESOLUTIONS}
    recorded={k for v in man.get('seeds',{}).values() for k in v.get('files',{})}
    expected_families=set(FAMILIES)
    good=(man.get('version')==INNER_VERSION and set(man.get('seeds',{}))==expected_families and recorded==required
          and all((root/f).is_file() and sha(root/f)==h for f,h in ORIGINAL_SHA256.items()))
    per_file={}; geometry={}
    for family in FAMILIES:
        entry=man.get('seeds',{}).get(family,{})
        geometry[family]={'historical_page':entry.get('historical_page'),
            'analytic_arclength_nondim':entry.get('analytic_arclength_nondim'),
            'files':len(entry.get('files',{}))}
        for tag in VARIANTS:
            for n in RESOLUTIONS:
                name=f'{family}_{tag}_N{n}_arclength.xyz'
                path=root/name
                rec=entry.get('files',{}).get(name,{})
                ok=path.is_file() and sha(path)==rec.get('sha256') and rec.get('N')==n and rec.get('variant')==tag
                if ok:
                    try:
                        pts=np.loadtxt(path)
                        ed=np.linalg.norm(np.roll(pts,-1,axis=0)-pts,axis=1)
                        ok=pts.shape==(n,3) and np.all(np.isfinite(pts)) and np.all(ed>0) and (float(ed.std()/ed.mean())<.001)
                        ok=bool(ok)
                    except (ValueError, OSError):ok=False
                per_file[name]={'expected_sha256':rec.get('sha256'),'actual_sha256':sha(path) if path.is_file() else None,'match':bool(ok)}
                good &= bool(ok)
    # Exact orientation/parity transforms are source controls, not source-independence.
    exact=True
    for family in FAMILIES:
        for n in RESOLUTIONS:
            base=np.loadtxt(source_path(root,family,'orig_ccw',n))
            mirror=np.column_stack((-base[:,0],base[:,1],base[:,2]))
            exact &= bool(np.array_equal(np.loadtxt(source_path(root,family,'orig_cw',n)),base[::-1]))
            exact &= bool(np.array_equal(np.loadtxt(source_path(root,family,'mirrorX_ccw',n)),mirror))
            exact &= bool(np.array_equal(np.loadtxt(source_path(root,family,'mirrorX_cw',n)),mirror[::-1]))
    good &= exact
    return {'schema':'A068-HISTORICAL-ATLAS-AUDIT-1','valid':bool(good),
       'manifest_sha256':sha(man_path),'original_auxiliary_files_sha256':{f:sha(root/f) if (root/f).is_file() else None for f in ORIGINAL_SHA256},'files':per_file,
       'geometry_families':geometry,'control_transforms_exact':bool(exact),
       'internal_manifest_version':man.get('version'),'outer_upload_zip_version':OUTER_ARCHIVE_VERSION,
       'provenance_version_name_mismatch':True,'physical_source_native_dynamics':False,
       'independent_physical_providers':0,
       'note':'Both geometries from 2015 historical parametrizations. N is centerline sampling, not Euler field grid refinement.'}

def pilot(data_dir, mode='BASIC'):
    """Prespecified small, independently integrated Euler MODEL trajectories.

    Historical runs do not alter official v0.4.0-primary solver/gate sequence.
    Each run uses the original unchanged A064 3D Euler simulation backend.
    """
    if mode=='BASIC':
        cases=[(name,'orig_ccw',600) for name in FAMILIES];n=12;dt=.04;T=.40
    else:
        cases=[(name,tag,r) for name in FAMILIES for tag,r in (
            ('orig_ccw',600),('orig_ccw',1200),('orig_cw',600),('mirrorX_ccw',600))]
        n=12;dt=.04;T=.80
    records={}
    for name,tag,r in cases:
        path=source_path(data_dir,name,tag,r)
        qualified_geometry_control=(mode!='BASIC' and tag=='orig_ccw' and r==600)
        summary,arrays,initial,_=simulation(path,n=n,core=.4,dt=dt,T=T,snapshots=round(T/dt)+1,
                                             track_tube=qualified_geometry_control)
        record_id=f'{name}__{tag}__N{r}'
        records[record_id]={
          'family':name,'variant':tag,'centerline_resolution':r,
          'source_sha256':sha(path),'n_3d_euler_grid':n,'model_core_width':.4,
          'time_end':T,'n_steps':summary['n_steps'],
          'max_energy_rel_drift':summary['max_energy_rel_drift'],
          'max_divergence_relative':summary['max_relative_divergence'],
          'max_cfl':summary['max_cfl'],
          'initial_enstrophy':summary['initial_enstrophy'],
          'final_enstrophy':summary['final_enstrophy'],
          'euler_conservation_screen':summary['conservation_screen_pass'],
          'relative_velocity_change':summary['end_velocity_relative_change'],
          'material_transport_and_rpo_screen_performed':qualified_geometry_control}
        if qualified_geometry_control:
            # Cheap FULL-field (all components) endpoint identity-rotation integer
            # translation control. The complete 24-rotation RPO search remains
            # exclusive to the original A068 primary; this does NOT certify RPO.
            u0=arrays['u'][0].transpose(3,0,1,2)
            uT=arrays['u'][-1].transpose(3,0,1,2)
            rpo=best_translation(u0,uT,refine=False)
            rng=np.random.default_rng(68041)
            G=Euler3D(n,.4);v=G.project(rng.normal(size=initial.shape))
            fd=tangent_fd_test(G,initial,v)
            records[record_id]['material_screen']={
                'advected_with_euler_rk4':summary['material_transport']['material_advection_performed'],
                'vortex_tube_qualified':summary['material_transport']['vortex_tube_qualified'],
                'max_volume_relative_drift':summary['material_transport']['max_relative_volume_drift'],
                'max_vorticity_tangency_mean':summary['material_transport']['max_vorticity_tangency_mean_abs_cos']}
            records[record_id]['full_field_rpo_screen']={
                'best_relative_residual':rpo['residual'],
                'screen_pass':rpo['residual']<.025,'certified_rpo':False,
                'rotations_tested':1,'translation_subgrid_refinement':False,
                'scan_period':'SHORT_EXPLORATORY_ENDPOINT_ONLY_NO_RPO_SHOOTING'}
            records[record_id]['floquet_operator_screen']={
                'tangent_linear_fd_relative_error':fd,'fd_screen_pass':fd<1e-5,
                'independent_floquet_frequency':'NOT_COMPUTED_NO_CERTIFIED_RPO'}
    n_pairs={}
    if mode!='BASIC':
        for name in FAMILIES:
            a=records[f'{name}__orig_ccw__N600']['final_enstrophy']
            b=records[f'{name}__orig_ccw__N1200']['final_enstrophy']
            n_pairs[name]={'source_point_sampling_enstrophy_difference':abs(a-b)/max(abs(b),1e-30),
                           'not_field_mesh_convergence':True,
                           'relative_to_N1200':True}
    return {'schema':'A068-HISTORICAL-EULER-PILOT-1','mode':mode,
       'source_class':'2015_NOTEBOOK_GEOMETRY_ONLY','integration_type':'ACTUAL_UNFORCED_3D_EULER_MODEL',
       'simulation_model':'DIMENSIONLESS_A064_EULER_GALERKIN',
       'no_prescribed_frequency':True,'independent_physical_providers':0,
       'test_matrix':records,'sampling_pairs':n_pairs,
       'all_model_screens_pass':all(x['euler_conservation_screen'] for x in records.values()),
       'physical_clock':'UNRESOLVED','reveal_eligibility':'NO_PHYSICAL_CLAIM',
       'limitations':'BASIC/FULL short numerical response probes; A/B N600 FULL additionally carry material transport, full-field candidate RPO and tangent-linear FD screen. Neither an RPO shooting certification nor a physical Floquet frequency/provider is established. Reflections and reversals are controls, not replicates.'}
