# A054 v0.4.0-r3 validation

**Framework target:** SST Falsifier Framework **v1.0.4 CANONICAL_FROZEN**  
**Status:** **MAINTENANCE INSTANCE VALIDATED / r2 BASIC SCIENCE PRESERVED**

## Scientific invariants
No mechanism equation, gain, geometry cohort, blind mapping, hard threshold, gate definition, or source contract changed from r2.

## Maintenance checks
- r2 Windows host built `a054-mechanism-injection-0.4.0.post2` successfully with MSVC/OpenMP and completed the framework test suite.
- r3 report source compiles successfully with `pdflatex/latexmk` after bibliography escaping repair.
- r3 uses `%SST_WORKBENCH_ROOT%\.venvs\A054-v0.4.0-r3`, outside the blinded instance root.
- legacy local `.venv` is removed before FREEZE/run.
- instance package manifest regenerated after the maintenance changes.

## Preserved r2 BASIC result
The r2 BASIC run completed G0--G3 before report/package failure. G0--G2 PASS; G3 FAIL because BASE, CORE, ELASTIC and CORE+ELASTIC each recovered 0/48 discovery cells. Held-out confirmation and downstream certification were therefore not run by prerequisite.
