# Review Prompt for Gemini / Claude

Please audit this SST v0.8.19 research-track evidence pack.

Context: The pack proposes four candidate routes for deriving the Planck time without using \(G\), \(L_p\), or \(t_p\) as inputs.  They are **not** claimed as canon derivations.  The goal is to find or falsify the missing kernel theorem.

Please produce:

1. A dimensional audit of Routes A--D.
2. A circularity audit: check whether any formula hides \(G\), \(L_p\), \(t_p\), or \(F_{m gr}^{\max}\).
3. A mathematical plausibility audit of the exponents \(5,6,7\).
4. A literature comparison: stereology / Crofton, quantum turbulence line density, Sakharov induced gravity, pressure Poisson recovery in Euler, maximum tension.
5. A falsification plan: the minimal calculation or simulation needed to kill or support each route.
6. A canonization recommendation: what should be [CANON], [RESEARCH-TRACK], [SPECULATIVE], or removed.

Important: do not reward numerical closeness alone.  Require a mechanism for the coefficients \(16/\pi^2\), \(32/\pi^2\), and \(\pi^2/32\).
