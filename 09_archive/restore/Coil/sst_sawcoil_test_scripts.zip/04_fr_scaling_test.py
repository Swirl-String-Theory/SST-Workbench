from __future__ import annotations
import argparse
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_sawcoil_common import V_SWIRL, frequency_for_x, kernel_x, write_csv

# Bessel-like reference nodes. These are not asserted as the true SST kernel;
# they are test markers for a generic oscillatory G(kR).
J0_NODES = [2.4048255577, 5.5200781103, 8.6537279129]
J1_NODES = [3.8317059702, 7.0155866698, 10.1734681351]


def main() -> None:
    ap = argparse.ArgumentParser(description="fR scaling predictions for SawShape kernel tests.")
    ap.add_argument("--radii", type=float, nargs="+", default=[0.03, 0.05, 0.10])
    ap.add_argument("--harmonics", type=int, nargs="+", default=[1, 3, 5, 7, 11])
    ap.add_argument("--outdir", default="/mnt/data/sawcoil_out")
    args = ap.parse_args()
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    rows = []
    for kernel, nodes in [("J0_like", J0_NODES), ("J1_like", J1_NODES)]:
        for node_i, x in enumerate(nodes, start=1):
            for R in args.radii:
                for n in args.harmonics:
                    f = frequency_for_x(x, n, R, V_SWIRL)
                    rows.append([kernel, node_i, x, R, n, f, f*R])
    csv_path = outdir / "fr_scaling_node_predictions.csv"
    write_csv(csv_path, ["kernel_model", "node_index", "x_node", "R_m", "harmonic_n", "f0_Hz", "f0_times_R_Hz_m"], rows)

    plt.figure(figsize=(8.5, 5.2))
    for n in args.harmonics:
        fs = [frequency_for_x(J0_NODES[0], n, R, V_SWIRL) / 1e6 for R in args.radii]
        plt.plot(args.radii, fs, marker="o", label=f"n={n}, x=J0 first")
    plt.xlabel("coil radius R [m]")
    plt.ylabel("predicted f0 [MHz]")
    plt.title("Kernel-node scaling: f0 ∝ 1/R")
    plt.grid(True, alpha=0.3); plt.legend()
    png_path = outdir / "fr_scaling_first_node.png"
    plt.tight_layout(); plt.savefig(png_path, dpi=160); plt.close()

    print(f"Wrote {csv_path}")
    print(f"Wrote {png_path}")


if __name__ == "__main__":
    main()
