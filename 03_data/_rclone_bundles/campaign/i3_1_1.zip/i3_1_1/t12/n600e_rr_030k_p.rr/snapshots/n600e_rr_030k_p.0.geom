LIST {
	{ < n600e_rr_030k_p.0.vect }
	{ < n600e_rr_030k_p.0.struts.vect }
	{ < n600e_rr_030k_p.0.dlen.vect }
	{ < n600e_rr_030k_p.0.dVdt.vect }
}
