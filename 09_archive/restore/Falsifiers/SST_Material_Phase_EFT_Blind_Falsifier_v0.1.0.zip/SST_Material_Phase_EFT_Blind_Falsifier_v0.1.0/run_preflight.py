import sys, numpy, pybind11, setuptools
from sst_eft.constants import *
from sst_eft.native import require_native, backend_name
mod=require_native()
print("Python",sys.version)
print("numpy",numpy.__version__)
print("pybind11",pybind11.__version__)
print("setuptools",setuptools.__version__)
print("Omega_core = %.9e s^-1"%OMEGA_CORE)
print("f_core = %.9e Hz"%F_CORE)
print("backend:",backend_name())
print("native:",mod.__doc__)
