# Source-to-falsifier traceability

The workbench intentionally separates source-derived EFT structure from SST hypotheses.

| Workbench item | Source basis | Adaptation status |
|---|---|---|
| Material labels | Dubovsky et al. comoving scalars `phi^I` | Source-derived method |
| Relabeling gate | Internal volume-preserving relabeling symmetry | Centerline proxy only |
| Phase-shift estimator | `psi -> psi + f(phi)` and invariant comoving derivative | Source-derived symmetry; SST phase-clock interpretation is hypothetical |
| Derivative hierarchy | Hydrodynamic derivative expansion | Source-derived method; SST uses a fixed geometry coarse-graining and optionally `k r_c` |
| Operator redundancy | Higher-derivative terms removable by field redefinitions / EOM | Source-derived method |
| `k^2+k^4` mode fit | Paper's sample higher-derivative correction produces a quartic dispersion correction | Methodological analogue only; SST mode coefficients are not copied from the paper |

## Explicit non-claims

- The paper does not derive SST.
- The paper does not identify `psi` with physical time.
- The paper does not establish a vortex-thread substrate.
- A structural-pass gate is software/symmetry consistency, not experimental confirmation.
- Static knot geometry cannot establish phase-clock dynamics; G5 requires external dynamical mode data.
