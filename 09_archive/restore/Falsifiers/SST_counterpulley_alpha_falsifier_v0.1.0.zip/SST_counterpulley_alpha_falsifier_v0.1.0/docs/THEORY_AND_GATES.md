# Theory and falsification protocol

## A. What is actually being tested

The v0.1.0 hypothesis is deliberately narrow:

> A pair of equal-magnitude, opposite-circulation material filaments placed at opposite sides of the ideal trefoil core modifies the geometric SST alpha baseline by the normalized pair interaction energy \(G_E\).

This is stronger than merely asking whether a counter-vortex pair exists hydrodynamically.  It proposes a concrete observable and a concrete alpha mapping, so it can fail.

## B. Why the interaction term has the desired sign

For \(\Gamma_+\Gamma_-<0\), the cross Hamiltonian has the opposite circulation sign.  When the tangent-correlation integral is positive, \(H_{+-}<0\), hence

\[
G_E-1=\frac{2H_{+-}}{H_{++}+H_{--}}<0.
\]

The sign therefore emerges from the counter-circulation rather than being inserted as an alpha correction coefficient.

## C. First-order cancellation diagnostic

Introduce a small circulation imbalance

\[
\Gamma_+=\Gamma(1+\eta),\qquad
\Gamma_-=-\Gamma(1-\eta).
\]

The code computes

\[
G_{\rm odd}'(0)\approx\frac{G(+\eta)-G(-\eta)}{2\eta},
\]

and an even second-order proxy

\[
G_{\rm even}''(0)\approx
\frac{G(+\eta)+G(-\eta)-2G(0)}{\eta^2}.
\]

H8 passes when

\[
\frac{|G_{\rm odd}'(0)|}{|G_{\rm even}''(0)|}<0.10.
\]

This is a symmetry diagnostic only.  It is not used to tune the alpha correction.

## D. Blinding

`physics.py`, the C++ kernel, geometry parser and blind sweep contain no measured alpha value.  The benchmark target exists only in `benchmark.py`.  The recommended workflow is therefore:

1. run `run_blind.py`;
2. archive/hash the blind JSON;
3. run `run_benchmark.py` on that fixed JSON.

## E. Falsification hierarchy

- H0-H6: protocol and numerical prerequisites.
- H7-H8: physical structural tests.
- H9-H10: alpha-specific post-hoc tests.

`INCONCLUSIVE_NUMERICS` is used if H0-H6 fail.  If numerics are sound but H7-H10 fail, the package reports

`FALSIFIED_OR_UNSUPPORTED_SIMPLE_COUNTERPULLEY_ENERGY_MAPPING`.

That verdict is scoped to the v0.1.0 energy mapping only.
