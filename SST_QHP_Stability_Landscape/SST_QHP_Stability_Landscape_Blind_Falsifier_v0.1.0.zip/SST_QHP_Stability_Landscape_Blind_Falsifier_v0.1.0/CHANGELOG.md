# Changelog

## 0.1.0 — 2026-08-27
- Initial blind QHP Stability Landscape release.
- QHP-manifold tangent projection of normal finite-core Biot--Savart velocity.
- One-dimensional zero-crossing/restoring-slope gates.
- Three-dimensional local Jacobian/eigenvalue stability gate where a complete local QHP stencil exists.
- Independent short-time RK4 drift confirmation.
- N=64/96/128 resolution ladder.
- Metadata-template generator for existing KnotPlot sweep exports.
- C++17/pybind11/OpenMP backend.
- Explicit Windows/MSVC guard: `py::ssize_t`, no global `ssize_t`.
