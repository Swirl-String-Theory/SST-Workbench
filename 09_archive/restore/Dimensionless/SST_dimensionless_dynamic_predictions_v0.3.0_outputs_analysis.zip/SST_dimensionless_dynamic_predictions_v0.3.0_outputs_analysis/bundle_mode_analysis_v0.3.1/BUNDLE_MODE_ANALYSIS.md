# Axial vortex-bundle mode analysis

Rows analyzed: **1280**.
Summary files used: **2**; skipped as incompatible: **0**.

## Mode separation

- Physical-tube rows: 512
- Numerical-discretization rows: 640
- Continuum-reference rows: 128

Physical tubes hold circulation per tube fixed, so total circulation grows as `N * Gamma_tube`.
Numerical discretization holds total bundle circulation fixed, so each tube carries `Gamma_total / N`.

## Backreaction gate

Full three-dimensional bending and mutual evolution of the axial tubes is **not certified in v0.3.1**. All bundle results use frozen infinite straight tubes.

## Numerical convergence by tube count

| N | matched | mean velocity-field error | mean intrinsic-residual error | clock-rate error |
|---:|---:|---:|---:|---:|
| 1 | 128 | 0 | 5.14144e-17 | 0 |
| 7 | 128 | 0.000213041 | 0.000656637 | 0 |
| 19 | 128 | 0.000256484 | 0.000530337 | 0 |
| 37 | 128 | 0.000153903 | 0.000320086 | 0 |
| 61 | 128 | 0.000121166 | 0.000252832 | 0 |
