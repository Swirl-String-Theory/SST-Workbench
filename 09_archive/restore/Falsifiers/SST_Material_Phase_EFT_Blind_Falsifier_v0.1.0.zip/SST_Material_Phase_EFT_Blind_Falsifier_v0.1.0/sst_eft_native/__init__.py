from importlib import import_module

def load():
    return import_module("sst_eft_native._native")
