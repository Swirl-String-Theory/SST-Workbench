@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "DATA=%~1"
if "%DATA%"=="" if exist "..\..\KnotPlot\knots\final" set "DATA=..\..\KnotPlot\knots\final"
if "%DATA%"=="" if exist "..\KnotPlot\knots\final" set "DATA=..\KnotPlot\knots\final"
if "%DATA%"=="" if exist "..\..\..\KnotPlot\knots\final" set "DATA=..\..\..\KnotPlot\knots\final"
if "%DATA%"=="" set "DATA=..\..\KnotPlot\knots\final"
echo ============================================================
echo SST Material/Phase EFT Blind Falsifier v0.1.0
echo Dataset: %DATA%
echo ============================================================
call "run_selftest.cmd"
if errorlevel 1 goto :fail
call "run_basic.cmd" "%DATA%"
if errorlevel 1 goto :fail
call "run_extended.cmd" "%DATA%"
if errorlevel 1 goto :fail
echo ============================================================
echo COMPLETE
echo basic:    outputs\basic\REVEALED_SUMMARY.csv
echo extended: outputs\extended\REVEALED_SUMMARY.csv
echo ============================================================
exit /b 0
:fail
echo [SST-EFT] FAILED with error %errorlevel%
exit /b %errorlevel%
