#!/usr/bin/env python3
"""CLI wrapper for sst_dark_knot_harness.taxonomy.

Examples:
  python taxonomy/compute_taxonomy.py --id 4_1 --validate --classify
  python taxonomy/compute_taxonomy.py --id 3_1 --mirror --no-snappy --out taxonomy_3_1_mirror.json
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sst_dark_knot_harness.taxonomy import _main

if __name__ == "__main__":
    raise SystemExit(_main())
