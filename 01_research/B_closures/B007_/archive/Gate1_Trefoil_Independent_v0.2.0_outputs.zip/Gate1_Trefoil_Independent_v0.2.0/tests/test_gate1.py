import sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import seed_core_v010 as core
from geometry_proof import certificate
from assess import assess


def test_analytic_reach_certificate():
    c=certificate()
    assert c['reach_lower_bound_proven']>core.A_CORE
    assert c['min_curvature_radius_bound']>.6
    assert c['exact_reach_not_claimed']

@pytest.mark.parametrize('m,d',[(.23,.11),(1.13,.4),(.23,1.0),(.23,2.0),(1.13,3.0)])
def test_exact_chord_identity(m,d):
    a=core.A_TORUS
    A=core.xder(m-d/2)[0];B=core.xder(m+d/2)[0]
    rhs=4*(np.sin(d)**2*(1+2*a*np.cos(3*m)*np.cos(1.5*d)+a*a*np.cos(3*m)**2)+
            a*a*np.cos(d)**2*np.sin(1.5*d)**2)
    assert np.isclose(np.linalg.norm(A-B)**2,rhs,atol=2e-13)

def test_antipodal_orthogonality():
    a=core.doublecritical_antipodal()
    assert a['max_distance_deviation_from_2alpha']<1e-12
    assert a['max_orthogonality_residual']<1e-12


def test_analytic_flux_and_exact_bump_support():
    L=core.curve_length()
    for q in (0,1):
        for phi in (.1,.6,1.9,3.1,5.5):
            assert abs(core.cross_section_flux(phi,L,q)-1)<1e-10
    assert abs(float(core.fprime(1.0)))<1e-13


def test_independent_gauss_linking():
    row=core.gauss_invariants(1024)
    assert abs(row['gauss_linking']+6)<1e-6
    assert abs(row['closure_error'])<5e-6


def test_saved_results_qualified():
    a=assess()
    assert a['status']=='GATE1_PASS_FOR_DECLARED_ANALYTIC_AND_NUMERICAL_SCOPE'
    assert a['passed']==a['total']
