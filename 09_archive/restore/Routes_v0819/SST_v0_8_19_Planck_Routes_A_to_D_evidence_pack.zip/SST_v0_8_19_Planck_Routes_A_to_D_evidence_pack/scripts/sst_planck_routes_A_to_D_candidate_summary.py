#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SST v0.8.19 Planck-time route candidates A--D.
Research-track audit only. No G, L_p, or t_p is used in candidate formulae,
except for computing reference errors after the fact.
"""
import math, json, csv, argparse
HBAR=1.054571817e-34
C=299792458.0
G=6.67430e-11
M_E=9.1093837015e-31
V=1.09384563e6
R_C=1.40897017e-15
RHO_CORE=3.8934358266918687e18
RHO_F=7.0e-7
F_SWIRL=29.053507
LP=math.sqrt(HBAR*G/C**3)
TP=math.sqrt(HBAR*G/C**5)
FGR=C**4/(4*G)
def rows():
    rho_ratio=RHO_CORE/RHO_F
    rho_inv=RHO_F/RHO_CORE
    x=C/V
    beta=V/C
    A=(1/R_C**2)*rho_ratio*(16/math.pi**2)*x**6
    A_tp=1/(C*math.sqrt(2*A))
    B=(32/math.pi**2)*rho_ratio*x**6
    B_req=(R_C/LP)**2
    B_tp=R_C/(C*math.sqrt(B))
    Cg=(math.pi**2/32)*rho_inv*beta**5*(V**2*R_C/M_E)
    C_tp=math.sqrt(HBAR*Cg/C**5)
    D=(16/math.pi**2)*F_SWIRL*rho_ratio*x**7
    D_tp=math.sqrt(HBAR/(4*D*C))
    return [
        dict(route='A', quantity='sigma_Lambda', formula='r_c^-2*(rho_core/rho_f)*(16/pi^2)*(c/v)^6', value=A, unit='m^-2', target=1/(2*LP**2), ratio=A/(1/(2*LP**2)), tp_s=A_tp, tp_ratio=A_tp/TP),
        dict(route='B', quantity='N_mode', formula='(32/pi^2)*(rho_core/rho_f)*(c/v)^6', value=B, unit='1', target=B_req, ratio=B/B_req, tp_s=B_tp, tp_ratio=B_tp/TP),
        dict(route='C', quantity='G_C', formula='(pi^2/32)*(rho_f/rho_core)*(v/c)^5*(v^2*r_c/M_e)', value=Cg, unit='m^3 kg^-1 s^-2', target=G, ratio=Cg/G, tp_s=C_tp, tp_ratio=C_tp/TP),
        dict(route='D', quantity='F_D', formula='(16/pi^2)*F_swirl_max*(rho_core/rho_f)*(c/v)^7', value=D, unit='N', target=FGR, ratio=D/FGR, tp_s=D_tp, tp_ratio=D_tp/TP),
    ]
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--json', default='candidate_summary.json')
    ap.add_argument('--csv', default='candidate_summary.csv')
    args=ap.parse_args()
    rs=rows()
    print('SST v0.8.19 Planck-time route candidates A--D [RESEARCH-TRACK]')
    print(f't_p_ref = {TP:.12e} s, L_p_ref = {LP:.12e} m')
    for r in rs:
        print(f"Route {r['route']}: {r['quantity']} = {r['value']:.12e} {r['unit']} | ratio={r['ratio']:.12f} | t_p={r['tp_s']:.12e} s | t_p/t_ref={r['tp_ratio']:.12f}")
    payload={'status':'RESEARCH_TRACK_NOT_DERIVED','reference':{'t_p_s':TP,'L_p_m':LP,'G':G,'F_gr_max_N':FGR},'routes':rs}
    with open(args.json,'w') as f: json.dump(payload,f,indent=2)
    with open(args.csv,'w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rs[0].keys()))
        w.writeheader(); w.writerows(rs)
if __name__=='__main__': main()
