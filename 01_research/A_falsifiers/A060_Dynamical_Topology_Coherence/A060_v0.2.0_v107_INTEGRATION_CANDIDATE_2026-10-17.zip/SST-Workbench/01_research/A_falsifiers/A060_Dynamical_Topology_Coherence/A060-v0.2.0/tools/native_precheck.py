from pathlib import Path
import json,importlib,sys
import numpy as np
from sst_falsifier.native_build import build_pybind
from a060_preflight.mechanics import diagnostics,rank_one,balanced,rank_two

def main():
 root=Path(__file__).resolve().parents[1]
 br=build_pybind(root,prefer_openmp=False,verbose=True)
 result={'schema':'A060-NATIVE-ENGINEERING-1','certified':False,'G5':'UNRESOLVED','scope':'Q, pressure source, Rs, Vs and fluxfactor only; no complete M01-M04 or Euler dynamics certification','build':br.to_dict()}
 if br.success:
  importlib.invalidate_caches();m=importlib.import_module('native_ext._sst_native')
  rng=np.random.default_rng(7189);cases=[rank_one(),balanced(),rank_two(eps=.02)]+[rng.normal(size=(3,3)) for _ in range(26)];error=0.
  for A in cases:
   A=A-np.trace(A)/3*np.eye(3);ref=diagnostics(A);got=dict(m.tensor(A))
   error=max(error,max(abs(got[k]-ref[k])/max(1.,abs(ref[k])) for k in got))
  result.update(actual_backend=dict(m.backend_info()),n_cases=len(cases),max_scaled_error=error,engineering_pass=error<=1e-10)
 else:result['engineering_pass']=False
 (root/'evidence/NATIVE_ENGINEERING.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='build'},indent=2));return 0 if result['engineering_pass'] else 2
if __name__=='__main__':raise SystemExit(main())
