from setuptools import setup, find_packages
from pybind11.setup_helpers import Pybind11Extension, build_ext

ext_modules = [
    Pybind11Extension(
        "sst_thpcf._native",
        ["cpp/native.cpp"],
        cxx_std=17,
        extra_compile_args=["/O2"] if __import__("sys").platform.startswith("win") else ["-O3"],
    )
]
setup(
    name="sst-thpcf",
    version="0.1.0",
    packages=find_packages(include=["sst_thpcf", "sst_thpcf.*"]),
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)
