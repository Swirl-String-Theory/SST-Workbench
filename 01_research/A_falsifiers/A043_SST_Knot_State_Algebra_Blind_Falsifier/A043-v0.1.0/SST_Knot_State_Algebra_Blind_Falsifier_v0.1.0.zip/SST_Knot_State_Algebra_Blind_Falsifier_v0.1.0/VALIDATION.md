# Validation — SST Knot State Algebra Blind Falsifier v0.1.0

Source-release validation performed before packaging:

- **Python unit tests:** 4 / 4 PASS.
- **PKLSA adapter unit:** PASS for a synthetic 48-variant family bundle indexed through `CANDIDATES_FULL.csv` + `SOURCE_MAP.json`.
- **Full atlas contract smoke:** PASS on a synthetic 49-family × 48-variant = 2352-candidate atlas. G1 reported exactly 2352 candidates, 49 families, and 48 variants per family.
- **Independent lane behavior:** PASS in smoke: absent invariant input produced `G2=UNRESOLVED`, `G3=NOT_RUN_PREREQUISITE`, while the independent geometry/dynamics lane continued through G4/G5.
- **Blind structural guard:** PASS.
- **Private denylist commitment + contamination scan:** PASS against the separately packaged private denylist.
- **Private reveal SHA-256 commitment:** PASS.
- **Opaque scorer identity:** public G4/G5 records use candidate/family-group IDs; true PKLSA family/topology/source mappings are written below `private/` and are excluded from BLIND archives.

## Native/GPU status

The C++17/OpenMP/pybind11 source is included, but this isolated packaging runtime could not install `pybind11` from the internet, so the native extension was **not compiled here**. `run_00_setup.cmd` installs the declared build dependency and performs the native build on the target Windows environment. Scientific GPU screening remains conditional on runtime CPU↔GPU parity; GPU results are never authoritative.

## Scientific scope guard

The regularized filament G4/G5 kernel is a screening/certification observable for the preregistered surrogate. It is **not** a claim of full 3-D Euler orbital stability. G6 remains `NOT_RUN_PREREQUISITE` until a physical finite-core solver supplies the external response contract.
