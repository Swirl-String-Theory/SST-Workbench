# Patch status for the reviewed v0.8.30 evidence pack

## Current direct Canon upgrade

`canon_upgrade_v0_8_28_to_v0_8_30/` contains the reviewed direct patch from the
exact v0.8.28 evidence-pack snapshot to the v0.8.30 snapshot. It includes the
v0.8.29/v0.8.30 semantic changes and carries forward the two predecessor review
hotfixes. Dry-run and byte-identical roundtrip are recorded under
`validation/v0_8_30_delta/`.

## Historical v0.8.28 patch record

- `0001-upgrade-verification-suite-v0.8.17-to-v0.8.28.patch` remains the portable
  diff of the original verification suite.
- `canon_accepted/0001-precision-omega-c-and-rt-clock-table.patch` is integrated
  in the reviewed v0.8.30 Research Track snapshot.
- `canon_accepted/0002-benchmark-exact-closure-guard-layout-safe.patch` is
  integrated in the reviewed v0.8.30 main snapshot.
- `canon_held/HELD-precision-fmax-printed-value.patch` remains held because it
  would alter a user-locked canonical constant.
- historical repository patches remain under `legacy_repo_patches/`; they have
  not been rebased against absent current repositories.

See the top-level `PATCH_DISPOSITION.md` for full adjudication.
