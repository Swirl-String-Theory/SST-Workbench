# A054 v0.4.0-r3 packaging/report maintenance hotfix

No scientific equations, mechanism arms, gain grid, source cohorts, thresholds, or blind mappings are changed.

Fixes:
1. Correct LaTeX bibliography escaping in `report/FALSIFIER_REPORT.tex`.
2. Move the Python virtual environment outside the blinded instance tree to `%SST_WORKBENCH_ROOT%\.venvs\A054-v0.4.0-r3`.
3. Delete any legacy in-instance `.venv` before blind packaging so third-party `site-packages` cannot trigger false forbidden-term hits.
4. Preserve fail-closed command propagation.

The completed r2 BASIC scientific outputs are not recomputed or reinterpreted by this maintenance release.
