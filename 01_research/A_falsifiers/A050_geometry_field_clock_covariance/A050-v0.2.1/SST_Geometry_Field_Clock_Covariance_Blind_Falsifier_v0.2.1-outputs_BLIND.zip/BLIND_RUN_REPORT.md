# BLIND RUN REPORT — v0.2.1

Verdict: `STRUCTURED_MEMORY_KELVIN_DETECTED_FLOQUET_INDETERMINATE`

## Gate summary

- Spatial covariance: PASS (4/4)
- Temporal memory: PASS (4/4)
- Transverse modal gate: PASS (1/4)
- Floquet gate: `INDETERMINATE_NO_RECURRENCE`
- Divergence qualification: PASS
- Resolution qualification: PASS (exponent span=0.583531)

## Family diagnostics

- G0001: spatial exponent=1.848259, null=3.065888, temporal exponent=2.000000, memory steps=1.950775, memory/null=1.827514, modal mode=8, modal fraction=0.309804, phase cycles=0.000000.
- G0002: spatial exponent=1.501571, null=3.026508, temporal exponent=1.841256, memory steps=7.062186, memory/null=7.062186, modal mode=3, modal fraction=0.941872, phase cycles=0.069550.
- G0003: spatial exponent=1.520462, null=3.032560, temporal exponent=2.003232, memory steps=6.057864, memory/null=6.057864, modal mode=2, modal fraction=0.622269, phase cycles=0.027011.
- G0004: spatial exponent=1.838191, null=3.034227, temporal exponent=2.020312, memory steps=7.035255, memory/null=7.035255, modal mode=2, modal fraction=0.881584, phase cycles=0.160618.

## Interpretation boundary

The blind verdict uses only dimensionless internal observables and decorrelated controls. The transverse-mode gate is reported from the preregistered family-count, modal-energy, phase-linearity and phase-advance criteria; individual families may still remain unresolved. The Floquet stage does not estimate multipliers unless a nontrivial return is first detected for the preregistered carrier. These are scientific outcomes, not runtime errors.
