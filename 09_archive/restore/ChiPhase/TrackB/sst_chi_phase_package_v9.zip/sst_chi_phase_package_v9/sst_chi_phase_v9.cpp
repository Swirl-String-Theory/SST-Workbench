#include <pybind11/pybind11.h>
#include <cmath>

namespace py = pybind11;

static double beta_from_alpha_q(double alpha, double q) {
    return alpha - 1.0 + q;
}

static double q_from_alpha_beta(double alpha, double beta) {
    return beta - alpha + 1.0;
}

static double alpha_eff_from_energy(double E, double rho, double Gamma, double R, double a) {
    return std::log(8.0 * R / a) - (2.0 * E) / (rho * Gamma * Gamma * R);
}

static double energy_from_alpha(double alpha, double rho, double Gamma, double R, double a) {
    return 0.5 * rho * Gamma * Gamma * R * (std::log(8.0 * R / a) - alpha);
}

static double smooth_matched_c2_over_v2(double a0) {
    return (2.0 * a0 * a0 + 13.0 * a0 + 78.0) / 105.0;
}

static double smooth_matched_c_over_v(double a0) {
    double v = smooth_matched_c2_over_v2(a0);
    return v > 0.0 ? std::sqrt(v) : 0.0;
}

PYBIND11_MODULE(sst_chi_phase_v9, m) {
    m.doc() = "SST chi-phase v9 alpha/beta scalar kernel";
    m.def("beta_from_alpha_q", &beta_from_alpha_q);
    m.def("q_from_alpha_beta", &q_from_alpha_beta);
    m.def("alpha_eff_from_energy", &alpha_eff_from_energy);
    m.def("energy_from_alpha", &energy_from_alpha);
    m.def("smooth_matched_c2_over_v2", &smooth_matched_c2_over_v2);
    m.def("smooth_matched_c_over_v", &smooth_matched_c_over_v);
}
