# CHANGELOG v0.2.1

- Corrected `charge`, `hooke`, `power`, and `timeincr` KPC lines from bare
  command form to KnotPlot parameter assignment form: `name = value`.
- `charge`, `power`, and `hooke` syntax confirmed on the target installation.
- `timeincr = value` remains an isolated empirical certification target.
- Fixed the batch-flow bug that ran the extended stage after reporting `NONE`.
- Added `analysis\EXTENDED_SKIPPED.flag` sentinel.
- Expanded parser diagnostics for unknown/invalid parameter messages.
- Selftest now proves all 24 KPCs contain exactly one uncertain parameter
  assignment and no old bare-command syntax.
- Sweep values and scientific certification gates are unchanged.
