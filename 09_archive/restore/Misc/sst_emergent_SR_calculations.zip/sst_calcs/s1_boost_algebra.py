#!/usr/bin/env python3
"""
s1_boost_algebra.py  —  AUDIT §1  (conversation turn 10)

CLAIM UNDER TEST
    The substrate's boost generator falls into one of two Lie algebras, read off
    from two structure constants:
        Galilei (Bargmann):  [K_i,K_j] = 0 ,   [K_i,P_j] = i m delta_ij   (mass = central charge)
        Poincare:            [K_i,K_j] = -(1/c^2) (x_i d_j - x_j d_i) ~ J/c^2 ,
                             [K_i,P_j] = -i delta_ij H / c^2              (energy, an OPERATOR)
    and that Galilei is the c -> infinity (Inonu-Wigner) contraction of Poincare.

    Consequence for SST: a strictly incompressible / non-relativistic-GP substrate
    is Galilean -> a moving vortex is NOT a 1/gamma-contracted rest state -> no gamma.
    Only a relativistic (box) substrate gives exact gamma. This is the §1 fork.

METHOD
    Represent each generator as a differential operator acting on a generic smooth
    field f(t,x,y,z). Compute commutators by direct operator action in sympy and
    compare to the claimed right-hand side. Everything is exact symbolic algebra;
    no numerics, no fitting.

STATUS OF RESULT:  [DERIVED]  (orthodox Lie-algebra fact; the SST application is the new step)
"""
import sympy as sp

t, x, y, z, m, c = sp.symbols('t x y z m c', real=True, positive=True)
coords = (x, y, z)
f = sp.Function('f')(t, x, y, z)

def d(expr, var, n=1):      # partial derivative (order n)
    return sp.diff(expr, var, n)

# ---------- generic commutator of two first/second-order operators given as callables ----------
def comm(A, B, g):
    """[A,B] g = A(B g) - B(A g), with A,B Python callables expr->expr."""
    return sp.simplify(A(B(g)) - B(A(g)))

# ============================================================ GALILEI (Bargmann) ============
# P_j = -i d_j ;  H = -1/(2m) Laplacian ;  K_i = -i t d_i - m x_i  (central extension = -m x_i)
I = sp.I
def P(j):  return lambda g: -I*d(g, coords[j])
def Hgal(g): return -1/(2*m)*sum(d(g, q, 2) for q in coords)
def Kgal(i): return lambda g: -I*t*d(g, coords[i]) - m*coords[i]*g

print("="*70)
print("GALILEI (Bargmann) algebra")
print("="*70)
# [K_i,K_j] = 0
res_KK = comm(Kgal(0), Kgal(1), f)
print(f"[K_x,K_y] f          = {res_KK}            (claim 0)")
assert res_KK == 0

# [K_i,P_j] should be a pure c-number multiple of delta_ij times m (central charge)
res_KP_xx = comm(Kgal(0), P(0), f)
res_KP_xy = comm(Kgal(0), P(1), f)
print(f"[K_x,P_x] f / f      = {sp.simplify(res_KP_xx/f)}      (claim +-i*m : central charge = MASS)")
print(f"[K_x,P_y] f          = {res_KP_xy}            (claim 0)")
assert res_KP_xy == 0
assert sp.simplify(res_KP_xx/f).free_symbols <= {m}   # a c-number in m, not an operator

# [K_i,H] = -i P_i  (here -i*(-i d_x f) = -d_x f)
res_KH = comm(Kgal(0), Hgal, f)
Px_f = (-I)*d(f, x)                       # P_x f
print(f"[K_x,H] f            = {sp.simplify(res_KH)}        (claim -i*P_x f = {sp.simplify(-I*Px_f)})")
assert sp.simplify(res_KH - (-I)*Px_f) == 0
print(">>> Galilei: [K,K]=0, [K,P]=c-number(mass). A moving soliton has no internal gamma.\n")

# ============================================================ POINCARE =======================
# H = i d_t ; P_j = -i d_j ; K_i = -i ( t d_i + (x_i/c^2) d_t )
def Hpoi(g): return I*d(g, t)
def Ppoi(j): return lambda g: -I*d(g, coords[j])
def Kpoi(i): return lambda g: -I*(t*d(g, coords[i]) + (coords[i]/c**2)*d(g, t))

print("="*70)
print("POINCARE algebra")
print("="*70)
# [K_i,K_j] ~ J_k / c^2  (nonzero, scales as 1/c^2)
res_KKp = sp.simplify(comm(Kpoi(0), Kpoi(1), f))
expected_J = sp.simplify(-(1/c**2)*(x*d(f, y) - y*d(f, x)))
print(f"[K_x,K_y] f          = {res_KKp}")
print(f"  expected -(1/c^2)(x d_y - y d_x) f = {expected_J}")
assert sp.simplify(res_KKp - expected_J) == 0
print("  -> NONZERO, proportional to rotation J_z / c^2")

# [K_i,P_j] = -i delta_ij H / c^2  (an OPERATOR, not a c-number)
res_KPp_xx = sp.simplify(comm(Kpoi(0), Ppoi(0), f))
res_KPp_xy = sp.simplify(comm(Kpoi(0), Ppoi(1), f))
expected_KPp = sp.simplify(-I*Hpoi(f)/c**2)
print(f"[K_x,P_x] f          = {res_KPp_xx}")
print(f"  expected -i H/c^2 f = {expected_KPp}    (proportional to ENERGY operator, not mass c-number)")
assert sp.simplify(res_KPp_xx - expected_KPp) == 0
assert res_KPp_xy == 0
print(">>> Poincare: [K,K]~J/c^2 != 0, [K,P]~H/c^2 (operator). Solitons contract by gamma.\n")

# ============================================================ INONU-WIGNER ====================
print("="*70)
print("INONU-WIGNER CONTRACTION  (Poincare --c->oo--> Galilei)")
print("="*70)
print("  [K_x,K_y] = -(1/c^2)(x d_y - y d_x)  --c->oo-->  0          (Galilei [K,K]=0)")
limit_KK = sp.limit(res_KKp, c, sp.oo)
print(f"  lim_{{c->oo}} [K_x,K_y] f = {limit_KK}")
assert limit_KK == 0
print("  [K_x,P_x] = -i H/c^2.  Define rest-mass M := lim H/c^2  =>  [K,P] -> -i M delta  (Galilei central charge).")
print("  Strict incompressibility is c_s -> oo in the pressure sector => forces the Galilei contraction.")
print("  => 'absolute Euclidean fluid' and 'exact-Lorentz matter' cannot both hold. [DERIVED]\n")

print("ALL §1 CHECKS PASSED.")
