import numpy as np
# from numba import jit 
from variable import *
from scipy.fftpack import *
from time import time
from functions import *
import pyfftw

threads = 1
omega_x = fftfreq(Nx,xmax*2/Nx)*2*np.pi
omega_y = fftfreq(Ny,ymax*2/Ny)*2*np.pi
omega_x , omega_y = np.meshgrid(omega_x,omega_y)
omega2 = omega_x**2 + omega_y**2

# The object to make the sample its ground state. args of instance are
# V_prime = V - 1, and v(velocity)
class img_time_calculator:
    
    # The part to initailize the object. 
    #  a,b,c,fft... are to accelerate the FFT
    def __init__(self,V_prime,v):
        self.psi = np.zeros((Ny,Nx),dtype=complex)
        self.V_prime = V_prime
        self.v = v
        self.Plot_flag = False
        self.a = pyfftw.empty_aligned((Ny, Nx), dtype='complex')
        self.b = pyfftw.empty_aligned((Ny, Nx), dtype='complex')
        self.c = pyfftw.empty_aligned((Ny, Nx), dtype='complex')
        self.fft_object = pyfftw.FFTW(self.a,self.b,axes=(0,1),threads=threads)
        self.ifft_object = pyfftw.FFTW(self.b,self.c,axes=(0,1),direction="FFTW_BACKWARD",threads=threads)

    # calcualte the imaginary time evolution by psedospectral method
    def imag_time_evolv(self):
        V_prime = self.V_prime
        self.a[:] = self.psi
        self.b[:] = self.fft_object()
        self.b[:] = self.b*np.exp(((-omega2)/2+omega_x*self.v)*dtau)
        psi1 = self.ifft_object()

        temp = np.zeros((Ny,Nx),dtype=complex)

        temp = (1-np.exp(-2*V_prime*dtau))/V_prime
        psi2_ = psi1*np.exp(-self.V_prime*dtau)/np.sqrt(1+(np.abs(psi1)**2)*temp)
        psi2_ = np.nan_to_num(psi2_)
        self.psi = psi2_

    # take the Thomas-Fermi psi as the input, and get the stationary state
    # by iterating `imag_time_evolv` method. If the integration of |psi(n+1)-psi(n)|
    # are below some value, then stopping 
    def make_init(self,image=False):
        trial = Thomas_Fermi(self.V_prime)
        self.psi = trial
        gamma0 = 1e10
        
        # print(epsilon*dtau)
        for i in range(Ntau):
            psi0 = self.psi
            self.imag_time_evolv()
            gamma = simp2d(np.abs(self.psi-psi0)**2)

            if gamma>gamma0:
                print("gamma start to increase... unstationary state")
                print(f"time : {i*dtau:.3f}, gamma : {gamma}")
                return self.psi


            if gamma<epsilon*dtau:
                density = np.abs(self.psi)**2
                phase = atan2(self.psi.imag,self.psi.real)

                if image:
                    Plot(density,i*dtau,"Number density")
                    Plot(phase,i*dtau,"Phase")

                print("imaginary time evolve done...")
                print(f"gamma = {gamma}")
                print(f"number_new = {l*simp2d(density)}")

                return self.psi
            
            if i%200==0:
                if image:
                    density = np.abs(self.psi)**2
                    phase = atan2(self.psi.imag,self.psi.real)
                    if self.Plot_flag:
                        Plot(density,i*dtau,"Number density")
                        Plot(phase,i*dtau,"Phase")

                print(f"tau = {i*dtau:.3f}, gamma = {gamma}\n")
  
            gamma0 = gamma
        
        print("exhaust full time. Yield the ground state")
        return self.psi


# if __name__ == "__main__":
    
#     V = 0.4*np.exp(-2*((xx-obstacle_position)**2+yy**2)/15**2)
#     V_prime = V - 1

#     start = time()
#     img_time_calculator(V_prime,0.65).make_init(image="on")
#     end = time()
#     print(f"lapsed time with pyFFTW:{(end-start):.3f} 초")



