"""Recreate the wake-pattern figure from raw public-release outputs."""

from __future__ import annotations

import numpy as np
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.patches import Circle
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

from _common import FIGURE_DIR, find_force_file, find_psi_dir, find_snapshot_file, setup_matplotlib

import variable as var


CASES = [
    {"V0": 0.9, "sigma": 20, "speed": 0.55, "snapshot_time": 7030.0}
]
TIME_WINDOW = (2000.0, 10000.0)
CROP_SLICE = (slice(150, 350), slice(200, 800))
FIGSIZE = (7.0, 3.0)
SAVE_NAME = "wake_pattern.png"


def D_field(psi, dx, dy):
    dpsi1_dx = np.gradient(psi.real, dx, axis=1)
    dpsi2_dx = np.gradient(psi.imag, dx, axis=1)
    dpsi1_dy = np.gradient(psi.real, dy, axis=0)
    dpsi2_dy = np.gradient(psi.imag, dy, axis=0)
    return dpsi1_dx * dpsi2_dy - dpsi1_dy * dpsi2_dx


setup_matplotlib()

custom_cmap = LinearSegmentedColormap.from_list(
    "BlueRed_balanced",
    [
        (0.00, "#2b83d3"),
        (0.25, "#b3d7ea"),
        (0.50, "#f7f7f7"),
        (0.75, "#f4b6c2"),
        (1.00, "#c51b3a"),
    ],
)

x_rel = var.x[CROP_SLICE[1]] - var.obstacle_position
y_vals = var.y[CROP_SLICE[0]]
extent = [x_rel.min(), x_rel.max(), y_vals.min(), y_vals.max()]

fig = plt.figure(figsize=FIGSIZE)
gs = gridspec.GridSpec(
    3,
    2,
    figure=fig,
    hspace=0.05,
    wspace=-0.3,
    left=0.05,
    right=0.95,
    bottom=0.12,
    top=0.85,
)

vort_axes = []
force_axes = []
left_labels = ["(a)", "(b)", "(c)"]
right_labels = ["(d)", "(e)", "(f)"]
im = None

for row, case in enumerate(CASES):
    psi_dir = find_psi_dir(case["V0"], case["sigma"], case["speed"])
    force_file = find_force_file(case["V0"], case["sigma"], case["speed"])
    psi_file = find_snapshot_file(psi_dir, case["snapshot_time"])

    psi = np.load(psi_file)[CROP_SLICE]
    density = np.abs(psi) ** 2
    D = D_field(psi, var.dx, var.dy) / np.maximum(density, 1e-10)

    ax_vort = fig.add_subplot(gs[row, 0])
    im = ax_vort.imshow(
        D,
        extent=extent,
        origin="lower",
        cmap=custom_cmap,
        aspect="equal",
        norm=TwoSlopeNorm(vmin=-0.4, vcenter=0.0, vmax=0.4),
    )
    ax_vort.add_patch(Circle((0.0, 0.0), case["sigma"], color="k", ls="--", lw=0.5, fill=False))
    ax_vort.set_xticks([-100, 0, 100])
    ax_vort.set_yticks([-40, 0, 40])
    ax_vort.set_xticklabels([-200, -100, 0])
    if row == 2:
        ax_vort.set_xlabel(r"$x/\xi$", labelpad=2)
    else:
        ax_vort.set_xticklabels([])
    ax_vort.set_ylabel(r"$y/\xi$", labelpad=-1)
    ax_vort.text(-0.2, 0.95, left_labels[row], transform=ax_vort.transAxes, fontsize=8, va="top")
    ax_vort.text(0.71, 0.94, rf"$v_0/c_\mathrm{{s0}}={case['speed']:g}$", transform=ax_vort.transAxes, fontsize=8, va="top")
    ax_vort.annotate(
        "",
        xy=(25, 0),
        xytext=(45, 0),
        arrowprops=dict(color="black", lw=0.8, alpha=0.9, arrowstyle="->", mutation_scale=7),
    )
    vort_axes.append(ax_vort)

    force_data = np.loadtxt(force_file)
    t_min, t_max = TIME_WINDOW
    force_data = force_data[(t_min <= force_data[:, 0]) & (force_data[:, 0] <= t_max)]
    time_arr, Fx_arr, Fy_arr, _ = force_data.T

    ax_force = fig.add_subplot(gs[row, 1])
    ax_force.plot(time_arr, -Fx_arr, label=r"$F_\mathrm{D}/F_{\mu}$", color="royalblue", lw=0.8, alpha=0.9)
    ax_force.plot(time_arr, Fy_arr, label=r"$F_\mathrm{L}/F_{\mu}$", color="orangered", linestyle=":", lw=0.8, alpha=0.9)
    ax_force.set_box_aspect(1 / 3)
    ax_force.set_xlim(1500, 10000)
    ax_force.set_xticks([2000, 4000, 6000, 8000, 10000])
    ax_force.set_xticklabels([2, 4, 6, 8, 10])
    ax_force.set_yticks([0, 2, 4])
    if row == 2:
        ax_force.set_xlabel(r"Time ($10^3$ $\tau$)")
    else:
        ax_force.set_xticklabels([])
    ax_force.text(-0.15, 0.95, right_labels[row], transform=ax_force.transAxes, fontsize=8, va="top")
    force_axes.append(ax_force)

cax = inset_axes(
    vort_axes[0],
    width="100%",
    height="5%",
    loc="upper center",
    bbox_to_anchor=(0, 0.2, 1, 1),
    bbox_transform=vort_axes[0].transAxes,
    borderpad=0,
)
cbar = fig.colorbar(im, cax=cax, orientation="horizontal")
cbar.set_label(r"$\omega_\mathrm{{s}}/\omega_\mathrm{{s0}}$", rotation=0, labelpad=3, fontsize=8)
cbar.ax.tick_params(labelsize=7)
cbar.ax.xaxis.set_ticks_position("top")
cbar.ax.xaxis.set_label_position("top")
cbar.ax.tick_params(pad=1)
cbar.set_ticks([-0.4, -0.2, 0.0, 0.2, 0.4])

handles, labels = force_axes[0].get_legend_handles_labels()
fig.legend(handles, labels, loc="center", bbox_to_anchor=(0.68, 0.9), frameon=False, fontsize=8, ncol=2, columnspacing=4)

out = FIGURE_DIR / SAVE_NAME
fig.savefig(out, dpi=600)
plt.close(fig)
print(f"saved {out}")
