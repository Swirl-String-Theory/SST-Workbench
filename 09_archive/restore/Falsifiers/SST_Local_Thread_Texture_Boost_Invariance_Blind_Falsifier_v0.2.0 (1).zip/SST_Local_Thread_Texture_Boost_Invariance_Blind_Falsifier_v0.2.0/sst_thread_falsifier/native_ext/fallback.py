from __future__ import annotations
import numpy as np


def biot_savart(points, component_offsets, gamma=1.0, core_radius=0.05):
    """Regularized midpoint filament self/mutual velocity."""
    p=np.ascontiguousarray(points,dtype=np.float64)
    offsets=np.asarray(component_offsets,dtype=np.int64)
    n=len(p); out=np.zeros((n,3),dtype=np.float64)
    a2=float(core_radius)**2; pref=float(gamma)/(4.0*np.pi)
    for c in range(len(offsets)-1):
        lo,hi=int(offsets[c]),int(offsets[c+1])
        if hi-lo<3: continue
        seg_a=p[lo:hi]; seg_b=np.roll(seg_a,-1,axis=0)
        dl=seg_b-seg_a; mid=0.5*(seg_a+seg_b)
        for i in range(n):
            r=p[i][None,:]-mid
            den=(np.einsum('ij,ij->i',r,r)+a2)**1.5
            out[i]+=pref*np.sum(np.cross(dl,r)/den[:,None],axis=0)
    return out


def segment_biot_savart(targets, vertices, component_offsets, gammas, core_radius=0.0):
    """Velocity from closed piecewise-straight finite vortex segments.

    With core_radius=0 this is the exact finite straight-segment Biot--Savart formula.
    The optional core softens the line singularity; standard campaigns keep source
    threads clear of the knot so the exact/near-exact regime is used.
    """
    X=np.ascontiguousarray(targets,dtype=np.float64)
    V=np.ascontiguousarray(vertices,dtype=np.float64)
    O=np.asarray(component_offsets,dtype=np.int64)
    G=np.asarray(gammas,dtype=np.float64)
    out=np.zeros((len(X),3),dtype=np.float64)
    a2=float(core_radius)**2
    fourpi=4.0*np.pi
    for c in range(len(O)-1):
        lo,hi=int(O[c]),int(O[c+1])
        if hi-lo<3: continue
        g=float(G[c])
        for j in range(lo,hi):
            k=j+1 if j+1<hi else lo
            A=V[j]; B=V[k]; L=B-A
            L2=float(np.dot(L,L))
            if L2<=0: continue
            r1=X-A[None,:]; r2=X-B[None,:]
            cr=np.cross(r1,r2)
            cr2=np.einsum('ij,ij->i',cr,cr)
            n1=np.sqrt(np.einsum('ij,ij->i',r1,r1)+a2)
            n2=np.sqrt(np.einsum('ij,ij->i',r2,r2)+a2)
            term=(r1@L)/np.maximum(n1,1e-300)-(r2@L)/np.maximum(n2,1e-300)
            den=cr2+a2*L2
            mask=den>1e-300
            coeff=np.zeros(len(X),float)
            coeff[mask]=(g/fourpi)*term[mask]/den[mask]
            out += cr*coeff[:,None]
    return out
