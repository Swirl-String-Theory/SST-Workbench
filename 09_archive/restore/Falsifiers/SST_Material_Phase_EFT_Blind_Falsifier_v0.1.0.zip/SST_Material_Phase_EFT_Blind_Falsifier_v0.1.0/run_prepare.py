from __future__ import annotations
import argparse,json,pathlib
from sst_eft.blind import prepare

def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--config",required=True); ap.add_argument("--dataset",required=True); ap.add_argument("--out",required=True); a=ap.parse_args()
 cfg=json.loads(pathlib.Path(a.config).read_text(encoding="utf-8")); lock=prepare(a.dataset,a.out,cfg); print(json.dumps(lock,indent=2))
if __name__=="__main__": main()
