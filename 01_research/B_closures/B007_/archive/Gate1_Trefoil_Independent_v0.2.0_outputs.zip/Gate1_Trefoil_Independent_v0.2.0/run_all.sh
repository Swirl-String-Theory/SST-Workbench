#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python src/geometry_proof.py --out results/reach_certificate.json
python src/qualify.py --q 0 --grids 64 96 128 --helicity-grids 64 96 128 --save-seed-grid 128 --output results/q0.json
python src/qualify.py --q 1 --grids 64 96 128 --helicity-grids 64 96 128 --save-seed-grid 128 --output results/q1.json
python src/assess.py
python -m pytest -q tests
