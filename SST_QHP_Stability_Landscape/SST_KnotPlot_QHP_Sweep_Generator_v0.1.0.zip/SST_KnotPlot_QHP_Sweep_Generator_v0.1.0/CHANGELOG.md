# Changelog

## 0.1.0
- Initial controlled Q/H/P geometry sweep generator.
- Uniform arclength resampling.
- Seed-derived Q/H/P basis fields with tangential and rigid-motion removal.
- Equal RMS normalization for comparable dimensionless amplitudes.
- BASIC 13-point axis sweep, EXTENDED axis sweep, optional 125-point full grid.
- Geometry safety diagnostics and direct `qhp_metadata.csv` output.
- Focus runner for family 6.3.
