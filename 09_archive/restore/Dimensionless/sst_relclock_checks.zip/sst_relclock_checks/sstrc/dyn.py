"""
Thin-filament swirl-string dynamics.

Model
-----
Desingularised (Rosenhead-Moore) Biot-Savart for a closed filament of
circulation Gamma with regularisation parameter a:

    v(x) = Gamma/(4 pi) sum_j  e_j x (x - r_j) / (|x - r_j|^2 + a^2)^{3/2}

with e_j the edge vector and r_j its midpoint. The LIA alternative is

    v = (Gamma/(4 pi)) * ln(R/a) * kappa * B

DECLARED PARAMETERS (audit requirement: no undeclared regularisation)
    a            core / regularisation radius
    v_floor      velocity floor applied before the timestep (0 disables)
    dt           timestep, set from cfl * delta^2 / Gamma unless overridden
    resample_every  arclength re-equidistribution interval; 0 disables.
                    Resampling is a DISSIPATIVE operation and is reported as
                    such, not hidden.

Units
-----
The integrator runs in reduced units (Gamma = 1, curve scale ~ 1). SST units
enter only through clock prefactors, which the check-1 harness shows to cancel.
This separation is deliberate: it is the numerical demonstration of audit
point M1.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import geom


@dataclass
class SolverConfig:
    a: float = 0.05
    Gamma: float = 1.0
    cfl: float = 0.25
    dt: float | None = None
    steps: int = 1200
    sample_every: int = 12
    resample_every: int = 0
    v_floor: float = 0.0
    model: str = "bs"  # "bs" or "lia"
    lia_R: float = 1.0
    N: int = 96
    reverse_at: int | None = None  # Loschmidt: reverse velocity at this step


def bs_velocity(X: np.ndarray, a: float, Gamma: float) -> np.ndarray:
    Xn = np.roll(X, -1, axis=0)
    e = Xn - X
    r = 0.5 * (X + Xn)
    d = X[:, None, :] - r[None, :, :]
    denom = (np.einsum("ijk,ijk->ij", d, d) + a * a) ** 1.5
    cr = np.cross(e[None, :, :], d)
    return Gamma / (4.0 * np.pi) * np.einsum("ijk,ij->ik", cr, 1.0 / denom)


def lia_velocity(X: np.ndarray, a: float, Gamma: float, R: float) -> np.ndarray:
    L = geom.total_length(X)
    Xs, Xss, _ = geom.spectral_derivatives(X, L)
    beta = Gamma / (4.0 * np.pi) * np.log(max(R / a, 1.0000001))
    return beta * np.cross(Xs, Xss)


def velocity(X: np.ndarray, cfg: SolverConfig) -> np.ndarray:
    if cfg.model == "lia":
        v = lia_velocity(X, cfg.a, cfg.Gamma, cfg.lia_R)
    else:
        v = bs_velocity(X, cfg.a, cfg.Gamma)
    if cfg.v_floor > 0.0:
        n = np.linalg.norm(v, axis=1, keepdims=True)
        v = np.where(n < cfg.v_floor, 0.0, v)
    return v


# ---------------------------------------------------------------------------
# invariants
# ---------------------------------------------------------------------------
def kinetic_energy(X: np.ndarray, a: float, Gamma: float, rho: float = 1.0) -> float:
    """Regularised filament kinetic energy (rho Gamma^2 / 8 pi) sum e_i.e_j/|r_ij|_a."""
    Xn = np.roll(X, -1, axis=0)
    e = Xn - X
    r = 0.5 * (X + Xn)
    d = r[:, None, :] - r[None, :, :]
    den = np.sqrt(np.einsum("ijk,ijk->ij", d, d) + a * a)
    num = np.einsum("ik,jk->ij", e, e)
    return float(rho * Gamma**2 / (8.0 * np.pi) * np.sum(num / den))


def enstrophy(L: float, a: float, Gamma: float) -> float:
    """Rankine-core enstrophy of a tube of length L and core radius a:
    Z = 1/2 * |omega|^2 * V = 1/2 (Gamma/pi a^2)^2 (pi a^2 L) = Gamma^2 L / (2 pi a^2)."""
    return Gamma**2 * L / (2.0 * np.pi * a * a)


def curvature_spectrum(X: np.ndarray, n_keep: int | None = None):
    """Power spectrum of curvature on the uniform-arclength grid."""
    kappa, _, _ = geom.curvature_torsion(X)
    F = np.fft.rfft(kappa - kappa.mean())
    P = np.abs(F) ** 2
    return P[1:] if n_keep is None else P[1 : n_keep + 1]


def torsion_spectrum(X: np.ndarray, n_keep: int | None = None):
    _, tau, _ = geom.curvature_torsion(X)
    tau = np.clip(tau, -1e6, 1e6)
    F = np.fft.rfft(tau - tau.mean())
    P = np.abs(F) ** 2
    return P[1:] if n_keep is None else P[1 : n_keep + 1]


def position_spectrum(X: np.ndarray, n_keep: int | None = None):
    """Bending-like spectrum from node positions: P_n ~ n^2 |X_n|^2."""
    Xc = X - X.mean(axis=0)
    F = np.fft.rfft(Xc, axis=0)
    n = np.arange(F.shape[0])
    P = (n**2) * np.sum(np.abs(F) ** 2, axis=1)
    return P[1:] if n_keep is None else P[1 : n_keep + 1]


SPECTRUM_BASES = {
    "curvature": curvature_spectrum,
    "torsion": torsion_spectrum,
    "position": position_spectrum,
}


# ---------------------------------------------------------------------------
# integrator
# ---------------------------------------------------------------------------
@dataclass
class Trajectory:
    t: np.ndarray
    L: np.ndarray
    E: np.ndarray
    Wr: np.ndarray
    Tw: np.ndarray
    Lk: np.ndarray
    kappa_max: np.ndarray
    Rg: np.ndarray
    spectra: dict = field(default_factory=dict)
    frames: list = field(default_factory=list)
    meta: dict = field(default_factory=dict)


def run(X0: np.ndarray, cfg: SolverConfig, twist_turns: float = 0.0,
        keep_frames: bool = False, n_spec: int = 24) -> Trajectory:
    X = X0.copy()
    u = geom.init_material_frame(X, twist_turns=twist_turns)

    delta = geom.total_length(X) / X.shape[0]
    dt = cfg.dt if cfg.dt is not None else cfg.cfl * delta**2 / cfg.Gamma

    rec = {k: [] for k in ["t", "L", "E", "Wr", "Tw", "Lk", "kappa_max", "Rg"]}
    spec = {b: [] for b in SPECTRUM_BASES}
    frames = []
    sign = 1.0
    n_resample = 0

    for step in range(cfg.steps + 1):
        if cfg.reverse_at is not None and step == cfg.reverse_at:
            sign = -1.0

        if step % cfg.sample_every == 0:
            Xu = geom.resample_uniform(X)
            L = geom.total_length(X)
            kap, _, _ = geom.curvature_torsion(Xu)
            w, tw, lk = geom.linking(X, u)
            rec["t"].append(step * dt)
            rec["L"].append(L)
            rec["E"].append(kinetic_energy(X, cfg.a, cfg.Gamma))
            rec["Wr"].append(w)
            rec["Tw"].append(tw)
            rec["Lk"].append(lk)
            rec["kappa_max"].append(float(np.max(kap)))
            rec["Rg"].append(float(np.sqrt(np.mean(np.sum((X - X.mean(0)) ** 2, axis=1)))))
            for b, fn in SPECTRUM_BASES.items():
                spec[b].append(fn(Xu, n_keep=n_spec))
            if keep_frames:
                frames.append(X.copy())

        if step == cfg.steps:
            break

        # RK4 on positions; material frame transported by the net tangent rotation
        T_old = geom.edge_tangents(X)
        k1 = sign * velocity(X, cfg)
        k2 = sign * velocity(X + 0.5 * dt * k1, cfg)
        k3 = sign * velocity(X + 0.5 * dt * k2, cfg)
        k4 = sign * velocity(X + dt * k3, cfg)
        X = X + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        T_new = geom.edge_tangents(X)
        u = geom.parallel_transport(u, T_old, T_new)
        u = geom.orthonormalise_frame(X, u)

        if cfg.resample_every and (step + 1) % cfg.resample_every == 0:
            Xr = geom.resample_uniform(X)
            u = geom.orthonormalise_frame(Xr, u)
            X = Xr
            n_resample += 1

    traj = Trajectory(
        t=np.array(rec["t"]),
        L=np.array(rec["L"]),
        E=np.array(rec["E"]),
        Wr=np.array(rec["Wr"]),
        Tw=np.array(rec["Tw"]),
        Lk=np.array(rec["Lk"]),
        kappa_max=np.array(rec["kappa_max"]),
        Rg=np.array(rec["Rg"]),
        spectra={b: np.array(v) for b, v in spec.items()},
        frames=frames,
        meta={
            "dt": dt,
            "a": cfg.a,
            "Gamma": cfg.Gamma,
            "N": X.shape[0],
            "steps": cfg.steps,
            "model": cfg.model,
            "v_floor": cfg.v_floor,
            "resample_every": cfg.resample_every,
            "n_resample": n_resample,
            "twist_turns_initial": twist_turns,
        },
    )
    return traj
