from pathlib import Path
import json
import math
from sst_vortex_shear.campaign import verify_seal
from sst_vortex_shear.reveal_constants import C, ALPHA, V_CIRCLEARROW, R_C, RHO_F

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "A049_Isotropic_Euler_Vortex_Shear_Modulus_Falsifier_v0.1.0-outputs"
BLIND = BASE / "BLIND"
OUT = BASE / "REVEALED"
OUT.mkdir(parents=True, exist_ok=True)

ok, errors = verify_seal(BLIND)
if not ok:
    raise SystemExit("Blind seal verification failed: " + "; ".join(errors))

py_summary = json.loads((BLIND / "python_backend" / "blind_summary.json").read_text(encoding="utf-8"))
native_path = BLIND / "native_backend" / "blind_summary.json"
parity_path = BLIND / "backend_parity_summary.json"
native_summary = json.loads(native_path.read_text(encoding="utf-8")) if native_path.exists() else None
parity = json.loads(parity_path.read_text(encoding="utf-8")) if parity_path.exists() else None

A2 = float(py_summary["measurements"]["A2_mean"])
c_ratio = float(py_summary["measurements"]["candidate_cT_over_urms"])
master_target_ratio = float(py_summary["master_factor_wave_gate"]["target_cT_over_reference_speed"])
required_mapping = float(py_summary["master_factor_wave_gate"]["required_urms_over_reference_speed_for_exact_closure"])

# Reveal mapping: first test the strict one-to-one identification u_rms = v_circlearrow.
c_born_unit_mapping = c_ratio * V_CIRCLEARROW
mu_born_unit_mapping = RHO_F * c_born_unit_mapping ** 2
master_measured = C / c_born_unit_mapping
master_target = 4.0 / ALPHA
master_rel_error = abs(master_measured - master_target) / master_target

c_target_from_master = V_CIRCLEARROW / 2.0
c_target_from_alpha = ALPHA * C / 4.0
v_alpha_half = ALPHA * C / 2.0
Gamma = 2.0 * math.pi * R_C * V_CIRCLEARROW

release_mode = "PYTHON_REFERENCE_ONLY"
if native_summary is not None and parity is not None and parity.get("status") == "PASS":
    release_mode = "FULL_PYTHON_NATIVE_QUALIFIED"

revealed = {
    "catalog_id": "A049",
    "version": "v0.1.0",
    "blind_seal_verified": True,
    "release_mode": release_mode,
    "blind_pipeline_status": py_summary["pipeline_status"],
    "blind_research_question_status": py_summary["research_question_status"],
    "blind_master_factor_wave_closure_status": py_summary["master_factor_wave_closure_status"],
    "scope_guard": py_summary["scope_guard"],
    "canonical_constants": {
        "c_m_s": C,
        "alpha": ALPHA,
        "v_circlearrow_m_s": V_CIRCLEARROW,
        "r_c_m": R_C,
        "rho_f_kg_m3": RHO_F,
        "Gamma_m2_s": Gamma,
        "alpha_c_over_2_m_s": v_alpha_half,
        "v_vs_alpha_c_over_2_relative": abs(V_CIRCLEARROW - v_alpha_half) / V_CIRCLEARROW,
    },
    "affine_born_reveal": {
        "A2_measured": A2,
        "mu_over_rho_urms2": A2,
        "candidate_cT_over_urms": c_ratio,
        "strict_mapping_assumption": "u_rms = v_circlearrow",
        "candidate_cT_m_s_under_strict_mapping": c_born_unit_mapping,
        "candidate_mu_Pa_under_rho_f_and_strict_mapping": mu_born_unit_mapping,
    },
    "master_factor_wave_closure": {
        "target_cT_over_v_circlearrow": master_target_ratio,
        "target_cT_m_s": c_target_from_master,
        "target_cT_from_alpha_c_over_4_m_s": c_target_from_alpha,
        "measured_c_over_cT_under_strict_mapping": master_measured,
        "target_4_over_alpha": master_target,
        "relative_error": master_rel_error,
        "required_u_rms_over_v_circlearrow_for_exact_closure": required_mapping,
        "status": py_summary["master_factor_wave_closure_status"],
        "interpretation": (
            "The affine Born modulus is nonzero and isotropic, but under the strict one-to-one mapping "
            "u_rms=v_circlearrow it does not reproduce the 1/2 speed ratio. Exact master-factor closure "
            "would require an independently derived u_rms/v_circlearrow mapping equal to the reported value; "
            "fitting that factor after the fact is not accepted as closure."
        ),
    },
    "next_gate": (
        "Full nonlinear Euler persistence/relaxation test: determine whether the Born shear response "
        "survives at low frequency and supports a coherent transverse pole omega approximately c_T k."
    ),
}
(OUT / "reveal_summary.json").write_text(json.dumps(revealed, indent=2), encoding="utf-8")

lines = [
    "# A049 v0.1.0 reveal report",
    "",
    "Blind seal: **VERIFIED**",
    f"Release mode: **{release_mode}**",
    f"Blind pipeline: **{py_summary['pipeline_status']}**",
    f"Affine research result: **{py_summary['research_question_status']}**",
    f"Master-Factor Wave Closure Gate: **{py_summary['master_factor_wave_closure_status']}**",
    "",
    "## Revealed scale mapping",
    "",
    f"- measured A2 = {A2:.12e}",
    f"- candidate c_T/u_rms = {c_ratio:.12e}",
    f"- strict-map c_T = {c_born_unit_mapping:.12e} m s^-1",
    f"- strict-map mu = {mu_born_unit_mapping:.12e} Pa",
    f"- measured c/c_T = {master_measured:.12e}",
    f"- target 4/alpha = {master_target:.12e}",
    f"- relative master-factor mismatch = {master_rel_error:.12e}",
    f"- required u_rms/v_circlearrow for exact 1/2 closure = {required_mapping:.12e}",
    "",
    "## Interpretation",
    "",
    revealed["master_factor_wave_closure"]["interpretation"],
    "",
    "## Scope guard",
    "",
    revealed["scope_guard"],
    "",
    "## Next gate",
    "",
    revealed["next_gate"],
]
(OUT / "reveal_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps(revealed, indent=2))
