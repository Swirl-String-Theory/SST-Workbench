@echo off
setlocal
cd /d "%~dp0"
call .venv\Scripts\activate.bat
pytest -q
exit /b %errorlevel%
