#!/usr/bin/env bash
# SST relational-clock pre-canonisation checks - POSIX launcher
set -euo pipefail
cd "$(dirname "$0")"
PROFILE="${1:-standard}"
python3 -m pip install -q -r requirements.txt || echo "[WARN] pip install failed"
python3 -m pytest -q tests || echo "[WARN] tests unavailable/failed"
python3 main.py --profile "$PROFILE" --out "results_${PROFILE}"
echo "Done. Open results_${PROFILE}/REPORT.md"
