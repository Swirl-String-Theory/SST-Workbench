# SST Canon v0.8.18 Research-Track Patch Notes

Patch: `Projected swirl-vorticity frequency / Coriolis-parameter analogue`

## Target

This is an incremental patch against the already cleaned Foucault research-track version of:

- `SST_CANON-v0.8.18-research-track.tex`

The main Canon file is included unchanged in the ZIP only to make compilation reproducible.

## Added content

The patch adds a research-track paragraph after the Foucault energy-density form:

- Defines the projected swirl-vorticity frequency
  \[
  f_{\circlearrowleft}(x,t;\hat{\mathbf a})
  :=
  \hat{\mathbf a}\cdot(\nabla\times\mathbf u_{\circlearrowleft}).
  \]
- Identifies the orthodox Coriolis parameter as the macroscopic special case
  \[
  f_{\rm Cor}=2\boldsymbol\Omega\cdot\hat{\mathbf n}=\hat{\mathbf n}\cdot(\nabla\times\mathbf u).
  \]
- States the Foucault relation as `f_Cor = 2 Omega_F`.
- Adds knot/atomic diagnostics:
  - local projected frequency `f_K(x; a_hat)`;
  - parallel strand diagnostic `f_parallel`;
  - radial pressure-envelope diagnostic `f_r`;
  - spherical RMS frequency `f_rms^(K)(r)`.
- Keeps pressure support tied to the Euler-vorticity channel, not to a new force law.
- Adds a local solid-body Swirl-Clock estimate
  \[
  S \simeq \sqrt{1-f_{\circlearrowleft}^2 r_\perp^2/(4c^2)}.
  \]

## Guardrail update

The old guardrail saying no `leaf-rate` relation is asserted is replaced with a stronger density guard:

- no law of the form `rho_f = K Omega` is asserted;
- no identification of projected vorticity with `rho_f`, `rho_core`, or `v_swirl` is asserted;
- any such relation requires a micro-to-macro averaging theorem.

## Compile check

Compiled via:

```bash
pdflatex -interaction=nonstopmode -halt-on-error SST_CANON-v0.8.18.tex
pdflatex -interaction=nonstopmode -halt-on-error SST_CANON-v0.8.18.tex
pdflatex -interaction=nonstopmode -halt-on-error SST_CANON-v0.8.18.tex
```

Result: exit code `0`; no undefined references in the final run.

## Status recommendation

Keep this in the Research Track as:

- `[RESEARCH TRACK / ORTHODOX ROSETTA BRIDGE / CONDITIONAL DIAGNOSTIC]`

Do not promote to main Canon until an explicit averaging/pressure-closure theorem connects projected vorticity diagnostics to atom-scale or knot-envelope observables.
