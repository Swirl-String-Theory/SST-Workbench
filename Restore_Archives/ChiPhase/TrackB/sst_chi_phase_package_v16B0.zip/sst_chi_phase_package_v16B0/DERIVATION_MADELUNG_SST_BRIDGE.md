# Derivation: A=B=C from SST axioms via Madelung transformation

## Status

**CANON-DERIVED** (conditional on three SST axioms below).

The single-modulus condition A=B=C is not a free choice.
It follows necessarily from SST's quantum superfluid structure via a two-step
algebraic argument.  v16B.0 closes Gate G5 from v13B.0.

---

## SST axioms used

| # | Axiom | SST basis |
|---|---|---|
| A1 | Quantum vacuum = irrotational inviscid barotropic fluid | Core of SST |
| A2 | Vortex lines carry quantized circulation Γ = nΓ₀ | SST topology |
| A3 | Vortex core has finite healing length ξ defined as the scale where gradient energy = depletion energy | SST resolved-core model |

No additional assumptions are made.

---

## Step 1: Madelung transformation (mathematical identity)

For any quantum superfluid (fluid with quantum coherence):

    Ψ = √(ρ/ρ₀) · exp(iφ)

where ρ is the local density and φ is the velocity potential:
v = (ħ/m) ∇φ.

The full kinetic energy density of a quantum fluid is:

    ε_kin = (ħ²/2m) |∇Ψ|²

This splits as:

    (ħ²/2m)|∇Ψ|² = (ħ²/2m)|∇F|² + ½ρ₀F² (ħ/m)²|∇φ|²
                  = quantum pressure  +  classical kinetic energy

**A classical fluid** has only the second term (no quantum pressure):
    ε_kin^{classical} = ½ρ|v|²  (no |∇F|² term)

**A quantum superfluid** (SST) has both terms combined as (ħ²/2m)|∇Ψ|².

---

## Step 2: A=B from the Pythagorean identity (forced)

For a vortex with winding number n:

    Ψ(r,θ) = F(r) e^{inθ}

The Euclidean gradient in polar coordinates gives:

    |∇Ψ|² = (∂F/∂r)² + n²F²/r²

This is the **Pythagorean theorem for the modulus of a complex gradient**.
Both terms come from the SAME expression |∇Ψ|².

In the generic radial Lagrangian:

    𝓛_r = A F'²r + B n²F²/r + (C/2)(F²-1)²r

the Madelung derivation gives:

    A = (ħ²/2m)ρ₀    [from |∇F|² term]
    B = (ħ²/2m)ρ₀    [from F²|∇φ|² = F²/r² term]

Therefore:

    A = B  (necessarily, not as a choice)

This step requires the quantum pressure term.  In a classical fluid (no quantum
pressure, A = 0), we get A ≠ B and no stable vortex core exists (the ODE
loses the F'' term and has no smooth 0→1 solution).

**Numerical verification:** reducing A → 0 while keeping B = C = 1 shows
the core structure becomes unphysical (F collapses toward a step function).
See v16B.0 simulation output.

---

## Step 3: C=A from healing length normalization (physical, not conventional)

The depletion energy density for a barotropic fluid expanded around ρ₀:

    ε_dep = (c_s²ρ₀/2)(F² - 1)²

where c_s is the sound speed at ρ = ρ₀.

Two physical energy scales:
- Gradient stiffness: κ = (ħ/m)²ρ₀
- Depletion stiffness: λ = c_s²ρ₀

The **healing length ξ** is defined as the physical scale at which gradient
energy balances depletion energy:

    ξ² = κ/λ = (ħ/m)²/c_s²

This is not a convention — it is a physical quantity determined by ħ/m and c_s.
After normalizing r → r/ξ (expressing all lengths in units of ξ):

    κ (dimensionless gradient) = 1
    λ ξ² (dimensionless depletion) = c_s²ρ₀ · ξ²/(ρ₀(ħ/m)²) = c_s² ξ²/( ħ/m)² = 1

Therefore:

    C/A = (λ ξ²)/κ = 1   →   C = A

Combined: **A = B = C = 1** (all from SST axioms + Madelung + definition of ξ).

---

## Derived theorem

Under SST axioms A1–A3:

    𝓛_r = F'²r + n²F²/r + ½(F²-1)²r    (A=B=C=1)

The Euler-Lagrange equation for n=1 is:

    F'' + F'/r - F/r² + F(1-F²) = 0     (unit GP/NLSE vortex ODE)

The ring constant extracted numerically:

    α_ring = 2 - C_∞ = 1.6193509...

    β_ring (q=0) = α_ring - 1 = 0.6193509...

This number is a **pure geometric constant** of the unit GP/NLSE ODE.
It does not depend on the value of ξ (only on the shape of F(r)).

---

## Why the classical (A=0) case fails

A purely classical irrotational fluid (no quantum coherence, no quantum
pressure) has A = 0, B = C ≠ 0.  The EL equation becomes:

    -n²F/r² + C·F(1-F²) = 0

This is algebraic in F and has only the solution F² = 1 - n²/(Cr²), which
becomes negative for r < n/√C.  There is no smooth bounded solution with
F(0) = 0, F(∞) = 1.

**The quantum pressure term (A-term) is essential for a stable vortex core.**
Its presence is what forces A = B, which is what gives A = B = C.
The single-modulus condition is therefore a direct consequence of the quantum
coherence of SST's vacuum.

---

## Remaining open gates (not closed by v16B.0)

| Gate | Status | Content |
|---|---|---|
| G6: φ-proximity structural | Open | α_ring ≈ 1.619 ≈ φ−0.001; proximity is numerical, not proven geometric |
| G7: ξ = r_c identification | Open | If c_s = c (causal speed), then ξ = r_c; not yet derived from SST EoS |
| G8: α_ring → α_em bridge | Open | Connecting ring constant to fine-structure constant requires separate derivation |

Gate G5 (A=B=C SST-internal derivation) is now **CLOSED** by v16B.0.

---

## Comparison table

| Step | Previous status | v16B.0 status |
|---|---|---|
| GP/NLSE energy functional | Imported from BEC (ansatz) | **Derived from SST axioms A1–A3** |
| A=B (equal stiffnesses) | Assumed (single-modulus lemma) | **Derived from Pythagorean identity** |
| C=A (depletion = gradient) | Assumed (normalization choice) | **Derived from healing length definition** |
| α_ring ≈ 1.619 | Conditional on GP import | **Derived from SST axioms** |
