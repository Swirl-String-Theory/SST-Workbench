# SST finite-core `c2` / `sigma` falsifier v0.1.0

This package tests whether a declared finite-core variational model independently
produces the required second-order shell coefficient from:

- a relaxed radial core profile;
- its amplitude and transverse Hessians;
- a cell Hessian;
- a contact-stress Hessian.

The package is deliberately split into a blind derivation and a later score.
The target values do not occur in the blind source or reference configuration.

## Important status

The bundled cell operator and contacts are **demonstration inputs**. Their result
cannot support a scientific closure claim. Replace them with independently
computed matrices or Ridgerunner/contact-stress multipliers. The harness will
otherwise mark the input quality as `demo_or_incomplete_input`.

## Install

```bash
python -m pip install -r requirements.txt
```

## Run

Single command:

```bash
python falsify.py --config config/reference.yaml
```

Or run the stages separately:

```bash
python derive_blind.py --config config/reference.yaml
python run_campaign.py --config config/reference.yaml
python score_target.py \
  --input outputs/blind_result.json \
  --campaign outputs/campaign_summary.json
```

`score_target.py` exits with code 0 only when the full candidate survives. A
falsified or methodologically incomplete run intentionally returns a nonzero exit
code.

## Replace the demonstration contact data

The easiest input is an edge list:

```csv
i,j,lambda
0,16,1.234
...
```

Here `lambda` should be an independently produced nonnegative contact multiplier.
The scalarized contact Hessian is the corresponding weighted graph Laplacian.
For a full vector Ridgerunner treatment, export the already assembled symmetric
contact Hessian as CSV and use:

```yaml
contact:
  kind: matrix_csv
  path: ../data/contact_hessian.csv
  scale: 1.0
  source_class: ridgerunner_export
```

## Replace the demonstration cell Hessian

```yaml
cell:
  kind: matrix_csv
  n_dof: 32
  parallel_path: ../data/H_cell_parallel.csv
  transverse_path: ../data/H_cell_transverse.csv
  source_class: independent_cell_solver
```

Both matrices must be symmetric and use the same nondimensionalisation as the
core functional and contact Hessian.

## Outputs

- `blind_result.json`: independent coefficient calculation and provenance hashes;
- `campaign_summary.json`: resolution and branch sensitivity;
- `scored_result.json`: target comparison and final gate verdict.

## Interpretation

- `CANDIDATE_SURVIVES_PREREGISTERED_FALSIFIER`: necessary gates passed; not yet a
  derivation of a measured coupling.
- `TARGET_CLOSURE_FALSIFIED_FOR_DECLARED_MODEL`: the declared model misses the
  target band.
- `INCONCLUSIVE_METHOD_GATES_FAILED`: a numerical match may exist, but scientific
  provenance, convergence or robustness is insufficient.
