@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (
  echo Usage: run_focus_topology.cmd ^<topology^> [--libraries=...] [--min-carriers=N] [--kind=knots^|links^|all]
  echo Example: run_focus_topology.cmd L2a1 --libraries=Gilbert,Katlas --min-carriers=2 --kind=links
  exit /b 2
)
set "TOPOLOGY=%~1"
shift
set "LIBRARIES="
set "MIN_CARRIERS="
set "KIND="
:parse_args
if "%~1"=="" goto args_done
set "ARG=%~1"
if /I "!ARG:~0,12!"=="--libraries=" (
  set "LIBRARIES=!ARG:~12!"
  shift
  goto parse_args
)
if /I "!ARG:~0,15!"=="--min-carriers=" (
  set "MIN_CARRIERS=!ARG:~15!"
  shift
  goto parse_args
)
if /I "!ARG:~0,7!"=="--kind=" (
  set "KIND=!ARG:~7!"
  shift
  goto parse_args
)
echo ERROR: unsupported focus argument: %~1
exit /b 2
:args_done
set "OUT=outputs\focus_%TOPOLOGY%"
if exist "%OUT%" rmdir /s /q "%OUT%"
if not exist "outputs" mkdir "outputs"
echo ============================================================
echo SST Modal Clock v0.2.2.7 - topology focus: %TOPOLOGY%
if defined LIBRARIES echo Libraries: %LIBRARIES%
if defined MIN_CARRIERS echo Min carriers: %MIN_CARRIERS%
if defined KIND echo Kind: %KIND%
echo ============================================================
call run_setup.cmd || exit /b 1
call run_build_native.cmd || exit /b 1
call run_selftest.cmd || exit /b 1
call .venv\Scripts\activate.bat || exit /b 1
set "SELECT_ARGS=--topology=%TOPOLOGY%"
if defined LIBRARIES set SELECT_ARGS=!SELECT_ARGS! --libraries="%LIBRARIES%"
if defined MIN_CARRIERS set SELECT_ARGS=!SELECT_ARGS! --min-carriers=%MIN_CARRIERS%
if defined KIND set SELECT_ARGS=!SELECT_ARGS! --kind=%KIND%
python -m sst_modal_clock.cli scan-provenance config\basic.json !SELECT_ARGS! > "outputs\SOURCE_SCAN_%TOPOLOGY%.json" || exit /b 1
python -m sst_modal_clock.cli prepare-provenance "%OUT%" config\basic.json !SELECT_ARGS! || exit /b 1
python -m sst_modal_clock.cli run "%OUT%" config\basic.json --branch stage_a || exit /b 1
python -m sst_modal_clock.cli analyze-stage-a "%OUT%" config\basic.json || exit /b 1
python -m sst_modal_clock.cli run "%OUT%" config\basic.json --branch stage_a_gauge_low || exit /b 1
python -m sst_modal_clock.cli run "%OUT%" config\basic.json --branch stage_a_gauge_high || exit /b 1
python -m sst_modal_clock.cli analyze-stage-a-gauge "%OUT%" config\basic.json || exit /b 1
python -m sst_modal_clock.cli analyze-provenance "%OUT%" config\basic.json || exit /b 1
python -m sst_modal_clock.cli run "%OUT%" config\basic.json --branch material || exit /b 1
python -m sst_modal_clock.cli run "%OUT%" config\basic.json --branch fixed || exit /b 1
python -m sst_modal_clock.cli analyze-stage-b "%OUT%" config\basic.json || exit /b 1
echo.
echo Source scan: outputs\SOURCE_SCAN_%TOPOLOGY%.json
echo Blind result: %OUT%\analysis\blind_summary.json
