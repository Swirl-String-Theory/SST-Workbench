# NLSE/Gross--Pitaevskii Inertia Closure Addendum

This addendum tests the requested SST/VAM inertia lemma using a defocusing Nonlinear Schrödinger / Gross--Pitaevskii condensate route.

Main result:

- NLSE/GPE supplies an intrinsic acoustic speed `c_s`, healing length `xi`, quantized circulation `Gamma_q = h/m_star`, and exact Galilean boost inertia `DeltaE = 1/2 M_NLS u^2`.
- If a defect satisfies `E0 = 1/2 M_NLS c_s^2`, then `DeltaE/E0 = u^2/c_s^2` follows.
- With canonical SST circulation `Gamma0 = 2*pi*r_c*v_swirl` and `xi = r_c`, the NLSE relation predicts `c_s = v_swirl/sqrt(2)`, not `c_light`.
- Therefore the NLSE route is a conditional acoustic closure, not yet a hard derivation of the light-speed Lorentz coefficient.

Files:

- `nlse_inertia_closure_patch.tex` — research-track LaTeX patch.
- `reproduce_nlse_inertia_closure.py` — reproducible diagnostic script.
- `nlse_inertia_closure_scenarios.csv` — numerical scenario table.
- `nlse_inertia_closure_output.txt` — default run output.
