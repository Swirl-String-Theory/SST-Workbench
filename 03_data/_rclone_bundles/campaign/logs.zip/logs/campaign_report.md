# Fseries full campaign — status report

**Command:** `run_catalog_batch.py --all-fseries -r150,300,600,900,1200 -t12`  
**Started / relaunched:** 2026-08-03 (after preflight + first-failure fix)  
**Log:** `KnotPlot/ridgerunner/out/logs/batch_all_fseries_t12.log`  
**Err log:** `KnotPlot/ridgerunner/out/logs/batch_all_fseries_t12.err.log`  
**Summary (written as stems finish):** `KnotPlot/ridgerunner/out/batch_fseries_summary.json`  
**Per-stem outs:** `KnotPlot/ridgerunner/out/fseries/<stem>/t12/`

## Preflight

| Check | Result |
|-------|--------|
| Dry-run discovery | **78** stems (includes `12a_1202`, `12a_1202z6`, `3_1p`) |
| Free disk | ~409 GB on C: |
| Multithread `-t12` | `bin/ridgerunner_multithread.exe` OK |
| Smoke `--stems 3_1 -r150,300 -t12` | **ok** — N150 Rop=32.782830, N300 Rop=32.754287 |

## First-launch failure (triaged)

Stem **`10_1`** N150 coarse died ~21 min in with:

```text
ERROR: stage 1 RR output missing: ...\n150_rr_010k_c.txt
```

Observations:

1. **Premature RR kill (root cause)** — `run_knotplot_txt.run_ridgerunner_live` called `_terminate_process` when stdout hit EOF while the child was still alive (common under redirected/piped logging). **Fixed**: always `proc.wait()`; only terminate on Ctrl+C.
2. **Stale-clear Path bug** — `Path(r'%SDIR%\')` broke on trailing `\`. **Fixed** (forward-slash `SDIR_PY`).
3. **`--NoOutputFiles`** is passed by default (suppresses animation `vectfiles/` only; final VECT still written). Not the missing-`.txt` cause.
4. **Pathological seed scale** — after `-a` autoscale, `10_1` starts near **Rop ~3500–4300** (pre-scale thickness ~0.012). Coarse is slow (~50 steps/min) → multi-hour N150 for this stem alone.
5. **Interleaved progress bars** — two alternating Rop/Thi streams in the log (possible OpenMP stdout races). Flagged for native RR follow-up.

Partial artifacts were cleaned; campaign **relaunched** without `--force` (PID via `cmd` → `python -u run_catalog_batch.py …`).

## Resume

```bat
cd C:\workspace\projects\SST-Workbench\KnotPlot\ridgerunner
python -u run_catalog_batch.py --all-fseries -r150,300,600,900,1200 -t12
```

Or a subset after failures:

```bat
python -u run_catalog_batch.py --stems 10_1,10_1n -r150,300,600,900,1200 -t12
```

Do **not** pass `--force` unless you intend to rebuild finished polishes.

## Rop table (available now)

| Stem | N150 | N300 | N600 | N900 | N1200 | Notes |
|------|------|------|------|------|-------|-------|
| 3_1 (smoke) | 32.782830 | 32.754287 | — | — | — | `out/3_1/t12` from pre-`out/fseries/` layout |
| 10_1… | (in progress) | | | | | see live summary JSON |

Refresh table from summary when present:

```bat
python -c "import json;d=json.load(open('out/batch_fseries_summary.json',encoding='utf-8')); print(d.get('status'), d.get('ok'), d.get('failed'));
[print(r['stem'], r['status'], r.get('rop_by_n')) for r in d.get('results',[]) if r.get('status')!='dry-run']"
```

## Open bugs → follow-up plans

| Issue | Follow-up |
|-------|-----------|
| Native OpenMP / dual progress lines | `rr_compile_repo_followup` |
| Parallel multi-knot (`--jobs`) already present in batch; tune for this host | `batch_parallel_knots_followup` |
| VortexLab / catalog upsert after polish | `batch_catalog_vortexlab_followup` |
| KnotPlot `--all-knotplot` export batch | `knotplot_export_batch_followup` |
| High-Rop fseries seeds after autoscale (e.g. 10_1) | investigate seed sampling / initial eq before long `-a` (catalog or plCurve tooling) |

## Note

Full 78 × (150→1200) is a **multi-day** sequential run at `-t12`. This report closes the operational checklist items that can complete without waiting for all 78 polishes; the batch process continues in the background and is resume-safe.
