# A055 v0.1.2 — REVEALED report

Blind seal verified: `6c9ffe14369dfe50a41fd311dbfce4cc5bb25808873b055a1285f6809c8df14c`.

## Historical VAM/SST quark check

Historical mapping: `u -> 5_2`, `d -> 6_1` (twist-knot pair).

- Raw diagnostic knot-space rank: **104/595** (fraction 0.174790).
- Raw diagnostic distance: **1.71263911**.
- The historical pair did **not** jointly pass all v0.1.2 knot-space feature gates; no qualified rank is assigned.

Unlike v0.1.0, the scientific rank is withheld if either topology fails the preregistered resolution/CV gates.

## Exploratory SM mass-pattern reveal

- **charged_leptons**: best valid common all-atlas proxy `min_distance` -> ['8_11', 'L8n5', 'L2a1']; log-RMS=2.53714; within-search null=0.330067; familywise common-all=0.330067; eligible cases=55; effect-size pass=False.
- **up_quarks**: best valid common all-atlas proxy `min_distance` -> ['8_11', 'L8n5', 'L2a1']; log-RMS=3.8021; within-search null=0.141386; familywise common-all=0.141386; eligible cases=55; effect-size pass=False.
- **down_quarks**: best valid common all-atlas proxy `min_distance` -> ['8_11', '6_3', 'L2a1']; log-RMS=1.96622; within-search null=0.0764924; familywise common-all=0.0764924; eligible cases=55; effect-size pass=False.
- **massive_EW_Higgs**: best valid common all-atlas proxy `min_distance` -> ['6_2', 'L8a11', 'L8a12']; log-RMS=0.000514158; within-search null=0.137386; familywise common-all=0.141186; eligible cases=55; effect-size pass=True.

Across all preregistered SM groups, valid feature domains and topology triplets, the empirical-p-space global look-elsewhere null fraction is **0.0212979** (best group: `charged_leptons`).

Each valid search uses **10000** null targets at the same total log-mass span.  The intermediate log-position is randomized and the complete eligible triplet search is repeated analytically through the exact lower envelope of candidate error quadratics.  Full null values are stored in `SM_NULL_DISTRIBUTIONS.csv.gz`.

## v0.1.2 domain corrections

- `linking_strength` is **links only**. Knot values are never replaced by `1e-6` or any other artificial floor.
- `abs_writhe` is not used in mixed knot/link fits.
- `contact_ratio` is diagnostic only because it scales explicitly with segment resolution.
- `min_distance` uses segment-segment distance with a fixed component-arclength exclusion and replaces it as the contact observable.
- Zero/non-positive values required by a logarithmic ratio fit are excluded, not shifted.

## Mandatory interpretation limits

1. v0.1.2 does **not** identify a knot/link with an SM particle.
2. PD-derived embeddings are presentation ensembles, not PKLSA ideal/relaxed vortex equilibria.
3. Higgs spin-0/scalar dynamics, gauge charge, color, chirality, weak isospin, lifetime and couplings are **not tested**.
4. Quark masses are scheme/scale dependent; their reveal remains diagnostic only.
5. Promotion to v0.2.0 requires PKLSA/finite-core dynamical observables under the same blind/domain/convergence protocol.
