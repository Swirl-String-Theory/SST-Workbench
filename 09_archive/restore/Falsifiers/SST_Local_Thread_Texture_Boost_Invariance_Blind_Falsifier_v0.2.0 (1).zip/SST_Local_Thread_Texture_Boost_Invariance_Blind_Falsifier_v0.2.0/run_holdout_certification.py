from __future__ import annotations
import argparse, copy, json, shutil, time
from pathlib import Path
from sst_thread_falsifier.campaign import run_full

def rel(a,b,floor=1e-14): return abs(a-b)/max(abs(a),abs(b),floor)
def extract(rep):
    return {d["source_path"]:{"status":d["overall_v020_status"],"response":d["gates"]["G9_orientation_ensemble"]["mean"]} for d in rep["datasets"]}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="config/holdout.json"); ap.add_argument("--dataset",default=r"..\..\KnotPlot\knots\final"); ap.add_argument("--out",default=None); ap.add_argument("--force-python",action="store_true"); ap.add_argument("--skip-build",action="store_true"); a=ap.parse_args()
    cfg=json.loads(Path(a.config).read_text(encoding="utf-8")); Ns=list(cfg.get("resample_ladder",[512,1024])); steps=list(cfg.get("temporal_steps_ladder",[8,16])); out=Path(a.out or f"outputs_holdout_{time.strftime('%Y%m%d_%H%M%S')}"); out.mkdir(parents=True,exist_ok=True)
    runs={}
    plan=[(Ns[0],steps[0],"spatial_low"),(Ns[-1],steps[0],"spatial_high"),(Ns[-1],steps[-1],"temporal_high")]
    for N,st,label in plan:
        c=copy.deepcopy(cfg); c["resample_n"]=int(N); c["n_steps"]=int(st); c.pop("resample_ladder",None); c.pop("temporal_steps_ladder",None)
        cp=out/f"config_{label}_N{N}_S{st}.json"; cp.write_text(json.dumps(c,indent=2),encoding="utf-8"); runs[label]=extract(run_full(cp,a.dataset,out/label,a.force_python,a.skip_build))
    stdS=float(cfg.get("spatial_convergence_standard_tol",0.02)); certS=float(cfg.get("spatial_convergence_certified_tol",0.005)); stdT=float(cfg.get("temporal_convergence_standard_tol",0.01)); certT=float(cfg.get("temporal_convergence_certified_tol",0.002)); rows=[]
    common=sorted(set(runs["spatial_low"]) & set(runs["spatial_high"]) & set(runs["temporal_high"]))
    for p in common:
        sl,sh,th=runs["spatial_low"][p],runs["spatial_high"][p],runs["temporal_high"][p]; sp=rel(sl["response"],sh["response"]); tp=rel(sh["response"],th["response"])
        stier="CERTIFIED_PASS" if sp<=certS else ("STANDARD_PASS" if sp<=stdS else "FAIL"); ttier="CERTIFIED_PASS" if tp<=certT else ("STANDARD_PASS" if tp<=stdT else "FAIL")
        model_ok=sl["status"]==sh["status"]==th["status"]=="PASS"; status="PASS" if model_ok and stier!="FAIL" and ttier!="FAIL" else "FAIL"
        rows.append({"source_path":p,"spatial_relative_change":sp,"spatial_tier":stier,"temporal_relative_change":tp,"temporal_tier":ttier,"model_status_all_runs":model_ok,"status":status})
    overall="PASS" if rows and all(x["status"]=="PASS" for x in rows) else "FAIL"; summary={"overall_holdout_status":overall,"selection_basis":cfg.get("prior_release_selection"),"plan":plan,"holdouts":rows}
    (out/"holdout_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8"); print(json.dumps({"out":str(out),"overall_holdout_status":overall,"holdouts":len(rows)},indent=2)); raise SystemExit(0 if overall=="PASS" else 2)
if __name__=="__main__": main()
