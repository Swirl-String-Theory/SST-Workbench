#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SST chi-phase v8: derive alpha/beta ring-constant relation and compare targets."""
from __future__ import annotations

import argparse
import csv
import os
import sys
import time

import matplotlib.pyplot as plt
import numpy as np

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)


def load_backend(force_python: bool = False):
    if force_python:
        import sst_chi_phase_v8_py as mod
        return mod, "python"
    try:
        from sst_chi_phase_v8_build import import_module
        mod_cpp = import_module(auto_build=True, script_dir=SCRIPT_DIR)
        import sst_chi_phase_v8_py as mod_py
        # attach table helpers from Python module; C++ carries scalar formula checks
        mod_cpp.PHI = mod_py.PHI
        mod_cpp.A0_STAR = mod_py.A0_STAR
        mod_cpp.LEGACY_MODELS = mod_py.LEGACY_MODELS
        mod_cpp.legacy_table_rows = mod_py.legacy_table_rows
        mod_cpp.target_comparison_rows = mod_py.target_comparison_rows
        mod_cpp.alpha_beta_lines = mod_py.alpha_beta_lines
        mod_cpp.derive_summary = mod_py.derive_summary
        return mod_cpp, "cpp"
    except Exception as exc:
        print(f"[!] C++ backend unavailable ({exc}); using Python fallback.")
        import sst_chi_phase_v8_py as mod
        return mod, "python"


def write_csv(path, rows):
    if not rows:
        return
    keys = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--python", action="store_true", help="force pure-Python backend")
    args = parser.parse_args(argv)

    mod, backend = load_backend(force_python=args.python)
    export_dir = os.path.join(SCRIPT_DIR, "exports")
    os.makedirs(export_dir, exist_ok=True)

    print("=" * 84)
    print("SST chi-phase v8 alpha/beta ring-constant derivation audit")
    print("=" * 84)
    print(f"[*] backend = {backend}")
    print("[*] v8 derives beta = alpha - 1 + q from ring Hamiltonian scaling.")
    print("[*] It compares legacy alpha/beta targets against the v6 chi-closure root.")
    print("[*] It does NOT derive absolute alpha from first-principles core dynamics.")

    t0 = time.time()
    summary = mod.derive_summary()
    legacy_rows = mod.legacy_table_rows()
    target_rows = mod.target_comparison_rows()
    line_rows = mod.alpha_beta_lines()

    legacy_csv = os.path.join(export_dir, "chi_v8_legacy_alpha_beta_table.csv")
    targets_csv = os.path.join(export_dir, "chi_v8_target_comparisons.csv")
    lines_csv = os.path.join(export_dir, "chi_v8_alpha_beta_lines.csv")
    write_csv(legacy_csv, legacy_rows)
    write_csv(targets_csv, target_rows)
    write_csv(lines_csv, line_rows)
    print(f"[*] CSV saved: {legacy_csv}")
    print(f"[*] CSV saved: {targets_csv}")
    print(f"[*] CSV saved: {lines_csv}")

    # Plot alpha-beta relation lines and legacy targets.
    alphas = np.array([r["alpha"] for r in line_rows], dtype=float)
    plt.figure(figsize=(10, 6))
    plt.plot(alphas, [r["beta_q0"] for r in line_rows], label=r"$q=0$: $\beta=\alpha-1$")
    plt.plot(alphas, [r["beta_q_minus_half"] for r in line_rows], label=r"$q=-1/2$: $\beta=\alpha-3/2$")
    plt.plot(alphas, [r["beta_q_plus_half"] for r in line_rows], label=r"$q=+1/2$: $\beta=\alpha-1/2$")
    for r in legacy_rows:
        plt.scatter([float(r["alpha"])], [float(r["beta"])])
        plt.text(float(r["alpha"]) + 0.01, float(r["beta"]) + 0.01, str(r["name"]).replace("_", " "), fontsize=8)
    plt.xlabel(r"$\alpha$")
    plt.ylabel(r"$\beta$")
    plt.title(r"Thin-ring Hamiltonian relation: $\beta=\alpha-1+q$")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    ab_plot = os.path.join(export_dir, "chi_v8_alpha_beta_relation.png")
    plt.savefig(ab_plot, dpi=160)
    print(f"[*] Plot saved: {ab_plot}")

    # Plot smooth matched closure curve and target positions.
    a_grid = np.linspace(0.0, 3.0, 801)
    c_grid = np.array([mod.smooth_matched_c_over_v(float(a)) if hasattr(mod, 'smooth_matched_c_over_v') else mod.smooth_c_over_v(float(a)) for a in a_grid])
    plt.figure(figsize=(10, 6))
    plt.plot(a_grid, c_grid, label=r"smooth matched $c_\chi/v_{ref}$")
    plt.axhline(1.0, linestyle="--", label=r"closure target $c/v=1$")
    for label, x in [
        (r"$a_0^*$", float(summary["a0_star_analytic"])),
        (r"$\varphi$", float(summary["phi"])),
        (r"NLS $\alpha=1.61$", 1.61),
        (r"$7/4$", 1.75),
        (r"$2$", 2.0),
    ]:
        plt.axvline(x, linestyle=":")
        plt.text(x + 0.015, 0.88, label, rotation=90, fontsize=9)
    plt.xlabel(r"parameter interpreted as $a_0$ or comparison target")
    plt.ylabel(r"$c_\chi/v_{ref}$")
    plt.title("v8 comparison: v6 closure root vs legacy alpha targets")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    curve_plot = os.path.join(export_dir, "chi_v8_smooth_closure_vs_targets.png")
    plt.savefig(curve_plot, dpi=160)
    print(f"[*] Plot saved: {curve_plot}")

    elapsed = time.time() - t0
    summary_path = os.path.join(export_dir, "chi_v8_run_results_summary.txt")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("SST chi-phase v8 alpha/beta ring-constant derivation audit\n")
        f.write("==========================================================\n")
        f.write(f"backend                                      = {backend}\n")
        f.write("\nDerived relation:\n")
        f.write("E = 1/2 rho Gamma^2 R [ln(8R/a)-alpha]\n")
        f.write("P = rho Gamma pi R^2\n")
        f.write("q = d ln a / d ln R\n")
        f.write("U = dE/dP = Gamma/(4 pi R) [ln(8R/a)-beta]\n")
        f.write("beta = alpha - 1 + q\n\n")
        for k, v in summary.items():
            f.write(f"{k:<45}= {v}\n")
        f.write(f"elapsed                                      = {elapsed:.3f} s\n\n")
        f.write("Legacy models:\n")
        for r in legacy_rows:
            f.write(f"{r['name']:<38} alpha={float(r['alpha']):.12g} beta={float(r['beta']):.12g} q_eff={float(r['q_eff']):.12g}\n")
        f.write("\nInterpretation:\n")
        f.write("v8 derives the alpha-beta constraint relation and confirms that NLS alpha/beta sits on q=0.\n")
        f.write("It does not derive the absolute value alpha=1.61 from SST/NLSE core dynamics.\n")
        f.write("It shows that the v6 closure root a0* is close to, but not equal to, NLS alpha or phi.\n")
    print(f"[*] Summary saved: {summary_path}")

    print("=" * 84)
    print("Summary")
    print("=" * 84)
    for k in ["a0_star_analytic", "a0_star_minus_NLS_alpha", "c_NLS_alpha_over_v", "NLS_q_eff", "NLS_beta_residual_q0", "a0_star_beta_if_q0"]:
        print(f"{k:<45}= {summary[k]}")
    print(f"elapsed                                      = {elapsed:.3f} s")
    print("[*] PASS: v8 alpha/beta relation audit completed.")


if __name__ == "__main__":
    main()
