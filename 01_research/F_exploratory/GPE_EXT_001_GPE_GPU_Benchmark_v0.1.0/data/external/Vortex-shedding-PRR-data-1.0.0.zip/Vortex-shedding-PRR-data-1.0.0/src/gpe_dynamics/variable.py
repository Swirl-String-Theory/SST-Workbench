"""Simulation parameters and derived grids.

Defaults match the production calculations. To override values at runtime, set
the GPE_VARIABLES_JSON environment variable to a JSON file containing a
"variables" object. The public driver scripts do this automatically when a
config file is passed with --config.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import cupy as cp


def _load_overrides() -> dict:
    path = os.environ.get("GPE_VARIABLES_JSON")
    if not path:
        return {}
    config_path = Path(path).expanduser().resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    return dict(config.get("variables", {}))


_OVERRIDES = _load_overrides()


def _get(name: str, default):
    return _OVERRIDES.get(name, default)



# half size of the sample along x direction (width)
# fluid flowing direction is along x 
# xi = hbar/sqrt(m*mu) unit
R_x = int(_get("R_x", 250))
# R_x=600
# half size of the sample along y direction (height)
# xi = hbar/sqrt(m*mu) unit
R_y = int(_get("R_y", 125))
# R_y=500



# the number of pix. along x direction. Namely, pix. num in 2*R_x
# size of one pixel is 2*R_x/Nx (xi)
Nx = int(_get("Nx", 1000))

# the number of pix. along y direction. Namely, pix. num in 2*R_y
# size of one pixel is 2*R_y/Ny (xi)
Ny = int(_get("Ny", 500))
# Ny=1000

obstacle_position = int(_get("obstacle_position", 100))
# obstacle_position = 500
t_ = float(_get("t_", 10000.0))

acceleration_time = float(_get("acceleration_time", 0.1))

dt = float(_get("dt", 0.01))

tau_ = float(_get("tau_", 1000.0))
 
dtau = float(_get("dtau", 0.04))

epsilon = float(_get("epsilon", Nx * Ny * 10e-10))


wx = int(_get("wx", 50))
wy = int(_get("wy", 40))

gamma0 = float(_get("gamma0", 0.1))
# gamma0=0.0
Wx1, Wx2 = R_x-wx, -(R_x-wx)
Wy1, Wy2 = R_y-wy, -(R_y-wy)

d = int(_get("d", 3))

## ramp down time in exp_protocol
ramp_down_t = float(_get("ramp_down_t", 1000.0))



##############################################################################################
# Not important in 2d homogeneous case

# Trapping freqeuncy of transverse direction x,y
w = float(_get("w", 2 * np.pi * 9))

# Trapping frequency of tightly bound direction z
w_z = float(_get("w_z", 2 * np.pi * 400))

# thickness of sample alogn z direction 
# xi = hbar/sqrt(m*mu) unit
R_z = float(_get("R_z", 10))


#############################################################################################
#physics quantites

k_B = float(_get("k_B", 1.38e-23))
hbar = float(_get("hbar", 6.626e-34 / 2 / np.pi))
m = float(_get("m", 22.98977 * 1.67e-27))
T = float(_get("T", 4.959835621642327e-8))
mu = k_B*T
xi = hbar/np.sqrt(m*mu)
a0 = float(_get("a0", 0.529e-10))
a_s = float(_get("a_s", 54.54 * a0))
g = 4*np.pi*hbar**2*a_s/m





# derivative variables


''' Trapping frequency '''
l = 2*R_z
xmax, ymax = R_x, R_y
Omega = hbar/(2*m*xi**2)

''' time '''
t_ += acceleration_time
Nt = int(t_//dt)

''' imaginary time '''
Ntau = int(tau_//dtau)
tau = np.arange(0, tau_, dtau)

''' spatial domain '''
dx, dy = 2*xmax/Nx, 2*ymax/Ny
P, Q = 1/dy**2, 1/dx**2

x = np.arange(-xmax, xmax, dx)
y = np.arange(-ymax, ymax, dy)
t = np.arange(0, t_, dt)
xx,yy = np.meshgrid(x,y)


''' spatial domain as cupy array'''
x_gpu = cp.array(x).astype("float32")
y_gpu = cp.array(y).astype("float32")
xx_gpu, yy_gpu = cp.meshgrid(x_gpu, y_gpu)

