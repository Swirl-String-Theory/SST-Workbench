@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo [2/7] Build C++17 / pybind11 native backend
echo ============================================================
call .venv\Scripts\activate.bat

python setup.py build_ext --inplace
if errorlevel 1 (
  echo.
  echo ERROR: native build failed.
  echo.
  echo Possible causes include:
  echo   - setuptools package-discovery/configuration error
  echo   - missing or incompatible C++ compiler/build tools
  echo   - pybind11/compiler configuration error
  echo.
  echo Review the build output ABOVE for the actual cause.
  echo If the error mentions "Multiple top-level packages discovered",
  echo verify that setup.py uses explicit package discovery, e.g.:
  echo   packages=find_packages(include=["sst_qgi", "sst_qgi.*"])
  echo.
  exit /b 1
)

python -c "import sst_qgi_native; print('native backend: cpp-pybind11')"
if errorlevel 1 (
  echo ERROR: native extension was built but could not be imported.
  exit /b 1
)

endlocal
