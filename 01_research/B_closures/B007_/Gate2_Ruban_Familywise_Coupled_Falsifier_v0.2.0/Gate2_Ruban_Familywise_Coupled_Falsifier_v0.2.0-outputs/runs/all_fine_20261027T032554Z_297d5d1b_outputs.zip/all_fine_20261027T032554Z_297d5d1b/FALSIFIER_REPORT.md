# Gate2 Ruban Familywise Coupled Falsifier v0.2.0

Scientific conclusion: **G2_UNRESOLVED_NO_CERTIFIED_EQUILIBRIUM**.

## What this run tested
- Families: ['T_2_3', 'T_3_2', 'T_2_5', 'T_2_7', 'T_3_4', 'T_3_5', 'T_3_7', 'T_4_3', 'T_4_5', 'T_5_2', 'T_5_3', 'T_5_4', 'T_2_9', 'T_2_11', 'T_2_13', 'T_2_15', 'T_3_8', 'T_3_10', 'T_4_7', 'T_4_9', 'T_5_6', 'T_5_7', 'T_6_7', 'T_7_2', 'T_3_3', 'T_3_6', 'T_3_9', 'T_6_15', 'T_6_21', 'T_6_9']
- B0: [0.02, 0.0225, 0.025, 0.0275, 0.03, 0.0325, 0.035, 0.0375, 0.04, 0.0425, 0.045, 0.0475, 0.05, 0.0525, 0.055, 0.0575, 0.06, 0.0625, 0.065, 0.0675, 0.07, 0.0725, 0.075, 0.0775, 0.08, 0.0825, 0.085, 0.0875, 0.09, 0.0925, 0.095, 0.0975, 0.1, 0.1025, 0.105, 0.1075, 0.11, 0.1125, 0.115, 0.1175, 0.12, 0.1225, 0.125, 0.1275, 0.13, 0.1325, 0.135, 0.1375, 0.14, 0.1425, 0.145, 0.1475, 0.15, 0.1525, 0.155, 0.1575, 0.16, 0.1625, 0.165, 0.1675, 0.17, 0.1725, 0.175, 0.1775, 0.18, 0.1825, 0.185, 0.1875, 0.19, 0.1925, 0.195, 0.1975, 0.2, 0.2025, 0.205, 0.2075, 0.21, 0.2125, 0.215, 0.2175, 0.22, 0.2225, 0.225, 0.2275, 0.23, 0.2325, 0.235, 0.2375, 0.24, 0.2425, 0.245, 0.2475, 0.25, 0.2525, 0.255, 0.2575, 0.26, 0.2625, 0.265, 0.2675, 0.27, 0.2725, 0.275, 0.2775, 0.28, 0.2825, 0.285, 0.2875, 0.29, 0.2925, 0.295, 0.2975, 0.3, 0.3025, 0.305, 0.3075, 0.31, 0.3125, 0.315, 0.3175, 0.32]
- Lambda: [3.4, 4.0, 5.0, 6.0, 7.0]
- Paired reduced-filament scenarios: 36300
- G3 promoted resolutions: 2048,4096
- G4 coupled Euler pilot runs: 0

## Gate statuses
- G1: PASS_ANALYTIC_GEOMETRY_SCREEN_ONLY
- G2: PASS_REDUCED_SCREEN_EXECUTED_RESOLUTION_LIMITED
- G3: RANKING_PROVISIONAL_NUMERICAL_CONVERGENCE_UNRESOLVED
- G4: NOT_RUN_USER_DISABLED

## Physical interpretation
This pipeline screens analytic torus seed families. It neither solves a fully deformable stationary Euler boundary-value problem nor proves nonlinear stability. The 3D Euler pilot is a finite periodic Gaussian-mollified vortex field with back-reaction, not a continuum equilibrium certificate.
Averaging or long survival under a reduced filament model is not a vanishing Euler residual.
Frozen-parameter convergence of the full-component Euler residual and topology-preserving material simulation are required before G2 PASS.

## Selected seeds
- T_3_9 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.512897
- T_3_6 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.546276
- T_3_10 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.592536
- T_3_3 B0=0.32000, Lambda=4.00; N=[2048, 4096]; score=0.601362
- T_3_8 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.601785
- T_3_7 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.608851
- T_3_5 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.630242
- T_3_4 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.644624
- T_3_2 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.674379
- T_4_9 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.687856
- T_4_7 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.705081
- T_4_5 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.724018
- T_4_3 B0=0.32000, Lambda=7.00; N=[2048, 4096]; score=0.741438
- T_5_7 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.754271
- T_2_3 B0=0.13250, Lambda=3.40; N=[2048, 4096]; score=0.757531
- T_5_6 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.761362
- T_5_4 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.77417
- T_5_3 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.779327
- T_5_2 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.783228
- T_6_7 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.783534
- T_7_2 B0=0.32000, Lambda=3.40; N=[2048, 4096]; score=0.818161
- T_2_5 B0=0.07750, Lambda=3.40; N=[2048, 4096]; score=0.876473
- T_6_9 B0=0.13250, Lambda=3.40; N=[2048, 4096]; score=0.902276
- T_2_7 B0=0.05500, Lambda=3.40; N=[2048, 4096]; score=0.925686
- T_2_9 B0=0.04250, Lambda=3.40; N=[2048, 4096]; score=0.9515
- T_6_15 B0=0.07750, Lambda=3.40; N=[2048, 4096]; score=0.954834
- T_2_11 B0=0.03500, Lambda=3.40; N=[2048, 4096]; score=0.965291
- T_2_13 B0=0.03000, Lambda=3.40; N=[2048, 4096]; score=0.973049
- T_6_21 B0=0.05500, Lambda=3.40; N=[2048, 4096]; score=0.977304
- T_2_15 B0=0.02500, Lambda=3.40; N=[2048, 4096]; score=0.980157

## Provenance
- E010 v0.3.6 generator SHA-256: 2c73d35fd58c9f4bcb4ddbb336021883d0bdff44051105750a68fa0fc6a0c609
- E010 v0.3.6 config SHA-256: c7b29996e665296a99c376be044c66eb0ebefe31ecd516a3e53e9b908679890d
KnotPlot labels for six links are metadata only; corresponding curves were analytically generated, not imported.
