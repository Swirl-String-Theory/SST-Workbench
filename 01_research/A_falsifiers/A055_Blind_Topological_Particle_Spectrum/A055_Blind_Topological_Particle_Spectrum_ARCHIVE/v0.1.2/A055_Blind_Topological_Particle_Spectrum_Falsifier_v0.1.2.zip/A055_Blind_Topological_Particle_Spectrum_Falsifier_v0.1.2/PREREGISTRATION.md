# PREREGISTRATION — A055 v0.1.2

## Frozen population and blindness

The population remains all 35 non-trivial prime knots through 8 crossings and all 47 prime links through 8 crossings. Historical SST/VAM mappings and SM data are reveal-only.

## PD realization

v0.1.2 fixes the v0.1.1 random-routing defect.  The PD diagram is interpreted as a planar rotation system.  Crossing nodes and subdividing edge-label nodes are embedded planarly; only registered crossing pairs receive opposite z offsets.  Replicates may vary local crossing height, port radius and periodic smoothing width, but may not change the planar routing.

Before final arclength sampling, every closed component is periodically Fourier-smoothed.  The construction is a screening geometry, not PKLSA or an Euler equilibrium.

## Resolution/presentation qualification

Normal runs use N=40,80,160 and the existing per-feature convergence/CV gates.  `basic` uses 8 embeddings; `full` uses 16.  A feature must satisfy both the registered resolution-relative tolerance and embedding-CV tolerance.

## Fixed-arclength contact gate

The contact observable is the minimum Euclidean distance between finite line segments subject, on the same component, to

\[
d_{\rm arc}(s_i,s_j) \ge 0.08 L_{\rm component}.
\]

The exclusion is therefore independent of N. `contact_ratio` remains diagnostic only.

## Gauss linking gate

For distinct components, v0.1.2 evaluates the Gauss integral without finite-core regularization:

\[
Lk(C_i,C_j)=\frac{1}{4\pi}\oint_{C_i}\oint_{C_j}
\frac{(d\mathbf r_i\times d\mathbf r_j)\cdot(\mathbf r_i-\mathbf r_j)}{\|\mathbf r_i-\mathbf r_j\|^3}.
\]

`linking_strength` is allowed only for links and must also have mean integer residual <= the configured calibration tolerance.  The selftest must recover, in absolute value, within 0.02:

- Hopf link `L2a1`: [1];
- Solomon link `L4a1`: [2];
- Borromean link `L6a4`: [0,0,0].

The regularized Neumann-energy proxy remains a separate geometric/dynamical screening observable and retains the configured core radius.

## Ratio/effect-size gate

The existing one-scale log-space fit is retained.  In addition to null significance, a highlighted match must satisfy

\[
\epsilon_{\log}\le 0.25.
\]

This is an effect-size gate; p-value and effect size are reported separately.

## Global look-elsewhere correction

Raw log-RMS values from particle groups with different total log-mass spans are not compared globally.  Each group's all-valid-domains familywise observed statistic is first mapped to its empirical familywise null p-value.  The global statistic is

\[
T_{\rm global}=\min_g p_g.
\]

Each synchronized null trial is transformed through the corresponding group's own familywise empirical CDF, then the minimum p-value is taken.  The final global p-value is the fraction of null minima no larger than the observed minimum.

## Interpretation boundary

v0.1.2 may validate or reject the numerical/topological screening layer. It cannot establish a particle identity, Higgs identification, or SST dynamical closure. Promotion to v0.2.0 requires PKLSA/finite-core/Hessian/Kelvin/Floquet observables while preserving this blind/reveal/statistical discipline.
