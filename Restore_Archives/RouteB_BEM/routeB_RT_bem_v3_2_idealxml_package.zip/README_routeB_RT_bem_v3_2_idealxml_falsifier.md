# Route B BEM v3.2 — direct support for Brian Gilbert `ideal.txt`

This version works directly with the uploaded XML/Fourier ideal-knot database:

```xml
<AB Id="3:1:1" Conway="3" L="16.371637" D="1.000000">
  <Coeff I="1" A="..." B="..." />
</AB>
```

It evaluates each Fourier block as

```tex
x(t)=\sum_I A_I\cos(It)+B_I\sin(It),\qquad t\in[0,2\pi).
```

## List blocks in your uploaded file

```bash
python routeB_RT_bem_v3_2_idealxml_falsifier.py --source file --ideal ideal.txt --list-ideal-xml-knots --sstcore-max-knots 30
```

## Run a small set from this file

The uploaded database starts at 3 crossings, so it does not contain `0:1:1`. Use IDs that exist in the file:

```bash
python routeB_RT_bem_v3_2_idealxml_falsifier.py \
  --source file \
  --ideal ideal.txt \
  --ideal-xml-knot-ids 3:1:1,4:1:1,5:1:1 \
  --outdir outputs_routeB_idealxml_fast \
  --n-center 10 --n-theta 3 --n-sphere 18 --modes 6 \
  --center-resolution-list 8,10,12 \
  --n-invariance-trials 1
```

## Run first N single-component blocks

```bash
python routeB_RT_bem_v3_2_idealxml_falsifier.py \
  --source file \
  --ideal ideal.txt \
  --ideal-xml-knot-ids all \
  --sstcore-max-knots 20 \
  --outdir outputs_routeB_idealxml_all20
```

## Provenance output

The script writes the exact sampled coordinates used by BEM to:

```text
<outdir>/idealxml_sampled_ideal_used.txt
```

Passing gates does not derive alpha; this is only a Route-B falsifier harness.
