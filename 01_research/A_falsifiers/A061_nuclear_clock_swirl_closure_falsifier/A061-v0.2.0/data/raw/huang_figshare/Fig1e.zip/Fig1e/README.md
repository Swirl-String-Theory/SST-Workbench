# Figure 1e

This directory contains the data and Python script used to generate Figure 1e.

## Data

`data/fig1e_12kmod.csv` contains three columns:

| Column | Description |
| --- | --- |
| `Frequency_offset_kHz` | Frequency offset (kHz) |
| `Normalized_signal` | Normalized signal |
| `Normalized_signal_error` | Vertical error bar |

Signal and error are multiplied by the same factor so that the maximum absolute
signal is 0.9. No additive offset is applied.
Frequency offsets are reported to 0.001 kHz; signal and error retain nine
significant digits.

## Plot

Run from the parent directory:

```powershell
python Fig1e/code/fig1e_plot.py
```

The script requires `pandas` and `matplotlib`. Output files are saved as `results/fig1e.png` and `results/fig1e.pdf`.
