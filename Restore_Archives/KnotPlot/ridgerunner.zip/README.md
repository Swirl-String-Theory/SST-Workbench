# Ridgerunner (portable, next to knotplotrc.kps)

This folder is a self-contained Windows bundle for tightening KnotPlot XYZ
`.txt` centerlines with ridgerunner.

## One-time setup

```powershell
cd <this-folder>
powershell -ExecutionPolicy Bypass -File .\install-user-path.ps1
```

Needs Python 3 on PATH for `.txt` runs.

## Help

```bat
ridgerunner --help
```

Shows **wrapper** options (checkpoints, `--label`, `--verbose`, `--full-output`, …).
For native ridgerunner flags (`-c`, `--EqForceOn`, `--StopResidual`, …):

```bat
bin\ridgerunner.exe -h
```

## Usage

```bat
ridgerunner -a -s 1000 C:\pad\naar\knotplot.txt
```

- **New seed:** `-a` (autoscale to thickness 0.501).
- **Continue** from a previous RR XYZ output: `-c` (no rescaling).

During a `.txt` run the wrapper shows an ASCII progress bar with live elapsed
time (`t=12m34s`). Use `--verbose` for classic per-step `Rop:` lines plus a
timer heartbeat every ~30s. At the end of each stage (and on Ctrl+C) a **Stage
summary** prints wall time, last Rop/Thi/residual/struts. `run_ideal_knot` /
`run_catalog_knot` also print a **Campaign summary** with total elapsed.

Checkpoint tag comes from `-s` / `--StopSteps`:

| `-s` | tag | main outputs next to the input |
|------|-----|--------------------------------|
| 1000 | `001k` | `knotplot_rr_001k.txt`, `.metrics.json`, `.vect`, `.rr\` |
| 5000 | `005k` | `knotplot_rr_005k.txt`, … |
| 10000 | `010k` | `knotplot_rr_010k.txt`, … |
| 20 | `s20` | `knotplot_rr_s20.txt`, … |

Optional `--label NAME` appends `_{NAME}` so parallel runs do not overwrite:

```bat
ridgerunner -c -s 10000 --label plain prev_rr_005k.txt
→ prev_rr_005k_rr_010k_plain.txt
```

### Equilateralization

| Flag | When it matters |
|------|-----------------|
| `--EqOn` | Occasional eq when max/min edge **> 3** |
| `--EqForceOn` | Continuous equilateralization force (can interfere with stepper) |

### Recommended workflow (3-stage pipeline)

Do **not** start with a single huge `--EqForceOn` run on a fresh KnotPlot
seed. Prefer:

1. **coarse** — new seed, pure tightening (`--EqOn` only as emergency edge fix)
2. **eqfinal** — restore vertex spacing with `--EqForceOn`, drive residual to 0.01
3. **polish** — short unbiased run without continuous EqForce

Primary seed is chosen by the checkpoint gate (not blindly 5k/10k/15k).

```bat
rem Stage 1
ridgerunner -a --EqOn -s 10000 --StopResidual=0.05 --label coarse "seed.txt"

rem Stage 2
ridgerunner -c --EqForceOn -s 50000 --StopResidual=0.005 --Stop20=0.000001 --label eqfinal "seed_rr_010k_coarse.txt"

rem Stage 3
ridgerunner -c --EqOn -s 30000 --StopResidual=0.005 --Stop20=0.0000001 --label polish "…_eqfinal.txt"
```

Or: `ridgerunner\run_three_stage.cmd path\to\seed.txt`

The **polish** output is the near-ideal candidate; keep eqfinal as checkpoint.

### KnotPlot build + seed gate (`run_build.cmd`)

```bat
cd C:\workspace\projects\SST-Workbench\KnotPlot

rem KnotPlot only: 15k checkpoints, log + *.knotplot.json sidecars
run_build.cmd torus_6.9

rem Auto-select one trial seed, then 3-stage ridgerunner
run_build.cmd torus_6.9 -rr

rem Overrides
run_build.cmd knot_3.1 -rr --seed trial_009k
run_build.cmd knot_3.1 -rr --multistart
run_build.cmd knot_4.1 -rr --allow-unverified-topology
```

`-rr` does **not** pipeline every TXT. It runs `select_knotplot_seed.py`
(after `parse_knotplot_log.py`) and sends **one** seed to `run_three_stage.cmd`.
After polish, stage 4 writes a **separate** VortexLab copy via
`resample_closed_knot_txt.py --points 300` → `*_polish_uniform_N300.txt`
(+ VECT). Then `classify_catalog_status.py` writes `catalog_status.json` and
`build_knotplot_knots_data.py --from-rr-outdir` upserts that uniform file into
`knotplot_knots_data.js`. The Ridgerunner `*_polish.txt` is left untouched.

Catalog statuses: `relaxed-seed` → `near-ideal-candidate` → `near-ideal`
(optional `run_build … -rr --certify` for multi-start + N600/N1200).
`certified-ideal` is never automatic. See `KNOTPLOT_KNOTS_DATA_README.md`.

**Robuuste checkpoint-gate (summary):**

- Plateau on **`R_proxy = L/D_proxy`** deltas (`|ΔR/R| < 0.001` after the local min) → status `settled-after-local-minimum`; earliest 0.1%-tie only among candidates at/after that min. No plateau → pure min `R_proxy` (`best-so-far-no-plateau`); **no** earliest-tie without settle. Same path for `knot_*` / `torus_*` / `link_*`.
- Signed length gain is logged for diagnostics only (KnotPlot length often grows).
- Per-component flatness `√(λ3/λ1)`; 5% drop = soft penalty; ~20–25% + worse `D_proxy`/`R_proxy` = hard DQ
- `D_proxy = min(2·MinRad, d_self_nonlocal, d_inter)` from **segment–segment** distances (arc-length exclusion window)
- Rank by class A/B/C then lowest `R_proxy`
- Topology (`knot_*` / `torus_*` / `link_*`): 1-comp prefers **`knot_type`** from folder (`knot_X.Y` / `torus_p.q`); `link_*` prefers **`link_type`** from folder (then `linking_matrix`). If the primary field is missing, consistent non-empty **`dowker_code`** across checkpoints verifies. Hard fail if both are absent.
- No settle by 15k → `best-so-far-no-plateau` warning, still may RR

Check `*.metrics.json` after eqfinal/polish: residual ≤ 0.01, prefer
`edge_length_ratio` ≤ 1.10 and `edge_length_cv` ≤ 0.01.

### Quick single checkpoints (trefoil)

```bat
ridgerunner -a -s 1000 C:\workspace\projects\SST-Workbench\KnotPlot\knots\knot_3.1\T_2_3_trial_005k.txt
ridgerunner -a -s 5000 C:\workspace\projects\SST-Workbench\KnotPlot\knots\knot_3.1\T_2_3_trial_005k.txt
```

### Metrics

Each checkpoint writes JSON with length, thickness, ropelength, residual,
**strutcount** (contact struts, from `.final.struts` / `strutcount.dat` col 2 — not MRstruts),
edge_length_variance, **edge_length_min/max/ratio/mean/cv** (from
final XYZ), **mr_struts** (separate), flatness, component sizes, and paths.

### Multilink without blank-line separators

```bat
ridgerunner -a -s 1000 --component-count 3 link_900verts.txt
ridgerunner -a -s 1000 --component-size 300 link_900verts.txt
```

### Full ridgerunner file output

```bat
ridgerunner --full-output -a -s 1000 knot.txt
```

(`--keep-vectfiles` is a deprecated alias for `--full-output`.)

Plain VECT files still go straight to the native exe (no checkpoint renaming):

```bat
ridgerunner -a -s 1000 knot.vect
```

### Gilbert ideal AB (`run_ideal_knot`)

Parallel path that starts from Brian Gilbert Fourier coeffs in
`SST-Workbench\knots_ideal_favorites.txt` (not KnotPlot `load 3.1`). Does
**not** change `run_build.cmd -rr`.

| Role | Value | Convention |
|------|------:|------------|
| Gilbert seed `L` | 16.371637 | diameter `D=1` |
| Acceptance target `L_3_1` | 16.357467488 | diameter `D=1` |
| Target ropelength (RR) | ≈ 32.714934976 | radius units (`2 × L`) |

```bat
cd C:\workspace\projects\SST-Workbench\KnotPlot\ridgerunner

rem Sample AB 3:1:1 → N=300 three-stage → N=600/N=1200 ladder
run_ideal_knot.cmd --3:1:1

rem N=300 only (alias also: run_gilbert_three_stage.cmd)
run_ideal_knot.cmd --3:1:1 --resolutions 300

rem Full per-step Rop lines (passed through to ridgerunner)
run_ideal_knot.cmd --3:1:1 --verbose

rem Resume: skip stages whose checkpoint TXT already exists
run_ideal_knot.cmd --3:1:1

rem Fresh unique run directory (does not overwrite prior out\3_1_1\t1\ files)
run_ideal_knot.cmd --3:1:1 --fresh
run_ideal_knot.cmd --3:1:1 --fresh --run-id try2

rem Force re-run even when checkpoints exist
run_ideal_knot.cmd --3:1:1 --force

rem Multithread binary + native --Threads=N; auto outdir t8\
run_ideal_knot.cmd --3:1:1 -t8
run_ideal_knot.cmd --3:1:1 --threads=8 --run-id MyMT

rem Full ladder through N=4800
run_ideal_knot.cmd --3:1:1 -r3,6,12,24,48 -t8
```

Default outputs under `out\3_1_1\t1\` (stock `ridgerunner.exe`; older flat
`out\3_1_1\` / `out\i3_1_1\` are not auto-migrated). Re-runs **resume** by
skipping finished stages. Use `--fresh` for `out\3_1_1\rYYYYMMDD_HHMMSS\`
(or `r_<id>\`) so prior results stay untouched. With `--threads=N`, results
go under `tN\` (or `r_<run-id>\`) using `bin\ridgerunner_multithread.exe`
and native `--Threads=N`. After each polish level the driver reports
`L_diam` vs `16.357467488`.

**Short naming** (keeps Windows paths under MAX_PATH):

| Role | Path |
|------|------|
| Campaign base | `out/3_1_1/` |
| Single-thread run | `out/3_1_1/t1/` |
| Threads run | `out/3_1_1/t8/` |
| Seed | `n300.txt` |
| N300 stages | `n300c.txt` → `n300e.txt` → `n300p.txt` (+ `p300.txt`) |
| Ladder N600 | `u600.txt` → `n600c.txt` → `n600e.txt` → `n600p.txt` (+ `p600.txt`) |
| Ladder N1200+ | `u{N}.txt` → `n{N}c` → **`n{N}s`** → `n{N}e` → `n{N}p` (+ `p{N}`) for N=1200/2400/4800 |
| LA recover seed | `n{N}r.txt` |

RR one-shot files use labels `c` / `e` / `p` (e.g. `n300c_rr_050k_e.rr`).
Old long stacked names under `out/ideal_*` / `run_threadsN` are not resume
targets.

**Ropelength display:** `Rop = L / Thi`. Small step-to-step Rop zigzags are
normal when thickness and length both move; the polygonal length often still
decreases. A large Rop jump after `Max edgelength/min edgelength > 3` is the
`--EqOn` rediscretization restart — usually a symptom of bad parameterization.

**Resolution ladder:** Default stops at N=1200. Full chain:
N=600 ← `p300`; N=1200 ← `p600`; N=2400 ← `p1200`; N=4800 ← `p2400`.
Request with `--resolutions 300,600,1200,2400,4800` or `-r3,6,12,24,48`.
Ladder upsamples use **`spline_repair`** (`resample_closed_knot_txt.py
--method auto`): periodic cubic spline followed by iterative Rawdon-MinRad
restore so discrete Rop stays within `|ΔRop/R| < 1e-3` of the source (bare
spline alone often drops thickness ~3% on tight knots; midpoint `subdivide`
halves MinRad and roughly doubles Rop). Strict gates: edge-ratio, length,
minrad, and Rop. Sidecars from older bare **spline** / **subdivide** transfers
are treated as stale and rebuilt by the ladder / `run_ideal_knot` /
`run_catalog_knot` without requiring `--force` on earlier rungs.

**N≥1200 contact avalanche / stabilize:** After a bad (legacy spline) upsample the first
coarse pass (`-a --EqOn`, `StopResidual=0.1`) often hits a sudden strut flood
(`Str: 0` → 1000+) and repeated:

```text
tsnnls: Fallback tried all solvers without success.
resolve_force: Linear algebra failure. Returning control to stepper.
```

That is a local NNLS/rigidity failure, not necessarily a dead run — Rop can
still fall while thickness stays above overstep. Treat coarse as a
**contact-rebuild seed**, not certified criticality. The ladder then runs
**stabilize** before eqfinal:

```text
-a  -s 50000  --StopResidual=0.01  --label s   (no --EqOn)
```

OpenMP threads for stabilize default to 8 and are capped at 12 even if the
parent passed `--Threads=16`. `count_rr_la_failures.py` prints a gate after
stabilize (`failures/steps`): `<0.01` OK, `>0.1` warning, `≥0.5` fatal (blocks
eqfinal). Coarse itself is not gated fatally.

| Role | Path |
|------|------|
| Ladder N≥1200 | `u{N}` → `n{N}c` → **`n{N}s`** → `n{N}e` → `n{N}p` |

### Catalog knots (`run_catalog_knot`)

Same three_stage → ladder pipeline as `run_ideal_knot`, but seeds from
KnotPlot trial TXT or KnotPlot Fourier `.fseries` (not Gilbert AB). Does
**not** change `run_build.cmd -rr`.

**Id / outdir convention**

| Source | Id | Outdir example | Flag |
|--------|----|----------------|------|
| Ideal (Gilbert) | `3_1_1` | `out/3_1_1/t1/` | `--3:1:1` |
| KnotPlot knot | `K3.1` | `out/K3.1/g1k/t1/` | `--knot3.1` |
| KnotPlot torus | `T2.3` | `out/T2.3/g1k/t1/` | `--torus2.3` |
| KnotPlot link | `L6.3.3` | `out/L6.3.3/g1k/t1/` | `--link6.3.3` |
| Fourier fseries | `3_1` / `3_1p` | `out/3_1/t1/` / `out/3_1p/t1/` | `--3_1` / `--3_1p` |

KnotPlot `--go` defaults to `1k` → `trial_001k.txt` and subdir `g1k`.
`--go` is invalid with fseries flags.

```bat
cd C:\workspace\projects\SST-Workbench\KnotPlot\ridgerunner

run_catalog_knot.cmd --knot3.1
run_catalog_knot.cmd --link6.3.3 -v -t8
run_catalog_knot.cmd --torus2.3 --fresh
run_catalog_knot.cmd --knot3.1 --go 2k
run_catalog_knot.cmd --3_1
run_catalog_knot.cmd --3_1p -r3
run_catalog_knot.cmd --3_1u -t8
run_catalog_knot.cmd --knot3.1 -r3,6,12,24,48 -t8
```

Unit tests:

```bat
python -m unittest test_gilbert_ab_to_xyz.py test_run_ideal_knot.py test_run_catalog_knot.py test_run_knotplot_txt.py test_fseries_to_xyz.py test_recover_ladder_coarse.py test_resample_closed_knot_txt.py test_count_rr_la_failures.py -v
```

## Layout

| Path | Role |
|------|------|
| `ridgerunner.cmd` | Entry point (put this folder on PATH) |
| `run_three_stage.cmd` | coarse → eqfinal → polish for one seed TXT |
| `run_resolution_ladder.cmd` | N=600..4800 (`--to=N`; stabilize for N≥1200) |
| `count_rr_la_failures.py` | LA-failure gates + stabilize thread cap |
| `run_ideal_knot.cmd` / `.py` | Gilbert AB sample + multi-resolution RR |
| `run_catalog_knot.cmd` / `.py` | KnotPlot trial / fseries → multi-resolution RR |
| `fseries_to_xyz.py` | KnotPlot Fourier `.fseries` → XYZ |
| `run_gilbert_three_stage.cmd` | N=300-only alias for `run_ideal_knot` |
| `gilbert_ab_to_xyz.py` | Gilbert Fourier → XYZ + target compare |
| `select_knotplot_seed.py` | checkpoint gate → one trial seed |
| `parse_knotplot_log.py` | KnotPlot log → `*.knotplot.json` sidecars |
| `run_knotplot_txt.py` | txt → VECT → ridgerunner → `{stem}_rr_{tag}[_{label}].*` |
| `out\3_1_1\` / `out\K3.1\` / `out\3_1\` | Campaign outputs (not in compile repo) |
| `bin\ridgerunner.exe` | Native binary + MinGW DLLs |
| `bin\ridgerunner_multithread.exe` | Same binary; used via `--threads=N` |
| `bin\*.dll` | OpenBLAS / GSL / runtime deps |

Do not place `ridgerunner.cmd` inside `bin\` next to the `.exe` — Windows
prefers `.exe` over `.cmd` in the same directory.

## Command reference

Copy-paste lookup for campaign drivers. Paths are relative to
`KnotPlot\ridgerunner` unless noted.

### Quick start

```bat
cd C:\workspace\projects\SST-Workbench\KnotPlot\ridgerunner

rem Ideal Gilbert AB (default ladder to N=1200, out\3_1_1\t1\)
run_ideal_knot.cmd --3:1:1

rem Full ladder + 8 OpenMP threads
run_ideal_knot.cmd --3:1:1 -r3,6,12,24,48 -t8

rem KnotPlot trial / Fourier catalog
run_catalog_knot.cmd --knot3.1
run_catalog_knot.cmd --3_1p -r3,6,12 -t8
```

### Shared driver options

| Flag | Short | Meaning |
|------|-------|---------|
| `--resolutions LIST` | `-r3,6,12,24,48` | Resolutions from `{300,600,1200,2400,4800}`. Short codes: `3→300`, `6→600`, `12→1200`, `24→2400`, `48→4800`. Default `300,600,1200`. Higher N auto-fills intermediates. |
| `--threads=N` | `-t8` | Use `bin\ridgerunner_multithread.exe` + native `--Threads=N`; outdir `tN\`. Without this: stock `ridgerunner.exe`, outdir `t1\`. |
| `--verbose` | `-v` | Full per-step Rop lines. |
| `--fresh` | | New `rYYYYMMDD_HHMMSS\` (or `r_<id>\` with `--run-id`) under campaign base. |
| `--run-id NAME` | | Subdir `r_NAME\` instead of timestamp / `tN`. |
| `--force` | | Re-run stages even when checkpoints exist. |
| `--outdir PATH` | | Explicit outdir (no auto `t1`/`tN`). |
| `--points N` | | Seed sample count / `n{N}.txt` (default 300). |

**Outdir matrix** (under campaign base, e.g. `out\3_1_1\` or `out\K3.1\g1k\`):

| Invocation | Outdir |
|------------|--------|
| default | `t1\` (stock exe) |
| `--threads=8` / `-t8` | `t8\` (multithread exe) |
| `--fresh` / `--run-id` | `r…\` (sibling of `tN`) |
| `--outdir PATH` | `PATH` as-is |

### `run_ideal_knot.cmd`

| Flag | Meaning |
|------|---------|
| `--3:1:1` / `--id X:Y:Z` | Gilbert AB id (default `3:1:1`) |
| `--ideal PATH` | Override `knots_ideal_favorites.txt` |
| `--rel-tol FLOAT` | Relative tolerance vs `L_3_1` target (default `1e-4`) |
| *(shared)* | `--resolutions`/`-r`, `--threads`/`-t`, `-v`, `--fresh`, `--run-id`, `--force`, `--outdir`, `--points` |

```bat
run_ideal_knot.cmd --3:1:1
run_ideal_knot.cmd --3:1:1 -r3
run_ideal_knot.cmd --3:1:1 -r3,6,12,24,48 -t8
run_ideal_knot.cmd --3:1:1 --resolutions 300,600,1200,2400,4800 --threads=8
run_ideal_knot.cmd --3:1:1 --fresh --run-id try2
run_ideal_knot.cmd --3:1:1 --force -v
```

### `run_catalog_knot.cmd`

| Flag | Meaning |
|------|---------|
| `--knotX.Y` / `--linkX.Y.Z` / `--torusX.Y` | KnotPlot trial seed (`--go` default `1k` → `trial_001k.txt`) |
| `--go TAG` | Trial tag (`1k`→`001k`); KnotPlot mode only |
| `--3_1` / `--3_1p` / `--3_1u` / `--4_1` … | Fourier `.fseries` stem |
| `--knots-root` / `--fseries-root` | Override catalog roots |
| *(shared)* | same as ideal (`-r`, `-t`, `-v`, …) |

```bat
run_catalog_knot.cmd --knot3.1
run_catalog_knot.cmd --link6.3.3 -v -t8
run_catalog_knot.cmd --torus2.3 --go 2k --fresh
run_catalog_knot.cmd --3_1
run_catalog_knot.cmd --3_1p -r3
run_catalog_knot.cmd --knot3.1 -r3,6,12,24,48 -t8
```

Outdirs: `out\K3.1\g1k\t1\`, `out\L6.3.3\g1k\t8\`, `out\3_1\t1\`, …

### `run_resolution_ladder.cmd`

Direct ladder from an existing N=300 polish (`p300.txt` / `n300p.txt`):

```bat
run_resolution_ladder.cmd path\to\p300.txt
run_resolution_ladder.cmd path\to\p300.txt --to=4800 --verbose --Threads=8
run_resolution_ladder.cmd path\to\p300.txt --to=600 --force
```

| Flag | Meaning |
|------|---------|
| `--to=N` | Stop at `600` / `1200` (default) / `2400` / `4800` |
| `--verbose` / `-v` | Pass through to ridgerunner |
| `--force` | Re-run existing checkpoints |
| `--Threads=N` | Native OpenMP (stabilize capped at 12) |

### `run_three_stage.cmd`

```bat
run_three_stage.cmd path\to\n300.txt
run_three_stage.cmd path\to\n300.txt --verbose --force --Threads=8
```

Stages (N1200-style precision on eqfinal/polish):

1. coarse: `-a --EqOn -s 10000 --StopResidual=0.05`
2. eqfinal: `-c --EqForceOn -s 50000 --StopResidual=0.005`
3. polish: `-c --EqOn -s 30000 --StopResidual=0.005`

### Full ladder examples

```bat
run_ideal_knot.cmd --3:1:1 -r3,6,12,24,48 -t8
run_ideal_knot.cmd --3:1:1 --resolutions 300,600,1200,2400,4800 --threads=8
run_catalog_knot.cmd --knot3.1 -r3,6,12,24,48 -v
```