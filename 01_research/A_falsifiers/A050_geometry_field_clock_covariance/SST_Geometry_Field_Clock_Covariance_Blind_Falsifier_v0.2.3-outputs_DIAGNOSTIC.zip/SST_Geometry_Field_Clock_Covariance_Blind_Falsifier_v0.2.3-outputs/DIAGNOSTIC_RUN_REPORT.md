# A050 v0.2.3 DIAGNOSTIC RUN REPORT

Verdict: `ISOLATED_M3_TRAJECTORY_BEHAVIOR`

Parent verdict (locked): `MODAL_PERSISTENCE_NOT_REPRODUCED`

## Basin profile

- epsilon=0.00125: strict m=3 0/12, fraction=0.000, frequency CV=None
- epsilon=0.0025: strict m=3 1/12, fraction=0.083, frequency CV=0.0
- epsilon=0.00375: strict m=3 1/12, fraction=0.083, frequency CV=0.0
- epsilon=0.005: strict m=3 1/12, fraction=0.083, frequency CV=0.0
- epsilon=0.0075: strict m=3 0/12, fraction=0.000, frequency CV=None
- epsilon=0.01: strict m=3 0/12, fraction=0.000, frequency CV=None

## Interpretation boundary

v0.2.3 is post-confirmatory and outcome-guided. Its result characterizes the local sensitivity of the generated G0002 m=3 branch. It does not revise the v0.2.2 confirmatory verdict and is not a test on production PKLSA/Ridgerunner geometry.
