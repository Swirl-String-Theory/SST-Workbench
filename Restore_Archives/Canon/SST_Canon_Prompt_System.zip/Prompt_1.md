# PROMPT 1 — CANON EXTRACTION & SKELETON

MODE: OUTLINE ONLY

TASK:
Analyze all inputs and generate a LaTeX skeleton.

INCLUDE:
- Sections and subsections
- Labels
- Placeholders for derivations

DO NOT:
- Write full derivations
