# Vortexring Lab v4 — regressie-audit

Auditdatum: 2026-07-10

## Scope

De beschikbare bestanden bevatten 72 HTML-kopieën/snapshots. Op SHA-256 zijn deze teruggebracht tot **22 unieke historische toestanden** plus één nieuwe gecorrigeerde hoofdversie. De audit volgt daarmee **23 chronologische toestanden** van v3 tot en met de regressie-gecorrigeerde versie.

## Uitgevoerde controles

- Inline JavaScript syntactisch gecontroleerd met `node --check`.
- HTML-ID’s gecontroleerd op duplicaten.
- Letterlijke `getElementById()`- en `querySelector(#id)`-referenties vergeleken met de aanwezige DOM-ID’s.
- Directe `addEventListener()`-bindings gecontroleerd op ontbrekende elementen.
- Kritieke functionele continuïteit gecontroleerd: broncirculatie in Biot–Savart, absolute cilindercoördinaten, geen geforceerde knoopschaling, kernlimiet, stabiliteitsrem, tijdomkering, dV-lagen, centrum-lock, periodieke z-wrap, camera, stroomlijnen, tabstructuur en frame-indicator.
- Gerichte semantische assertions uitgevoerd op de nieuwste versie, inclusief de SST-standaardwaarden en de koppeling `Γ = 2πa²|Ω|`.

## Resultaat per toestand

| # | Bestand | JS | Dubbele IDs | Ontbrekende DOM-ref. | Status |
|---:|---|:---:|---:|---:|---|
| 00 | `00_v3_baseline.html` | ✓ | 0 | 0 | PASS |
| 01 | `01_step1_particle-angular-velocity-hue.html` | ✓ | 0 | 0 | PASS |
| 02 | `02_step2_1_physics-overlay-close-fix.html` | ✓ | 0 | 0 | PASS |
| 03 | `03_step2_reset-top-and-adaptive-particle-hue.html` | ✓ | 0 | 0 | PASS |
| 04 | `04_step3_transparent-taylor-stewartson.html` | ✓ | 0 | 0 | PASS |
| 05 | `05_step4_dropdown-ui-groups.html` | ✓ | 0 | 0 | PASS |
| 06 | `06_step5_extra-topologies.html` | ✓ | 0 | 0 | PASS |
| 07 | `07_step6_number-inputs-with-slider-controls.html` | ✓ | 0 | 0 | PASS |
| 08 | `08_step7_full-height-taylor-column.html` | ✓ | 0 | 0 | PASS |
| 09 | `09_step8_particle-count-input.html` | ✓ | 0 | 0 | PASS |
| 10 | `10_step9_variable-cylinder-height-and-linked-volume.html` | ✓ | 0 | 0 | PASS |
| 11 | `11_step9_1_do-not-scale-knots-with-cylinder.html` | ✓ | 0 | 0 | PASS |
| 12 | `12_step10_absolute-centered-cylinder-and-particle-reset.html` | ✓ | 0 | 0 | PASS |
| 13 | `13_step11_stability-display-and-auto-relax.html` | ✓ | 0 | 0 | PASS |
| 14 | `14_step11_1_safety-time-brake-reverse-time-dV-toggles.html` | ✓ | 0 | 0 | PASS |
| 15 | `15_step12_knot-interaction-core-limit-and-stability-groups.html` | ✓ | 0 | 0 | PASS |
| 16 | `vortexring-lab-v4-step13-15.html` | ✓ | 0 | 0 | PASS |
| 17 | `vortexring-lab-v4-step16.html` | ✓ | 0 | 0 | PASS |
| 18 | `vortexring-lab-v4-before-packman-wrap.html` | ✓ | 0 | 0 | PASS |
| 19 | `vortexring-lab-v4-before-default-run-visual-merge.html` | ✓ | 0 | 0 | PASS |
| 20 | `vortexring-lab-v4-before-outer-reference.html` | ✓ | 0 | 0 | PASS |
| 21 | `vortexring-lab-v4-before-regression-fix.html` | ✓ | 0 | 0 | PASS |
| 22 | `vortexring-lab-v4.html` | ✓ | 0 | 0 | PASS |

**Statische structurele score:** 23/23 toestanden geslaagd.

## Gevonden regressies in toestand 21

1. **Default-preset wijzigde de handmatige tijdversnelling.** `applyDefaultStartup()` zette `P.accExp=0.3`, terwijl eerder expliciet was vastgelegd dat presets de tijdversnelling niet mogen wijzigen.
2. **De standaard tracerwolk startte in het volledige volume.** Ondanks standaard actieve centrum-lock en z-wrap stond `tracerSpawnMode` nog op `volume`, niet op de centrale Taylor-kolom.
3. **Default-preset herstelde z-wrap en kolomspawn niet.** Na handmatig uitschakelen bleven deze instellingen uit, ook na het kiezen van Default.
4. **Exact `z=+h` werd niet direct gewrapt.** De particlegrens gebruikte `nz > zHi` in plaats van het halfopen domein `nz >= zHi`.

## Aangebrachte correcties in toestand 22

- Default-preset behoudt nu de actuele handmatige tijdversnelling; de initiële pagina-start blijft `0.3` door de standaardwaarde in `P`.
- De standaard tracerbron is nu de centrale Taylor-kolom.
- Default-preset herstelt `tracerWrapZ=true` en `tracerSpawnMode=column` en reset de particles naar die kolom.
- Particle-wrap gebruikt nu het halfopen periodieke interval `[-h,+h)`: `z >= +h` gaat onmiddellijk naar de overeenkomstige positie bij `-h`.

## Bevestigde niet-regressies

- De knopen worden bij cilinder-resize **niet** geometrisch meegeschaald; alleen het volume en de passieve tracers volgen de opgelegde domeinrek.
- Niet-lokale Biot–Savart-bijdragen gebruiken nog steeds de circulatie van het **bronfilament** `fl[fs]`.
- De cilinder blijft gecentreerd op `(0,0,0)` met eindvlakken op `z=-h` en `z=+h`.
- De SST-default blijft: solo trefoil, SST, GP/NLSE, LIA, kwaliteit Hoog, `n=10`, centrum-lock aan.
- Kernradius, circulatie en rotatiesnelheid blijven gekoppeld via `|Γ|=2πa²|Ω|`; de standaard kernradius is numeriek consistent met `n=10` en `Ω=1 s⁻¹`.
- De losse dV-lagen, reverse-time, Auto-relax, stabiliteitsrem, particle size, vortex-opacity, streamline count, vorticiteitskleur en buitenste rotating-frame-referentie zijn behouden.

## Restbeperking van de audit

Dit is een sterke statische en semantische regressie-audit. Een volledige deterministische WebGL-trajectvergelijking is nog niet uitgevoerd: de pagina laadt Three.js/KaTeX via CDN en er bestaat nog geen vastgelegde golden-run met numerieke trajecten, screenshots en toleranties. De huidige versie is daarom **structureel regressie-gecontroleerd**, maar niet formeel gevalideerd als numerieke solver.

## Integriteit

- `vortexring-lab-v4-before-regression-fix.html`: `8bb3e4874f81acfb61d366e805083470f28a0aa0ff3b2b73cba34dec74162d63`
- `vortexring-lab-v4.html`: `566af3f1e0e89824adc7f22ad27fc802f3959c1704f8d96571382ec00fed300d`
