# SST Trefoil Lobe-Orientation Blind Falsifier v0.2.0

Blind finite-core Biot–Savart test of whether the three mutually tilted lobes of a trefoil generate non-local separating/restoring dynamics, and whether that local separation actually stabilizes the full reduced trefoil dynamics.

## Default working datasets

```text
C:\workspace\projects\SST-Workbench\KnotPlot\Knots_FourierSeries\3_1\knot.3_1.fseries
C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_3.1_final.txt
```

The release also contains byte-identical reproducibility copies in `repro_inputs/`.

## One-command run

```bat
run_all.cmd
```

This performs installation, native smoke test, BASIC campaign and EXTENDED campaign.

Other entry points:

```bat
run_basic.cmd
run_extended.cmd
run_cpu.cmd
run_gpu_sycl.cmd
run_summarize.cmd <output_directory>
```

`run_install.cmd` deliberately builds the deterministic C++/OpenMP extension. `run_gpu_sycl.cmd` is the explicit Intel oneAPI/SYCL path and initializes `setvars.bat` first.

## Scientific structure

### Legacy critical gates retained exactly

For cross-version continuity, overall PASS/FAIL still uses:

```text
G0_numerical_sanity
G2_reduced_stability
G3_cross_lobe_stabilizes
G4_nearest_pair_cross_separates
G6_ringdown_bounded
```

`G1` and `G5` remain diagnostics. v0.2.0 adds `G7`–`G11` as diagnostics only.

### v0.2.0 deeper diagnostics

1. **Exact modal causal decomposition**

For every reduced eigenmode, including the dominant unstable mode,

\[
\lambda_k
=
\lambda_k^{\mathrm{local}}
+
\lambda_k^{\mathrm{same\ lobe}}
+
\lambda_k^{\mathrm{cross\ lobe}}
+
\lambda_k^{\mathrm{transition}}.
\]

This uses left/right biorthogonal eigenvectors. A positive cross-lobe contact separation can therefore be distinguished from a negative or positive cross-lobe contribution to the actual unstable eigenvalue.

2. **Component ablation**

The package calculates the spectra for the full Jacobian and counterfactual Jacobians with each interaction component removed.

3. **Orientation-resolved close contacts**

The top-K distinct close cross-lobe contacts report

- separation distance;
- lobe identities;
- local tangent dot product \(\mathbf t_i\cdot\mathbf t_j\);
- tangent angle;
- antiparallelness;
- total/local/same/cross/transition separation rates.

4. **Three lobe-pair interaction test**

For each of the three lobe pairs, source-lobe segment fields are evaluated without inventing a closing segment. The centroid separation rate tests whether repulsion is a coherent three-lobe property or only a local contact effect.

5. **Curvature-matched orientation controls**

The original orientation scrambles are retained. v0.2.0 additionally filters them by a curvature-signature distance before claiming orientation specificity.

6. **`C_3` sector diagnostics**

The six-mode basis is interpreted as the symmetric `m=0` pair plus the real two-dimensional `E` sector, with separate tilt/breathing participation and block leakage.

7. **Nonlinear causal counterfactual**

A short nonlinear evolution is initialized along the dominant reduced eigenmode and run with

```text
full dynamics
full dynamics - cross-lobe component
```

No reconnection or repulsion rule is inserted. The ordering is compared with the sign predicted by the linear modal attribution.

## New gate-level reporting

Every run now writes:

```text
REPORT.md
GATE_CONCLUSIONS.md
gate_conclusions.json
summary_metrics.csv
modal_attribution.csv
contact_pairs.csv
component_ablation.csv
plots/
```

`GATE_CONCLUSIONS.md` contains, for **every gate and every source**:

- critical/diagnostic role;
- scientific question;
- PASS/FAIL;
- conclusion in words;
- measured evidence;
- preregistered criterion.

The blind score still exists before source identity is restored in:

```text
pre_unblind/blind_verdict.json
```

## No artificial reconnection or hard-core force

There is no

```text
reconnect()
repel_if_d_lt_2rc()
cut_and_splice()
```

operator. The finite-core kernel regularizes the induced velocity. A near-core event is reported but never repaired, bounced, or reconnected.

## Immutable version history inside every new release

v0.2.0 contains:

```text
release_history/SST_Trefoil_Lobe_Orientation_Blind_Falsifier_v0.1.0.zip
release_history/SST_Trefoil_Lobe_Orientation_Blind_Falsifier_v0.1.1.zip
```

and the exact current trefoil inputs under `repro_inputs/`.

Recalculate all BASIC historical conclusions:

```bat
run_reproduce_history_basic.cmd
```

Recalculate EXTENDED history:

```bat
run_reproduce_history_extended.cmd
```

See `docs/REPRODUCIBILITY.md` and `docs/HISTORICAL_REFERENCE_CONCLUSIONS.md`.

## SST dimensional mapping

Normalized calculations use \(\Gamma=1\) and total centerline length \(2\pi\). The physical mapping uses

\[
\Gamma_{\rm SST}=2\pi r_c\,\mathbf{v}_{\!\boldsymbol{\circlearrowleft}},
\]

with

\[
r_c=1.40897017\times10^{-15}\ \mathrm{m},
\qquad
\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}=1.09384563\times10^6\ \mathrm{m\,s^{-1}},
\]

so

\[
\Gamma_{\rm SST}=9.68361920349\times10^{-9}\ \mathrm{m^2\,s^{-1}}.
\]

The numerical core is calibrated blind from the geometric tube-thickness estimate and then mapped to physical \(r_c\).

## Historical result currently reproduced on the bundled inputs

Both v0.1.0 and v0.1.1 returned:

```text
G0 PASS
G1 PASS
G2 FAIL
G3 FAIL
G4 PASS
G5 FAIL
G6 PASS
Overall FAIL
```

v0.2.0 confirms that the **closest cross-lobe contact separates**, but the dominant unstable mode receives a positive real contribution from cross-lobe coupling in both input representations. See the historical conclusions document for the numerical reference values.

## Release notes

See `CHANGELOG.md`.
