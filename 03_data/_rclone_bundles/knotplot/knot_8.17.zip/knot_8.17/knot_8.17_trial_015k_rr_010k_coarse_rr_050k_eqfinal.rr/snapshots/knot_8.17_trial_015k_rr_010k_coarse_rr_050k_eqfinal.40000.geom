LIST {
	{ < knot_8.17_trial_015k_rr_010k_coarse_rr_050k_eqfinal.40000.vect }
	{ < knot_8.17_trial_015k_rr_010k_coarse_rr_050k_eqfinal.40000.struts.vect }
	{ < knot_8.17_trial_015k_rr_010k_coarse_rr_050k_eqfinal.40000.dlen.vect }
	{ < knot_8.17_trial_015k_rr_010k_coarse_rr_050k_eqfinal.40000.dVdt.vect }
}
