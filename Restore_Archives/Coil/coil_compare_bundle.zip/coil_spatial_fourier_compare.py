#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
coil_spatial_fourier_compare.py

Compare spatial Fourier mode spectra for three coil geometries:
1) SawShape bowl, 3-phase, S=40, steps +11/-9
2) Rodin 6-lane torus-knot guide, 3 phases + mirrored set, P=5,Q=12
3) Starship 6-phase/ABC+anti, S=9 steps +4/+4 mapped to 27 points

The code is self-contained and mirrors the geometry definitions in:
- GUI-SawBowl.py
- rodin_6coil_guide_generator.py

Outputs are CSV and PNG files in --out-dir.
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

VSST = 1.09384563e6  # m/s canonical SST swirl speed


def alternating_skip_indices(S, step_fwd, step_bwd, n_pairs, start=1):
    idx = start
    seq = [idx]
    for k in range(2*n_pairs):
        if k % 2 == 0:
            idx = (idx + step_fwd - 1) % S + 1
        else:
            idx = (idx + step_bwd - 1) % S + 1
        seq.append(idx)
    return np.array(seq, dtype=int)


def r_profile(s, Rb, Rt, profile='Exponential', power=2.2):
    if profile == 'Exponential':
        return Rb + (Rt - Rb) * (s**power)
    if profile == 'Inverse Exp':
        return Rt - (Rt - Rb) * (s**power)
    return Rb + (Rt - Rb) * s


def build_curved_phase(seq, S, Rb, Rt, n_pairs, samples_per_seg=24,
                       angle_offset=0.0, profile='Exponential', power=2.2):
    slot_angles_base = np.linspace(0, 2*np.pi, S, endpoint=False) - np.pi/2.0
    N = len(seq) - 1
    s_nodes = np.linspace(0, 1, N+1)
    r_nodes = r_profile(s_nodes, Rb, Rt, profile, power)
    z_nodes = s_nodes
    xs, ys, zs = [], [], []
    for k in range(N):
        i0, i1 = seq[k]-1, seq[k+1]-1
        a0 = slot_angles_base[i0] + angle_offset
        a1 = slot_angles_base[i1] + angle_offset
        da = (a1 - a0 + np.pi) % (2*np.pi) - np.pi
        a_line = a0 + np.linspace(0, 1, samples_per_seg, endpoint=False) * da
        r_line = np.linspace(r_nodes[k], r_nodes[k+1], samples_per_seg, endpoint=False)
        z_line = np.linspace(z_nodes[k], z_nodes[k+1], samples_per_seg, endpoint=False)
        xs.append(r_line * np.cos(a_line))
        ys.append(r_line * np.sin(a_line))
        zs.append(z_line)
    return np.column_stack([np.concatenate(xs), np.concatenate(ys), np.concatenate(zs)])


def segmentize_paths(paths, decimate=1):
    mids, dls, labels, phases = [], [], [], []
    for name, pts, phase in paths:
        pts = pts[::max(1, decimate)]
        if len(pts) < 2:
            continue
        dl = pts[1:] - pts[:-1]
        mid = 0.5*(pts[1:] + pts[:-1])
        mids.append(mid)
        dls.append(dl)
        labels += [name] * len(mid)
        phases += [phase] * len(mid)
    if not mids:
        return np.empty((0,3)), np.empty((0,3)), [], np.array([])
    return np.vstack(mids), np.vstack(dls), labels, np.asarray(phases)


def wire_spectrum(paths, m_max=60, decimate=1, driven=True):
    mids, dls, labels, phases = segmentize_paths(paths, decimate=decimate)
    theta = np.arctan2(mids[:,1], mids[:,0])
    weights = np.linalg.norm(dls, axis=1)
    if driven:
        weights = weights * np.exp(1j*phases)
    norm = np.sum(np.abs(weights))
    rows = []
    for m in range(m_max+1):
        amp = np.sum(weights * np.exp(-1j*m*theta))
        rows.append((m, np.abs(amp)/norm if norm > 0 else 0.0))
    return pd.DataFrame(rows, columns=["m", "S_wire"])


def normalize_paths_outer_radius(paths):
    max_r = 0.0
    for _, pts, _ in paths:
        r = np.sqrt(pts[:,0]**2 + pts[:,1]**2)
        max_r = max(max_r, float(np.max(r)))
    out = []
    for name, pts, ph in paths:
        out.append((name, pts / max_r, ph))
    return out, max_r


def biot_savart_complex_field(paths, phi_grid, r_probe=0.60, z_probe=0.60, decimate=6):
    mids, dls, labels, phases = segmentize_paths(paths, decimate=decimate)
    I = np.exp(1j*phases)
    obs = np.column_stack([
        r_probe*np.cos(phi_grid),
        r_probe*np.sin(phi_grid),
        np.full_like(phi_grid, z_probe)
    ])
    B = np.zeros((len(obs), 3), dtype=complex)
    for k, p in enumerate(obs):
        R = p[None,:] - mids
        Rnorm = np.linalg.norm(R, axis=1)
        mask = Rnorm > 1e-8
        cross = np.cross(dls[mask], R[mask])
        coef = I[mask] / (Rnorm[mask]**3)
        B[k] = np.sum(cross * coef[:,None], axis=0)
    return B


def field_spectrum(paths, m_max=60, n_phi=360, decimate=6, component="Bz"):
    paths_norm, original_max_r = normalize_paths_outer_radius(paths)
    phi = np.linspace(0, 2*np.pi, n_phi, endpoint=False)
    B = biot_savart_complex_field(paths_norm, phi, r_probe=0.60, z_probe=0.60, decimate=decimate)
    if component == "Br":
        e_r = np.column_stack([np.cos(phi), np.sin(phi), np.zeros_like(phi)])
        sig = np.sum(B * e_r, axis=1)
    elif component == "Bphi":
        e_phi = np.column_stack([-np.sin(phi), np.cos(phi), np.zeros_like(phi)])
        sig = np.sum(B * e_phi, axis=1)
    else:
        sig = B[:,2]
    sig = sig - np.mean(sig)
    norm = np.sum(np.abs(sig))
    rows = []
    for m in range(m_max+1):
        amp = np.sum(sig * np.exp(-1j*m*phi))
        rows.append((m, np.abs(amp)/norm if norm > 0 else 0.0))
    return pd.DataFrame(rows, columns=["m", f"S_field_{component}"]), phi, sig, original_max_r


def top_modes(df, col, top_n=8, exclude_dc=True):
    d = df.copy()
    if exclude_dc:
        d = d[d["m"] > 0]
    return d.sort_values(col, ascending=False).head(top_n)


def make_mode_lock_rows(geometry, top_df, R_eff_m, n_max=12):
    rows = []
    for m in top_df["m"].astype(int).tolist():
        for n in range(1, n_max+1):
            f = abs(m)*VSST/(n*2*np.pi*R_eff_m)
            rows.append({
                "geometry": geometry,
                "m": m,
                "n": n,
                "R_eff_m": R_eff_m,
                "f_lock_Hz": f,
                "f_lock_MHz": f/1e6
            })
    return rows


# ---------------- Geometry constructors ----------------

def make_sawshape_paths(n_pairs=20, Rb=0.5, Rt=1.5, Hc=0.1, scale_to_mm=34.0/1.5,
                        samples_per_seg=24, profile='Exponential'):
    S = 40
    step_fwd = 11
    step_bwd = -9
    seq = alternating_skip_indices(S, step_fwd, step_bwd, n_pairs, start=1)
    paths = []
    phases = [0.0, 2*np.pi/3, 4*np.pi/3]
    for k, ang in enumerate(phases):
        pts = build_curved_phase(seq, S, Rb, Rt, n_pairs,
                                 samples_per_seg=samples_per_seg,
                                 angle_offset=ang, profile=profile)
        pts[:,2] *= Hc
        pts *= scale_to_mm
        paths.append((f"SawShape phase {k+1}", pts, phases[k]))
    return paths


def torus_lane(R_major, r_surface, p, q, t, phase_angle=0.0, mirror=False, offset=0.0):
    theta = p*t + phase_angle
    phi = q*t
    r_eff = r_surface + offset
    x = (R_major + r_eff*np.cos(phi))*np.cos(theta)
    y = (R_major + r_eff*np.cos(phi))*np.sin(theta)
    z = r_eff*np.sin(phi)
    if mirror:
        z = -z
    return np.column_stack([x,y,z])


def make_rodin_paths(R_major=34.0, R_tube=9.0, P=5, Q=12, N_path=1800):
    t = np.linspace(0, 2*np.pi, N_path, endpoint=True)
    paths = []
    phases = [0.0, 2*np.pi/3, 4*np.pi/3]
    for k, ang in enumerate(phases):
        pts_top = torus_lane(R_major, R_tube, P, Q, t, phase_angle=ang, mirror=False)
        pts_bot = torus_lane(R_major, R_tube, P, Q, t, phase_angle=ang, mirror=True)
        paths.append((f"Rodin phase {k+1} top", pts_top, phases[k]))
        paths.append((f"Rodin phase {k+1} bottom", pts_bot, phases[k]))
    return paths


def make_starship_paths(n_pairs=20, Rb=0.5, Rt=1.5, Hc=0.1, scale_to_mm=34.0/1.5,
                        samples_per_seg=24, profile='Exponential'):
    STARSHIP_S = 9
    STARSHIP_STEP_FWD = 4
    STARSHIP_STEP_BWD = 4
    STARSHIP_ROT_ANGLE = (2*np.pi/27)/3
    STARSHIP_COIL_ANGLES = (
        np.linspace(0, 2*np.pi, 28)[:-1] - np.pi*1.5 + (2*np.pi/27)
    )[::-1] + STARSHIP_ROT_ANGLE
    STARSHIP_SEGMENT_SHIFT = (2*np.pi/27)/3
    phase_base = {'A': 0.0, 'B': 2*np.pi/3, 'C': 4*np.pi/3,
                  'a': 0.0, 'b': 2*np.pi/3, 'c': 4*np.pi/3}
    specs = [
        (0,  0.0,   False, (1,2,3), 'A'),
        (9,  0.0,   False, (1,2,3), 'B'),
        (18, 0.0,   False, (1,2,3), 'C'),
        (0,  np.pi, True,  (1,2,3), 'a'),
        (9,  np.pi, True,  (1,2,3), 'b'),
        (18, np.pi, True,  (1,2,3), 'c'),
    ]

    def starship_saw_to_27(saw_seq, phase_offset_27):
        return np.array([((int(s)*3 - phase_offset_27 - 1) % 27) + 1 for s in saw_seq], dtype=int)

    def build_starship_curved(seq_27, phase_angle, segment):
        N = len(seq_27) - 1
        s_nodes = np.linspace(0, 1, N+1)
        r_nodes = r_profile(s_nodes, Rb, Rt, profile, 2.2)
        z_nodes = s_nodes
        seg = STARSHIP_SEGMENT_SHIFT*(segment-1)
        xs, ys, zs = [], [], []
        for k in range(N):
            i0, i1 = int(seq_27[k])-1, int(seq_27[k+1])-1
            a0 = STARSHIP_COIL_ANGLES[i0] + seg + phase_angle
            a1 = STARSHIP_COIL_ANGLES[i1] + seg + phase_angle
            da = (a1-a0 + np.pi) % (2*np.pi) - np.pi
            a_line = a0 + np.linspace(0,1,samples_per_seg,endpoint=False)*da
            r_line = np.linspace(r_nodes[k], r_nodes[k+1], samples_per_seg, endpoint=False)
            z_line = np.linspace(z_nodes[k], z_nodes[k+1], samples_per_seg, endpoint=False)
            xs.append(r_line*np.cos(a_line))
            ys.append(r_line*np.sin(a_line))
            zs.append(z_line)
        pts = np.column_stack([np.concatenate(xs), np.concatenate(ys), np.concatenate(zs)])
        pts[:,2] *= Hc
        pts *= scale_to_mm
        return pts

    saw_seq = alternating_skip_indices(STARSHIP_S, STARSHIP_STEP_FWD, STARSHIP_STEP_BWD, n_pairs, start=1)
    paths = []
    for off27, phase_angle, reverse, segs, tag in specs:
        path = saw_seq[::-1] if reverse else saw_seq
        seq_27 = starship_saw_to_27(path, off27)
        for segment, strand in zip(segs, ["fwd", "neu", "bwd"]):
            pts = build_starship_curved(seq_27, phase_angle, segment)
            paths.append((f"Starship {tag} {strand}", pts, phase_base[tag]))
    return paths


# ---------------- Main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default="coil_compare")
    ap.add_argument("--m-max", type=int, default=80)
    ap.add_argument("--n-phi", type=int, default=360)
    ap.add_argument("--decimate-wire", type=int, default=1)
    ap.add_argument("--decimate-field", type=int, default=10)
    ap.add_argument("--top-n", type=int, default=10)
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    geoms = {
        "SawShape_P40_+11_-9": make_sawshape_paths(),
        "Rodin_6lane_P5_Q12": make_rodin_paths(),
        "Starship_6phase_S9_+4_+4": make_starship_paths(),
    }

    wire_all, field_all, summary_rows, mode_rows = [], [], [], []
    profiles = {}

    for geom_name, paths in geoms.items():
        wire_df = wire_spectrum(paths, m_max=args.m_max, decimate=args.decimate_wire, driven=True)
        wire_top = top_modes(wire_df, "S_wire", args.top_n)
        wire_df.insert(0, "geometry", geom_name)
        wire_all.append(wire_df)

        field_df, phi, sig, original_max_r = field_spectrum(paths, m_max=args.m_max, n_phi=args.n_phi,
                                                            decimate=args.decimate_field, component="Bz")
        field_top = top_modes(field_df, "S_field_Bz", args.top_n)
        field_df.insert(0, "geometry", geom_name)
        field_all.append(field_df)
        profiles[geom_name] = (phi, sig)

        R_eff_m = 0.60 * original_max_r * 1e-3
        summary_rows.append({
            "geometry": geom_name,
            "outer_radius_mm": original_max_r,
            "R_eff_for_lock_mm": R_eff_m*1e3,
            "top_wire_modes": ", ".join([f"{int(r.m)}:{r.S_wire:.3f}" for r in wire_top.itertuples()]),
            "top_field_Bz_modes": ", ".join([f"{int(r.m)}:{r.S_field_Bz:.3f}" for r in field_top.itertuples()]),
        })
        mode_rows.extend(make_mode_lock_rows(geom_name, field_top.head(5), R_eff_m, n_max=12))

    wire_all_df = pd.concat(wire_all, ignore_index=True)
    field_all_df = pd.concat(field_all, ignore_index=True)
    summary_df = pd.DataFrame(summary_rows)
    mode_df = pd.DataFrame(mode_rows)

    wire_all_df.to_csv(out / "coil_compare_wire_spectrum.csv", index=False)
    field_all_df.to_csv(out / "coil_compare_field_spectrum.csv", index=False)
    summary_df.to_csv(out / "coil_compare_summary.csv", index=False)
    mode_df.to_csv(out / "coil_compare_mode_lock_frequencies.csv", index=False)

    fig, axes = plt.subplots(2, 1, figsize=(13, 8), sharex=True)
    for geom_name in geoms:
        d = wire_all_df[wire_all_df.geometry == geom_name]
        axes[0].plot(d["m"], d["S_wire"], marker="o", ms=2, lw=1, label=geom_name)
        d2 = field_all_df[field_all_df.geometry == geom_name]
        axes[1].plot(d2["m"], d2["S_field_Bz"], marker="o", ms=2, lw=1, label=geom_name)
    axes[0].set_ylabel("S_wire driven")
    axes[0].set_title("Driven wire spatial Fourier spectrum")
    axes[0].grid(True, alpha=0.3)
    axes[1].set_xlabel("azimuthal mode m")
    axes[1].set_ylabel("S_field_Bz")
    axes[1].set_title("Biot-Savart Bz field spectrum on normalized probe ring")
    axes[1].grid(True, alpha=0.3)
    axes[0].legend(fontsize=8)
    axes[1].legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out / "coil_compare_spatial_fourier.png", dpi=170)
    plt.close(fig)

    fig, axes = plt.subplots(len(geoms), 1, figsize=(13, 9), sharex=True)
    for ax, geom_name in zip(axes, geoms):
        phi, sig = profiles[geom_name]
        ax.plot(phi, np.real(sig), lw=1, label="Re(Bz - mean)")
        ax.plot(phi, np.imag(sig), lw=1, ls="--", label="Im(Bz - mean)")
        ax.set_ylabel(geom_name.split("_")[0])
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=8)
    axes[-1].set_xlabel("probe angle φ [rad]")
    plt.tight_layout()
    plt.savefig(out / "coil_compare_field_profiles.png", dpi=170)
    plt.close(fig)

    lines = ["COIL SPATIAL FOURIER COMPARISON", ""]
    for row in summary_rows:
        lines.append(f"{row['geometry']}:")
        lines.append(f"  outer_radius_mm: {row['outer_radius_mm']:.3f}")
        lines.append(f"  R_eff_for_lock_mm: {row['R_eff_for_lock_mm']:.3f}")
        lines.append(f"  top wire modes: {row['top_wire_modes']}")
        lines.append(f"  top field Bz modes: {row['top_field_Bz_modes']}")
        lines.append("")
    (out / "coil_compare_summary.txt").write_text("\n".join(lines), encoding="utf-8")

    print(summary_df.to_string(index=False))
    print("Wrote:", out)

if __name__ == "__main__":
    main()
