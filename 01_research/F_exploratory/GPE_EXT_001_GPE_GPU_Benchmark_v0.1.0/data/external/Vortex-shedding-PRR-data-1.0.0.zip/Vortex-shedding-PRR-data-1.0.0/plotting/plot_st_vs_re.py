"""Recreate the St-vs-Re summary figure from merged public-release data."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
from scipy.optimize import curve_fit

from _common import FIGURE_DIR, load_freq_outlier, load_merged, load_threshold_reynolds_table, setup_matplotlib


SERIES_DICT = {
    0.7: [(0.7, 15, "^", "C1"), (0.7, 20, "x", "C2"), (0.7, 25, "h", "C3"), (0.7, 30, "s", "skyblue")],
    0.9: [(0.9, 15, "o", "C0"), (0.9, 20, "s", "C1"), (0.9, 25, "^", "C2"), (0.9, 30, "D", "C3")],
}
SAVE_NAME = "st_vs_re.png"
MS = 2.4


def make_legend_bins():
    return {"filled": [], "unfilled": [], "sigma_handles": [], "sigma_labels": [], "seen_sigma": set()}


def st_model(Re, St0, A, B):
    return St0 * (1.0 - A / (Re + B))


setup_matplotlib()
merged = load_merged()
outlier_rows = load_freq_outlier()
threshold_rows = load_threshold_reynolds_table()

all_sigmas = sorted(np.unique(merged[:, 1]).astype(float))
marker_cycle = ["<", "o", "s", "^", "D", "p", "h", ">", "<"]
color_cycle = ["k", "C0", "C1", "C2", "C3", "C4", "C5", "C6", "C7"]
sigma_styles = {float(s): (marker_cycle[i % len(marker_cycle)], color_cycle[i % len(color_cycle)]) for i, s in enumerate(all_sigmas)}


def threshold_speed(V0, sigma, subset):
    row = threshold_rows[(np.isclose(threshold_rows["V0"], V0)) & (np.isclose(threshold_rows["sigma"], sigma))]
    if len(row) == 0:
        return 0.33
    re_target = float(row["Re_th"][0])
    index = int(np.argmin(np.abs(subset[:, 7] - re_target)))
    return float(subset[index, 2])


def corrected_f_drag(V0, sigma, subset):
    values = subset[:, 5].copy()
    mask = np.isclose(outlier_rows["V0"], V0) & np.isclose(outlier_rows["sigma"], sigma)
    for row in outlier_rows[mask]:
        values[np.isclose(subset[:, 2], row["speed"])] = row["fdrag"]
    return values


def plot_panel_with_fit(ax, series, legend_bins, label_pos):
    re_all_list = []
    st_all_list = []
    scatter_handles = []

    for V0, sigma, marker, color in series:
        subset = merged[
            (merged[:, 0] == V0)
            & (merged[:, 1] == sigma)
            & (merged[:, 6] > 0)
            & (merged[:, 7] > 0)
            & (merged[:, 2] < 0.65)
        ]
        if subset.size == 0:
            continue

        f_drag = corrected_f_drag(V0, sigma, subset)
        f_lift = subset[:, 4]
        re_vals = subset[:, 7]
        st_vals = np.empty_like(re_vals)
        yerr = np.empty_like(re_vals)

        thres_speed = threshold_speed(V0, sigma, subset)
        mask_low = subset[:, 2] < thres_speed
        mask_high = ~mask_low

        st_vals[mask_low] = f_drag[mask_low] * subset[mask_low, 6] / subset[mask_low, 2] / 2.0
        yerr[mask_low] = np.sqrt(
            (1 / 10000 * subset[mask_low, 6] / subset[mask_low, 2]) ** 2
            + (f_drag[mask_low] / 2 * 0.5 / subset[mask_low, 2]) ** 2
        )

        st_vals[mask_high] = f_lift[mask_high] * subset[mask_high, 6] / subset[mask_high, 2]
        yerr[mask_high] = np.sqrt(
            (1 / 10000 * subset[mask_high, 6] / subset[mask_high, 2]) ** 2
            + (f_lift[mask_high] * 0.5 / subset[mask_high, 2]) ** 2
        )

        mkr, col = sigma_styles.get(float(sigma), (marker, color))
        scatter_handles.append((re_vals, st_vals, yerr, mkr, col, sigma))
        re_all_list.append(re_vals)
        st_all_list.append(st_vals)

    if re_all_list:
        re_all = np.concatenate(re_all_list)
        st_all = np.concatenate(st_all_list)
        fit_mask = (re_all > 0.1) & np.isfinite(re_all) & np.isfinite(st_all) & (st_all > 0)
        re_fit = re_all[fit_mask]
        st_fit = st_all[fit_mask]
        if re_fit.size >= 3:
            hi = re_fit > 3.0
            st0_init = np.median(st_fit[hi]) if np.any(hi) else np.median(st_fit)
            popt, _ = curve_fit(st_model, re_fit, st_fit, p0=[max(st0_init, 1e-3), 1.0, 0.0], bounds=([0.0, 0.0, 0.0], [np.inf, np.inf, np.inf]), maxfev=200000)
            St0, A, B = popt
            xg = np.linspace(0.1, 21.0, 400)
            ax.plot(xg, st_model(xg, St0, A, B), linestyle=":", color="k", lw=0.8, alpha=0.9, zorder=1)
            ax.text(0.96, 0.065, rf"$\mathrm{{St_0}}={St0:.2f}$" + "\n" + rf"$A={A:.2f}$" + "\n" + rf"$B={B:.2f}$", transform=ax.transAxes, ha="right", va="bottom", fontsize=7)
            ax.text(0.96, 0.81, rf"$V_0/\mu$={series[0][0]}", transform=ax.transAxes, ha="right", va="bottom", fontsize=8)

    for re_vals, st_vals, yerr, mkr, col, sigma in scatter_handles:
        mask_sub = re_vals < 1
        h1 = ax.plot(re_vals[mask_sub][::2], st_vals[mask_sub][::2], marker=mkr, linestyle="none", mec=col, mfc=colors.to_rgba(col, alpha=0.3), mew=0.7, markersize=MS, zorder=2)[0]
        ax.plot(re_vals[~mask_sub], st_vals[~mask_sub], marker=mkr, linestyle="none", mec=col, mfc=colors.to_rgba(col, alpha=0.3), mew=0.7, markersize=MS, zorder=2)
        ax.errorbar(re_vals[mask_sub][::2], st_vals[mask_sub][::2], yerr=yerr[mask_sub][::2], fmt="none", ecolor=col, elinewidth=0.5, alpha=1, zorder=1, capsize=1.5, capthick=0.5)
        ax.errorbar(re_vals[~mask_sub], st_vals[~mask_sub], yerr=yerr[~mask_sub], fmt="none", ecolor=col, elinewidth=0.5, alpha=1, zorder=1, capsize=1.5, capthick=0.5)
        if sigma not in legend_bins["seen_sigma"]:
            h_sigma = Line2D([0], [0], marker=mkr, color="none", mfc=colors.to_rgba(col, alpha=0.3), mec=col, markersize=MS, mew=0.7, linestyle="none")
            legend_bins["sigma_handles"].append(h_sigma)
            legend_bins["sigma_labels"].append(rf"$\sigma/\xi={sigma}$")
            legend_bins["seen_sigma"].add(sigma)

    ax.set_ylabel(r"$\mathrm{{St}}$")
    ax.set_ylim(0, 0.45)
    ax.grid(False)
    ax.text(-0.16, 0.86, label_pos, transform=ax.transAxes, fontsize=8)
    ax.vlines(2, 0, 0.45, colors="grey", linestyles="dashed", linewidth=0.6)


fig = plt.figure(figsize=(3.375, 3.75))
outer = fig.add_gridspec(2, 1, hspace=0.3, height_ratios=[4, 1.4], bottom=0.1, right=0.97, left=0.15)
gs_top = outer[0].subgridspec(2, 1, hspace=0.09)
ax_top = fig.add_subplot(gs_top[0])
ax_bot = fig.add_subplot(gs_top[1])
ax_aux = fig.add_subplot(outer[1])
legend_bins = make_legend_bins()

plot_panel_with_fit(ax_top, SERIES_DICT[0.7], legend_bins, label_pos="(a)")
ax_top.tick_params(labelbottom=False)
plot_panel_with_fit(ax_bot, SERIES_DICT[0.9], legend_bins, label_pos="(b)")
ax_bot.set_xlabel(r"$\mathrm{{Re_s}}$")

if legend_bins["sigma_handles"]:
    fig.legend(legend_bins["sigma_handles"], legend_bins["sigma_labels"], ncol=len(legend_bins["sigma_handles"]), frameon=False, loc="upper left", bbox_to_anchor=(0.12, 1.021), handletextpad=0.3, columnspacing=1.0, fontsize=8)

sub = merged[merged[:, 1] == 20]
v0_vals = np.unique(sub[:, 0])
v0_list, st_mean_list, st_err_list = [], [], []
for V0 in v0_vals:
    subV = sub[(sub[:, 0] == V0) & (sub[:, 2] > 0.55) & (sub[:, 2] <= 0.65)]
    if subV.size == 0:
        continue
    st_unique = np.unique(subV[:, 8])
    v0_list.append(V0)
    st_mean_list.append(np.mean(st_unique))
    st_err_list.append(np.std(st_unique, ddof=1) if len(st_unique) > 1 else 0.0)

v0_arr = np.array(v0_list)
st_mean_arr = np.array(st_mean_list)
st_err_arr = np.array(st_err_list)
ax_aux.plot(v0_arr, st_mean_arr, marker="o", markersize=MS, linestyle="None", mfc=colors.to_rgba("k", alpha=0.3), mec="k", mew=0.7)
ax_aux.errorbar(v0_arr, st_mean_arr, yerr=st_err_arr, fmt="none", ecolor="k", elinewidth=0.5, alpha=1, zorder=1, capsize=1.5, capthick=0.5)
ax_aux.set_ylim(0.1, 0.37)
ax_aux.set_xlim(0.5, 3.0)
ax_aux.set_yticks([0.1, 0.2, 0.3])
ax_aux.grid(True, alpha=0.8)
ax_aux.grid(True, which="minor", alpha=0.8, linestyle="--")
ax_aux.yaxis.set_minor_locator(MultipleLocator(0.05))
ax_aux.set_xlabel(r"$V_0/\mu$")
ax_aux.set_ylabel(r"$\mathrm{St_0}$")
ax_aux.text(-0.16, 0.86, "(c)", transform=ax_aux.transAxes, fontsize=8)

out = FIGURE_DIR / SAVE_NAME
fig.savefig(out, dpi=600)
plt.close(fig)
print(f"saved {out}")
