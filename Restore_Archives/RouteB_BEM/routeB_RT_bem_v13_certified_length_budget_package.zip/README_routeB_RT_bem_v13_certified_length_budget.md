# Route B BEMv13 certified-length budget

BEMv13 implements the certified-length branch suggested by BEMv12.

The Fourier coefficients remain the BEM geometry source, but the leading longitudinal scale uses the certified/database length column:

\[
L_{\rm cert}(K)=L_{\rm database}(K).
\]

The blind budget is:

\[
\alpha^{-1}_{\rm pred,blind}
=
\frac12\left[
N_{\rm soft}V_{\rm soft}L_{\rm cert}(3_1)
+
\frac{\Delta F_{\rm pair}}{\mathcal N_q}
\right].
\]

No observed alpha is used.

## Outputs

```text
certified_length_audit.csv
certified_normalizer_candidates.csv
alpha_component_budget_v13.csv
certified_length_report.md
run_config_v13.json
```

## Reuse an existing BEMv8 output

```bash
python routeB_RT_bem_v13_certified_length_budget.py \
  --ideal ideal.txt \
  --from-bemv8-outdir outputs_routeB_BEM_v8_fast \
  --outdir outputs_routeB_BEM_v13_from_v8
```

## Full run

```bash
python routeB_RT_bem_v13_certified_length_budget.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v13 \
  --ideal-xml-knot-ids 0:1:1,3:1:1,4:1:1 \
  --n-center 48 --n-theta 8 --n-sphere 256 \
  --pair-fit-min-M 10
```

## Default preferred normalizer

```text
M_Lcert2 = M_max * L_cert^2
```

BEMv13 is not the final derivation. It is the certified-length budget gate. The next step is BEMv14: convergence grid for the certified-length budget.
