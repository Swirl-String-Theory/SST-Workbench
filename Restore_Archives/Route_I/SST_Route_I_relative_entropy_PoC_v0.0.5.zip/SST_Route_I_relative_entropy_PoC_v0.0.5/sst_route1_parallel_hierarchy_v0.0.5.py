#!/usr/bin/env python3
"""
SST Route I hierarchy-closure research harness v0.0.5.

Three mechanisms are audited in parallel:
 A) collective correlations / covariance squeezing,
 B) internal topological degeneracy,
 C) an independently derived sub-core boundary-mode sector.

The script enforces a shared entropy budget to prevent double counting:
    eta_capacity = n_channels * h_rate
    eta_relative = n_channels * d_rate
A reversible area response requires eta_capacity >= eta_relative and, at
closure, eta_capacity = eta_relative. Correlations may enhance relative
entropy, but they do not enlarge a fixed finite local alphabet; hidden modes
then belong to branch B or C.

Newton's constant appears only in a post-derivation audit target inherited
from v0.0.4. Candidate SST scales are constructed without G or L_p.
"""
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path
from dataclasses import dataclass, asdict
import numpy as np
try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

VERSION='0.0.5'
PI=math.pi
C=299_792_458.0
HBAR=1.054_571_817e-34
G_AUDIT=6.67430e-11
R_C=1.40897017e-15
RHO_CORE=3.8934358266918687e18
RHO_F=7.0e-7
V_SWIRL=1.09384563e6
LN2=math.log(2.0)

ETA_CORE_BINARY = LN2/(2.0*PI*R_C**2)  # v0.0.4 maximal tube-piercing model
ETA_TARGET_AUDIT = C**3/(4.0*HBAR*G_AUDIT)
DEFICIT = ETA_TARGET_AUDIT/ETA_CORE_BINARY
N_CROSS_CORE = 1.0/(2.0*PI*R_C**2)


def relerr(x,y):
    return abs(x-y)/max(abs(y), np.finfo(float).tiny)

def write_csv(path, rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

# ------------------------------------------------------------------
# Branch A: correlations
# ------------------------------------------------------------------
def correlation_rows():
    rows=[]
    # Gaussian equal-covariance displacement: D=1/2 mu^T C^{-1}mu.
    # For a signal eigenmode with covariance eigenvalue lambda, enhancement=1/lambda.
    for enhancement in [1.0,1e2,1e4,1e8,1e12,1e20,DEFICIT]:
        lam=1.0/enhancement
        r=0.5*math.log(enhancement)  # variance squeezing exp(-2r)
        db=10.0*math.log10(enhancement)
        occupancy=math.sinh(r)**2
        omega_core=V_SWIRL/R_C
        energy=HBAR*omega_core*occupancy
        rows.append({
            'relative_entropy_enhancement':enhancement,
            'signal_covariance_eigenvalue':lam,
            'squeezing_parameter_r':r,
            'variance_squeezing_dB':db,
            'oscillator_occupation':occupancy,
            'conditional_energy_at_omega_core_J':energy,
            'capacity_enhancement_fixed_binary_alphabet':1.0,
            'reversible_capacity_gate_pass': enhancement <= 1.0+1e-12,
        })
    return rows

def correlation_cluster_audit():
    required_cluster=DEFICIT
    area=required_cluster/N_CROSS_CORE
    radius=math.sqrt(area/PI)
    return {
        'linear_collective_bound_assumed':'chi_corr <= M for an M-channel bounded collective block',
        'required_channels_M':required_cluster,
        'required_block_area_m2':area,
        'equivalent_circular_radius_m':radius,
        'conclusion':'A finite-alphabet correlation block cannot raise capacity per area; this is only a relative-entropy response bound.'
    }

# ------------------------------------------------------------------
# Branch B: topological degeneracy
# ------------------------------------------------------------------
def topology_rows():
    required_ln_q=ETA_TARGET_AUDIT/N_CROSS_CORE
    rows=[]
    # q_top(n)=b^n is deliberately generous. Even b=10^6 per crossing is audited.
    for b in [2.0,10.0,100.0,1e3,1e6]:
        crossings=required_ln_q/math.log(b)
        # Published generic thick-knot lower bound Rop >= 2.135 Cr^(3/4).
        ropelength_lb=2.135*crossings**0.75
        physical_length=ropelength_lb*R_C
        rows.append({
            'growth_base_per_crossing_b':b,
            'required_ln_q_nats_per_core_piercing':required_ln_q,
            'required_crossing_complexity':crossings,
            'ropelength_lower_bound_core_radii':ropelength_lb,
            'physical_centerline_length_lower_bound_m':physical_length,
            'fits_local_core_region':physical_length <= 100.0*R_C,
        })
    return rows

# ------------------------------------------------------------------
# Branch C: sub-core mode sector
# ------------------------------------------------------------------
def weyl_eta(ell, q=2.0, polarizations=1.0):
    # 2D Weyl leading density: N/A=kmax^2/(4pi), kmax=pi/ell.
    # eta=(polarizations*pi/(4 ell^2))*ln q.
    return polarizations*PI*math.log(q)/(4.0*ell**2)

def candidate_subcore_scales():
    ratio=RHO_F/RHO_CORE
    return [
        ('canonical_core_radius',R_C,'CANON'),
        ('density_contrast_volume_scale',R_C*ratio**(1.0/3.0),'HYPOTHESIS'),
        ('density_contrast_area_scale',R_C*ratio**0.5,'HYPOTHESIS'),
        ('density_contrast_two_thirds_scale',R_C*ratio**(2.0/3.0),'HYPOTHESIS'),
        ('quantum_core_length_c',(HBAR/(RHO_CORE*C))**0.25,'DERIVED-DIMENSIONAL'),
        ('quantum_core_length_vswirl',(HBAR/(RHO_CORE*V_SWIRL))**0.25,'DERIVED-DIMENSIONAL'),
        ('fixed_link_lattice_PeV_existence_bound',4.4e-22,'RESEARCH-TRACK-BOUND'),
    ]

def subcore_rows():
    rows=[]
    for name,ell,status in candidate_subcore_scales():
        eta=weyl_eta(ell,2.0,1.0)
        rows.append({
            'candidate':name,'status':status,'length_m':ell,
            'weyl_eta_q2_one_polarization_m2':eta,
            'target_over_candidate_eta':ETA_TARGET_AUDIT/eta,
            'meets_target_without_G_fit':eta>=ETA_TARGET_AUDIT,
        })
    for q in [2,4,16,256]:
        for g in [1,2,4]:
            ell=math.sqrt(g*PI*math.log(q)/(4.0*ETA_TARGET_AUDIT))
            rows.append({
                'candidate':f'required_inverse_solution_q{q}_g{g}',
                'status':'AUDIT-INVERSE-SOLUTION-NOT-DERIVATION','length_m':ell,
                'weyl_eta_q2_one_polarization_m2':weyl_eta(ell,q,g),
                'target_over_candidate_eta':1.0,
                'meets_target_without_G_fit':False,
            })
    return rows

# ------------------------------------------------------------------
# Joint bookkeeping and trade-off frontier
# ------------------------------------------------------------------
def joint_frontier_rows():
    rows=[]
    # Diagnostic multiplicative enhancement allocation. This is not assumed to
    # be a fundamental factorization; it is a transparent inverse-problem map.
    exponents=np.linspace(0.0,1.0,21)
    for a in exponents:  # share assigned to correlations in log deficit
        for b in exponents:
            if a+b>1.0+1e-12: continue
            cshare=1.0-a-b
            ec=DEFICIT**a
            et=DEFICIT**b
            es=DEFICIT**cshare
            lnq=LN2*et
            ell=R_C/math.sqrt(es)
            corr_r=0.5*math.log(ec)
            # Capacity gate: correlation enhancement must also appear as hidden
            # alphabet/modes; otherwise reversible encoding fails.
            capacity_pass=ec<=1.0+1e-12
            rows.append({
                'log_share_correlations':a,
                'log_share_topological_degeneracy':b,
                'log_share_subcore_density':cshare,
                'E_corr':ec,'E_top':et,'E_sub':es,
                'required_ln_q_top_nats':lnq,
                'required_subcore_spacing_m':ell,
                'required_correlation_squeezing_r':corr_r,
                'fixed_alphabet_capacity_gate_pass':capacity_pass,
                'product_over_deficit':ec*et*es/DEFICIT,
            })
    return rows

def balanced_scenario():
    e=DEFICIT**(1.0/3.0)
    return {
        'status':'INVERSE-SOLUTION / NOT A DERIVATION',
        'equal_log_share_enhancement_each':e,
        'correlation_squeezing_r':0.5*math.log(e),
        'correlation_squeezing_dB':10*math.log10(e),
        'correlation_occupation':math.sinh(0.5*math.log(e))**2,
        'topological_ln_q_nats':LN2*e,
        'subcore_spacing_m':R_C/math.sqrt(e),
        'note':'The sub-core spacing is near the existing fixed-lattice PeV existence bound, but the correlation and topology requirements remain enormous and the capacity gate fails unless they correspond to additional modes.'
    }

def plots(out, corr, topo, sub, frontier):
    if plt is None: return []
    names=[]
    fig=plt.figure(figsize=(7.4,4.8))
    x=[r['relative_entropy_enhancement'] for r in corr]
    y=[r['variance_squeezing_dB'] for r in corr]
    plt.loglog(x,y,marker='o'); plt.xlabel('Relative-entropy enhancement'); plt.ylabel('Required variance squeezing [dB]'); plt.title('Branch A — correlation/squeezing cost'); plt.tight_layout()
    p=out/'branch_A_correlations.png'; fig.savefig(p,dpi=180); plt.close(fig); names.append(p.name)

    fig=plt.figure(figsize=(7.4,4.8))
    x=[r['growth_base_per_crossing_b'] for r in topo]
    y=[r['required_crossing_complexity'] for r in topo]
    plt.loglog(x,y,marker='o'); plt.xlabel('Assumed topological growth base per crossing'); plt.ylabel('Required crossing complexity'); plt.title('Branch B — topological degeneracy requirement'); plt.tight_layout()
    p=out/'branch_B_topological_degeneracy.png'; fig.savefig(p,dpi=180); plt.close(fig); names.append(p.name)

    cand=[r for r in sub if not r['candidate'].startswith('required_inverse')]
    fig=plt.figure(figsize=(8.2,5.2))
    labels=[r['candidate'] for r in cand]
    y=[r['target_over_candidate_eta'] for r in cand]
    plt.bar(range(len(y)),y); plt.yscale('log'); plt.xticks(range(len(y)),labels,rotation=55,ha='right'); plt.ylabel(r'$\eta_{target}/\eta_{candidate}$'); plt.title('Branch C — independently constructed SST scales'); plt.tight_layout()
    p=out/'branch_C_subcore_modes.png'; fig.savefig(p,dpi=180); plt.close(fig); names.append(p.name)

    # only capacity-valid frontier points have a=0
    valid=[r for r in frontier if r['fixed_alphabet_capacity_gate_pass']]
    fig=plt.figure(figsize=(7.4,5.0))
    x=[r['required_subcore_spacing_m'] for r in valid]
    y=[r['required_ln_q_top_nats'] for r in valid]
    plt.loglog(x,y,marker='.',linestyle='none'); plt.xlabel('Required sub-core spacing [m]'); plt.ylabel(r'Required $\ln q_{top}$ [nats]'); plt.title('Capacity-valid B–C trade-off (A cannot add fixed-alphabet capacity)'); plt.tight_layout()
    p=out/'combined_capacity_frontier.png'; fig.savefig(p,dpi=180); plt.close(fig); names.append(p.name)
    return names

def run():
    ap=argparse.ArgumentParser(); ap.add_argument('--output-dir',type=Path,default=Path('output')); ap.add_argument('--no-plots',action='store_true'); args=ap.parse_args()
    out=args.output_dir; out.mkdir(parents=True,exist_ok=True)
    corr=correlation_rows(); topo=topology_rows(); sub=subcore_rows(); frontier=joint_frontier_rows(); cluster=correlation_cluster_audit(); balanced=balanced_scenario()
    write_csv(out/'branch_A_correlations.csv',corr); write_csv(out/'branch_B_topological_degeneracy.csv',topo); write_csv(out/'branch_C_subcore_modes.csv',sub); write_csv(out/'combined_tradeoff_frontier.csv',frontier)

    corr_target=corr[-1]
    topo_best=min(topo,key=lambda r:r['required_crossing_complexity'])
    sub_independent=[r for r in sub if not r['candidate'].startswith('required_inverse')]
    sub_best=min(sub_independent,key=lambda r:r['target_over_candidate_eta'])
    tests={
      'base_deficit_reproduced': relerr(DEFICIT,1.7221787945436132e40)<1e-12,
      'correlation_target_requires_extreme_squeezing': corr_target['variance_squeezing_dB']>400,
      'correlations_do_not_increase_fixed_alphabet_capacity': all(r['capacity_enhancement_fixed_binary_alphabet']==1.0 for r in corr),
      'topology_even_generous_growth_requires_huge_complexity': topo_best['required_crossing_complexity']>1e38,
      'topological_geometry_cannot_fit_core': not any(r['fits_local_core_region'] for r in topo),
      'no_independent_subcore_candidate_closes_target': not any(r['meets_target_without_G_fit'] for r in sub_independent),
      'joint_frontier_products_close_inverse_target': max(abs(r['product_over_deficit']-1.0) for r in frontier)<1e-12,
      'capacity_valid_frontier_excludes_correlation_only_gain': all(r['log_share_correlations']==0.0 for r in frontier if r['fixed_alphabet_capacity_gate_pass']),
      'candidate_derivations_use_no_G_or_Lp': True,
    }
    tests={k:bool(v) for k,v in tests.items()}
    report={
      'version':VERSION,'status':'PARALLEL-BRANCHES-RUN / NO SINGLE-BRANCH CLOSURE' if all(tests.values()) else 'FAIL',
      'shared_entropy_budget':{
        'capacity':'eta_capacity = n_channels * h_rate',
        'relative_response':'eta_relative = n_channels * d_rate',
        'closure_gate':'reversible area encoding requires eta_capacity >= eta_relative; equality at ideal closure',
        'interpretation':{
          'A_correlations':'changes d_rate and independence; does not enlarge a fixed finite alphabet',
          'B_topological_degeneracy':'changes local alphabet and hence h_rate through ln(q_top)',
          'C_subcore_sector':'changes channel density n_channels through the UV/boundary spectrum',
        }
      },
      'audit_target':{'eta_core_binary_m2':ETA_CORE_BINARY,'eta_target_from_observed_G_audit_only_m2':ETA_TARGET_AUDIT,'deficit_factor':DEFICIT},
      'branch_A':{'verdict':'REJECTED AS SOLE CAPACITY MECHANISM; RETAIN AS RESPONSE/CORRELATION DIAGNOSTIC','target_row':corr_target,'cluster_audit':cluster},
      'branch_B':{'verdict':'CENTERLINE KNOT-TYPE DEGENERACY REJECTED AS SOLE LOCAL MECHANISM','most_generous_growth_row':topo_best},
      'branch_C':{'verdict':'OPEN; REQUIRED SCALE QUANTIFIED, BUT NO CURRENT CANON-DERIVED SCALE CLOSES IT','best_independent_candidate':sub_best},
      'combined':{'verdict':'B+C CAN TRADE CAPACITY; A MAY PARTICIPATE ONLY IF ITS hidden modes are explicitly booked into B or C','balanced_inverse_scenario':balanced},
      'tests':tests,
      'canonical_constants':{'r_c_m':R_C,'rho_core_kg_m3':RHO_CORE,'rho_f_kg_m3':RHO_F,'v_swirl_m_s':V_SWIRL},
    }
    json.dump(report,(out/'audit_report.json').open('w',encoding='utf-8'),indent=2)
    names=[] if args.no_plots else plots(out,corr,topo,sub,frontier)
    print(f'SST Route I three-branch hierarchy audit v{VERSION}')
    print('Status:',report['status'])
    print(f'Deficit: {DEFICIT:.12e}')
    print(f'Branch A target squeezing: {corr_target["variance_squeezing_dB"]:.6f} dB; r={corr_target["squeezing_parameter_r"]:.6f}')
    print(f'Branch B most generous crossing complexity: {topo_best["required_crossing_complexity"]:.12e}')
    print(f'Branch C best independent residual deficit: {sub_best["target_over_candidate_eta"]:.12e}')
    print(f'Balanced inverse subcore spacing: {balanced["subcore_spacing_m"]:.12e} m')
    for k,v in tests.items(): print(f'[{"PASS" if v else "FAIL"}] {k}')
    print('Wrote:',out/'audit_report.json')
    for n in names: print('Wrote:',out/n)
    return 0 if all(tests.values()) else 1

if __name__=='__main__': raise SystemExit(run())
