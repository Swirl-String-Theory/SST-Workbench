# Derivation note: extracting alpha and beta

The classical thin-ring energy form is

\[
E=\frac12\rho\Gamma^2R\left[\ln\left(\frac{8R}{a}\right)-\alpha\right].
\]

Therefore, for any independent computation of \(E(R,a)\), the effective constant is

\[
\alpha_{\rm eff}(R/a)
=\ln\left(\frac{8R}{a}\right)-\frac{2E(R,a)}{\rho\Gamma^2R}.
\]

The absolute ring constant is the slender-ring intercept

\[
\alpha=\lim_{a/R\to0}\alpha_{\rm eff}(R/a).
\]

The impulse of a thin vortex ring is

\[
P=\rho\Gamma\pi R^2.
\]

Let

\[
q=\frac{d\ln a}{d\ln R}.
\]

Using \(U=dE/dP\) gives

\[
U=\frac{\Gamma}{4\pi R}\left[\ln\left(\frac{8R}{a}\right)-\alpha+1-q\right].
\]

Comparing to

\[
U=\frac{\Gamma}{4\pi R}\left[\ln\left(\frac{8R}{a}\right)-\beta\right]
\]

yields

\[
\boxed{\beta=\alpha-1+q.}
\]

Thus:

- \(q=0\): \(\beta=\alpha-1\)
- \(q=-1/2\): \(\beta=\alpha-3/2\)

The legacy NLS target \((\alpha,\beta)=(1.61,0.61)\) lies on the \(q=0\) line.
