# v0.1.1 local-path patch

Configured matrix directory:
`C:\workspace\projects\SST-Workbench\KnotPlot\KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0`

Configured KnotPlot shortcut:
`C:\workspace\projects\SST-Workbench\KnotPlot\KnotPlot.lnk`

All geometry outputs go under `out/`; batch console logs under `logs/`. Example:

```text
save KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0/out/F10_M_only_i00000.k float
coords KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0/out/F10_M_only_i00000.txt
```

Catalog runs still write under `catalog/<id>/`. Campaign root keeps scripts/docs only.

The master scripts also use the same subdirectory prefix for their `< ...kpc` includes.

## Batch launch (cmd → Python, like ridgerunner catalog batch)

Batch runners are thin wrappers around `run_matrix_batch.py`, same packaging as
`KnotPlot/ridgerunner/run_catalog_batch.cmd`. KnotPlot is invoked exactly like
`KnotPlot/run_build.cmd`:

```bat
"%KP_EXE%" -nog < script.kpc > logs\stem_console.log 2>&1
```

(exe + workdir from `KnotPlot.lnk`; no shortcut Arguments; one process per family
`.kpc`). Fail-fast if the process exits non-zero, or if the log shows load
failure **without** a later `knot loaded` / `knot saved` (workdir `knotplotrc.kps`
may print `nothing loaded` during startup before the script body runs).

```bat
run_one.cmd smoke_load_3_1.kpc
run_one.cmd 10_force_ablation_matrix.kpc
run_one.cmd catalog\knot_0.1\build_knot_0.1.kpc
run_core.cmd
run_all.cmd
run_all.cmd --dry-run
```

Interactive include masters (`98_run_core_matrix.kpc`, `99_run_all_matrix.kpc`)
remain for use inside the KnotPlot Command Window (`< 99_run_all_matrix.kpc`).
They are not used by the batch `.cmd` runners.

## Catalog conversion (`catalog/`)

The `catalog/` subdirectory holds converted copies of every unique
`KnotPlot/knots/*/build_{knot,link,torus}_*.kpc` script (49 total; `build_effort_active.kpc`
duplicates are skipped). Originals under `knots/` are untouched.

Transforms applied:

- `refine nbeads N` → `nbeads N` (absolute bead count; links/tori keep their N)
- checkpoints `analytic_D1` / `trial_001k` … `trial_015k` → `i00000` / `i01000` … `i15000`
- dual saves: `save …k float` plus `coords …txt` under
  `KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0/catalog/<id>/`

Regenerate with:

```bat
python convert_catalog_kpc.py
```

Master include for the full catalog ladder:

```bat
run_one.cmd 97_run_catalog.kpc
```

See `CATALOG.txt` for the id / bead-count listing.

---

# KnotPlot 3.1 Multi-Dynamics Relaxation Matrix v0.1.0

Goal: generate a controlled ensemble of relaxed trefoil geometries so that downstream
Euler / finite-core Biot-Savart / RPO / Floquet stability can be compared without
confounding force parameters.

## Fixed baseline

- seed: `load 3.1`
- beads: `nbeads 300`
- normalization: `fitto mindist 1.05`
- collision: `fast`
- close: 1.0
- max-dr: 0.01
- mechanical: on
- electric: on
- bending: on
- charge: 15
- Hooke: 1
- power: 6
- time increment: 15
- bencon: 1
- stusplit: 0
- dstep: 1
- bradius: 0.1
- cradius: 0.05
- energy model: MD

The explicit values `charge=15`, `hooke=1`, `timeincr=15`, `power=6` match the
values shown in KnotPlot's documented dynamics panel. They are written explicitly
so that a reset or installation-default change cannot silently change a campaign.

## Why `nbeads 300` instead of `refine nbeads 300`

The KnotPlot manual defines `nbeads value` as setting an absolute bead count, whereas
`refine N` multiplies the current bead count by N. For a controlled matrix we therefore
use `nbeads 300`.

## Why `ago`

`go N` runs relaxation in the background. `ago N` performs the requested number of
iterations atomically. Using `ago` guarantees that the following `save` is a true
checkpoint after the intended iteration count.

## Checkpoints

Most candidates save at cumulative iterations:

- 0
- 1,000
- 4,000
- 10,000

Each checkpoint writes:

- KnotPlot float geometry: `*.k`
- coordinate export: `*.txt`

The command window also computes MD energy, writhe, length, radius of gyration,
and the Alexander determinant (`alex -1`) at checkpoints.

## Families

- `10_force_ablation_matrix.kpc`: M / ME / MB / MEB
- `20_charge_sweep_ME.kpc`: q = 3.75, 7.5, 15, 30, 60
- `30_bend_sweep_MB.kpc`: bencon = 0.25, 0.5, 1, 2, 4
- `40_power_sweep_ME.kpc`: power = 4, 5, 6, 7, 8
- `50_close_sweep_MEB.kpc`: close = 0.50, 0.65, 0.80, 0.95, 1.00
- `60_hooke_sweep_ME.kpc`: Hooke = 0.25, 0.5, 1, 2, 4
- `70_maxdr_sweep_MEB.kpc`: max-dr = 0.0025, 0.005, 0.01, 0.02, 0.04
- `80_timeincr_sweep_MEB.kpc`: timeincr = 3.75, 7.5, 15, 22.5, 30
- `90_charge_anneal_MEB.kpc`: q = 60 -> 30 -> 15 -> 7.5 -> 0

## Recommended execution

For the scientifically most informative first pass:

    < 98_run_core_matrix.kpc

For the complete matrix:

    < 99_run_all_matrix.kpc

Or use `run_core.cmd` / `run_all.cmd` if `knotplot.exe` is on PATH.

## Interpretation

KnotPlot dynamics are candidate-generation dynamics only. Do NOT identify the
lowest KnotPlot MD energy with SST hydrodynamic stability.

After generation, all candidate geometries should be:
1. uniformly resampled in arc length,
2. normalized identically,
3. assigned the same circulation and finite-core radius,
4. tested blind under the same Euler / finite-core Biot-Savart stability pipeline.

The key question is whether stable downstream candidates cluster around particular
KnotPlot preparation variables or dimensionless geometric observables.

## References

R. G. Scharein, *KnotPlot Manual*, current KnotPlot documentation.
https://knotplot.com/doc/KnotPlot-Manual.pdf

R. G. Scharein, *Interactive Topological Drawing*, M.Sc. thesis,
University of British Columbia, 1998.
https://www.knotplot.com/thesis/thesis_letter.pdf

J. K. Simon, "Energy functions for polygonal knots",
Journal of Knot Theory and Its Ramifications 3 (1994), 299-320.
DOI: 10.1142/S0218216594000234