# Philosophical Prelude - ontology, operational SR, and scope

## Slide 1/15 - Why the Prelude exists

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- It prevents readers from importing GR/QFT primitives too early.
- It states the ontological shift before equations.
- It distinguishes interpretation from proof.

**Single slide message:** It prevents readers from importing GR/QFT primitives too early.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 2/15 - Ontological shift

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Underlying layer: Euclidean 3-space plus ordering parameter.
- Observed spacetime is reconstructed by vortex matter and signals.
- Substrate coordinates are not directly operational observables.

**Single slide message:** Underlying layer: Euclidean 3-space plus ordering parameter.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 3/15 - Relation to orthodox physics

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- GR, QFT, and EM remain constraint references.
- SST may reinterpret but cannot ignore measurements.
- Analogy alone is not validation.

**Single slide message:** GR, QFT, and EM remain constraint references.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 4/15 - Special relativity as operational starting point

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Alice and Bob measure with clocks, rulers, and torsion/light signals.
- They reconstruct invariant local two-way signal speed.
- Raw substrate coordinate speed is a different concept.

**Single slide message:** Alice and Bob measure with clocks, rulers, and torsion/light signals.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 5/15 - Local c from vortex-atom perspective

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- c_A^(2w)=2 ell_A / Delta tau_A defines local two-way speed.
- It must be independent of knot type, orientation, and polarization in the IR.
- This is a theorem target if derived from link dynamics.

**Single slide message:** c_A^(2w)=2 ell_A / Delta tau_A defines local two-way speed.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 6/15 - Why delay and topology matter

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Delay can select locked modes.
- Topology prevents arbitrary circulation creation or destruction.
- Classical discreteness needs stability mechanisms.

**Single slide message:** Delay can select locked modes.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 7/15 - Scope of v0.8.23

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Defines primitives, axioms, bridge sectors, status rules, and active research tracks.
- Does not claim complete Standard Model or Einstein dynamics.
- Does formalize falsification gates.

**Single slide message:** Defines primitives, axioms, bridge sectors, status rules, and active research tracks.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 8/15 - Interpretive summary

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Matter: trapped structured circulation/link response.
- Light: free transverse torsion/link excitation.
- Time: operational cycles of vortex matter.
- Gravity: pressure/clock-field bridge under strict gates.

**Single slide message:** Matter: trapped structured circulation/link response.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 9/15 - What classical means

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Classical does not mean point-particle Newtonian simplicity.
- It means medium dynamics before quantum postulates.
- Topology and spectra may still produce discreteness.

**Single slide message:** Classical does not mean point-particle Newtonian simplicity.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 10/15 - Observer dependence without subjectivity

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Different observers decompose intervals differently.
- The invariant object is operational interval/signal cone.
- Measurements are physical constructions.

**Single slide message:** Different observers decompose intervals differently.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 11/15 - Preferred foliation danger

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST retains underlying ordering.
- Operational Lorentz invariance must hide substrate velocity.
- Measurable preferred-frame residue is a falsifier.

**Single slide message:** SST retains underlying ordering.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 12/15 - Analogue gravity lesson

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Effective geometry follows from perturbation characteristics.
- Acoustic metrics do not directly apply to exact incompressible SST.
- Torsion/vorticity operators must be derived.

**Single slide message:** Effective geometry follows from perturbation characteristics.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 13/15 - Primary vs reconstructed

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Primary: substrate, circulation sectors, link relations.
- Reconstructed: local spacetime coordinates and signal speed.
- Bridged: EM, atoms, gravity, spectroscopy.

**Single slide message:** Primary: substrate, circulation sectors, link relations.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 14/15 - Prelude to axioms

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Prelude motivates axioms.
- Axioms state commitments.
- Later derivations must respect status labels.

**Single slide message:** Prelude motivates axioms.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.

## Slide 15/15 - Prelude closing message

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST is a physical-substrate reconstruction programme.
- It must recover local relativity, not deny it.
- Credibility depends on separating ontology, bridges, and tests.

**Single slide message:** SST is a physical-substrate reconstruction programme.

**Source anchors:** Philosophical Prelude; Axiom 7; Relational Time Framework.

**Visual specification:** Layered diagram: substrate -> vortex/link dynamics -> operational spacetime.

**Do not generate:** Do not say the substrate frame is directly observable or that SR is simply rejected.
