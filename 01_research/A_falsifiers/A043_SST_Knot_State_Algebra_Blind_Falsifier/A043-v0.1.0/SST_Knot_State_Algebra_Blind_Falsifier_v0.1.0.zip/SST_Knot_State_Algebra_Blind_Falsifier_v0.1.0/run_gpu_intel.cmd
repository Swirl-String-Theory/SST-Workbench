@echo off
setlocal
set SST_BACKEND=dpnp
call run_all_extended.cmd --backend dpnp %*
