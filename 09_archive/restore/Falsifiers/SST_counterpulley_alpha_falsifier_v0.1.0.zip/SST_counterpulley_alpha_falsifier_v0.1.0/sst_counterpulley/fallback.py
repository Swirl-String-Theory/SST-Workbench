from __future__ import annotations
import math
import numpy as np


def _as_curve(a, name: str) -> np.ndarray:
    x = np.asarray(a, dtype=float)
    if x.ndim != 2 or x.shape[1] != 3 or x.shape[0] < 3:
        raise ValueError(f"{name} must have shape (N,3), N>=3")
    return np.ascontiguousarray(x)


def interaction_hamiltonian(curve_a, curve_b, gamma_a: float, gamma_b: float, eps: float) -> float:
    a = _as_curve(curve_a, "curve_a")
    b = _as_curve(curve_b, "curve_b")
    if eps <= 0:
        raise ValueError("eps must be > 0")
    da = np.roll(a, -1, axis=0) - a
    db = np.roll(b, -1, axis=0) - b
    ma = 0.5 * (a + np.roll(a, -1, axis=0))
    mb = 0.5 * (b + np.roll(b, -1, axis=0))
    total = 0.0
    for i in range(a.shape[0]):
        r = ma[i] - mb
        den = np.sqrt(np.einsum("ij,ij->i", r, r) + eps * eps)
        total += float(np.sum((db @ da[i]) / den))
    return gamma_a * gamma_b * total / (8.0 * math.pi)


def induced_velocity(targets, filament, gamma: float, eps: float) -> np.ndarray:
    x = _as_curve(targets, "targets")
    q = _as_curve(filament, "filament")
    if eps <= 0:
        raise ValueError("eps must be > 0")
    dl = np.roll(q, -1, axis=0) - q
    mid = 0.5 * (q + np.roll(q, -1, axis=0))
    out = np.zeros_like(x)
    pref = gamma / (4.0 * math.pi)
    for i, xi in enumerate(x):
        r = xi - mid
        r2 = np.einsum("ij,ij->i", r, r) + eps * eps
        den = r2 * np.sqrt(r2)
        out[i] = pref * np.sum(np.cross(dl, r) / den[:, None], axis=0)
    return out
