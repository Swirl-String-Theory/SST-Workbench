param(
  [string]$BaseDir = "../../provenance/canon_snapshot_v0_8_28"
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Out = Join-Path $Here "patched"
$MainOld = Join-Path $BaseDir "SST_CANON-v0.8.28.tex"
$RtOld = Join-Path $BaseDir "SST_CANON-v0.8.28-research-track.tex"
if (!(Test-Path $MainOld) -or !(Test-Path $RtOld)) { throw "Missing v0.8.28 baseline files in $BaseDir" }
if (Test-Path $Out) { Remove-Item -Recurse -Force $Out }
New-Item -ItemType Directory -Path $Out | Out-Null
$MainOut = Join-Path $Out "SST_CANON-v0.8.30.tex"
$RtOut = Join-Path $Out "SST_CANON-v0.8.30-research-track.tex"
Get-Content -Raw (Join-Path $Here "0001-main-canon-v0.8.28-to-v0.8.30.diff") | patch --batch -o $MainOut $MainOld
if ($LASTEXITCODE -ne 0) { throw "Main patch failed" }
Get-Content -Raw (Join-Path $Here "0002-research-track-v0.8.28-to-v0.8.30.diff") | patch --batch -o $RtOut $RtOld
if ($LASTEXITCODE -ne 0) { throw "Research Track patch failed" }
Write-Host "Created $Out. Verify hashes with SHA256SUMS.outputs.txt."
