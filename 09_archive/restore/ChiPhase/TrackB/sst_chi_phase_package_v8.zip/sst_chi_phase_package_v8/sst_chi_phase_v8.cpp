#include <pybind11/pybind11.h>
#include <cmath>

namespace py = pybind11;

static double beta_from_alpha_q(double alpha, double q) {
    return alpha - 1.0 + q;
}

static double alpha_from_beta_q(double beta, double q) {
    return beta + 1.0 - q;
}

static double q_eff(double alpha, double beta) {
    return beta - alpha + 1.0;
}

static double smooth_c2(double a0) {
    return (2.0*a0*a0 + 13.0*a0 + 78.0) / 105.0;
}

static double smooth_c(double a0) {
    return std::sqrt(smooth_c2(a0));
}

static double a0_star() {
    return (std::sqrt(385.0) - 13.0) / 4.0;
}

PYBIND11_MODULE(sst_chi_phase_v8, m) {
    m.doc() = "SST chi phase v8 alpha/beta ring-constant derivation helpers";
    m.def("beta_from_alpha_q", &beta_from_alpha_q);
    m.def("alpha_from_beta_q", &alpha_from_beta_q);
    m.def("q_eff", &q_eff);
    m.def("smooth_c2_over_v2", &smooth_c2);
    m.def("smooth_c_over_v", &smooth_c);
    m.def("a0_star", &a0_star);
}
