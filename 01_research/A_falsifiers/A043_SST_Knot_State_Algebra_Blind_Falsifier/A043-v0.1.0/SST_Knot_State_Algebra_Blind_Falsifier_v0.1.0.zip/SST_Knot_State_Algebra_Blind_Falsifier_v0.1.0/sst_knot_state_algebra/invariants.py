from __future__ import annotations
from pathlib import Path
import csv,json,math

def load_table(path):
    p=Path(path); out=[]
    if not p.exists(): return out
    if p.suffix.lower()==".json":
        obj=json.loads(p.read_text(encoding="utf-8")); rows=obj if isinstance(obj,list) else obj.get("records",[])
        for r in rows: out.append(dict(r))
    else:
        with p.open(newline="",encoding="utf-8-sig") as f: out=[dict(r) for r in csv.DictReader(f)]
    return out

def snappy_twist_records(topologies):
    try: import snappy
    except Exception: return []
    rows=[]
    for k in topologies:
        try:
            M=snappy.Manifold(k); vol=float(M.volume())
            rows.append({"topology":k,"invariant":"hyperbolic_volume","value":vol,"provider":"SnapPy","provider_independent":True})
        except Exception: pass
    return rows

def numeric_records(rows):
    out=[]
    for r in rows:
        try:v=float(r.get("value"))
        except Exception: continue
        if math.isfinite(v): out.append({**r,"value":v})
    return out
