"""Convert catalog build_*.kpc scripts to iNNNNN checkpoint convention."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

MATRIX_PREFIX = "KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0"
CHECKPOINT_RE = re.compile(
    r"^echo CHECKPOINT (?P<label>\S+)[ \t]*$",
    re.MULTILINE,
)
SAVE_RE = re.compile(
    r"^save[ \t]+(?P<path>\S+)[ \t]*$",
    re.MULTILINE,
)
REFINE_RE = re.compile(r"^refine nbeads (?P<n>\d+)[ \t]*$", re.MULTILINE)
TORUS_RE = re.compile(r"^torus\s+\d+\s+\d+\s+(?P<n>\d+)\s*$", re.MULTILINE)
TRIAL_RE = re.compile(r"^trial_(\d+)k$")


def checkpoint_name(old: str) -> str:
    """Map analytic_D1 / trial_NNNk labels to iNNNNN cumulative iteration tags."""
    if old == "analytic_D1":
        return "i00000"
    m = TRIAL_RE.match(old)
    if not m:
        raise ValueError(f"Unrecognized checkpoint label: {old!r}")
    thousands = int(m.group(1))
    return f"i{thousands * 1000:05d}"


def catalog_id_from_path(path: Path) -> str:
    """Return catalog id from knots/<id>/build_*.kpc path."""
    return path.parent.name


def transform_kpc(text: str, catalog_id: str) -> str:
    """Rewrite a catalog build script to nbeads + dual save/coords + iNNNNN names."""
    out = REFINE_RE.sub(r"nbeads \g<n>", text)

    def _replace_checkpoint(match: re.Match[str]) -> str:
        return f"echo CHECKPOINT {checkpoint_name(match.group('label'))}"

    out = CHECKPOINT_RE.sub(_replace_checkpoint, out)

    def _replace_save(match: re.Match[str]) -> str:
        old_path = match.group("path")
        stem = Path(old_path).stem  # e.g. knot_0.1_analytic_D1
        # Replace trailing label after last underscore-ish checkpoint suffix.
        for old_label in ("analytic_D1", *[f"trial_{i:03d}k" for i in range(1, 16)]):
            suffix = f"_{old_label}"
            if stem.endswith(suffix):
                new_stem = stem[: -len(suffix)] + f"_{checkpoint_name(old_label)}"
                break
        else:
            raise ValueError(f"Cannot map save stem to checkpoint: {old_path!r}")
        base = f"{MATRIX_PREFIX}/catalog/{catalog_id}/{new_stem}"
        return f"save {base}.k float\ncoords {base}.txt"

    out = SAVE_RE.sub(_replace_save, out)
    return out


def iter_source_kpc(knots_dir: Path) -> list[Path]:
    """Yield unique build_{knot,link,torus}_*.kpc paths; skip build_effort_active.kpc."""
    paths: list[Path] = []
    for path in sorted(knots_dir.glob("*/build_*.kpc")):
        if path.name == "build_effort_active.kpc":
            continue
        if not path.name.startswith(("build_knot_", "build_link_", "build_torus_")):
            continue
        paths.append(path)
    return paths


def bead_count_from_text(text: str) -> int:
    """Extract absolute bead count from nbeads or torus line."""
    m = re.search(r"^nbeads (?P<n>\d+)\s*$", text, re.MULTILINE)
    if m:
        return int(m.group("n"))
    m = TORUS_RE.search(text)
    if m:
        return int(m.group("n"))
    m = REFINE_RE.search(text)
    if m:
        return int(m.group("n"))
    raise ValueError("No bead count found in script")


def write_catalog(
    knots_dir: Path,
    matrix_dir: Path,
) -> list[tuple[str, int, Path]]:
    """Convert all unique catalog scripts into matrix_dir/catalog/."""
    catalog_dir = matrix_dir / "catalog"
    catalog_dir.mkdir(parents=True, exist_ok=True)
    written: list[tuple[str, int, Path]] = []

    for src in iter_source_kpc(knots_dir):
        catalog_id = catalog_id_from_path(src)
        dest_dir = catalog_dir / catalog_id
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src.name
        text = src.read_text(encoding="utf-8")
        converted = transform_kpc(text, catalog_id)
        dest.write_text(converted, encoding="utf-8", newline="\n")
        beads = bead_count_from_text(converted)
        written.append((catalog_id, beads, dest))

    return written


def write_run_catalog(matrix_dir: Path, entries: list[tuple[str, int, Path]]) -> Path:
    """Write 97_run_catalog.kpc with < includes for every converted script."""
    lines = ["% Catalog conversion: all build_*.kpc under catalog/"]
    for catalog_id, _beads, dest in entries:
        rel = f"{MATRIX_PREFIX}/catalog/{catalog_id}/{dest.name}"
        lines.append(f"< {rel}")
    path = matrix_dir / "97_run_catalog.kpc"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return path


def write_catalog_txt(matrix_dir: Path, entries: list[tuple[str, int, Path]]) -> Path:
    """Write CATALOG.txt with ids, bead counts, and iNNNNN mapping."""
    lines = [
        "Catalog kpc conversion (iNNNNN checkpoints)",
        "==========================================",
        "",
        "Checkpoint mapping:",
        "  analytic_D1 -> i00000",
        "  trial_001k  -> i01000",
        "  trial_002k  -> i02000",
        "  ...",
        "  trial_015k  -> i15000",
        "",
        "Each script: ago 1000 between checkpoints (cumulative 0..15000).",
        "Saves: *.k float (KnotPlot state) + coords *.txt (centerline).",
        "",
        "Entries:",
    ]
    for catalog_id, beads, dest in entries:
        lines.append(f"  {catalog_id:16s}  nbeads={beads:4d}  {dest.name}")
    path = matrix_dir / "CATALOG.txt"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    matrix_default = Path(__file__).resolve().parent
    parser.add_argument(
        "--knots-dir",
        type=Path,
        default=matrix_default.parent / "knots",
        help="Source KnotPlot/knots directory",
    )
    parser.add_argument(
        "--matrix-dir",
        type=Path,
        default=matrix_default,
        help="Destination MultiDynamics matrix directory",
    )
    args = parser.parse_args(argv)

    entries = write_catalog(args.knots_dir, args.matrix_dir)
    write_run_catalog(args.matrix_dir, entries)
    write_catalog_txt(args.matrix_dir, entries)
    print(f"Wrote {len(entries)} catalog scripts under {args.matrix_dir / 'catalog'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
