#!/usr/bin/env python3
"""
s4_parity_lv_coefficients.py  —  AUDIT §3  (conversation turn 15, corrected turn 16)

CLAIM UNDER TEST
    Parity assignments:  v (polar), omega = curl v (axial), h = v.omega (PSEUDOSCALAR).
    Two independent photon LV operators at xi ~ r_c:
      - parity-EVEN dispersion  F box F :  needs a_gamma <~ 1e-24  (forbid => full Lorentz inv. = Tak III)
      - parity-ODD birefringence theta E.B: needs b_gamma <~ 1e-29 (forbid => PARITY, i.e. <h>=0)
    KEY ASYMMETRY: parity (<h>=0) alone kills birefringence (achievable in a Galilean fluid);
    only full Lorentz invariance kills the parity-even dispersion.

    CORRECTION (turn 16): a mode carrying helicity is NOT a vacuum carrying helicity.
    <h>=0 vacua support degenerate helicity eigenmodes (Maxwell photon). So 'torsion'
    is not automatically birefringent; the live obstruction is the parity-even F box F.

STATUS: [DERIVED]
"""
import numpy as np

hbar=1.054571817e-34; c=2.99792458e8; eV=1.602176634e-19
hbar_c_GeV_m = hbar*c/eV/1e9
r_c=1.40897017e-15
E0 = hbar_c_GeV_m/r_c                    # natural medium scale at xi=r_c (GeV)

bound_disp = 1e11    # parity-even quadratic (n=2) dispersion bound (GeV)
bound_bir  = 1e28    # parity-odd dimension-5 birefringence bound (GeV)

a_disp = (E0/bound_disp)**2              # F box F:        E_LV = hbar c/(xi sqrt(a))
b_bir  =  E0/bound_bir                   # theta E.B (dim5): E_LV = hbar c/(xi b)

print("="*78)
print("Parity check:  v polar,  omega=curl v axial,  h=v.omega PSEUDOSCALAR")
print("  => parity-odd photon term theta E.B exists iff <h> != 0  (E.B is a pseudoscalar)")
print("="*78)
print(f"natural medium scale at xi=r_c:  hbar c / r_c = {E0:.3f} GeV\n")
print(f"PARITY-EVEN dispersion (F box F):    need a_gamma <= {a_disp:.1e}   (forbid => FULL Lorentz inv = Tak III)")
print(f"PARITY-ODD  birefringence (theta E.B): need b_gamma <= {b_bir:.1e}   (forbid => PARITY, i.e. <h>=0)")
print(f"\nsuppression margins:  dispersion {bound_disp/E0:.1e} orders   birefringence {bound_bir/E0:.1e} orders")
print("\nKEY ASYMMETRY:")
print("  parity (<h>=0) ALONE forbids birefringence  -> achievable in a Galilean fluid")
print("  only FULL Lorentz inv. forbids F box F       -> = Tak III, not a fluid symmetry")

assert a_disp < 1e-20 and b_bir < 1e-25
print("\nALL §3 CHECKS PASSED.")
