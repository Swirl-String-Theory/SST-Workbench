import bpy, os, glob
BASE = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else os.getcwd()
PARTS = sorted(glob.glob(os.path.join(BASE, "gear_*_half_*.stl")))
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for path in PARTS:
    bpy.ops.wm.stl_import(filepath=path)
bpy.context.scene.unit_settings.system = 'METRIC'
bpy.context.scene.unit_settings.scale_length = 0.001
print("Imported split click-fit triple gear kit.")