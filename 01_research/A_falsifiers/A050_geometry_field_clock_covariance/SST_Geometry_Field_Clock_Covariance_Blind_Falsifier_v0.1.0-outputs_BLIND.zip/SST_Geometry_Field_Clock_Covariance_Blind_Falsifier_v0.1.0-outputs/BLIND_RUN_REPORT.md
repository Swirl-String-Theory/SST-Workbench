# Blind reference-run report

Verdict: `CORRELATED_CLOSURE_SCALING_DETECTED`

Qualified families: 3 / 4
Discrete divergence gate: 1
Resolution gate: 1
Resolution exponent span: 0.431698

## Fitted exponents

| ID | scalar n_space | R^2 | direct-vector n_space | shuffled-null n_space | temporal m_time | temporal R^2 |
|---|---:|---:|---:|---:|---:|---:|
| G0001 | 1.721118 | 0.777461 | 1.737077 | 3.012072 | 2.000000 | 1.000000 |
| G0002 | 1.360483 | 0.900632 | 1.626430 | 3.043046 | 1.905576 | 0.999949 |
| G0003 | 1.327825 | 0.970613 | 1.543088 | 3.020085 | 1.723090 | 0.999715 |
| G0004 | 1.812012 | 0.980658 | 1.761767 | 3.015926 | 2.022566 | 0.999993 |

## Interpretation boundary

The blind verdict tests only whether the scalar closure shows robust correlated finite-volume scaling relative to a shuffled spatial null under the preregistered numerical gates. It does not establish an absolute clock scale or any SST-specific parameter relation.

The reference campaign uses generated closed curves. Production certification requires external Workbench geometries plus stronger grid/core/box sensitivity ladders.
