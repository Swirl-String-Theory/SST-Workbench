@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo SST Katlas curated wiki snapshot
echo all knots + links through 7 crossings + SST interest list
echo ============================================================
if not exist .venv\Scripts\python.exe (
  echo Creating virtual environment...
  py -3 -m venv .venv || exit /b 1
)
.venv\Scripts\python.exe -m katlas_source.cli --config config.json fetch-profile sst_curated %*
exit /b %ERRORLEVEL%
