"""Pure-Python kernel for SST chi-phase v9: alpha/beta ring-constant intercept audit.

Status: Research Track scaffolding.  This module derives and tests the
log-subtracted intercept machinery for vortex-ring constants alpha and beta.
It does not solve the full NLSE/GP vortex-core energy.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, List, Sequence, Tuple

PHI = (1.0 + math.sqrt(5.0)) / 2.0
A0_STAR = (math.sqrt(385.0) - 13.0) / 4.0


@dataclass(frozen=True)
class RingConstantTarget:
    name: str
    alpha: float
    beta: float
    q_label: str
    source: str = "legacy notebook target"


def beta_from_alpha_q(alpha: float, q: float) -> float:
    """Robust v8 relation: beta = alpha - 1 + q."""
    return alpha - 1.0 + q


def q_from_alpha_beta(alpha: float, beta: float) -> float:
    """Infer q = d ln a / d ln R from alpha,beta via beta=alpha-1+q."""
    return beta - alpha + 1.0


def alpha_eff_from_energy(E: float, rho: float, Gamma: float, R: float, a: float) -> float:
    """Extract alpha_eff from E = 1/2 rho Gamma^2 R [ln(8R/a)-alpha]."""
    return math.log(8.0 * R / a) - (2.0 * E) / (rho * Gamma * Gamma * R)


def energy_from_alpha(alpha: float, rho: float, Gamma: float, R: float, a: float) -> float:
    """Generate ring energy from a chosen alpha constant. Useful as a roundtrip check."""
    return 0.5 * rho * Gamma * Gamma * R * (math.log(8.0 * R / a) - alpha)


def energy_with_slender_corrections(alpha: float, rho: float, Gamma: float, R: float, a: float,
                                    A: float = 0.35, B: float = -0.12) -> float:
    """Synthetic slender-ring energy with known intercept alpha.

    This is not a physical derivation; it tests whether the fitting machinery
    recovers the intercept when finite-epsilon corrections are present.
    """
    eps = a / R
    correction = A * eps * eps * math.log(1.0 / eps) + B * eps * eps
    return 0.5 * rho * Gamma * Gamma * R * (math.log(8.0 * R / a) - alpha + correction)


def smooth_matched_c2_over_v2(a0: float) -> float:
    """Analytic v6 result for f=x[a0+(3-2a0)x^2+(a0-2)x^4]."""
    return (2.0 * a0 * a0 + 13.0 * a0 + 78.0) / 105.0


def smooth_matched_c_over_v(a0: float) -> float:
    return math.sqrt(max(0.0, smooth_matched_c2_over_v2(a0)))


def smooth_matched_profile(x: float, a0: float) -> float:
    return x * (a0 + (3.0 - 2.0 * a0) * x * x + (a0 - 2.0) * x**4)


def default_targets() -> List[RingConstantTarget]:
    return [
        RingConstantTarget("solid/fixed core, constant volume", 7.0/4.0, 1.0/4.0, "q=-1/2"),
        RingConstantTarget("hollow core, constant volume", 2.0, 1.0/2.0, "q=-1/2"),
        RingConstantTarget("hollow core, constant pressure", 3.0/2.0, 1.0/2.0, "q=0"),
        RingConstantTarget("hollow core, surface tension", 1.0, 0.0, "q=0"),
        RingConstantTarget("NLS legacy target", 1.61, 0.61, "q=0"),
    ]


def linear_least_squares_3cols(X: Sequence[Tuple[float, float, float]], y: Sequence[float]) -> Tuple[float, float, float]:
    """Tiny 3-parameter normal-equation least squares without numpy."""
    M = [[0.0]*3 for _ in range(3)]
    b = [0.0]*3
    for row, yi in zip(X, y):
        for i in range(3):
            b[i] += row[i] * yi
            for j in range(3):
                M[i][j] += row[i] * row[j]
    # Gaussian elimination
    A = [M[i] + [b[i]] for i in range(3)]
    for col in range(3):
        pivot = max(range(col, 3), key=lambda r: abs(A[r][col]))
        A[col], A[pivot] = A[pivot], A[col]
        pv = A[col][col]
        if abs(pv) < 1e-300:
            raise ValueError("singular least-squares normal matrix")
        for k in range(col, 4):
            A[col][k] /= pv
        for r in range(3):
            if r == col:
                continue
            fac = A[r][col]
            for k in range(col, 4):
                A[r][k] -= fac * A[col][k]
    return A[0][3], A[1][3], A[2][3]


def fit_alpha_intercept(eps_values: Sequence[float], alpha_eff_values: Sequence[float]) -> Tuple[float, float, float]:
    """Fit alpha_eff(eps)=alpha0 + A eps^2 log(1/eps)+B eps^2."""
    X = []
    for eps in eps_values:
        X.append((1.0, eps*eps*math.log(1.0/eps), eps*eps))
    return linear_least_squares_3cols(X, alpha_eff_values)


def synthetic_intercept_rows(alpha: float, eps_values: Sequence[float], rho: float = 1.0,
                             Gamma: float = 1.0, R: float = 1.0,
                             A: float = 0.35, B: float = -0.12):
    rows = []
    for eps in eps_values:
        a = eps * R
        E = energy_with_slender_corrections(alpha, rho, Gamma, R, a, A=A, B=B)
        alpha_eff = alpha_eff_from_energy(E, rho, Gamma, R, a)
        rows.append({"eps": eps, "R_over_a": 1.0/eps, "E": E, "alpha_eff": alpha_eff})
    return rows


def target_analysis_rows(targets: Sequence[RingConstantTarget] | None = None):
    targets = targets or default_targets()
    rows = []
    for t in targets:
        q_eff = q_from_alpha_beta(t.alpha, t.beta)
        beta_pred = beta_from_alpha_q(t.alpha, q_eff)
        c_at_alpha_as_a0 = smooth_matched_c_over_v(t.alpha)
        rows.append({
            "name": t.name,
            "alpha": t.alpha,
            "beta": t.beta,
            "q_eff": q_eff,
            "q_label": t.q_label,
            "beta_pred": beta_pred,
            "beta_residual": t.beta - beta_pred,
            "alpha_minus_a0_star": t.alpha - A0_STAR,
            "alpha_minus_phi": t.alpha - PHI,
            "c_over_v_if_a0_eq_alpha": c_at_alpha_as_a0,
            "c_minus_1_if_a0_eq_alpha": c_at_alpha_as_a0 - 1.0,
        })
    return rows
