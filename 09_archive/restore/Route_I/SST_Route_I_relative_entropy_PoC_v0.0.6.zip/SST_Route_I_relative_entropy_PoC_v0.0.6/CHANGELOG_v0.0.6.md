# Changelog v0.0.6

## Added

- one shared compact-\(U(1)\) cellular foundation for branches A, B, and C;
- exact \(D_1D_0=0\) and \(D_2D_1=0\) audits;
- Betti-number and harmonic-sector certification;
- generalized curl--curl spectrum after Gauss/gauge reduction;
- boundary trace-rank channel counting;
- common-mode covariance and coherent relative-entropy response;
- compact-defect dilution scan;
- blind/frozen configuration file;
- CANON Research-Track insertion patch.

## Changed

- the v0.0.5 multiplicative hierarchy map is no longer used as a model;
- correlations may only act on modes counted by the shared ledger;
- global topology and local defects are booked separately;
- the physical adjacency length is kept symbolic.

## Result

\[
\nu_{\mathrm{ch}}=2,
\qquad
\eta_{\mathrm{cap}}^{(2)}=2\ln2/a_\star^2.
\]

## Deferred

- nonlinear derivation of \(a_\star,I_\ell,K_\ell\);
- edge-rewiring dynamics;
- nonperturbative deconfinement;
- blind SI prediction of the area coefficient.
