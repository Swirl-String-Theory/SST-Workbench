from __future__ import annotations
import json, pathlib, tempfile
import numpy as np
from sst_eft import native
from sst_eft.gates import *

def trefoil(n=1200):
 t=np.linspace(0,2*np.pi,n,endpoint=False)
 # Smooth torus-knot embedding, topology only; not an SST physical solution.
 return np.c_[(2+np.cos(3*t))*np.cos(2*t),(2+np.cos(3*t))*np.sin(2*t),np.sin(3*t)]

def main():
 root=pathlib.Path(__file__).resolve().parent; cfg=json.loads((root/"config"/"basic.json").read_text())
 p=trefoil(); q=native.resample(p,256); m=native.metrics(q); assert m["length"]>0 and np.isfinite(native.writhe(q))
 g1=gate_g1_relabel(p,cfg,1234); g2=gate_g2_phase_shift(p,cfg,1234); g3=gate_g3_derivative_hierarchy(p,cfg); g4=gate_g4_redundancy(p,cfg)
 print(g1["status"],g1["worst"]); print(g2["status"],g2["max_rate_difference_rad_s"]); print(g3["status"],g3["top_pair"]); print(g4["status"],g4["ibp_rel_residual"])
 if g2["status"]!="STRUCTURAL_PASS" or g4["status"]!="STRUCTURAL_PASS": raise SystemExit("structural self-test failed")
 # Native round-trip and exact blind mechanics are the hard self-test; G1/G3 may be threshold-sensitive for synthetic polygon sampling and are reported, not required.
 print("SELFTEST OK")
if __name__=="__main__": main()
