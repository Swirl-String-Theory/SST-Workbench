# A049 v0.4.1 blind report

Backend: **native**
Pipeline: **PREQUALIFICATION_QUALIFIED_WAVE_STAGE_SKIPPED**
Research question: **INCONCLUSIVE_BACKGROUND_NOT_RELATIVE_EQUILIBRIUM_AT_V0.4.1**

## Relative-equilibrium prequalification

- primary grid N = 15
- fitted translation velocity = [-0.14652517546290328, 0.04299853450365917, -0.05165056294689746]
- translation residual = 9.929293e-01
- raw state change at t=0.500 = 9.139251e-01
- co-moving state change = 9.108581e-01
- higher-resolution grid N = 21
- higher-resolution translation residual = 9.943029e-01
- residual resolution delta = 1.373550e-03
- wave stage executed = False

## Qualification gates

- Q01_STATIC_TRANSVERSE_SAMPLING: PASS
- Q02_STATIC_A2_RECOVERY: PASS
- Q03_REL_EQ_INITIAL_SPECTRAL_RESOLUTION: PASS
- Q04_REL_EQ_RESOLUTION_CHECK_INITIAL_SPECTRAL_RESOLUTION: PASS
- Q05_BARE_REST_EULER_NO_WAVE: PASS
- Q06_REL_EQ_RESIDUAL_RESOLUTION_STABILITY: PASS

## Precondition gates

- P01_BACKGROUND_TRANSLATION_RESIDUAL: FAIL
- P02_BACKGROUND_COMOVING_PERSISTENCE: FAIL
- P03_BACKGROUND_RELATIVE_EQUILIBRIUM: FAIL

## Hypothesis gates

- NOT EVALUATED: relative-equilibrium precondition failed; expensive wave stage intentionally skipped.

## Target-free hierarchy observable

- qualified before reveal = False
- chi_wave = NOT_REACHED

## Scope guard

v0.4.1 is a qualification-first patch. A non-stationary structured Euler background cannot be used to make a physical claim about a bulk normal mode. The background is therefore tested against the translational relative-equilibrium condition before the costly evolving and frozen tangent-wave stages are run.
