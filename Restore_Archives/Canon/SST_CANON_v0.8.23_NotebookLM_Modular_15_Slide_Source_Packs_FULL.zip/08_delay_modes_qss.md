# Delay, mode selection, response theory, and QSS

## Slide 1/15 - Delay as physical primitive

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Circulation paths have finite response time.
- Delayed self-interaction can lock modes.
- Delay is not solver lag.

**Single slide message:** Circulation paths have finite response time.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 2/15 - Delayed self-interaction dynamics

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- State interacts with earlier state through a kernel.
- Locked branches depend on delay time.
- Stability must be analysed.

**Single slide message:** State interacts with earlier state through a kernel.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 3/15 - Discrete stable modes

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Allowed modes satisfy phase closure or fixed-point conditions.
- Branches can be stable or unstable.
- Discreteness may emerge without quantum postulates.

**Single slide message:** Allowed modes satisfy phase closure or fixed-point conditions.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 4/15 - Delay-induced quantization

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Delay imposes phase compatibility.
- Nonlinearity/topology can isolate branches.
- It remains a bridge until tied to observed spectra.

**Single slide message:** Delay imposes phase compatibility.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 5/15 - NLSE bridge

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Amplitude-phase decompositions can resemble nonlinear wave equations.
- This is effective bridge material.
- Do not import quantum axioms.

**Single slide message:** Amplitude-phase decompositions can resemble nonlinear wave equations.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 6/15 - Response framework

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Perturbations excite resonances.
- Kernels determine linewidth, decay, and multi-mode behavior.
- Response connects dynamics to observables.

**Single slide message:** Perturbations excite resonances.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 7/15 - Resonance selection

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Not every mathematical mode is observable.
- Coupling, topology, damping, symmetry select modes.
- Selection rules need justification.

**Single slide message:** Not every mathematical mode is observable.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 8/15 - Time-domain kernel

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Kernels encode finite-memory response.
- They include causal tails and nonlocal-in-time behavior.
- Useful for classical substrate modelling.

**Single slide message:** Kernels encode finite-memory response.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 9/15 - Swirl impedance and linewidth

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Linewidth measures damping/leakage.
- Impedance measures acceptance/reflection of excitation.
- Jump impedance needs response language.

**Single slide message:** Linewidth measures damping/leakage.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 10/15 - Layered relaxation

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Decay can occur through several channels.
- Single exponentials may be insufficient.
- Mode coupling must be separated from artifacts.

**Single slide message:** Decay can occur through several channels.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 11/15 - QSS introduction

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- QSS treats open resonances as poles/robust modes.
- It separates closed normal modes from open response.
- It requires operator/resolvent certification.

**Single slide message:** QSS treats open resonances as poles/robust modes.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 12/15 - Pseudospectra

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Non-normal operators can be spectrum-sensitive.
- Pseudospectra measure robustness.
- Do not overinterpret unstable numerical peaks.

**Single slide message:** Non-normal operators can be spectrum-sensitive.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 13/15 - Quadratic combination modes

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Nonlinear perturbations generate sums/differences.
- Amplitude scaling tests combinations.
- Prevents false new-mode claims.

**Single slide message:** Nonlinear perturbations generate sums/differences.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 14/15 - Mode falsifiers

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- No stable branch fails delay mechanism.
- No robust pole fails QSS.
- No convergence fails numerical mode.
- Wrong linewidth/coupling fails physical ID.

**Single slide message:** No stable branch fails delay mechanism.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.

## Slide 15/15 - Delay/QSS closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Topology supplies carriers.
- Delay and response select persistent modes.
- QSS certifies robust open resonances.

**Single slide message:** Topology supplies carriers.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; Quasinormal Swirl Spectroscopy.

**Visual specification:** Feedback loop into spectral pole/resolvent diagram.

**Do not generate:** Do not call every FFT peak a physical mode.
