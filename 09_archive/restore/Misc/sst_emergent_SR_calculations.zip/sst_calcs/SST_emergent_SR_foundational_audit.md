# SST Foundational-Layer Audit: Does the Substrate Yield Emergent Special Relativity?

**Scope.** Consolidates the reasoning chain on whether SST's substrate dynamics produce
emergent special relativity (a single universal `c`, exact `γ` for the swirl clock) and
whether the photon and matter sectors can be made consistent with Lorentz-invariance (LV)
bounds. This is the layer *logically prior* to Papers I–IV (α, mass, EM): if it fails,
calling `α_cell` "the fine-structure constant" loses the Minkowski/lightcone structure it
presupposes.

**Date:** 2026-06-23  **Status:** working audit, not a canon patch.

**Label legend.**
`[ORTHODOX]` established physics/math · `[DERIVED]` follows from stated SST assumptions ·
`[DERIVED NEGATIVE]` a route is *closed* by explicit argument · `[OPEN]` not yet settled ·
`[RETRACTED]` a claim I previously made and now withdraw · `[DECISION]` an ontological
choice with a price, not a calculation · `[UNBUILT]` requires constructing new structure
the corpus has not specified.

---

## 0. Dependency spine

```
v_↺ tangential (not causal)            [DERIVED, prior turns]
        │
§1  Boost algebra: Galilei vs Poincaré  ── İnönü–Wigner axis
        │   (three branches; Tak II = branch 2 chosen)        [DECISION]
        │
§2  Tak II ⇒ c_s = c ⇒ ξ = ℏ/(m_eff c) ⇒ E_LV = m_eff c²
        │   n=2 dispersion bound ⇒ ξ ≠ r_c forced            [DERIVED]
        │
§3  Photon as protected transverse mode
        │   σ-decoupling [DERIVED] · F□F survives [OPEN]
        │   birefringence self-undermining claim             [RETRACTED]
        │
§4  Volovik route: photon = emergent U(1) at nodal points
        │   M_* decouples from r_c                             [DERIVED — the real win]
        │
§5  Gate A (leading isotropy) before Gate C (a_γ)
        │   cube = 2-design ✔ dim-4 · dim-6 survives          [DERIVED]
        │   matter isotropy = the binding gate                [DERIVED]
        │
§6  Electron = trefoil knot-soliton
        │   static trefoil anisotropic [DERIVED NEGATIVE]
        │   O-orientational delocalization isotropizes        [DERIVED, conditional]
        │   L_K orientation-invariant ⇒ α-program survives    [RETRACTED prior claim]
        │
§7  Foundational target space                                 [OPEN / UNBUILT]
            + metric locking c_e = c_γ                        [OPEN, load-bearing]
```

---

## 1. Boost algebra — the Galilei/Poincaré diagnostic

The structure constants of `[K_i,K_j]` and `[K_i,P_j]` decide everything; they are read off
without assuming `γ`.

- **Candidate A — incompressible Euler / non-relativistic GP.** Boost generator
  `K_i^G = m∫x_i|ψ|² − tP_i`; `[K_i^G,K_j^G]=0`, `[K_i^G,P_j]=iℏMδ_ij`. **Galilei (Bargmann)**,
  mass as central charge. A moving vortex is a *different* solution, not a `1/γ`-contracted
  rest state → no `γ`. `[DERIVED]`
- **Candidate B — relativistic GP (□ in the action).** `[K_i^L,K_j^L]=−(i/c²)ε_ijk J_k`,
  `[K_i^L,P_j]=(i/c²)δ_ij H`. **Poincaré**; Nielsen–Olesen strings contract by `γ`. `[DERIVED]`
- **İnönü–Wigner.** Galilei is the `c→∞` contraction of Poincaré. Strict incompressibility
  *is* `c_s→∞` in the pressure sector, so incompressibility forces the Galilei contraction.
  `[ORTHODOX]`

**Three-branch verdict** `[DERIVED]`:
1. Strict incompressible → pure Galilei, no SR for anything → falsified as a theory of
   relativistic matter.
2. Non-relativistic GP (finite `c_s`, Schrödinger time-derivative) → fundamental substrate is
   Galilei; only the linearized phonon sector carries *approximate* Poincaré(`c_s`) at low `k`
   via the acoustic metric. Vortices stay Galilean; phonons are approximately Lorentz. This is
   the Volovik situation; SST-23 dual-vacuum is its phenomenology.
3. Relativistic GP → exact Poincaré, but "incompressible fluid" is gone.

No fourth option: İnönü–Wigner forbids a Galilean fluid substrate *and* exact-Lorentz matter
simultaneously. You cannot have both (a) absolute Euclidean 3D+t and (b) exact emergent SR for
matter. **Tak II = branch 2 chosen.** `[DECISION]`

*Numerically verified:* explicit generators and commutators for both algebras.

---

## 2. LV dispersion scale and the healing length

- Tak II requires the emergent signal speed = light speed, `c_s = c`. With
  `ξ = ℏ/(m_eff c_s)`, this gives `E_LV = ℏc/ξ = m_eff c²`: **the LV scale is the rest energy
  of the condensate quantum.** `[DERIVED]`
- Bogoliubov dispersion `ω² = c²k²(1+(kξ/2)²)` is **quadratic (n=2)**. The binding constraint
  is the n=2 photon time-of-flight bound, `E_LV ≳ 10¹⁰–10¹¹ GeV`, *not* the linear (n=1) bound.
  `[DERIVED]`
- `ξ = r_c` → `E_LV = 140 MeV` → excluded by ~11 orders (a 10 GeV photon sits ~70× above the
  scale). `ξ = 10⁻³ r_c` (140 GeV) still excluded by ~8 orders. **Safety requires
  `ξ ≲ 10⁻¹¹ r_c`, i.e. `m_eff ≳ 10¹⁰ GeV`** (full safety ~`m_Planck`). `[DERIVED / FALSIFIED for ξ=r_c]`
- **Ontology consequence:** the swirl/Compton/`r_c` sector is IR-emergent ~11–20 orders below
  the medium scale (analog-gravity-like). The medium is *not* the fm-scale object the papers
  describe; `r_c` is a defect scale, not the substrate scale. `[DERIVED]`

**Self-corrections (turn 14):**
- The Bogoliubov sign is **superluminal** (`v_g = c(1+(3/8)(kξ)²)`): high-energy photons arrive
  *early*. Definite sign ⇒ falsifiable. `[DERIVED]`
- My earlier worry of a naive `(v_lab/c)² ~ 10⁻⁶` frame anisotropy was **overstated**: the
  leading acoustic metric is exactly Lorentzian (uniform flow is Painlevé–Gullstrand, removable),
  so anisotropy lives only in the dispersive `(kξ)²` sector. The GRB dispersion bound binds, not
  the optical resonator bound. `[RETRACTED overstatement]`

*Numerically verified:* `E_LV`, `m_eff`, and dispersion at 10 GeV across the `ξ` cases.

---

## 3. Photon as a protected transverse mode (the ξ~r_c escape attempt)

- **σ-sector decoupling.** A strictly transverse mode (`k·A_T = 0`) in an isotropic,
  parity-even condensate does **not** inherit the longitudinal `(kξ)²` healing term; the
  quadratic propagator is block-diagonal. `[DERIVED, under isotropy + no density mixing]`
- **But F□F is not thereby forbidden.** The parity-even operator `F_{μν}□F^{μν}` is allowed by
  every symmetry except exact LI. Bianchi `dF=0` is *kinematic* and does not constrain the
  dynamical action. At `ξ~r_c` it needs `a_γ ≲ 10⁻²⁴` (a symmetry zero). Forbidding it = exact
  LI = Tak III. `[DERIVED NEGATIVE for Bianchi/Kelvin-closure as the protection]`
- **Birefringence sub-thread.** `h = v·ω` is a pseudoscalar; `⟨h⟩≠0 ⟺ θE·B birefringence`.
  I claimed "torsion ⇒ `⟨h⟩≠0` ⇒ self-undermining."
  **`[RETRACTED]`** — a mode *carrying* helicity is not a vacuum *carrying* helicity. A
  parity-even vacuum (`⟨h⟩=0`) supports degenerate helicity eigenmodes; the Maxwell photon is
  the existence proof (individual photons are helical, the vacuum is not optically active).
  Torsion is therefore **not** automatically birefringent.

**Net:** `ξ~r_c` survives only if `a_γ = 0` by emergent-LI / fixed-point protection; the
parity-even dispersion operator, not birefringence, is the live obstruction. `[OPEN]`

*Numerically verified:* parity-even (`a_γ`) vs parity-odd (`b_γ`) coefficient suppression at
`ξ=r_c`, and the parity assignment `v` (polar), `ω` (axial), `h` (pseudoscalar).

---

## 4. Volovik route — the genuine win

- Photon = emergent `U(1)` gauge mode near nodal/Fermi points, **not** the raw `l̂`-Goldstone
  (which would be a material wave with multi-speed dispersion). `[DECISION, correct]`
- The photon's UV cutoff becomes `M_*` (the nodal linearity scale), **decoupled from `r_c`**.
  This escapes the 140 MeV death: the dispersion gate becomes `M_*c²/√a_γ ≳ 10¹⁰–10¹¹ GeV`,
  not `ℏc/r_c ≳ …`. `[DERIVED — this is why the route lives]`
- `a_γ` is no longer a free EFT coefficient but a *calculable* deviation from Fermi-point
  linearity. `[REFRAME]`

---

## 5. Gate A (leading isotropy) precedes Gate C (a_γ)

- **³He-A is rejected as a final vacuum.** Two Weyl nodes on one `l̂`-axis give leading
  (dim-4) anisotropy `c_∥/c_⊥ ~ 10³`. `[DERIVED NEGATIVE for two-node uniaxial]`
- **Spherical 2-design condition.** Isotropic leading photon metric ⟺
  `Σ_a w_a n_a^i n_a^j = (W/3)δ^{ij}`. The 8-node cube satisfies it (`Σ = (8/3)δ`). `[DERIVED]`
- **Cube is a 3-design, not a 4-design.** dim-6 (`k⁴`) cubic anisotropy survives
  (cubic-anisotropy `= −0.222`). Killing it needs the **icosahedron** (5-design,
  cubic-anisotropy `= 0`). `[DERIVED]`
- **Gate ordering corrected:** Gate A (isotropy) before Gate C (`a_γ`). `a_γ` is not the first
  gate. `[DERIVED]`
- **Hidden condition:** a *single democratic* `U(1)` coupling equally to all nodes (else
  multiple emergent gauge fields, not one photon). `[OPEN]`
- **The binding gate is matter isotropy, not `a_γ`.** The photon averages over nodes (vacuum
  polarization sum); a single-node Weyl *fermion* lives at one node and sees that node's
  anisotropic cone. Matter-sector rotation/LV is bounded ~`10⁻²⁹–10⁻³³` — tighter than the
  photon. Node-locking to isotropize fermions → Nielsen–Ninomiya gaps them; RG-isotropization
  is non-generic and fails in ³He-A. `[DERIVED — matter isotropy binds]`

*Numerically verified:* 2nd- and 4th-moment tensors for tetra/octa/cube/icosa node sets.

---

## 6. Electron = trefoil knot-soliton

- **Escape:** the electron is a knot-soliton sampling the node set, not a single-node Weyl
  fermion. Preserves the corpus identity (matter = knot). `[DECISION, SST-consistent]`

**Self-corrections (turn 18) — both withdrawals of my own prior overclaims:**
- **`L_K` is orientation-invariant.** Ropelength is a property of the knot *type*, not its
  spatial orientation. Orientational delocalization does **not** blur `L_K`, so the α-program
  (`α⁻¹ ≈ (8π/3)·L_K`) survives delocalization. `[RETRACTED: "delocalization kills sharp L_K"]`
- Consequently the "**irreconcilable fork** between isotropy and the chiral-knot taxonomy" was
  too strong. They reconcile. `[RETRACTED]`

**Mechanism correction (against the "3D sampling" intuition):**
- The *static* trefoil is **anisotropic**: gyration tensor eigenvalues `0.28 / 1.36 / 1.36`,
  anisotropy ratio ~4.9. A wiggly 3D curve is not isotropic; it has a C₃ axis. Symmetry of the
  effective metric = symmetry of the configuration = C₃/D₃ → uniaxial. Only O/I/SO(3) force
  rank-2 isotropy. `[DERIVED NEGATIVE for static-trefoil isotropy]`
- **Working mechanism:** quantum orientational delocalization over the chiral cubic group `O`.
  The `O`-average of the uniaxial tensor is exactly isotropic (eigenvalues → `1,1,1`).
  Averaging over proper rotations preserves chirality (`e⁻` stays `e⁻`) and `L_K`. `[DERIVED, conditional]`
- If the node-lattice `O` symmetry is **exact**, the electron ground state (symmetric
  orientational superposition) is exactly `O`-invariant → **exactly** isotropic at rank-2, no
  tuning. The binding question reduces to: *is the node point-group symmetry exact?* `[DERIVED]`

*Numerically verified:* trefoil gyration tensor; `O`-orientation-average → isotropic.

---

## 7. Foundational target space + metric locking

- **The target space must carry four structures at once** `[OPEN / UNBUILT]`:
  (i) a *fermionic* paired vacuum (Weyl nodes need a Bloch/Dirac Hamiltonian);
  (ii) 12 chirality-balanced Weyl nodes in icosahedral arrangement (photon dim-6 isotropy +
  Nielsen–Ninomiya `Σχ_a=0`);
  (iii) `π_3 ≠ 0` supporting trefoil solitons (the electron);
  (iv) a single emergent `U(1)`.
  A single `l̂` (³He-A) gives 2 nodes, not 12. No known order parameter satisfies all four; it
  must be constructed.
- **Crystallographic obstruction** `[DERIVED NEGATIVE for icosahedral crystal]`: the icosahedron
  (needed for dim-6 isotropy) requires 5-fold axes, forbidden in any periodic lattice
  (rotation trace `1+φ` is irrational; only 1,2,3,4,6-fold are lattice-compatible). So
  icosahedral isotropy needs a continuous / quasicrystalline medium, where the Weyl-node /
  Bloch machinery that produced the nodes is not well-defined. A cubic crystal is allowed but
  retains dim-6 anisotropy.
- **Metric locking `c_e = c_γ`** `[OPEN, load-bearing]`: point-group symmetry forces each
  stiffness isotropic but does *not* relate their magnitudes. `c_γ` ~ Weyl-cone velocity,
  `c_e` ~ soliton order-parameter stiffness — distinct sectors, unequal in ³He-A. Equality
  needs an emergent-Lorentz RG fixed point (strong coupling), which ³He-A does not have.
  **Irony:** if the fixed point is assumed, it isotropizes everything anyway, making the node
  engineering partly redundant; if not assumed, metric locking fails. The real heavy lifting is
  the unproven RG assumption — i.e. "assume the IR flows to exact Lorentz invariance."
- **Predictivity** `[OPEN]`: the stacked structure (fermionic vacuum + icosahedral nodes +
  `π_3` solitons + single `U(1)` + RG fixed point) risks unfalsifiability. The distinctive
  predictions left are generic emergent-LV signatures (dim-6 anisotropy if cubic, `M_*`
  dispersion, CMB preferred frame). A *uniquely* SST prediction beyond emergent SM/GR is not
  yet identified.

*Numerically verified:* crystallographic restriction (lattice-compatible rotation orders).

---

## Bottom line

**Dead as a fundamental ontology** (three independent axes): the fm-scale classical
incompressible scalar fluid cannot be the substrate for the relativistic/photon sector —
killed by (1) the Galilei boost algebra (§1), (2) the `F□F` dispersion = Tak III (§3), and
(3) the foundational over-constraint (§7). It survives only as an **IR-effective** description.

**Two survivors:**
1. **Trans-Planckian scalar medium** — accept `ξ ≲ 10⁻¹¹ r_c`, `m_eff ~ m_Planck`; the fluid
   is purely IR-effective; the whole swirl/`r_c` sector is emergent ~20 orders below the medium.
2. **Volovik vector/fermionic vacuum** (this branch) — alive, but resting on **one unconstructed
   foundation** (the target space, §7) and **one unproven dynamical assumption** (the
   emergent-Lorentz RG fixed point that locks `c_e = c_γ`).

**The single decision that now gates the entire matter sector:** *specify the order-parameter
target space and show it admits an exact discrete O/I node structure (topologically realizable,
ground state) with the trefoil as a permitted defect.* Every rank-2 isotropy result follows from
this by group theory; only metric locking stands outside it and needs the RG assumption.

**What survives intact from the corpus:** `v_↺` as internal/tangential (rest mass, not a second
lightcone); `L_K` and the α-relation (orientation-invariant); chirality as the matter/antimatter
label (preserved by proper-rotation averaging); the Compton anchor. None of these were damaged
by this audit.
