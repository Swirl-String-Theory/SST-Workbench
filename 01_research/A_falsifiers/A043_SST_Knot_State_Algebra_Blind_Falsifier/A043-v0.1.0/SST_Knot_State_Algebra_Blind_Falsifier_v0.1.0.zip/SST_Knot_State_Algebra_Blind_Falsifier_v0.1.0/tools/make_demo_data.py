from pathlib import Path
import numpy as np
p=Path("demo_data/pklsa/families");p.mkdir(parents=True,exist_ok=True)
for fam,phase in [("3_1",0),("4_1",.1)]:
 for v in range(24):
  t=np.linspace(0,2*np.pi,128,endpoint=False); r=1+.1*np.cos(3*t+phase+.01*v); xyz=np.c_[r*np.cos(2*t),r*np.sin(2*t),.2*np.sin(3*t)]
  np.savez_compressed(p/f"knot_{fam}_v{v:02d}.npz",points=xyz)
print(p)
