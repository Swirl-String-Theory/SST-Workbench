from __future__ import annotations
import argparse,csv,json,pathlib

def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--out",required=True); a=ap.parse_args(); out=pathlib.Path(a.out)
 if not (out/"LOCKED_VERDICTS.json").exists(): raise SystemExit("Refusing reveal: LOCKED_VERDICTS.json missing")
 with (out/"private"/"blind_map.csv").open(encoding="utf-8") as f: mp={r["blind_id"]:r for r in csv.DictReader(f)}
 locked=json.loads((out/"LOCKED_VERDICTS.json").read_text())["verdicts"]
 fields=["blind_id","source_path","source_sha256","n_input","overall","G1","G2","G3","G4","G5"]
 with (out/"REVEALED_SUMMARY.csv").open("w",newline="",encoding="utf-8") as f:
  w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
  for r in locked:
   m=mp[r["blind_id"]]; w.writerow({"blind_id":r["blind_id"],"source_path":m["source_path"],"source_sha256":m["source_sha256"],"n_input":m["n_input"],**{k:r[k] for k in ["overall","G1","G2","G3","G4","G5"]}})
 print("REVEALED:",out/"REVEALED_SUMMARY.csv")
if __name__=="__main__": main()
