# SST Route I — Parallel Hierarchy Closure v0.0.5

## Purpose

This package runs three candidate explanations for the v0.0.4 area-density
deficit in parallel:

1. collective correlations;
2. internal topological degeneracy;
3. a sub-core boundary-mode sector.

They are related but not interchangeable. The shared bookkeeping is

\[
\eta_{\rm cap}=n_{\rm ch}h_{\rm rate},
\qquad
\eta_{\rm rel}=n_{\rm ch}d_{\rm rate}.
\]

Reversible Route-I encoding requires

\[
\eta_{\rm cap}\ge \eta_{\rm rel},
\]

with equality at ideal closure. Correlations change the relative-entropy rate
and independence structure; topology changes the local alphabet; sub-core
physics changes channel density.

## Run

```bash
python sst_route1_parallel_hierarchy_v0.0.5.py --output-dir output
```

## Verdict

- Branch A is rejected as a sole fixed-alphabet capacity mechanism.
- Branch B is rejected if interpreted only as localized centreline knot-type
  degeneracy.
- Branch C remains open: it quantifies the required UV scale, but the current
  CANON does not derive such a scale without \(G\) or \(L_p\).
- A combined B+C mechanism remains mathematically possible. Correlation gains
  may participate only when their hidden modes are explicitly counted in B or C.

The package is therefore a parallel falsification programme, not a claimed
closure of the gravitational coefficient.
