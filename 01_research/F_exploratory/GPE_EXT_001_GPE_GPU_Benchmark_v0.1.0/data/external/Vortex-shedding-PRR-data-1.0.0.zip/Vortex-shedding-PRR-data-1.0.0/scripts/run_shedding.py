"""Run a configured GPU shedding case and write production-style outputs.

The config file controls both run parameters and the variables that were
formerly edited in Input/variables.py. Outputs follow the production layout:

    outputs/Nx = .../
      spec.txt
      V0=... sigma=... v=... dt = ... GPU/
        Force/force_dt=0.02.txt
        Vortex/vortex.txt
        Psi/psi_time:<t>.npy
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "gpe_dynamics"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=ROOT / "input" / "shedding_V0=0.9_sigma=20_v=0.550.json",
        help="JSON config with 'run' and 'variables' sections.",
    )
    parser.add_argument("--V0", type=float, default=None)
    parser.add_argument("--sigma", type=int, default=None)
    parser.add_argument("--v-init", type=float, default=None)
    parser.add_argument("--v-fin", type=float, default=None)
    parser.add_argument("--t-final", type=float, default=None, help="Real-time evolution duration in tau.")
    parser.add_argument("--steps", type=int, default=None, help="Override t_final with an exact step count.")
    parser.add_argument("--force-every-tau", type=float, default=None)
    parser.add_argument("--vortex-every-tau", type=float, default=None)
    parser.add_argument("--psi-every-tau", type=float, default=None)
    parser.add_argument("--init", choices=("tf", "imaginary"), default=None)
    parser.add_argument("--output-root", type=Path, default=None)
    return parser.parse_args()


def resolve_rooted(path: Path | str) -> Path:
    resolved = Path(path).expanduser()
    if not resolved.is_absolute():
        cwd_candidate = Path.cwd() / resolved
        if cwd_candidate.exists():
            resolved = cwd_candidate
        else:
            resolved = ROOT / resolved
    return resolved


def load_config(path: Path) -> dict[str, Any]:
    with resolve_rooted(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def setting(cli_value, config: dict[str, Any], key: str, default):
    return cli_value if cli_value is not None else config.get(key, default)


def load_modules(config_path: Path):
    os.environ["GPE_VARIABLES_JSON"] = str(resolve_rooted(config_path).resolve())
    sys.path.insert(0, str(SRC))

    import cupy as cp  # noqa: PLC0415
    import variable as var  # noqa: PLC0415
    from force_GPU_energy import Eren_force  # noqa: PLC0415
    from functions import velocity_field_gpu  # noqa: PLC0415
    from imag_time_evolv import img_time_calculator  # noqa: PLC0415
    from time_evolv_GPU import time_evolver  # noqa: PLC0415
    from vortex_GPU import vortex_detect, vortex_unwinder  # noqa: PLC0415

    return cp, var, Eren_force, velocity_field_gpu, img_time_calculator, time_evolver, vortex_detect, vortex_unwinder


def as_float(value) -> float:
    if hasattr(value, "get"):
        value = value.get()
    return float(np.real(value))


def interval_to_steps(interval_tau: float, dt: float) -> int:
    return max(1, int(round(interval_tau / dt)))


def write_spec(var, base: Path) -> None:
    base.mkdir(parents=True, exist_ok=True)
    (base / "spec.txt").write_text(
        "\n".join(
            [
                "------------------Space Domain------------------",
                f"R_x = {var.R_x}",
                f"R_y = {var.R_y}",
                f"Nx = {var.Nx}",
                f"Ny = {var.Ny}",
                f"obstacle position = {var.obstacle_position}",
                "",
                "------------------Time Domain------------------",
                f"t = {var.t_:.3f}",
                f"dt = {var.dt:.3f}",
                f"tau = {var.tau_:.3f}",
                f"dtau = {var.dtau:.3f}",
                f"acceleration time = {var.acceleration_time:.3f}",
                "",
                "-----------------Tolerance----------------------",
                f"epsilon = {var.epsilon}",
                "",
                "-----------------Damping------------------------",
                f"wx = {var.wx}",
                f"wy = {var.wy}",
                f"gamma0 = {var.gamma0:.3f}",
                f"d = {var.d}",
                "",
                "------------------Ramp down time----------------",
                f"ramp_down_t = {var.ramp_down_t:.3f}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def make_case_dirs(var, output_root: Path, V0: float, sigma: int, v_fin: float) -> tuple[Path, dict[str, Path]]:
    base = output_root / f"Nx = {var.Nx:d} Ny = {var.Ny:d} dt={var.dt:.3f} obstacle={var.obstacle_position:d}"
    case = base / f"V0={V0:.1f} sigma={sigma:02d} v={v_fin:.3f} dt = {var.dt:.4f} GPU"
    dirs = {name: case / name for name in ("Image", "Force", "Vortex", "Psi")}
    for directory in dirs.values():
        directory.mkdir(parents=True, exist_ok=True)
    write_spec(var, base)
    return case, dirs


def initialize_wavefunction(cp, var, img_time_calculator, init_mode: str, V_prime: np.ndarray, v_init: float):
    if init_mode == "imaginary":
        psi0 = img_time_calculator(V_prime, v_init).make_init()
    else:
        psi0 = np.sqrt(np.maximum(-V_prime, 0.0)).astype(np.complex64)

    rng = np.random.default_rng(seed=2026)
    noise = 1e-4 * (
        rng.integers(-5, 5, size=(var.Ny, var.Nx))
        + 1j * rng.integers(-5, 5, size=(var.Ny, var.Nx))
    )
    return cp.asarray(psi0 + noise, dtype=cp.complex64)


def append_rows(path: Path, rows: list[list[float]]) -> None:
    if not rows:
        return
    with path.open("ab") as handle:
        np.savetxt(handle, np.asarray(rows, dtype=float))
    rows.clear()


def compute_energy_rate(cp, var, velocity_field_gpu, evolver) -> float:
    phase = cp.arctan2(evolver.psi.imag, evolver.psi.real)
    vel_x, vel_y = velocity_field_gpu(phase, var.dx, var.dy)
    density = cp.abs(evolver.psi) ** 2
    potential = evolver.V_prime + 1.0
    dV_dx = cp.gradient(potential, var.dx, axis=1)
    dV_dy = cp.gradient(potential, var.dy, axis=0)
    dE_dt = -density * vel_x * dV_dx - density * dV_dy * vel_y
    return as_float(cp.trapz(cp.trapz(dE_dt, var.x_gpu, axis=1), var.y_gpu))


def main() -> int:
    args = parse_args()
    config = load_config(args.config)
    run_config = dict(config.get("run", {}))
    cp, var, Eren_force, velocity_field_gpu, img_time_calculator, time_evolver, vortex_detect, vortex_unwinder = load_modules(args.config)

    V0 = float(setting(args.V0, run_config, "V0", 0.9))
    sigma = int(setting(args.sigma, run_config, "sigma", 20))
    v_init = float(setting(args.v_init, run_config, "v_init", 0.0))
    v_fin = float(setting(args.v_fin, run_config, "v_fin", 0.25))
    init_mode = str(setting(args.init, run_config, "init", "tf"))
    output_root = resolve_rooted(setting(args.output_root, run_config, "output_root", "outputs"))

    t_final = float(setting(args.t_final, run_config, "t_final", 0.2))
    steps = int(args.steps) if args.steps is not None else int(round(t_final / var.dt))
    force_every = interval_to_steps(float(setting(args.force_every_tau, run_config, "force_every_tau", 0.1)), var.dt)
    vortex_every = interval_to_steps(float(setting(args.vortex_every_tau, run_config, "vortex_every_tau", 5.0)), var.dt)
    psi_every = interval_to_steps(float(setting(args.psi_every_tau, run_config, "psi_every_tau", 10.0)), var.dt)

    case_dir, dirs = make_case_dirs(var, output_root, V0, sigma, v_fin)
    (dirs["Force"] / "force_dt=0.02.txt").write_text("", encoding="utf-8")
    (dirs["Vortex"] / "vortex.txt").write_text("", encoding="utf-8")

    V_prime = V0 * np.exp(-2 * ((var.xx - var.obstacle_position) ** 2 + var.yy**2) / sigma**2) - 1.0
    evolver = time_evolver(V0, v_init, v_fin, sigma, var.obstacle_position, V_prime)
    evolver.psi = initialize_wavefunction(cp, var, img_time_calculator, init_mode, V_prime, v_init)

    force_rows: list[list[float]] = []
    vortex_rows: list[list[float]] = []
    unwind_total = 0

    print(f"Writing output to: {case_dir}")
    print(f"Grid: {var.Nx} x {var.Ny}, dt={var.dt}, steps={steps}, t_final={steps * var.dt:.3f}, init={init_mode}")
    print(f"Cadence: force={force_every} steps, vortex={vortex_every} steps, psi={psi_every} steps")

    for i in range(steps + 1):
        tt = i * var.dt
        if i > 0:
            evolver.time_evolv(tt)

        if i % force_every == 0:
            force_x, force_y = Eren_force(evolver)
            dE_dt = compute_energy_rate(cp, var, velocity_field_gpu, evolver)
            force_rows.append([tt, as_float(force_x), as_float(force_y), dE_dt])

        if i % vortex_every == 0:
            density = cp.asnumpy(cp.abs(evolver.psi) ** 2)
            phase = cp.asnumpy(cp.arctan2(evolver.psi.imag, evolver.psi.real))
            vortices = vortex_detect(density, phase, V0, sigma)
            n_vortices = len(vortices)
            vortex_rows.append([tt, n_vortices, n_vortices + unwind_total])
            unwind_total += vortex_unwinder(evolver, vortices, int(var.Nx - 100))
            print(f"step={i:08d} t={tt:10.3f}: vortices={n_vortices}, unwind_total={unwind_total}")

        if i % psi_every == 0 or i == steps:
            np.save(dirs["Psi"] / f"psi_time_{tt:.1f}.npy", cp.asnumpy(evolver.psi))
            append_rows(dirs["Force"] / "force_dt=0.02.txt", force_rows)
            append_rows(dirs["Vortex"] / "vortex.txt", vortex_rows)
            print(f"saved checkpoint at t={tt:.1f}")

    append_rows(dirs["Force"] / "force_dt=0.02.txt", force_rows)
    append_rows(dirs["Vortex"] / "vortex.txt", vortex_rows)
    print("Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
