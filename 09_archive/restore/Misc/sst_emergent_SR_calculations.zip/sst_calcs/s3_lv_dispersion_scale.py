#!/usr/bin/env python3
"""
s3_lv_dispersion_scale.py  —  AUDIT §2  (conversation turns 11-12)

CLAIM UNDER TEST
    In Tak II (c_s = c), the Bogoliubov healing length sets the Lorentz-violation
    scale:  E_LV = hbar c / xi = m_eff c^2.
    The Bogoliubov correction is QUADRATIC (n=2): omega^2 = c^2 k^2 (1 + (k xi/2)^2),
    so the binding bound is the n=2 photon time-of-flight limit, E_LV >~ 1e10-1e11 GeV.
    xi = r_c gives E_LV = 140 MeV -> excluded by ~11 orders -> xi != r_c forced.

STATUS: [DERIVED] for the scale relation; [FALSIFIED] for xi = r_c.
"""
import numpy as np

hbar = 1.054571817e-34; c = 2.99792458e8; eV = 1.602176634e-19
hbar_c_eV_m = hbar*c/eV
r_c  = 1.40897017e-15            # swirl-string core radius (m)
L_P  = 1.616255e-35             # Planck length (m)
m_P_c2_GeV = 1.22089e19

E_LV = lambda xi: hbar_c_eV_m/xi          # in eV

print("="*92)
print("E_LV = hbar c / xi = m_eff c^2     (Tak II, c_s = c)")
print("="*92)
print(f"{'xi':>16}  {'xi/r_c':>10}  {'E_LV (GeV)':>14}  {'m_eff (GeV)':>14}  {'dv/c @10GeV':>12}")
for label, xi in [("r_c", r_c), ("1e-3 r_c",1e-3*r_c), ("1e-6 r_c",1e-6*r_c),
                  ("1e-11 r_c",1e-11*r_c), ("L_Planck",L_P)]:
    E = E_LV(xi); EG = E/1e9
    Eg = 10e9                                  # 10 GeV GRB photon
    dvg = (3/8)*(Eg/E)**2                       # superluminal group-velocity fraction
    print(f"{label:>16}  {xi/r_c:>10.1e}  {EG:>14.3e}  {EG:>14.3e}  {dvg:>12.2e}")

print("\nInversion: required xi for the binding n=2 photon bound")
for Eb in [1e10, 1e11, 1.22e19]:
    xi_req = hbar_c_eV_m/(Eb*1e9)
    print(f"  E_LV={Eb:.2e} GeV -> xi={xi_req:.3e} m  xi/r_c={xi_req/r_c:.2e}  m_eff={Eb/m_P_c2_GeV:.1e} m_Planck")

# self-checks
assert abs(E_LV(r_c)/1e9 - 0.140) < 0.005          # xi=r_c -> 140 MeV
assert (3/8)*(10e9/E_LV(r_c))**2 > 100              # 10 GeV photon far above scale -> non-perturbative
assert hbar_c_eV_m/(1e10*1e9)/r_c < 1e-10           # safety needs xi <~ 1e-11 r_c
print("\n>>> xi = r_c is excluded by ~11 orders; group velocity is SUPERLUMINAL (high-E photons arrive early).")
print(">>> Leading acoustic metric is exactly Lorentzian -> no naive (v/c)^2 anisotropy; GRB dispersion binds.")
print("\nALL §2 CHECKS PASSED.")
