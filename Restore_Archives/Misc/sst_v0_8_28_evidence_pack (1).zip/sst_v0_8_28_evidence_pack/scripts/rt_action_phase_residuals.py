#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rt_action_phase_residuals.py
============================
Numerical harness for the v0.8.28 research-track residual vector

    Delta_shell := (H^2 - P^2 c^2 - E_0^2)/E_0^2
    Delta_V     := V H/(P c^2) - 1
    Delta_Omega := Omega(P) H/(Omega_0 E_0) - 1
    Delta_q(P)  := ||q_*(P) - q_*(0)|| / q_ref

(canon: SST_CANON-v0.8.28-research-track, eq:rt_action_phase_residual_vector,
 Sec. "Action--phase mass--shell route to carrier-clock dilation";
 main canon: eq:action_phase_mass_shell_hamiltonian ...
 eq:action_phase_shape_extremum_equivalence)

WHY THIS SCRIPT EXISTS
----------------------
The canon states that a carrier family satisfying the separable mass-shell
bridge must return all four residuals converging to zero, and that a
reproducible non-zero Delta_q is evidence for an *additional* momentum-shape
coupling rather than for translation-induced flattening.  Both halves of that
statement need numerical support:

  MODEL A (separable bridge)   H = sqrt(P^2c^2 + E_0(I,q)^2)
      -> all four residuals must vanish under refinement.

  MODEL B (momentum-shape coupled)  H = sqrt(P^2c^2 + E_0(I,q)^2) + H_Pq
      -> Delta_q must become non-zero and grow with P.

If MODEL B also returned Delta_q = 0, the residual vector would be vacuous and
could not act as a falsifier.  This script therefore verifies that the canon's
proposed test is DISCRIMINATING, not merely satisfiable.

EPISTEMIC STATUS
----------------
[ORTHODOX FORM / BRIDGE]  The mass-shell Hamiltonian and the action-angle pair
are imported, not derived from the SST substrate.  This script tests the
*internal consistency and discriminating power* of the residual protocol.  It
does NOT derive the bridge, and it is not a physical carrier calculation:
E_0(I,q) here is a deliberately generic smooth surrogate, not an SST filament
energy.  Replacing E_0 by a resolved filament functional is the open task.

Usage:
    python3 rt_action_phase_residuals.py [--json FILE]
"""

import math
import json
import argparse

# --- CODATA-2018 / canon calibration ---------------------------------------
HBAR = 1.054571817e-34
M_E = 9.1093837015e-31
C = 2.99792458e8
OMEGA_C = M_E*C**2/HBAR
E_REST = M_E*C**2

Q0 = 0.37          # rest-shape extremum of the surrogate
Q_REF = 1.0        # reference scale for Delta_q
LAMBDA = 0.8       # shape stiffness of the surrogate


# ===========================================================================
# Surrogate carrier energetics
# ===========================================================================
def E0(I, q):
    """Rest-branch energy of the surrogate carrier. E_0 > 0 for all q used."""
    return (I/HBAR)*E_REST*(1.0 + LAMBDA*(q-Q0)**2)


def Omega0(I, q, h=1e-3):
    """Comoving internal frequency Omega_0 = dE_0/dI (central difference)."""
    dI = h*HBAR
    return (E0(I+dI, q)-E0(I-dI, q))/(2*dI)


def H_A(P, I, q):
    """MODEL A: separable mass-shell bridge (canon v0.8.28)."""
    e = E0(I, q)
    return math.sqrt(P*P*C*C + e*e)


def H_B(P, I, q, eps=1.0e-3):
    """MODEL B: explicit momentum-shape coupling H_Pq (NOT adopted by canon)."""
    e = E0(I, q)
    base = math.sqrt(P*P*C*C + e*e)
    return base + eps*(P*C)**2*(q-Q0)/e


# ===========================================================================
# Numerical differentiation and shape minimization
# ===========================================================================
def d_dP(Hfun, P, I, q, rel=1e-6):
    h = max(abs(P)*rel, 1e-12*E_REST/C)
    return (Hfun(P+h, I, q)-Hfun(P-h, I, q))/(2*h)


def d_dI(Hfun, P, I, q, rel=1e-6):
    h = abs(I)*rel
    return (Hfun(P, I+h, q)-Hfun(P, I-h, q))/(2*h)


def d_dq(Hfun, P, I, q, h=1e-6):
    return (Hfun(P, I, q+h)-Hfun(P, I, q-h))/(2*h)


def argmin_q(Hfun, P, I, lo=-4.0, hi=5.0, h=1e-6):
    """Locate the shape extremum by bisecting the gradient dH/dq (robust to
    the flatness that limits direct golden-section minimization)."""
    f_lo, f_hi = d_dq(Hfun, P, I, lo, h), d_dq(Hfun, P, I, hi, h)
    if f_lo*f_hi > 0:
        raise RuntimeError("gradient does not bracket a root")
    for _ in range(200):
        mid = 0.5*(lo+hi)
        f_mid = d_dq(Hfun, P, I, mid, h)
        if f_lo*f_mid <= 0:
            hi, f_hi = mid, f_mid
        else:
            lo, f_lo = mid, f_mid
    return 0.5*(lo+hi)


# ===========================================================================
# Residual vector
# ===========================================================================
def residuals(Hfun, beta, I=HBAR, fixed_V_mistake=False):
    """Return the four residuals at translational speed V = beta c."""
    gamma = 1.0/math.sqrt(1.0-beta*beta)
    q_rest = argmin_q(Hfun, 0.0, I)
    e0 = E0(I, q_rest)
    P = gamma*(e0/C**2)*(beta*C)

    q_star = argmin_q(Hfun, P, I)
    Hval = Hfun(P, I, q_star)
    V = d_dP(Hfun, P, I, q_star)
    Om0 = Omega0(I, q_rest)

    if fixed_V_mistake:
        # dH/dI evaluated along the fixed-V branch H = gamma(V) E_0(I):
        # this is the derivative the canon's fixed-momentum guard forbids.
        hI = abs(I)*1e-6
        Omega = (gamma*E0(I+hI, q_star)-gamma*E0(I-hI, q_star))/(2*hI)
    else:
        Omega = d_dI(Hfun, P, I, q_star)

    return {
        "beta": beta,
        "gamma": gamma,
        "Delta_shell": (Hval**2 - P*P*C*C - e0*e0)/e0**2,
        "Delta_V": V*Hval/(P*C*C) - 1.0,
        "Delta_Omega": Omega*Hval/(Om0*e0) - 1.0,
        "Delta_q": abs(q_star-q_rest)/Q_REF,
    }


def report(title, rows, note=""):
    print()
    print("="*78)
    print(title)
    print("="*78)
    print(f"{'V/c':>8} {'gamma':>10} {'Delta_shell':>14} {'Delta_V':>13} "
          f"{'Delta_Omega':>14} {'Delta_q':>12}")
    for r in rows:
        print(f"{r['beta']:>8.4f} {r['gamma']:>10.4f} {r['Delta_shell']:>14.3e} "
              f"{r['Delta_V']:>13.3e} {r['Delta_Omega']:>14.3e} {r['Delta_q']:>12.3e}")
    if note:
        print(f"  -> {note}")


def main():
    ap = argparse.ArgumentParser(description="v0.8.28 action-phase residual harness")
    ap.add_argument("--json", metavar="FILE")
    args = ap.parse_args()

    betas = [0.01, 0.1, 0.5, 0.9, 0.99]

    rows_A = [residuals(H_A, b) for b in betas]
    max_A = max(max(abs(r["Delta_shell"]), abs(r["Delta_V"]), abs(r["Delta_Omega"]),
                    abs(r["Delta_q"])) for r in rows_A)
    report("MODEL A -- separable mass-shell bridge (canon v0.8.28)", rows_A,
           f"max |residual| = {max_A:.2e}  "
           f"{'PASS' if max_A < 1e-6 else 'FAIL'} (tol 1e-6; floor = finite differences)")

    rows_B = [residuals(H_B, b) for b in betas]
    dq_B = max(r["Delta_q"] for r in rows_B)
    growing = all(rows_B[i]["Delta_q"] <= rows_B[i+1]["Delta_q"] + 1e-12
                  for i in range(len(rows_B)-1))
    report("MODEL B -- explicit momentum-shape coupling H_Pq (NOT canon)", rows_B,
           f"max Delta_q = {dq_B:.3e}, monotone in P: {growing}  "
           f"{'PASS' if (dq_B > 1e-3 and growing) else 'FAIL'} "
           f"(the protocol must DETECT this coupling)")

    rows_C = [residuals(H_A, b, fixed_V_mistake=True) for b in betas]
    ok_C = all(abs(r["Delta_Omega"] - (r["gamma"]**2 - 1.0)) < 1e-5 for r in rows_C)
    report("GUARD -- dH/dI taken at fixed V instead of fixed P (forbidden)", rows_C,
           f"Delta_Omega reproduces gamma^2-1 as predicted by the fixed-momentum "
           f"guard: {'PASS' if ok_C else 'FAIL'}")

    print()
    print("INTERPRETATION")
    print("-"*78)
    print("  * MODEL A confirms the residual vector is satisfiable by the separable")
    print("    bridge: no shape deformation is needed to obtain 1/gamma clock dressing.")
    print("  * MODEL B confirms the residual vector is DISCRIMINATING: an explicit")
    print("    momentum-shape coupling is detected by Delta_q, so a reported Delta_q = 0")
    print("    carries information.")
    print("  * The GUARD table shows the magnitude of the error the canon's")
    print("    fixed-momentum guard prevents: gamma^2 - 1 (a factor 4.3 at V/c = 0.9).")
    print("  * [OPEN] E_0(I,q) here is a generic smooth surrogate. Replacing it by a")
    print("    resolved SST filament energy functional, and identifying a concrete")
    print("    conserved internal action I, remains the open theorem target.")

    ok = (max_A < 1e-6) and (dq_B > 1e-3 and growing) and ok_C
    print()
    print(f"OVERALL: {'PASS' if ok else 'FAIL'}")

    if args.json:
        with open(args.json, "w") as f:
            json.dump({"canon_version": "0.8.28",
                       "model_A_separable": rows_A,
                       "model_B_coupled": rows_B,
                       "guard_fixed_V": rows_C,
                       "max_residual_A": max_A,
                       "max_Delta_q_B": dq_B,
                       "overall_pass": bool(ok)}, f, indent=2)
        print(f"[wrote {args.json}]")

    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
