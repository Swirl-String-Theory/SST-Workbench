# Executed Gate 1 — Independent Trefoil v0.2.0

**Decision:** `GATE1_PASS_FOR_DECLARED_ANALYTIC_AND_NUMERICAL_SCOPE`.

Analytic: `reach > 0.210606825 R0` strictly, while selected core radius `a0=0.20 R0`. Numerically sampled curve length `L0=14.2705590613 R0`. The exact reach is **not** determined or claimed.

## Frame and flux

| Diagnostic | q=0 | q=1 |
|---|---:|---:|
| Torus-framing Gauss linking | -6.000000000034 | -6.000000000034 |
| Writhe + twist | -5.999998486107 | -5.999998486107 |
| 16 cross-section flux maximum error | 2.22e-16 | 2.22e-16 |

## Three-dimensional grid qualification

| q | n | Raw spectral divergence RMS | Relative Helmholtz projection correction | Projected spectral divergence RMS | Independently computed projected helicity | Relative helicity error |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 64 | 2.893148 | 0.03346577 | 1.00e-15 | -5.888237 | 1.8627% |
| 0 | 96 | 1.658030 | 0.01281441 | 9.67e-16 | -5.936845 | 1.0526% |
| 0 | 128 | 1.058250 | 0.00591911 | 9.80e-16 | -5.965103 | 0.5816% |
| 0 | 160 | 0.675851 | 0.00305455 | (available in JSON) | not computed | n/a |
| 1 | 64 | (available in JSON) | 0.03326630 | 9.90e-16 | -4.933241 | 1.3352% |
| 1 | 96 | (available in JSON) | 0.01271196 | 9.65e-16 | -4.959145 | 0.8171% |
| 1 | 128 | (available in JSON) | 0.00585940 | 9.50e-16 | -4.977567 | 0.4487% |
| 1 | 160 | 0.666867 | 0.00302685 | (available in JSON) | not computed | n/a |

Reference helicities `H=-6` for `q=0`, `H=-5` for `q=1` are analytically predicted for the stated *torus framing*. The independent evaluation uses midpoint free-space Biot–Savart convolution; no rigorous error bound is claimed.

**IMPORTANT:** The FFT Helmholtz projected arrays are not compact-support vortex tubes; their small nonlocal tails must not be treated as physical fluid filaments. The analytic `C_c^infty` construction is the actual G1 seed. Source-target leakage from SST is avoided; the numeric thresholds are version-frozen but were informed by exploratory v0.1 runs.

No Euler relative equilibrium, nonlinear stability, background stabilization, source-independent knot preference or preferred physical length scale was established.
