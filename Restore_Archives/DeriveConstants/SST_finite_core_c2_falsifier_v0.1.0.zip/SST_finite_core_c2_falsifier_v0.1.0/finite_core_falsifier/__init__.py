"""Finite-core shell-coefficient falsification harness."""
__version__ = "0.1.0"
