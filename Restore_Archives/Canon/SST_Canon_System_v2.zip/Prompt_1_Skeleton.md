
MODE: OUTLINE ONLY

TASK:
Generate LaTeX skeleton for the canon.

INCLUDE:
- Sections
- Labels
- Equation placeholders

DO NOT:
- Expand text
