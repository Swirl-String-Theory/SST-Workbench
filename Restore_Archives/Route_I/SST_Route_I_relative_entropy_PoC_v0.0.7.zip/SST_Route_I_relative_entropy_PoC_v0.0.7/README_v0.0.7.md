# SST Route I — Nonlinear Adjacency and Phase Audit v0.0.7

## Release verdict

\[
\boxed{
\texttt{NONLINEAR-MICROGEOMETRY-PASS / FINITE-VOLUME-COULOMB-WINDOW-PASS / UNIQUE-BETA-SELECTION-OPEN}
}
\]

v0.0.7 extends the common v0.0.6 foundation by supplying an explicit nonlinear
core-neck microgeometry for \(I_\ell\) and \(K_\ell\). Quantization maps the
Hamiltonian exactly to an isotropic four-dimensional Wilson coupling

\[
\beta_Q=\frac{\sqrt{I_\ell K_\ell}}{\hbar}.
\]

The physical adjacency becomes an analytic Lambert-W family
\(a_\star(\beta_Q)\). A deterministic hot/cold Monte Carlo scan separates a
strong-coupling confining region from a weak-coupling Coulomb candidate region.

## Principal blind candidate

For a core-density torsion neck at \(\beta_Q=1.20\):

\[
a_\star=8.957630800917\times10^{-15}\ \mathrm m,
\]

\[
I_\ell=2.159003023856\times10^{-55}\ \mathrm{kg\,m^2},
\qquad
K_\ell=7.417568456773\times10^{-14}\ \mathrm J,
\]

\[
c_T=5.250459523414\times10^6\ \mathrm{m\,s^{-1}}.
\]

This is internally derived but does not reproduce \(c\). Matching \(c\) after
unblinding requires \(\beta_Q=68.51799313865\), which is Coulomb-compatible but
not dynamically selected.

## Run

```bash
./run_v0.0.7.sh
```

or on Windows:

```bat
run_v0.0.7.bat
```

The Monte Carlo run is deterministic but may take tens of seconds because Numba
compiles the lattice kernels on first execution.

## Main outputs

- `THEOREM_TARGET_v0.0.7.md/.tex/.pdf`
- `FOUNDATION_FREEZE_v0.0.7.yaml`
- `sst_route1_nonlinear_adjacency_phase_v0.0.7.py`
- `output_v0.0.7/audit_report.json`
- `output_v0.0.7/analytic_adjacency_closure.csv`
- `output_v0.0.7/phase_scan.csv`
- `output_v0.0.7/adjacency_scale_vs_beta.png`
- `output_v0.0.7/speed_vs_beta.png`
- `output_v0.0.7/phase_observables.png`
- `canon_patch/SST_CANON-v0.8.28-research-track_routeI_v0.0.7.diff`

## What is not claimed

The \(4^4\) simulation is a finite-volume pre-certification. It does not prove
the thermodynamic-limit phase or transition order. The microgeometry is an SST
research hypothesis, not yet CANON. Most importantly, the Coulomb phase is an
interval and does not select one unique \(\beta_Q\).
