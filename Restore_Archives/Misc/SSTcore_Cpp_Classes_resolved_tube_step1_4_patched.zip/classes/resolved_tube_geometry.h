#ifndef SSTCORE_RESOLVED_TUBE_GEOMETRY_H
#define SSTCORE_RESOLVED_TUBE_GEOMETRY_H

#pragma once

#include <array>
#include <cstddef>
#include <string>
#include <vector>

namespace sst {

using Vec3 = std::array<double, 3>;

struct SegmentPair {
    std::size_t i = 0;          // first polygon edge index
    std::size_t j = 0;          // second polygon edge index
    double s = 0.0;             // local parameter on edge i in [0,1]
    double t = 0.0;             // local parameter on edge j in [0,1]
    double distance = 0.0;      // Euclidean segment-to-segment distance
    double arclength_i = 0.0;   // approximate arclength position of closest point on edge i
    double arclength_j = 0.0;   // approximate arclength position of closest point on edge j
};

struct KinkRecord {
    std::size_t vertex = 0;
    double minrad_minus = 0.0;
    double minrad_plus = 0.0;
    double minrad = 0.0;
    double turning_angle = 0.0;
};

struct ResolvedTubeMetrics {
    double length = 0.0;
    double minrad = 0.0;
    double min_dcsd = 0.0;
    double half_min_dcsd = 0.0;
    double thickness_rad = 0.0;
    double reach_rad = 0.0;          // alias: thickness_rad = reach = normal injectivity radius
    double ropelength_rad = 0.0;     // Len / thickness radius convention
    double ropelength_diam = 0.0;    // Len / tube diameter convention
    double edge_length_mean = 0.0;
    double edge_length_rel_std = 0.0;
    bool equilateral_ok = false;
    bool lower_bound_ok = true;
    std::vector<SegmentPair> struts;
    std::vector<KinkRecord> kinks;
};

struct ContactStressDiagnostics {
    double contact_residual = 0.0;   // lightweight score; 0 is balanced/resolved in this proxy
    double strut_weight_sum = 0.0;
    double kink_weight_sum = 0.0;
    double contact_entropy = 0.0;
    std::size_t strut_count = 0;
    std::size_t kink_count = 0;
    bool solved_nnls = false;        // false for this lightweight implementation
};

class ResolvedTubeGeometry {
public:
    [[nodiscard]] static double length(const std::vector<Vec3>& pts);
    [[nodiscard]] static double edge_length_mean(const std::vector<Vec3>& pts);
    [[nodiscard]] static double edge_length_relative_std(const std::vector<Vec3>& pts);

    [[nodiscard]] static double turning_angle(const Vec3& a, const Vec3& b, const Vec3& c);
    [[nodiscard]] static double minrad_at_vertex(const std::vector<Vec3>& pts, std::size_t i);
    [[nodiscard]] static KinkRecord kink_at_vertex(const std::vector<Vec3>& pts, std::size_t i);
    [[nodiscard]] static double global_minrad(const std::vector<Vec3>& pts);

    [[nodiscard]] static double segment_segment_distance(
        const Vec3& p0, const Vec3& p1,
        const Vec3& q0, const Vec3& q1,
        double* s_out = nullptr,
        double* t_out = nullptr);

    [[nodiscard]] static std::vector<SegmentPair> dcsd_candidates(
        const std::vector<Vec3>& pts,
        int skip_neighbors = 2,
        double distance_tol = 0.0);

    [[nodiscard]] static ResolvedTubeMetrics analyze(
        const std::vector<Vec3>& pts,
        int skip_neighbors = 2,
        double contact_tol = 1e-3,
        double equilateral_tol = 1e-3);

    [[nodiscard]] static double nontrivial_knot_lower_bound_rad();
    [[nodiscard]] static double radius_to_diameter_ropelength(double ropelength_rad);
    [[nodiscard]] static double diameter_to_radius_ropelength(double ropelength_diam);
};

class ContactStressMap {
public:
    [[nodiscard]] static ContactStressDiagnostics diagnose_length_criticality(
        const std::vector<Vec3>& pts,
        const ResolvedTubeMetrics& tube,
        bool solve_nnls = false);
};

} // namespace sst

#endif // SSTCORE_RESOLVED_TUBE_GEOMETRY_H
