"""Standalone read-only diagnostics: python run_historical_trefoils.py [--out output.json]."""
from experiment.historical_trefoils import evaluate
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--out',type=Path);args=p.parse_args()
r=evaluate();payload=json.dumps(r,indent=2,sort_keys=True)+'\n'
if args.out:args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(payload,encoding='utf8')
print(payload)
raise SystemExit(0 if r['status']=='PASS_STATIC_DIAGNOSTIC_ONLY' else 1)
