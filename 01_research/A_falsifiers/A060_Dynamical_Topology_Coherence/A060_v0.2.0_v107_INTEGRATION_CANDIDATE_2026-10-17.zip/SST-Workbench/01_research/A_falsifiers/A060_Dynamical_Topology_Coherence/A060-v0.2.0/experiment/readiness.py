from pathlib import Path
import json,hashlib
class CampaignNotReady(RuntimeError): pass

def implementation_integrity(root):
    root=Path(root); lock=root/'integration/IMPLEMENTATION_LOCK.json'
    if not lock.exists(): return False,['implementation lock missing']
    errors=[]
    for row in json.loads(lock.read_text())['files']:
        p=root/row['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
            errors.append(row['path'])
    return not errors,errors

def readiness(root):
    root=Path(root)
    state=json.loads((root/'integration/UNRESOLVED.json').read_text())
    pending=[k for k,v in state['items'].items() if v!='RESOLVED_WITH_EVIDENCE']
    ok,errors=implementation_integrity(root)
    # All declared completions also require separately supplied, auditable evidence.
    evidence=root/'integration/READINESS_EVIDENCE.json'
    if not evidence.exists(): pending.append('authoritative_readiness_evidence_missing')
    return {'ready':not pending and ok,'unresolved':pending,'integrity_errors':errors,
            'status':'READY_FOR_REVIEW' if not pending and ok else 'UNRESOLVED'}

def require_ready(root):
    result=readiness(root)
    if not result['ready']:
        raise CampaignNotReady('Campaign blocked before FREEZE/science/reveal: '+json.dumps(result))
