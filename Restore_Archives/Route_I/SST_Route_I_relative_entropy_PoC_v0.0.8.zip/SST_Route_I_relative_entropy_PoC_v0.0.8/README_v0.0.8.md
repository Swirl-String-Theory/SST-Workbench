# SST Route I relative-entropy programme v0.0.8

This package tests all three v0.0.7 proposals for selecting the compact-link
quantum coupling

\[
\beta_Q=\sqrt{I_\ell K_\ell}/\hbar.
\]

## Run

```bash
python sst_route1_beta_selection_v0.0.8.py \
  --output-dir output_v0.0.8
```

The default run repeats a small hot/cold Wilson simulation at the exact-duality
candidate \(\beta_Q=1/(2\pi)\). Use `--skip-mc` to reproduce only the analytic
audit and retain the certified reference values.

## Result

\[
\boxed{
\texttt{THREE-PATH-AUDIT-PASS / UNIQUE-BETA-NOT-DERIVED}}
\]

- Raw Wilson free-energy stationarity fails.
- A duality-normalized free energy is stationary at \(1/(2\pi)\), but only
  because exact duality was imposed.
- Exact EM duality selects \(1/(2\pi)\) only in a modified Villain theory, not
  in the Wilson theory used by v0.0.7.
- Phase-action impedance matching also gives approximately \(1/(2\pi)\), but
  only through the calibrated horn identity and an unresolved \(2\pi\)
  normalization.

## Outputs

- `output_v0.0.8/audit_report.json`
- `output_v0.0.8/route_comparison.csv`
- `output_v0.0.8/candidate_closures.csv`
- `output_v0.0.8/selfdual_wilson_mc.csv`
- `output_v0.0.8/beta_vs_speed.png`
- `output_v0.0.8/beta_vs_eta_capacity.png`

## Epistemic boundary

The package does not claim that \(\beta_Q\) has been derived. Its result is a
provenance and no-go audit that prevents three dependent appearances of
\(1/(2\pi)\) from being counted as independent evidence.

## Formal report and integration

- `THEOREM_TARGET_v0.0.8.pdf` - rendered five-page theorem report;
- `THEOREM_TARGET_v0.0.8.tex` - copy-ready LaTeX source;
- `VALIDATION_v0.0.8.md` - deterministic, PDF, and CANON-patch validation;
- `DEPENDENCY_LEDGER_v0.0.8.csv` - independent/dependent claim ledger;
- `canon_patch/` - current v0.8.28 Research-Track and bibliography diffs.
