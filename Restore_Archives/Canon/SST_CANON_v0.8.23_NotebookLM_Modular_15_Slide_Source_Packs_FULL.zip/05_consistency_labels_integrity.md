# Consistency, labels, dependency rules, and Canon integrity

## Slide 1/15 - Why classification exists

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST spans Canon, bridge, research, and speculative material.
- Without labels the document overclaims.
- Classification lets reviewers trust assertions.

**Single slide message:** SST spans Canon, bridge, research, and speculative material.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 2/15 - Classification scheme

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Canon/accepted material has strongest authority.
- Bridge material connects to orthodox frameworks.
- Research material remains unfinished.
- Speculative material is hypothesis generation only.

**Single slide message:** Canon/accepted material has strongest authority.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 3/15 - Extended labels from Genesis

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- [ORIGIN] preserves provenance.
- [CALIBRATED] marks numerical input use.
- [PREDICTION] requires no upstream dependency.
- [FALSIFIER] states failure conditions.

**Single slide message:** [ORIGIN] preserves provenance.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 4/15 - Orthodox constraints

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SR, QED, GR, fluid mechanics, and knot theory constrain SST.
- Reinterpretation does not waive measurements.
- Violations require domain limits or falsifiers.

**Single slide message:** SR, QED, GR, fluid mechanics, and knot theory constrain SST.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 5/15 - Internal consistency rules

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Symbols keep fixed meanings.
- Density/speed symbols require unit discipline.
- Core, horn, link, and vorticity sectors must not be conflated.

**Single slide message:** Symbols keep fixed meanings.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 6/15 - Conflict resolution

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Prefer current loose Canon over archived versions.
- Prefer explicit axioms over old intuition.
- Preserve demoted claims as provenance.

**Single slide message:** Prefer current loose Canon over archived versions.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 7/15 - Epistemic status tracking

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Strong claims need status: derived, bridge, research, origin.
- Status can change across versions.
- Promotion requires proof, benchmark, or falsifier clarity.

**Single slide message:** Strong claims need status: derived, bridge, research, origin.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 8/15 - Canon integrity principle

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- MAIN Canon is normative.
- Research track is companion.
- Chats, notebooks, and videos need promotion before Canon use.

**Single slide message:** MAIN Canon is normative.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 9/15 - Technical hygiene

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Known duplicate labels are inherited from v0.8.22.
- Genesis integration did not create them.
- Cross-reference audit remains separate.

**Single slide message:** Known duplicate labels are inherited from v0.8.22.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 10/15 - Dependency ledger logic

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Declare inputs and outputs.
- If a target constant appears upstream, result is closure not prediction.
- Graphs decide evidence value.

**Single slide message:** Declare inputs and outputs.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 11/15 - Use policy for constants

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- c,h,e,alpha,epsilon0,mu0 are validation targets unless calibrated.
- Canonical constants may also contain historical dependencies.
- Numerical runs remain useful when labelled calibrated.

**Single slide message:** c,h,e,alpha,epsilon0,mu0 are validation targets unless calibrated.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 12/15 - Promotion path

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Origin insight -> research hypothesis.
- Hypothesis -> theorem target/benchmark.
- Proof or benchmark -> Canon candidate.
- Consistency check -> locked Canon.

**Single slide message:** Origin insight -> research hypothesis.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 13/15 - Demotion path

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Failed derivations can remain origin.
- Wrong mechanisms can be deprecated while intuition survives.
- Demotion prevents amnesia.

**Single slide message:** Failed derivations can remain origin.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 14/15 - Why this matters for Gemini

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- NotebookLM compresses status distinctions unless source pages force them.
- Each page includes do-not-overclaim rules.
- This reduces repeated generic videos.

**Single slide message:** NotebookLM compresses status distinctions unless source pages force them.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.

## Slide 15/15 - Integrity closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST earns trust by refusing to overclaim.
- Labels make uncertainty visible.
- Dependency rules make predictions meaningful.

**Single slide message:** SST earns trust by refusing to overclaim.

**Source anchors:** Consistency and Classification Framework; Genesis labels; validation notes.

**Visual specification:** Status cards, dependency graph, and promotion/demotion pipeline.

**Do not generate:** Do not collapse all statuses into “SST says”.
