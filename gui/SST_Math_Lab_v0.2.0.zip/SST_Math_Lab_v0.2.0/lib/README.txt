The six third-party browser libraries are downloaded here by install_libs.cmd / install_libs.ps1 on first run.
They are pinned; see THIRD_PARTY.md and install_libs.ps1.
