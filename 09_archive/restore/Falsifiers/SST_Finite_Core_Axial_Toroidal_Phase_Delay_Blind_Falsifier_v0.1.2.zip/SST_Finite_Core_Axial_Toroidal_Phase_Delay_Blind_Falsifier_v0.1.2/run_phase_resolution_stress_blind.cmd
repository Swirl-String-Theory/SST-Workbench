@echo off
call "%~dp0_common.cmd" || exit /b 1
cd /d "%ROOT%"
"%PY%" -m sst_finite_core_falsifier.cli blind --root . --config config/preset_phase_resolution_stress.json --campaign outputs/phase_resolution_stress/campaign --out outputs/phase_resolution_stress/blind
