#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include <cmath>
#include <vector>
#include <array>
#include <stdexcept>

namespace py = pybind11;
using Vec = std::array<double,3>;

static Vec add(Vec a, Vec b){return {a[0]+b[0],a[1]+b[1],a[2]+b[2]};}
static Vec sub(Vec a, Vec b){return {a[0]-b[0],a[1]-b[1],a[2]-b[2]};}
static Vec mul(Vec a,double s){return {a[0]*s,a[1]*s,a[2]*s};}
static double norm(Vec a){return std::sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]);}
static Vec crossv(Vec a,Vec b){return {a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};}

static std::array<std::array<double,3>,3> Rz(double th){
    double c=std::cos(th), s=std::sin(th);
    return {{{c,-s,0},{s,c,0},{0,0,1}}};
}
static std::array<std::array<double,3>,3> strain(double th){
    auto R=Rz(th); std::array<std::array<double,3>,3> A{};
    double D[3]={1,-1,0};
    for(int i=0;i<3;i++) for(int j=0;j<3;j++){
        double v=0; for(int k=0;k<3;k++) v += R[i][k]*D[k]*R[j][k];
        A[i][j]=v;
    }
    return A;
}
static double envelope(double t,double total,const std::string& kind){
    if(kind=="flat") return 1.0;
    if(kind=="sin2") { double x=std::min(1.0,std::max(0.0,t/total)); double s=std::sin(M_PI*x); return s*s; }
    throw std::runtime_error("unknown envelope");
}

static std::vector<Vec> rhs(const std::vector<Vec>& X,double t,double t_origin,const py::dict& cfg){
    const int n=(int)X.size(); double L=0;
    for(int i=0;i<n;i++) L += norm(sub(X[(i+1)%n],X[i]));
    double ds=L/n;
    double beta=py::cast<double>(cfg["beta_lia"]), omega=py::cast<double>(cfg["omega"]);
    double a1=py::cast<double>(cfg["a1"]), a2=py::cast<double>(cfg["a2"]), phase=py::cast<double>(cfg["phase"]);
    double strength=py::cast<double>(cfg["drive_strength"]), total=py::cast<double>(cfg["total_time"]);
    std::string chir=py::cast<std::string>(cfg["chirality"]), env=py::cast<std::string>(cfg["envelope"]);
    double s2 = chir=="COR" ? 1.0 : -1.0;
    double tt=t+t_origin; auto A1=strain(omega*tt), A2=strain(s2*2*omega*tt+phase);
    double e=envelope(tt,total,env);
    Vec C{0,0,0}; for(auto p:X) C=add(C,p); C=mul(C,1.0/n);
    std::vector<Vec> out(n);
    for(int i=0;i<n;i++){
        Vec xp=X[(i+1)%n], xm=X[(i+n-1)%n];
        Vec xs=mul(sub(xp,xm),1.0/(2*ds));
        Vec xss=mul(add(sub(xp,mul(X[i],2.0)),xm),1.0/(ds*ds));
        double den=std::pow(norm(xs),3)+1e-12;
        Vec v=mul(crossv(xs,xss),beta/den);
        Vec q=sub(X[i],C), f{0,0,0};
        for(int r=0;r<3;r++) for(int c=0;c<3;c++) f[r]+=e*(a1*A1[r][c]+a2*A2[r][c])*q[c];
        out[i]=add(v,mul(f,strength));
    }
    return out;
}

static py::array_t<double> evolve(py::array_t<double, py::array::c_style | py::array::forcecast> arr,
                                  double duration,double t_origin,py::dict cfg){
    auto b=arr.request(); if(b.ndim!=2 || b.shape[1]!=3) throw std::runtime_error("expected Nx3");
    int n=(int)b.shape[0]; auto* ptr=(double*)b.ptr; std::vector<Vec> X(n);
    for(int i=0;i<n;i++) X[i]={ptr[3*i],ptr[3*i+1],ptr[3*i+2]};
    double dt0=py::cast<double>(cfg["dt"]); int steps=std::max(1,(int)std::ceil(duration/dt0)); double dt=duration/steps;
    for(int step=0;step<steps;step++){
        double t=step*dt;
        auto k1=rhs(X,t,t_origin,cfg);
        std::vector<Vec> Y(n); for(int i=0;i<n;i++) Y[i]=add(X[i],mul(k1[i],0.5*dt));
        auto k2=rhs(Y,t+0.5*dt,t_origin,cfg); for(int i=0;i<n;i++) Y[i]=add(X[i],mul(k2[i],0.5*dt));
        auto k3=rhs(Y,t+0.5*dt,t_origin,cfg); for(int i=0;i<n;i++) Y[i]=add(X[i],mul(k3[i],dt));
        auto k4=rhs(Y,t+dt,t_origin,cfg);
        for(int i=0;i<n;i++) X[i]=add(X[i],mul(add(add(k1[i],mul(k2[i],2)),add(mul(k3[i],2),k4[i])),dt/6.0));
    }
    py::array_t<double> out({n,3}); auto ob=out.mutable_unchecked<2>();
    for(int i=0;i<n;i++) for(int j=0;j<3;j++) ob(i,j)=X[i][j];
    return out;
}

PYBIND11_MODULE(_native,m){ m.doc()="SST THPCF C++17 reference backend"; m.def("evolve",&evolve); }
