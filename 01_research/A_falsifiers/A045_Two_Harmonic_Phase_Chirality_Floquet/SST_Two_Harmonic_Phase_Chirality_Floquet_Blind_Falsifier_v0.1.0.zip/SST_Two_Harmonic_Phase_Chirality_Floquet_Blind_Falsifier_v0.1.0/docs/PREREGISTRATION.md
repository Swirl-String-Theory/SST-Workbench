# Preregistration — v0.1.0

## Primary hypothesis
A counter-rotating two-harmonic drive has the exact dynamical symmetry

\[
A(t+T/3)=R_z(2\pi/3)A(t)R_z(-2\pi/3),
\]

whereas the co-rotating control generally does not. For any rotationally equivariant reference dynamics, the corresponding transformed-flow identity must hold numerically within convergence error.

## Blind protocol
Conditions are reduced to anonymous IDs before scoring. The primary blind metrics are the dynamic-equivariance residual, numerical length drift, curvature diagnostics, and nonlocal-distance proxy. Arm labels and phase values are stored only in `private_reveal/reveal_map.json` and are excluded from the BLIND output archive.

## Gates
- G0: trefoil C3 geometry residual below preregistered threshold.
- G1: at least one anonymous drive class satisfies the analytic C3 dynamic-symmetry identity.
- G2: low-residual anonymous branch satisfies the numerical equivariance threshold.
- G3: positive-control branch is separated by the preregistered ratio.
- G4: numerical length drift remains below the reference-model tolerance.

## Scope restriction
v0.1.0 is a dimensionless LIA reference-model falsifier and software architecture test. It does not claim finite-core SST closure. Formal Floquet multipliers are explicitly skipped until a certified periodic orbit or relative periodic orbit is supplied.
