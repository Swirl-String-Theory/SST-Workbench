@echo off
setlocal
cd /d "%~dp0"
where knotplot.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: knotplot.exe not found on PATH.
  echo Open KnotPlot manually and run: ^< 98_run_core_matrix.kpc
  exit /b 1
)
echo Running KnotPlot 3.1 CORE relaxation matrix...
knotplot.exe -nog < 98_run_core_matrix.kpc > core_matrix_console.log 2>&1
set RC=%ERRORLEVEL%
echo Finished with exit code %RC%.
echo Console log: core_matrix_console.log
exit /b %RC%
