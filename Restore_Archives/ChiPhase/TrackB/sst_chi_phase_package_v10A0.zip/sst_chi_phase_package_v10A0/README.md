# SST chi-phase package v10A.0 — Track A Euler/Biot–Savart ring-alpha solver

Status: **Research Track / CANON-compatible audit prototype**.

This package implements the first non-synthetic Track A step after v9:

\[
E
=
\frac{\rho}{8\pi}
\int\!\!\int
\frac{\boldsymbol\omega(\mathbf x)\cdot\boldsymbol\omega(\mathbf x')}
     {|\mathbf x-\mathbf x'|}
\,d^3x\,d^3x',
\]

for a slender toroidal vortex tube. It then extracts the effective vortex-ring constant

\[
\alpha_{\rm eff}(\epsilon)
=
\ln\left(\frac{8R}{a}\right)
-
\frac{2E}{\rho\Gamma^2R},
\qquad
\epsilon=\frac{a}{R}.
\]

The thin-ring intercept is estimated by fitting

\[
\alpha_{\rm eff}(\epsilon)
=
\alpha_0
+
A\epsilon^2\ln(1/\epsilon)
+
B\epsilon^2.
\]

The corresponding \(\beta\)-constant is then obtained from the v8 relation

\[
\beta=\alpha-1+q,
\qquad
q=\frac{d\ln a}{d\ln R}.
\]

## What is new relative to v9?

v9 only validated the alpha/beta intercept *pipeline* using synthetic energy data.  
v10A.0 replaces the synthetic energy with a genuine incompressible Euler/Biot–Savart vorticity-energy integral.

## What is deliberately not included?

v10A.0 is **Track A only**. It does **not** include Gross–Pitaevskii / NLSE gradient energy, density-depletion potential energy, or healing-length physics. Therefore v10A.0 is not expected to prove the old NLS value \((\alpha,\beta)=(1.61,0.61)\). That belongs to Track B.

## Canon-safe interpretation

The canon-compatible result is the method:

\[
\alpha
=
\lim_{\epsilon\to0}
\left[
\ln\left(\frac{8}{\epsilon}\right)
-
\frac{2E_{\rm BS}(\epsilon)}{\rho\Gamma^2R}
\right].
\]

A profile-specific numerical \(\alpha_0\) is only as strong as:
1. the vortex-core profile,
2. the quadrature resolution,
3. the thin-ring extrapolation.

## Included profile tests

Default profiles:

- `rankine_solid`: solid-body tangential velocity \(f(x)=x\), i.e. uniform axial/toroidal vorticity in the tube. This is the benchmark; it should approach the classical solid-core constant \(\alpha\approx 7/4\).
- `smooth_a0star`: the v6 closure root \(a_0^\star=(\sqrt{385}-13)/4\).
- `smooth_phi`: the same smooth-matched family evaluated at \(a_0=\varphi\).
- `smooth_a0_2`: the simple matched polynomial \(a_0=2\).
- `smooth_grad_min`: the v6 gradient-energy minimum \(a_0=7/4\).

The smooth-matched profile is

\[
f_{a_0}(x)
=
x\left[a_0+(3-2a_0)x^2+(a_0-2)x^4\right],
\]

with

\[
f(0)=0,\qquad f(1)=1,\qquad f'(1)=-1.
\]

## Run

```bash
python simulate_chi_phase_v10A0.py
```

Higher-resolution benchmark:

```bash
python simulate_chi_phase_v10A0.py --nr 12 --ntheta 36 --eps 0.10,0.075,0.055,0.04 --nd-scale 130 --nd-min 1024
```

No plots:

```bash
python simulate_chi_phase_v10A0.py --no-plots
```

## Outputs

The script writes:

```text
exports/chi_v10A0_alpha_scan.csv
exports/chi_v10A0_alpha_intercepts.csv
exports/chi_v10A0_beta_from_q.csv
exports/chi_v10A0_run_results_summary.txt
exports/chi_v10A0_alpha_eff_vs_eps.png
exports/chi_v10A0_alpha_intercepts.png
```

## Expected first-pass behavior

The `rankine_solid` benchmark should land near \(\alpha=7/4=1.75\) as resolution is increased.  
The smooth-matched profiles generally do not automatically reproduce \(\alpha_{\rm NLS}=1.61\). If they do not, that is a useful negative result: the v6 \(\chi\)-closure root is not automatically the NLS ring-energy selector.

## Version label

`v10A.0` means:

- `10`: after v9 alpha/beta synthetic intercept audit.
- `A`: Track A, incompressible Euler/Biot–Savart.
- `.0`: first working prototype, not final high-precision solver.
