from pathlib import Path
import json
from sst_vortex_shear.campaign import run_blind_campaign


def test_campaign_smoke(tmp_path):
    root=Path(__file__).resolve().parents[1]
    cfg=json.loads((root/'configs'/'default.json').read_text(encoding='utf-8'))
    cfg['n_directions']=1000
    cfg['dynamic']['grid_n']=9
    cfg['dynamic']['coarse_grid_n']=9
    cfg['dynamic']['background_shell_min']=2.0
    cfg['dynamic']['background_shell_max']=2.9
    cfg['dynamic']['dt']=0.01
    cfg['dynamic']['t_final']=0.04
    cfg['dynamic']['coarse_t_final']=0.04
    cfg['dynamic']['sample_stride']=1
    cfg['tolerances']['dynamic_initial_isotropy_fro_max']=0.30
    cfg['tolerances']['static_A2_relative_error_max']=5e-4
    p=tmp_path/'cfg.json'; p.write_text(json.dumps(cfg),encoding='utf-8')
    s=run_blind_campaign(p,tmp_path/'out')
    assert s['pipeline_status']=='PIPELINE_QUALIFIED'
    assert s['static_born']['A2_mean'] > 0.0
