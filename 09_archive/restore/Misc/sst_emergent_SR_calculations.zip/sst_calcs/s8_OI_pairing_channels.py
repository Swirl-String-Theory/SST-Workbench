#!/usr/bin/env python3
"""
s8_OI_pairing_channels.py  —  AUDIT §7  (conversation turn 23)

CLAIM UNDER TEST
    A continuous (non-crystal) order parameter producing O- or I-symmetric Weyl
    nodes needs a gap function containing an O/I-invariant spherical harmonic.
    The number of invariants of the spin-l SO(3) irrep under a finite group G is
        n_l = (1/|G|) sum_classes (size) * chi_l(theta),
        chi_l(theta) = sin((2l+1) theta/2) / sin(theta/2).
    Lowest non-trivial invariant: l = 4 for cubic O, l = 6 for icosahedral I.
    => exact O nodes need an l>=4 (g-wave) pairing (exotic);
       exact I nodes need l=6 (essentially unphysical) or are crystal-forbidden.

STATUS: [DERIVED NEGATIVE for continuous O/I superfluid nodes]
"""
import numpy as np
def chi(l, theta):
    return (2*l+1) if abs(theta) < 1e-12 else np.sin((2*l+1)*theta/2)/np.sin(theta/2)
# proper point groups by class: (class_size, rotation_angle)
O = [(1,0),(8,2*np.pi/3),(6,np.pi/2),(3,np.pi),(6,np.pi)]              # order 24
I = [(1,0),(12,2*np.pi/5),(12,4*np.pi/5),(20,2*np.pi/3),(15,np.pi)]   # order 60
def n_inv(group, order, l):
    return round(sum(s*chi(l,t) for s,t in group)/order)

print(" l : #O-invariants  #I-invariants")
lowest_O = lowest_I = None
for l in range(0, 13):
    nO, nI = n_inv(O,24,l), n_inv(I,60,l)
    if l>0 and nO>=1 and lowest_O is None: lowest_O = l
    if l>0 and nI>=1 and lowest_I is None: lowest_I = l
    print(f"{l:2d} :   {nO:3d}            {nI:3d}")
print(f"\nlowest non-trivial CUBIC (O) harmonic:       l = {lowest_O}  -> needs l>=4 (g-wave) pairing")
print(f"lowest non-trivial ICOSAHEDRAL (I) harmonic: l = {lowest_I}  -> needs l=6 pairing (unphysical)")
assert lowest_O == 4 and lowest_I == 6
print("\n>>> exact O nodes: continuous superfluid needs l>=4 (exotic) or a cubic crystal (dim-6 survives).")
print(">>> exact I nodes: l=6 pairing (unphysical) or icosahedral crystal (forbidden). Essentially unreachable.")
print("\nALL §7-pairing CHECKS PASSED.")
