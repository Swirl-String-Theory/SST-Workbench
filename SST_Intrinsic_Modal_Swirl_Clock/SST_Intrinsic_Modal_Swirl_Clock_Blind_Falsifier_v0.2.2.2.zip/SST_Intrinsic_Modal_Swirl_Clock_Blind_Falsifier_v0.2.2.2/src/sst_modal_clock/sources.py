from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import gzip, hashlib, re
import numpy as np

_FLOAT=r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?'

@dataclass
class SourceGeometry:
    topology_id: str
    provenance: str
    source_path: str
    source_name: str
    source_record_id: str
    components: list[np.ndarray]
    metadata: dict


def _read_text_or_gzip(path: Path) -> str:
    p=Path(path)
    if p.suffix.lower()=='.gz':
        with gzip.open(p,'rt',encoding='utf-8',errors='ignore') as f: return f.read()
    return p.read_text(encoding='utf-8',errors='ignore')


def _vec(s):
    v=[float(x) for x in re.findall(_FLOAT,str(s))]
    if len(v)<3: return np.zeros(3,float)
    return np.asarray(v[:3],float)


def eval_fourier(coeff: dict[int,tuple[np.ndarray,np.ndarray]], n_points: int) -> np.ndarray:
    n=max(16,int(n_points)); t=np.linspace(0,2*np.pi,n,endpoint=False); x=np.zeros((n,3),float)
    for k,(A,B) in coeff.items():
        if int(k)==0: x += .5*np.asarray(A,float)[None,:]
        else: x += np.cos(int(k)*t)[:,None]*np.asarray(A,float)[None,:] + np.sin(int(k)*t)[:,None]*np.asarray(B,float)[None,:]
    if not np.isfinite(x).all() or np.ptp(x,axis=0).max()<1e-12: raise ValueError('degenerate Fourier reconstruction')
    return x


def _canonical_from_fseries_path(path: Path) -> str|None:
    s=(path.parent.name+' '+path.stem).lower()
    # Hoste--Thistlethwaite style names in the official Fremlin archive.
    m=re.search(r'(?:knot[._-]?)?(\d+)([an])[._](\d+)',s,re.I)
    if m: return f'K{int(m.group(1))}{m.group(2).upper()}{int(m.group(3))}'
    # A small number of official Fremlin files use a compact catalogue label
    # with no unambiguous Rolfsen separator (e.g. 15331). Preserve it without
    # guessing a topology mapping; it remains available for provenance audit.
    m=re.search(r'(?:knot[._-]?)(\d{4,})(?:$|\D)',path.stem,re.I)
    if m: return f'FREMLIN{m.group(1)}'
    m=re.search(r'(?:knot[._-]?)?t\s*([2-9]\d*)[._](\d+)',s)
    if m: return f'T{int(m.group(1))}.{int(m.group(2))}'
    m=re.search(r'(?:knot[._-]?)?(\d+)[_.](\d+)',s)
    if m: return f'K{int(m.group(1))}.{int(m.group(2))}'
    m=re.search(r'knot[_\.-]?(\d+)\.(\d+)',s)
    if m: return f'K{int(m.group(1))}.{int(m.group(2))}'
    return None


def _canonical_relaxed(path: Path) -> str|None:
    s=path.stem.lower()
    m=re.search(r'^knot[_\.-](\d+)[\._](\d+)',s)
    if m: return f'K{int(m.group(1))}.{int(m.group(2))}'
    m=re.search(r'^link[_\.-](\d+)[\._](\d+)[\._](\d+)',s)
    if m: return f'L{int(m.group(1))}.{int(m.group(2))}.{int(m.group(3))}'
    m=re.search(r'^torus[_\.-]?(\d+)[\._](\d+)',s)
    if m: return f'T{int(m.group(1))}.{int(m.group(2))}'
    return None


ROLFSEN_LINK_ALIASES = {
    # Verified Knot Atlas Thistlethwaite -> Rolfsen mappings used by the current relaxed-link catalog.
    'L2A1':'L2.2.1', 'L4A1':'L4.2.1', 'L5A1':'L5.2.1',
    'L6A3':'L6.2.1', 'L6A5':'L6.3.1', 'L6A4':'L6.3.2', 'L6N1':'L6.3.3',
    'L7A2':'L7.2.5', 'L7A1':'L7.2.6', 'L7N2':'L7.2.8',
    'L8A14':'L8.2.1',
}

def canonical_ideal_id(raw_id: str, has_strings: bool=False) -> str:
    rid=str(raw_id).strip()
    # Gilbert AB IDs: crossing:string-count:identifier. 5:1:2 == knot 5_2.
    m=re.fullmatch(r'(\d+)\s*:\s*(\d+)\s*:\s*(\d+)',rid)
    if m:
        c,nstr,idx=map(int,m.groups())
        return f'K{c}.{idx}' if nstr==1 and not has_strings else f'L{c}.{nstr}.{idx}'
    # Hoste-Thistlethwaite link forms.  The Gilbert IdealLinks database uses IDs
    # such as L2a1 / L6n1, while the relaxed catalog uses Rolfsen-style
    # crossing.component.index IDs (e.g. L6.3.3).  Use verified aliases where
    # available; otherwise retain an explicit HT identifier rather than silently
    # pretending that the HT index is the Rolfsen index.
    if rid.upper().startswith('L'):
        key=rid.upper().replace('_','')
        if key in ROLFSEN_LINK_ALIASES: return ROLFSEN_LINK_ALIASES[key]
        return 'HT'+key
    if re.fullmatch(r'K?11[an]\d+',rid,re.I):
        x=rid.upper()
        return x if x.startswith('K') else 'K'+x
    return ('L' if has_strings else 'K')+rid.replace(':','.').replace('_','.')


def parse_fseries_file(path: Path, n_points: int) -> list[SourceGeometry]:
    """Fremlin six-column format: ax bx ay by az bz per harmonic j=1..N.

    A 3-column numeric line at the start is accepted as A0. Comment/blank lines
    split blocks; multiple nonempty blocks are retained as separate seed variants.
    """
    text=Path(path).read_text(encoding='utf-8',errors='ignore')
    blocks=[]; cur=[]; headers=[]; hdr=[]
    def flush():
        nonlocal cur,hdr
        if cur: blocks.append((list(hdr),list(cur)))
        cur=[]; hdr=[]
    for line in text.splitlines():
        s=line.strip()
        if not s:
            if cur: flush()
            continue
        if s.startswith(('%','#','//',';')):
            hdr.append(s)
            continue
        nums=[]
        for tok in re.split(r'[\s,]+',s):
            try: nums.append(float(tok))
            except ValueError: pass
        if len(nums) in (3,6): cur.append(nums)
    if cur: flush()
    topo=_canonical_from_fseries_path(Path(path))
    if topo is None: return []
    out=[]
    for bi,(head,rows) in enumerate(blocks):
        coeff={}; harmonic=1
        for row in rows:
            if len(row)==3 and harmonic==1 and 0 not in coeff:
                coeff[0]=(np.asarray(row,float),np.zeros(3,float)); continue
            if len(row)<6: continue
            coeff[harmonic]=(np.asarray([row[0],row[2],row[4]],float),np.asarray([row[1],row[3],row[5]],float)); harmonic+=1
        if not coeff or not any(k>0 for k in coeff): continue
        try: x=eval_fourier(coeff,n_points)
        except Exception: continue
        rid=f'{Path(path).name}#block{bi}'
        stem=Path(path).stem
        vm=re.search(r'(?:knot[._-]?)?\d+(?:[an])?[_.]\d+([^.]*)$',stem,re.I)
        variant=(vm.group(1) if vm else '').strip('_-.') or 'base'
        out.append(SourceGeometry(topo,'fseries',str(path),Path(path).name,rid,[x],{'header':' | '.join(head[:4]),'n_harmonics':max(coeff),'variant_label':variant,'official_fremlin_variant':True}))
    return out


def _parse_coeff_body(body: str) -> dict[int,tuple[np.ndarray,np.ndarray]]:
    coeff={}
    # XML-ish Gilbert representation; omitted zero coefficients are naturally zero.
    for m in re.finditer(r'<\s*Coeff\b([^>]*)/?>',body,re.I|re.S):
        attrs=m.group(1)
        im=re.search(r'\bI\s*=\s*["\']([^"\']+)',attrs,re.I); am=re.search(r'\bA\s*=\s*["\']([^"\']+)',attrs,re.I); bm=re.search(r'\bB\s*=\s*["\']([^"\']+)',attrs,re.I)
        if not im: continue
        i=int(float(im.group(1))); A=_vec(am.group(1)) if am else np.zeros(3); B=_vec(bm.group(1)) if bm else np.zeros(3); coeff[i]=(A,B)
    return coeff


def _ideal_records_xml(text: str, provenance: str, source_path: Path, n_points: int) -> list[SourceGeometry]:
    out=[]
    # Gilbert knots use AB / HT. Official Gilbert IdealLinks uses TL containers
    # with one STRING block per link component. HL/LINK are tolerated only for mirrors/conversions.
    pat=re.compile(r'<\s*(AB|HT|TL|HL|LINK)\b([^>]*)>(.*?)</\s*\1\s*>',re.I|re.S)
    for m in pat.finditer(text):
        tag,attrs,body=m.group(1),m.group(2),m.group(3)
        im=re.search(r'\bId\s*=\s*["\']([^"\']+)',attrs,re.I)
        if not im: continue
        rid=im.group(1).strip(); string_blocks=list(re.finditer(r'<\s*STRING\b([^>]*)>(.*?)</\s*STRING\s*>',body,re.I|re.S)); comps=[]
        if string_blocks:
            for sm in string_blocks:
                co=_parse_coeff_body(sm.group(2))
                if co:
                    try: comps.append(eval_fourier(co,n_points))
                    except Exception: pass
        else:
            co=_parse_coeff_body(body)
            if co:
                try: comps=[eval_fourier(co,n_points)]
                except Exception: comps=[]
        if not comps: continue
        topo=canonical_ideal_id(rid,has_strings=len(comps)>1)
        out.append(SourceGeometry(topo,provenance,str(source_path),source_path.name,rid,comps,{'ideal_id':rid,'n_components':len(comps),'tag':tag.upper()}))
    return out


def _ideal_records_legacy(text: str, provenance: str, source_path: Path, n_points: int) -> list[SourceGeometry]:
    """Fallback for legacy/mirrored block files with numeric topology headers.

    Supports a header like 3.1.1 / 3:1:1 followed by Gilbert-style six-column
    coefficient rows. This does not reinterpret arbitrary tables as coordinates.
    """
    out=[]; current=None; rows=[]
    def flush():
        nonlocal current,rows
        if current and rows:
            coeff={}; h=1
            for r in rows:
                if len(r)==3 and h==1 and 0 not in coeff: coeff[0]=(np.asarray(r),np.zeros(3)); continue
                if len(r)>=6:
                    coeff[h]=(np.asarray([r[0],r[2],r[4]]),np.asarray([r[1],r[3],r[5]])); h+=1
            if coeff and any(k>0 for k in coeff):
                try:
                    x=eval_fourier(coeff,n_points); rid=current.replace('.',':'); topo=canonical_ideal_id(rid,False)
                    out.append(SourceGeometry(topo,provenance,str(source_path),source_path.name,current,[x],{'ideal_id':current,'legacy_block':True,'n_components':1}))
                except Exception: pass
        current=None; rows=[]
    for line in text.splitlines():
        s=line.strip()
        hm=re.fullmatch(r'(\d+)[\.:](\d+)[\.:](\d+)',s)
        if hm:
            flush(); current='.'.join(hm.groups()); continue
        if current:
            nums=[]
            for tok in re.split(r'[\s,]+',s):
                try: nums.append(float(tok))
                except ValueError: pass
            if len(nums) in (3,6): rows.append(nums)
    flush(); return out


def parse_ideal_catalog(path: Path, provenance: str, n_points: int) -> list[SourceGeometry]:
    text=_read_text_or_gzip(path); out=_ideal_records_xml(text,provenance,Path(path),n_points)
    return out if out else _ideal_records_legacy(text,provenance,Path(path),n_points)


def _find_ideal_file(root: Path, stem: str) -> Path|None:
    root=Path(root)
    candidates=[root/f'{stem}.txt',root/f'{stem}.txt.gz',root/f'{stem}.gz',root/stem]
    for p in candidates:
        if p.exists() and p.is_file(): return p
    # Case-insensitive fallback.
    if root.exists():
        for p in root.iterdir():
            if p.is_file() and p.name.lower() in {f'{stem.lower()}.txt',f'{stem.lower()}.txt.gz',f'{stem.lower()}.gz',stem.lower()}: return p
    return None


def discover_relaxed(root: Path) -> list[SourceGeometry]:
    from .geometry import read_xyz_components,read_xyz
    root=Path(root); out=[]
    if not root.exists(): return out
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.suffix.lower() not in {'.txt','.xyz','.csv','.dat','.pts'}: continue
        topo=_canonical_relaxed(p)
        if topo is None: continue
        try: comps=read_xyz_components(p) if topo.startswith('L') else [read_xyz(p)]
        except Exception: continue
        out.append(SourceGeometry(topo,'relaxed',str(p),p.name,p.name,comps,{'n_components':len(comps)}))
    return out


def discover_fseries(root: Path,n_points: int) -> list[SourceGeometry]:
    root=Path(root); out=[]
    if not root.exists(): return out
    for p in sorted(root.rglob('*.fseries')): out.extend(parse_fseries_file(p,n_points))
    return out


def discover_all_sources(cfg: dict, config_base: Path|None=None) -> tuple[list[SourceGeometry],dict]:
    """Discover relaxed/Fremlin/Gilbert sources using config-relative roots."""
    base=Path(config_base or '.').resolve()
    def resolve(v):
        p=Path(str(v)); return p if p.is_absolute() else (base/p).resolve()
    n=int(cfg.get('n_points',64))
    roots=cfg.get('source_roots',{})
    rr=resolve(roots.get('relaxed','../../KnotPlot/knots/final'))
    fr=resolve(roots.get('fseries','../../KnotPlot/Knots_FourierSeries'))
    ir=resolve(roots.get('ideal','../../Ideal_Sources'))
    rows=[]; errors=[]
    relaxed=discover_relaxed(rr); rows.extend(relaxed)
    fseries=discover_fseries(fr,n); rows.extend(fseries)
    # Official Knot Atlas/Gilbert catalog family.  Read every upstream file that
    # is present; relaxed-only matching below keeps the physics campaign bounded.
    knot_stems=['Ideal','Ideal_11a','Ideal_11n']
    link_stems=['IdealLinks','IdealLinks_10a','IdealLinks_10n','IdealLinks_11a1','IdealLinks_11a2','IdealLinks_11n1','IdealLinks_11n2']
    ideal=[]; ideal_links=[]; ideal_files=[]; ideal_links_files=[]
    for stem in knot_stems:
        pp=_find_ideal_file(ir,stem)
        if not pp: continue
        ideal_files.append(str(pp))
        try:
            rrk=parse_ideal_catalog(pp,'ideal',n); ideal.extend(rrk); rows.extend(rrk)
        except Exception as e: errors.append({'source':'ideal','catalog':stem,'path':str(pp),'error':repr(e)})
    for stem in link_stems:
        pp=_find_ideal_file(ir,stem)
        if not pp: continue
        ideal_links_files.append(str(pp))
        try:
            rrl=parse_ideal_catalog(pp,'ideal_links',n); ideal_links.extend(rrl); rows.extend(rrl)
        except Exception as e: errors.append({'source':'ideal_links','catalog':stem,'path':str(pp),'error':repr(e)})
    ik=Path(ideal_files[0]) if ideal_files else None
    il=Path(ideal_links_files[0]) if ideal_links_files else None
    # Keep only topologies represented by relaxed seeds by default, making this a true provenance comparison.
    ref=set(r.topology_id for r in relaxed)
    if bool(cfg.get('provenance_reference_relaxed_only',True)): rows=[r for r in rows if r.topology_id in ref]
    trx=cfg.get('source_topology_regex')
    if trx:
        rx=re.compile(str(trx),re.I); rows=[r for r in rows if rx.search(r.topology_id)]
    maxv=int(cfg.get('max_variants_per_topology_per_provenance',1)); kept=[]; count={}
    for r in sorted(rows,key=lambda z:(z.topology_id,z.provenance,z.source_record_id)):
        k=(r.topology_id,r.provenance); count[k]=count.get(k,0)+1
        if count[k]<=maxv: kept.append(r)
    summary={'roots':{'relaxed':str(rr),'fseries':str(fr),'ideal':str(ir)},'ideal_file':str(ik) if ik else None,'ideal_links_file':str(il) if il else None,'ideal_files':ideal_files,'ideal_links_files':ideal_links_files,'discovered_counts':{'relaxed':len(relaxed),'fseries':len(fseries),'ideal':len(ideal),'ideal_links':len(ideal_links)},'kept_records':len(kept),'reference_topologies':len(ref),'errors':errors}
    return kept,summary
