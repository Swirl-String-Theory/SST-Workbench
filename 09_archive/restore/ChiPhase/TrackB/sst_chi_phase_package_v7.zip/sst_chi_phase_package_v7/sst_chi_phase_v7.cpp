#include <pybind11/pybind11.h>
#include <cmath>

namespace py = pybind11;

constexpr double A0_STAR = (-13.0 + std::sqrt(385.0)) / 4.0;
constexpr double PHI = (1.0 + std::sqrt(5.0)) / 2.0;

double c2_over_v2_smooth(double a0) {
    return (2.0*a0*a0 + 13.0*a0 + 78.0) / 105.0;
}

double c_over_v_smooth(double a0) {
    return std::sqrt(c2_over_v2_smooth(a0));
}

double root_residual(double a0) {
    return c2_over_v2_smooth(a0) - 1.0;
}

double analytic_root() { return A0_STAR; }

double golden_ratio() { return PHI; }

double bisection_root(double lo=0.0, double hi=3.0, double tol=1e-14, int max_iter=200) {
    double flo = root_residual(lo);
    double fhi = root_residual(hi);
    if (flo * fhi > 0.0) throw std::runtime_error("root not bracketed");
    for (int k=0; k<max_iter; ++k) {
        double mid = 0.5*(lo+hi);
        double fm = root_residual(mid);
        if (std::abs(fm) < tol || 0.5*(hi-lo) < tol) return mid;
        if (flo*fm <= 0.0) { hi = mid; fhi = fm; }
        else { lo = mid; flo = fm; }
    }
    return 0.5*(lo+hi);
}

PYBIND11_MODULE(sst_chi_phase_v7, m) {
    m.doc() = "SST chi-phase v7 ring-constant comparator backend";
    m.def("c2_over_v2_smooth", &c2_over_v2_smooth);
    m.def("c_over_v_smooth", &c_over_v_smooth);
    m.def("root_residual", &root_residual);
    m.def("analytic_root", &analytic_root);
    m.def("golden_ratio", &golden_ratio);
    m.def("bisection_root", &bisection_root, py::arg("lo")=0.0, py::arg("hi")=3.0, py::arg("tol")=1e-14, py::arg("max_iter")=200);
}
