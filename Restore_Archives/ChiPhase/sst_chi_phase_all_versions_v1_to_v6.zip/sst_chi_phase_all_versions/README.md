# SST Chi-Phase Research Packages v1-v6

Self-contained combined archive for the SST internal torsional chi-phase work.

## Quick start

From this folder:

```bash
python scripts/run_version.py v6 --python
python scripts/run_version.py v5 --python --sweep
python scripts/run_version.py v4 --python
```

Without `--python`, each package attempts to build/use its local C++ pybind11 extension. The Python fallback is included for portability.

## Folder layout

```text
versions/
  v1_shared_moment_consistency/
  v2_shape_robustness_consistency/
  v3_profile_derived_stiffness/
  v4_four_profile_admissibility/
  v5_profile_zoo_selector/
  v6_smooth_matched_root_selector/
archives_original_zips/
  original generated zip packages
scripts/
  run_version.py
CANON_STATUS.md
MANIFEST.md
```

## Summary

Versions 1 and 2 are archived as consistency/arithmetic checks. They assume the shared-moment ansatz

\[
I_\chi=\rho_f J,
\quad
K_\chi=\rho_f v_{\rm swirl}^2J,
\]

so \(c_\chi=v_{\rm swirl}\) follows algebraically. They are not physical verification packages.

Versions 3 through 6 replace this with profile-derived stiffness:

\[
K_\chi=\rho_f\int_A v_\theta(r)^2 r_\perp^2\,dA.
\]

The current best route is the smooth-matched polynomial family in v5/v6, with root

\[
a_0^\star=\frac{\sqrt{385}-13}{4}\approx1.6553542176.
\]

See `CANON_STATUS.md` for the epistemic status.
