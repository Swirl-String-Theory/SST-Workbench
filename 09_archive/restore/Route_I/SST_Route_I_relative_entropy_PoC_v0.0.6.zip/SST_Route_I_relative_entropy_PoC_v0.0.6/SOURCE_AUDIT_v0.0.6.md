# Source Audit v0.0.6

## Authority order used

1. `SST_CANON-v0.8.28.tex`
2. `SST_CANON-v0.8.28-research-track.tex`
3. `SST-00_90_source_latex.zip`
4. v0.0.5 Route-I package

## Source-supported ingredients

The current Research Track explicitly supplies:

- Route I as thermodynamic gravity;
- the line-piercing area-law target with independently derived vacuum density;
- a minimal compact relational link phase
  \(U_e=e^{i\vartheta_e}\in U(1)\);
- the discrete Gauss constraint and compact plaquette action;
- the weak-field transverse sector;
- the requirement of two transverse modes and no physical longitudinal mode;
- the compact-defect/deconfinement gate;
- three distinct interpretations of the adjacency scale;
- Scenario C as relational or dynamical adjacency.

The archived papers contribute only contextual support:

- `SST-23_Hydrodynamic_Dual-Vacuum_Unification.tex` motivates an accelerated
  torsional/Unruh-like sector, but does not derive a boundary microstate density.
- `SST-56_superfluid.tex` supplies topology/lifetime diagnostics, but not a
  local entropy alphabet of the required size.
- `SST-63_Holograpic.tex` supplies boundary reconstruction language and global
  sector labels, but does not derive an area-law coefficient.

## New content in v0.0.6

The following is new Research-Track construction rather than established
CANON:

1. a periodic three-torus cellular complex as the common numerical carrier;
2. fluctuating metric Hodge weights on a frozen combinatorial complex;
3. a boundary trace-rank definition of the channel density;
4. exact bookkeeping separating coexact, gradient, harmonic, and defect sectors;
5. the resulting dimensionless coefficient \(\nu_{\mathrm{ch}}=2\);
6. a covariance calculation for a frozen weak boundary excitation.

## Unsupported claims deliberately excluded

The sources do not support, and v0.0.6 does not claim:

- a derivation of the physical adjacency length \(a_\star\);
- full dynamic edge creation/deletion;
- nonperturbative deconfinement of this precise SST microstructure;
- a protected extensive local topological alphabet;
- a numerical prediction of \(G\) or \(\eta_A^{\mathrm{SST}}\) in SI units.

## Epistemic classification

\[
\boxed{
\text{Research Track common foundation; exact linear algebra plus finite-size numerical certification.}
}
\]
