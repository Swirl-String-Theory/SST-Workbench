# Validation — v0.1.0

Validation performed in the artifact build environment on 2026-08-21.

- C++17 `cpp/core.cpp` standalone compilation with GCC 14.2 + OpenMP: **PASS**.
- Python regression suite: **4/4 PASS**.
- Synthetic trefoil end-to-end fallback smoke test (blind prepare -> modal delay prediction -> nonlinear paired evolution): **PASS**.
- The build environment does not contain pybind11 headers/package, so the actual pybind extension could not be compiled here. The Windows workflow therefore contains a strict native import gate and a native-vs-Python velocity parity test; no scientific campaign starts unless these pass.
- C++ wrapper uses `py::ssize_t` dimensions and converts NumPy buffers before releasing the GIL, avoiding the Python-3.14/MSVC issues seen in earlier SST workbench iterations.

Synthetic smoke-test values in this environment (Python fallback, deliberately low resolution):

```text
delay_score ~ 7.276e-3
observed_growth ~ 1.624e-2 (dimensionless inverse-time units)
```

These are implementation smoke-test values only, not physical SST results and not acceptance targets.
