# SST Two-Harmonic Phase-Chirality Floquet Blind Falsifier v0.1.0

Python reference + C++17/pybind11 backend template for a blind dynamical-symmetry test inspired by two-colour Floquet control.

## What v0.1.0 tests

1. C3 symmetry of the dimensionless T(2,3) trefoil seed.
2. Exact C3 dynamical symmetry of the counter-rotating \(\omega/2\omega\) drive.
3. Numerical equivariance of the vortex-filament flow under the corresponding time shift + rotation.
4. Separation from the co-rotating positive-control arm.
5. Numerical stability diagnostics.

Formal Floquet multipliers are **not** claimed unless a periodic/relative-periodic orbit is independently certified.

## Run Python reference

```bat
run_python.cmd
```

## Build and run C++/pybind11

Use a Visual Studio Developer Command Prompt, then:

```bat
run_build_cpp.cmd
run_all.cmd
```

## Output convention

`./SST_Two_Harmonic_Phase_Chirality_Floquet_Blind_Falsifier_v0.1.0-outputs/`

with sibling `*_outputs_BLIND.zip`, `*_outputs_REVEALED.zip`, and SHA-256 files.

## Blindness

v0.1.0 is dimensionless and uses no SST canonical constants. Private reveal mappings are excluded from the BLIND archive.
