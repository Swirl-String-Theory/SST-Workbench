@echo off
setlocal
cd /d "%~dp0"
if not exist .venv py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -q numpy pytest
python -m pytest -q || exit /b 1
python -m sst_thpcf.campaign --config configs\smoke.json --backend python --root . --reveal --package
endlocal
