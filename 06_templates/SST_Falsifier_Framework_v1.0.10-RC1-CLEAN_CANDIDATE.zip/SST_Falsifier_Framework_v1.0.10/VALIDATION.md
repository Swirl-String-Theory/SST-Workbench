# v1.0.10 local validation — 2026-10-19

- Base: exact clean v1.0.9 canonical ZIP, verified source manifest `104/104` and original manifest SHA-256 PASS.
- Full regression: **81 PASS** (72 inherited, 9 new gate execution/qualification/reveal tests).
- Generated-instance smoke: two sequential BASIC runs, two unique PDFs and blind ZIPs, archived previous output **PASS**.
- Generated-instance actual FULL diagnostic run: G2 FAIL, G3 PASS but DIAGNOSTIC_ONLY, G8 PASS but DIAGNOSTIC_ONLY; other enabled gates attempted; `REVEAL` preflight withheld; output manifest integrity **PASS**.
- Numerical C++/SYCL/DD32 kernels unchanged from v1.0.9; **no new target-machine hardware backend test in this environment**.
- Status: LOCAL_VALIDATED_CANDIDATE. Windows native `run_all.cmd ALL`, DD32 and both smoke scripts are required to promote the exact release ZIP to canonical.
- Technical limitations: cannot force arbitrary pre-existing custom instance pipelines to stop checking `dependencies_pass`; explicit migration is needed. Unknown exceptions remain fatal. Disabled and genuinely data-ineligible gates cannot be numerically evaluated.
