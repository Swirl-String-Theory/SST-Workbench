# SST Two-Harmonic Phase-Chirality Floquet Blind Falsifier v0.2.0

v0.2.0 upgrades the v0.1.0 analytic/LIA architecture test to a **dimensionless regularized finite-core nonlocal filament surrogate** driven by a two-colour \(\omega/2\omega\) waveform.

## New in v0.2.0

- four frozen A038 trefoil candidates are bundled as opaque Nx3 inputs;
- raw input hashes are fail-closed before dynamics;
- the drive is built from an explicit two-colour planar waveform and converted to a trace-free strain coupling;
- local-induction dynamics are replaced by regularized nonlocal segment summation;
- a finite-core ladder \(a/\Delta s\) is preregistered;
- a temporal refinement gate is added;
- the production C++17 backend uses OpenMP and defaults to 16 native threads;
- numerical and physics verdicts are separated;
- formal Floquet analysis remains blocked until an independently certified periodic or relative-periodic orbit exists;
- E010/PKLSA provenance is frozen in `data/provenance/`; a PKLSA centerline is never reconstructed from metadata.

## Run

Python smoke test:

```bat
run_smoke.cmd
```

Native basic campaign (Visual Studio Developer Command Prompt):

```bat
run_build_cpp.cmd
run_all.cmd
```

Extended campaign:

```bat
run_all_extended.cmd
```

## Output

`./SST_Two_Harmonic_Phase_Chirality_Floquet_Blind_Falsifier_v0.2.0-outputs/`

and sibling `*_outputs_BLIND.zip` / `*_outputs_REVEALED.zip` archives.

## Scientific status

This is a blind **dimensionless finite-core surrogate**. It does not identify graphene Berry curvature with fluid vorticity and does not claim a closed SST mechanism. No SST calibration constants are used in the blind campaign.
