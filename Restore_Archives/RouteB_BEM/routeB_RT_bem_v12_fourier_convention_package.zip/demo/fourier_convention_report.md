# BEMv12 Fourier-convention report

This report is alpha-blind: it does not contain or compare with observed fine structure.

BEMv12 audits why the printed Fourier coefficients and the database `L` column do not give exactly the same arclength.

## Target budget

- `target`: `3_1`
- `target_id`: `3:1:1`
- `N_samples`: `32000`
- `L_database`: `16.371637`
- `L_fourier_raw`: `16.3724604307158`
- `scale_factor_to_database_L`: `0.9999497063548093`
- `delta_L_raw_minus_database`: `0.0008234307158012655`
- `rel_L_raw_minus_database`: `5.0296174768672523e-05`
- `alpha_inv_lead_fourier_raw`: `137.16160376087024`
- `alpha_inv_lead_database_L`: `137.15470540383689`
- `delta_alpha_raw_minus_database`: `0.0068983570333500666`
- `status`: `ALPHA_BLIND_V12_LENGTH_CONVENTION_BUDGET_NO_CODATA`

## Rounding sensitivity

- `L_nominal`: `16.3724604307158`
- `L_database`: `16.371637`
- `delta_nominal_minus_database`: `0.0008234307158012655`
- `L_jitter_std`: `3.2719794504782225e-06`
- `L_jitter_span`: `1.621818070773884e-05`
- `delta_over_rounding_std`: `251.66133475591215`
- `rounding_covers_database_delta_3sigma`: `False`

## Interpretation

If the convention variants leave the length essentially unchanged while the rounding sensitivity is comparable to the database mismatch, the likely source is printed-coefficient precision or database/Fourier approximation provenance, not numerical integration.

## Output files

- `fourier_convention_audit.csv`
- `coefficient_rounding_sensitivity.csv`
- `scale_normalization_audit.csv`
- `alpha_leading_v12_budget.csv`