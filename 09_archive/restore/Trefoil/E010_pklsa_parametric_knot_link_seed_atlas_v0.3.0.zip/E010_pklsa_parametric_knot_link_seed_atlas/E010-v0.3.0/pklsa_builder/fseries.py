from __future__ import annotations
from pathlib import Path
import re, numpy as np

_HEADER=re.compile(r'^\s*%|^\s*#')

def parse_fremlin_fseries(path):
    """Decode Fremlin's six-column Fourier coefficient records.

    Each non-comment row is harmonic n=1..M with columns
    x_cos, x_sin, y_cos, y_sin, z_cos, z_sin. This is the
    convention exhibited by the archived Fremlin SST source files.
    The function returns the coefficient array without sampling it.
    """
    rows=[]
    header=[]
    for raw in Path(path).read_text(encoding='utf-8',errors='replace').splitlines():
        s=raw.strip()
        if not s: continue
        if _HEADER.match(s):
            header.append(s); continue
        parts=s.replace(',',' ').split()
        if len(parts)!=6:
            raise ValueError(f"Fremlin fseries row must have six coefficients: {s[:100]}")
        try: row=[float(x) for x in parts]
        except ValueError as e: raise ValueError(f"non-numeric fseries row: {s[:100]}") from e
        rows.append(row)
    if not rows: raise ValueError('no Fourier coefficient rows')
    c=np.asarray(rows,float)
    if not np.isfinite(c).all(): raise ValueError('non-finite Fourier coefficients')
    return {'coefficients':c,'header':header}

def sample_fremlin_fseries(path_or_coeffs, n=1024, phase=0.0):
    if isinstance(path_or_coeffs,(str,Path)):
        coeff=parse_fremlin_fseries(path_or_coeffs)['coefficients']
    elif isinstance(path_or_coeffs,dict): coeff=np.asarray(path_or_coeffs['coefficients'],float)
    else: coeff=np.asarray(path_or_coeffs,float)
    t=np.linspace(0,2*np.pi,int(n),endpoint=False)+float(phase)
    k=np.arange(1,len(coeff)+1,dtype=float)[:,None]
    ct=np.cos(k*t[None,:]); st=np.sin(k*t[None,:])
    out=np.empty((int(n),3),float)
    out[:,0]=(coeff[:,0,None]*ct + coeff[:,1,None]*st).sum(axis=0)
    out[:,1]=(coeff[:,2,None]*ct + coeff[:,3,None]*st).sum(axis=0)
    out[:,2]=(coeff[:,4,None]*ct + coeff[:,5,None]*st).sum(axis=0)
    return out
