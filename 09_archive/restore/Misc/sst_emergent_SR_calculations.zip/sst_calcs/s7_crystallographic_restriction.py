#!/usr/bin/env python3
"""
s7_crystallographic_restriction.py  —  AUDIT §7  (conversation turn 19)

CLAIM UNDER TEST
    Icosahedral symmetry (needed to kill the dim-6 cubic photon anisotropy) requires
    5-fold axes, which NO periodic lattice can carry: a lattice rotation must be an
    integer matrix in the lattice basis, hence have integer trace, but
    trace(n-fold) = 1 + 2 cos(2 pi / n) is non-integer for n = 5.
    Only n = 1,2,3,4,6 are lattice-compatible. Cubic uses 2,3,4 (allowed) but keeps
    dim-6 anisotropy; icosahedral needs 5-fold (forbidden) -> continuous/quasicrystal only.

STATUS: [DERIVED NEGATIVE for icosahedral crystal]
"""
import numpy as np
print("n-fold rotation:  trace = 1 + 2 cos(2 pi / n)  must be INTEGER for a lattice symmetry\n")
allowed=[]
for n in [1,2,3,4,5,6,7,8,10,12]:
    tr = 1 + 2*np.cos(2*np.pi/n)
    ok = abs(tr - round(tr)) < 1e-9
    if ok: allowed.append(n)
    print(f"  n={n:2d}:  trace={tr:+.4f}   {'ALLOWED' if ok else 'FORBIDDEN'}")
print(f"\nlattice-compatible rotation orders: {allowed}")
assert set(allowed) == {1,2,3,4,6}
assert 5 not in allowed                          # icosahedral (5-fold) impossible in a crystal
print("5-fold trace = 1 + phi (golden ratio, irrational) -> no icosahedral CRYSTAL.")
print("Cubic group uses 2,3,4-fold -> allowed, but retains dim-6 cubic anisotropy.")
print("\nALL §7-crystallography CHECKS PASSED.")
