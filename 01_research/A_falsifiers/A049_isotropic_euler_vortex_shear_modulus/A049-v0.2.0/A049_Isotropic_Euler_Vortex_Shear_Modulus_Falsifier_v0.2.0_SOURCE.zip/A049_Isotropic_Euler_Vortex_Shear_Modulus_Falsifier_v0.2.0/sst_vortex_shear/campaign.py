from pathlib import Path
import csv
import hashlib
import json
import math
import numpy as np

from .backend import energy_ratio_general, backend_name
from .reference import (
    fit_even_energy_coefficient,
    isotropy_tensor,
    transverse_residual,
    energy_ratio_helicity_pair,
    transverse_wave_ratio_from_A2,
    linearized_rest_euler_frequency,
)
from .sampling import paired_transverse_samples, rotation_matrix, shear_matrix
from .euler_spectral import (
    EulerSpectral3D,
    random_isotropic_background,
    velocity_covariance_isotropy,
    helical_probe_field,
    probe_descriptor,
    probe_amplitude,
    fit_complex_mode,
)

THEORY_A2 = 2.0 / 15.0
THEORY_C_OVER_URMS = math.sqrt(THEORY_A2)


def _load_config(config_path):
    return json.loads(Path(config_path).read_text(encoding="utf-8"))


def _write_csv(path, fieldnames, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _rel_l2(a, b):
    a = np.asarray(a)
    b = np.asarray(b)
    return float(np.linalg.norm((a-b).ravel()) / max(np.linalg.norm(b.ravel()), 1e-300))


def verify_seal(blind_dir):
    blind = Path(blind_dir)
    seal = blind / "BLIND_SEAL_SHA256.txt"
    if not seal.exists():
        return False, ["BLIND_SEAL_SHA256.txt missing"]
    errors = []
    for line in seal.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        p = blind / rel
        if not p.exists():
            errors.append(f"missing:{rel}")
        elif _sha256(p) != digest:
            errors.append(f"hash:{rel}")
    return len(errors) == 0, errors


def _static_born_campaign(cfg):
    gammas = np.asarray(cfg["strain_amplitudes"], dtype=float)
    planes = list(cfg["shear_planes"])
    n_pair, w_pair, n_base, e1, e2 = paired_transverse_samples(cfg["n_directions"])
    trans_res = transverse_residual(n_pair, w_pair)
    iso = isotropy_tensor(n_base)
    iso_res = float(np.linalg.norm(iso - np.eye(3)/3.0))
    rows = []
    fits = {}
    max_odd = 0.0
    max_helicity = 0.0
    for plane in planes:
        rp, rm = [], []
        for g in gammas:
            fp = shear_matrix(+g, plane); fm = shear_matrix(-g, plane)
            ap = energy_ratio_general(n_pair, w_pair, fp)
            am = energy_ratio_general(n_pair, w_pair, fm)
            rp.append(ap); rm.append(am)
            odd = 0.5*(ap-am)
            max_odd = max(max_odd, abs(odd))
            hp, hm = energy_ratio_helicity_pair(n_base, e1, e2, fp)
            max_helicity = max(max_helicity, abs(hp-hm))
            rows.append({
                "plane": plane, "gamma": float(g), "R_plus": ap, "R_minus": am,
                "even_delta": 0.5*(ap+am)-1.0, "odd_component": odd,
                "helicity_plus_ratio": hp, "helicity_minus_ratio": hm,
            })
        fit = fit_even_energy_coefficient(gammas, rp, rm)
        fit["relative_error_vs_2_over_15"] = abs(fit["A2"]-THEORY_A2)/THEORY_A2
        fit["candidate_cT_over_urms"] = transverse_wave_ratio_from_A2(fit["A2"])
        fits[plane] = fit
    vals = np.array([fits[p]["A2"] for p in planes])
    A2 = float(vals.mean())
    spread = float((vals.max()-vals.min())/abs(A2))
    return {
        "rows": rows, "transverse_residual": trans_res, "orientation_tensor": iso.tolist(),
        "orientation_isotropy_fro": iso_res, "plane_fits": fits, "A2_mean": A2,
        "A2_plane_relative_spread": spread, "candidate_cT_over_urms": math.sqrt(max(A2,0.0)),
        "max_odd_energy_component": max_odd, "helicity_split_max_abs": max_helicity,
    }


def _dynamic_probe_set(grid, cfg):
    probes, descs = [], []
    amp = float(cfg["probe_amplitude"])
    primary_mode = int(cfg["primary_mode"])
    secondary_mode = int(cfg["secondary_mode"])
    for axis in cfg["primary_axes"]:
        for helicity in (-1, +1):
            probes.append(helical_probe_field(grid, axis, primary_mode, helicity, amp))
            descs.append(probe_descriptor(grid, axis, primary_mode, helicity))
    for helicity in (-1, +1):
        probes.append(helical_probe_field(grid, cfg["secondary_axis"], secondary_mode, helicity, amp))
        descs.append(probe_descriptor(grid, cfg["secondary_axis"], secondary_mode, helicity))
    return np.stack(probes), descs


def _run_dynamic(cfg, n_override=None, reduced=False):
    dc = cfg["dynamic"]
    n = int(n_override or dc["grid_n"])
    grid = EulerSpectral3D(n=n, length=float(dc["domain_length"]))
    u = random_isotropic_background(
        grid, int(cfg["seed"]), float(dc["background_shell_min"]),
        float(dc["background_shell_max"]), float(dc["background_urms"])
    )
    cov, cov_iso = velocity_covariance_isotropy(grid, u)
    e0 = grid.energy(u)
    urms0 = grid.urms(u)
    div0 = grid.divergence_fourier_rel(u)

    if reduced:
        # Coarse sign-control only: one primary direction, both helicities.
        amp = float(dc["probe_amplitude"])
        ax = dc["secondary_axis"]
        mode = int(dc["primary_mode"])
        probes = np.stack([helical_probe_field(grid, ax, mode, h, amp) for h in (-1,+1)])
        descs = [probe_descriptor(grid, ax, mode, h) for h in (-1,+1)]
    else:
        probes, descs = _dynamic_probe_set(grid, dc)
    d = probes
    divd0 = grid.divergence_fourier_rel(d)

    dt = float(dc["dt"])
    t_final = float(dc["t_final"])
    if reduced:
        t_final = min(t_final, float(dc.get("coarse_t_final", 2.0)))
    steps = int(round(t_final/dt))
    stride = int(dc["sample_stride"])
    times = [0.0]
    amps = [[probe_amplitude(d, desc, i)] for i, desc in enumerate(descs)]
    energies = [e0]
    max_div = div0

    for step in range(1, steps+1):
        u, d = grid.rk4_step(u, d, dt)
        if step % stride == 0 or step == steps:
            times.append(step*dt)
            energies.append(grid.energy(u))
            max_div = max(max_div, grid.divergence_fourier_rel(u), grid.divergence_fourier_rel(d))
            for i, desc in enumerate(descs):
                amps[i].append(probe_amplitude(d, desc, i))

    # Local time-step consistency: one dt step vs two half steps from the same initial state.
    uinit = random_isotropic_background(
        grid, int(cfg["seed"]), float(dc["background_shell_min"]),
        float(dc["background_shell_max"]), float(dc["background_urms"])
    )
    if reduced:
        amp = float(dc["probe_amplitude"]); ax = dc["secondary_axis"]; mode = int(dc["primary_mode"])
        dinit = np.stack([helical_probe_field(grid, ax, mode, h, amp) for h in (-1,+1)])
    else:
        dinit, _ = _dynamic_probe_set(grid, dc)
    u1, d1 = grid.rk4_step(uinit, dinit, dt)
    uh, dh = grid.rk4_step(uinit, dinit, 0.5*dt)
    u2, d2 = grid.rk4_step(uh, dh, 0.5*dt)
    timestep_rel = max(_rel_l2(u1, u2), _rel_l2(d1, d2))

    energy_drift = float(np.max(np.abs(np.asarray(energies)-e0))/e0)
    probe_rows = []
    fits = []
    qtol = cfg["wave_qualification"]
    for i, desc in enumerate(descs):
        fit = fit_complex_mode(times, amps[i], float(dc["fit_min_relative_amplitude"]))
        c_ratio = fit["omega_abs"] / max(desc["k"]*urms0, 1e-300)
        damping_ratio = abs(fit["log_amplitude_rate"]) / max(fit["omega_abs"], 1e-300)
        qualified = (
            fit["phase_fit_r2"] >= float(qtol["phase_fit_r2_min"])
            and fit["coherent_fit_fraction"] >= float(qtol["coherent_fit_fraction_min"])
            and c_ratio >= float(qtol["c_over_urms_min"])
            and damping_ratio <= float(qtol["damping_over_omega_max"])
        )
        rec = {
            "axis": desc["axis"], "mode": desc["mode"], "helicity": desc["helicity"],
            "k": desc["k"], **fit, "c_over_urms": c_ratio,
            "damping_over_omega": damping_ratio, "wave_qualified": bool(qualified),
        }
        fits.append(rec)
        # Save time-series compactly as semicolon-separated real diagnostics is avoided; rows below are per sample.
        for t, a in zip(times, amps[i]):
            probe_rows.append({
                "axis": desc["axis"], "mode": desc["mode"], "helicity": desc["helicity"],
                "time": float(t), "amplitude_real": float(np.real(a)), "amplitude_imag": float(np.imag(a)),
                "amplitude_abs_rel": float(abs(a)/max(abs(amps[i][0]),1e-300)),
                "phase_rel_rad": float(np.angle(a/amps[i][0])),
            })

    # Aggregate symmetry/dispersion diagnostics. They are only physics-qualified if each constituent pole qualifies.
    primary_mode = int(dc["primary_mode"]); secondary_mode = int(dc["secondary_mode"])
    primary = [r for r in fits if r["mode"] == primary_mode]
    secondary = [r for r in fits if r["mode"] == secondary_mode]
    c_primary = np.array([r["c_over_urms"] for r in primary], dtype=float)
    c_secondary = np.array([r["c_over_urms"] for r in secondary], dtype=float)
    c_primary_median = float(np.median(c_primary)) if len(c_primary) else math.nan
    c_secondary_median = float(np.median(c_secondary)) if len(c_secondary) else math.nan
    direction_spread = float((c_primary.max()-c_primary.min())/max(abs(c_primary_median),1e-300)) if len(c_primary) else math.inf

    helicity_splits = []
    for mode in sorted(set(r["mode"] for r in fits)):
        axes = sorted(set(r["axis"] for r in fits if r["mode"] == mode))
        for axis in axes:
            pair = [r for r in fits if r["mode"] == mode and r["axis"] == axis]
            if len(pair) == 2:
                a, b = pair
                helicity_splits.append(abs(a["c_over_urms"]-b["c_over_urms"]) / max(0.5*(a["c_over_urms"]+b["c_over_urms"]),1e-300))
    helicity_split = max(helicity_splits, default=math.inf)
    dispersion_rel = abs(c_primary_median-c_secondary_median)/max(abs(c_primary_median),1e-300) if len(secondary) else math.inf

    # Spectral occupancy diagnostic near the de-alias boundary; reported but deliberately not used as a physics gate.
    modes = np.fft.fftfreq(n)*n
    mx,my,mz = np.meshgrid(modes,modes,modes,indexing="ij")
    cutoff = n//3
    edge = np.maximum.reduce([np.abs(mx),np.abs(my),np.abs(mz)]) >= cutoff
    edge_fraction = float(np.sum(np.abs(u[edge])**2)/max(np.sum(np.abs(u)**2),1e-300))

    return {
        "n": n, "background_urms_initial": urms0, "background_covariance_normalized": cov.tolist(),
        "background_covariance_isotropy_fro": cov_iso, "initial_divergence_rel": div0,
        "initial_probe_divergence_rel": divd0, "max_divergence_rel": max_div,
        "base_energy_initial": e0, "base_energy_drift_rel_max": energy_drift,
        "rk4_one_step_vs_two_half_rel_l2": timestep_rel,
        "spectral_edge_energy_fraction_final": edge_fraction,
        "probe_fits": fits, "probe_rows": probe_rows,
        "qualified_probe_count": int(sum(r["wave_qualified"] for r in fits)),
        "probe_count": len(fits), "all_probes_qualified": bool(all(r["wave_qualified"] for r in fits)),
        "primary_c_over_urms_median_diagnostic": c_primary_median,
        "secondary_c_over_urms_median_diagnostic": c_secondary_median,
        "direction_spread_relative_diagnostic": direction_spread,
        "helicity_split_relative_diagnostic": helicity_split,
        "dispersion_relative_diagnostic": dispersion_rel,
    }


def run_blind_campaign(config_path, out_dir):
    cfg = _load_config(config_path)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    tol = cfg["tolerances"]

    born = _static_born_campaign(cfg)
    dynamic = _run_dynamic(cfg, reduced=False)
    coarse = _run_dynamic(cfg, n_override=int(cfg["dynamic"]["coarse_grid_n"]), reduced=True)

    # Bare Euler rest no-wave control retained.
    kprobe = np.array([1.0,2.0,-3.0]); uprobe = np.cross(kprobe, np.array([0.3,-0.4,0.8])); uprobe /= np.linalg.norm(uprobe)
    rest_accel, rest_trans = linearized_rest_euler_frequency(kprobe, uprobe)

    qualification = {
        "Q01_STATIC_TRANSVERSE_SAMPLING": born["transverse_residual"] < tol["static_transverse_max_abs"],
        "Q02_STATIC_A2_RECOVERY": abs(born["A2_mean"]-THEORY_A2)/THEORY_A2 < tol["static_A2_relative_error_max"],
        "Q03_DYNAMIC_INITIAL_ISOTROPY": dynamic["background_covariance_isotropy_fro"] < tol["dynamic_initial_isotropy_fro_max"],
        "Q04_DYNAMIC_INCOMPRESSIBILITY": dynamic["max_divergence_rel"] < tol["dynamic_divergence_rel_max"],
        "Q05_DYNAMIC_ENERGY_CONSERVATION": dynamic["base_energy_drift_rel_max"] < tol["dynamic_energy_drift_rel_max"],
        "Q06_RK4_LOCAL_CONVERGENCE": dynamic["rk4_one_step_vs_two_half_rel_l2"] < tol["rk4_local_convergence_rel_max"],
        "Q07_BARE_REST_EULER_NO_WAVE": rest_accel < tol["rest_euler_operator_abs_max"],
    }
    qualification = {k:bool(v) for k,v in qualification.items()}

    # Research hypothesis: a universal conservative transverse pole must survive every primary-axis/helicity probe,
    # have small damping, and satisfy isotropy/helicity/linear-dispersion consistency.
    dc = cfg["dynamic"]; wq = cfg["wave_qualification"]
    all_primary = [r for r in dynamic["probe_fits"] if r["mode"] == int(dc["primary_mode"])]
    secondary = [r for r in dynamic["probe_fits"] if r["mode"] == int(dc["secondary_mode"])]
    dynamic_wave_exists = bool(all(r["wave_qualified"] for r in all_primary) and all(r["wave_qualified"] for r in secondary))
    isotropic_wave = dynamic_wave_exists and dynamic["direction_spread_relative_diagnostic"] <= float(wq["direction_spread_relative_max"])
    helicity_degenerate = dynamic_wave_exists and dynamic["helicity_split_relative_diagnostic"] <= float(wq["helicity_split_relative_max"])
    linear_dispersion = dynamic_wave_exists and dynamic["dispersion_relative_diagnostic"] <= float(wq["dispersion_relative_max"])
    coarse_same_sign = not coarse["all_probes_qualified"] if not dynamic_wave_exists else coarse["all_probes_qualified"]

    hypothesis = {
        "H01_NONZERO_BORN_MODULUS_RETAINED": born["A2_mean"] > 0.0,
        "H02_COHERENT_DYNAMIC_TRANSVERSE_POLE": dynamic_wave_exists,
        "H03_DYNAMIC_DIRECTION_ISOTROPY": isotropic_wave,
        "H04_DYNAMIC_HELICITY_DEGENERACY": helicity_degenerate,
        "H05_APPROX_LINEAR_DISPERSION": linear_dispersion,
        "H06_COARSE_RESOLUTION_SAME_QUALIFICATION_SIGN": coarse_same_sign,
    }
    hypothesis = {k:bool(v) for k,v in hypothesis.items()}

    target = float(cfg["master_factor_wave_gate"]["target_cT_over_reference_speed"])
    mtol = float(cfg["master_factor_wave_gate"]["absolute_tolerance"])
    born_master_error = abs(born["candidate_cT_over_urms"]-target)
    mf01 = born_master_error <= mtol
    if dynamic_wave_exists and isotropic_wave and helicity_degenerate and linear_dispersion:
        dyn_c = 0.5*(dynamic["primary_c_over_urms_median_diagnostic"] + dynamic["secondary_c_over_urms_median_diagnostic"])
        mf02_status = "PASS" if abs(dyn_c-target) <= mtol else "FAIL"
    else:
        dyn_c = None
        mf02_status = "NOT_REACHED_NO_QUALIFIED_WAVE"
    master_overall = "PASS" if (mf01 and mf02_status == "PASS") else "NOT_CLOSED"

    pipeline = "PIPELINE_QUALIFIED" if all(qualification.values()) else "PIPELINE_FAILED"
    if pipeline != "PIPELINE_QUALIFIED":
        research = "INCONCLUSIVE_NUMERICAL_QUALIFICATION_FAILED"
    elif all([dynamic_wave_exists,isotropic_wave,helicity_degenerate,linear_dispersion]):
        research = "SUPPORTED_DYNAMIC_CONSERVATIVE_TRANSVERSE_MODULUS"
    else:
        research = "NOT_SUPPORTED_AT_V0.2.0_DYNAMIC_RESOLUTION"

    summary = {
        "catalog_id": "A049", "falsifier": "A049_isotropic_euler_vortex_shear_modulus_falsifier",
        "version": cfg["version"], "blind": True, "backend": backend_name(),
        "pipeline_status": pipeline, "research_question_status": research,
        "static_born_status": "SUPPORTED_AT_FROZEN_IN_AFFINE_BORN_LEVEL" if born["A2_mean"]>0 else "NOT_SUPPORTED",
        "dynamic_wave_status": "QUALIFIED" if dynamic_wave_exists else "NO_UNIVERSAL_QUALIFIED_TRANSVERSE_POLE",
        "master_factor_wave_closure_status": master_overall,
        "scope_guard": (
            "v0.2.0 advances from the affine Born test to a dealiased pseudospectral 3D incompressible Euler background "
            "with tangent-linear transverse helical probes. A negative dynamic result is reported as resolution-bounded: "
            "it does not prove impossibility for every Euler vortex microstructure, topology, or continuum limit."
        ),
        "static_born": born,
        "dynamic_primary": {k:v for k,v in dynamic.items() if k != "probe_rows"},
        "dynamic_coarse_control": {k:v for k,v in coarse.items() if k != "probe_rows"},
        "bare_rest_euler_control": {"acceleration_operator_abs": rest_accel, "transverse_residual": rest_trans},
        "qualification_gates": qualification, "hypothesis_gates": hypothesis,
        "master_factor_wave_gate": {
            "target_cT_over_reference_speed": target,
            "absolute_tolerance": mtol,
            "MF01_BORN_SPEED_RATIO": "PASS" if mf01 else "FAIL",
            "born_cT_over_urms": born["candidate_cT_over_urms"],
            "born_absolute_error": born_master_error,
            "MF02_DYNAMIC_SPEED_RATIO": mf02_status,
            "dynamic_cT_over_urms_if_qualified": dyn_c,
            "overall": master_overall,
            "guard": "Dynamic master closure is never inferred from an unqualified/noisy phase fit."
        }
    }

    _write_csv(out/"static_shear_scan.csv", list(born["rows"][0].keys()), born["rows"])
    _write_csv(out/"dynamic_probe_timeseries.csv", list(dynamic["probe_rows"][0].keys()), dynamic["probe_rows"])
    _write_csv(out/"coarse_probe_timeseries.csv", list(coarse["probe_rows"][0].keys()), coarse["probe_rows"])
    (out/"blind_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")

    report = [
        "# A049 v0.2.0 blind report", "", f"Backend: **{summary['backend']}**", f"Pipeline: **{pipeline}**",
        f"Research question: **{research}**", f"Dynamic wave status: **{summary['dynamic_wave_status']}**",
        f"Master-Factor Wave Closure: **{master_overall}**", "", "## Static Born carry-forward", "",
        f"- A2 = {born['A2_mean']:.12e}", f"- candidate c_T/u_rms = {born['candidate_cT_over_urms']:.12e}", "",
        "## Dynamic Euler persistence test", "",
        f"- grid N = {dynamic['n']}", f"- initial isotropy Frobenius residual = {dynamic['background_covariance_isotropy_fro']:.6e}",
        f"- base-energy max relative drift = {dynamic['base_energy_drift_rel_max']:.6e}",
        f"- max divergence relative residual = {dynamic['max_divergence_rel']:.6e}",
        f"- RK4 one-step/two-half relative L2 = {dynamic['rk4_one_step_vs_two_half_rel_l2']:.6e}",
        f"- qualified probes = {dynamic['qualified_probe_count']}/{dynamic['probe_count']}",
        f"- primary median c/u_rms (diagnostic only) = {dynamic['primary_c_over_urms_median_diagnostic']:.6e}",
        f"- secondary median c/u_rms (diagnostic only) = {dynamic['secondary_c_over_urms_median_diagnostic']:.6e}",
        f"- direction spread (diagnostic) = {dynamic['direction_spread_relative_diagnostic']:.6e}",
        f"- helicity split (diagnostic) = {dynamic['helicity_split_relative_diagnostic']:.6e}",
        f"- dispersion mismatch (diagnostic) = {dynamic['dispersion_relative_diagnostic']:.6e}",
        f"- final de-alias-edge energy fraction (resolution diagnostic) = {dynamic['spectral_edge_energy_fraction_final']:.6e}",
        "", "## Probe fits", ""
    ]
    for r in dynamic["probe_fits"]:
        report.append(
            f"- k-mode {r['mode']} axis {r['axis']} h={r['helicity']:+d}: "
            f"c/u={r['c_over_urms']:.6e}, R2={r['phase_fit_r2']:.4f}, "
            f"|gamma|/|omega|={r['damping_over_omega']:.4f}, qualified={r['wave_qualified']}"
        )
    report += ["", "## Qualification gates", ""]
    for k,v in qualification.items(): report.append(f"- {k}: {'PASS' if v else 'FAIL'}")
    report += ["", "## Hypothesis gates", ""]
    for k,v in hypothesis.items(): report.append(f"- {k}: {'PASS' if v else 'FAIL'}")
    report += ["", "## Master-Factor Wave Closure", "", f"- MF01 Born ratio: {'PASS' if mf01 else 'FAIL'}", f"- MF02 dynamic ratio: {mf02_status}", f"- overall: {master_overall}", "", "## Scope guard", "", summary["scope_guard"]]
    (out/"blind_report.md").write_text("\n".join(report)+"\n",encoding="utf-8")
    return summary
