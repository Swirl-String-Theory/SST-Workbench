# Changelog v0.0.5

- Added a shared capacity/relative-entropy budget.
- Added Branch A: correlated Gaussian response and squeezing/energy audits.
- Added Branch B: topological alphabet growth and ropelength locality audits.
- Added Branch C: sub-core Weyl mode counting and source-independent candidate scales.
- Added capacity-valid B+C and diagnostic three-way trade-off frontiers.
- Added a no-double-counting merge gate.
- Added a Research-Track preview patch.
