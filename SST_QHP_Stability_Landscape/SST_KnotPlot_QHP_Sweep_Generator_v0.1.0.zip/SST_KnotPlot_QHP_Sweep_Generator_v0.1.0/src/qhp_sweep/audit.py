from __future__ import annotations
import csv,json,sys
from pathlib import Path

def main():
    root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('../../KnotPlot/qhp')
    meta=root/'qhp_metadata.csv'
    if not meta.exists(): raise SystemExit(f'Missing {meta}')
    rows=list(csv.DictReader(meta.open(encoding='utf-8')))
    bad=[r for r in rows if r.get('geometry_ok','').lower()!='true']
    fam=sorted(set(r['family'] for r in rows))
    print(json.dumps({'n_rows':len(rows),'families':fam,'n_geometry_rejected':len(bad),'pass':len(rows)>0},indent=2))
if __name__=='__main__': main()
