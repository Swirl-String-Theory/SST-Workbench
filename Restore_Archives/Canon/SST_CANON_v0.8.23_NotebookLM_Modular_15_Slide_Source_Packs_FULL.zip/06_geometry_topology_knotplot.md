# Geometry, topology, finite thickness, and KnotPlot provenance

## Slide 1/15 - Topology needs geometry

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- A knot type alone is not a physical carrier.
- Finite-core tubes need thickness, length, curvature, and contact control.
- Particle candidates need certified representatives.

**Single slide message:** A knot type alone is not a physical carrier.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 2/15 - Euler preservation and closure

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Ideal evolution transports vortex sectors.
- Creation/destruction/reconnection need explicit gates.
- Topology cannot change silently.

**Single slide message:** Ideal evolution transports vortex sectors.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 3/15 - Framed self-linking

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- A vortex tube has centerline and framing/twist data.
- Spin-like claims depend on framed structure.
- Bare projections miss framing.

**Single slide message:** A vortex tube has centerline and framing/twist data.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 4/15 - Bounded-domain curl spectrum

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Curl spectra test field reconstruction.
- Boundaries affect admissible spectra.
- Benchmarks need declared domains.

**Single slide message:** Curl spectra test field reconstruction.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 5/15 - Dark-knot classification

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Achiral knots may cancel first-order chirality response.
- They can retain local/second-order response.
- Dark/quasi-dark/active status must be measured.

**Single slide message:** Achiral knots may cancel first-order chirality response.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 6/15 - Orthodox ropelength definition

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Ropelength = length/thickness.
- Thickness is controlled by curvature and doubly critical self-distance.
- Minimizers exist but need not be smooth beyond C1,1.

**Single slide message:** Ropelength = length/thickness.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 7/15 - KnotPlot role

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- KnotPlot constructs and relaxes seeds.
- It is not a certificate of ideality.
- Outputs need topology and geometry sidecars.

**Single slide message:** KnotPlot constructs and relaxes seeds.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 8/15 - Ridgerunner role

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Ridgerunner minimizes length under thickness constraints.
- Active constraints are struts and kinks.
- KKT/NNLS residuals test criticality.

**Single slide message:** Ridgerunner minimizes length under thickness constraints.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 9/15 - Topology sidecars

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Record component count, linking, safe status, and provenance.
- Missing sidecars trigger conservative status.
- geometry-qualified-topology-unverified is a deliberate stop state.

**Single slide message:** Record component count, linking, safe status, and provenance.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 10/15 - Signed plateau selection

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use signed improvement, not absolute change.
- Later checkpoints can regress.
- best-so-far-no-plateau is not convergence.

**Single slide message:** Use signed improvement, not absolute change.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 11/15 - Radius vs diameter convention

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Gilbert database entries may use diameter convention D=1.
- SST radius-thickness convention doubles ropelength values.
- Every comparison must declare convention.

**Single slide message:** Gilbert database entries may use diameter convention D=1.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 12/15 - Trefoil candidate status

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Current 3_1 candidate is near-ideal, not final certified exact.
- Length and edge-uniformity can pass while strict residual/convergence remains open.
- N=600/1200 branches are required.

**Single slide message:** Current 3_1 candidate is near-ideal, not final certified exact.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 13/15 - Contact skeleton and Z_jump

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Struts, kinks, multipliers, rank, and condition number form mechanical skeleton.
- This may feed bound response Z_J(omega).
- It is not yet electric charge or mass.

**Single slide message:** Struts, kinks, multipliers, rank, and condition number form mechanical skeleton.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 14/15 - Certification ladder

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Seed -> relaxed candidate -> near-ideal -> strict near-ideal -> certified smooth upper bound.
- Each rung requires tests.
- Uncertainty propagates downstream.

**Single slide message:** Seed -> relaxed candidate -> near-ideal -> strict near-ideal -> certified smooth upper bound.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.

## Slide 15/15 - Topology closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- KnotPlot/Ridgerunner turn early closed-interference intuition into testable finite-thickness carriers.
- Physical interpretation comes only after certification.

**Single slide message:** KnotPlot/Ridgerunner turn early closed-interference intuition into testable finite-thickness carriers.

**Source anchors:** Geometric and Topological Sector; KnotPlot/Ridgerunner provenance; topology research appendices.

**Visual specification:** Finite tube, contact map, status ladder, and pipeline diagram.

**Do not generate:** Do not use a pretty knot image as proof of a particle state.
