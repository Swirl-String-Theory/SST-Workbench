from __future__ import annotations
import csv, hashlib, json, platform, secrets, sys, time
from pathlib import Path
import numpy as np
from .io import discover_dataset, load_components
from .geometry import resample_components, radius_gyration, kabsch_rms, metrics, random_rotation
from .thread_bundles import (fibonacci_sphere, local_source_closed_bundle, concatenate_bundles,
                             transform_bundle, closure_diagnostics, minimum_clearance)
from .integrator import integrate_rk4
from .native_ext.core import backend_name
from .constants import SST_CANONICAL, PACKAGE_VERSION


def _canonical(obj): return json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def _sha_bytes(b): return hashlib.sha256(b).hexdigest()
def _sha_file(p): return _sha_bytes(Path(p).read_bytes())
def _write_json(path,obj):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False),encoding="utf-8")

def _unit(rng):
    x=rng.normal(size=3); n=np.linalg.norm(x); return x/(n if n else 1.0)

def _geom_velocity_scale(gamma,rg): return abs(float(gamma))/(4*np.pi*max(float(rg),1e-15))

def _empty_bundle():
    return np.zeros((0,3),float),np.array([0],dtype=np.int64),np.zeros((0,),float),{"type":"empty"}

def _case_payload(points,offsets,bundle,dt,n_steps,knot_core,bg_core,gamma,frame_velocity,source_file_hash,rg):
    BV,BO,BG,_=bundle
    return dict(points=np.asarray(points,np.float64),offsets=np.asarray(offsets,np.int64),
                bg_vertices=np.asarray(BV,np.float64),bg_offsets=np.asarray(BO,np.int64),bg_gammas=np.asarray(BG,np.float64),
                dt=np.float64(dt),n_steps=np.int64(n_steps),knot_core=np.float64(knot_core),bg_core=np.float64(bg_core),
                gamma=np.float64(gamma),frame_velocity=np.asarray(frame_velocity,np.float64),
                source_file_hash=np.asarray(source_file_hash),rg=np.float64(rg))

def _bundle_ring_radius_rg(P,c,rg,margin_rg,min_rg):
    rmax=float(np.max(np.linalg.norm(P-c[None,:],axis=1)))
    return max(float(min_rg),rmax/max(rg,1e-15)+float(margin_rg))

def _make_source_bundle(P,c,rg,n,config,return_rg,source_D=None,total_gamma=None,phase=0.0,radial=True):
    D=float(config["source_distance_rg"] if source_D is None else source_D)
    ring=_bundle_ring_radius_rg(P,c,rg,config.get("bundle_ring_margin_rg",0.65),config.get("bundle_ring_min_rg",2.5))
    total=float(config["thread_total_gamma_ratio"]*config.get("gamma",1.0) if total_gamma is None else total_gamma)
    # Geometry-only clearance adaptation.  The same chosen ring is then used for all paired cases.
    min_clear=float(config.get("min_thread_clearance_rg",0.10))*rg
    for attempt in range(int(config.get("clearance_attempts",6))):
        bundle=local_source_closed_bundle(c,rg,n,D,int(config["n_threads"]),ring,
                                          float(config["active_half_length_rg"]),float(return_rg),
                                          total,phase=phase,radial=radial)
        clear=minimum_clearance(P,bundle[0],bundle[1])
        if clear>=min_clear:
            bundle[3]["initial_min_clearance_rg"]=clear/rg; bundle[3]["clearance_attempt"]=attempt; return bundle,ring
        ring += float(config.get("clearance_ring_increment_rg",0.5))
    bundle=local_source_closed_bundle(c,rg,n,D,int(config["n_threads"]),ring,
                                      float(config["active_half_length_rg"]),float(return_rg),
                                      total,phase=phase,radial=radial)
    clear=minimum_clearance(P,bundle[0],bundle[1])
    bundle[3]["initial_min_clearance_rg"]=clear/rg; bundle[3]["clearance_attempt"]="exhausted"
    return bundle,ring

def _make_source_bundle_fixed_ring(c,rg,n,config,ring,return_rg,source_D,total_gamma,phase,radial=True):
    return local_source_closed_bundle(c,rg,n,float(source_D),int(config["n_threads"]),float(ring),
                                      float(config["active_half_length_rg"]),float(return_rg),
                                      float(total_gamma),phase=float(phase),radial=radial)


def prepare_blind(config,dataset,out_dir):
    out=Path(out_dir); blind=out/"blind"; cases_dir=blind/"cases"; secret_dir=out/"secret"
    cases_dir.mkdir(parents=True,exist_ok=True); secret_dir.mkdir(parents=True,exist_ok=True)
    seed=int(config["blind_seed"]); rng=np.random.default_rng(seed)
    files=discover_dataset(dataset,int(config.get("max_files",0)),config.get("include_patterns"))
    if not files: raise RuntimeError(f"no supported geometry files under {dataset}")
    orientation_count=max(2,int(config.get("orientation_count",3)))
    Rglobal=random_rotation(rng); directions=fibonacci_sphere(orientation_count,Rglobal)
    precommit={
        "package_version":PACKAGE_VERSION,"created_unix":time.time(),"config":config,
        "config_sha256":_sha_bytes(_canonical(config).encode()),"dataset_root":str(Path(dataset).resolve()),
        "dataset_files":[{"path":str(p),"sha256":_sha_file(p)} for p in files],
        "precommitted_orientation_count":orientation_count,
        "epistemic_status":{
            "G0_G5":"STRUCTURAL_AND_DISCRETE_VORTICITY_VALIDITY",
            "G6_return_flux":"THREAD_MODEL_LIMIT_GATE",
            "G7_source_distance":"THREAD_MODEL_ASYMPTOTIC_GATE",
            "G8_plus":"MEASURED_RESPONSE_DIAGNOSTICS",
            "claim":"v0.2.0 replaces curl-free prescribed velocity proxies with explicit closed vortex-filament backgrounds. Passing is not a derivation of SST gravity or Lorentz symmetry."
        },
        "v010_result_driven_changes":{
            "old_radial_proxy_removed":True,"old_director_proxy_removed":True,"one_step_euler_removed":True,
            "core_radius_now_fixed_in_Rg":True,"rk4_multistep":True,"return_flux_closure_required":True,
            "spatial_standard_tol":config.get("spatial_convergence_standard_tol",0.02)
        },
        "sst_canonical_constants":SST_CANONICAL,
    }
    _write_json(out/"precommit.json",precommit)
    case_records=[]; group_records=[]; secret_map={"datasets":{},"groups":{},"orientation_directions":directions.tolist()}
    case_serial=0; group_serial=0; nres=int(config["resample_n"]); gamma=float(config.get("gamma",1.0))
    n_steps=int(config["n_steps"]); tf=float(config["final_time_fraction"]); boost_ratio=float(config["boost_ratio"])
    ret=list(map(float,config.get("return_offsets_rg",[12.0,24.0,48.0])))
    if len(ret)<3: raise ValueError("return_offsets_rg must contain near, mid, far")
    ret_near,ret_mid,ret_far=ret[0],ret[-2],ret[-1]
    translate_rg=float(config.get("covariance_translation_rg",11.0))

    def new_case(dataset_key,role,P,O,bundle,dt,knot_core,bg_core,frame_velocity,src_hash,rg):
        nonlocal case_serial
        case_serial+=1; cid=f"C{case_serial:06d}"; fn=cases_dir/f"{cid}.npz"
        np.savez_compressed(fn,**_case_payload(P,O,bundle,dt,n_steps,knot_core,bg_core,gamma,frame_velocity,src_hash,rg))
        case_records.append({"case_id":cid,"file":str(fn.relative_to(out)),"sha256":_sha_file(fn),"dataset_key":dataset_key})
        secret_map["datasets"].setdefault(dataset_key,{"roles":{}})["roles"][role]=cid
        return cid
    def new_group(dataset_key,role,case_ids,expectation="diagnostic"):
        nonlocal group_serial
        group_serial+=1; gid=f"P{group_serial:06d}"
        group_records.append({"group_id":gid,"case_ids":list(case_ids),"expectation":expectation,"dataset_key":dataset_key})
        secret_map["groups"][gid]=f"{dataset_key}:{role}"; return gid

    accepted=0; skipped=[]
    for p in files:
        try:
            comps=load_components(p); P,O=resample_components(comps,nres); rg=radius_gyration(P)
            if not np.isfinite(rg) or rg<=0: raise ValueError("invalid Rg")
            c=P.mean(axis=0); u0=_geom_velocity_scale(gamma,rg); T=tf*rg/max(u0,1e-15); dt=T/n_steps
            knot_core=float(config["knot_core_radius_rg"])*rg; bg_core=float(config.get("background_core_radius_rg",0.0))*rg
            phase=float(rng.uniform(0.0,2.0*np.pi)); n0=directions[0]
            total_gamma=float(config["thread_total_gamma_ratio"])*gamma
            main,ring=_make_source_bundle(P,c,rg,n0,config,ret_far,phase=phase)
            # Paired bundles reuse the same local ring radius and active thread placement.
            near=_make_source_bundle_fixed_ring(c,rg,n0,config,ring,ret_near,config["source_distance_rg"],total_gamma,phase,True)
            mid=_make_source_bundle_fixed_ring(c,rg,n0,config,ring,ret_mid,config["source_distance_rg"],total_gamma,phase,True)
            parallel=_make_source_bundle_fixed_ring(c,rg,n0,config,ring,ret_far,config["source_distance_rg"],total_gamma,phase,False)
            far_source=_make_source_bundle_fixed_ring(c,rg,n0,config,ring,ret_far,config["source_distance_far_rg"],total_gamma,phase,True)
            # Same hidden orientation set for every topology; only geometry changes.
            orient_bundles=[main]
            for oi in range(1,orientation_count):
                orient_bundles.append(_make_source_bundle_fixed_ring(c,rg,directions[oi],config,ring,ret_far,config["source_distance_rg"],total_gamma,phase,True))
            # Second source: different hidden direction, weaker precommitted circulation.
            n_sun=directions[1]
            sun_gamma=total_gamma*float(config.get("sun_strength_ratio",0.35))
            sun=_make_source_bundle_fixed_ring(c,rg,n_sun,config,ring,ret_far,config.get("sun_source_distance_rg",24.0),sun_gamma,phase+0.37,True)
            earth_sun=concatenate_bundles(main,sun)
            empty=_empty_bundle(); src_hash=_sha_file(p); key=f"D{accepted:04d}"
            secret_map["datasets"][key]={
                "source_path":str(p),"source_sha256":src_hash,"roles":{},"rg_input_units":rg,"u_geom_input_units_per_time":u0,
                "T_final_input_time":T,"dt_input_time":dt,"n_steps":n_steps,"knot_core_over_rg":knot_core/rg,"bg_core_over_rg":bg_core/rg,
                "bundle_ring_radius_rg":ring,"phase":phase,"orientation_count":orientation_count,
                "bundle_meta":{"main":main[3],"sun":sun[3]},
            }
            z=np.zeros(3)
            c_base=new_case(key,"base",P,O,empty,dt,knot_core,bg_core,z,src_hash,rg)
            c_dup=new_case(key,"duplicate",P,O,empty,dt,knot_core,bg_core,z,src_hash,rg)
            c_main=new_case(key,"radial_main",P,O,main,dt,knot_core,bg_core,z,src_hash,rg)
            # Common boost: translate source-attached background and knot with identical U.
            U=boost_ratio*u0*_unit(rng)
            c_boost=new_case(key,"radial_common_boost",P,O,main,dt,knot_core,bg_core,U,src_hash,rg)
            # Rigid translation of complete initial knot+thread configuration.
            tr=translate_rg*rg*_unit(rng)
            main_t=(transform_bundle(main[0],translation=tr),main[1],main[2],main[3])
            c_trans=new_case(key,"radial_translated",P+tr,O,main_t,dt,knot_core,bg_core,z,src_hash,rg)
            # Rigid rotation of the complete initial configuration.
            RR=random_rotation(rng); Pr=(P-c)@RR.T+c
            main_r=(transform_bundle(main[0],rotation=RR,origin=c),main[1],main[2],main[3])
            c_rot=new_case(key,"radial_rotated",Pr,O,main_r,dt,knot_core,bg_core,z,src_hash,rg)
            c_near=new_case(key,"return_near",P,O,near,dt,knot_core,bg_core,z,src_hash,rg)
            c_mid=new_case(key,"return_mid",P,O,mid,dt,knot_core,bg_core,z,src_hash,rg)
            c_parallel=new_case(key,"parallel_bundle",P,O,parallel,dt,knot_core,bg_core,z,src_hash,rg)
            c_far_source=new_case(key,"far_source_radial",P,O,far_source,dt,knot_core,bg_core,z,src_hash,rg)
            orient_ids=[c_main]
            for oi,b in enumerate(orient_bundles[1:],start=1):
                orient_ids.append(new_case(key,f"orientation_{oi:02d}",P,O,b,dt,knot_core,bg_core,z,src_hash,rg))
            c_sun=new_case(key,"sun_only",P,O,sun,dt,knot_core,bg_core,z,src_hash,rg)
            c_es=new_case(key,"earth_sun",P,O,earth_sun,dt,knot_core,bg_core,z,src_hash,rg)
            new_group(key,"zero_recovery",[c_base,c_dup],"null")
            new_group(key,"common_boost_covariance",[c_main,c_boost],"null")
            new_group(key,"translation_covariance",[c_main,c_trans],"null")
            new_group(key,"rotation_covariance",[c_main,c_rot],"null")
            new_group(key,"return_near_far",[c_near,c_main])
            new_group(key,"return_mid_far",[c_mid,c_main])
            new_group(key,"near_source_vs_parallel",[c_main,c_parallel])
            new_group(key,"far_source_vs_parallel",[c_far_source,c_parallel])
            for oi,cid in enumerate(orient_ids): new_group(key,f"orientation_response_{oi:02d}",[c_base,cid])
            new_group(key,"parallel_response",[c_base,c_parallel])
            new_group(key,"sun_response",[c_base,c_sun])
            new_group(key,"earth_sun_response",[c_base,c_es])
            accepted+=1
        except Exception as e:
            skipped.append({"path":str(p),"reason":repr(e)})
    if accepted==0: raise RuntimeError("all dataset files were rejected; inspect parser/report")
    rng.shuffle(case_records); rng.shuffle(group_records)
    blind_manifest={"cases":case_records,"groups":group_records,"accepted_datasets":accepted,"skipped":skipped}
    _write_json(blind/"manifest.json",blind_manifest)
    salt=secrets.token_hex(32); secret_map["salt"]=salt
    commitment=_sha_bytes((salt+_canonical({k:v for k,v in secret_map.items() if k!="salt"})).encode())
    _write_json(secret_dir/"semantic_manifest.json",secret_map)
    _write_json(out/"blind_commitment.json",{"semantic_sha256":commitment,"blind_manifest_sha256":_sha_file(blind/"manifest.json"),"algorithm":"sha256(salt || canonical_semantic_manifest_without_salt)"})
    return blind_manifest


def run_blind(config,out_dir,force_python=False,skip_build=False):
    out=Path(out_dir); manifest_path=out/"blind/manifest.json"
    commitment=json.loads((out/"blind_commitment.json").read_text(encoding="utf-8"))
    if _sha_file(manifest_path)!=commitment["blind_manifest_sha256"]: raise RuntimeError("blind manifest hash mismatch")
    manifest=json.loads(manifest_path.read_text(encoding="utf-8")); result_dir=out/"blind/results"; result_dir.mkdir(parents=True,exist_ok=True)
    rows=[]
    for rec in manifest["cases"]:
        case_path=out/rec["file"]
        if _sha_file(case_path)!=rec["sha256"]: raise RuntimeError(f"blinded case hash mismatch: {rec['case_id']}")
        z=np.load(case_path,allow_pickle=False)
        P=np.asarray(z["points"],float); O=np.asarray(z["offsets"],np.int64)
        BV=np.asarray(z["bg_vertices"],float); BO=np.asarray(z["bg_offsets"],np.int64); BG=np.asarray(z["bg_gammas"],float)
        dt=float(z["dt"]); ns=int(z["n_steps"]); kc=float(z["knot_core"]); bc=float(z["bg_core"]); gamma=float(z["gamma"])
        U=np.asarray(z["frame_velocity"],float); rg=float(z["rg"])
        close=closure_diagnostics(BV,BO,BG) if len(BV) else {"component_count":0,"max_closure_vector_norm_over_length":0.0,"weighted_boundary_residual":0.0}
        clear=minimum_clearance(P,BV,BO)/rg if len(BV) else None
        final,traj=integrate_rk4(P,O,gamma,kc,BV,BO,BG,bc,U,dt,ns,force_python=force_python,skip_build=skip_build,record=True)
        rr={"case_id":rec["case_id"],"dataset_key":rec["dataset_key"],"backend":backend_name() if not force_python else "python",
            "final_file":f"blind/results/{rec['case_id']}_final.npy","rg0":rg,"metrics0":metrics(P,O),"metrics_final":metrics(final,O),
            "trajectory":traj,"n_steps":ns,"dt":dt,"final_time":ns*dt,"frame_speed":float(np.linalg.norm(U)),
            "background_component_count":int(max(0,len(BO)-1)),"background_closure":close,"initial_min_clearance_over_rg":clear}
        np.save(out/rr["final_file"],final); _write_json(result_dir/f"{rec['case_id']}.json",rr); rows.append(rr)
    _write_json(out/"blind_results.json",{"backend":backend_name() if not force_python else "python","cases":rows})
    return rows


def score_blind(config,out_dir):
    out=Path(out_dir); manifest=json.loads((out/"blind/manifest.json").read_text(encoding="utf-8"))
    recs={x["case_id"]:x for x in json.loads((out/"blind_results.json").read_text(encoding="utf-8"))["cases"]}
    scores=[]
    for g in manifest["groups"]:
        if len(g["case_ids"])!=2: continue
        a,b=g["case_ids"]; A=np.load(out/recs[a]["final_file"]); B=np.load(out/recs[b]["final_file"]); rg=max(float(recs[a]["rg0"]),1e-15)
        s=kabsch_rms(A,B)/rg
        status="PASS" if (g["expectation"]=="null" and s<=float(config["null_shape_rms_tol_rg"])) else ("FAIL" if g["expectation"]=="null" else "DIAGNOSTIC")
        scores.append({"group_id":g["group_id"],"dataset_key":g["dataset_key"],"expectation":g["expectation"],"shape_rms_over_rg":s,"blinded_status":status})
    _write_json(out/"blind_score.json",{"scores":scores,"thresholds":{"null_shape_rms_tol_rg":config["null_shape_rms_tol_rg"]}}); return scores


def unblind(config,out_dir):
    out=Path(out_dir); secret_map=json.loads((out/"secret/semantic_manifest.json").read_text(encoding="utf-8")); com=json.loads((out/"blind_commitment.json").read_text(encoding="utf-8"))
    if _sha_file(out/"blind/manifest.json")!=com["blind_manifest_sha256"]: raise RuntimeError("blind manifest hash mismatch during unblind")
    salt=secret_map["salt"]; calc=_sha_bytes((salt+_canonical({k:v for k,v in secret_map.items() if k!="salt"})).encode())
    if calc!=com["semantic_sha256"]: raise RuntimeError("blind semantic commitment mismatch")
    score_by_gid={x["group_id"]:x for x in json.loads((out/"blind_score.json").read_text(encoding="utf-8"))["scores"]}
    result_by_cid={x["case_id"]:x for x in json.loads((out/"blind_results.json").read_text(encoding="utf-8"))["cases"]}
    role_scores={}
    for gid,semantic in secret_map["groups"].items():
        d,r=semantic.split(":",1); role_scores.setdefault(d,{})[r]=score_by_gid[gid]
    datasets=[]
    null_roles=["zero_recovery","common_boost_covariance","translation_covariance","rotation_covariance"]
    closure_tol=float(config.get("closure_residual_tol",1e-12)); clear_tol=float(config.get("min_thread_clearance_rg",0.10))
    return_tol=float(config.get("return_flux_relative_tol",0.05)); asym_slack=float(config.get("source_limit_monotonic_slack",0.02))
    floor=float(config.get("response_ratio_floor_rg",1e-10))
    for key,rs in role_scores.items():
        semantic=secret_map["datasets"][key]; roles=semantic["roles"]
        null_ok=all(rs[r]["blinded_status"]=="PASS" for r in null_roles)
        # Every explicit thread case must be a closed cyclic filament current and start clear of the knot.
        thread_case_ids=[cid for role,cid in roles.items() if role not in ("base","duplicate")]
        closure_vals=[]; clearance_vals=[]
        for cid in thread_case_ids:
            rr=result_by_cid[cid]
            closure_vals.append(max(rr["background_closure"].get("max_closure_vector_norm_over_length",0.0),rr["background_closure"].get("weighted_boundary_residual",0.0)))
            if rr["initial_min_clearance_over_rg"] is not None: clearance_vals.append(rr["initial_min_clearance_over_rg"])
        closure_max=max(closure_vals) if closure_vals else 0.0; clearance_min=min(clearance_vals) if clearance_vals else float("inf")
        closure_ok=closure_max<=closure_tol; clearance_ok=clearance_min>=clear_tol
        radial=rs["orientation_response_00"]["shape_rms_over_rg"]
        ret_abs=rs["return_mid_far"]["shape_rms_over_rg"]; ret_rel=ret_abs/max(radial,floor); ret_ok=ret_rel<=return_tol
        near_parallel=rs["near_source_vs_parallel"]["shape_rms_over_rg"]; far_parallel=rs["far_source_vs_parallel"]["shape_rms_over_rg"]
        source_limit_ok=far_parallel<=near_parallel*(1.0+asym_slack)+floor
        orient=[]
        for i in range(int(semantic["orientation_count"])):
            orient.append(rs[f"orientation_response_{i:02d}"]["shape_rms_over_rg"])
        orient=np.asarray(orient,float); om=float(np.mean(orient)); os=float(np.std(orient)); anis=os/max(om,floor)
        structural="PASS" if (null_ok and closure_ok and clearance_ok) else "FAIL"
        thread_model="PASS" if (ret_ok and source_limit_ok) else "FAIL"
        overall="PASS" if structural=="PASS" and thread_model=="PASS" else "FAIL"
        datasets.append({
            "dataset_key":key,"source_path":semantic["source_path"],"structural_status":structural,"thread_model_status":thread_model,"overall_v020_status":overall,
            "gates":{
                "G0_zero_recovery":rs["zero_recovery"],
                "G1_common_boost_covariance":rs["common_boost_covariance"],
                "G2_translation_covariance":rs["translation_covariance"],
                "G3_rotation_covariance":rs["rotation_covariance"],
                "G4_closed_filament_topology":{"status":"PASS" if closure_ok else "FAIL","max_closure_residual":closure_max,"tol":closure_tol,"meaning":"discrete distributional analogue of div(omega)=0: every vorticity filament has zero boundary"},
                "G5_initial_thread_clearance":{"status":"PASS" if clearance_ok else "FAIL","min_clearance_over_rg":clearance_min,"tol":clear_tol},
                "G6_return_flux_independence":{"status":"PASS" if ret_ok else "FAIL","mid_vs_far_shape_rms_over_rg":ret_abs,"relative_to_main_response":ret_rel,"tol":return_tol,"near_vs_far_diagnostic":rs["return_near_far"]["shape_rms_over_rg"]},
                "G7_radial_to_parallel_source_distance_limit":{"status":"PASS" if source_limit_ok else "FAIL","near_source_vs_parallel":near_parallel,"far_source_vs_parallel":far_parallel,"monotonic_slack":asym_slack},
                "G8_radial_bundle_response":{"status":"MEASURED","shape_rms_over_rg":radial,"epistemic":"EXPLICIT_VORTEX_THREAD_MODEL_RESPONSE"},
                "G9_orientation_ensemble":{"status":"MEASURED","responses":orient.tolist(),"mean":om,"std":os,"anisotropy_cv":anis},
                "G10_parallel_bundle_response":{"status":"MEASURED","shape_rms_over_rg":rs["parallel_response"]["shape_rms_over_rg"]},
                "G11_sun_only_response":{"status":"MEASURED","shape_rms_over_rg":rs["sun_response"]["shape_rms_over_rg"]},
                "G12_earth_plus_sun_response":{"status":"MEASURED","shape_rms_over_rg":rs["earth_sun_response"]["shape_rms_over_rg"]},
            },
            "numerics":{"rg_input_units":semantic["rg_input_units"],"T_final":semantic["T_final_input_time"],"dt":semantic["dt_input_time"],"n_steps":semantic["n_steps"],"knot_core_over_rg":semantic["knot_core_over_rg"],"bundle_ring_radius_rg":semantic["bundle_ring_radius_rg"]}
        })
    structural_overall="PASS" if all(d["structural_status"]=="PASS" for d in datasets) else "FAIL"
    thread_overall="PASS" if all(d["thread_model_status"]=="PASS" for d in datasets) else "FAIL"
    overall="PASS" if structural_overall=="PASS" and thread_overall=="PASS" else "FAIL"
    report={"commitment_verified":True,"package_version":PACKAGE_VERSION,"overall_v020_status":overall,"overall_structural_status":structural_overall,"overall_thread_model_status":thread_overall,
            "interpretation":"Structural PASS certifies boost/rigid covariance and closed-filament validity for the implemented solver. Thread-model PASS additionally requires return-flux convergence and the radial-to-parallel source-distance limit. G8-G12 are measured predictions of this explicit stress-test bundle model, not a derivation of SST gravity or a calibrated Earth/Sun substrate.",
            "datasets":datasets,"provenance":{"python":sys.version,"platform":platform.platform(),"backend":json.loads((out/"blind_results.json").read_text())["backend"]},"sst_canonical_constants":SST_CANONICAL}
    _write_json(out/"unblinded_report.json",report)
    with (out/"summary.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["dataset_key","source_path","structural_status","thread_model_status","overall_v020_status","boost_null_rms_rg","return_rel","radial_response_mean_rg","orientation_anisotropy_cv","earth_sun_response_rg"])
        for d in datasets:
            g=d["gates"]; w.writerow([d["dataset_key"],d["source_path"],d["structural_status"],d["thread_model_status"],d["overall_v020_status"],g["G1_common_boost_covariance"]["shape_rms_over_rg"],g["G6_return_flux_independence"]["relative_to_main_response"],g["G9_orientation_ensemble"]["mean"],g["G9_orientation_ensemble"]["anisotropy_cv"],g["G12_earth_plus_sun_response"]["shape_rms_over_rg"]])
    return report


def run_full(config_path,dataset,out_dir,force_python=False,skip_build=False):
    config=json.loads(Path(config_path).read_text(encoding="utf-8")); prepare_blind(config,dataset,out_dir); run_blind(config,out_dir,force_python,skip_build); score_blind(config,out_dir); return unblind(config,out_dir)
