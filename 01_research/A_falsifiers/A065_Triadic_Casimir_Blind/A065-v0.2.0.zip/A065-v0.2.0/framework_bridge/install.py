"""Generate and execute a *genuine* SST Falsifier Framework v1.0.7 instance.

Never vendors, reimplements or modifies the frozen runtime. Calls its real
`tools/new_falsifier.py`, pins the generated instance, runs FREEZE and FULL.
The separate always-PDF renderer is invoked by triadic.entrypoint afterward.
"""
from __future__ import annotations
import json,os,shutil,subprocess,sys,traceback
from pathlib import Path


def _discover_framework(root):
    env=os.environ.get('SST_FALSIFIER_FRAMEWORK_ROOT','').strip()
    paths=[Path(env)] if env else []
    wb=os.environ.get('SST_WORKBENCH_ROOT',r'C:\workspace\projects\SST-Workbench')
    paths.append(Path(wb)/'06_templates'/'SST_Falsifier_Framework'/'SST_Falsifier_Framework_v1.0.7')
    for p in [root,*root.parents]:
        paths.append(p/'06_templates'/'SST_Falsifier_Framework'/'SST_Falsifier_Framework_v1.0.7')
    for p in paths:
        if (p/'sst_falsifier'/'__init__.py').is_file() and (p/'tools'/'new_falsifier.py').is_file():
            frozen=p/'CANONICAL_FREEZE.json'
            try:
                status=json.loads(frozen.read_text(encoding='utf-8'))
                if status.get('version')=='1.0.7' and status.get('status')=='CANONICAL_FROZEN':
                    return p.resolve()
            except (OSError,ValueError):
                pass
    return None


def _write_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')


def _configure(root,instance):
    for folder in ('data','seals','private_reveal','triadic'):
        shutil.copytree(root/folder,instance/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copy2(root/'framework_bridge'/'pipeline.py',instance/'experiment'/'pipeline.py')
    # The official resolver defaults to a Workbench root; for this portable
    # instance, independently sealed source paths are instance-relative.
    launch=instance/'run_instance.py'
    s=launch.read_text(encoding='utf-8')
    s=s.replace('ROOT = Path(__file__).resolve().parent','ROOT = Path(__file__).resolve().parent\nimport os\nos.environ["SST_WORKBENCH_ROOT"] = str(ROOT)')
    launch.write_text(s,encoding='utf-8')
    toml=instance/'falsifier.toml'
    s=toml.read_text(encoding='utf-8').replace('pdf_required = false','pdf_required = false')
    # Framework's native LaTeX report is optional if TeX is absent; the
    # companion report writer is ALWAYS required and checked by entrypoint.
    toml.write_text(s,encoding='utf-8')
    symbols=[{'symbol':'u','meaning':'Material velocity','si_unit':'m/s','dimensions':'L/T'},
             {'symbol':'omega','meaning':'Material vorticity','si_unit':'1/s','dimensions':'1/T'},
             {'symbol':'p','meaning':'Euler pressure','si_unit':'Pa','dimensions':'M/(L T^2)'}]
    eqs=[{'id':'E1','purpose':'Incompressible Euler kinematics','latex':r'\\nabla\\cdot\\mathbf u=0,\\quad\\boldsymbol\\omega=\\nabla\\times\\mathbf u','inputs':['u'],'outputs':['omega'],'dimensional_check':'divergence and vorticity both inverse seconds'},
         {'id':'E2','purpose':'Pressure Poisson source','latex':r'\\nabla^2p=\\rho_M(\\frac12|\\omega|^2-||S||_F^2)','inputs':['u','omega','p'],'outputs':['p'],'dimensional_check':'kg/(m^3 s^2) on each side'},
         {'id':'E3','purpose':'Regularized geometric velocity diagnostic','latex':r'\\mathbf u(\\mathbf x)=\\frac{1}{4\\pi}\\sum_j\\frac{\\Delta\\mathbf X_j\\times(\\mathbf x-\\mathbf X_{j+1/2})}{(|\\mathbf x-\\mathbf X_{j+1/2}|^2+\\varepsilon^2)^{3/2}}','inputs':['centerline'],'outputs':['u'],'dimensional_check':'dimensionless Gamma=1 geometry diagnostic'}]
    # LaTeX inputs must contain actual single-backslash command sequences.
    for e in eqs:e['latex']=e['latex'].replace('\\\\','\\')
    science={'schema':'SST-SCIENCE-CONTRACT-2',
      'research_question':'Does a preregistered triadic clock/stress geometry pilot satisfy its analytic controls while independent physical coupling gates remain unresolved?',
      'objective':'Independently verify three dataset seals, analytic Euler/gauge/sheet controls and one sourced KnotPlot trefoil finite-core geometric response without importing target force.',
      'null_hypothesis':'No independently qualified source-specific physical two-surface response is established by the present geometry and toy models.',
      'alternative_hypothesis':'Independently qualified PKLSA Euler motion, boundary conditions and microscopic link coupling produce held-out physical predictions.',
      'assumptions':['The 300-node KnotPlot trefoil is real geometric source material, not a fluid-time solution.',
                     'Dimensionless circulation and regularization are diagnostic choices, not calibrated SST constants.',
                     'The scalar sheet reflection model is a toy control, not actual metal response.',
                     'No independent second provider is present in this release.'],
      'symbols':symbols,'equations':eqs,
      'observables':[{'id':'O1','definition':'Three independent source SHA256 seals','equation_refs':['E1'],'unit':'1'},
                     {'id':'O2','definition':'Geometry-convergence and Poisson diagnostic residuals','equation_refs':['E2','E3'],'unit':'1'}],
      'steps':[{'id':'S1','operation':'Verify all three source seals before any scientific result is evaluated','formula_refs':['E1'],'gate':'G1'},
               {'id':'S2','operation':'Evaluate analytic Euler controls and preregistered trefoil geometry resolution scan','formula_refs':['E2','E3'],'gate':'G2'},
               {'id':'S3','operation':'Withhold physical Casimir claims without independent providers, wall dynamics, and atom-link normalization','formula_refs':['E3'],'gate':'G3'}],
      'falsification_criteria':[{'id':'F1','criterion':'Any source seal mismatch invalidates the run','conclusion_if_met':'INVALID'},
                                {'id':'F2','criterion':'Any preregistered analytic benchmark fails its tolerance','conclusion_if_met':'FAIL'},
                                {'id':'F3','criterion':'A physical claim cannot be substantiated without two independent dynamic upstream providers','conclusion_if_met':'UNRESOLVED'}],
      'edge_cases':['Irrotational, nonuniform-clock synthetic flow','decoupled zero-force sheet','missing second provider','unchanged physical results under pure gauge relabeling'],
      'predictions':['Precommitted reference identities and finite geometric velocity fields, no target Casimir amplitude.']}
    _write_json(instance/'science_contract.json',science)
    source={'schema':'SST-SOURCE-CONTRACT-2','independent_unit':'Upstream geometry production family, never numerical subsample',
            'sources':[{'source_id':a,'catalog_id':cat,'version':'v0.2.0','relative_path':path,'role':role,
                        'independence_family':fam,'provenance_family':fam,'evidence_class':ec,'override_path':None}
                       for (a,cat,path,role,fam,ec) in [
                        ('D01','A046','data/D01_EULER/cases.json','analytic_control','synthetic-euler','synthetic_control'),
                        ('PKLSA','E010','data/D01_EULER/pklsa/trefoil_KnotPlot_relaxed_N300.txt','geometry_diagnostic','knotplot-relaxed-3_1','simulation'),
                        ('D02','CANON','data/D02_CLOCK_LINK/single_surface.json','toy_control','synthetic-link','synthetic_control'),
                        ('D03','CANON','data/D03_TWO_SURFACE/conditions.json','heldout_control','synthetic-sheet','synthetic_control')]],
            'parser_contract':'PKLSA 3 numeric float coordinates per row; closed periodic centerline, raw hash verified',
            'translator_contract':'Regularized dimensionless segment Biot-Savart, no physical wall or atom-link parameter inference',
            'allow_no_external_sources':False,
            'replication_policy':{'require_explicit_evidence_class':True,'min_independent_groups':2,'synthetic_controls_may_close_cross_source':False}}
    _write_json(instance/'source_contract.json',source)
    # The canonical framework's autogenerated TeX table uses verbatim gate
    # questions. Older gate-plan labels contain Unicode arrows not recognized
    # by pdfLaTeX (e.g. CPU<->GPU). Sanitize labels *before* FREEZE in the new
    # instance; never modify the canonical framework's frozen template.
    gatepath=instance/'gate_plan.json'
    plan=json.loads(gatepath.read_text(encoding='utf-8'))
    for gate in plan['gates']:
        question=gate['question']
        for before,after in [('↔',' to '),('→',' to '),('≤',' <= '),('≥',' >= '),('–','-'),('—','-')]:
            question=question.replace(before,after)
        gate['question']=question
    _write_json(gatepath,plan)
    # Pre-freeze report: the 16 official section markers are all required.
    sections=[('IDENTIFICATION','Instance identity','Unregistered research instance. No A-number claimed.'),
     ('QUESTION','Research question',science['research_question']),('HYPOTHESES','Null and alternative hypotheses',science['null_hypothesis']),
     ('ASSUMPTIONS','Explicit assumptions','Sourced geometry and toy scalar link physics are distinct.'),
     ('SYMBOLS','Definitions','u material velocity; omega=curl u; S symmetric strain.'),
     ('EQUATIONS','Analytical equations','The official AUTO_SCIENCE_CONTRACT fragment records frozen equations.'),
     ('ALGORITHM','Scientific algorithm','Verify three seals; compute controls; evaluate trefoil diagnostic.'),
     ('SOURCES','Dataset provenance','D01 D02 D03, plus one KnotPlot relaxed N300 trefoil in D01.'),
     ('GATES','Independent gates','Only source/analytic gates qualify; dynamic physical claims remain unresolved.'),
     ('NUMERICS','Numerical controls','Dimensionless finite-segment Biot-Savart and finite-difference derivatives.'),
     ('BACKENDS','Backend authority','Minimal Python reference. No strict C++ native certification.'),
     ('BLINDNESS','Blindness and integrity','All three dataset SHA256 seals checked; reveal comparator not used in blind kernel.'),
     ('STATISTICS','Statistics','Geometry subsamples are not independent upstream providers.'),
     ('RESULTS','Result status','Read dynamic AUTO_RESULTS fragment; no target-matched force.'),
     ('INTERPRETATION','Scientific interpretation','Physical Casimir force and gravitation remain unvalidated.'),
     ('REPRODUCIBILITY','Reproduction','Run native FREEZE and FULL via the installation bridge.')]
    raw=[r'\\documentclass[10pt,a4paper]{article}',r'\\usepackage[margin=18mm]{geometry}',r'\\usepackage{amsmath,amssymb,booktabs,longtable,hyperref}',r'\\title{Triadic Casimir --- PKLSA v0.2.0 Framework Report}',r'\\author{SST Workbench / Unregistered instance}',r'\\begin{document}',r'\\maketitle']
    for marker,title,content in sections:
        raw.append('%% SST-REPORT-SECTION:'+marker)
        raw.append(r'\\section{'+title+'}')
        raw.append(content.replace('_',r'\\_'))
        if marker=='EQUATIONS':raw.append(r'\\input{AUTO_SCIENCE_CONTRACT.tex}')
        if marker=='RESULTS':raw.append(r'\\input{AUTO_RESULTS.tex}')
    raw.append(r'\\end{document}')
    (instance/'report'/'FALSIFIER_REPORT.tex').write_text(('\n'.join(raw)+'\n').replace('\\\\','\\'),encoding='utf-8')
    # No-reveal guard: opening physical comparator after unresolved physical gate is blocked.
    policy=instance/'blind_policy.json';d=json.loads(policy.read_text(encoding='utf-8'))
    d['block_reveal_on_unresolved']=True
    d['reveal_requires_gate']='G3'
    d['reveal_requires_gate_status']=['PASS','FAIL']
    _write_json(policy,d)
    (instance/'private'/'blind_forbidden_terms.txt').write_text('REVEAL_ONLY_TARGET\n',encoding='utf-8')
    _write_json(instance/'private'/'reveal.json',{'schema':'SST-REVEAL-DATA-2','external_physical_target':'NOT_INCLUDED','note':'No physical amplitude or model-derived surface response'} )


def run_framework(root):
    root=Path(root).resolve();framework=_discover_framework(root)
    if framework is None:
        return {'state':'FRAMEWORK_NOT_FOUND','detail':'Set SST_FALSIFIER_FRAMEWORK_ROOT to frozen v1.0.7, or install under C:\\workspace\\projects\\SST-Workbench\\06_templates\\SST_Falsifier_Framework\\SST_Falsifier_Framework_v1.0.7.'}
    instance=root/'FRAMEWORK_INSTANCE'/'TCAS-v0.2.0'
    log=root/'reports'/'FRAMEWORK_RUN.log';log.parent.mkdir(parents=True,exist_ok=True)
    localpy=framework/'.venv'/'Scripts'/'python.exe'
    exe=str(localpy) if localpy.exists() else sys.executable
    details=[]
    try:
        if not instance.exists():
            instance.parent.mkdir(parents=True,exist_ok=True)
            c=[exe,str(framework/'tools'/'new_falsifier.py'),'TCAS','Triadic_Casimir',str(instance),'--profile','minimal','--version','v0.2.0']
            x=subprocess.run(c,capture_output=True,text=True,timeout=120)
            details.append({'stage':'OFFICIAL_INSTANCE_GENERATOR','returncode':x.returncode,'output':x.stdout[-3000:],'error':x.stderr[-3000:]})
            if x.returncode:raise RuntimeError('Official new_falsifier.py failed: '+x.stderr[-1000:])
            _configure(root,instance)
        env=os.environ.copy();env['SST_FALSIFIER_FRAMEWORK_ROOT']=str(framework)
        env['SST_WORKBENCH_ROOT']=str(instance)
        for mode in ('FREEZE','FULL','REVEAL_IF_ALLOWED'):
            cp=subprocess.run([exe,str(instance/'run_instance.py'),mode],cwd=str(instance),env=env,capture_output=True,text=True,timeout=600)
            details.append({'stage':mode,'returncode':cp.returncode,'output':cp.stdout[-3500:],'error':cp.stderr[-3500:]})
            if cp.returncode:raise RuntimeError(f'Official framework {mode} failed; inspect reports/FRAMEWORK_RUN.log')
        # Record the actual native reporter status separately from successful
        # protocol/gate execution. The portable top-level PDF is guaranteed
        # by triadic.report_pdf after this function returns.
        out=instance/'Triadic_Casimir_v0.2.0-outputs'
        render=out/'REPORT_RENDER.json'
        native_report=json.loads(render.read_text(encoding='utf-8')) if render.exists() else {'status':'MISSING'}
        return {'state':'OFFICIAL_FRAMEWORK_EXECUTED','detail':'Canonical framework code ran through real generator, protocol freeze, FULL and reveal-policy check. PHYSICAL_G3_UNRESOLVED.',
                'native_report':{'success':native_report.get('success',False),'status':native_report.get('status','UNKNOWN')},
                'framework_root':str(framework),'instance_path':str(instance),'stages':[d['stage'] for d in details]}
    except Exception as exc:
        return {'state':'OFFICIAL_FRAMEWORK_FAILED','detail':str(exc),'framework_root':str(framework),'instance_path':str(instance)}
    finally:
        log.write_text(json.dumps(details,indent=2)+'\n',encoding='utf-8')
