# Gate2 Ruban Familywise Coupled Falsifier v0.2.0

Scientific conclusion: **G2_UNRESOLVED_NO_CERTIFIED_EQUILIBRIUM**.

## What this run tested
- Families: ['T_2_3', 'T_3_2', 'T_2_5', 'T_2_7', 'T_3_4', 'T_3_5', 'T_3_7', 'T_4_3', 'T_4_5', 'T_5_2', 'T_5_3', 'T_5_4', 'T_2_9', 'T_2_11', 'T_2_13', 'T_2_15', 'T_3_8', 'T_3_10', 'T_4_7', 'T_4_9', 'T_5_6', 'T_5_7', 'T_6_7', 'T_7_2', 'T_3_3', 'T_3_6', 'T_3_9', 'T_6_15', 'T_6_21', 'T_6_9']
- B0: [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32]
- Lambda: [3.4, 4.0, 5.0, 6.0, 7.0]
- Paired reduced-filament scenarios: 4800
- G3 promoted resolutions: 2048
- G4 coupled Euler pilot runs: 0

## Gate statuses
- G1: PASS_ANALYTIC_GEOMETRY_SCREEN_ONLY
- G2: PASS_REDUCED_SCREEN_EXECUTED_RESOLUTION_LIMITED
- G3: RANKING_PROVISIONAL_NUMERICAL_CONVERGENCE_UNRESOLVED
- G4: NOT_RUN_USER_DISABLED

## Physical interpretation
This pipeline screens analytic torus seed families. It neither solves a fully deformable stationary Euler boundary-value problem nor proves nonlinear stability. The 3D Euler pilot is a finite periodic Gaussian-mollified vortex field with back-reaction, not a continuum equilibrium certificate.
Averaging or long survival under a reduced filament model is not a vanishing Euler residual.
Frozen-parameter convergence of the full-component Euler residual and topology-preserving material simulation are required before G2 PASS.

## Selected seeds
- T_2_5 B0=0.32000, Lambda=7.00; N=[2048]; score=0.453826
- T_2_3 B0=0.32000, Lambda=7.00; N=[2048]; score=0.465216
- T_2_7 B0=0.32000, Lambda=7.00; N=[2048]; score=0.477476
- T_2_9 B0=0.30000, Lambda=7.00; N=[2048]; score=0.498792
- T_2_11 B0=0.30000, Lambda=7.00; N=[2048]; score=0.512994
- T_2_13 B0=0.30000, Lambda=3.40; N=[2048]; score=0.522483
- T_2_15 B0=0.30000, Lambda=3.40; N=[2048]; score=0.528215
- T_3_9 B0=0.30000, Lambda=3.40; N=[2048]; score=0.5473
- T_3_6 B0=0.32000, Lambda=3.40; N=[2048]; score=0.566979
- T_3_3 B0=0.32000, Lambda=3.40; N=[2048]; score=0.626187
- T_3_10 B0=0.32000, Lambda=3.40; N=[2048]; score=0.633146
- T_3_8 B0=0.32000, Lambda=7.00; N=[2048]; score=0.640933
- T_3_7 B0=0.32000, Lambda=7.00; N=[2048]; score=0.646456
- T_6_21 B0=0.32000, Lambda=3.40; N=[2048]; score=0.658194
- T_3_5 B0=0.32000, Lambda=7.00; N=[2048]; score=0.662413
- T_3_4 B0=0.32000, Lambda=7.00; N=[2048]; score=0.67293
- T_6_15 B0=0.32000, Lambda=3.40; N=[2048]; score=0.693616
- T_3_2 B0=0.32000, Lambda=7.00; N=[2048]; score=0.695108
- T_4_9 B0=0.32000, Lambda=3.40; N=[2048]; score=0.714872
- T_4_7 B0=0.32000, Lambda=3.40; N=[2048]; score=0.727949
- T_6_9 B0=0.32000, Lambda=3.40; N=[2048]; score=0.738318
- T_4_5 B0=0.32000, Lambda=3.40; N=[2048]; score=0.742642
- T_4_3 B0=0.32000, Lambda=3.40; N=[2048]; score=0.756399
- T_5_7 B0=0.32000, Lambda=3.40; N=[2048]; score=0.770559
- T_5_6 B0=0.32000, Lambda=3.40; N=[2048]; score=0.77604
- T_5_4 B0=0.32000, Lambda=3.40; N=[2048]; score=0.786255
- T_5_3 B0=0.32000, Lambda=3.40; N=[2048]; score=0.790466
- T_5_2 B0=0.32000, Lambda=3.40; N=[2048]; score=0.793674
- T_6_7 B0=0.32000, Lambda=3.40; N=[2048]; score=0.796459
- T_7_2 B0=0.32000, Lambda=3.40; N=[2048]; score=0.825132

## Provenance
- E010 v0.3.6 generator SHA-256: 2c73d35fd58c9f4bcb4ddbb336021883d0bdff44051105750a68fa0fc6a0c609
- E010 v0.3.6 config SHA-256: c7b29996e665296a99c376be044c66eb0ebefe31ecd516a3e53e9b908679890d
KnotPlot labels for six links are metadata only; corresponding curves were analytically generated, not imported.
