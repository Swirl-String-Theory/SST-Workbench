# Blind verdict

**Verdict:** `MIXED_SURVIVING_MODEL_CLASSES`

The blind engine used public observational constraints only. It did not load the candidate identity or private constants.

## Constraint-window results

| model class | n | effective lower [GeV] | Carpet upper [GeV] | result |
|---|---:|---:|---:|---|
| n1_nonbirefringent | 1 | 1.220000e+20 | 1.220000e+21 | PASS |
| n1_birefringent | 1 | 3.600000e+34 | 1.220000e+21 | FAIL |
| n2_nonbirefringent | 2 | 2.380000e+12 | 2.030000e+13 | PASS |
| n2_birefringent | 2 | 2.380000e+12 | 2.030000e+13 | PASS |

The generic birefringent n=1 class is rejected by incompatible lower/upper intervals; non-birefringent n=1 and both quadratic bookkeeping classes retain non-empty windows under the published baseline bounds. UHE-photon non-detection is retained as a conditional detector-response gate rather than silently discarded.

Conventional expected count: `3.900e-96` versus frozen 5% observability threshold `0.05129329`.
