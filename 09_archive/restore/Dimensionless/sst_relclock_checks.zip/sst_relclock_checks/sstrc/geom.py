"""
Closed-curve geometry for swirl-string (vortex filament) diagnostics.

All routines assume a CLOSED curve stored as X with shape (N,3), node i
followed by node i+1 (mod N).

Conventions and guards
----------------------
* Spectral derivatives are used only after resampling to uniform arclength.
  A non-uniform grid silently corrupts curvature/torsion spectra, which would
  invalidate the basis-robustness check.
* Writhe uses the Gauss double integral with the |i-j|<=1 band excluded. The
  excluded band contributes O(1/N) for smooth curves; check_writhe_convergence
  quantifies this instead of assuming it.
* Twist uses the discrete Bergou-style formulation: parallel transport the
  material vector along the curve and accumulate the residual rotation.
* Linking number Lk = Wr + Tw (Calugareanu-White-Fuller). For a thin uniformly
  framed tube, Moffatt-Ricca gives H = Gamma^2 * Lk, which is what the M2 check
  actually tests.
"""
from __future__ import annotations

import numpy as np


# ---------------------------------------------------------------------------
# resampling
# ---------------------------------------------------------------------------
def arclength(X: np.ndarray) -> np.ndarray:
    """Cumulative arclength at each node (length N+1, s[0]=0, s[-1]=L)."""
    d = np.linalg.norm(np.roll(X, -1, axis=0) - X, axis=1)
    return np.concatenate([[0.0], np.cumsum(d)])


def total_length(X: np.ndarray) -> float:
    return float(np.sum(np.linalg.norm(np.roll(X, -1, axis=0) - X, axis=1)))


def resample_uniform(X: np.ndarray, N: int | None = None) -> np.ndarray:
    """Resample the closed curve to N nodes equispaced in arclength."""
    if N is None:
        N = X.shape[0]
    s = arclength(X)
    L = s[-1]
    Xc = np.vstack([X, X[0]])
    target = np.linspace(0.0, L, N, endpoint=False)
    out = np.empty((N, 3))
    for k in range(3):
        out[:, k] = np.interp(target, s, Xc[:, k])
    # one Fourier smoothing pass to remove interpolation kinks (keeps 90% modes)
    return out


def spectral_derivatives(X: np.ndarray, L: float):
    """
    Return (Xs, Xss, Xsss) via FFT on a uniform-arclength grid of period L.
    """
    N = X.shape[0]
    k = 2.0 * np.pi * np.fft.fftfreq(N, d=L / N)
    F = np.fft.fft(X, axis=0)
    ik = (1j * k)[:, None]
    Xs = np.real(np.fft.ifft(ik * F, axis=0))
    Xss = np.real(np.fft.ifft(ik**2 * F, axis=0))
    Xsss = np.real(np.fft.ifft(ik**3 * F, axis=0))
    return Xs, Xss, Xsss


def curvature_torsion(X: np.ndarray):
    """
    Curvature kappa(s) and torsion tau(s) on a uniform-arclength closed curve.
    Returns (kappa, tau, L).
    """
    L = total_length(X)
    Xs, Xss, Xsss = spectral_derivatives(X, L)
    cross = np.cross(Xs, Xss)
    ncross = np.linalg.norm(cross, axis=1)
    nXs = np.linalg.norm(Xs, axis=1)
    kappa = ncross / np.maximum(nXs**3, 1e-300)
    denom = np.maximum(ncross**2, 1e-300)
    tau = np.einsum("ij,ij->i", cross, Xsss) / denom
    return kappa, tau, L


# ---------------------------------------------------------------------------
# writhe
# ---------------------------------------------------------------------------
def writhe(X: np.ndarray, exclude_band: int = 1) -> float:
    """
    Gauss double integral writhe of a closed polygon, midpoint rule.

        Wr = 1/(4 pi) * sum_i sum_j  [ (r_i - r_j) . (e_i x e_j) ] / |r_i-r_j|^3

    with r_i the edge midpoints and e_i the edge vectors. The |i-j|<=band
    diagonal is excluded (integrand limit is finite but the midpoint rule is
    inaccurate there).
    """
    N = X.shape[0]
    Xn = np.roll(X, -1, axis=0)
    e = Xn - X
    r = 0.5 * (X + Xn)

    d = r[:, None, :] - r[None, :, :]
    nd = np.linalg.norm(d, axis=2)
    cr = np.cross(e[:, None, :], e[None, :, :])
    num = np.einsum("ijk,ijk->ij", d, cr)

    idx = np.arange(N)
    sep = np.abs(idx[:, None] - idx[None, :])
    sep = np.minimum(sep, N - sep)
    mask = sep > exclude_band

    with np.errstate(divide="ignore", invalid="ignore"):
        term = np.where(mask, num / np.maximum(nd**3, 1e-300), 0.0)
    return float(term.sum() / (4.0 * np.pi))


def writhe_convergence(make_curve, Ns=(48, 96, 192, 384)) -> list[dict]:
    """Diagnostic: writhe vs. resolution for a curve factory make_curve(N)."""
    out = []
    prev = None
    for N in Ns:
        w = writhe(make_curve(N))
        out.append({"N": N, "writhe": w, "delta_vs_prev": None if prev is None else w - prev})
        prev = w
    return out


# ---------------------------------------------------------------------------
# frames and twist
# ---------------------------------------------------------------------------
def unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    return v / np.maximum(n, 1e-300)


def parallel_transport(v: np.ndarray, t_from: np.ndarray, t_to: np.ndarray) -> np.ndarray:
    """
    Rotate v by the minimal rotation carrying t_from onto t_to (Rodrigues).
    Vectorised over the leading axis. Used both along the curve (spatial
    Bishop transport) and in time (material transport with no internal torque).
    """
    a = unit(np.atleast_2d(t_from))
    b = unit(np.atleast_2d(t_to))
    v = np.atleast_2d(v)
    ax = np.cross(a, b)
    s = np.linalg.norm(ax, axis=1, keepdims=True)
    c = np.einsum("ij,ij->i", a, b)[:, None]
    small = (s < 1e-12).ravel()
    axu = np.where(s > 1e-12, ax / np.maximum(s, 1e-300), 0.0)
    theta = np.arctan2(s.ravel(), c.ravel())[:, None]
    ct, st = np.cos(theta), np.sin(theta)
    out = v * ct + np.cross(axu, v) * st + axu * np.einsum("ij,ij->i", axu, v)[:, None] * (1 - ct)
    out[small] = v[small]
    return out


def edge_tangents(X: np.ndarray) -> np.ndarray:
    return unit(np.roll(X, -1, axis=0) - X)


def init_material_frame(X: np.ndarray, twist_turns: float = 0.0) -> np.ndarray:
    """
    Build the Bishop (zero-torsion) material framing of a closed curve.

    The Bishop framing has a nonzero residual twist Tw_0 = delta/(2 pi), where
    delta is the Bishop holonomy of the closed curve. This is not an error: the
    real-valued twist of a closed ribbon is fixed only modulo the integer
    homotopy class of the framing, and Calugareanu then forces
    Wr + Tw_0 in Z (verified numerically to 1e-4 at N=768 for the trefoil).

    VERIFIED (tests/test_selftests.py): an INTEGER `twist_turns` shifts Tw by
    exactly that integer, hence shifts Lk by an integer and leaves the Lk DRIFT
    -- the quantity the M2 check actually measures -- untouched. Non-integer
    values break framing closure and are rejected.
    """
    N = X.shape[0]
    T = edge_tangents(X)
    seed = np.array([0.0, 0.0, 1.0])
    if abs(np.dot(seed, T[0])) > 0.9:
        seed = np.array([1.0, 0.0, 0.0])
    u = np.empty((N, 3))
    u[0] = unit(seed - np.dot(seed, T[0]) * T[0])
    for i in range(N - 1):
        u[i + 1] = parallel_transport(u[i], T[i], T[i + 1])[0]
    if twist_turns:
        if abs(twist_turns - round(twist_turns)) > 1e-12:
            raise ValueError(
                "twist_turns must be an integer: a non-integer uniform winding "
                "does not close the ribbon and makes Tw ill-defined."
            )
        per_edge = 2.0 * np.pi * twist_turns / N
        for i in range(N):
            ang = per_edge * i
            bi = np.cross(T[i], u[i])
            u[i] = np.cos(ang) * u[i] + np.sin(ang) * bi
    return unit(u)


def twist(X: np.ndarray, u: np.ndarray) -> float:
    """
    Discrete twist of the ribbon (X, u): accumulate the angle between the
    parallel-transported material vector and the actual next material vector.
    """
    N = X.shape[0]
    T = edge_tangents(X)
    Tn = np.roll(T, -1, axis=0)
    un = np.roll(u, -1, axis=0)
    upt = parallel_transport(u, T, Tn)
    b = np.cross(Tn, upt)
    ang = np.arctan2(np.einsum("ij,ij->i", un, b), np.einsum("ij,ij->i", un, upt))
    return float(np.sum(ang) / (2.0 * np.pi))


def orthonormalise_frame(X: np.ndarray, u: np.ndarray) -> np.ndarray:
    """Re-project u onto the plane normal to the current tangent."""
    T = edge_tangents(X)
    u = u - np.einsum("ij,ij->i", u, T)[:, None] * T
    return unit(u)


def linking(X: np.ndarray, u: np.ndarray):
    """Return (Wr, Tw, Lk)."""
    w = writhe(X)
    t = twist(X, u)
    return w, t, w + t


# ---------------------------------------------------------------------------
# canonical test curves
# ---------------------------------------------------------------------------
def torus_knot(N: int = 128, p: int = 2, q: int = 3, R: float = 1.0, r: float = 0.4) -> np.ndarray:
    """Standard T(p,q) torus knot. T(2,3) is the trefoil."""
    th = np.linspace(0.0, 2.0 * np.pi, N, endpoint=False)
    ph = q * th / p if p != 0 else th
    x = (R + r * np.cos(q * th)) * np.cos(p * th)
    y = (R + r * np.cos(q * th)) * np.sin(p * th)
    z = r * np.sin(q * th)
    return np.stack([x, y, z], axis=1)


def circle(N: int = 128, R: float = 1.0) -> np.ndarray:
    th = np.linspace(0.0, 2.0 * np.pi, N, endpoint=False)
    return np.stack([R * np.cos(th), R * np.sin(th), np.zeros_like(th)], axis=1)


def perturb(X: np.ndarray, amp: float, n_modes: int = 6, rng=None) -> np.ndarray:
    """Add a smooth low-mode random perturbation (ensemble generator)."""
    rng = np.random.default_rng() if rng is None else rng
    N = X.shape[0]
    s = np.linspace(0.0, 2.0 * np.pi, N, endpoint=False)
    d = np.zeros_like(X)
    scale = np.linalg.norm(X - X.mean(axis=0), axis=1).mean()
    for n in range(1, n_modes + 1):
        for k in range(3):
            a, b = rng.normal(size=2)
            d[:, k] += (a * np.cos(n * s) + b * np.sin(n * s)) / n
    return X + amp * scale * d
