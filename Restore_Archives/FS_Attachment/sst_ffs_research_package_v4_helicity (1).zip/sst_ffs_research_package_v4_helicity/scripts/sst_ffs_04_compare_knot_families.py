#!/usr/bin/env python3
"""
sst_ffs_04_compare_knot_families.py

Aggregate SST FFS filament-projection and attachment-threshold outputs.

Inputs:
  - family_config.csv with knot,family,ideal_id,conway,role
  - results/02_ideal_<SAFE>/sst_ffs_02_summary.csv
  - results/03_threshold_<SAFE>/sst_ffs_03_attachment_scan.csv

Outputs:
  - family_comparison.csv
  - family_ranking_by_B_actual.csv
  - family_comparison_B_actual.png
  - family_comparison_ell_eff95.png

The actual barrier is computed from the measured spectrum:
    B_actual = <q^2>_power / q_crit^2 = <q^2>_power * r_c^2
where q_crit = 1/r_c by default.

This is separate from the top-hat B_ell scan in script 03.
"""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np


def safe_id(ideal_id: str) -> str:
    return ideal_id.replace(":", "_").replace("/", "_").replace("\\", "_")


def read_kv(path: Path) -> dict[str, str]:
    out = {}
    with path.open("r", newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            k = (row.get("quantity") or "").strip()
            v = (row.get("value") or "").strip()
            if k:
                out[k] = v
    return out


def fnum(v, default=float("nan")) -> float:
    try:
        return float(v)
    except Exception:
        return default


def read_family_config(path: Path):
    with path.open("r", newline="", encoding="utf-8", errors="replace") as f:
        return list(csv.DictReader(f))


def read_threshold_scan(path: Path):
    rows = []
    with path.open("r", newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows


def nearest_row_by_ell(rows, ell):
    if not rows:
        return None
    return min(rows, key=lambda r: abs(fnum(r.get("ell")) - ell))


def write_csv(path: Path, rows: list[dict]):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def save_bar_plot(path: Path, rows: list[dict], ykey: str, ylabel: str, title: str):
    import matplotlib.pyplot as plt

    labels = [r["knot"] for r in rows]
    vals = [fnum(r[ykey]) for r in rows]

    plt.figure(figsize=(max(8, len(labels) * 0.65), 4.8))
    x = np.arange(len(labels))
    plt.bar(x, vals)
    plt.xticks(x, labels, rotation=45, ha="right")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--family-config", type=Path, default=Path("data/family_config.csv"))
    p.add_argument("--results-root", type=Path, default=Path("results_families"))
    p.add_argument("--outdir", type=Path, default=Path("results_families/04_compare"))
    p.add_argument("--ells", type=float, nargs="+", default=[1,2,4,8,13,21,28,34,55,89])
    args = p.parse_args()

    config = read_family_config(args.family_config)
    args.outdir.mkdir(parents=True, exist_ok=True)

    out_rows = []
    missing = []

    for row in config:
        sid = safe_id(row["ideal_id"])
        s02 = args.results_root / f"02_ideal_{sid}" / "sst_ffs_02_summary.csv"
        s03 = args.results_root / f"03_threshold_{sid}" / "sst_ffs_03_attachment_scan.csv"

        if not s02.exists():
            missing.append(f"missing {s02}")
            continue
        summary = read_kv(s02)

        scan = []
        if s03.exists():
            scan = read_threshold_scan(s03)
        else:
            missing.append(f"missing {s03}")

        r_c = fnum(summary.get("r_c_m"))
        q2_power = fnum(summary.get("spectral_m2_power_m_inv2"))
        B_actual = q2_power * r_c * r_c if math.isfinite(q2_power) and math.isfinite(r_c) else float("nan")

        q0 = fnum(summary.get("q0_m_inv"))
        q95 = fnum(summary.get("q95_abs_m_inv"))
        ell_eff = fnum(summary.get("ell_eff_95"))

        out = {
            "knot": row["knot"],
            "family": row["family"],
            "ideal_id": row["ideal_id"],
            "conway": row["conway"],
            "role": row["role"],
            "length_m": summary.get("length_m", ""),
            "q0_m_inv": summary.get("q0_m_inv", ""),
            "q_peak_abs_m_inv": summary.get("q_peak_abs_m_inv", ""),
            "q95_abs_m_inv": summary.get("q95_abs_m_inv", ""),
            "ell_eff_95": summary.get("ell_eff_95", ""),
            "spectral_m2_power_m_inv2": summary.get("spectral_m2_power_m_inv2", ""),
            "B_actual_rc": f"{B_actual:.16e}" if math.isfinite(B_actual) else "",
            "mean_kappa_m_inv": summary.get("mean_kappa_m_inv", ""),
            "rms_kappa_m_inv": summary.get("rms_kappa_m_inv", ""),
            "mean_tau_m_inv": summary.get("mean_tau_m_inv", ""),
            "rms_tau_m_inv": summary.get("rms_tau_m_inv", ""),
        }

        for ell in args.ells:
            sr = nearest_row_by_ell(scan, ell)
            if sr is not None:
                key = str(int(ell)) if abs(ell - int(ell)) < 1e-9 else str(ell).replace(".", "p")
                out[f"F_ell_{key}"] = sr.get("spectral_power_fraction", "")
                out[f"B_tophat_ell_{key}"] = sr.get("barrier_qcrit", "")
                out[f"class_ell_{key}"] = sr.get("classification", "")
            else:
                key = str(int(ell)) if abs(ell - int(ell)) < 1e-9 else str(ell).replace(".", "p")
                out[f"F_ell_{key}"] = ""
                out[f"B_tophat_ell_{key}"] = ""
                out[f"class_ell_{key}"] = ""

        out_rows.append(out)

    # Preserve family order for comparison, plus ranked output.
    write_csv(args.outdir / "family_comparison.csv", out_rows)
    ranked = sorted(out_rows, key=lambda r: fnum(r.get("B_actual_rc")), reverse=True)
    write_csv(args.outdir / "family_ranking_by_B_actual.csv", ranked)

    if out_rows:
        save_bar_plot(args.outdir / "family_comparison_B_actual.png", out_rows, "B_actual_rc", "B_actual = <q^2> r_c^2", "Actual torsion/R-phase barrier")
        save_bar_plot(args.outdir / "family_comparison_ell_eff95.png", out_rows, "ell_eff_95", "ell_eff,95", "Effective 95% spectral support")

    if missing:
        (args.outdir / "missing.txt").write_text("\n".join(missing) + "\n", encoding="utf-8")

    print(f"rows: {len(out_rows)}")
    print(f"wrote: {args.outdir / 'family_comparison.csv'}")
    print(f"wrote: {args.outdir / 'family_ranking_by_B_actual.csv'}")
    if missing:
        print("missing:")
        for m in missing:
            print("  " + m)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
