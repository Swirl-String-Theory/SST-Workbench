@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "ROOT=%%~fI"
set "WB=%~1"
if "%WB%"=="" if not "%SST_WORKBENCH_ROOT%"=="" set "WB=%SST_WORKBENCH_ROOT%"
if "%WB%"=="" set "WB=C:\workspace\projects\SST-Workbench"
set "FW=%WB%\06_templates\SST_Falsifier_Framework\SST_Falsifier_Framework_v1.0.4"
set "VENV=%WB%\.venvs\A054-v0.4.0-r3"
set "PY=%VENV%\Scripts\python.exe"

if not exist "%FW%\PACKAGE_MANIFEST.json" (
  echo [ERROR] Framework v1.0.4 not found: %FW%
  exit /b 2
)
if not exist "%FW%\profiles\multilibrary_gpu.toml" (
  echo [ERROR] Canonical framework profile missing: %FW%\profiles\multilibrary_gpu.toml
  exit /b 3
)

rem Migration cleanup: a local venv is not scientific source and must not be scanned/packed as blind content.
if exist "%ROOT%\.venv" rmdir /s /q "%ROOT%\.venv"
if not exist "%WB%\.venvs" mkdir "%WB%\.venvs"
if not exist "%PY%" (
  py -3 -m venv "%VENV%"
  if errorlevel 1 exit /b 10
)

"%PY%" -m pip install -U pip setuptools wheel pybind11 numpy pytest
if errorlevel 1 exit /b 11

del /q "%ROOT%\experiment\_native*.pyd" >nul 2>nul
del /q "%ROOT%\experiment\_native*.so" >nul 2>nul
if exist "%ROOT%\build" rmdir /s /q "%ROOT%\build"

"%PY%" -m pip install --no-build-isolation -e "%FW%"
if errorlevel 1 exit /b 12
"%PY%" -m pip install --no-build-isolation -e "%ROOT%"
if errorlevel 1 exit /b 13

set "SST_FALSIFIER_FRAMEWORK_ROOT=%FW%"
"%PY%" "%ROOT%\run_instance.py" SELFTEST
if errorlevel 1 exit /b 14
exit /b 0
