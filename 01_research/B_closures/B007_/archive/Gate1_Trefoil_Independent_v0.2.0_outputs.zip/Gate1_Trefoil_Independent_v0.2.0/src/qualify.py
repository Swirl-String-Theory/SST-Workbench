#!/usr/bin/env python3
"""Numerical G1 qualification using independent cross-section, Gauss, and 3D field tests.

Analytic solenoidality is established by the closed 2-form construction. Sampling
alone is NOT discrete divergence-free: optional Fourier Hodge projection provides
a consistent solenoidal Eulerian discretization; the projection error is always
recorded, and the pre-projection divergence is separately reported.
"""
import argparse, hashlib, json, sys, time
from pathlib import Path
import numpy as np
from scipy import fft as sfft
from geometry_proof import certificate
import seed_core_v010 as core

def fft_metrics(w,dx,L0):
    n=w.shape[1]
    # Setting Nyquist derivative to zero preserves Hermitian symmetry on even meshes
    k=2*np.pi*sfft.fftfreq(n,dx)
    if n%2==0: k[n//2]=0
    wk=sfft.fftn(w,axes=(1,2,3),workers=2)
    kd=k[:,None,None]*wk[0]+k[None,:,None]*wk[1]+k[None,None,:]*wk[2]
    k2=k[:,None,None]**2+k[None,:,None]**2+k[None,None,:]**2
    k2=np.where(k2==0,1,k2)
    coeff=kd/k2
    projected=wk-np.stack((k[:,None,None]*coeff,k[None,:,None]*coeff,k[None,None,:]*coeff))
    # show measured numerical curl/Helmholtz residual separately from identity
    projected_div_hat=1j*(k[:,None,None]*projected[0]+k[None,:,None]*projected[1]+k[None,None,:]*projected[2])
    div=sfft.ifftn(1j*kd,workers=2).real
    divp=sfft.ifftn(projected_div_hat,workers=2).real
    correction=np.sqrt(np.sum(np.abs(wk-projected)**2)/np.sum(np.abs(wk)**2))
    # 4th order FD divergence independent of FFT derivative
    divfd=np.zeros_like(w[0])
    for axis in range(3):
        f=w[axis]
        divfd+=(np.roll(f,2,axis=axis)-8*np.roll(f,1,axis=axis)+8*np.roll(f,-1,axis=axis)-np.roll(f,-2,axis=axis))/(12*dx)
    m={
        'spectral_raw_divergence_rms':float(np.sqrt(np.mean(div**2))),
        'spectral_raw_Dstar_rms':float(np.sqrt(np.mean(div**2))*L0**3/core.GAMMA),
        'finite_difference_order4_raw_divergence_rms':float(np.sqrt(np.mean(divfd**2))),
        'finite_difference_order4_raw_Dstar_rms':float(np.sqrt(np.mean(divfd**2))*L0**3/core.GAMMA),
        'projection_relative_L2_correction':float(correction),
        'projected_spectral_divergence_rms':float(np.sqrt(np.mean(divp**2))),
        'max_raw_divergence':float(np.max(np.abs(div))),
        'projected_solenoidality_algebraic':True,
        'net_vorticity_integral_norm':float(np.linalg.norm(w.sum(axis=(1,2,3))*dx**3)),
    }
    return m,sfft.ifftn(projected,axes=(1,2,3),workers=2).real

def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--q',type=int,default=0)
    cli.add_argument('--grids',type=int,nargs='+',default=[64,96,128])
    cli.add_argument('--helicity-grids',type=int,nargs='+',default=[64,96,128])
    cli.add_argument('--output',required=True)
    cli.add_argument('--save-seed-grid',type=int,default=0)
    args=cli.parse_args()
    t0=time.monotonic()
    L0=core.curve_length()
    g=certificate()
    fluxes=[core.cross_section_flux(float(p),L0,args.q,ngauss=96,ntheta=72) for p in np.linspace(0,2*np.pi,16,endpoint=False)]
    result={'test':'Gate 1 dimensionless seeded T(2,3) finite-core Euler initial field',
      'version':'v0.2.0','q':args.q,
      'assumptions':{'R0':core.R0,'torus_minor_ratio':core.A_TORUS,'Gamma0':core.GAMMA,'core_radius':core.A_CORE,
       'radial_bump_eta_c':core.ETA_C,'bump_b':core.BUMP_B,'cartesian_box':4.0,
       'frame':'periodic torus-surface framing','L0':L0,'helicity_analytic_candidate':-6+args.q,
       'kernel':'unregularized free-space 1/r^3 odd kernel principal-value diagonal'},
      'reach_proven_lower_bound':g['reach_lower_bound_proven'],
      'analytic_geometry':{'max_curvature_sampled':core.curvature_max()[0],
       'curve_length':L0,'antipodal_family':core.doublecritical_antipodal()},
      'cross_section_flux_samples':fluxes,'max_flux_relative_error':float(np.max(np.abs(np.array(fluxes)-1))),
      'gauss':core.gauss_invariants(1024),'pointwise_fd':core.pointwise_divergence_check(L0,args.q),
      'grids':[],'limitations':[
       'Spectral projection is a consistent numerical representation, not independent verification of analytic div=0.',
       'Free-space helicity uses a midpoint-kernel convolution and has discretization error.',
       'No Newton-Krylov Euler relative equilibrium or dynamical stability result is computed.',
       'No claim of globally exact reach; a rigorous lower bound sufficient for a0=0.20 is provided.'
      ]}
    for n in args.grids:
        print('q',args.q,'n',n, 'evaluating ...',flush=True)
        ts=time.monotonic()
        w,dx=core.make_cartesian_grid(n,L0,args.q,box=4.0,samples=4096)
        diag,wsol=fft_metrics(w,dx,L0)
        diag.update(n=n,dx=dx)
        if n in args.helicity_grids:
            diag['helicity_raw_free_space']=core.helicity_discrete_free_space(w,dx)
            diag['helicity_projected_free_space']=core.helicity_discrete_free_space(wsol,dx)
            h0=-6+args.q
            diag['helicity_reference']=h0
            diag['relative_helicity_error_raw']=abs(diag['helicity_raw_free_space']-h0)/abs(h0)
            diag['relative_helicity_error_projected']=abs(diag['helicity_projected_free_space']-h0)/abs(h0)
        if n==args.save_seed_grid:
            ofile=Path(args.output).parent/f'seed_q{args.q}_n{n}_solenoidal.npz'
            # explicit grid metadata; projected 3D field is not a flow equilibrium
            np.savez_compressed(ofile, omega=wsol.astype(np.float32), box=np.float64(4),
                dx=np.float64(dx), Gamma0=np.float64(1), alpha0=np.float64(.35),q=np.int32(args.q),
                a0=np.float64(.2),layout=np.array('omega_component_xyz_centered'))
            diag['seed_grid_file']=ofile.name
        diag['time_seconds']=time.monotonic()-ts
        result['grids'].append(diag)
        print('  proj relative',diag['projection_relative_L2_correction'],'pre-div-rms',diag['spectral_raw_divergence_rms'],
              'hel',diag.get('helicity_raw_free_space','skipped'),'s',diag['time_seconds'],flush=True)
        del w,wsol
    result['runtime_seconds']=time.monotonic()-t0
    result['source_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(core.__file__),Path(sys.modules['geometry_proof'].__file__)]}
    Path(args.output).parent.mkdir(parents=True,exist_ok=True)
    Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
    print('wrote',args.output,flush=True)

if __name__=='__main__': main()
