# SST Canon v0.8.30 evidence pack -- reviewed revision 4

This package upgrades the reviewed v0.8.28 evidence pack to the v0.8.30 Canon
snapshot while preserving the complete v0.8.28 numerical and adversarial record
as historical provenance.

The v0.8.29 and v0.8.30 changes are semantic and provenance corrections around
`rho_f`; they do not alter the frozen numerical anchors checked by the older
99/99 and 111/111 suites. Those older results are retained, but they are not
misrepresented as newly rerun v0.8.30 ledgers.

Start with:

1. `AUDIT_REPORT_v0_8_30_DELTA.md` -- consolidated v0.8.28 -> v0.8.30 verdict;
2. `EVIDENCE_DELTA_v0_8_28_to_v0_8_30.md` -- exact scope and epistemic change;
3. `PORT_STATUS_v0_8_30.md` -- current evidence/code status;
4. `PATCH_DISPOSITION.md` -- historical and current patch disposition.

## Current v0.8.30 validation status

- v0.8.30 delta ledger: **15/15**;
- v0.8.30 marker/reference checker: **25/25**;
- duplicate labels across main + Research Track: **0**;
- unresolved cross-file references: **0**;
- direct v0.8.28 -> v0.8.30 patch dry-run: **PASS**;
- direct patch output versus reviewed v0.8.30 snapshot: **byte-identical**;
- reviewed LaTeX build: **231 A4 pages**, succeeded;
- unresolved LaTeX references/citations: **0 / 0**;
- selected title, ontology, benchmark, and historical-provenance pages rendered
  and visually checked.

## Historical v0.8.28 verification retained

The predecessor pack remains part of this archive:

- primary upgraded suite: **99/99**;
- Claude adversarial suite with SSTcore 0.8.18: **111/111**;
- action--phase residual/counter-model harness: **PASS**;
- original v0.8.28 marker/reference checker: **27/27**.

These results verify the v0.8.28 algebraic/numerical baseline. They do not by
themselves verify the new v0.8.29/v0.8.30 semantic claims; those are covered by
the dedicated delta ledger and source checks.

## v0.8.30 delta commands

```bash
python3 scripts/sst_v0_8_30_delta_verification.py \
  canon_snapshot/SST_CANON-v0.8.30.tex \
  canon_snapshot/SST_CANON-v0.8.30-research-track.tex \
  --json results/v0_8_30_delta/delta_verification.json
```

```bash
python3 scripts/adversarial/check_canon_markers_v0_8_30.py \
  canon_snapshot/SST_CANON-v0.8.30.tex \
  canon_snapshot/SST_CANON-v0.8.30-research-track.tex \
  --json results/v0_8_30_delta/canon_marker_report_v0_8_30.json
```

Direct Canon patch:

```bash
cd patches/canon_upgrade_v0_8_28_to_v0_8_30
./apply_canon_upgrade.sh ../../provenance/canon_snapshot_v0_8_28
```

## Directory layout

- `canon_snapshot/` -- reviewed v0.8.30 main and Research Track sources;
- `provenance/canon_snapshot_v0_8_28/` -- untouched evidence-pack baseline;
- `patches/canon_upgrade_v0_8_28_to_v0_8_30/` -- direct unified diffs and apply scripts;
- `results/v0_8_30_delta/` -- new source/numerical delta ledgers;
- `validation/v0_8_30_delta/` -- compile logs, PDF, patch logs, and render checks;
- all other `results/`, `scripts/`, `external_reviews/`, and `validation/`
  directories retain the reviewed v0.8.28 evidence record.

## Reviewed-overlay note

The v0.8.30 snapshot carries forward the two accepted v0.8.28 review hotfixes:

1. corrected printed `omega_c` values in the Research Track;
2. explicit exact-closure/tautology wording in the benchmark table.

It also uses breakable `\path{...}` formatting for the archived benchmark path
to remove a visible right-margin overflow. This is an editorial layout overlay,
not a physics change.

## Scope guard

The v0.8.30 result is a semantic correction, not a new derivation:

```text
rho_f = rho_eff^(0) = 7.0e-7 kg m^-3
[CALIBRATED QUASI-STATIC EFFECTIVE RESPONSE]
```

is kept distinct from

```text
J_omega^VAM ~= 6.84e-7 kg m^-1
[HISTORICAL ORIGIN / CONDITIONAL ANSATZ]
```

The evidence pack does not derive `rho_sub`, `rho_f`, or the missing micro--macro
participation law.
