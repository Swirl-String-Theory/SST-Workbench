# A049 v0.2.0 method

The numerical domain is periodic and uses a Fourier pseudospectral incompressible Euler solver with 2/3 dealiasing. The nonlinear term is evaluated in rotational form \(\mathcal P(\mathbf u\times\boldsymbol\omega)\). The background is a deterministic seed-fixed, divergence-free narrow-band random velocity field normalized to a blind RMS speed of unity.

Small helical transverse probes are evolved with the tangent-linear Euler equation. For each retained Fourier mode, the complex coherent projection \(a(t)\) is measured. A candidate angular frequency is obtained from a linear fit to unwrapped \(\arg[a(t)/a(0)]\) over the leading interval that remains above the preregistered coherence floor. Exponential amplitude drift provides the damping/growth rate.

A probe is called a wave only when all preregistered coherence, phase-linearity, nonzero-speed and weak-damping gates pass. Universal transverse elasticity additionally requires all axes/helicities to pass, low direction/helicity splitting, and consistency of \(\omega/k\) between two wavenumbers.

A lower-resolution run is used only as a sign-control for the qualification conclusion, not as quantitative continuum convergence.
