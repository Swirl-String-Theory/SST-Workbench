from __future__ import annotations
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_sawcoil_common import (
    SawShapeParams, build_three_phase_sawshape, make_grid, biot_savart_points,
    three_phase_currents_from_pwm, magnetic_energy_density, write_csv, skin_depth_copper
)


def main() -> None:
    ap = argparse.ArgumentParser(description="Biot-Savart harmonic scan for 3-phase SawShape coil.")
    ap.add_argument("--radius", type=float, default=0.05)
    ap.add_argument("--height", type=float, default=0.0)
    ap.add_argument("--pairs", type=int, default=20)
    ap.add_argument("--duty", type=float, default=0.382)
    ap.add_argument("--current", type=float, default=10.0, help="PWM pulse current amplitude [A]")
    ap.add_argument("--f0", type=float, default=1.0e6)
    ap.add_argument("--harmonics", type=int, default=15)
    ap.add_argument("--bounds", type=float, default=0.10)
    ap.add_argument("--res", type=int, default=31)
    ap.add_argument("--softening", type=float, default=1e-4)
    ap.add_argument("--outdir", default="/mnt/data/sawcoil_out")
    args = ap.parse_args()

    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    params = SawShapeParams(n_pairs=args.pairs, radius_bottom=args.radius, radius_top=args.radius,
                            height=args.height, samples_per_segment=8)
    coils = build_three_phase_sawshape(params)
    Ih = three_phase_currents_from_pwm(args.duty, args.harmonics, args.current)
    points, (X, Y, Z) = make_grid(args.bounds, args.res, z=0.0)

    rows = []
    B_by_n = {}
    for n in range(1, args.harmonics + 1):
        Bn = np.zeros((points.shape[0], 3), dtype=np.complex128)
        for p, poly in enumerate(coils):
            Bn += biot_savart_points(points, poly, current=Ih[p, n], softening=args.softening)
        B_by_n[n] = Bn
        Bmag = np.sqrt(np.real(np.sum(Bn * np.conjugate(Bn), axis=1)))
        U = magnetic_energy_density(Bn)
        rows.append([n, 2*abs(Ih[0,n]), np.mean(Bmag), np.max(Bmag), np.mean(U), np.max(U)])

    csv_path = outdir / f"biot_scan_R{args.radius:.3f}_d{args.duty:.3f}_f{args.f0:.0f}.csv"
    write_csv(csv_path, ["n", "phase1_sinus_I_amp_A", "B_rms_mean_T", "B_rms_max_T", "uB_mean_J_m3", "uB_max_J_m3"], rows)

    # Plot summed real instantaneous field proxy at t=0 from selected harmonics.
    Bsum = np.zeros((points.shape[0], 3), dtype=np.float64)
    for n, Bn in B_by_n.items():
        Bsum += 2.0 * np.real(Bn)  # real signal positive harmonic contribution at t=0
    Bmag = np.linalg.norm(Bsum, axis=1).reshape(X.shape)
    plt.figure(figsize=(7.0, 5.8))
    plt.imshow(Bmag.T, origin="lower", extent=[-args.bounds, args.bounds, -args.bounds, args.bounds], aspect="equal")
    plt.xlabel("x [m]"); plt.ylabel("y [m]")
    plt.title(f"Mid-plane |B(t=0)|, R={args.radius:.3f} m, duty={args.duty:.3f}")
    plt.colorbar(label="T")
    png_path = outdir / f"B_midplane_R{args.radius:.3f}_d{args.duty:.3f}.png"
    plt.tight_layout(); plt.savefig(png_path, dpi=160); plt.close()

    print(f"Wrote {csv_path}")
    print(f"Wrote {png_path}")
    print(f"Copper skin depth at f0={args.f0:.3g} Hz: {skin_depth_copper(args.f0)*1e6:.2f} um")


if __name__ == "__main__":
    main()
