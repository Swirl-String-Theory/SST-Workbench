#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from sst_counterpulley.core import DEFAULT_DATA, run_grid, write_csv, write_json

def floats(s): return [float(x) for x in s.split(",") if x.strip()]
def ints(s): return [int(x) for x in s.split(",") if x.strip()]
def main() -> int:
    ap=argparse.ArgumentParser(description="Blind N/offset/core sweep. Contains no alpha target comparison.")
    ap.add_argument("--data",default=str(DEFAULT_DATA)); ap.add_argument("--id",default="3:1:1")
    ap.add_argument("--n-values",default="64,96,128")
    ap.add_argument("--offsets",default="0.05,0.1,0.2,0.3,0.4,0.5")
    ap.add_argument("--eps-values",default="0.025,0.05,0.1,0.2")
    ap.add_argument("--force-python",action="store_true"); ap.add_argument("--force-build",action="store_true")
    ap.add_argument("--out-json",default="audit_out/blind_grid.json"); ap.add_argument("--out-csv",default="audit_out/blind_grid.csv")
    a=ap.parse_args()
    rows=run_grid(n_values=ints(a.n_values),offsets=floats(a.offsets),eps_values=floats(a.eps_values),
                  data_path=a.data,knot_id=a.id,force_python=a.force_python,force_build=a.force_build)
    write_json(a.out_json,rows); write_csv(a.out_csv,rows)
    print(json.dumps({"rows":len(rows),"out_json":a.out_json,"out_csv":a.out_csv},indent=2))
    return 0
if __name__=="__main__": raise SystemExit(main())
