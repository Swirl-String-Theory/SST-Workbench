# Gate1 Trefoil Independent v0.2.0 — analytic certificate + numerical qualification

**Status:** `GATE1_PASS_FOR_DECLARED_ANALYTIC_AND_NUMERICAL_SCOPE` (not a rigorous error-controlled certification of the FFT quadrature, and not Euler dynamical stability). The v0.2 tolerances were chosen after inspecting exploratory v0.1 results; this is **not a blind holdout qualification**.

## Research scope

A single dimensionless embedded trefoil `T(2,3)` with torus parameter `alpha=0.35`, `R0=1`, circulation `Gamma0=1`, nominal tube radius `a0=0.20`, and two independently run internal-twist settings `q=0` and `q=1`. No SST Canon values, mass scales, core radii, speeds, or measured target constants enter the search or qualification.

Parameterization:

\[
X(\phi)=((1+0.35\cos3\phi)\cos2\phi,(1+0.35\cos3\phi)\sin2\phi,0.35\sin3\phi).
\]

The smooth, compactly supported vorticity is generated from the closed two-form

\[
\iota_{\omega}dV=d\Psi\wedge(d\varphi-2\pi q\,ds/L_0),\quad
\Psi=\frac{\Gamma_0}{2\pi}F(r^2/a_0^2),
\]

with `F'` a smooth normalized bump supported inside `eta<=0.95`. The primary mathematical field is **analytic in physical space**; the 3D grids are diagnostic samples.

## Key findings

* **Analytic tube radius certified:** `reach > 0.210606825 R0`, hence `a0=0.20 R0` is strictly admissible. This is a *lower bound* for the true reach, not the exact reach. The certificate uses an exact rational polynomial positivity check, a curvature cap `<1.6/R0` and explicit global chord lower bounds. See `docs/geometry_certificate.md` and `results/reach_certificate.json`.
* Periodic torus framing has numerical self-linking `Lk ≈ -6`; at `n_curve=1024`, `(Wr+Tw)-Lk≈1.514e-6`.
* All 16 cross-section flux samples agree with the input `Gamma0=1` to `~2.22e-16` for each tested `q`.
* Both real-space centered finite difference and Fourier sampled-grid divergence errors decrease as resolution increases; the former also exhibits approximately second-order decay as the pointwise finite difference step decreases.
* FFT Helmholtz projection of the 3D field has relative correction below `0.6%` on `128^3`, and its spectral divergence is close to floating-point roundoff. The **pre-projection** divergence is separately recorded and is **not near roundoff**.
* Independent free-space midpoint Biot–Savart helicity evaluation at `128^3` differs by `0.58%` from `H=-6` for `q=0` and `0.45%` from `H=-5` for `q=1`. The error decreases from `64^3` through `96^3` to `128^3`.
* Supplemental `160^3` field-only tests strengthen the divergence/projection convergence trend (`q=0` and `q=1`).
* `10/10` scope checks and `10/10` unit/regression tests passed on this executed package.

## Crucial interpretation limits

1. **This does not identify a stable trefoil:** G1 constructs and qualifies an admissible initial field. Euler relative equilibrium and spectral/nonlinear stability remain G2 and G3.
2. `a0/R0 = 0.20`, `alpha0 = 0.35`, `q in {0,1}`, `eta_c=0.95` are explicitly chosen *dimensionless test parameters*. Their values are not mathematically selected as energetically preferred or dynamically stable.
3. Projecting a sampled vorticity field onto the discrete divergence-free subspace introduces small spatially distributed tails. **The `seed_q*_n128_solenoidal.npz` files are projected diagnostic grids, not qualified compact-support topology-preserving Euler initial data.** Reconstruct the analytic field, or adopt a compatible support-preserving numerical curl/finite-volume formulation, before G2. The `omega` arrays in NPZ were serialized in float32; after reloading, divergence is not literally machine-zero without recomputation/projection.
4. The free-space helicity quadrature uses a midpoint approximation of a singular kernel and is **not interval-certified**. A `PASS` is a declared practical numerical tolerance, not an exact bound on the continuum helicity error.
5. The conservative reach proof is specialized to the stated `(2,3)` torus curve; it does not automatically apply to `Ideal.txt`, KnotPlot, a deformed core, or background configurations.
6. No numerical regularization appears in the analytic fluid model. Spectral projection here is a **discretization device**, not a claim that a shape is dynamically stable.

## Reproduce on Windows

From a Python environment with `numpy`, `scipy`, `sympy` and `pytest`:

```cmd
python -m pip install -r requirements.txt
run_all.cmd
```

`run_all.cmd` performs the analytic certificate, two 3D `64^3`, `96^3`, `128^3` campaigns, assessment and regression tests. On Linux/macOS use `./run_all.sh`. Tests and outputs are written under `./results/`. No input file is read from the SST Canon.

## File structure

- `src/geometry_proof.py` — exact rational reach **lower-bound proof**.
- `src/seed_core_v010.py` — reproducible baseline analytic field and quadrature implementation (vendored from v0.1.0; retained for provenance).
- `src/qualify.py` — G1 field tests: cross-section, Gauss invariants, Cartesian field, Fourier projection, independent midpoint Biot–Savart helicity.
- `src/assess.py` — hard-coded acceptance gates with scope/limitations.
- `tests/test_gate1.py` — regression tests including independent chord identity checks.
- `results/q0.json`, `results/q1.json`, `results/reach_certificate.json`, `results/gate1_qualification.json` — machine-readable results.
- `results/q*_n160.json` — supplemental field-only convergence runs.
- `results/seed_q*_n128_solenoidal.npz` — **diagnostic projection grids only**, with explicit metadata.
- `docs/geometry_certificate.md` — human-readable proof with assumptions.
- `docs/GATE_STATUS.md` — precise qualification decision and falsifier transition criteria.

## Citations

```latex
\begin{thebibliography}{9}
\bibitem{GonzalezMaddocks1999}
O. Gonzalez and J. H. Maddocks (1999),
``Global curvature, thickness, and the ideal shapes of knots,''
Proceedings of the National Academy of Sciences 96, 4769--4773.
doi:10.1073/pnas.96.9.4769.
\bibitem{MoffattRicca1992}
H. K. Moffatt and R. L. Ricca (1992),
``Helicity and the Calugareanu invariant,''
Proceedings of the Royal Society A 439, 411--429.
doi:10.1098/rspa.1992.0159.
\end{thebibliography}
```
