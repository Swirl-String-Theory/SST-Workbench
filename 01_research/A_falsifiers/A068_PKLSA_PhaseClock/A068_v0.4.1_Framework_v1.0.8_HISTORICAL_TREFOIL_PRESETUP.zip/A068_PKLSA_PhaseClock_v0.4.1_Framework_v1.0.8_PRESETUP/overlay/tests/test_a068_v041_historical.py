"""A/B historical source qualification and science guardrails."""
import json,hashlib
from pathlib import Path
import numpy as np
from experiment import historical, pipeline
R=Path(__file__).resolve().parents[1]
A=R/'data/historical'

def test_all_40_sources_sha_and_geometry():
    q=historical.audit(A)
    assert q['valid'] and len(q['files'])==40 and q['control_transforms_exact']
    assert len(q['geometry_families'])==2
    assert q['independent_physical_providers']==0
    assert q['provenance_version_name_mismatch']

def test_historical_originals_not_rewritten():
    m=json.loads((A/'manifest.json').read_text())
    assert m['version']=='0.1.0'
    assert m['seeds']['A_Fourier_2015_p32']['historical_page']==32
    assert m['seeds']['B_Torus_2015_p66']['historical_page']==66
    for family in historical.FAMILIES:
        rec=m['seeds'][family]['files']
        for tag in historical.VARIANTS:
            for n in historical.RESOLUTIONS:
                f=historical.source_path(A,family,tag,n)
                assert hashlib.sha256(f.read_bytes()).hexdigest()==rec[f.name]['sha256']

def test_geometry_distinction_not_physical_provider():
    m=json.loads((R/'source_contract.json').read_text())
    assert m['replication_policy']['min_independent_groups']==2
    assert m['replication_policy']['independent_physical_provider_count']==0
    assert 'HISTORICAL_2015_NOTEBOOK' in {s['provenance_family'] for s in m['sources']}

def test_historical_pilot_actual_euler():
    q=historical.pilot(A,'BASIC')
    assert q['all_model_screens_pass']
    assert len(q['test_matrix'])==2
    assert all(v['n_steps']==10 and v['relative_velocity_change']>0 for v in q['test_matrix'].values())
    assert q['physical_clock']=='UNRESOLVED'

def test_traversal_mirror_symmetry_exact():
    for family in historical.FAMILIES:
        p=np.loadtxt(historical.source_path(A,family,'orig_ccw',600))
        x=np.loadtxt(historical.source_path(A,family,'orig_cw',600))
        m=np.loadtxt(historical.source_path(A,family,'mirrorX_ccw',600))
        assert np.array_equal(x,p[::-1])
        assert np.array_equal(m,np.column_stack((-p[:,0],p[:,1],p[:,2])))


def test_tampered_historical_manifest_fails_closed(tmp_path):
    import shutil
    dst=tmp_path/'historical'
    shutil.copytree(A,dst)
    f=dst/'manifest.json'
    f.write_bytes(f.read_bytes()+b'\n')
    assert historical.audit(dst)['valid'] is False

def test_tampered_historical_xyz_fails_closed(tmp_path):
    import shutil
    dst=tmp_path/'historical'
    shutil.copytree(A,dst)
    f=historical.source_path(dst,historical.FAMILIES[0],'orig_ccw',600)
    f.write_bytes(f.read_bytes()+b'\n')
    assert historical.audit(dst)['valid'] is False
