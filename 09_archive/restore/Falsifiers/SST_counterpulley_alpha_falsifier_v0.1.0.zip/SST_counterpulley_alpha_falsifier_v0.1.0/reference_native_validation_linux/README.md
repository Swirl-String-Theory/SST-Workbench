# Native C++ validation (Linux construction environment)

`cpp/native.cpp` was compiled as a Python 3.13 C++17 pybind11 extension during package validation, then the full H0-H10 campaign was run through the native backend.

Key validation facts:

- active canonical backend: `cpp`;
- H1 native/Python parity: PASS;
- full H6 convergence: PASS;
- native and Python canonical `G_energy` agree;
- scientific verdict remains `FALSIFIED_OR_UNSUPPORTED_SIMPLE_COUNTERPULLEY_ENERGY_MAPPING`.

The compiled Linux `.so` is intentionally **not** distributed. On Windows, run `install_requirements.cmd`, `build_native.cmd`, and `native_preflight.cmd` to create the correct local `.pyd`.
