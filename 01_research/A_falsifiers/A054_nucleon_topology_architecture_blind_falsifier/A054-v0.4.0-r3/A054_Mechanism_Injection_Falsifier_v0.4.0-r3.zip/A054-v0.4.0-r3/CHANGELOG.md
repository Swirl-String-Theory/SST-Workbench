# Changelog

## v0.4.0-r3 — packaging/report maintenance
- No scientific changes.
- Corrects LaTeX bibliography escaping.
- Moves the venv outside the blinded instance tree to prevent false blind-scan hits from third-party packages.
- Removes legacy local `.venv` on migration.

## v0.4.0-r2 — MSVC native build / fail-closed execution hotfix
- `ssize_t` -> `py::ssize_t` in the pybind11 extension.
- Adds CORE and ELASTIC native parity coverage.
- Repairs CMD errorlevel propagation so failed build/setup cannot continue into FREEZE/run.
- No scientific model, source, threshold, gain-grid, blindness, or gate change.

## v0.4.0-r1 — execution/profile hotfix
- Replaces invalid framework profile `mechanism_injection` with canonical `multilibrary_gpu`.
- Normalizes `%~dp0` before editable install.
- Separates framework and instance editable installs.
- Propagates non-zero exit codes.

## v0.4.0
- New framework-v1.0.4 thin instance.
- Freezes the exact v0.2 FULL anonymous geometry cohort as discovery evidence.
- Adds opaque source-native v0.3 KnotPlot link confirmation cohort.
- Introduces BASE/CORE/ELASTIC/CORE+ELASTIC mechanism factorial with global no-refit gains.
- Inherits all v0.2 hard recovery thresholds unchanged.
