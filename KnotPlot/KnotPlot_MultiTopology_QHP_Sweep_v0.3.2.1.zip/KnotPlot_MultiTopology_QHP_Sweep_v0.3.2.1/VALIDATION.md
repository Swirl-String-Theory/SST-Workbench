# Validation — v0.3.2.1

- v0.3.1 bead-allocation selftest: PASS.
- v0.3.2 stage/timer selftest: PASS.
- 0.2.1 synthetic unlink: 2 parsed components, [300,300].
- 0.3.1 synthetic unlink: 3 parsed components, [300,300,300].
- Multi-component ASCII roundtrip: PASS.
- Stage-1 generate-only at 6 scripts / 30k: 90 scripts PASS.
- Nontrivial links still use strict KnotPlot component-count validation.
