LIST {
	{ < knot_0.1_trial_015k_rr_010k_coarse_rr_050k_eqfinal_rr_020k_polish.0.vect }
	{ < knot_0.1_trial_015k_rr_010k_coarse_rr_050k_eqfinal_rr_020k_polish.0.dlen.vect }
	{ < knot_0.1_trial_015k_rr_010k_coarse_rr_050k_eqfinal_rr_020k_polish.0.dVdt.vect }
}
