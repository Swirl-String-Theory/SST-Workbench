#!/usr/bin/env python3
r"""
routeB_RT_bem_v12_fourier_convention_audit.py
=============================================

BEMv12 Route-B audit: Fourier convention / provenance audit.

BEMv11 showed that the direct derivative-integral length from the printed
Brian Gilbert Fourier coefficients is stable but differs from the database L
column for the trefoil:

    L_Fourier != L_database.

BEMv12 audits whether this is caused by:
  1. Fourier convention choices,
  2. derivative parameterization conventions,
  3. global scale / D normalization,
  4. finite printed coefficient precision.

No observed alpha is used.

Core Fourier form
-----------------
Standard convention:

    x(t) = sum_I A_I cos(I t) + B_I sin(I t),       t in [0,2pi)

Derivative length:

    L = integral_0^{2pi} ||x'(t)|| dt.

Outputs
-------
  fourier_convention_audit.csv
  coefficient_rounding_sensitivity.csv
  scale_normalization_audit.csv
  alpha_leading_v12_budget.csv
  fourier_convention_report.md
  run_config_v12.json
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Basic helpers
# ---------------------------------------------------------------------------

def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: List[str] = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def parse_id_csv(s: str) -> List[str]:
    return [x.strip() for x in str(s).split(",") if x.strip()]


def parse_attrs_from_tag(tag: str) -> Dict[str, str]:
    return {m.group(1): m.group(2) for m in re.finditer(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"([^"]*)"', tag)}


def parse_vec3_attr(s: str) -> np.ndarray:
    vals = [float(x.strip()) for x in s.split(",")]
    if len(vals) != 3:
        raise ValueError(f"expected 3-vector, got {s!r}")
    return np.asarray(vals, dtype=float)


def ideal_id_to_name(bid: str) -> str:
    parts = str(bid).split(":")
    if len(parts) >= 3 and parts[2] == "1":
        return f"{parts[0]}_{parts[1]}"
    if len(parts) >= 2:
        return f"{parts[0]}_{parts[1]}"
    return str(bid).replace(":", "_")


def is_xml_ideal(path: Path) -> bool:
    head = path.read_text(encoding="utf-8", errors="replace")[:8192]
    return "<AB " in head and "<Coeff " in head


def parse_xml_ideal_blocks(path: Path) -> Dict[str, Dict[str, Any]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks: Dict[str, Dict[str, Any]] = {}

    for m in re.finditer(r"<AB\b([^>]*)>(.*?)</AB>", text, flags=re.S | re.I):
        attrs = parse_attrs_from_tag(m.group(1))
        bid = attrs.get("Id", f"AB_{len(blocks)+1}")
        body = m.group(2)
        ncomp = int(attrs.get("n", "1").strip() or "1")
        supported = (ncomp == 1 and "<Component" not in body)
        A: Dict[int, np.ndarray] = {}
        B: Dict[int, np.ndarray] = {}
        coeff_count = 0

        if supported:
            for cm in re.finditer(r"<Coeff\b([^>]*)/?>", body, flags=re.I):
                ca = parse_attrs_from_tag(cm.group(1))
                if not all(k in ca for k in ("I", "A", "B")):
                    continue
                idx = int(ca["I"])
                A[idx] = parse_vec3_attr(ca["A"])
                B[idx] = parse_vec3_attr(ca["B"])
                coeff_count += 1
            supported = bool(A and B)

        def maybe_float(k: str):
            try:
                return float(str(attrs.get(k, "")).strip())
            except Exception:
                return None

        blocks[bid] = {
            "id": bid,
            "name": ideal_id_to_name(bid),
            "conway": attrs.get("Conway", ""),
            "L_database": maybe_float("L"),
            "D_database": maybe_float("D"),
            "n_components": ncomp,
            "supported": supported,
            "A": A,
            "B": B,
            "max_I": max(set(A) | set(B)) if (A or B) else None,
            "coeff_count": coeff_count,
            "source": "xml_fourier",
        }
    return blocks


def generated_unknot_block() -> Dict[str, Any]:
    return {
        "id": "0:1:1",
        "name": "0_1",
        "conway": "0",
        "L_database": 2.0 * math.pi,
        "D_database": 1.0,
        "n_components": 1,
        "supported": True,
        "A": {1: np.asarray([1.0, 0.0, 0.0], dtype=float)},
        "B": {1: np.asarray([0.0, 1.0, 0.0], dtype=float)},
        "max_I": 1,
        "coeff_count": 1,
        "source": "generated_unit_circle_control",
    }


def load_blocks(path: Path, ids_csv: str, auto_add_unknot: bool, max_knots: int) -> Dict[str, Dict[str, Any]]:
    if not is_xml_ideal(path):
        raise ValueError("BEMv12 expects a Brian Gilbert XML/Fourier ideal.txt file")
    blocks_by_id = parse_xml_ideal_blocks(path)
    blocks_by_name = {b["name"]: b for b in blocks_by_id.values() if b.get("supported")}
    tokens = parse_id_csv(ids_csv)
    selected: Dict[str, Dict[str, Any]] = {}

    if len(tokens) == 1 and tokens[0].lower() == "all":
        if auto_add_unknot and "0:1:1" not in blocks_by_id:
            b = generated_unknot_block()
            selected[b["name"]] = b
        for b in blocks_by_id.values():
            if b.get("supported"):
                selected[b["name"]] = b
                if len(selected) >= max_knots:
                    break
        return selected

    for tok in tokens:
        b = blocks_by_id.get(tok) or blocks_by_name.get(tok)
        if b is None and auto_add_unknot and tok in {"0:1:1", "0_1"}:
            b = generated_unknot_block()
        if b is None:
            raise ValueError(f"requested knot {tok!r} not found")
        if not b.get("supported"):
            raise ValueError(f"requested knot {tok!r} unsupported/multi-component")
        selected[b["name"]] = b
    return selected


# ---------------------------------------------------------------------------
# Fourier evaluation variants
# ---------------------------------------------------------------------------

def coeff_arrays(block: Dict[str, Any]) -> Tuple[List[int], Dict[int, np.ndarray], Dict[int, np.ndarray]]:
    ids = sorted(set(block["A"]) | set(block["B"]))
    return ids, block["A"], block["B"]


def eval_curve_standard(block: Dict[str, Any], n: int, scale: float = 1.0) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False)
    P = np.zeros((len(t), 3), dtype=float)
    ids, A, B = coeff_arrays(block)
    for I in ids:
        P += np.cos(I*t)[:, None] * A.get(I, np.zeros(3))[None, :]
        P += np.sin(I*t)[:, None] * B.get(I, np.zeros(3))[None, :]
    return scale * P


def eval_derivative_standard(block: Dict[str, Any], n: int, scale: float = 1.0) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False)
    V = np.zeros((len(t), 3), dtype=float)
    ids, A, B = coeff_arrays(block)
    for I in ids:
        V += (-I * np.sin(I*t))[:, None] * A.get(I, np.zeros(3))[None, :]
        V += ( I * np.cos(I*t))[:, None] * B.get(I, np.zeros(3))[None, :]
    return scale * V


def eval_curve_variant(block: Dict[str, Any], n: int, variant: str, scale: float = 1.0) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False)
    P = np.zeros((len(t), 3), dtype=float)
    ids, A, B = coeff_arrays(block)

    for I in ids:
        Ai = A.get(I, np.zeros(3))
        Bi = B.get(I, np.zeros(3))
        if variant == "standard":
            P += np.cos(I*t)[:, None] * Ai[None, :] + np.sin(I*t)[:, None] * Bi[None, :]
        elif variant == "sin_cos_swapped":
            P += np.sin(I*t)[:, None] * Ai[None, :] + np.cos(I*t)[:, None] * Bi[None, :]
        elif variant == "minus_sin":
            P += np.cos(I*t)[:, None] * Ai[None, :] - np.sin(I*t)[:, None] * Bi[None, :]
        elif variant == "minus_cos":
            P += -np.cos(I*t)[:, None] * Ai[None, :] + np.sin(I*t)[:, None] * Bi[None, :]
        elif variant == "A_minus_B":
            P += np.cos(I*t)[:, None] * Ai[None, :] - np.sin(I*t)[:, None] * Bi[None, :]
        elif variant == "B_cos_A_sin":
            P += np.cos(I*t)[:, None] * Bi[None, :] + np.sin(I*t)[:, None] * Ai[None, :]
        else:
            raise ValueError(f"unknown variant {variant}")
    return scale * P


def length_derivative(block: Dict[str, Any], n: int, scale: float = 1.0) -> float:
    if block.get("source") == "generated_unit_circle_control":
        return 2.0 * math.pi * scale
    V = eval_derivative_standard(block, n, scale)
    return float((2.0 * math.pi / n) * np.sum(np.linalg.norm(V, axis=1)))


def length_polygon(P: np.ndarray) -> float:
    Q = np.vstack([P, P[0]])
    return float(np.sum(np.linalg.norm(np.diff(Q, axis=0), axis=1)))


def bbox_max_distance(P: np.ndarray) -> float:
    # Fast approximate pairwise diameter: exact for <= 6000 points? Instead use axis-aligned bbox diagonal and coordinate spans.
    spans = np.ptp(P, axis=0)
    return float(np.linalg.norm(spans))


def farthest_sample_distance(P: np.ndarray, max_points: int = 2000) -> float:
    # Deterministic subsampling exact pairwise among selected points.
    if len(P) > max_points:
        idx = np.linspace(0, len(P)-1, max_points).astype(int)
        Q = P[idx]
    else:
        Q = P
    dmax = 0.0
    block = 256
    for i in range(0, len(Q), block):
        D = np.linalg.norm(Q[i:i+block, None, :] - Q[None, :, :], axis=2)
        dmax = max(dmax, float(D.max()))
    return dmax


def leading_alpha_inv(L: float) -> float:
    return (8.0 * math.pi / 3.0) * L


# ---------------------------------------------------------------------------
# Rounding sensitivity
# ---------------------------------------------------------------------------

def jitter_block(block: Dict[str, Any], rng: np.random.Generator, eps: float) -> Dict[str, Any]:
    if block.get("source") == "generated_unit_circle_control":
        return block
    A2: Dict[int, np.ndarray] = {}
    B2: Dict[int, np.ndarray] = {}
    for I, v in block["A"].items():
        A2[I] = v + rng.uniform(-eps, eps, size=3)
    for I, v in block["B"].items():
        B2[I] = v + rng.uniform(-eps, eps, size=3)
    out = dict(block)
    out["A"] = A2
    out["B"] = B2
    out["source"] = block.get("source", "") + "_jittered"
    return out


def rounding_sensitivity(block: Dict[str, Any], n: int, trials: int, eps: float, seed: int) -> Dict[str, Any]:
    if trials <= 0:
        return {}
    if block.get("source") == "generated_unit_circle_control":
        L0 = 2.0 * math.pi
        return {
            "rounding_trials": trials,
            "rounding_eps": eps,
            "L_jitter_mean": L0,
            "L_jitter_std": 0.0,
            "L_jitter_min": L0,
            "L_jitter_max": L0,
            "L_jitter_span": 0.0,
            "status": "GENERATED_CONTROL_NO_ROUNDING",
        }
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(trials):
        jb = jitter_block(block, rng, eps)
        vals.append(length_derivative(jb, n))
    arr = np.asarray(vals, dtype=float)
    return {
        "rounding_trials": trials,
        "rounding_eps": eps,
        "L_jitter_mean": float(arr.mean()),
        "L_jitter_std": float(arr.std(ddof=1)) if len(arr) > 1 else 0.0,
        "L_jitter_min": float(arr.min()),
        "L_jitter_max": float(arr.max()),
        "L_jitter_span": float(arr.max() - arr.min()),
        "status": "PRINTED_COEFFICIENT_ROUNDING_MONTE_CARLO",
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ideal", default="ideal.txt")
    ap.add_argument("--outdir", default="outputs_routeB_BEM_v12_fourier")
    ap.add_argument("--ideal-xml-knot-ids", default="0:1:1,3:1:1,4:1:1")
    ap.add_argument("--target", default="3_1")
    ap.add_argument("--reference", default="0_1")
    ap.add_argument("--samples", type=int, default=32000)
    ap.add_argument("--variants", default="standard,sin_cos_swapped,minus_sin,minus_cos,B_cos_A_sin")
    ap.add_argument("--rounding-trials", type=int, default=80)
    ap.add_argument("--rounding-eps", type=float, default=5e-7)
    ap.add_argument("--rounding-samples", type=int, default=6000)
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--max-knots", type=int, default=50)
    ap.add_argument("--no-auto-add-unknot", action="store_true")
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    blocks = load_blocks(Path(args.ideal), args.ideal_xml_knot_ids, auto_add_unknot=(not args.no_auto_add_unknot), max_knots=args.max_knots)
    variants = parse_id_csv(args.variants)

    # 1. Convention audit.
    conv_rows: List[Dict[str, Any]] = []
    for name, block in blocks.items():
        L_db = block.get("L_database")
        for var in variants:
            if block.get("source") == "generated_unit_circle_control":
                L_poly = 2.0 * math.pi
                L_der = 2.0 * math.pi
            else:
                P = eval_curve_variant(block, args.samples, var)
                L_poly = length_polygon(P)
                L_der = length_derivative(block, args.samples) if var == "standard" else L_poly
            conv_rows.append({
                "knot": name,
                "id": block.get("id", name),
                "variant": var,
                "N_samples": args.samples,
                "L_variant": L_der,
                "L_polygon_variant": L_poly,
                "L_database": L_db if L_db is not None else "",
                "delta_variant_minus_database": (L_der - float(L_db)) if L_db is not None else "",
                "rel_variant_minus_database": ((L_der - float(L_db))/float(L_db)) if L_db is not None and abs(float(L_db)) > 0 else "",
                "alpha_inv_lead_variant": leading_alpha_inv(L_der),
                "status": "ALPHA_BLIND_FOURIER_CONVENTION_CHECK",
            })
    write_csv(outdir / "fourier_convention_audit.csv", conv_rows)

    # 2. Rounding sensitivity.
    round_rows: List[Dict[str, Any]] = []
    for name, block in blocks.items():
        L0 = length_derivative(block, args.rounding_samples)
        rs = rounding_sensitivity(block, args.rounding_samples, args.rounding_trials, args.rounding_eps, args.seed)
        L_db = block.get("L_database")
        row = {
            "knot": name,
            "id": block.get("id", name),
            "N_samples": args.rounding_samples,
            "L_nominal": L0,
            "L_database": L_db if L_db is not None else "",
            "delta_nominal_minus_database": (L0 - float(L_db)) if L_db is not None else "",
            "abs_delta_nominal_minus_database": abs(L0 - float(L_db)) if L_db is not None else "",
            **rs,
        }
        if rs:
            std = float(rs.get("L_jitter_std", float("nan")))
            delta = abs(float(row["delta_nominal_minus_database"])) if row["delta_nominal_minus_database"] != "" else float("nan")
            row["delta_over_rounding_std"] = delta/std if std and math.isfinite(std) and std > 0 else ""
            row["rounding_covers_database_delta_3sigma"] = bool(math.isfinite(std) and delta <= 3*std)
        round_rows.append(row)
    write_csv(outdir / "coefficient_rounding_sensitivity.csv", round_rows)

    # 3. Scale normalization audit.
    scale_rows: List[Dict[str, Any]] = []
    for name, block in blocks.items():
        L_db = block.get("L_database")
        L_raw = length_derivative(block, args.samples)
        P = eval_curve_standard(block, min(args.samples, 6000))
        far_diam = farthest_sample_distance(P)
        bbox_diag = bbox_max_distance(P)
        s_to_Ldb = float(L_db)/L_raw if L_db is not None and abs(L_raw) > 0 else float("nan")
        s_to_D1_farthest = 1.0/far_diam if far_diam > 0 else float("nan")
        s_to_D1_bbox = 1.0/bbox_diag if bbox_diag > 0 else float("nan")
        for mode, scale in [
            ("raw", 1.0),
            ("rescale_to_database_L", s_to_Ldb),
            ("rescale_farthest_sample_diameter_to_1", s_to_D1_farthest),
            ("rescale_bbox_diagonal_to_1", s_to_D1_bbox),
        ]:
            L_scaled = L_raw*scale if math.isfinite(scale) else float("nan")
            scale_rows.append({
                "knot": name,
                "id": block.get("id", name),
                "scale_mode": mode,
                "scale_factor": scale,
                "L_scaled": L_scaled,
                "L_raw": L_raw,
                "L_database": L_db if L_db is not None else "",
                "farthest_sample_distance_raw": far_diam,
                "bbox_diagonal_raw": bbox_diag,
                "alpha_inv_lead_scaled": leading_alpha_inv(L_scaled) if math.isfinite(L_scaled) else "",
                "delta_scaled_minus_database": (L_scaled - float(L_db)) if L_db is not None and math.isfinite(L_scaled) else "",
                "status": "ALPHA_BLIND_SCALE_CONVENTION_CHECK",
            })
    write_csv(outdir / "scale_normalization_audit.csv", scale_rows)

    # 4. Budget summary for target.
    target = args.target
    if target not in blocks:
        for name, b in blocks.items():
            if b.get("id") == args.target:
                target = name
                break
    if target not in blocks:
        raise ValueError(f"target {args.target!r} not found in selected blocks {list(blocks)}")

    tb = blocks[target]
    L_db = tb.get("L_database")
    L_raw = length_derivative(tb, args.samples)
    s_to_Ldb = float(L_db)/L_raw if L_db is not None and abs(L_raw) > 0 else float("nan")
    alpha_raw = leading_alpha_inv(L_raw)
    alpha_Ldb = leading_alpha_inv(float(L_db)) if L_db is not None else float("nan")
    delta_alpha = alpha_raw - alpha_Ldb if math.isfinite(alpha_Ldb) else float("nan")

    budget = {
        "target": target,
        "target_id": tb.get("id", target),
        "N_samples": args.samples,
        "L_database": L_db if L_db is not None else "",
        "L_fourier_raw": L_raw,
        "scale_factor_to_database_L": s_to_Ldb,
        "delta_L_raw_minus_database": (L_raw - float(L_db)) if L_db is not None else "",
        "rel_L_raw_minus_database": ((L_raw - float(L_db))/float(L_db)) if L_db is not None and abs(float(L_db)) > 0 else "",
        "alpha_inv_lead_fourier_raw": alpha_raw,
        "alpha_inv_lead_database_L": alpha_Ldb,
        "delta_alpha_raw_minus_database": delta_alpha if math.isfinite(delta_alpha) else "",
        "status": "ALPHA_BLIND_V12_LENGTH_CONVENTION_BUDGET_NO_CODATA",
    }
    write_csv(outdir / "alpha_leading_v12_budget.csv", [budget])

    # Report.
    target_round = next((r for r in round_rows if r["knot"] == target), {})
    lines = []
    lines.append("# BEMv12 Fourier-convention report")
    lines.append("")
    lines.append("This report is alpha-blind: it does not contain or compare with observed fine structure.")
    lines.append("")
    lines.append("BEMv12 audits why the printed Fourier coefficients and the database `L` column do not give exactly the same arclength.")
    lines.append("")
    lines.append("## Target budget")
    lines.append("")
    for k, v in budget.items():
        lines.append(f"- `{k}`: `{v}`")
    lines.append("")
    lines.append("## Rounding sensitivity")
    lines.append("")
    for k in [
        "L_nominal", "L_database", "delta_nominal_minus_database",
        "L_jitter_std", "L_jitter_span", "delta_over_rounding_std",
        "rounding_covers_database_delta_3sigma"
    ]:
        if k in target_round:
            lines.append(f"- `{k}`: `{target_round[k]}`")
    lines.append("")
    lines.append("## Interpretation")
    lines.append("")
    lines.append("If the convention variants leave the length essentially unchanged while the rounding sensitivity is comparable to the database mismatch, the likely source is printed-coefficient precision or database/Fourier approximation provenance, not numerical integration.")
    lines.append("")
    lines.append("## Output files")
    lines.append("")
    lines.append("- `fourier_convention_audit.csv`")
    lines.append("- `coefficient_rounding_sensitivity.csv`")
    lines.append("- `scale_normalization_audit.csv`")
    lines.append("- `alpha_leading_v12_budget.csv`")
    (outdir / "fourier_convention_report.md").write_text("\n".join(lines), encoding="utf-8")

    config = {"args": vars(args)}
    (outdir / "run_config_v12.json").write_text(json.dumps(config, indent=2, sort_keys=True), encoding="utf-8")

    print("="*78)
    print("Route B BEMv12 Fourier-convention audit complete")
    print("="*78)
    print(f"outdir: {outdir}")
    print(f"target: {target}")
    print(f"L_database: {L_db}")
    print(f"L_fourier_raw: {L_raw}")
    print(f"scale_factor_to_database_L: {s_to_Ldb}")
    print(f"alpha_inv_lead_fourier_raw: {alpha_raw}")
    print(f"alpha_inv_lead_database_L: {alpha_Ldb}")
    print("wrote: fourier_convention_audit.csv, coefficient_rounding_sensitivity.csv, scale_normalization_audit.csv, alpha_leading_v12_budget.csv, fourier_convention_report.md")


if __name__ == "__main__":
    main()
