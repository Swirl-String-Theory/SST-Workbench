# A049 v0.2.0 blind report

Backend: **python**
Pipeline: **PIPELINE_QUALIFIED**
Research question: **NOT_SUPPORTED_AT_V0.2.0_DYNAMIC_RESOLUTION**
Dynamic wave status: **NO_UNIVERSAL_QUALIFIED_TRANSVERSE_POLE**
Master-Factor Wave Closure: **NOT_CLOSED**

## Static Born carry-forward

- A2 = 1.333333345970e-01
- candidate c_T/u_rms = 3.651483734005e-01

## Dynamic Euler persistence test

- grid N = 15
- initial isotropy Frobenius residual = 7.489742e-02
- base-energy max relative drift = 1.141737e-07
- max divergence relative residual = 3.538960e-17
- RK4 one-step/two-half relative L2 = 3.551447e-08
- qualified probes = 0/8
- primary median c/u_rms (diagnostic only) = 1.175048e-01
- secondary median c/u_rms (diagnostic only) = 9.034577e-02
- direction spread (diagnostic) = 1.841495e+00
- helicity split (diagnostic) = 1.010606e+00
- dispersion mismatch (diagnostic) = 2.311313e-01
- final de-alias-edge energy fraction (resolution diagnostic) = 4.232184e-01

## Probe fits

- k-mode 1 axis x h=-1: c/u=1.463311e-01, R2=0.7373, |gamma|/|omega|=1.9228, qualified=False
- k-mode 1 axis x h=+1: c/u=1.773370e-01, R2=0.6667, |gamma|/|omega|=0.9234, qualified=False
- k-mode 1 axis y h=-1: c/u=8.867855e-02, R2=0.6591, |gamma|/|omega|=3.3687, qualified=False
- k-mode 1 axis y h=+1: c/u=2.300475e-01, R2=0.5895, |gamma|/|omega|=1.1071, qualified=False
- k-mode 1 axis z h=-1: c/u=1.366295e-02, R2=0.0890, |gamma|/|omega|=9.1580, qualified=False
- k-mode 1 axis z h=+1: c/u=4.157471e-02, R2=0.8994, |gamma|/|omega|=4.1585, qualified=False
- k-mode 2 axis x h=-1: c/u=9.524954e-02, R2=0.7504, |gamma|/|omega|=0.9688, qualified=False
- k-mode 2 axis x h=+1: c/u=8.544201e-02, R2=0.6795, |gamma|/|omega|=3.9499, qualified=False

## Qualification gates

- Q01_STATIC_TRANSVERSE_SAMPLING: PASS
- Q02_STATIC_A2_RECOVERY: PASS
- Q03_DYNAMIC_INITIAL_ISOTROPY: PASS
- Q04_DYNAMIC_INCOMPRESSIBILITY: PASS
- Q05_DYNAMIC_ENERGY_CONSERVATION: PASS
- Q06_RK4_LOCAL_CONVERGENCE: PASS
- Q07_BARE_REST_EULER_NO_WAVE: PASS

## Hypothesis gates

- H01_NONZERO_BORN_MODULUS_RETAINED: PASS
- H02_COHERENT_DYNAMIC_TRANSVERSE_POLE: FAIL
- H03_DYNAMIC_DIRECTION_ISOTROPY: FAIL
- H04_DYNAMIC_HELICITY_DEGENERACY: FAIL
- H05_APPROX_LINEAR_DISPERSION: FAIL
- H06_COARSE_RESOLUTION_SAME_QUALIFICATION_SIGN: PASS

## Master-Factor Wave Closure

- MF01 Born ratio: FAIL
- MF02 dynamic ratio: NOT_REACHED_NO_QUALIFIED_WAVE
- overall: NOT_CLOSED

## Scope guard

v0.2.0 advances from the affine Born test to a dealiased pseudospectral 3D incompressible Euler background with tangent-linear transverse helical probes. A negative dynamic result is reported as resolution-bounded: it does not prove impossibility for every Euler vortex microstructure, topology, or continuum limit.
