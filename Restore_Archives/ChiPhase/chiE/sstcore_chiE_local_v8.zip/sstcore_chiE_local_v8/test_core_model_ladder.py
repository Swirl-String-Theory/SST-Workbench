#!/usr/bin/env python3
from __future__ import annotations

import math

from sst_core_model_ladder import (
    TARGET_CHI_E,
    ASYMPTOTIC_MODEL_TABLE,
    alpha_required_for_target,
    chi_cavitation,
    chi_from_xi,
    chi_internal_profile,
    chi_surface_tension,
    density_profile_g,
    evaluate_asymptotic_model,
    evaluate_finite_core_balance,
    evaluate_surface_tension,
    profile_integral_I,
    sigma_required_for_target,
    xi_cavitation,
)


def assert_close(a: float, b: float, tol: float = 1e-10) -> None:
    if abs(a - b) > tol:
        raise AssertionError(f"{a!r} != {b!r} within {tol}")


def test_cavity_conversion() -> None:
    assert_close(xi_cavitation(1.0), 0.25)
    assert_close(chi_cavitation(1.0), math.pi * math.pi)


def test_rankine_integral() -> None:
    assert_close(profile_integral_I("rankine", n=4096), 0.25, tol=1e-8)
    assert_close(chi_internal_profile(1.0, "rankine", n=4096), math.pi * math.pi / 2.0, tol=2e-7)


def test_profiles_boundary_normalized() -> None:
    for profile in ["rankine", "polynomial", "lamb_oseen", "nlse_tanh"]:
        assert_close(density_profile_g(1.0, profile, shape=1.5, normalize_boundary=True), 1.0, tol=1e-12)


def test_finite_core_balance_no_false_match() -> None:
    r = evaluate_finite_core_balance(lambda_=1.0, epsilon=1.0, profile="rankine", n_theta=2048, n_profile=1024)
    if abs(r.chi_E - TARGET_CHI_E) / TARGET_CHI_E < 1e-2:
        raise AssertionError("finite-core regularized diagnostic accidentally matches 2*pi")


def test_asymptotic_required_alpha() -> None:
    req = alpha_required_for_target(1.0)
    # Known from v7 solid-core audit: close to but not equal to 7/4.
    assert 1.75 < req < 1.77
    solid = [s for s in ASYMPTOTIC_MODEL_TABLE if s.name == "solid_core_constant_volume"][0]
    r = evaluate_asymptotic_model(solid, 1.0)
    assert r.chi_E > TARGET_CHI_E


def test_surface_tension_required_sigma() -> None:
    base_chi = 17.630570750631865
    req = sigma_required_for_target(1.0, base_chi)
    assert req < 0.0
    r = evaluate_surface_tension(lambda_=1.0, epsilon=1.0, Sigma=0.0, base_mode="hollow", n=2048)
    assert r.Sigma_required_for_2pi < 0.0
    assert_close(chi_surface_tension(1.0, 1.0), 2.0 * math.pi * math.pi)


def main() -> None:
    test_cavity_conversion()
    test_rankine_integral()
    test_profiles_boundary_normalized()
    test_finite_core_balance_no_false_match()
    test_asymptotic_required_alpha()
    test_surface_tension_required_sigma()
    print("PASS: core model ladder tests")


if __name__ == "__main__":
    main()
