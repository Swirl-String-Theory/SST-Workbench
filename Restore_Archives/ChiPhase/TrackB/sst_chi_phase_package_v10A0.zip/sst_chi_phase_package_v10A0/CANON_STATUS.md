# CANON_STATUS — SST chi-phase v10A.0

## Short status

v10A.0 is **Research Track / CANON-compatible**, not locked CANON.

It is canon-compatible because it stays inside incompressible Euler / vortex mechanics and extracts the ring constant from a Biot-Savart vorticity-energy integral:

\[
E_{\rm BS}
=
\frac{\rho}{8\pi}
\int\!\!\int
\frac{
\boldsymbol\omega(\mathbf x)\cdot\boldsymbol\omega(\mathbf x')
}{
|\mathbf x-\mathbf x'|
}
\,d^3x\,d^3x'.
\]

The extracted quantity is:

\[
\alpha_{\rm eff}
=
\ln\left(\frac{8R}{a}\right)
-
\frac{2E_{\rm BS}}{\rho\Gamma^2R}.
\]

The thin-ring estimate is:

\[
\alpha_0=\lim_{a/R\to0}\alpha_{\rm eff}.
\]

## What is canon-safe?

The method and definitions are canon-safe Research Track:

\[
\alpha_{\rm eff}
=
\ln(8R/a)-2E/(\rho\Gamma^2R),
\]

\[
\beta=\alpha-1+q.
\]

## What is not canonized?

The numerical values from v10A.0 are not canonized. They are provisional because they depend on quadrature resolution, near-singularity treatment, and finite-\(\epsilon\) extrapolation.

## Main current result

The Rankine/solid-core benchmark lands near the expected classical value:

\[
\alpha_{\rm solid}\approx 7/4.
\]

This validates the pipeline at prototype level.

The v6 smooth-matched closure profile \(a_0^\star\) does **not** automatically land on the old NLS target \(\alpha\simeq1.61\) in this Track A calculation. That is not a failure; it means the \(\chi\)-closure selector and the NLS ring-energy selector are likely distinct unless Track B proves otherwise.

## Track split

- v10A.0: Euler/Biot-Savart, canon-compatible.
- Future v11B/v10B: NLSE/GP full core energy, more likely to reproduce \(\alpha_{\rm NLS}\approx1.61\), but less directly canon-fundamental unless framed as effective core-envelope physics.
