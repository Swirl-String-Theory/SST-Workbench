# SST chi-phase package v7 — legacy vortex-ring α/β target comparator

v7 is **not** another copy of v6. v6 solved the smooth-matched closure root

\[
(c_\chi/v_{\rm ref})^2=(2a_0^2+13a_0+78)/105=1.
\]

v7 compares that root against the old vortex-ring constants from the legacy
notebook, especially the NLS entry \((\alpha,\beta)=(1.61,0.61)\).

## Epistemic status

v7 is a **target comparator**, not a proof. It does not derive physical
\(\alpha_{\rm eff}\) or \(\beta_{\rm eff}\) from the ring energy. It simply
answers:

- how close is the v6 closure root \(a_0^\star\) to the old NLS \(\alpha=1.61\)?
- what is \(c_\chi/v\) if one inserts each legacy \(\alpha\) as the smooth-matched shape parameter \(a_0\)?
- which legacy \(\alpha,\beta\) relation is closest to the closure root?

## Key result

\[
a_0^\star = \frac{\sqrt{385}-13}{4}=1.6553542176.
\]

Legacy NLS:

\[
\alpha_{\rm NLS}=1.61,\qquad \beta_{\rm NLS}=0.61.
\]

So

\[
a_0^\star-\alpha_{\rm NLS}\approx 0.0453542.
\]

At the NLS alpha target:

\[
c_\chi(\alpha_{\rm NLS})/v_{\rm ref}\approx 0.99577.
\]

This is close, but not exact.

## Run

```powershell
python simulate_chi_phase_v7.py
```

Force pure Python:

```powershell
python simulate_chi_phase_v7.py --python
```

Force C++ rebuild:

```powershell
python sst_chi_phase_v7_build.py --force
```

## Exports

- `chi_v7_legacy_targets.csv`
- `chi_v7_special_points.csv`
- `chi_v7_a0_sweep.csv`
- `chi_v7_root_vs_legacy_alpha.png`
- `chi_v7_legacy_target_speed_bars.png`
- `chi_v7_legacy_alpha_distance.png`
- `chi_v7_selected_profiles.png`
- `chi_v7_beta_relation_residuals.png`
- `chi_v7_run_results_summary.txt`

## Next step

A real v8/v7.1 must derive \(\alpha_{\rm eff}\) and \(\beta_{\rm eff}\) from a
vortex-ring energy/impulse calculation. v7 only compares known target constants.
