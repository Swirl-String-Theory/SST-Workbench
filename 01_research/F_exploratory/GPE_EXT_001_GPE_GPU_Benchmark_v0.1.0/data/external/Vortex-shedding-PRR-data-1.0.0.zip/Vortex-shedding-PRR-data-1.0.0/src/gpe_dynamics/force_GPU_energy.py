from variable import *
from functions import *
import numpy as np
import cupy as cp



x_min,x_max = np.where(x==Wx2)[0][0], np.where(x==Wx1)[0][0]
y_min,y_max = np.where(y==Wy2)[0][0], np.where(y==Wy1)[0][0]

def Eren_force(a):
    psi = a.psi[y_min:y_max, x_min:x_max]
    crop_den = cp.abs(psi)**2
    V_prime = a.V_prime+1


    crop_V = V_prime[y_min:y_max, x_min:x_max] 
    dV_dx = cp.gradient(crop_V, dx, axis=1)
    dV_dy = cp.gradient(crop_V, dy, axis=0)
    force_x = cp.trapz(cp.trapz(dV_dx * crop_den, x_gpu[x_min:x_max], axis=1), y_gpu[y_min:y_max])
    force_y = cp.trapz(cp.trapz(dV_dy * crop_den, x_gpu[x_min:x_max], axis=1), y_gpu[y_min:y_max])                

    return [force_x,force_y]


