# Full SSTcore 0.8.18 rerun

The uploaded CPython-3.13 manylinux wheel was installed into an isolated virtual
environment using `pip --no-deps`.

Results:

- primary suite: **99/99**;
- Claude adversarial suite: **111/111**;
- SSTcore live alignment section: **19/19**;
- action--phase residual/counter-model harness: **PASS**;
- canon marker checker: **27/27**.

No stderr was produced by the three Claude audit programs. The live code checks also
reproduce the calibrated value

\[
F_{\mathrm{swirl}}^{\max}\approx29.05351013\ \mathrm{N},
\]

which supports the held precision patch numerically but does not override the frozen
canon datum without an explicit rebaselining decision.

The package still lacks the v0.8.28 action--phase API and the
`M_0=(m_e/4)L_tot` helper. These remain confirmed code gaps.
