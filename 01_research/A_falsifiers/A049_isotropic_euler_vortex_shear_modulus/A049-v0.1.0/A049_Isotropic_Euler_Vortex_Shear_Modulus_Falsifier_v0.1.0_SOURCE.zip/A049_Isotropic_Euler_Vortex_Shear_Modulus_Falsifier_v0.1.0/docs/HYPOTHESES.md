# A049 hypotheses and preregistered gates

## Research question

Can an isotropic, incompressible Euler-vorticity microstructure generate a nonzero, conservative transverse shear modulus without using density compressibility?

The release deliberately separates three claims:

1. **Affine/Born claim** — a frozen-in isotropic vortical microstructure has a nonzero conservative quadratic energy curvature under volume-preserving shear.
2. **Persistent modulus claim** — that curvature survives relaxation under full nonlinear Euler dynamics and defines a low-frequency macroscopic shear modulus.
3. **Wave/master-factor claim** — the persistent modulus supports an isotropic transverse branch and closes the SST Master-Factor speed ratio.

v0.1.0 directly tests claim 1, provides structural controls relevant to claim 2, and evaluates the Master-Factor Wave Closure Gate conditionally. It does **not** claim to have established claim 2.

## Orthodox affine Euler benchmark

For an incompressible affine deformation \(F\), Cauchy's vorticity formula gives

\[
\boldsymbol\omega' = F\boldsymbol\omega,
\qquad
\mathbf{k}' = F^{-T}\mathbf{k},
\qquad \det F=1.
\]

For a transverse Fourier mode, kinetic energy is proportional to

\[
\frac{|\boldsymbol\omega|^2}{|\mathbf{k}|^2}.
\]

For simple shear \(F=I+\gamma\,\mathbf e_x\otimes\mathbf e_y\), isotropic averaging over wave-vector direction and the two transverse polarizations gives

\[
\frac{E(\gamma)}{E_0}
=1+\frac{2}{15}\gamma^2+O(\gamma^4).
\]

Therefore, with \(e_0=\rho u_{\rm rms}^2/2\),

\[
\mu_{\rm Born}
=\left.\frac{d^2 e}{d\gamma^2}\right|_{\gamma=0}
=\frac{2}{15}\rho u_{\rm rms}^2,
\]

and, **only if this modulus persists dynamically**, the candidate transverse speed is

\[
\frac{c_T}{u_{\rm rms}}=\sqrt{\frac{2}{15}}.
\]

## Blind gates

Qualification gates check transversality, isotropy, recovery of \(2/15\), shear-plane isotropy, parity, SO(3) objectivity, cyclic reversibility, helicity degeneracy, and the no-wave baseline for homogeneous-rest Euler.

The Master-Factor Wave Closure Gate is preregistered as

\[
\left|\frac{c_T}{v_*}-\frac12\right|\le 0.01,
\]

where \(v_*\) is a blind reference speed. No \(\alpha\), \(c\), \(r_c\), \(\rho_{\!f}\), \(\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}\), or SST circulation is available to the blind campaign.

A failed Master-Factor gate is a valid scientific result and does not invalidate numerical qualification.

## References

```latex
\begin{thebibliography}{9}

\bibitem{Hartley1957}
R.~Hartley,
``Rotational Waves in a Turbulent Liquid,''
\textit{Journal of the Acoustical Society of America} \textbf{29}, 195--196 (1957).
\doi{10.1121/1.1908826}

\bibitem{Kelly1963}
E.~M.~Kelly,
``Maxwell's Equations as Properties of the Vortex Sponge,''
\textit{American Journal of Physics} \textbf{31}, 785--791 (1963).
\doi{10.1119/1.1969085}

\bibitem{Crow1967}
S.~C.~Crow,
``Visco-Elastic Character of Fine-Grained Isotropic Turbulence,''
\textit{Physics of Fluids} \textbf{10}, 1587--1589 (1967).
\doi{10.1063/1.1762327}

\bibitem{PullinSaffman1994}
D.~I.~Pullin and P.~G.~Saffman,
``Reynolds stresses and one-dimensional spectra for a vortex model of homogeneous anisotropic turbulence,''
\textit{Physics of Fluids} \textbf{6}, 1787--1796 (1994).
\doi{10.1063/1.868240}

\end{thebibliography}
```
