# Patch status for the v0.8.28 evidence pack

- `0001-upgrade-verification-suite-v0.8.17-to-v0.8.28.patch` is a portable diff of the verification suite itself.
- Historical canon-text patches `0004` and `0005` are retired because all six evidence guards are already present in the supplied v0.8.28 files.
- Historical repository patches are preserved under `legacy_repo_patches/`. They target SSTcore/Workbench source trees that were not supplied here, so they were not mechanically rebased or claimed as applied.
