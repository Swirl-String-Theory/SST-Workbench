@echo off
setlocal
if "%~2"=="" (
  echo Usage: %~nx0 C:\workspace\projects\SST-Workbench C:\path\SST_Parametric_Knot_Link_Seed_Atlas_v0.2.0.zip [TOPOLOGY]
  exit /b 2
)
call run_00_setup.cmd || exit /b 1
call run_05_resolve_sources.cmd "%~1" || exit /b 1
call run_10_inventory.cmd "%~1" || exit /b 1
call run_30_geometry.cmd "%~1" "%~2" "%~3" || exit /b 1
call run_90_pack.cmd || exit /b 1
endlocal
