# B007 v0.2.3 — Atlas Perturbation Dynamics

- Cases: 1; input perturbed records: 1; Lambda values: [3.4]
- Input source points: 2048,4096; dynamical points: [128, 256]; base/refined steps: 2/4; T*=0.0005
- Native two-level comparisons: False; provisional consistent cases: 0
- Filament model: regularized midpoint Biot-Savart plus explicit Heun, one knot at a time with circulation Gamma=1.
- Nominal and perturbed evolve independently from the same analytic source and identical solver settings.
- Rigid separation uses proper Kabsch SE(3) alignment at each sampled time. Material indexing retained; no cyclic reparametrization.
- Finite-time log growth and observed return are *diagnostics*, not Lyapunov exponent, attractor, proof of chaos or stability.
- Spatial and temporal gates compare only two levels. True asymptotic convergence requires additional independent levels.
- Edge/core and timestep/core^2 preflight heuristics can block promotion; neither proves stability.
- Shape/length errors, core clearance, finite-core Euler and cross-model agreement remain UNRESOLVED.
- Source coordinates are dimensionless R0=1; no SI calibration.
- G4 is NOT RUN. No physical clock or Euler equilibrium claim.

## Selected provisional numerical candidates

## Dataset integrity
- N2048: manifest SHA256 4fd255888ba7cd9a23595e61fe0db3b08ff3b8d33e4894949726e39565d9d875
- N4096: manifest SHA256 fc834bf46374614a05f8c18111d0e18344198b71b0304cbdff4ac8cbb08e80b7
