

This directory consists mostly of demo scripts. 
MOST knot and link files have the filename extension ".k".
MOST KnotPlot scripts have the extension ".kps".

KnotPlot reads in the file "basic-demos" when
the "load demos" button is pressed. 



