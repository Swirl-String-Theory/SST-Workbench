@echo off
setlocal
python -m sst_counterpulley.build_ext_if_needed --strict
if errorlevel 1 exit /b %errorlevel%
python run_blind.py --n 192 --offset-over-D 0.5 --eps-over-D 0.05 --out audit_out_blind\blind_canonical.json
if errorlevel 1 exit /b %errorlevel%
python run_benchmark.py audit_out_blind\blind_canonical.json --out audit_out_blind\posthoc_alpha_benchmark.json
exit /b %errorlevel%
