# Route-A/L2 photon-gas consistency falsifier

Expected photon degeneracy: g = 2
Expected coefficient u/(kT)^4*hbar^3*c^3 = pi^2/15 = 6.5797362673929050e-01

- orthodox_photon_Weyl_x_2_polarizations: ratio=1.0000000000000000e+00, pass=True
- invalid_photon_Weyl_x_2_x_4pi: ratio=1.2566370614359172e+01, pass=False
- invalid_photon_Weyl_x_2_x_(4pi)^2: ratio=1.5791367041742976e+02, pass=False

## Route-A/L2 implication
paired Weyl baseline coefficient = 1.1406646949649263e-03
dim(R^3 tensor Lambda^2 R^3) = 9
dim-only coefficient = 1.0265982254684336e-02
with extra (4*pi)^2 coefficient = 1.6211389382774044e+00
old trial 16/pi^2 coefficient = 1.6211389382774044e+00
dim-only / old-trial = 6.3325739776461110e-03
missing factor after dim=9 only = 1.5791367041742973e+02 = 16*pi^2

Verdict: extra angular measure fails the photon-gas control; keep dim=9 [ORTHODOX], demote (4*pi)^2 to [NOT DERIVED / measure convention / double-counting risk].
