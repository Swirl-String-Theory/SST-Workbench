from __future__ import annotations
from pathlib import Path
import secrets
import numpy as np
from sst_falsifier_core.gates import GateLedger, GateRecord
from sst_falsifier_core.protocol import load_config, freeze_protocol
from sst_falsifier_core.source_registry import resolve_sources
from sst_falsifier_core.util import write_json, environment_record
from sst_falsifier_core.blind import opaque_id
from .sources import (
    discover_pklsa, discover_xyz_like, load_cross_source_manifest,
    activate_a002, a002_load,
)
from .invariants import load_table, snappy_twist_records, numeric_records
from .rational_lane import pair_statistics, TWIST_CHAIN
from .dynamics import relative_equilibrium_score, resolution_certificate, gpu_parity
from .algebra import load_core_response, closure_metrics, double_cover_metrics


def _public_source_summary(src, required):
    return {
        "required_count": len(required),
        "required_present": sum(bool(src.get(k, {}).get("exists")) for k in required),
        "optional_present_count": sum(bool(v.get("exists")) for k, v in src.items() if k not in required),
    }


def _load_candidates(src, cfg, cross_source_manifest=None):
    rows = []; pklsa_audit = None
    if src["pklsa"]["exists"]:
        pk, pklsa_audit = discover_pklsa(src["pklsa"]["path"])
        rows += pk
    for key in ("fremlin", "gilbert", "katlas", "knotplot"):
        if src[key]["exists"]:
            rows += discover_xyz_like(src[key]["path"], key, cfg["limits"].get("max_cross_source_files", 10000))
    if cross_source_manifest:
        rows += load_cross_source_manifest(cross_source_manifest)
    return rows, pklsa_audit


def _screen_population(pk, max_candidates):
    """Family-stratified round robin: one variant per family before reuse."""
    ordered = sorted(pk, key=lambda r: (int(r.get("variant_index", 0)), int(r.get("family_index", 0))))
    return ordered[: min(int(max_candidates), len(ordered))]


def _blind_map(pk, out):
    private = out / "private"; private.mkdir(parents=True, exist_ok=True)
    salt = secrets.token_hex(24)
    public = []; mapping = []
    for i, r in enumerate(pk):
        source_seed = f"{r.get('candidate_source_id')}|{r.get('source_sha256')}|{r.get('variant_index')}"
        family_seed = f"family|{r.get('family')}|{r.get('family_index')}"
        cid = "C" + opaque_id(source_seed, salt, 18)
        gid = "G" + opaque_id(family_seed, salt, 14)
        public.append({"candidate_id": cid, "family_group_id": gid, "_internal_index": i})
        mapping.append({
            "candidate_id": cid, "family_group_id": gid, "internal_index": i,
            "candidate_source_id": r.get("candidate_source_id"), "family": r.get("family"),
            "family_index": r.get("family_index"), "variant_index": r.get("variant_index"),
            "topology": r.get("topology"), "source_path": r.get("source_path"),
            "source_sha256": r.get("source_sha256"),
        })
    write_json(private / "candidate_map.json", {"salt": salt, "rows": mapping})
    return public


def _try_geometry(row, a002_ok):
    if row.get("components") is not None:
        return row["components"]
    if a002_ok and row.get("source_path"):
        try:
            return a002_load(row["source_path"])
        except Exception:
            return None
    return None


def run(config_path, outdir, profile="basic", backend=None, invariants_path=None, core_response=None, cross_source_manifest=None):
    cfg = load_config(config_path); out = Path(outdir); out.mkdir(parents=True, exist_ok=True); led = GateLedger()
    (out / "private").mkdir(exist_ok=True)
    freeze_protocol(cfg, out / "FROZEN_PROTOCOL.json"); write_json(out / "environment.json", environment_record())

    src = resolve_sources(cfg.get("source_overrides"))
    write_json(out / "private" / "source_resolution.json", src)
    required = cfg["sources"]["required_for_discovery"]
    missing = [k for k in required if not src.get(k, {}).get("exists")]
    led.add(GateRecord(
        "G0", "PASS" if not missing else "UNRESOLVED", "Required source provenance is present",
        {**_public_source_summary(src, required), "missing_required_count": len(missing)},
        "Exact paths/source identities are private; missing sources make the campaign unresolved, never negative evidence.",
    ))
    a002_ok = bool(src.get("sst_knot_library", {}).get("exists")) and activate_a002(src["sst_knot_library"]["path"])
    candidates, pklsa_audit = _load_candidates(src, cfg, cross_source_manifest)
    write_json(out / "private" / "pklsa_adapter_audit.json", pklsa_audit or {})
    pk = [r for r in candidates if r["source_family"] == "pklsa" and r.get("components") is not None]
    n_fam = len({r.get("family") for r in pk if r.get("family")})
    expected_c = int(cfg["gates"]["g1_expected_pklsa_candidates"])
    expected_f = int(cfg["gates"]["g1_expected_pklsa_families"])
    family_counts = {}
    for r in pk:
        family_counts[r.get("family")] = family_counts.get(r.get("family"), 0) + 1
    exact_family_grid = n_fam == expected_f and len(pk) == expected_c and set(family_counts.values()) == {48}
    adapter_clean = not (pklsa_audit or {}).get("family_errors")
    ok = exact_family_grid and adapter_clean
    led.add(GateRecord(
        "G1", "PASS" if ok else "UNRESOLVED", "The complete PKLSA family-by-variant population is admissible",
        {"pklsa_geometry_candidates": len(pk), "pklsa_families": n_fam, "variants_per_loaded_family": sorted(set(family_counts.values())),
         "expected_candidates": expected_c, "expected_families": expected_f, "adapter_family_errors": len((pklsa_audit or {}).get("family_errors", []))},
        "All 49 families and all 48 variants per family are prerequisites; partial family-bundle decoding is unresolved.",
    ))
    public_ids = _blind_map(pk, out) if ok else []
    public_by_internal = {r["_internal_index"]: r for r in public_ids}

    # Invariant/fractional lane: independent of PKLSA shape variants.
    inv = []
    if invariants_path:
        inv += load_table(invariants_path)
    inv += snappy_twist_records(TWIST_CHAIN)
    inv = numeric_records(inv); providers = sorted({r.get("provider") for r in inv})
    led.add(GateRecord(
        "G2", "PASS" if len(inv) >= cfg["gates"]["g2_min_invariant_records"] else "UNRESOLVED",
        "Independent dimensionless invariant records are available",
        {"records": len(inv), "provider_count": len(providers)},
        "Provider names/records may be audited separately; invariant absence is unresolved, not falsification.",
    ))
    if led.status("G2") == "PASS":
        rr = pair_statistics(inv, cfg["rational"]["qmax"], cfg["rational"]["permutations"], cfg["random_seed"])
        write_json(out / "G3_rational_discovery.json", rr)
        discoveries = [r for r in rr if r["bh_q"] <= cfg["rational"]["fdr_alpha"] and r["scaled_error"] <= cfg["rational"]["max_scaled_error"]]
        led.add(GateRecord(
            "G3", "PASS" if discoveries else "FAIL", "A low-denominator structure survives permutation and multiplicity controls",
            {"tests": len(rr), "discoveries": len(discoveries), "fdr_alpha": cfg["rational"]["fdr_alpha"]},
            "This gate has no access to the private historical target pair or target fractions.",
        ))
    else:
        led.add(GateRecord("G3", "NOT_RUN_PREREQUISITE", "Blind rational discovery", {"requires": "G2 PASS"}, "The fractional lane stops without admissible invariant data; other lanes remain independent."))

    # G4 is independent of G3 but requires the full G1 atlas.
    if led.status("G1") == "PASS":
        requested = backend or cfg["backend"]["screen"]
        screen_pk = _screen_population(pk, cfg["limits"]["basic_max_candidates"] if profile == "basic" else len(pk))
        parity_rep = None
        if requested not in {"cpu", "native", "python"} and screen_pk:
            try:
                parity_rep = gpu_parity(screen_pk[0]["components"], requested, cfg["dynamics"]["core"])
            except Exception as e:
                parity_rep = {"error": repr(e), "relative_l2": float("inf")}
        gpu_ok = (parity_rep is None) or parity_rep.get("relative_l2", float("inf")) <= cfg["backend"]["gpu_parity_rtol"]
        effective = requested if gpu_ok else "cpu"
        write_json(out / "G4_backend_parity.json", {"requested": requested, "effective": effective, "parity": parity_rep, "gpu_ok": gpu_ok})

        scores_internal = []
        index_by_obj = {id(r): i for i, r in enumerate(pk)}
        for r in screen_pk:
            ii = index_by_obj[id(r)]; pub = public_by_internal[ii]
            try:
                m = relative_equilibrium_score(r["components"], effective, cfg["dynamics"]["core"])
                scores_internal.append({"_internal_index": ii, "candidate_id": pub["candidate_id"], "family_group_id": pub["family_group_id"], **m})
            except Exception as e:
                scores_internal.append({"_internal_index": ii, "candidate_id": pub["candidate_id"], "family_group_id": pub["family_group_id"], "error": repr(e), "re_residual": float("inf")})
        scores_internal.sort(key=lambda r: r.get("re_residual", float("inf")))
        write_json(out / "G4_screen.json", [{k: v for k, v in r.items() if not k.startswith("_")} for r in scores_internal])

        unique = []; seen = set()
        for r in scores_internal:
            k = r["family_group_id"]
            if k in seen or not np.isfinite(r.get("re_residual", float("inf"))):
                continue
            seen.add(k); unique.append(r)
            if len(unique) >= cfg["dynamics"]["finalists"]:
                break
        led.add(GateRecord(
            "G4", "PASS" if len(unique) >= cfg["dynamics"]["min_finalists"] else "UNRESOLVED",
            "Broad carrier screening yields distinct upstream-family CPU-certifiable finalists",
            {"screened": len(scores_internal), "families_represented": len({r['family_group_id'] for r in scores_internal}), "unique_finalists": len(unique),
             "effective_backend": effective, "gpu_parity": parity_rep},
            "GPU is rank-only after parity; 48 variants of one PKLSA family never count as 48 independent finalists.",
        ))

        cert_internal = []
        for u in unique:
            srcrow = pk[u["_internal_index"]]
            rep = resolution_certificate(srcrow["components"], tuple(cfg["dynamics"]["resolution_levels"]), cfg["dynamics"]["core"])
            cert_internal.append({"_internal_index": u["_internal_index"], "candidate_id": u["candidate_id"], "family_group_id": u["family_group_id"], **rep})
        write_json(out / "G5_cpu_certification.json", [{k: v for k, v in r.items() if not k.startswith("_")} for r in cert_internal])
        passed = [c for c in cert_internal if c["last_relative_change"] <= cfg["dynamics"]["resolution_rtol"]]
        led.add(GateRecord(
            "G5", "PASS" if len(passed) >= cfg["dynamics"]["min_certified"] else "FAIL",
            "Finalists survive CPU-only resolution certification",
            {"certified": len(passed), "tested": len(cert_internal), "resolution_rtol": cfg["dynamics"]["resolution_rtol"]},
            "This certifies the preregistered regularized filament screening observable, not full 3-D Euler orbital stability.",
        ))

        # G5X: independently prepared geometry for the same underlying topology, with CPU numerical certification.
        external = [r for r in candidates if r["source_family"] != "pklsa"]
        repl_public = []; replicated_finalists = 0
        cross_salt = secrets.token_hex(20)
        for c in passed:
            base = pk[c["_internal_index"]]; topo = base.get("topology")
            by_source = {}
            for r in external:
                if r.get("topology") == topo:
                    by_source.setdefault(r["source_family"], r)
            source_pass = []
            for sf, r in sorted(by_source.items()):
                comps = _try_geometry(r, a002_ok)
                if comps is None:
                    continue
                try:
                    rep = resolution_certificate(comps, tuple(cfg["cross_source"]["resolution_levels"]), cfg["dynamics"]["core"])
                except Exception:
                    continue
                good = rep["last_relative_change"] <= cfg["dynamics"]["resolution_rtol"]
                sgid = "S" + opaque_id(sf, cross_salt, 12)
                repl_public.append({"candidate_id": c["candidate_id"], "source_group_id": sgid, "cpu_converged": bool(good), "certificate": rep})
                if good:
                    source_pass.append(sf)
            if 1 + len(set(source_pass)) >= cfg["cross_source"]["min_source_families"]:
                replicated_finalists += 1
        write_json(out / "G5X_cross_source_certification.json", repl_public)
        led.add(GateRecord(
            "G5X", "PASS" if replicated_finalists >= cfg["cross_source"]["min_replicated_finalists"] else "UNRESOLVED",
            "CPU-certified finalists replicate numerically across independently prepared geometry source families",
            {"replicated_finalists": replicated_finalists, "required": cfg["cross_source"]["min_replicated_finalists"], "a002_available": a002_ok,
             "cross_source_certificates": len(repl_public), "external_manifest_supplied": bool(cross_source_manifest)},
            "Source-family identities are blinded in public output. A source-root's mere existence is not counted as replication.",
        ))

    else:
        led.add(GateRecord("G4", "NOT_RUN_PREREQUISITE", "Broad carrier screening", {"requires": "G1 PASS"}, "Dynamics lane cannot start from a partial/ambiguous PKLSA population."))
        led.add(GateRecord("G5", "NOT_RUN_PREREQUISITE", "CPU resolution certification", {"requires": "G4 PASS"}, "No finalist certification without admissible screening population."))
        led.add(GateRecord("G5X", "NOT_RUN_PREREQUISITE", "Cross-source replication", {"requires": "G5 PASS"}, "No replication claim without CPU-certified finalists."))

    if core_response:
        d = load_core_response(core_response); cm = closure_metrics(d["generators"]); dc = double_cover_metrics(d["angles"], d["state_overlap"]) if "angles" in d else None
        closure_pass = cm["closure_relative_residual"] <= cfg["algebra"]["closure_rtol"] and cm["noncommutativity"] >= cfg["algebra"]["min_noncommutativity"]
        double_pass = bool(dc and dc["overlap_4pi_abs"] >= cfg["algebra"]["overlap_4pi_min"] and dc["overlap_2pi_real"] <= cfg["algebra"]["overlap_2pi_real_max"])
        status = "PASS" if closure_pass and double_pass else "FAIL"
        metrics = {"closure": cm, "double_cover": dc, "closure_pass": closure_pass, "double_cover_pass": double_pass}
    else:
        status = "NOT_RUN_PREREQUISITE"; metrics = {"required_contract": "NPZ with generators[3,n,n], angles[], state_overlap[]"}
    led.add(GateRecord(
        "G6", status, "A physical finite-core response closes a non-Abelian algebra and demonstrates a double-cover state",
        metrics, "Analytic SO(3) controls cannot satisfy the physical-provider requirement; ordinary 2pi return rejects the half-integer bridge.",
    ))
    led.write(out / "gate_ledger.json")
    st = {g: led.status(g) for g in ("G0","G1","G2","G3","G4","G5","G5X","G6")}
    fractional = "SUPPORTED" if st["G3"] == "PASS" else ("FALSIFIED" if st["G3"] == "FAIL" else "UNRESOLVED")
    algebra = "SUPPORTED" if st["G6"] == "PASS" else ("FALSIFIED" if st["G6"] == "FAIL" else "UNRESOLVED")
    combined_required = ("G0","G1","G3","G4","G5","G5X","G6")
    combined = "ELIGIBLE_FOR_PRIVATE_REVEAL" if all(st[g] == "PASS" for g in combined_required) else "NOT_ELIGIBLE"
    write_json(out / "SCIENTIFIC_SUMMARY.json", {
        "schema": "SST-KSA-SCIENTIFIC-SUMMARY-1",
        "fractional_topology_lane": fractional,
        "physical_algebra_lane": algebra,
        "combined_bridge": combined,
        "combined_required_gates": list(combined_required),
        "gate_status": st,
        "guard": "No particle/quark/electroweak interpretation is authorized before private reveal, and a reveal match cannot repair a failed or unresolved blind gate.",
    })
    return led.to_dict()
