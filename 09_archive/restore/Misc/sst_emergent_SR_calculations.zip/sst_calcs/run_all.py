#!/usr/bin/env python3
"""run_all.py — execute every verification script and report PASS/FAIL."""
import subprocess, sys, glob, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
scripts = sorted(glob.glob("s[0-9]*_*.py"))
fails = 0
for s in scripts:
    r = subprocess.run([sys.executable, s], capture_output=True, text=True)
    ok = (r.returncode == 0) and ("CHECKS PASSED" in r.stdout)
    print(f"[{'PASS' if ok else 'FAIL'}]  {s}")
    if not ok:
        fails += 1
        print(r.stdout[-400:]); print(r.stderr[-400:])
print(f"\n{len(scripts)-fails}/{len(scripts)} scripts passed.")
sys.exit(1 if fails else 0)
