from __future__ import annotations
from pathlib import Path
import json,os,re,subprocess,time,csv
from datetime import datetime
from .kpc import resume_script
from .model import prepare_components_from_coords,parse_multicomponent_coords

REJECT=("unknown command","unknown parameter","invalid parameter","illegal parameter","not a parameter","obsolete")
HARD=("can't open file","cannot open file","failed to open","freeglut error")

def resolve_knotplot(package_root):
    override=os.environ.get("KNOTPLOT_LNK","").strip()
    sc=Path(override) if override else package_root.parent/"KnotPlot.lnk"
    if not sc.is_file(): raise FileNotFoundError(f"KnotPlot shortcut missing: {sc}")
    ps="$s=(New-Object -ComObject WScript.Shell).CreateShortcut('"+str(sc).replace("'","''")+"'); Write-Output $s.TargetPath; Write-Output $s.WorkingDirectory"
    cp=subprocess.run(["powershell","-NoProfile","-Command",ps],capture_output=True,text=True)
    rows=[x.strip() for x in cp.stdout.splitlines() if x.strip()]
    if not rows: raise RuntimeError("Could not resolve KnotPlot.lnk")
    return Path(rows[0]),Path(rows[1]) if len(rows)>1 and rows[1] else package_root.parent

def render(text,campaign,cwd,name):
    rel=os.path.relpath(campaign,cwd).replace("\\","/")
    if " " in rel: raise RuntimeError("Campaign relative path contains spaces")
    rd=campaign/"runtime_kpc";rd.mkdir(parents=True,exist_ok=True)
    p=rd/name;p.write_text(text.replace("__CAMPAIGN_REL__",rel),encoding="utf-8",newline="\n");return p

def fmt_duration(seconds):
    if seconds is None or not isinstance(seconds,(int,float)) or seconds<0:return "--:--:--"
    seconds=int(round(seconds));d,rem=divmod(seconds,86400);h,rem=divmod(rem,3600);m,s=divmod(rem,60)
    return f"{d}d {h:02d}:{m:02d}:{s:02d}" if d else f"{h:02d}:{m:02d}:{s:02d}"

def log_progress(campaign,message):
    stamp=datetime.now().astimezone().isoformat(timespec="seconds");line=f"{stamp} {message}"
    print(line,flush=True)
    with (campaign/"progress.log").open("a",encoding="utf-8") as f:f.write(line+"\n");f.flush()

def run_kpc(exe,cwd,kpc,log):
    with kpc.open("rb") as fin,log.open("wb") as fout:
        cp=subprocess.run([str(exe),"-nog"],cwd=str(cwd),stdin=fin,stdout=fout,stderr=subprocess.STDOUT)
    txt=log.read_text(encoding="utf-8",errors="replace")
    rej=[x.strip() for x in txt.splitlines() if any(k in x.lower() for k in REJECT)]
    hard=[x.strip() for x in txt.splitlines() if any(k in x.lower() for k in HARD)]
    return cp.returncode,rej,hard

def prepare_topologies(package_root,campaign,force=False):
    plan=json.loads((campaign/"campaign.json").read_text());exe,cwd=resolve_knotplot(package_root)
    rawd=campaign/"prep_raw";prepd=campaign/"prepared_inputs";logs=campaign/"logs"
    rawd.mkdir(exist_ok=True);prepd.mkdir(exist_ok=True);logs.mkdir(exist_ok=True)
    result=[];dur=[];total=len(plan["topologies"])
    for i,t in enumerate(plan["topologies"],1):
        raw=rawd/f"{t['topo_id']}.txt";prepared=prepd/f"{t['topo_id']}.txt";ap=prepd/f"{t['topo_id']}.allocation.json";start=time.monotonic()
        if force or not raw.is_file():
            src=(campaign/"prep_kpc"/f"{t['topo_id']}.kpc").read_text(encoding="utf-8");rt=render(src,campaign,cwd,f"PREP__{t['topo_id']}.kpc")
            log_progress(campaign,f"[PREP {i:03d}/{total:03d}] START {t['spec']}")
            rc,rej,hard=run_kpc(exe,cwd,rt,logs/f"PREP__{t['topo_id']}.log")
            if rc or rej or hard or not raw.is_file():raise RuntimeError(f"Topology probe failed for {t['spec']}: rc={rc} reject={rej[-3:]} hard={hard[-3:]}")
        comps=parse_multicomponent_coords(raw)
        if len(comps)!=int(t["components"]):raise RuntimeError(f"Component-count mismatch for {t['spec']}: expected {t['components']}, parsed {len(comps)}")
        allocation=prepare_components_from_coords(raw,prepared,t["nbeads"],plan["min_beads_per_component"])
        allocation.update({"topology_id":t["topo_id"],"kind":t["kind"],"spec":t["spec"],"expected_components":t["components"]});ap.write_text(json.dumps(allocation,indent=2)+"\n")
        dt=time.monotonic()-start;dur.append(dt);eta=(sum(dur)/len(dur))*(total-i)
        log_progress(campaign,f"[PREP {i:03d}/{total:03d}] DONE {t['spec']} elapsed={fmt_duration(dt)} prepETA={fmt_duration(eta)} lengths={['%.6g'%x for x in allocation['component_lengths']]} beads={allocation['allocated_beads']}")
        result.append(allocation)
    (prepd/"ALLOCATIONS.json").write_text(json.dumps(result,indent=2)+"\n");return result

def checkpoint_file(campaign,rid,it,ext):return campaign/"out"/f"{rid}_i{it:06d}.{ext}"
def completed_checkpoint(campaign,rid,checkpoints):
    found=[]
    for it in checkpoints:
        m=checkpoint_file(campaign,rid,it,"metrics.csv");k=checkpoint_file(campaign,rid,it,"k")
        if m.is_file() and m.stat().st_size>0 and k.is_file() and k.stat().st_size>0:found.append(it)
    return max(found) if found else None

def append_timing(campaign,row):
    p=campaign/"timings.csv";fields=["run_index","run_total","run_id","mode","status","start_time","end_time","elapsed_seconds","start_checkpoint","final_checkpoint","max_ago"]
    exists=p.is_file()
    with p.open("a",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields)
        if not exists:w.writeheader()
        w.writerow({k:row.get(k) for k in fields})

def recent_mean(v,n=12):
    x=[float(a) for a in v if a and a>0][-n:]
    return sum(x)/len(x) if x else None

def execute_one(exe,cwd,rt,log,campaign,rid,index,total,cps,max_ago,mode,done_durations,progress_every):
    start_wall=datetime.now().astimezone();start=time.monotonic();start_cp=completed_checkpoint(campaign,rid,cps) or 0;last_seen=start_cp;last_report=-1
    log_progress(campaign,f"[RUN {index:04d}/{total:04d}] START {rid} mode={mode} from={start_cp} target={max_ago}")
    with rt.open("rb") as fin,log.open("ab" if mode.startswith("RESUME") else "wb") as fout:
        proc=subprocess.Popen([str(exe),"-nog"],cwd=str(cwd),stdin=fin,stdout=fout,stderr=subprocess.STDOUT)
        while True:
            rc=proc.poll();elapsed=time.monotonic()-start;cpnow=completed_checkpoint(campaign,rid,cps) or start_cp
            changed=cpnow!=last_seen; heartbeat=last_report<0 or elapsed-last_report>=max(1,progress_every)
            if changed or heartbeat or rc is not None:
                denom=max(1,max_ago-start_cp);frac=max(0,min(1,(cpnow-start_cp)/denom));run_eta=(elapsed/frac-elapsed) if frac>0.001 else None
                avg=recent_mean(done_durations);remaining=max(0,total-index)
                if avg is not None:camp_eta=(run_eta if run_eta is not None else avg)+remaining*avg
                elif run_eta is not None:camp_eta=run_eta+remaining*(elapsed/max(frac,0.001))
                else:camp_eta=None
                log_progress(campaign,f"[TIMER {index:04d}/{total:04d}] {rid} elapsed={fmt_duration(elapsed)} checkpoint={cpnow}/{max_ago} ({frac*100:5.1f}%) runETA={fmt_duration(run_eta)} campaignETA={fmt_duration(camp_eta)}")
                last_seen=cpnow;last_report=elapsed
            if rc is not None:break
            time.sleep(min(5,max(1,progress_every)))
    return rc,time.monotonic()-start,start_wall,datetime.now().astimezone(),start_cp

def execute(package_root,campaign,baseline,fit_mindist,save_coords,force=False,limit=None,progress_every=30):
    plan=json.loads((campaign/"campaign.json").read_text());prepare_topologies(package_root,campaign,False);exe,cwd=resolve_knotplot(package_root)
    out=campaign/"out";logs=campaign/"logs";out.mkdir(exist_ok=True);logs.mkdir(exist_ok=True);runs=plan["runs"][:limit] if limit else plan["runs"];max_ago=plan["max_ago"]
    log_progress(campaign,f"[CAMPAIGN] START name={plan['name']} runs={len(runs)} max_ago={max_ago} heartbeat={progress_every}s")
    fail=skip=0;durations=[];campaign_start=time.monotonic()
    for i,r in enumerate(runs,1):
        rid=r["run_id"];cps=plan["checkpoints"];final=cps[-1]
        if not force and checkpoint_file(campaign,rid,final,"metrics.csv").is_file() and checkpoint_file(campaign,rid,final,"k").is_file():
            skip+=1;log_progress(campaign,f"[RUN {i:04d}/{len(runs):04d}] SKIP {rid} final={final} already complete");continue
        last=None if force else completed_checkpoint(campaign,rid,cps)
        if last is not None and last<final:
            remain=[x for x in cps if x>last];text=resume_script(r,baseline,remain,last,fit_mindist,save_coords);name=f"{rid}__resume_i{last:06d}.kpc";mode=f"RESUME@{last}"
        else:text=(campaign/"kpc"/f"{rid}.kpc").read_text();name=f"{rid}.kpc";mode="START"
        rt=render(text,campaign,cwd,name);log=logs/f"{rid}.log"
        rc,elapsed,sw,ew,start_cp=execute_one(exe,cwd,rt,log,campaign,rid,i,len(runs),cps,max_ago,mode,durations,progress_every)
        txt=log.read_text(encoding="utf-8",errors="replace");rej=[x.strip() for x in txt.splitlines() if any(k in x.lower() for k in REJECT)];hard=[x.strip() for x in txt.splitlines() if any(k in x.lower() for k in HARD)];last_done=completed_checkpoint(campaign,rid,cps)
        ok=rc==0 and not rej and not hard and checkpoint_file(campaign,rid,final,"metrics.csv").is_file();status="PASS" if ok else "FAIL"
        (logs/f"{rid}_audit.json").write_text(json.dumps({"run_id":rid,"mode":mode,"status":status,"exit":rc,"rejections":rej[-20:],"hard_errors":hard[-20:],"last_checkpoint":last_done,"elapsed_seconds":elapsed},indent=2)+"\n")
        append_timing(campaign,{"run_index":i,"run_total":len(runs),"run_id":rid,"mode":mode,"status":status,"start_time":sw.isoformat(timespec="seconds"),"end_time":ew.isoformat(timespec="seconds"),"elapsed_seconds":round(elapsed,3),"start_checkpoint":start_cp,"final_checkpoint":last_done,"max_ago":max_ago})
        if ok:durations.append(elapsed)
        else:fail+=1
        avg=recent_mean(durations);eta=avg*(len(runs)-i) if avg is not None else None
        log_progress(campaign,f"[RUN {i:04d}/{len(runs):04d}] DONE {rid} status={status} elapsed={fmt_duration(elapsed)} last={last_done} avgRun={fmt_duration(avg)} remainingETA={fmt_duration(eta)}")
    log_progress(campaign,f"[CAMPAIGN] DONE pass_or_skip={len(runs)-fail} fail={fail} skipped={skip} elapsed={fmt_duration(time.monotonic()-campaign_start)}")
    return 1 if fail else 0
