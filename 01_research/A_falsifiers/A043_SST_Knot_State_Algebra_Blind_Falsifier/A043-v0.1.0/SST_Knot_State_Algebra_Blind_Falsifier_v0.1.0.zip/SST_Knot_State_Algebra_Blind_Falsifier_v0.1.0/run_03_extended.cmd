@echo off
setlocal
call .venv\Scripts\activate.bat
set "OUT=SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs\extended"
python run_pipeline.py --config configs\extended.json --profile extended --out "%OUT%" %*
