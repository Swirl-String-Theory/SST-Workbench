from __future__ import annotations
import csv, hashlib, pathlib, re
import numpy as np

NUM = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")
COORD_EXTS={".txt",".xyz",".dat",".csv",".vect"}

def sha256_file(path: pathlib.Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

def _dedup_close(a: np.ndarray) -> np.ndarray:
    if len(a)>4:
        scale=max(1.0,float(np.linalg.norm(a,axis=1).max()))
        if np.linalg.norm(a[0]-a[-1]) < 1e-12*scale:
            a=a[:-1]
    return a

def load_coords(path: str|pathlib.Path) -> np.ndarray:
    path=pathlib.Path(path)
    if path.suffix.lower()==".vect":
        return _load_vect(path)
    pts=[]
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        s=line.strip()
        if not s or s.startswith(("#",";","//")): continue
        vals=NUM.findall(s)
        if len(vals)==3:
            try: pts.append([float(v) for v in vals])
            except ValueError: pass
    if len(pts)<8:
        raise ValueError(f"{path}: fewer than 8 XYZ rows")
    a=np.asarray(pts,dtype=np.float64)
    if not np.isfinite(a).all(): raise ValueError(f"{path}: non-finite coordinates")
    return _dedup_close(a)

def _load_vect(path: pathlib.Path) -> np.ndarray:
    lines=[ln.strip() for ln in path.read_text(encoding="utf-8", errors="ignore").splitlines() if ln.strip()]
    try: i=next(j for j,s in enumerate(lines) if s.upper().startswith("VECT"))+1
    except StopIteration: raise ValueError(f"{path}: VECT header missing")
    hdr=[int(float(x)) for x in NUM.findall(lines[i])[:3]]; i+=1
    if len(hdr)<3: raise ValueError(f"{path}: invalid VECT header")
    nobj,nvert,_=hdr
    counts=[]
    while len(counts)<nobj:
        counts += [int(float(x)) for x in NUM.findall(lines[i])]; i+=1
    color_counts=[]
    while len(color_counts)<nobj:
        color_counts += [int(float(x)) for x in NUM.findall(lines[i])]; i+=1
    pts=[]
    while len(pts)<nvert and i<len(lines):
        vals=NUM.findall(lines[i]); i+=1
        if len(vals)>=3: pts.append([float(vals[0]),float(vals[1]),float(vals[2])])
    if len(pts)<8: raise ValueError(f"{path}: insufficient VECT vertices")
    # For multi-component VECT files, this v0.1.0 gate requires a single closed component.
    if nobj != 1: raise ValueError(f"{path}: multi-component VECT ({nobj}) not supported in v0.1.0")
    return _dedup_close(np.asarray(pts,dtype=np.float64))

def discover_coords(root: str|pathlib.Path):
    root=pathlib.Path(root)
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in COORD_EXTS: continue
        low=p.name.lower()
        if low.endswith(".modes.csv") or low.endswith(".phase.csv") or "summary" in low or "manifest" in low: continue
        yield p

def read_modes(path: pathlib.Path):
    rows=[]
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        r=csv.DictReader(f)
        for row in r:
            try:
                k=float(row["k_m_inv"]); w=float(row["omega_rad_s"])
                if k>0 and w>0: rows.append((k,w))
            except Exception: pass
    return np.asarray(rows,dtype=float)
