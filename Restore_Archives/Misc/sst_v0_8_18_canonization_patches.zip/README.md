# SST CANON v0.8.18 canonization patch queue

Apply these patches in order:

1. `01_orthodox_ropelength_foundation.patch`
2. `02_screening_functional_scalarization.patch`
3. `03_thin_filament_energy_scale.patch`
4. `04_geometric_mass_functional_audit.patch`
5. `05_geometric_impedance_bridge.patch`
6. `06_release_status_summary.patch`

The patches are sequential. Patch 02 expects Patch 01 to have been applied, and so on.

Patch scope:
- Patch 01 promotes orthodox finite-thickness/ropelength conventions.
- Patch 02 scalarizes the screening functional and prevents unscalarized `delta Q(K)`.
- Patch 03 adds the derived leading thin-filament energy scale.
- Patch 04 audits the geometric mass branch, density usage, and alpha-gate status.
- Patch 05 adds a geometric impedance bridge with explicit reparameterization status.
- Patch 06 adds release hygiene and stricter reintegration rules.

Generated for:
- `SST_CANON-v0.8.18.tex`
- `SST_CANON-v0.8.18-research-track.tex`
