# SST Counter-Pulley Alpha Falsifier v0.3.0

## Coupled Kelvin / Floquet eigenmode clock — alpha-blind

This version replaces the v0.2 clock/holonomy candidates with a temporal linear-response calculation of the actual regularised two-filament Biot–Savart ODE.

The central question is deliberately narrow:

> Can a counter-rotating `+Gamma/-Gamma` trefoil pair generate a parameter-free, dynamically selected relative phase from its own coupled Kelvin-like eigenmodes, before the fine-structure constant is opened?

The answer for the present minimal model is **no**, but for a more informative reason than v0.2: the new phase is genuinely dynamical and does **not** collapse to ribbon twist, yet the present double-trefoil geometry is not a relative equilibrium and the resulting eigenclock is not sufficiently nuisance-robust.

## What changed from v0.2

v0.2 followed local mutual-induction directions and clock ansatzes. v0.3 instead builds

1. the full temporal two-filament Biot–Savart RHS;
2. the best rigid translation + rotation of the base state;
3. a central-difference temporal Jacobian in the co-rigid frame;
4. a pre-registered `m=1` Kelvin subspace: two helicities x common/differential channel parity;
5. a 4x4 projected dynamical generator;
6. its counter-propagating eigenmode doublet;
7. an eigenmode-defined Floquet clock;
8. a post-hoc alpha benchmark only after H0-H12 have been archived.

No `dt = ds/U` ansatz is used.

## Primary blind observable

Let the selected projected eigenvalues be

```text
lambda_plus  = sigma_plus  + i omega_plus
lambda_minus = sigma_minus - i omega_minus
```

with `omega_plus, omega_minus > 0`. The clock is defined symmetrically by the doublet itself:

```text
omega_clock = (omega_plus + omega_minus)/2
T_clock     = 2*pi/omega_clock
mu_plus     = exp(lambda_plus  * T_clock)
mu_minus    = exp(lambda_minus * T_clock)
h_F         = arg(mu_plus * mu_minus)/(2*pi)  mod 1
```

The canonical signed `h_F` is the primary result. `-abs(h_F)` is reported only as a parity-even diagnostic and cannot rescue a failed signed primary.

## Hard caveat: Floquet eligibility

A frozen Jacobian gives a genuine global Floquet monodromy only if the base state is a relative equilibrium or lies on a periodic orbit. v0.3 therefore fits

```text
u_i = V + Omega x (x_i - x_c) + residual_i
```

and gates the relative RMS residual.

For the canonical `3:1:1` counter-pulley geometry:

```text
relative_equilibrium_residual = 0.9989498433
full threshold                = 0.15
H3                            = FAIL
```

Thus the current eigenvalues are scientifically usable as a **frozen local spectrum**, but not as a demonstrated global Floquet spectrum.

## Reference full-native result

Canonical full run: `N=2048`, `offset/D=0.5`, `eps/D=0.05`.

```text
h_F signed                     = -0.1436561389 turns
|Re lambda+|/|Im lambda+|      = 0.0075824080
|Re lambda-|/|Im lambda-|      = 0.2626644724
relative-equilibrium residual  = 0.9989498433
```

The phase does **not** collapse to the v0.2 ribbon result:

```text
v0.3 dynamic phase at N=1024  = -0.1311765177 turns
v0.2 director holonomy         = +0.4179999745 turns
Tw = Lk - Wr                   = +0.4179161061 turns
```

So H12 passes: this is a genuinely different observable.

## The false-positive trap

The alpha benchmark remains closed while the resolution ladder is generated:

| N | blind h_F [turns] |
|---:|---:|
| 256 | -0.0422727494 |
| 384 | see reference CSV |
| 512 | -0.0942061748 |
| 768 | -0.1197034353 |
| 1024 | -0.1311765177 |
| 1536 | -0.1402860038 |
| 2048 | -0.1436561389 |

Only after this archive exists is alpha opened. `N=768` happens to lie close to the required correction, but the converged ladder moves away from it. The post-hoc benchmark therefore records it as a **preconverged near-hit**, not evidence.

## H0-H13 gates

| Gate | Purpose | Full reference |
|---|---|---|
| H0 | alpha absent from blind solver | PASS |
| H1 | native/Python temporal RHS + phase parity | PASS |
| H2 | geometry / Kelvin-subspace / phase consistency | PASS |
| H3 | relative-equilibrium eligibility | **FAIL** |
| H4 | Euclidean invariance | PASS |
| H5 | uniform scale collapse | PASS |
| H6 | transverse-basis gauge invariance | PASS |
| H7 | circulation-reversal covariance | PASS |
| H8 | finite-difference stability | PASS |
| H9 | resolution convergence | PASS |
| H10 | core + physical channel-orientation robustness | **FAIL** |
| H11 | both counter-propagating modes predominantly oscillatory | **FAIL** |
| H12 | dynamic phase does not collapse to `Tw` / v0.2 holonomy | PASS |
| H13 | post-hoc parameter-free alpha hit | **FAIL** |

Blind verdict:

```text
NO_RELATIVE_EQUILIBRIUM__FROZEN_SPECTRUM_ONLY
```

Post-hoc verdict:

```text
FALSIFIED_OR_UNSUPPORTED_BEFORE_ALPHA_MATCH_CAN_COUNT
```

## Windows usage

```bat
install_requirements.cmd
native_preflight.cmd
run_quick.cmd
run_full.cmd
```

For the strict separation protocol:

```bat
run_blind_then_benchmark.cmd
```

This first writes `blind_audit_summary.json`; only the second process imports `benchmark.py`.

`requirements.txt` explicitly includes `setuptools>=70`, `pybind11`, `wheel`, `numpy`, and `pytest`.

## Main outputs

```text
audit_out_full/
  blind_canonical.json
  blind_audit_summary.json
  resolution_convergence.csv
  finite_difference_sweep.csv
  regularization_sweep.csv
  channel_phase_sweep.csv
  basis_gauge_sweep.csv
  posthoc_alpha_benchmark.json
  audit_summary.json
```

## Interpretation

v0.3 does **not** falsify the general idea that vortex eigenmodes can define a dimensionless coupling phase. It falsifies/blocks the present minimal construction at three earlier levels:

- the assumed double-trefoil is not a relative equilibrium;
- the phase is strongly dependent on regularisation and physical cross-section orientation;
- one member of the selected counter-propagating doublet has substantial growth/decay compared with its oscillation frequency.

The next scientifically clean route is therefore **not** another alpha scan. It is to solve for a genuine relative equilibrium / relative periodic `+Gamma/-Gamma` trefoil pair first, then integrate the variational equations along that base orbit to obtain a true time-ordered monodromy matrix.

See `docs/THEORY_AND_GATES.md` and `CONCLUSIONS.md`.
