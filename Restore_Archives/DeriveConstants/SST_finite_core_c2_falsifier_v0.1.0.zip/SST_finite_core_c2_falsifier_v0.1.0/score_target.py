#!/usr/bin/env python3
"""External, post-derivation scoring stage.

The target values live only here. This file is intentionally excluded from the
blind provenance scan. A match is not a proof: convergence, robustness and
scientific-input provenance must also pass.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

TARGET_C2 = 0.231978
TARGET_SIGMA = 3.711655


def rel_error(value: float, target: float) -> float:
    return abs(value - target) / abs(target)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", default="outputs/blind_result.json")
    ap.add_argument("--campaign", default=None, help="Optional campaign_summary.json for convergence/robustness gates.")
    ap.add_argument("--relative-tolerance", type=float, default=5.0e-3, help="Default 0.5 percent preregistered target band.")
    ap.add_argument("--output", default="outputs/scored_result.json")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    in_path = (root / args.input).resolve() if not Path(args.input).is_absolute() else Path(args.input)
    out_path = (root / args.output).resolve() if not Path(args.output).is_absolute() else Path(args.output)
    data = json.loads(in_path.read_text(encoding="utf-8"))
    c2 = float(data["closure"]["c2"])
    sigma = float(data["closure"]["sigma"])

    gates = {
        "blind_provenance": bool(data.get("provenance", {}).get("pass", False)),
        "profile_solver": bool(data.get("profile", {}).get("success", False)),
        "scientific_input": data.get("derivation_quality") == "scientific_input",
        "c2_target": rel_error(c2, TARGET_C2) <= args.relative_tolerance,
        "sigma_target": rel_error(sigma, TARGET_SIGMA) <= args.relative_tolerance,
    }
    campaign_data = None
    if args.campaign:
        campaign_path = (root / args.campaign).resolve() if not Path(args.campaign).is_absolute() else Path(args.campaign)
        campaign_data = json.loads(campaign_path.read_text(encoding="utf-8"))
        gates["grid_convergence"] = bool(campaign_data["gates"]["grid_convergence"])
        gates["branch_robustness"] = bool(campaign_data["gates"]["branch_robustness"])
        gates["no_target_tuning"] = bool(campaign_data["gates"]["no_target_tuning"])
    else:
        gates["grid_convergence"] = False
        gates["branch_robustness"] = False
        gates["no_target_tuning"] = True

    target_match = gates["c2_target"] and gates["sigma_target"]
    methodological = all(gates[k] for k in ["blind_provenance", "profile_solver", "scientific_input", "grid_convergence", "branch_robustness", "no_target_tuning"])
    if methodological and target_match:
        verdict = "CANDIDATE_SURVIVES_PREREGISTERED_FALSIFIER"
    elif not target_match:
        verdict = "TARGET_CLOSURE_FALSIFIED_FOR_DECLARED_MODEL"
    else:
        verdict = "INCONCLUSIVE_METHOD_GATES_FAILED"

    scored = {
        "verdict": verdict,
        "targets": {"c2": TARGET_C2, "sigma": TARGET_SIGMA, "relative_tolerance": args.relative_tolerance},
        "derived": {"c2": c2, "sigma": sigma},
        "relative_errors": {"c2": rel_error(c2, TARGET_C2), "sigma": rel_error(sigma, TARGET_SIGMA)},
        "gates": gates,
        "important_note": "A surviving candidate is not a derivation of an electromagnetic constant; it only survives this preregistered coefficient test.",
    }
    if campaign_data is not None:
        scored["campaign"] = campaign_data
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(scored, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(scored, indent=2))
    return 0 if verdict == "CANDIDATE_SURVIVES_PREREGISTERED_FALSIFIER" else 1


if __name__ == "__main__":
    raise SystemExit(main())
