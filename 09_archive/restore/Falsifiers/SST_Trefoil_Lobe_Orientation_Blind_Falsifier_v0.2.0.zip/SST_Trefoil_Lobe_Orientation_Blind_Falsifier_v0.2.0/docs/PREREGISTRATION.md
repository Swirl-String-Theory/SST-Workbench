# v0.2.0 preregistration

## Primary hypothesis

The mutually tilted lobes of a trefoil produce orientation-dependent non-local finite-core Biot–Savart interactions. The test separates three statements that must not be conflated:

1. a close cross-lobe pair can be locally separating;
2. separating motion can be coherent across multiple contacts/lobe pairs;
3. the cross-lobe interaction can stabilize the reduced trefoil eigenmodes.

## Blinding

Input source identity is mapped to `B01/B02` before analysis. Pre-unblind hashes, analyses, scores, circle nulls and the campaign verdict are written before `unblind_manifest.json`.

## Geometry preprocessing

Both curves are uniformly resampled by arclength, centered and normalized to total centerline length \(2\pi\). The finite core is resolved as the configured fraction of the blind tube-thickness estimate.

## Reduced modes

The six real modes are

```text
tilt_0, tilt_1, tilt_2,
breathe_0, breathe_1, breathe_2
```

where index `0` is the three-lobe symmetric pattern and `1/2` span the real two-dimensional `E` representation of the three-lobe pattern.

## Jacobian decomposition

Symmetric finite differences generate

\[
J=J_{\rm local}+J_{\rm same}+J_{\rm cross}+J_{\rm transition}.
\]

For right/left eigenvectors \(Jv_k=\lambda_kv_k\) and \(w_k^\dagger J=\lambda_k w_k^\dagger\), v0.2.0 reports

\[
\lambda_k^{(c)}=
\frac{w_k^\dagger J_c v_k}{w_k^\dagger v_k},
\qquad
\sum_c\lambda_k^{(c)}=\lambda_k
\]

up to numerical roundoff.

## Critical gates retained from v0.1

- `G0_numerical_sanity`
- `G2_reduced_stability`
- `G3_cross_lobe_stabilizes`
- `G4_nearest_pair_cross_separates`
- `G6_ringdown_bounded`

Overall campaign PASS requires both source representations to pass these gates and the circle nulls. Diagnostic gates do not alter this rule.

## Added diagnostic gates

### G7 — curvature-matched orientation specificity
At least the configured number of scramble controls must satisfy the curvature-signature match tolerance, and their median reduced growth must exceed the seed by the preregistered delta.

### G8 — coherent cross-lobe repulsion
Requires the configured fraction of distinct close cross-lobe contacts to have positive cross-lobe separation rate, positive median rate, and the configured fraction of the three lobe-centroid pairs to separate.

### G9 — dominant-mode cross-lobe stabilization
The normalized real cross-lobe contribution to the dominant reduced eigenvalue must be at most the configured negative stabilization threshold.

### G10 — C3 sector localization
The dominant eigenvector must have the configured minimum participation in one of `m0/E_tilt/E_breathe`, while the `m0` versus `E` off-block Jacobian leakage remains below threshold.

### G11 — linear/nonlinear causal consistency
A short counterfactual evolution with and without cross-lobe induction must order early reduced-mode growth with the same sign as the modal cross-lobe eigenvalue contribution.

## Nulls and prohibited mechanisms

The circular unknot null must not develop artificial mean radial collapse. No explicit reconnection, topology editing, contact penalty, hard-core bounce, or hand-written restoring force is allowed.
