from __future__ import annotations
import argparse, json, numpy as np
from sst_thread_falsifier.native_ext import fallback
from sst_thread_falsifier.native_ext.core import biot_savart, segment_biot_savart, backend_name
from sst_thread_falsifier.geometry import kabsch_rms, radius_gyration
from sst_thread_falsifier.thread_bundles import local_source_closed_bundle, closure_diagnostics, minimum_clearance
from sst_thread_falsifier.integrator import integrate_rk4


def trefoil(n=96):
    t=np.linspace(0,2*np.pi,n,endpoint=False)
    return np.c_[np.sin(t)+2*np.sin(2*t),np.cos(t)-2*np.cos(2*t),-np.sin(3*t)].astype(float)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--require-native",action="store_true"); ap.add_argument("--force-python",action="store_true"); ap.add_argument("--tol",type=float,default=2e-9); a=ap.parse_args()
    P=trefoil(); O=np.array([0,len(P)],dtype=np.int64); rg=radius_gyration(P); c=P.mean(axis=0); kc=0.10*rg
    py=fallback.biot_savart(P,O,1.0,kc); got=biot_savart(P,O,1.0,kc,force_python=a.force_python,skip_build=True)
    rel_self=float(np.linalg.norm(got-py)/max(np.linalg.norm(py),1e-15))
    bundle=local_source_closed_bundle(c,rg,[0.2,-0.3,1.0],12.0,4,3.5,5.0,32.0,0.35,phase=0.17,radial=True)
    V,BO,BG,_=bundle; pyb=fallback.segment_biot_savart(P,V,BO,BG,1e-5*rg); gotb=segment_biot_savart(P,V,BO,BG,1e-5*rg,force_python=a.force_python,skip_build=True)
    rel_bg=float(np.linalg.norm(gotb-pyb)/max(np.linalg.norm(pyb),1e-15))
    close=closure_diagnostics(V,BO,BG); clearance=minimum_clearance(P,V,BO)/rg
    u0=1.0/(4*np.pi*rg); T=0.008*rg/u0; ns=2; dt=T/ns; U=0.75*u0*np.array([0.31,-0.27,0.19]); U=U/np.linalg.norm(U)*0.75*u0
    z=np.zeros(3)
    A,_=integrate_rk4(P,O,1.0,kc,V,BO,BG,1e-5*rg,z,dt,ns,force_python=a.force_python,skip_build=True,record=False)
    B,_=integrate_rk4(P,O,1.0,kc,V,BO,BG,1e-5*rg,U,dt,ns,force_python=a.force_python,skip_build=True,record=False)
    boost=kabsch_rms(A,B)/rg
    be="python" if a.force_python else backend_name(); ok=(rel_self<=a.tol and rel_bg<=a.tol and boost<=a.tol and close["max_closure_vector_norm_over_length"]<=1e-12 and clearance>0.05 and (be=="cpp" or not a.require_native))
    print(json.dumps({"backend":be,"self_kernel_cpp_vs_python_relative_l2":rel_self,"segment_kernel_cpp_vs_python_relative_l2":rel_bg,"multistep_common_boost_shape_rms_over_rg":boost,"closed_filament_residual":close["max_closure_vector_norm_over_length"],"initial_thread_clearance_over_rg":clearance,"tol":a.tol,"status":"PASS" if ok else "FAIL"},indent=2))
    raise SystemExit(0 if ok else 1)
if __name__=="__main__": main()
