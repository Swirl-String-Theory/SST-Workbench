"""Public data acquisition. Nothing is fabricated if a download fails."""
from pathlib import Path
import hashlib,json,urllib.request,urllib.parse,time
ROOT=Path(__file__).resolve().parents[1];DEST=ROOT/'data/raw';DEST.mkdir(parents=True,exist_ok=True)
# Zenodo file digest from deposited manifest on record 22657608
SOURCES={
 'center_beat_frequencies.csv':'08500cc229bd6f70bfeeae31c06aff48',
 'allan_T20s.csv':'d0d264149e6790be22173238db8b9a24',
 'allan_T30min.csv':'b90f639a23b0b9182254fc89d56e88bf',
 'extracted_amplitudes.csv':'6d8218659e97f2bea4bfa89f6573faec',
 'detection_threshold_MC.csv':'1e9d64c66d7a3e68a358242df3f1a137',
 '95_confidence_level.csv':'2807fe606733b6c34c2d1c6182eb9c13',
}
def retrieve(url,path,expected_md5=None):
    req=urllib.request.Request(url,headers={'User-Agent':'A061-research-reproduction/0.1.0'})
    with urllib.request.urlopen(req,timeout=30) as fh:content=fh.read()
    checksum=hashlib.md5(content).hexdigest()
    if expected_md5 and checksum!=expected_md5:raise ValueError(f'md5 mismatch {path.name}: {checksum} != {expected_md5}')
    tmp=path.with_name(path.name+'.part');tmp.write_bytes(content);tmp.replace(path)
    return {'path':str(path),'size':len(content),'md5':checksum,'sha256':hashlib.sha256(content).hexdigest(),'url':url}
def main():
    registry=[];failure=[]
    for name,digest in SOURCES.items():
      try:
        path=DEST/name
        if path.exists() and hashlib.md5(path.read_bytes()).hexdigest()==digest:
          registry.append({'path':str(path),'md5':digest,'existing':True});continue
        url='https://zenodo.org/records/22657608/files/'+urllib.parse.quote(name)+'?download=1'
        registry.append(retrieve(url,path,digest))
      except Exception as e:failure.append({'source':name,'error':str(e)})
    try:
       req=urllib.request.Request('https://api.figshare.com/v2/articles/33386191',headers={'User-Agent':'A061-research-reproduction/0.1.0'})
       with urllib.request.urlopen(req,timeout=30) as f:metadata=json.load(f)
       for entry in metadata.get('files',[]):
          name=str(entry['name']).replace('\\','_').replace('/','_')
          if not name or name.startswith('.'):continue
          path=DEST/'huang_figshare'/name;path.parent.mkdir(exist_ok=True)
          try:
             url=entry.get('download_url') or f"https://api.figshare.com/v2/file/download/{entry['id']}"
             registry.append(retrieve(url,path,entry.get('supplied_md5') or entry.get('computed_md5')))
          except Exception as e:failure.append({'source':'huang_figshare/'+name,'error':str(e)})
    except Exception as e:failure.append({'source':'huang_figshare_index','error':str(e)})
    path=ROOT/'data/raw/DOWNLOAD_PROVENANCE.json';path.write_text(json.dumps({'files':registry,'failed':failure},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':len(registry),'failures':failure},indent=2))
    if failure:raise SystemExit(3)
if __name__=='__main__':main()
