import argparse
from sst_knot_state_algebra.reveal import reveal
p=argparse.ArgumentParser();p.add_argument("blind_out");p.add_argument("private_json");a=p.parse_args();reveal(a.blind_out,a.private_json)
