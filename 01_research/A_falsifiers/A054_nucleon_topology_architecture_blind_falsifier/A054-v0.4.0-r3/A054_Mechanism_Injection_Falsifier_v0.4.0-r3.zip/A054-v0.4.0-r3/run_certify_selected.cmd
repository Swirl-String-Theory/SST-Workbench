@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "ROOT=%%~fI"
set "WB=%~1"
if "%WB%"=="" if not "%SST_WORKBENCH_ROOT%"=="" set "WB=%SST_WORKBENCH_ROOT%"
if "%WB%"=="" set "WB=C:\workspace\projects\SST-Workbench"
set "PY=%WB%\.venvs\A054-v0.4.0-r3\Scripts\python.exe"
call "%ROOT%\run_00_setup.cmd" "%WB%"
if errorlevel 1 exit /b 30
"%PY%" "%ROOT%\tools\certify_selected.py" --root "%ROOT%"
if errorlevel 1 exit /b 31
set "SST_FALSIFIER_FRAMEWORK_ROOT=%WB%\06_templates\SST_Falsifier_Framework\SST_Falsifier_Framework_v1.0.4"
"%PY%" "%ROOT%\run_instance.py" CERTIFY
if errorlevel 1 exit /b 32
exit /b 0
