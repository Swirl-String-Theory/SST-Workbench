# A055 v0.3.0 — compound bridge reveal

A054 v0.2.x provides the authoritative three-component finite-core dynamics.
A055 supplies the single-knot control branch and blind/reveal bridge.

## Architecture contrasts
- U: Q0 CP=1.0, 2+1 CP=1.0, 2+1 Kelvin-CP=1.0, RPO=0.0
- G: Q0 CP=1.0, 2+1 CP=1.0, 2+1 Kelvin-CP=1.0, RPO=0.0
- B: Q0 CP=1.0, 2+1 CP=1.0, 2+1 Kelvin-CP=1.0, RPO=0.0

## Working historical hypotheses (reveal-only)
- proton-like G(5_2,5_2,6_1), 6_1 opposed: {'n': 12, 'counterpropagating_symmetric_fraction': 1.0, 'kelvin_counterpropagating_symmetric_fraction': 1.0, 'certified_fraction': 0.0, 'rpo_fraction': 0.0, 'floquet_evaluated_fraction': 0.0, 'median_normalized_growth': 0.2248696083514254}
- neutron-like B(5_2,6_1,6_1), 6_1 opposed: {'n': 24, 'counterpropagating_symmetric_fraction': 1.0, 'kelvin_counterpropagating_symmetric_fraction': 1.0, 'certified_fraction': 0.0, 'rpo_fraction': 0.0, 'floquet_evaluated_fraction': 0.0, 'median_normalized_growth': 0.21274520440668415}

No particle identity is established by this bridge alone.
