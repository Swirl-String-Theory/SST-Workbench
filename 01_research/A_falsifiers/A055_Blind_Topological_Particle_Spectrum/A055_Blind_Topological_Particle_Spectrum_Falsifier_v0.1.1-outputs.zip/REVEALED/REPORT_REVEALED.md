# A055 v0.1.1 — REVEALED report

Blind seal verified: `79a83c25cad79fe2ad4a2e59159b936328e170e90d0ddc5b1dc921bee891bd2e`.

## Historical VAM/SST quark check

Historical mapping: `u -> 5_2`, `d -> 6_1` (twist-knot pair).

- Raw diagnostic knot-space rank: **416/595** (fraction 0.699160).
- Raw diagnostic distance: **2.70268006**.
- The historical pair did **not** jointly pass all v0.1.1 knot-space feature gates; no qualified rank is assigned.

Unlike v0.1.0, the scientific rank is withheld if either topology fails the preregistered resolution/CV gates.

## Exploratory SM mass-pattern reveal

- **charged_leptons**: no valid common all-atlas triplet survived feature qualification.
- **up_quarks**: no valid common all-atlas triplet survived feature qualification.
- **down_quarks**: no valid common all-atlas triplet survived feature qualification.
- **massive_EW_Higgs**: no valid common all-atlas triplet survived feature qualification.

Each valid search uses **10000** null targets at the same total log-mass span.  The intermediate log-position is randomized and the complete eligible triplet search is repeated analytically through the exact lower envelope of candidate error quadratics.  Full null values are stored in `SM_NULL_DISTRIBUTIONS.csv.gz`.

## v0.1.1 domain corrections

- `linking_strength` is **links only**. Knot values are never replaced by `1e-6` or any other artificial floor.
- `abs_writhe` is not used in mixed knot/link fits.
- `contact_ratio` is diagnostic only because it scales explicitly with segment resolution.
- `min_distance` after common length normalization replaces it as the contact observable.
- Zero/non-positive values required by a logarithmic ratio fit are excluded, not shifted.

## Mandatory interpretation limits

1. v0.1.1 does **not** identify a knot/link with an SM particle.
2. PD-derived embeddings are presentation ensembles, not PKLSA ideal/relaxed vortex equilibria.
3. Higgs spin-0/scalar dynamics, gauge charge, color, chirality, weak isospin, lifetime and couplings are **not tested**.
4. Quark masses are scheme/scale dependent; their reveal remains diagnostic only.
5. Promotion to v0.2.0 requires PKLSA/finite-core dynamical observables under the same blind/domain/convergence protocol.
