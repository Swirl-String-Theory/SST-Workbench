#!/usr/bin/env python3
"""
SST relational-clock pre-canonisation check suite.

Runs the six blocking checks defined in the audit of
"Testing the problem of time with cold atoms" (Barontini, PRR 8, L022047, 2026)
as a candidate SST research-track import.

Usage
-----
    python main.py                       # standard profile, all checks
    python main.py --profile quick       # fast smoke run
    python main.py --profile full        # high resolution
    python main.py --checks 2 3          # subset
    python main.py --no-plots --out res/

Exit code is 0 on completion regardless of verdict: this suite reports, it
does not adjudicate.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sstrc import checks, dyn  # noqa: E402
from sstrc.report import write_report  # noqa: E402

PROFILES = {
    "quick": dict(N=64, steps=400, sample_every=10, n_runs=6, K_null=200, cfl=0.06),
    "standard": dict(N=96, steps=1500, sample_every=15, n_runs=10, K_null=500, cfl=0.05),
    "full": dict(N=160, steps=5000, sample_every=25, n_runs=16, K_null=2000, cfl=0.03),
}


def jsonable(o):
    if isinstance(o, dict):
        return {k: jsonable(v) for k, v in o.items() if not str(k).startswith("_")}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, float) and not np.isfinite(o):
        return None
    return o


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile", choices=list(PROFILES), default="standard")
    ap.add_argument("--checks", nargs="*", type=int, default=[1, 2, 3, 4, 5, 6])
    ap.add_argument("--out", default="results")
    ap.add_argument("--no-plots", action="store_true")
    ap.add_argument("--a", type=float, default=0.05,
                    help="declared regularisation / core radius (reduced units)")
    ap.add_argument("--v-floor", type=float, default=0.0,
                    help="declared velocity floor (0 = disabled)")
    ap.add_argument("--seed", type=int, default=20260805)
    ap.add_argument("--n-star", type=int, default=6,
                    help="bright/dark spectral cutoff (number of bright modes)")
    args = ap.parse_args()

    P = PROFILES[args.profile]
    os.makedirs(args.out, exist_ok=True)
    plotdir = None if args.no_plots else os.path.join(args.out, "figures")

    cfg = dyn.SolverConfig(
        a=args.a, N=P["N"], steps=P["steps"], sample_every=P["sample_every"],
        cfl=P["cfl"], v_floor=args.v_floor,
    )

    banner = f"""
================================================================================
 SST relational-clock pre-canonisation checks
 profile={args.profile}  N={cfg.N}  steps={cfg.steps}  a={cfg.a}  v_floor={cfg.v_floor}
 seed={args.seed}  bright modes n*={args.n_star}
 DECLARED: reduced units (Gamma=1). SST units enter only via clock prefactors.
================================================================================
"""
    print(banner)

    results = {
        "meta": {
            "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
            "python": platform.python_version(),
            "numpy": np.__version__,
            "platform": platform.platform(),
            "profile": args.profile,
            "solver_config": {k: v for k, v in cfg.__dict__.items()},
            "seed": args.seed,
            "n_runs": P["n_runs"],
            "K_null": P["K_null"],
            "n_star": args.n_star,
        }
    }

    order = [
        (6, "constant chain / CODATA hygiene",
         lambda: checks.check6_constants()),
        (2, "helicity conservation on a material tube",
         lambda: checks.check2_helicity(cfg, plotdir=plotdir)),
        (3, "cutoff scan of the enstrophy clock",
         lambda: checks.check3_cutoff(cfg, plotdir=plotdir)),
        (4, "mode-basis robustness",
         lambda: checks.check4_basis(cfg, n_runs=P["n_runs"], n_star=args.n_star,
                                     seed=args.seed + 3, plotdir=plotdir)),
        (5, "Loschmidt reversal",
         lambda: checks.check5_loschmidt(cfg, n_star=args.n_star, plotdir=plotdir)),
        (1, "null-model benchmark (BLOCKING)",
         lambda: checks.check1_null_model(cfg, n_runs=P["n_runs"], n_star=args.n_star,
                                          K_null=P["K_null"], seed=args.seed,
                                          plotdir=plotdir)),
    ]

    for num, title, fn in order:
        if num not in args.checks:
            continue
        t0 = time.time()
        print(f"[check {num}] {title} ...", flush=True)
        try:
            r = fn()
            r["_elapsed_s"] = round(time.time() - t0, 2)
            results[f"check{num}"] = r
            print(f"    -> {r.get('verdict', '(no verdict)')}")
        except Exception as exc:  # keep the suite running
            import traceback
            results[f"check{num}"] = {"error": repr(exc),
                                      "traceback": traceback.format_exc()}
            print(f"    !! FAILED: {exc!r}")
        print(f"    ({time.time() - t0:.1f} s)\n", flush=True)

    jpath = os.path.join(args.out, "results.json")
    with open(jpath, "w", encoding="utf-8") as f:
        json.dump(jsonable(results), f, indent=2)
    rpath = write_report(jsonable(results), args.out)

    print("=" * 80)
    print(f"JSON   : {jpath}")
    print(f"REPORT : {rpath}")
    if plotdir:
        print(f"FIGURES: {plotdir}")
    print("=" * 80)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
