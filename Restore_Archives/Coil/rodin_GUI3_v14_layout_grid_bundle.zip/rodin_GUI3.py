#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rodin_GUI3.py

Version v13: uses v11 clean side-nav; adds sub-cell micro phase offsets and Saw/Rodin/Starship CW+CCW phase families.

Merged coil GUI for Rodin / SawShape / Starship experiments.

Fuses the intent of:
- rodin_GUI.py   : 3-phase Rodin torus-knot CW/CCW families, p/q cells, gap, Biot-Savart grid.
- rodin_GUI2.py  : generic coil presets, cached Biot-Savart, heatmap/quiver style controls.
- GUI-SawBowl.py : Straight/Curved SawShape + Straight/Curved Starship with bowl profile sliders.

Presets included:
- Solenoide
- Toroid
- Enkele winding
- Helmholtz
- Rodin-knot
- Rodin 3-phase CW/CCW
- Straight SawShape
- Curved SawShape
- Straight Starship
- Curved Starship

Exports:
- Save PNG of current view
- Export coil centerlines to CSV for external Fourier checks

Dependencies:
    pip install numpy matplotlib

Units:
- Generic coils use meters.
- Rodin 3-phase controls expose major diameter in cm and minor radius/gap in mm/cm as labelled.
- SawShape/Starship shape sliders are in mm and internally converted to meters.
"""

from __future__ import annotations

import csv
import math
import os
import time
import importlib
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize

MU0_4PI = 1e-7  # mu0/(4*pi)

Coil = Tuple[np.ndarray, str, str, str, float]  # pts, color, linestyle, label, current multiplier


# =============================================================================
# GUI helpers
# =============================================================================
class ScrollableFrame(ttk.Frame):
    def __init__(self, parent, width=460):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, borderwidth=0, highlightthickness=0, width=width)
        self.vscroll = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vscroll.set)
        self.inner = ttk.Frame(self.canvas)
        self.inner_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vscroll.pack(side="right", fill="y")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.inner_id, width=e.width))
        self._bind_mousewheel(self.canvas)
        self._bind_mousewheel(self.inner)

    def _bind_mousewheel(self, widget):
        widget.bind("<Enter>", lambda e: self._activate_mousewheel())
        widget.bind("<Leave>", lambda e: self._deactivate_mousewheel())

    def _activate_mousewheel(self):
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.canvas.bind_all("<Button-4>", self._on_mousewheel_linux)
        self.canvas.bind_all("<Button-5>", self._on_mousewheel_linux)

    def _deactivate_mousewheel(self):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-event.delta / 120), "units")

    def _on_mousewheel_linux(self, event):
        self.canvas.yview_scroll(-1 if event.num == 4 else 1, "units")


class CollapsibleSection(ttk.Frame):
    def __init__(self, parent, title, initially_open=True):
        super().__init__(parent)
        self._open = tk.BooleanVar(value=initially_open)
        header = ttk.Frame(self)
        header.pack(fill=tk.X)
        self.btn = ttk.Button(header, width=2, command=self.toggle)
        self.btn.pack(side=tk.LEFT)
        ttk.Label(header, text=title, font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT, padx=(6, 0))
        self.body = ttk.Frame(self)
        self.body.pack(fill=tk.X, pady=(4, 8))
        self._refresh()

    def toggle(self):
        self._open.set(not self._open.get())
        self._refresh()

    def _refresh(self):
        if self._open.get():
            self.btn.configure(text="▼")
            self.body.pack(fill=tk.X, pady=(4, 8))
        else:
            self.btn.configure(text="►")
            self.body.forget()


@dataclass
class Grid3D:
    x: np.ndarray
    y: np.ndarray
    z: np.ndarray
    X: np.ndarray
    Y: np.ndarray
    Z: np.ndarray


def make_grid(bounds: float, res: int) -> Grid3D:
    x = np.linspace(-bounds, bounds, res)
    y = np.linspace(-bounds, bounds, res)
    z = np.linspace(-bounds, bounds, res)
    X, Y, Z = np.meshgrid(x, y, z, indexing="ij")
    return Grid3D(x=x, y=y, z=z, X=X, Y=Y, Z=Z)


def finite_polyline(points: np.ndarray) -> np.ndarray:
    pts = np.asarray(points, dtype=float)
    pts = pts[np.all(np.isfinite(pts), axis=1)]
    if len(pts) < 2:
        return np.zeros((0, 3), dtype=float)
    return pts


def try_import_sstcore():
    """Return SSTcore/sstcore module if a compiled binding is importable.

    The GUI uses only the wire-grid field kernel when available:
    ``biot_savart_wire_grid(X,Y,Z,wire_points,current)``.
    That kernel is segment-based and does not auto-close the polyline, so it is
    the correct SSTcore backend for open or guided coil centerlines.
    """
    for name in ("SSTcore", "sstcore"):
        try:
            return importlib.import_module(name)
        except Exception:
            pass
    return None


def biot_savart_wire_grid_sstcore(module, grid: Grid3D, polyline: np.ndarray, current: float):
    """Fast C++ backend via SSTcore.field_kernels.

    Important unit convention: SSTcore's field kernel uses mu0=1 internally
    and applies current/(4*pi). To reproduce SI Tesla from our NumPy kernel
    mu0*I/(4*pi), we pass current_core = mu0 * I.

    The current SSTcore field kernel has only an epsilon singularity guard, not
    the configurable GUI softening radius. Use the NumPy backend when you need
    softened near-wire fields for very close probe grids.
    """
    pts = np.ascontiguousarray(finite_polyline(polyline), dtype=float)
    if pts.shape[0] < 2 or abs(current) < 1e-30:
        z = np.zeros_like(grid.X, dtype=np.float64)
        return z.copy(), z.copy(), z.copy()
    if module is None or not hasattr(module, "biot_savart_wire_grid"):
        raise AttributeError("SSTcore backend has no biot_savart_wire_grid")

    current_core = (4.0 * math.pi * MU0_4PI) * float(current)  # mu0 * I
    bx, by, bz = module.biot_savart_wire_grid(
        np.ascontiguousarray(grid.X, dtype=float),
        np.ascontiguousarray(grid.Y, dtype=float),
        np.ascontiguousarray(grid.Z, dtype=float),
        pts,
        current_core,
    )
    return np.asarray(bx, dtype=float).reshape(grid.X.shape), \
           np.asarray(by, dtype=float).reshape(grid.X.shape), \
           np.asarray(bz, dtype=float).reshape(grid.X.shape)


# =============================================================================
# Coil geometry: generic coils
# =============================================================================
def torus_knot_polyline(R_major: float, r_minor: float, p: int, q: int, turns: int, n_points: int,
                        mirror: bool = False, theta_offset: float = 0.0, z_offset: float = 0.0) -> np.ndarray:
    p = int(max(1, p))
    q = int(max(1, q))
    turns = int(max(1, turns))
    n_points = int(max(200, n_points))
    t = np.linspace(0.0, 2.0 * np.pi * turns, n_points, endpoint=True)
    theta = p * t + theta_offset
    phi = q * t
    if mirror:
        phi = -phi
    x = (R_major + r_minor * np.cos(phi)) * np.cos(theta)
    y = (R_major + r_minor * np.cos(phi)) * np.sin(theta)
    z = r_minor * np.sin(phi) + z_offset
    return np.column_stack([x, y, z])


def generic_wire_points(kind: str, N: int, R: float, L: float, pts: int, p_knot: int, q_knot: int, turns_knot: int) -> np.ndarray:
    k = kind.lower()
    pts = int(max(200, pts))
    N = int(max(1, N))

    if k == "enkele winding":
        t = np.linspace(0, 2*np.pi, pts, endpoint=True)
        return np.column_stack([R*np.cos(t), R*np.sin(t), 0*t])

    if k == "helmholtz":
        sep = np.clip(L/4.0, 0.2*R, 1.6*R)
        t = np.linspace(0, 2*np.pi, max(100, pts//2), endpoint=True)
        x = R*np.cos(t)
        y = R*np.sin(t)
        p1 = np.column_stack([x, y, np.full_like(t, -sep/2)])
        p2 = np.column_stack([x, y, np.full_like(t, +sep/2)])
        # NaN separator for export/plot safety is not used; separate coils are cleaner elsewhere.
        return np.vstack([p1, p2])

    if k == "toroid":
        r = max(1e-9, R)
        a = max(1.5*r, 0.6*L)
        u = np.linspace(0, 2*np.pi, pts, endpoint=True)
        v = N*u
        x = (a + r*np.cos(v)) * np.cos(u)
        y = (a + r*np.cos(v)) * np.sin(u)
        z = r*np.sin(v)
        return np.column_stack([x, y, z])

    if k == "rodin-knot":
        r_minor = max(1e-9, R)
        R_major = max(1.5*r_minor, 0.6*L)
        return torus_knot_polyline(R_major, r_minor, p_knot, q_knot, turns_knot, pts)

    # Solenoide default
    pts_per_turn = max(60, pts // max(1, N))
    n_total = N * pts_per_turn
    t = np.linspace(0, 2*np.pi*N, n_total, endpoint=True)
    z = np.linspace(-L/2, L/2, n_total, endpoint=True)
    x = R*np.cos(t)
    y = R*np.sin(t)
    return np.column_stack([x, y, z])


# =============================================================================
# Coil geometry: Rodin 3-phase CW/CCW from rodin_GUI.py
# =============================================================================
def torus_knot_cellphase_polyline(
    R_major: float,
    r_minor: float,
    p: int,
    q: int,
    n_points: int = 1200,
    turns: int = 1,
    cell_phase_frac: float = 0.0,
    mirror: bool = False,
    z_offset: float = 0.0,
    theta_offset: float = 0.0,
) -> np.ndarray:
    p = int(max(1, p))
    q = int(max(1, q))
    turns = int(max(1, turns))
    n_points = int(max(200, n_points))
    t = np.linspace(0.0, 2.0*np.pi*turns, n_points, endpoint=True)
    dt_cell = float(cell_phase_frac) * (2.0*np.pi / q)
    tp = t + dt_cell
    theta = p*tp + float(theta_offset)
    phi_t = q*tp
    if mirror:
        phi_t = -phi_t
    x = (R_major + r_minor*np.cos(phi_t)) * np.cos(theta)
    y = (R_major + r_minor*np.cos(phi_t)) * np.sin(theta)
    z = r_minor*np.sin(phi_t) + z_offset
    return np.column_stack([x, y, z])


def build_rodin_3phase(
    R_major: float,
    r_minor: float,
    p: int,
    q: int,
    phases: int,
    turns: int,
    points: int,
    separate_families: bool,
    gap: float,
    ccw_start_mode: str,
    phase_placement: str = "Global rotation + sub-cell offset",
    micro_mode: str = "Auto 360/(slots*phases)",
    micro_deg: float = 0.0,
) -> List[Coil]:
    """Build Rodin CW/CCW lane families.

    v13 phase rule:
    the visible phase angle is not only 0/120/240 deg. A small sub-cell
    offset is added per phase:

        theta_i = i * (360/phases + 360/(q*phases))

    for CW, and the negative of that for CCW/return. For p=5, q=12,
    phases=3 this gives phase micro offsets 0, +10, +20 degrees.

    The legacy cell-phase mode is retained for comparison, but can overlap
    because it reparameterizes the same closed torus knot.
    """
    phases = int(max(1, min(phases, 12)))
    q = int(max(1, q))
    z_cw = -gap/2.0 if separate_families else 0.0
    z_ccw = +gap/2.0 if separate_families else 0.0
    theta_offset_ccw = np.pi if str(ccw_start_mode).startswith("Opposite") else 0.0
    placement_l = str(phase_placement).lower()
    use_cell_phase = placement_l.startswith("cell")
    use_subcell = "sub-cell" in placement_l or "subcell" in placement_l or placement_l.startswith("global")
    colors_cw = ["crimson", "darkorange", "gold", "tomato", "sienna", "khaki", "salmon", "peru"]
    colors_ccw = ["royalblue", "navy", "teal", "deepskyblue", "slateblue", "cyan", "dodgerblue", "cadetblue"]
    coils: List[Coil] = []

    for i in range(phases):
        tag = phase_tag(i, upper=True)
        if use_cell_phase:
            cell_phase = i / phases
            theta_phase = 0.0
        else:
            cell_phase = 0.0
            if use_subcell:
                theta_phase = phase_angle_rad(i, phases, q, micro_mode, micro_deg, sign=+1.0)
            else:
                theta_phase = 2.0*np.pi*i/phases
        pts = torus_knot_cellphase_polyline(
            R_major, r_minor, p, q, points, turns,
            cell_phase, False, z_cw, theta_phase
        )
        coils.append((pts, colors_cw[i % len(colors_cw)], "-", f"{tag} CW", 1.0))

    for i in range(phases):
        tag = phase_tag(i, upper=False)
        if use_cell_phase:
            cell_phase = i / phases
            theta_phase = theta_offset_ccw
        else:
            cell_phase = 0.0
            if use_subcell:
                theta_phase = theta_offset_ccw + phase_angle_rad(i, phases, q, micro_mode, micro_deg, sign=-1.0)
            else:
                theta_phase = theta_offset_ccw - 2.0*np.pi*i/phases
        pts = torus_knot_cellphase_polyline(
            R_major, r_minor, p, q, points, turns,
            cell_phase, True, z_ccw, theta_phase
        )
        coils.append((pts, colors_ccw[i % len(colors_ccw)], "--", f"{tag} CCW", 1.0))
    return coils


# =============================================================================
# Coil geometry: SawShape and Starship from GUI-SawBowl.py
# =============================================================================
def alternating_skip_indices(S: int, step_fwd: int, step_bwd: int, n_pairs: int, start: int = 1) -> np.ndarray:
    idx = int(start)
    seq = [idx]
    for k in range(2*int(max(1, n_pairs))):
        if k % 2 == 0:
            idx = (idx + int(step_fwd) - 1) % int(S) + 1
        else:
            idx = (idx + int(step_bwd) - 1) % int(S) + 1
        seq.append(idx)
    return np.array(seq, dtype=int)


def r_profile(s: np.ndarray, Rb: float, Rt: float, profile: str, power: float) -> np.ndarray:
    profile = str(profile)
    if profile == "Exponential":
        return Rb + (Rt - Rb) * (s**power)
    if profile == "Inverse Exp":
        return Rt - (Rt - Rb) * (s**power)
    return Rb + (Rt - Rb) * s


def phase_micro_step_rad(slots: int, phases: int, mode: str, custom_deg: float) -> float:
    """Small lane offset inserted between discrete coil points.

    Auto mode implements the requested rule:

        micro = 360 deg / slots / phases

    Example: Rodin T(5,12), phases=3 -> 360/12/3 = 10 deg.
    Phase B gets +10 deg beyond its 120 deg base placement, phase C gets
    +20 deg. CCW/return families use the negative sign.
    """
    slots = int(max(1, slots))
    phases = int(max(1, phases))
    mode_l = str(mode).lower()
    if mode_l.startswith("off"):
        return 0.0
    if mode_l.startswith("custom"):
        return math.radians(float(custom_deg))
    return 2.0 * np.pi / (slots * phases)


def phase_angle_rad(i: int, phases: int, slots: int, mode: str, custom_deg: float, sign: float = +1.0) -> float:
    phases = int(max(1, phases))
    base = 2.0 * np.pi / phases
    micro = phase_micro_step_rad(slots, phases, mode, custom_deg)
    return float(sign) * int(i) * (base + micro)


def phase_tag(i: int, upper: bool = True) -> str:
    tags = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"]
    t = tags[int(i) % len(tags)]
    return t if upper else t.lower()


def build_sawshape_phase(seq: np.ndarray, S: int, Rb: float, Rt: float, spacing: float,
                         angle_offset: float, profile: str, power: float, curved: bool,
                         samples_per_seg: int) -> np.ndarray:
    slot_angles_base = np.linspace(0, 2*np.pi, int(S), endpoint=False) - np.pi/2.0
    N = len(seq) - 1
    s_nodes = np.linspace(0, 1, N+1)
    r_nodes = r_profile(s_nodes, Rb, Rt, profile, power)
    z_nodes = s_nodes * spacing
    if not curved:
        xyz = np.zeros((N+1, 3), dtype=float)
        for k in range(N+1):
            a = slot_angles_base[int(seq[k])-1] + angle_offset
            xyz[k, 0] = r_nodes[k] * np.cos(a)
            xyz[k, 1] = r_nodes[k] * np.sin(a)
            xyz[k, 2] = z_nodes[k]
        return xyz - np.array([0.0, 0.0, spacing/2.0])

    xs, ys, zs = [], [], []
    samples_per_seg = int(max(2, samples_per_seg))
    for k in range(N):
        i0, i1 = int(seq[k])-1, int(seq[k+1])-1
        a0 = slot_angles_base[i0] + angle_offset
        a1 = slot_angles_base[i1] + angle_offset
        da = (a1 - a0 + np.pi) % (2*np.pi) - np.pi
        a_line = a0 + np.linspace(0, 1, samples_per_seg, endpoint=False) * da
        r_line = np.linspace(r_nodes[k], r_nodes[k+1], samples_per_seg, endpoint=False)
        z_line = np.linspace(z_nodes[k], z_nodes[k+1], samples_per_seg, endpoint=False)
        xs.append(r_line*np.cos(a_line))
        ys.append(r_line*np.sin(a_line))
        zs.append(z_line)
    pts = np.column_stack([np.concatenate(xs), np.concatenate(ys), np.concatenate(zs)])
    return pts - np.array([0.0, 0.0, spacing/2.0])


def build_sawshape(S: int, step_fwd: int, step_bwd: int, n_pairs: int, Rb: float, Rt: float,
                   spacing: float, profile: str, power: float, curved: bool,
                   samples_per_seg: int, phases: int = 3, include_ccw: bool = True,
                   micro_mode: str = "Auto 360/(slots*phases)",
                   micro_deg: float = 0.0) -> List[Coil]:
    """Build SawShape with the same global phase logic as Rodin.

    CW phases use +phase angles. CCW/return phases are reversed polylines with
    negative phase angles, so their current direction is geometrically opposite.
    """
    phases = int(max(1, min(phases, 12)))
    S = int(max(3, S))
    seq = alternating_skip_indices(S, step_fwd, step_bwd, n_pairs, start=1)
    colors_cw = ["tab:purple", "tab:blue", "tab:green", "tab:red", "tab:orange", "tab:brown"]
    colors_ccw = ["indigo", "navy", "darkgreen", "maroon", "darkorange", "saddlebrown"]
    coils: List[Coil] = []
    for i in range(phases):
        ang = phase_angle_rad(i, phases, S, micro_mode, micro_deg, sign=+1.0)
        tag = phase_tag(i, upper=True)
        pts = build_sawshape_phase(seq, S, Rb, Rt, spacing, ang, profile, power, curved, samples_per_seg)
        coils.append((pts, colors_cw[i % len(colors_cw)], "-", f"{tag} CW", 1.0))
    if include_ccw:
        seq_return = seq[::-1]
        for i in range(phases):
            ang = phase_angle_rad(i, phases, S, micro_mode, micro_deg, sign=-1.0)
            tag = phase_tag(i, upper=False)
            pts = build_sawshape_phase(seq_return, S, Rb, Rt, spacing, ang, profile, power, curved, samples_per_seg)
            coils.append((pts, colors_ccw[i % len(colors_ccw)], "--", f"{tag} CCW", 1.0))
    return coils


STARSHIP_ROT_ANGLE = (2*np.pi/27) / 3
STARSHIP_COIL_ANGLES = (np.linspace(0, 2*np.pi, 28)[:-1] - np.pi*1.5 + (2*np.pi/27))[::-1] + STARSHIP_ROT_ANGLE
STARSHIP_SEGMENT_SHIFT = (2*np.pi/27) / 3


def starship_saw_to_27(saw_seq: np.ndarray, phase_offset_27: int) -> np.ndarray:
    return np.array([((int(s)*3 - int(phase_offset_27) - 1) % 27) + 1 for s in saw_seq], dtype=int)


def build_starship_path(seq_27: np.ndarray, phase_angle: float, segment: int, Rb: float, Rt: float,
                        spacing: float, profile: str, power: float, curved: bool,
                        samples_per_seg: int, reverse: bool = False) -> np.ndarray:
    if reverse:
        seq_27 = seq_27[::-1]
    N = len(seq_27) - 1
    s_nodes = np.linspace(0, 1, N+1)
    r_nodes = r_profile(s_nodes, Rb, Rt, profile, power)
    z_nodes = s_nodes * spacing
    seg = STARSHIP_SEGMENT_SHIFT * (int(segment) - 1)
    if not curved:
        pts = np.zeros((N+1, 3), dtype=float)
        for k in range(N+1):
            a = STARSHIP_COIL_ANGLES[int(seq_27[k])-1] + seg + phase_angle
            pts[k, 0] = r_nodes[k]*np.cos(a)
            pts[k, 1] = r_nodes[k]*np.sin(a)
            pts[k, 2] = z_nodes[k]
        return pts - np.array([0.0, 0.0, spacing/2.0])

    xs, ys, zs = [], [], []
    samples_per_seg = int(max(2, samples_per_seg))
    for k in range(N):
        i0, i1 = int(seq_27[k])-1, int(seq_27[k+1])-1
        a0 = STARSHIP_COIL_ANGLES[i0] + seg + phase_angle
        a1 = STARSHIP_COIL_ANGLES[i1] + seg + phase_angle
        da = (a1 - a0 + np.pi) % (2*np.pi) - np.pi
        a_line = a0 + np.linspace(0, 1, samples_per_seg, endpoint=False)*da
        r_line = np.linspace(r_nodes[k], r_nodes[k+1], samples_per_seg, endpoint=False)
        z_line = np.linspace(z_nodes[k], z_nodes[k+1], samples_per_seg, endpoint=False)
        xs.append(r_line*np.cos(a_line))
        ys.append(r_line*np.sin(a_line))
        zs.append(z_line)
    pts = np.column_stack([np.concatenate(xs), np.concatenate(ys), np.concatenate(zs)])
    return pts - np.array([0.0, 0.0, spacing/2.0])


def build_starship(S: int, step_fwd: int, step_bwd: int, n_pairs: int, Rb: float, Rt: float,
                   spacing: float, profile: str, power: float, curved: bool,
                   samples_per_seg: int, ccw_start_mode: str = "Opposite (180 deg)",
                   enabled_phases=None, enabled_strands=None,
                   neutral_current_factor: float = 0.0,
                   micro_mode: str = "Auto 360/(slots*phases)",
                   micro_deg: float = 0.0) -> List[Coil]:
    """Build Starship ABC + anti branches.

    Labels intentionally omit the word "Starship" so the legend stays compact:
    "A fwd", "A neu", "A bwd", ...

    The neutral strand is modeled as a sense/measurement wire by default. It is
    still drawn/exported, but its Biot-Savart contribution is multiplied by
    ``neutral_current_factor``. Use 0.0 for an ideal sense wire, small values for
    parasitic pickup/current, and 1.0 when deliberately driving it.
    """
    if enabled_phases is None:
        enabled_phases = {p: True for p in ["A", "B", "C", "a", "b", "c"]}
    if enabled_strands is None:
        enabled_strands = {s: True for s in ["fwd", "neu", "bwd"]}

    anti_angle = np.pi if str(ccw_start_mode).startswith("Opposite") else 0.0
    saw_seq = alternating_skip_indices(S, step_fwd, step_bwd, n_pairs, start=1)
    # Starship has a 27-point angular grid. The micro phase is therefore
    # 360/27/3 = 4.444... degrees in Auto mode, matching the existing
    # one-third-segment idea.
    star_slots = 27
    star_phases = 3
    specs = [
        (0,  phase_angle_rad(0, star_phases, star_slots, micro_mode, micro_deg, +1.0), False, "A", ["tab:blue", "tab:cyan", "steelblue"]),
        (9,  phase_angle_rad(1, star_phases, star_slots, micro_mode, micro_deg, +1.0), False, "B", ["tab:red", "tab:orange", "salmon"]),
        (18, phase_angle_rad(2, star_phases, star_slots, micro_mode, micro_deg, +1.0), False, "C", ["tab:green", "tab:purple", "yellowgreen"]),
        (0,  anti_angle + phase_angle_rad(0, star_phases, star_slots, micro_mode, micro_deg, -1.0), True, "a", ["navy", "deepskyblue", "slateblue"]),
        (9,  anti_angle + phase_angle_rad(1, star_phases, star_slots, micro_mode, micro_deg, -1.0), True, "b", ["maroon", "tomato", "darkorange"]),
        (18, anti_angle + phase_angle_rad(2, star_phases, star_slots, micro_mode, micro_deg, -1.0), True, "c", ["darkgreen", "limegreen", "olive"]),
    ]
    strands = [(1, "fwd", "-"), (2, "neu", "--"), (3, "bwd", "-")]
    coils: List[Coil] = []
    for phase_off27, phase_angle, reverse, tag, colors in specs:
        if not bool(enabled_phases.get(tag, True)):
            continue
        seq_27 = starship_saw_to_27(saw_seq, phase_off27)
        for (segment, strand_name, ls), color in zip(strands, colors):
            if not bool(enabled_strands.get(strand_name, True)):
                continue
            pts = build_starship_path(seq_27, phase_angle, segment, Rb, Rt, spacing, profile, power,
                                      curved, samples_per_seg, reverse=reverse)
            cmul = float(neutral_current_factor) if strand_name == "neu" else 1.0
            coils.append((pts, color, ls, f"{tag} {strand_name}", cmul))
    return coils


# =============================================================================
# Biot-Savart and field helpers
# =============================================================================
def biot_savart_wire_grid_chunked(grid: Grid3D, polyline: np.ndarray, current: float,
                                  r_softening: float, chunk: int = 96) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    X, Y, Z = grid.X, grid.Y, grid.Z
    Bx = np.zeros_like(X, dtype=np.float64)
    By = np.zeros_like(Y, dtype=np.float64)
    Bz = np.zeros_like(Z, dtype=np.float64)

    polyline = finite_polyline(polyline)
    if polyline.shape[0] < 2 or abs(current) < 1e-30:
        return Bx, By, Bz

    p0 = polyline[:-1]
    p1 = polyline[1:]
    dl = p1 - p0
    mid = 0.5 * (p0 + p1)
    target = np.stack([X.ravel(), Y.ravel(), Z.ravel()], axis=1)
    rs2 = float(max(1e-15, r_softening)) ** 2

    for i0 in range(0, len(dl), int(max(1, chunk))):
        i1 = min(i0 + chunk, len(dl))
        dL = dl[i0:i1]
        M = mid[i0:i1]
        r_vec = target[:, None, :] - M[None, :, :]
        r_sq = np.sum(r_vec*r_vec, axis=2) + rs2
        r_cubed = r_sq * np.sqrt(r_sq)
        cross = np.cross(dL[None, :, :], r_vec)
        factor = (MU0_4PI * current) / r_cubed
        Bseg = cross * factor[:, :, None]
        Bsum = np.sum(Bseg, axis=1)
        Bx += Bsum[:, 0].reshape(X.shape)
        By += Bsum[:, 1].reshape(Y.shape)
        Bz += Bsum[:, 2].reshape(Z.shape)

    return Bx, By, Bz


def estimate_bounds_from_coils(coils: List[Coil], margin: float = 2.90) -> float:
    pts = [finite_polyline(c[0]) for c in coils if finite_polyline(c[0]).shape[0] > 0]
    if not pts:
        return 1.0
    all_pts = np.vstack(pts)
    max_abs = float(np.max(np.abs(all_pts)))
    return max(1e-3, margin * max_abs)


def polyline_length(points: np.ndarray) -> float:
    """Return the arc length of a polyline in meters."""
    pts = finite_polyline(points)
    if len(pts) < 2:
        return 0.0
    return float(np.sum(np.linalg.norm(np.diff(pts, axis=0), axis=1)))


def safe_float_fmt(value: float, digits: int = 6) -> str:
    """Compact numerical formatting for log tables."""
    try:
        v = float(value)
    except Exception:
        return ""
    if not np.isfinite(v):
        return ""
    return f"{v:.{digits}g}"


# =============================================================================
# GUI app
# =============================================================================
class RodinGUI3(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("rodin_GUI3 — Rodin + SawShape + Starship coil field GUI")
        self.geometry("1500x900")
        self._after_id = None
        self._layout_heatmap = None
        self._cbar_heat = None
        self._cbar_b = None
        self._cache_key = None
        self._cache: Dict[str, object] = {}
        self._spin_refs: Dict[str, ttk.Spinbox] = {}
        self._entry_refs: Dict[str, ttk.Entry] = {}

        # Main vars
        self.var_quality = tk.StringVar(value="Normal")
        self.var_preset = tk.StringVar(value="Rodin 3-phase CW/CCW")
        self.var_phase_drive = tk.StringVar(value="All +I")
        self.var_phase_micro_mode = tk.StringVar(value="Auto 360/(slots*phases)")
        self.var_phase_micro_deg = tk.DoubleVar(value=0.0)
        self.var_shape_include_ccw = tk.BooleanVar(value=True)

        # Generic controls
        self.var_N = tk.IntVar(value=10)
        self.var_R_m = tk.DoubleVar(value=0.035)
        self.var_L_m = tk.DoubleVar(value=0.090)

        # Rodin controls
        self.var_major_d_cm = tk.DoubleVar(value=9.8)
        self.var_minor_r_mm = tk.DoubleVar(value=12.0)
        self.var_p = tk.IntVar(value=5)
        self.var_q = tk.IntVar(value=12)
        self.var_turns = tk.IntVar(value=1)
        self.var_phases = tk.IntVar(value=3)
        self.var_separate = tk.BooleanVar(value=True)
        self.var_gap_cm = tk.DoubleVar(value=5.0)
        self.var_ccw_start = tk.StringVar(value="Same")
        # Global rotation is the physically visible/default phase placement.
        # The older cell-phase mode only reparameterizes a closed torus knot and can overlap lanes.
        self.var_rodin_phase_placement = tk.StringVar(value="Global rotation + sub-cell offset")
        self.var_starship_ccw_start = tk.StringVar(value="Opposite (180 deg)")

        # Starship branch selection: ABC + anti phases, and fwd/neu/bwd strands.
        # Neutral is a drawn/exported sense wire by default and contributes no B field
        # unless a non-zero factor is entered.
        self.var_starship_phase_A = tk.BooleanVar(value=True)
        self.var_starship_phase_B = tk.BooleanVar(value=True)
        self.var_starship_phase_C = tk.BooleanVar(value=True)
        self.var_starship_phase_a = tk.BooleanVar(value=True)
        self.var_starship_phase_b = tk.BooleanVar(value=True)
        self.var_starship_phase_c = tk.BooleanVar(value=True)
        self.var_starship_strand_fwd = tk.BooleanVar(value=True)
        self.var_starship_strand_neu = tk.BooleanVar(value=True)
        self.var_starship_strand_bwd = tk.BooleanVar(value=True)
        self.var_starship_neutral_current_factor = tk.DoubleVar(value=0.0)

        # Saw/Starship shape controls, in mm
        self.var_shape_Rb_mm = tk.DoubleVar(value=12.0)
        self.var_shape_Rt_mm = tk.DoubleVar(value=28.0)
        self.var_shape_spacing_mm = tk.DoubleVar(value=18.0)
        self.var_shape_layers = tk.IntVar(value=20)
        self.var_shape_power = tk.DoubleVar(value=2.2)
        self.var_shape_profile = tk.StringVar(value="Exponential")
        self.var_saw_S = tk.IntVar(value=40)
        self.var_saw_fwd = tk.IntVar(value=11)
        self.var_saw_bwd = tk.IntVar(value=-9)
        self.var_starship_S = tk.IntVar(value=9)
        self.var_starship_fwd = tk.IntVar(value=4)
        self.var_starship_bwd = tk.IntVar(value=4)
        self.var_samples_per_seg = tk.IntVar(value=24)

        # Compute/viz controls
        self.var_I = tk.DoubleVar(value=1.0)
        self.var_field_backend = tk.StringVar(value="SSTcore C++ fast")
        self._sstcore_module = None
        self._sstcore_checked = False
        self.var_bounds_m = tk.DoubleVar(value=0.09)
        self.var_auto_bounds = tk.BooleanVar(value=True)
        self.var_grid_res = tk.IntVar(value=25)
        self.var_poly_pts = tk.IntVar(value=1400)
        self.var_soft_m = tk.DoubleVar(value=0.001)
        self.var_show_quiver = tk.BooleanVar(value=True)
        self.var_show_3d_grid = tk.BooleanVar(value=True)
        self.var_show_null = tk.BooleanVar(value=False)
        self.var_show_heatmap = tk.BooleanVar(value=True)
        self.var_view_layout = tk.StringVar(value="Perspective")
        self.var_heatmap_plane = tk.StringVar(value="XY z=0")
        self.var_null_threshold = tk.DoubleVar(value=0.60)
        self.var_b_floor = tk.DoubleVar(value=1e-12)
        self.var_quiver_step = tk.IntVar(value=2)
        self.var_arrow_scale = tk.DoubleVar(value=0.25)
        self.var_show_legend = tk.BooleanVar(value=False)
        self.var_autoupdate = tk.BooleanVar(value=False)

        # Update log window state. The log is intentionally compact: it records
        # one run-summary row per update plus per-lane summary rows. Full point
        # clouds remain available through Export coil CSV to avoid freezing the UI.
        self.var_log_updates = tk.BooleanVar(value=True)
        self.var_auto_open_log = tk.BooleanVar(value=False)
        self._update_counter = 0
        self._log_rows: List[Dict[str, str]] = []
        self._lane_log_rows: List[Dict[str, str]] = []
        self._log_window = None
        self._log_summary_tree = None
        self._log_lane_tree = None
        self._last_update_snapshot: Dict[str, object] = {}

        self._build_controls()
        self._build_plot()
        self._apply_quality_preset(initial=True)
        self.update_plot()

    # ------------------------------------------------------------------
    # UI construction helpers
    # ------------------------------------------------------------------
    def _quality_map(self):
        return {
            "Low": {"grid_res": 17, "poly_pts": 700, "quiver_step": 3, "samples_per_seg": 12},
            "Normal": {"grid_res": 25, "poly_pts": 1400, "quiver_step": 2, "samples_per_seg": 24},
            "High": {"grid_res": 33, "poly_pts": 2400, "quiver_step": 2, "samples_per_seg": 36},
        }

    def _apply_quality_preset(self, initial=False):
        p = self._quality_map().get(self.var_quality.get(), self._quality_map()["Normal"])
        self.var_grid_res.set(p["grid_res"])
        self.var_poly_pts.set(p["poly_pts"])
        self.var_quiver_step.set(p["quiver_step"])
        self.var_samples_per_seg.set(p["samples_per_seg"])
        if not initial:
            self.lbl_status.config(text=f"Applied quality: {self.var_quality.get()}")

    def _bind_widget_mousewheel_to_sidebar(self, widget):
        """Let mouse wheel scroll the sidebar, never mutate Entry/Spinbox values.

        ttk.Spinbox and ttk.Combobox can consume mouse-wheel events and change
        values while the user is trying to scroll the long settings panel. This
        binding redirects wheel events to the sidebar canvas and returns
        ``break`` so the widget class binding cannot increment/decrement values.
        """
        def _wheel(event):
            canvas = getattr(getattr(self, "_sidebar_scroll", None), "canvas", None)
            if canvas is not None:
                if getattr(event, "num", None) == 4:
                    canvas.yview_scroll(-1, "units")
                elif getattr(event, "num", None) == 5:
                    canvas.yview_scroll(1, "units")
                else:
                    delta = int(-event.delta / 120) if getattr(event, "delta", 0) else 0
                    if delta:
                        canvas.yview_scroll(delta, "units")
            return "break"

        widget.bind("<MouseWheel>", _wheel)
        widget.bind("<Button-4>", _wheel)
        widget.bind("<Button-5>", _wheel)

    def _add_labeled_entry(self, parent, label, var, key=None):
        block = ttk.Frame(parent)
        block.pack(fill=tk.X, pady=3)
        ttk.Label(block, text=label).pack(anchor="w")
        e = ttk.Entry(block, textvariable=var)
        e.pack(fill=tk.X)
        self._bind_widget_mousewheel_to_sidebar(e)
        if key:
            self._entry_refs[key] = e
        return e

    def _add_labeled_spin(self, parent, label, var, from_, to_, increment=1, key=None):
        block = ttk.Frame(parent)
        block.pack(fill=tk.X, pady=3)
        ttk.Label(block, text=label).pack(anchor="w")
        sp = ttk.Spinbox(block, from_=from_, to=to_, increment=increment, textvariable=var)
        sp.pack(fill=tk.X)
        self._bind_widget_mousewheel_to_sidebar(sp)
        if key:
            self._spin_refs[key] = sp
        return sp

    def _add_labeled_combo(self, parent, label, var, values, key=None):
        block = ttk.Frame(parent)
        block.pack(fill=tk.X, pady=3)
        ttk.Label(block, text=label).pack(anchor="w")
        cb = ttk.Combobox(block, textvariable=var, values=list(values), state="readonly")
        cb.pack(fill=tk.X)
        self._bind_widget_mousewheel_to_sidebar(cb)
        if key:
            self._entry_refs[key] = cb
        return cb

    def _add_compact_fields(self, parent, specs, columns=3):
        """Add compact label+field cells in a grid.

        specs entries:
          (kind, label, var, key, options)
        where kind is ``entry`` or ``spin``. For spin, options may contain
        from_, to_, increment.
        """
        grid = ttk.Frame(parent)
        grid.pack(fill=tk.X, pady=3)
        columns = max(1, int(columns))
        for c in range(columns):
            grid.columnconfigure(c, weight=1, uniform="fieldcols")
        widgets = []
        for i, spec in enumerate(specs):
            kind, label, var, key, opts = spec
            row = i // columns
            col = i % columns
            cell = ttk.Frame(grid)
            cell.grid(row=row, column=col, sticky="ew", padx=(0 if col == 0 else 4, 4 if col < columns-1 else 0), pady=2)
            ttk.Label(cell, text=label).pack(anchor="w")
            if kind == "spin":
                w = ttk.Spinbox(
                    cell,
                    from_=opts.get("from_", 0),
                    to=opts.get("to_", 100),
                    increment=opts.get("increment", 1),
                    textvariable=var,
                    width=8,
                )
                self._spin_refs[key] = w
            else:
                w = ttk.Entry(cell, textvariable=var, width=9)
                self._entry_refs[key] = w
            w.pack(fill=tk.X)
            self._bind_widget_mousewheel_to_sidebar(w)
            widgets.append(w)
        return widgets

    def _add_check_row(self, parent, title, items, columns=6):
        block = ttk.Frame(parent)
        block.pack(fill=tk.X, pady=4)
        ttk.Label(block, text=title).pack(anchor="w")
        row = ttk.Frame(block)
        row.pack(fill=tk.X, pady=(2, 0))
        for i, (label, var) in enumerate(items):
            cb = ttk.Checkbutton(row, text=label, variable=var)
            cb.grid(row=i // columns, column=i % columns, sticky="w", padx=(0, 10), pady=1)
        return row

    def _add_slider(self, parent, label, var, from_, to_, fmt=lambda v: f"{v:.3g}"):
        block = ttk.Frame(parent)
        block.pack(fill=tk.X, pady=5)
        top = ttk.Frame(block)
        top.pack(fill=tk.X)
        ttk.Label(top, text=label).pack(side=tk.LEFT)
        val_lbl = ttk.Label(top, text="")
        val_lbl.pack(side=tk.RIGHT)

        def refresh(*_):
            try:
                val_lbl.configure(text=fmt(float(var.get())))
            except Exception:
                val_lbl.configure(text="?")

        scale = ttk.Scale(block, from_=from_, to=to_, orient="horizontal", variable=var)
        scale.pack(fill=tk.X)
        # Sliders keep their native drag behavior; mouse wheel is redirected
        # because accidental wheel changes while scrolling are not useful here.
        self._bind_widget_mousewheel_to_sidebar(scale)
        var.trace_add("write", lambda *_: refresh())
        refresh()
        return scale

    def _build_controls(self):
        sidebar = ttk.Frame(self)
        sidebar.pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=8)
        scroll = ScrollableFrame(sidebar, width=500)
        self._sidebar_scroll = scroll
        scroll.pack(fill=tk.BOTH, expand=True)
        frm = scroll.inner

        # Quality
        qb = ttk.Frame(frm)
        qb.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(qb, text="Quality preset", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        qrow = ttk.Frame(qb)
        qrow.pack(fill=tk.X, pady=3)
        qcombo = ttk.Combobox(qrow, textvariable=self.var_quality, values=["Low", "Normal", "High"], state="readonly")
        qcombo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._bind_widget_mousewheel_to_sidebar(qcombo)
        ttk.Button(qrow, text="Apply", command=self._apply_quality_preset).pack(side=tk.RIGHT, padx=(6, 0))
        self.var_quality.trace_add("write", lambda *_: self._apply_quality_preset())

        self.sec_preset = CollapsibleSection(frm, "Coil preset", True); self.sec_preset.pack(fill=tk.X)
        self.sec_generic = CollapsibleSection(frm, "Generic coil controls", False); self.sec_generic.pack(fill=tk.X)
        self.sec_rodin = CollapsibleSection(frm, "Rodin / knot controls", True); self.sec_rodin.pack(fill=tk.X)
        self.sec_shape = CollapsibleSection(frm, "SawShape / Starship shape sliders", True); self.sec_shape.pack(fill=tk.X)
        self.sec_compute = CollapsibleSection(frm, "Compute / field", True); self.sec_compute.pack(fill=tk.X)
        self.sec_viz = CollapsibleSection(frm, "Visual / export", True); self.sec_viz.pack(fill=tk.X)
        sec_preset = self.sec_preset
        sec_generic = self.sec_generic
        sec_rodin = self.sec_rodin
        sec_shape = self.sec_shape
        sec_compute = self.sec_compute
        sec_viz = self.sec_viz

        pbody = sec_preset.body
        ttk.Label(pbody, text="Preset").pack(anchor="w")
        presets = [
            "Solenoide", "Toroid", "Enkele winding", "Helmholtz", "Rodin-knot",
            "Rodin 3-phase CW/CCW",
            "Straight SawShape", "Curved SawShape",
            "Straight Starship", "Curved Starship",
        ]
        self.cmb_preset = ttk.Combobox(pbody, textvariable=self.var_preset, values=presets, state="readonly")
        self.cmb_preset.pack(fill=tk.X, pady=(0, 6))
        self._bind_widget_mousewheel_to_sidebar(self.cmb_preset)
        self.cmb_preset.bind("<<ComboboxSelected>>", self._on_preset_changed)
        ttk.Label(pbody, text="Phase drive / current assignment").pack(anchor="w")
        drive_cb = ttk.Combobox(pbody, textvariable=self.var_phase_drive,
                                values=["All +I", "ABC static [1,-0.5,-0.5]", "ACB static [1,-0.5,-0.5]"],
                                state="readonly")
        drive_cb.pack(fill=tk.X)
        self._bind_widget_mousewheel_to_sidebar(drive_cb)
        self._add_labeled_combo(
            pbody,
            "Phase micro-offset",
            self.var_phase_micro_mode,
            ["Auto 360/(slots*phases)", "Off", "Custom degrees"],
        )
        self._add_labeled_entry(pbody, "Custom micro-offset [deg]", self.var_phase_micro_deg, key="phase_micro_deg")
        ttk.Checkbutton(pbody, text="Generate CCW / return family for SawShape", variable=self.var_shape_include_ccw).pack(anchor="w", pady=2)

        g = sec_generic.body
        self._add_compact_fields(g, [
            ("spin", "N", self.var_N, "N", {"from_": 1, "to": 120, "increment": 1}),
            ("entry", "R [m]", self.var_R_m, "R_m", {}),
            ("entry", "L [m]", self.var_L_m, "L_m", {}),
        ], columns=3)

        r = sec_rodin.body
        self.frame_knot_common = ttk.Frame(r)
        self.frame_knot_common.pack(fill=tk.X)
        self._add_compact_fields(self.frame_knot_common, [
            ("spin", "p", self.var_p, "p", {"from_": 1, "to": 200, "increment": 1}),
            ("spin", "q", self.var_q, "q", {"from_": 1, "to": 200, "increment": 1}),
            ("spin", "Turns", self.var_turns, "turns", {"from_": 1, "to": 50, "increment": 1}),
        ], columns=3)

        self.frame_rodin3 = ttk.Frame(r)
        self.frame_rodin3.pack(fill=tk.X)
        self._add_compact_fields(self.frame_rodin3, [
            ("entry", "Major Ø [cm]", self.var_major_d_cm, "major_d_cm", {}),
            ("entry", "Minor r [mm]", self.var_minor_r_mm, "minor_r_mm", {}),
            ("spin", "Phases", self.var_phases, "phases", {"from_": 1, "to": 12, "increment": 1}),
        ], columns=3)
        ttk.Checkbutton(self.frame_rodin3, text="Separate CW/CCW families along z", variable=self.var_separate).pack(anchor="w", pady=2)
        self._add_slider(self.frame_rodin3, "Gap [cm]", self.var_gap_cm, 0.0, 25.0, lambda v: f"{v:.2f} cm")
        cb = self._add_labeled_combo(self.frame_rodin3, "CCW start relative to CW", self.var_ccw_start, ["Same", "Opposite (1->19)"])
        self._add_labeled_combo(
            self.frame_rodin3,
            "Rodin phase placement",
            self.var_rodin_phase_placement,
            ["Global rotation + sub-cell offset", "Global rotation only", "Cell phase legacy (may overlap)"],
        )

        s = sec_shape.body
        self.frame_shape_common = ttk.Frame(s)
        self.frame_shape_common.pack(fill=tk.X)
        self._add_compact_fields(self.frame_shape_common, [
            ("entry", "R bottom [mm]", self.var_shape_Rb_mm, "shape_Rb_mm", {}),
            ("entry", "R top [mm]", self.var_shape_Rt_mm, "shape_Rt_mm", {}),
            ("entry", "Height [mm]", self.var_shape_spacing_mm, "shape_spacing_mm", {}),
            ("spin", "Layers", self.var_shape_layers, "shape_layers", {"from_": 1, "to": 240, "increment": 1}),
            ("entry", "Bowl power", self.var_shape_power, "shape_power", {}),
            ("spin", "Samples", self.var_samples_per_seg, "samples_per_seg", {"from_": 2, "to": 120, "increment": 1}),
        ], columns=3)
        self._add_labeled_combo(self.frame_shape_common, "Bowl profile", self.var_shape_profile, ["Exponential", "Linear", "Inverse Exp"])

        self.frame_sawshape = ttk.Frame(s)
        self.frame_sawshape.pack(fill=tk.X)
        ttk.Label(self.frame_sawshape, text="SawShape-specific", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(6, 0))
        self._add_compact_fields(self.frame_sawshape, [
            ("spin", "S", self.var_saw_S, "saw_S", {"from_": 3, "to": 200, "increment": 1}),
            ("spin", "Fwd step", self.var_saw_fwd, "saw_fwd", {"from_": -200, "to": 200, "increment": 1}),
            ("spin", "Back step", self.var_saw_bwd, "saw_bwd", {"from_": -200, "to": 200, "increment": 1}),
        ], columns=3)

        self.frame_starship = ttk.Frame(s)
        self.frame_starship.pack(fill=tk.X)
        ttk.Label(self.frame_starship, text="Starship-specific", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(6, 0))
        self._add_compact_fields(self.frame_starship, [
            ("spin", "S", self.var_starship_S, "starship_S", {"from_": 3, "to": 200, "increment": 1}),
            ("spin", "Fwd step", self.var_starship_fwd, "starship_fwd", {"from_": -200, "to": 200, "increment": 1}),
            ("spin", "Back step", self.var_starship_bwd, "starship_bwd", {"from_": -200, "to": 200, "increment": 1}),
        ], columns=3)
        self._add_labeled_combo(self.frame_starship, "CCW / anti start relative to CW / ABC", self.var_starship_ccw_start,
                                ["Same", "Opposite (180 deg)"])
        self._add_check_row(self.frame_starship, "Active phases", [
            ("A", self.var_starship_phase_A),
            ("B", self.var_starship_phase_B),
            ("C", self.var_starship_phase_C),
            ("a", self.var_starship_phase_a),
            ("b", self.var_starship_phase_b),
            ("c", self.var_starship_phase_c),
        ], columns=6)
        self._add_check_row(self.frame_starship, "Active strands", [
            ("fwd", self.var_starship_strand_fwd),
            ("neu / sense", self.var_starship_strand_neu),
            ("bwd", self.var_starship_strand_bwd),
        ], columns=3)
        self._add_labeled_entry(self.frame_starship, "Neutral/sense current factor", self.var_starship_neutral_current_factor,
                                key="starship_neutral_current_factor")
        ttk.Label(
            self.frame_starship,
            text="Starship: fwd=heen, bwd=terug, neu=sense/meetkabel tussen fwd en bwd. Default neu factor 0.0 = zichtbaar maar geen B-bijdrage.",
            wraplength=460,
            foreground="#555555",
        ).pack(anchor="w", pady=(2, 6))

        c = sec_compute.body
        self._add_compact_fields(c, [
            ("entry", "Current [A]", self.var_I, "I", {}),
            ("entry", "Bounds [m]", self.var_bounds_m, "bounds_m", {}),
            ("spin", "Grid", self.var_grid_res, "grid_res", {"from_": 10, "to": 60, "increment": 1}),
            ("spin", "Polyline", self.var_poly_pts, "poly_pts", {"from_": 200, "to": 8000, "increment": 50}),
            ("entry", "Softening [m]", self.var_soft_m, "soft_m", {}),
        ], columns=3)
        self._add_labeled_combo(c, "Field backend", self.var_field_backend,
                                ["NumPy softened", "Auto SSTcore/NumPy", "SSTcore C++ fast"])
        ttk.Checkbutton(c, text="Auto bounds from coil", variable=self.var_auto_bounds).pack(anchor="w", pady=2)

        v = sec_viz.body
        self._add_compact_fields(v, [
            ("spin", "Quiver step", self.var_quiver_step, "quiver_step", {"from_": 1, "to": 10, "increment": 1}),
            ("entry", "Arrow scale", self.var_arrow_scale, "arrow_scale", {}),
        ], columns=2)
        ttk.Checkbutton(v, text="Show quiver", variable=self.var_show_quiver).pack(anchor="w", pady=2)
        ttk.Checkbutton(v, text="Show 3D grid", variable=self.var_show_3d_grid).pack(anchor="w", pady=2)
        ttk.Checkbutton(v, text="Show null proxy scatter 1/|B|", variable=self.var_show_null).pack(anchor="w", pady=2)
        self._add_slider(v, "Null threshold", self.var_null_threshold, 0.0, 0.98, lambda x: f"{x:.2f}")
        self._add_labeled_entry(v, "Null floor B [T]", self.var_b_floor, key="b_floor")
        self._add_labeled_combo(v, "3D view layout", self.var_view_layout,
                                ["Perspective", "Top", "Front", "Side", "Quad views"])
        ttk.Checkbutton(v, text="Show heatmap", variable=self.var_show_heatmap).pack(anchor="w", pady=2)
        self._add_labeled_combo(v, "Heatmap plane", self.var_heatmap_plane,
                                ["XY z=0", "XZ y=0", "YZ x=0", "All 3 planes"])
        ttk.Checkbutton(v, text="Show legend", variable=self.var_show_legend).pack(anchor="w", pady=2)
        buttons = ttk.Frame(v); buttons.pack(fill=tk.X, pady=(8, 2))
        ttk.Button(buttons, text="Save PNG", command=self.save_png).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(buttons, text="Export coil CSV", command=self.export_csv).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 0))
        buttons2 = ttk.Frame(v); buttons2.pack(fill=tk.X, pady=(2, 2))
        ttk.Button(buttons2, text="Open update log", command=self.open_update_log).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(buttons2, text="Clear log", command=self.clear_update_log).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 0))
        ttk.Checkbutton(v, text="Log updates to table", variable=self.var_log_updates).pack(anchor="w", pady=2)
        ttk.Checkbutton(v, text="Show log window on update", variable=self.var_auto_open_log).pack(anchor="w", pady=2)

        bottom = ttk.Frame(frm)
        bottom.pack(fill=tk.X, pady=(10, 8))
        ttk.Button(bottom, text="Update", command=self.update_plot).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Checkbutton(bottom, variable=self.var_autoupdate, text="Auto").pack(side=tk.RIGHT)
        self.lbl_status = ttk.Label(frm, text="Ready.")
        self.lbl_status.pack(anchor="w", pady=(0, 8))
        self._bind_autoupdate()
        self._refresh_option_visibility()


    def _on_preset_changed(self, event=None):
        """Immediate UI refresh when the coil preset dropdown changes."""
        self._refresh_option_visibility()
        self._cache_key = None
        if self.var_autoupdate.get():
            self._schedule_update()

    def _refresh_option_visibility(self):
        """Show only controls relevant to the currently selected coil preset.

        This deliberately repacks the whole sidebar section order. Tkinter can
        otherwise leave stale packed frames visible after several preset changes,
        especially when the section body was open while another section is hidden.
        """
        preset = str(self.var_preset.get())
        is_standard_generic = preset in ["Solenoide", "Toroid", "Enkele winding", "Helmholtz"]
        is_rodin3 = preset == "Rodin 3-phase CW/CCW"
        is_knot = preset == "Rodin-knot"
        is_saw = "SawShape" in preset
        is_starship = "Starship" in preset
        is_shape = is_saw or is_starship

        # Repack top-level sections in a deterministic order.
        top_sections = [
            self.sec_preset,
            self.sec_generic,
            self.sec_rodin,
            self.sec_shape,
            self.sec_compute,
            self.sec_viz,
        ]
        for sec in top_sections:
            try:
                sec.pack_forget()
            except Exception:
                pass

        self.sec_preset.pack(fill=tk.X)
        if is_standard_generic:
            self.sec_generic.pack(fill=tk.X)
        if is_rodin3 or is_knot:
            self.sec_rodin.pack(fill=tk.X)
        if is_shape:
            self.sec_shape.pack(fill=tk.X)
        self.sec_compute.pack(fill=tk.X)
        self.sec_viz.pack(fill=tk.X)

        # Rodin section internals.
        for frame in [self.frame_knot_common, self.frame_rodin3]:
            try:
                frame.pack_forget()
            except Exception:
                pass
        if is_rodin3 or is_knot:
            self.frame_knot_common.pack(fill=tk.X)
        if is_rodin3:
            self.frame_rodin3.pack(fill=tk.X)

        # Shape section internals.
        for frame in [self.frame_shape_common, self.frame_sawshape, self.frame_starship]:
            try:
                frame.pack_forget()
            except Exception:
                pass
        if is_shape:
            self.frame_shape_common.pack(fill=tk.X)
        if is_saw:
            self.frame_sawshape.pack(fill=tk.X)
        if is_starship:
            self.frame_starship.pack(fill=tk.X)

        # Refresh scroll area after packing changes.
        try:
            self.update_idletasks()
            self._sidebar_scroll.canvas.configure(scrollregion=self._sidebar_scroll.canvas.bbox("all"))
        except Exception:
            pass

    def _build_plot(self):
        plot_frame = ttk.Frame(self)
        plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=8, pady=8)
        self.fig = plt.Figure(figsize=(10.7, 7.7), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self._ensure_axes(self.var_show_heatmap.get())

    def _selected_3d_views(self):
        layout = str(self.var_view_layout.get())
        if layout == "Top":
            return ["Top"]
        if layout == "Front":
            return ["Front"]
        if layout == "Side":
            return ["Side"]
        if layout == "Quad views":
            return ["Perspective", "Top", "Front", "Side"]
        return ["Perspective"]

    def _selected_heatmap_planes(self, show_heatmap: bool):
        if not bool(show_heatmap):
            return []
        plane = str(self.var_heatmap_plane.get())
        if plane == "All 3 planes":
            return ["XY z=0", "XZ y=0", "YZ x=0"]
        return [plane]

    def _ensure_axes(self, show_heatmap: bool, force: bool = False):
        """Create fresh axes with a vertical split: 3D views above, heatmaps below.

        For Quad views the 3D part is always a 2x2 grid:
            Perspective | Top
            Front       | Side

        Heatmaps are always rendered below the 3D views. When all three planes
        are selected, they are rendered as XY | XZ | YZ in the lower row.
        """
        views = self._selected_3d_views()
        heatmaps = self._selected_heatmap_planes(show_heatmap)
        layout_key = (tuple(views), tuple(heatmaps), "v14_vertical_split")
        if (not force) and self._layout_heatmap == layout_key:
            return

        self.fig.clf()
        self._cbar_heat = None
        self._cbar_b = None
        self.ax3d_views = []
        self.ax_heatmaps = []

        if heatmaps:
            outer = self.fig.add_gridspec(
                2, 1,
                height_ratios=[2.1, 1.0],
                hspace=0.28,
            )
            top_spec = outer[0]
            bottom_spec = outer[1]
        else:
            outer = self.fig.add_gridspec(1, 1)
            top_spec = outer[0]
            bottom_spec = None

        # --- Top: 3D views ---
        if views == ["Perspective", "Top", "Front", "Side"]:
            gs3d = top_spec.subgridspec(2, 2, wspace=0.08, hspace=0.12)
            positions = [(0, 0), (0, 1), (1, 0), (1, 1)]
            for view_name, pos in zip(views, positions):
                ax = self.fig.add_subplot(gs3d[pos], projection="3d")
                self.ax3d_views.append((ax, view_name))
        else:
            gs3d = top_spec.subgridspec(1, max(1, len(views)), wspace=0.08)
            for idx, view_name in enumerate(views):
                ax = self.fig.add_subplot(gs3d[0, idx], projection="3d")
                self.ax3d_views.append((ax, view_name))

        # --- Bottom: heatmap planes ---
        if heatmaps and bottom_spec is not None:
            gs2d = bottom_spec.subgridspec(1, max(1, len(heatmaps)), wspace=0.28)
            for j, plane in enumerate(heatmaps):
                ax = self.fig.add_subplot(gs2d[0, j])
                self.ax_heatmaps.append((ax, plane))

        self.ax3d = self.ax3d_views[0][0] if self.ax3d_views else None
        self.ax2d = self.ax_heatmaps[0][0] if self.ax_heatmaps else None
        self._layout_heatmap = layout_key

    def _apply_3d_view(self, ax, view_name: str):
        if view_name == "Top":
            ax.view_init(elev=90, azim=-90)
        elif view_name == "Front":
            ax.view_init(elev=0, azim=-90)
        elif view_name == "Side":
            ax.view_init(elev=0, azim=0)
        else:
            ax.view_init(elev=22, azim=42)

    def _draw_3d_scene(self, ax, view_name: str, coils: List[Coil], grid: Grid3D,
                       Bx, By, Bz, Bmag, bounds: float, bnorm, bclip: float,
                       qstep: int, arrow_scale: float, show_legend: bool):
        ax.set_title(view_name)
        ax.set_xlabel("X [m]")
        ax.set_ylabel("Y [m]")
        ax.set_zlabel("Z [m]")
        ax.set_xlim(-bounds, bounds)
        ax.set_ylim(-bounds, bounds)
        ax.set_zlim(-bounds, bounds)
        ax.set_box_aspect((1, 1, 1))
        show_grid = bool(getattr(self, "var_show_3d_grid", tk.BooleanVar(value=True)).get())
        ax.grid(show_grid)
        if not show_grid:
            try:
                ax.xaxis._axinfo["grid"]["linewidth"] = 0
                ax.yaxis._axinfo["grid"]["linewidth"] = 0
                ax.zaxis._axinfo["grid"]["linewidth"] = 0
            except Exception:
                pass

        for pts, color, ls, label, cmul in coils:
            if len(pts) >= 2:
                ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], color=color, linestyle=ls, lw=1.35,
                        alpha=0.92, label=f"{label} ×{cmul:g}")

        if bool(self.var_show_null.get()):
            b_floor = max(0.0, float(self.var_b_floor.get()))
            null_map = 1.0 / (Bmag + b_floor + 1e-300)
            null_map = null_map / max(float(np.nanmax(null_map)), 1e-300)
            mask = null_map > float(self.var_null_threshold.get())
            if np.any(mask):
                idx = np.flatnonzero(mask.ravel())
                max_pts = 6500 if len(getattr(self, "ax3d_views", [])) <= 1 else 2200
                if idx.size > max_pts:
                    idx = idx[np.linspace(0, idx.size - 1, max_pts).astype(int)]
                ax.scatter(grid.X.ravel()[idx], grid.Y.ravel()[idx], grid.Z.ravel()[idx],
                           c=null_map.ravel()[idx], cmap="inferno", s=8, alpha=0.22)

        if bool(self.var_show_quiver.get()):
            st = max(1, qstep)
            xs = grid.X[::st, ::st, ::st]
            ys = grid.Y[::st, ::st, ::st]
            zs = grid.Z[::st, ::st, ::st]
            bxs = Bx[::st, ::st, ::st]
            bys = By[::st, ::st, ::st]
            bzs = Bz[::st, ::st, ::st]
            rgba = plt.cm.Blues(bnorm(np.sqrt(bxs*bxs + bys*bys + bzs*bzs))).reshape(-1, 4)
            scale = arrow_scale / max(bclip, 1e-30)
            try:
                ax.quiver(xs.ravel(), ys.ravel(), zs.ravel(),
                          (bxs*scale).ravel(), (bys*scale).ravel(), (bzs*scale).ravel(),
                          length=1.0, normalize=False, color=rgba, alpha=0.50, linewidth=0.22)
            except Exception:
                ax.quiver(xs, ys, zs, bxs, bys, bzs, length=arrow_scale, normalize=True,
                          alpha=0.30, color="gray")

        if show_legend:
            ax.legend(loc="upper left", fontsize=7)
        self._apply_3d_view(ax, view_name)

    def _draw_heatmap(self, ax, plane: str, grid: Grid3D, Bmag, bounds: float):
        if plane == "XZ y=0":
            j0 = int(np.argmin(np.abs(grid.y - 0.0)))
            data = Bmag[:, j0, :]
            extent = [-bounds, bounds, -bounds, bounds]
            xlabel, ylabel, title = "X [m]", "Z [m]", "XZ plane y≈0"
        elif plane == "YZ x=0":
            i0 = int(np.argmin(np.abs(grid.x - 0.0)))
            data = Bmag[i0, :, :]
            extent = [-bounds, bounds, -bounds, bounds]
            xlabel, ylabel, title = "Y [m]", "Z [m]", "YZ plane x≈0"
        else:
            k0 = int(np.argmin(np.abs(grid.z - 0.0)))
            data = Bmag[:, :, k0]
            extent = [-bounds, bounds, -bounds, bounds]
            xlabel, ylabel, title = "X [m]", "Y [m]", "XY plane z≈0"
        im = ax.imshow(np.log10(np.asarray(data).T + 1e-30), origin="lower",
                       extent=extent, aspect="equal", cmap="viridis")
        ax.set_title(f"{title}: log10(|B| [T])")
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        self.fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    def _bind_autoupdate(self):
        watch = [
            self.var_quality, self.var_preset, self.var_phase_drive, self.var_phase_micro_mode, self.var_phase_micro_deg, self.var_shape_include_ccw,
            self.var_N, self.var_R_m, self.var_L_m,
            self.var_major_d_cm, self.var_minor_r_mm, self.var_p, self.var_q, self.var_turns, self.var_phases,
            self.var_separate, self.var_gap_cm, self.var_ccw_start, self.var_rodin_phase_placement, self.var_starship_ccw_start,
            self.var_shape_Rb_mm, self.var_shape_Rt_mm, self.var_shape_spacing_mm, self.var_shape_layers,
            self.var_shape_power, self.var_shape_profile, self.var_saw_S, self.var_saw_fwd, self.var_saw_bwd,
            self.var_starship_S, self.var_starship_fwd, self.var_starship_bwd, self.var_samples_per_seg,
            self.var_starship_phase_A, self.var_starship_phase_B, self.var_starship_phase_C,
            self.var_starship_phase_a, self.var_starship_phase_b, self.var_starship_phase_c,
            self.var_starship_strand_fwd, self.var_starship_strand_neu, self.var_starship_strand_bwd,
            self.var_starship_neutral_current_factor,
            self.var_I, self.var_field_backend, self.var_bounds_m, self.var_auto_bounds, self.var_grid_res, self.var_poly_pts, self.var_soft_m,
            self.var_show_quiver, self.var_show_3d_grid, self.var_show_null, self.var_show_heatmap, self.var_view_layout, self.var_heatmap_plane,
            self.var_null_threshold, self.var_b_floor,
            self.var_quiver_step, self.var_arrow_scale, self.var_show_legend,
        ]
        for v in watch:
            v.trace_add("write", lambda *_: self._schedule_update())
        self.var_preset.trace_add("write", lambda *_: self._on_preset_changed())

    def _schedule_update(self):
        if not self.var_autoupdate.get():
            return
        if self._after_id is not None:
            self.after_cancel(self._after_id)
        self._after_id = self.after(350, self.update_plot)

    def _commit_inputs(self):
        def to_int(key, var, lo=None, hi=None):
            if key in self._spin_refs:
                try:
                    val = int(float(self._spin_refs[key].get()))
                except Exception:
                    val = int(var.get())
                if lo is not None: val = max(lo, val)
                if hi is not None: val = min(hi, val)
                var.set(val)
        def to_float(key, var, lo=None, hi=None):
            if key in self._entry_refs:
                try:
                    val = float(self._entry_refs[key].get())
                except Exception:
                    val = float(var.get())
                if lo is not None: val = max(lo, val)
                if hi is not None: val = min(hi, val)
                var.set(val)
        for key, var, lo, hi in [
            ("N", self.var_N, 1, 1000), ("p", self.var_p, 1, 500), ("q", self.var_q, 1, 500),
            ("turns", self.var_turns, 1, 200), ("phases", self.var_phases, 1, 12),
            ("shape_layers", self.var_shape_layers, 1, 1000), ("saw_S", self.var_saw_S, 3, 1000),
            ("saw_fwd", self.var_saw_fwd, -1000, 1000), ("saw_bwd", self.var_saw_bwd, -1000, 1000),
            ("starship_S", self.var_starship_S, 3, 1000), ("starship_fwd", self.var_starship_fwd, -1000, 1000),
            ("starship_bwd", self.var_starship_bwd, -1000, 1000), ("samples_per_seg", self.var_samples_per_seg, 2, 240),
            ("grid_res", self.var_grid_res, 10, 80), ("poly_pts", self.var_poly_pts, 200, 10000),
            ("quiver_step", self.var_quiver_step, 1, 20),
        ]:
            to_int(key, var, lo, hi)
        for key, var, lo, hi in [
            ("R_m", self.var_R_m, 1e-6, None), ("L_m", self.var_L_m, 1e-6, None),
            ("major_d_cm", self.var_major_d_cm, 0.1, None), ("minor_r_mm", self.var_minor_r_mm, 0.1, None),
            ("shape_Rb_mm", self.var_shape_Rb_mm, 0.1, None), ("shape_Rt_mm", self.var_shape_Rt_mm, 0.1, None),
            ("shape_spacing_mm", self.var_shape_spacing_mm, 0.1, None), ("shape_power", self.var_shape_power, 0.01, None),
            ("I", self.var_I, None, None), ("bounds_m", self.var_bounds_m, 1e-4, None),
            ("soft_m", self.var_soft_m, 0.0, None), ("b_floor", self.var_b_floor, 0.0, None),
            ("starship_neutral_current_factor", self.var_starship_neutral_current_factor, -10.0, 10.0),
            ("arrow_scale", self.var_arrow_scale, 1e-6, None),
            ("phase_micro_deg", self.var_phase_micro_deg, -360.0, 360.0),
        ]:
            to_float(key, var, lo, hi)

    # ------------------------------------------------------------------
    # Geometry dispatch
    # ------------------------------------------------------------------
    def current_multiplier_for_label(self, label: str, index: int) -> float:
        mode = str(self.var_phase_drive.get())
        if mode == "All +I":
            return 1.0
        phase = 0
        ll = label.lower().strip()
        tokens = ll.replace("/", " ").replace("-", " ").split()
        if "phase" in tokens:
            # Rodin labels: Rodin CW phase 1, 2, 3, ...
            for tok in tokens:
                if tok.isdigit():
                    phase = (int(tok) - 1) % 3
                    break
        elif tokens:
            # Starship labels are compact: A fwd, a neu, b bwd, ...;
            # after lower() the phase family is a/b/c, with A/a both phase 0.
            tag = tokens[0]
            if tag == "b":
                phase = 1
            elif tag == "c":
                phase = 2
            else:
                phase = 0
        abc = [1.0, -0.5, -0.5]
        acb = [1.0, -0.5, -0.5]  # same static amplitudes; handedness is in phase order / wiring geometry
        return abc[phase] if mode.startswith("ABC") else acb[phase]

    def build_current_coils(self) -> List[Coil]:
        preset = str(self.var_preset.get())
        poly_pts = int(self.var_poly_pts.get())
        coils: List[Coil]

        if preset in ["Solenoide", "Toroid", "Enkele winding", "Helmholtz", "Rodin-knot"]:
            pts = generic_wire_points(preset, int(self.var_N.get()), float(self.var_R_m.get()), float(self.var_L_m.get()),
                                      poly_pts, int(self.var_p.get()), int(self.var_q.get()), int(self.var_turns.get()))
            coils = [(pts, "darkorange", "-", preset, 1.0)]

        elif preset == "Rodin 3-phase CW/CCW":
            R_major = 0.5 * float(self.var_major_d_cm.get()) * 1e-2
            r_minor = float(self.var_minor_r_mm.get()) * 1e-3
            r_minor = max(1e-6, min(r_minor, 0.95*max(R_major, 1e-9)))
            coils = build_rodin_3phase(
                R_major=R_major,
                r_minor=r_minor,
                p=int(self.var_p.get()),
                q=int(self.var_q.get()),
                phases=int(self.var_phases.get()),
                turns=int(self.var_turns.get()),
                points=poly_pts,
                separate_families=bool(self.var_separate.get()),
                gap=float(self.var_gap_cm.get()) * 1e-2,
                ccw_start_mode=str(self.var_ccw_start.get()),
                phase_placement=str(self.var_rodin_phase_placement.get()),
                micro_mode=str(self.var_phase_micro_mode.get()),
                micro_deg=float(self.var_phase_micro_deg.get()),
            )

        elif "SawShape" in preset:
            coils = build_sawshape(
                S=int(self.var_saw_S.get()),
                step_fwd=int(self.var_saw_fwd.get()),
                step_bwd=int(self.var_saw_bwd.get()),
                n_pairs=int(self.var_shape_layers.get()),
                Rb=float(self.var_shape_Rb_mm.get())*1e-3,
                Rt=float(self.var_shape_Rt_mm.get())*1e-3,
                spacing=float(self.var_shape_spacing_mm.get())*1e-3,
                profile=str(self.var_shape_profile.get()),
                power=float(self.var_shape_power.get()),
                curved=preset.startswith("Curved"),
                samples_per_seg=int(self.var_samples_per_seg.get()),
                phases=3,
                include_ccw=bool(self.var_shape_include_ccw.get()),
                micro_mode=str(self.var_phase_micro_mode.get()),
                micro_deg=float(self.var_phase_micro_deg.get()),
            )

        elif "Starship" in preset:
            coils = build_starship(
                S=int(self.var_starship_S.get()),
                step_fwd=int(self.var_starship_fwd.get()),
                step_bwd=int(self.var_starship_bwd.get()),
                n_pairs=int(self.var_shape_layers.get()),
                Rb=float(self.var_shape_Rb_mm.get())*1e-3,
                Rt=float(self.var_shape_Rt_mm.get())*1e-3,
                spacing=float(self.var_shape_spacing_mm.get())*1e-3,
                profile=str(self.var_shape_profile.get()),
                power=float(self.var_shape_power.get()),
                curved=preset.startswith("Curved"),
                samples_per_seg=int(self.var_samples_per_seg.get()),
                ccw_start_mode=str(self.var_starship_ccw_start.get()),
                enabled_phases={
                    "A": bool(self.var_starship_phase_A.get()),
                    "B": bool(self.var_starship_phase_B.get()),
                    "C": bool(self.var_starship_phase_C.get()),
                    "a": bool(self.var_starship_phase_a.get()),
                    "b": bool(self.var_starship_phase_b.get()),
                    "c": bool(self.var_starship_phase_c.get()),
                },
                enabled_strands={
                    "fwd": bool(self.var_starship_strand_fwd.get()),
                    "neu": bool(self.var_starship_strand_neu.get()),
                    "bwd": bool(self.var_starship_strand_bwd.get()),
                },
                neutral_current_factor=float(self.var_starship_neutral_current_factor.get()),
                micro_mode=str(self.var_phase_micro_mode.get()),
                micro_deg=float(self.var_phase_micro_deg.get()),
            )
        else:
            pts = generic_wire_points("Solenoide", 10, 0.035, 0.09, poly_pts, 5, 12, 1)
            coils = [(pts, "darkorange", "-", "Solenoide", 1.0)]

        # Apply static drive multipliers after labels exist. The geometry builder
        # may already carry a per-strand multiplier, e.g. Starship neu/sense.
        out = []
        for i, (pts, color, ls, label, cmul) in enumerate(coils):
            out.append((finite_polyline(pts), color, ls, label, float(cmul) * self.current_multiplier_for_label(label, i)))
        return out

    # ------------------------------------------------------------------
    # Update log table
    # ------------------------------------------------------------------
    def open_update_log(self):
        """Open a separate table window with update summaries and lane summaries."""
        if self._log_window is not None and tk.Toplevel.winfo_exists(self._log_window):
            self._log_window.lift()
            return

        win = tk.Toplevel(self)
        win.title("rodin_GUI3 update log")
        win.geometry("1320x620")
        self._log_window = win

        def _on_close():
            self._log_window = None
            self._log_summary_tree = None
            self._log_lane_tree = None
            win.destroy()
        win.protocol("WM_DELETE_WINDOW", _on_close)

        top = ttk.Frame(win)
        top.pack(fill=tk.X, padx=8, pady=6)
        ttk.Label(
            top,
            text="Update log: compact run summary + lane summary. Full point cloud remains in Export coil CSV.",
            font=("Segoe UI", 9, "bold"),
        ).pack(side=tk.LEFT)
        ttk.Button(top, text="Refresh", command=self._populate_log_trees).pack(side=tk.RIGHT, padx=(6, 0))
        ttk.Button(top, text="Clear", command=self.clear_update_log).pack(side=tk.RIGHT, padx=(6, 0))
        ttk.Button(top, text="Export log CSV", command=self.export_update_log_csv).pack(side=tk.RIGHT)

        nb = ttk.Notebook(win)
        nb.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

        frame_summary = ttk.Frame(nb)
        frame_lanes = ttk.Frame(nb)
        nb.add(frame_summary, text="Update summary")
        nb.add(frame_lanes, text="Lane summary")

        summary_cols = [
            "id", "time", "preset", "drive", "coils", "points", "I_A",
            "bounds_m", "grid", "backend", "cache", "B_min_T", "B_p95_T", "B_max_T", "null_voxels",
        ]
        lane_cols = [
            "id", "lane", "points", "cmul", "I_eff_A", "length_m", "xmin", "xmax", "ymin", "ymax", "zmin", "zmax",
        ]
        self._log_summary_tree = self._make_treeview(frame_summary, summary_cols)
        self._log_lane_tree = self._make_treeview(frame_lanes, lane_cols)
        self._populate_log_trees()

    def _make_treeview(self, parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True)
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        for col in columns:
            tree.heading(col, text=col)
            width = 95
            if col in {"preset", "backend"}:
                width = 180
            elif col == "lane":
                width = 150
            elif col == "time":
                width = 145
            tree.column(col, width=width, minwidth=55, anchor="w", stretch=True)
        return tree

    def _populate_log_trees(self):
        # Latest updates are shown on top so the table immediately reflects the
        # most recent Update/Auto step. Lanes are grouped by newest update id.
        if self._log_summary_tree is not None:
            self._log_summary_tree.delete(*self._log_summary_tree.get_children())
            cols = list(self._log_summary_tree["columns"])
            first_item = None
            for row in reversed(self._log_rows):
                item = self._log_summary_tree.insert("", "end", values=[row.get(c, "") for c in cols])
                if first_item is None:
                    first_item = item
            if first_item:
                self._log_summary_tree.selection_set(first_item)
                self._log_summary_tree.focus(first_item)
                self._log_summary_tree.see(first_item)
        if self._log_lane_tree is not None:
            self._log_lane_tree.delete(*self._log_lane_tree.get_children())
            cols = list(self._log_lane_tree["columns"])
            for row in reversed(self._lane_log_rows):
                self._log_lane_tree.insert("", "end", values=[row.get(c, "") for c in cols])

    def clear_update_log(self):
        self._log_rows.clear()
        self._lane_log_rows.clear()
        self._populate_log_trees()
        self.lbl_status.config(text="Update log cleared.")

    def export_update_log_csv(self):
        fn = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV file", "*.csv")],
            initialfile="rodin_GUI3_update_log.csv",
        )
        if not fn:
            return
        with open(fn, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            summary_cols = [
                "id", "time", "preset", "drive", "coils", "points", "I_A",
                "bounds_m", "grid", "backend", "cache", "B_min_T", "B_p95_T", "B_max_T", "null_voxels",
            ]
            lane_cols = [
                "id", "lane", "points", "cmul", "I_eff_A", "length_m", "xmin", "xmax", "ymin", "ymax", "zmin", "zmax",
            ]
            w.writerow(["UPDATE SUMMARY"])
            w.writerow(summary_cols)
            for row in self._log_rows:
                w.writerow([row.get(c, "") for c in summary_cols])
            w.writerow([])
            w.writerow(["LANE SUMMARY"])
            w.writerow(lane_cols)
            for row in self._lane_log_rows:
                w.writerow([row.get(c, "") for c in lane_cols])
        self.lbl_status.config(text=f"Exported update log: {fn}")

    def _append_update_log(self, coils: List[Coil], I: float, bounds: float, res: int,
                           backend_note: str, recompute: bool, Bmag: np.ndarray, null_count: int):
        if not bool(self.var_log_updates.get()):
            return
        self._update_counter += 1
        update_id = str(self._update_counter)
        total_points = int(sum(len(pts) for pts, *_ in coils))
        bvals = np.asarray(Bmag, dtype=float)
        finite = bvals[np.isfinite(bvals)]
        if finite.size:
            b_min = float(np.min(finite))
            b_p95 = float(np.percentile(finite, 95))
            b_max = float(np.max(finite))
        else:
            b_min = b_p95 = b_max = 0.0

        row = {
            "id": update_id,
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "preset": str(self.var_preset.get()),
            "drive": str(self.var_phase_drive.get()),
            "rodin_phase_placement": str(self.var_rodin_phase_placement.get()),
            "phase_micro_mode": str(self.var_phase_micro_mode.get()),
            "coils": str(len(coils)),
            "points": str(total_points),
            "I_A": safe_float_fmt(I),
            "bounds_m": safe_float_fmt(bounds),
            "grid": f"{res}^3",
            "backend": str(backend_note),
            "cache": "MISS" if recompute else "HIT",
            "B_min_T": safe_float_fmt(b_min),
            "B_p95_T": safe_float_fmt(b_p95),
            "B_max_T": safe_float_fmt(b_max),
            "null_voxels": str(int(null_count)),
        }
        self._log_rows.append(row)

        for pts, _color, _ls, label, cmul in coils:
            pts = finite_polyline(pts)
            if len(pts):
                mins = np.min(pts, axis=0)
                maxs = np.max(pts, axis=0)
            else:
                mins = maxs = np.zeros(3)
            self._lane_log_rows.append({
                "id": update_id,
                "lane": str(label),
                "points": str(len(pts)),
                "cmul": safe_float_fmt(cmul),
                "I_eff_A": safe_float_fmt(I * cmul),
                "length_m": safe_float_fmt(polyline_length(pts)),
                "xmin": safe_float_fmt(mins[0]),
                "xmax": safe_float_fmt(maxs[0]),
                "ymin": safe_float_fmt(mins[1]),
                "ymax": safe_float_fmt(maxs[1]),
                "zmin": safe_float_fmt(mins[2]),
                "zmax": safe_float_fmt(maxs[2]),
            })

        # Keep the in-memory table responsive during Auto updates.
        max_updates = 500
        if len(self._log_rows) > max_updates:
            keep_ids = {r["id"] for r in self._log_rows[-max_updates:]}
            self._log_rows = self._log_rows[-max_updates:]
            self._lane_log_rows = [r for r in self._lane_log_rows if r.get("id") in keep_ids]

        if bool(getattr(self, "var_auto_open_log", tk.BooleanVar(value=False)).get()) and (
            self._log_window is None or not tk.Toplevel.winfo_exists(self._log_window)
        ):
            self.after_idle(self.open_update_log)
        elif self._log_window is not None and tk.Toplevel.winfo_exists(self._log_window):
            self._populate_log_trees()

    # ------------------------------------------------------------------
    # Render / compute
    # ------------------------------------------------------------------
    def update_plot(self):
        self.lbl_status.config(text="Computing…")
        self.update_idletasks()
        self._commit_inputs()
        show_heatmap = bool(self.var_show_heatmap.get())
        self._refresh_option_visibility()
        self._ensure_axes(show_heatmap, force=True)

        coils = self.build_current_coils()
        I = float(self.var_I.get())
        bounds = estimate_bounds_from_coils(coils) if bool(self.var_auto_bounds.get()) else float(self.var_bounds_m.get())
        res = int(self.var_grid_res.get())
        soft = float(self.var_soft_m.get())
        qstep = int(self.var_quiver_step.get())
        arrow_scale = float(self.var_arrow_scale.get())

        backend_request = str(self.var_field_backend.get())
        sstcore_module = None
        use_sstcore = False
        backend_note = "NumPy softened"
        if backend_request != "NumPy softened":
            if not self._sstcore_checked:
                self._sstcore_module = try_import_sstcore()
                self._sstcore_checked = True
            sstcore_module = self._sstcore_module
            use_sstcore = sstcore_module is not None and hasattr(sstcore_module, "biot_savart_wire_grid")
            if backend_request == "SSTcore C++ fast" and not use_sstcore:
                messagebox.showwarning(
                    "SSTcore not available",
                    "SSTcore/sstcore with biot_savart_wire_grid was not found. Falling back to NumPy."
                )
            if use_sstcore:
                backend_note = f"SSTcore C++ ({getattr(sstcore_module, '__name__', 'sstcore')}; no GUI softening)"

        # cache key includes geometry arrays sampled by shape labels/lengths, not entire arrays
        lens_key = tuple((label, len(pts), tuple(np.round(pts[0], 9)) if len(pts) else None, tuple(np.round(pts[-1], 9)) if len(pts) else None, round(cmul, 6))
                         for pts, _c, _ls, label, cmul in coils)
        compute_key = (str(self.var_preset.get()), lens_key, round(I, 9), round(bounds, 9), res, round(soft, 12), backend_note)
        recompute = compute_key != self._cache_key

        if recompute:
            grid = make_grid(bounds, res)
            Bx = np.zeros_like(grid.X)
            By = np.zeros_like(grid.X)
            Bz = np.zeros_like(grid.X)
            for pts, _color, _ls, label, cmul in coils:
                if use_sstcore:
                    try:
                        bx, by, bz = biot_savart_wire_grid_sstcore(sstcore_module, grid, pts, current=I*cmul)
                    except Exception as exc:
                        backend_note = f"NumPy fallback after SSTcore error: {type(exc).__name__}"
                        bx, by, bz = biot_savart_wire_grid_chunked(grid, pts, current=I*cmul, r_softening=soft, chunk=96)
                        use_sstcore = False
                else:
                    bx, by, bz = biot_savart_wire_grid_chunked(grid, pts, current=I*cmul, r_softening=soft, chunk=96)
                Bx += bx; By += by; Bz += bz
            Bmag = np.sqrt(Bx*Bx + By*By + Bz*Bz) + 1e-30
            self._cache_key = compute_key
            self._cache = dict(grid=grid, Bx=Bx, By=By, Bz=Bz, Bmag=Bmag, bounds=bounds, backend_note=backend_note)
        else:
            grid = self._cache["grid"]
            Bx = self._cache["Bx"]
            By = self._cache["By"]
            Bz = self._cache["Bz"]
            Bmag = self._cache["Bmag"]
            backend_note = self._cache.get("backend_note", backend_note)

        # Compact null-proxy count for the log table. This is computed even when
        # the scatter visualization is hidden, so the log reflects the current
        # threshold/floor settings consistently.
        b_floor_log = max(0.0, float(self.var_b_floor.get()))
        null_map_log = 1.0 / (Bmag + b_floor_log + 1e-300)
        null_map_log = null_map_log / max(float(np.nanmax(null_map_log)), 1e-300)
        null_count = int(np.count_nonzero(null_map_log > float(self.var_null_threshold.get())))
        self._last_update_snapshot = {
            "coils": coils,
            "I": I,
            "bounds": bounds,
            "res": res,
            "backend_note": backend_note,
            "cache": "MISS" if recompute else "HIT",
            "B_p95": float(np.percentile(Bmag, 95)) if np.any(np.isfinite(Bmag)) else 0.0,
            "B_max": float(np.nanmax(Bmag)) if np.any(np.isfinite(Bmag)) else 0.0,
            "null_count": null_count,
        }
        self._append_update_log(coils, I, bounds, res, backend_note, recompute, Bmag, null_count)

        # Axes are freshly rebuilt above; no stale colorbar or legend axes remain.
        bclip = float(np.percentile(Bmag, 95)) if np.any(np.isfinite(Bmag)) else 1.0
        bclip = max(bclip, 1e-30)
        bnorm = Normalize(vmin=0.0, vmax=bclip)

        views = getattr(self, "ax3d_views", [(self.ax3d, "Perspective")])
        for i, (ax, view_name) in enumerate(views):
            self._draw_3d_scene(
                ax, view_name, coils, grid, Bx, By, Bz, Bmag,
                bounds=bounds, bnorm=bnorm, bclip=bclip,
                qstep=qstep, arrow_scale=arrow_scale,
                show_legend=bool(self.var_show_legend.get()) and i == 0,
            )

        for ax, plane in getattr(self, "ax_heatmaps", []):
            self._draw_heatmap(ax, plane, grid, Bmag, bounds)

        if views:
            sm = ScalarMappable(norm=bnorm, cmap=plt.cm.Blues)
            sm.set_array([])
            try:
                self.fig.colorbar(sm, ax=[ax for ax, _ in views], fraction=0.025, pad=0.02).set_label("|B| [T], clipped p95")
            except Exception:
                self.fig.colorbar(sm, ax=views[0][0], fraction=0.035, pad=0.02).set_label("|B| [T], clipped p95")

        self.fig.suptitle(
            f"{self.var_preset.get()} | drive={self.var_phase_drive.get()} | I={I:g} A | bounds={bounds:.3g} m | "
            f"res={res} | backend={backend_note} | cache={'MISS' if recompute else 'HIT'}",
            fontsize=10,
        )
        self.fig.tight_layout(rect=[0, 0, 1, 0.95])
        self.canvas.draw()
        self.lbl_status.config(text=f"Done. Coils={len(coils)}, grid={res}³, bounds={bounds:.4g} m.")

    # ------------------------------------------------------------------
    # Export functions
    # ------------------------------------------------------------------
    def save_png(self):
        fn = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG image", "*.png")],
                                          initialfile="rodin_GUI3_view.png")
        if not fn:
            return
        self.fig.savefig(fn, dpi=180, bbox_inches="tight")
        self.lbl_status.config(text=f"Saved PNG: {fn}")

    def export_csv(self):
        fn = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV file", "*.csv")],
                                          initialfile="rodin_GUI3_coils.csv")
        if not fn:
            return
        coils = self.build_current_coils()
        with open(fn, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["lane", "point_index", "x", "y", "z", "current_multiplier"])
            for pts, _color, _ls, label, cmul in coils:
                for i, p in enumerate(pts):
                    w.writerow([label, i, f"{p[0]:.12g}", f"{p[1]:.12g}", f"{p[2]:.12g}", f"{cmul:.12g}"])
        self.lbl_status.config(text=f"Exported CSV: {fn}")


def main():
    app = RodinGUI3()
    app.mainloop()


if __name__ == "__main__":
    main()
