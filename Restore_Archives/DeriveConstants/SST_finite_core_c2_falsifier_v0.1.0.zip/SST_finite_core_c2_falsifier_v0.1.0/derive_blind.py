#!/usr/bin/env python3
"""Blind finite-core variational derivation stage.

This program must not contain target constants. It computes a shell coefficient
from a declared core functional, scalarized contact-stress Hessian and cell
Hessians. External target scoring is performed only by score_target.py.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import yaml

from finite_core_falsifier.model import canonical_json_hash, derive_coefficients, sha256_file
from finite_core_falsifier.provenance import scan_text_files


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/reference.yaml")
    ap.add_argument("--output", default="outputs/blind_result.json")
    ap.add_argument("--allow-provenance-failure", action="store_true")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    cfg_path = (root / args.config).resolve() if not Path(args.config).is_absolute() else Path(args.config)
    out_path = (root / args.output).resolve() if not Path(args.output).is_absolute() else Path(args.output)
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))

    derivation_sources = [
        root / "derive_blind.py",
        root / "finite_core_falsifier" / "model.py",
        cfg_path,
    ]
    contact = cfg.get("contact", {})
    if contact.get("path"):
        derivation_sources.append((cfg_path.parent / str(contact["path"])).resolve())
    cell = cfg.get("cell", {})
    for key in ("parallel_path", "transverse_path"):
        if cell.get(key):
            derivation_sources.append((cfg_path.parent / str(cell[key])).resolve())

    hits = scan_text_files(derivation_sources)
    provenance = {
        "pass": len(hits) == 0,
        "hits": hits,
        "source_hashes": {str(p): sha256_file(p) for p in derivation_sources if p.exists()},
        "config_hash": canonical_json_hash(cfg),
    }
    if hits and not args.allow_provenance_failure:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps({"provenance": provenance, "status": "BLOCKED_TARGET_LEAKAGE"}, indent=2), encoding="utf-8")
        print(f"Blocked: forbidden target leakage detected. See {out_path}", file=sys.stderr)
        return 2

    result = derive_coefficients(cfg, cfg_path.parent)
    result["provenance"] = provenance
    result["config_path"] = str(cfg_path)
    result["status"] = "BLIND_DERIVATION_COMPLETE" if result["profile"]["success"] else "PROFILE_SOLVER_WARNING"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(out_path), "closure": result["closure"], "quality": result["derivation_quality"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
