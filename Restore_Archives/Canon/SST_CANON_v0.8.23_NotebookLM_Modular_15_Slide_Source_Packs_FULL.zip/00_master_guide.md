# Master guide - modular 15-slide NotebookLM source strategy

## Slide 1/15 - Why this package exists

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- NotebookLM repeatedly turns one large Canon into the same generic SST video.
- These packs constrain each generation to one narrow 15-slide narrative.
- The MAIN Canon remains authoritative; these are source windows, not new Canon.

**Single slide message:** NotebookLM repeatedly turns one large Canon into the same generic SST video.

**Source anchors:** README; all chapter PDFs; SST Canon v0.8.23.

**Visual specification:** Hub-and-spoke diagram: MAIN Canon in center, modules around it.

**Do not generate:** Do not upload all module PDFs into one notebook if the goal is a focused video.

## Slide 2/15 - Operational use pattern

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Open a fresh notebook for one chapter.
- Upload exactly one chapter PDF.
- Paste the matching NOTEBOOKLM_PROMPT text.
- Ask for exactly 15 slides and preserve the numbered order.

**Single slide message:** Open a fresh notebook for one chapter.

**Source anchors:** README; prompts.

**Visual specification:** Four-step workflow: choose PDF -> upload -> paste prompt -> generate.

**Do not generate:** Do not ask for an agenda or generic SST overview unless the chapter page asks for it.

## Slide 3/15 - Four chapter families

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Origin and provenance modules explain why SST exists.
- Foundational modules define primitives, axioms, and status labels.
- Canon physics modules explain topology, EM, delay, atoms, time, gravity, and synthesis.
- Research modules isolate open theorem targets and numerical programmes.

**Single slide message:** Origin and provenance modules explain why SST exists.

**Source anchors:** Package chapter list.

**Visual specification:** Four-row taxonomy with chapter numbers.

**Do not generate:** Do not flatten research-track material into locked Canon.

## Slide 4/15 - Recommended first reading order

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- 01 Genesis, 02 Prelude, 03 Foundations, 04 Axioms, 05 Classification.
- 06 Topology, 07 EM/link field, 08 Delay/QSS, 09 Atomic bridge, 10 Spectroscopy.
- 11 Time/gravity, 12 Unification, 13 Limits, 14-16 Research.

**Single slide message:** 01 Genesis, 02 Prelude, 03 Foundations, 04 Axioms, 05 Classification.

**Source anchors:** MAIN Canon order and research-track companion.

**Visual specification:** Numbered dependency ladder.

**Do not generate:** Do not start with particle mapping for a first-time audience.

## Slide 5/15 - When to use Genesis

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use for rediscovered impedance path and non-circularity.
- Use for 2012 notebook and 2013 proto-Canon provenance.
- Use to explain why vorticity came after resonance/impedance.

**Single slide message:** Use for rediscovered impedance path and non-circularity.

**Source anchors:** Author Origin Note; Genesis section; provenance register.

**Visual specification:** Notebook -> proto-Canon -> modern link-field pipeline.

**Do not generate:** Do not turn Genesis into biography only.

## Slide 6/15 - When to use Axioms

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use when the audience asks what SST assumes.
- Keep all eight axioms in order.
- Separate axioms from theorem targets and research tracks.

**Single slide message:** Use when the audience asks what SST assumes.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight pillar blocks.

**Do not generate:** Do not add hidden extra axioms.

## Slide 7/15 - When to use Topology

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use for KnotPlot, Ridgerunner, finite thickness, ropelength, struts and kinks.
- Use when explaining why an ideal-knot label is not a certificate.
- Use before particle-state claims.

**Single slide message:** Use for KnotPlot, Ridgerunner, finite thickness, ropelength, struts and kinks.

**Source anchors:** Geometric and Topological Sector; topology research appendices.

**Visual specification:** Thick tube around knot with contact map.

**Do not generate:** Do not show pretty knots as proof of particles.

## Slide 8/15 - When to use EM/link field

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use for photon/R-phase, relational torsion, and Maxwell-Faraday reconstruction.
- Keep link curvature distinct from material vorticity.
- Use for non-circular route to c_T and Z_link.

**Single slide message:** Use for photon/R-phase, relational torsion, and Maxwell-Faraday reconstruction.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action.

**Visual specification:** Two-layer field diagram: material vortex field and link field.

**Do not generate:** Do not import acoustic or compressional sound waves.

## Slide 9/15 - When to use Delay/QSS

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use for mode locking, delayed self-interaction, response kernels, linewidths, QSS.
- Use when a video should focus on spectra rather than foundations.
- Keep FFT peaks separate from certified modes.

**Single slide message:** Use for mode locking, delayed self-interaction, response kernels, linewidths, QSS.

**Source anchors:** Delay and Mode Selection; Swirl-String Response; QSS research track.

**Visual specification:** Delayed loop feeding complex-frequency poles.

**Do not generate:** Do not reduce QSS to black-hole QNM copy-paste.

## Slide 10/15 - When to use Atomic/Particle modules

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use for bridge Hamiltonian, electron-trefoil identity, particle candidates.
- Keep particle maps labelled as bridge/research where appropriate.
- Use spectroscopy module for constraints.

**Single slide message:** Use for bridge Hamiltonian, electron-trefoil identity, particle candidates.

**Source anchors:** Atomic Bridge; Particle-Candidate Mapping; Spectroscopy Constraints.

**Visual specification:** Vortex core inside atomic envelope.

**Do not generate:** Do not claim complete Standard Model derivation.

## Slide 11/15 - When to use Time/Gravity modules

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Use for Alice/Bob operational spacetime, clock fields, pressure gravity, tensor-speed gates.
- Separate substrate time from local proper time.
- Keep full Einstein dynamics as a theorem target.

**Single slide message:** Use for Alice/Bob operational spacetime, clock fields, pressure gravity, tensor-speed gates.

**Source anchors:** Relational Time Framework; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clock over substrate layer.

**Do not generate:** Do not claim full GR replacement as established.

## Slide 12/15 - Research-track usage rule

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Research PDFs are for open work, theorem targets, diagnostics, and numerical programmes.
- They preserve uncertainty and promotion gates.
- They should not be mixed into established Canon videos.

**Single slide message:** Research PDFs are for open work, theorem targets, diagnostics, and numerical programmes.

**Source anchors:** Research-track companion.

**Visual specification:** Promotion pipeline: Research -> benchmark -> proof -> Canon candidate.

**Do not generate:** Do not treat a research page as a theorem.

## Slide 13/15 - Anti-repetition: unique opening problem

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Each chapter begins with a different problem.
- Genesis starts with provenance; Axioms with assumptions; Topology with certification; Time/gravity with measurement.
- This blocks the repeated generic six-minute summary.

**Single slide message:** Each chapter begins with a different problem.

**Source anchors:** First pages of each source pack.

**Visual specification:** Grid of opening questions.

**Do not generate:** Do not begin every video with “What is Swirl-String Theory?”

## Slide 14/15 - Anti-repetition: visual vocabulary

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Genesis uses notebooks and ledgers.
- Axioms use pillars.
- Topology uses tubes/contact maps.
- EM uses link fields.
- Time/gravity uses clocks and pressure.
- Research uses gates and roadmaps.

**Single slide message:** Genesis uses notebooks and ledgers.

**Source anchors:** Visual specifications throughout packs.

**Visual specification:** Visual vocabulary table.

**Do not generate:** Do not use generic space-time grids for every chapter.

## Slide 15/15 - Master closing message

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- The package is a controlled input layer for Gemini Notebook.
- It keeps chapters narrow enough to generate distinct videos.
- It protects Canon status labels and dependency discipline.

**Single slide message:** The package is a controlled input layer for Gemini Notebook.

**Source anchors:** All source packs.

**Visual specification:** Binder with module tabs and source prompts.

**Do not generate:** Do not treat generated slides as canonical text.
