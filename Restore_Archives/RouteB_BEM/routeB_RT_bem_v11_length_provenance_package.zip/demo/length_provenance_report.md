# BEMv11 length-provenance report

This report is alpha-blind: it does not contain or compare with observed fine structure.

BEMv11 computes arclength directly from Fourier coefficients by

\[
L=\int_0^{2\pi}\|\mathbf{x}'(t)\|\,dt.
\]

It then audits the leading Route-B scale

\[
\alpha^{-1}_{\rm lead}=\frac{8\pi}{3}L.
\]

## Target summary

- `target`: `3_1`
- `target_id`: `3:1:1`
- `L_database`: `16.371637`
- `L_latest_derivative`: `16.3724604307158`
- `N_latest`: `32000`
- `L_extrapolated_best`: `16.372460430715797`
- `best_tail_p`: `6.0`
- `best_tail_rms`: `3.552713678800501e-15`
- `delta_latest_minus_database`: `0.0008234307158012655`
- `delta_extrapolated_minus_database`: `0.0008234307157977128`
- `alpha_inv_lead_database`: `137.15470540383689`
- `alpha_inv_lead_latest`: `137.16160376087024`
- `alpha_inv_lead_extrapolated`: `137.1616037608702`
- `delta_alpha_latest_minus_database`: `0.0068983570333500666`
- `delta_alpha_extrapolated_minus_database`: `0.006898357033321645`
- `status`: `ALPHA_BLIND_LEADING_LENGTH_AUDIT_NO_CODATA`

## Output files

- `length_convergence.csv`
- `length_extrapolation_fit.csv`
- `alpha_leading_length_audit.csv`

## Interpretation

If `L_latest_derivative` and `L_extrapolated_best` do not converge to the database Fourier arclength/provenance value, the leading Route-B alpha scale is not ppm-certified.