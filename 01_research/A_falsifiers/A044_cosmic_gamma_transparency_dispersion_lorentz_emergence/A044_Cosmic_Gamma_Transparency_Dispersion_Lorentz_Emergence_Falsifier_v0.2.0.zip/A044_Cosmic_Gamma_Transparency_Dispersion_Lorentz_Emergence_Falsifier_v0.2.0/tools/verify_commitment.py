from pathlib import Path
import hashlib, sys
p=Path(sys.argv[1] if len(sys.argv)>1 else "private/candidate.json")
c=Path("data/public/reveal_commitment_sha256.txt")
if not p.exists() or not c.exists():
    print("REVEAL SKIPPED: candidate or commitment missing"); raise SystemExit(3)
actual=hashlib.sha256(p.read_bytes()).hexdigest(); expected=c.read_text().strip()
if actual!=expected:
    print("REVEAL COMMITMENT FAIL",actual,expected); raise SystemExit(2)
print("REVEAL COMMITMENT PASS")
