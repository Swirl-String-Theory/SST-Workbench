"""SST relational-clock pre-canonisation check suite."""
__version__ = "0.1.0"
