#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, math
from pathlib import Path
from typing import Callable, Dict, List, Tuple
import numpy as np

FOUR_PI_3 = 4.0 * math.pi / 3.0
ALPHA_INV_COMPARISON = 137.035999177  # comparison only

KNOTS = [
    {"knot": "trefoil_3_1", "topology": "T(2,3) trefoil", "L_K": 16.371637},
    {"knot": "unknot_0_1", "topology": "ideal circle / unknot", "L_K": math.pi},
]

def write_csv(path: Path, rows: List[Dict]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

def surface_hessian_spectrum(lmax: int = 8) -> Tuple[int, List[Dict]]:
    rows, Np = [], 0
    for ell in range(lmax + 1):
        k_l = ell * (ell + 1) - 2
        mult = 2 * ell + 1
        active = k_l <= 0
        if active:
            Np += mult
        rows.append({
            "ell": ell,
            "multiplicity": mult,
            "surface_hessian_eigenvalue_k_l": k_l,
            "active_pressure_sector": active,
            "classification": "scalar compression" if ell == 0 else
                              "translation zero-mode triplet" if ell == 1 else
                              "positive shape mode",
        })
    return Np, rows

def pressure_energy_eta(eta: float, E0: float, sigma: float, c4: float = 0.0) -> float:
    return E0 * (1.0 - sigma * eta * eta + c4 * eta**4)

def pressure_eta_hessian(E0: float, sigma: float, c4: float = 0.0, h: float = 1e-5) -> Dict:
    Em = pressure_energy_eta(-h, E0, sigma, c4)
    E = pressure_energy_eta(0.0, E0, sigma, c4)
    Ep = pressure_energy_eta(h, E0, sigma, c4)
    H_num = (Ep - 2.0 * E + Em) / (h * h)
    H_exact = -2.0 * sigma * E0
    return {
        "pressure_eta_hessian_numeric": H_num,
        "pressure_eta_hessian_exact_model": H_exact,
        "relative_error_numeric_vs_exact": abs(H_num - H_exact) / max(abs(H_exact), 1e-300),
        "status": "CONDITIONAL_PRESSURE_MODE_MODEL_NOT_PRIMITIVE_DERIVATION",
    }

def integrate_phase_hessian(a: float, R: float, n_of_r: Callable[[np.ndarray], np.ndarray], n_grid: int = 20000) -> Dict:
    r = np.linspace(a, R, n_grid)
    n = np.maximum(np.asarray(n_of_r(r), dtype=float), 1e-300)
    denom = float(np.trapezoid(1.0 / (n * r * r), r))
    Lambda = 4.0 * math.pi / denom
    K_cell = Lambda / (4.0 * math.pi * R)
    return {"a_inner": a, "R_outer": R, "Lambda_phi": Lambda, "K_cell": K_cell, "denominator_integral": denom}

def phase_profiles(a: float, R: float, E_eff: float):
    # For n=M/[4*pi(R-a)r^2], Lambda=M/(R-a)^2.
    M_target = 0.5 * E_eff * (R - a)**2
    def uniform(r): return np.ones_like(r)
    def rminus2_unit(r):
        M = 1.0
        return M / (4.0 * math.pi * (R - a) * r**2)
    def rminus2_target(r):
        return M_target / (4.0 * math.pi * (R - a) * r**2)
    def gp_like(r):
        width = max(0.05 * (R - a), 1e-6)
        return np.tanh((r - a) / width)**2 + 1e-12
    return [
        ("uniform_n1", "operator_output_mismatch_expected", uniform),
        ("rminus2_unit_budget", "operator_output_mismatch_expected", rminus2_unit),
        ("rminus2_target_budget", "IDENTITY_CHECK_TARGET_BUDGET_NOT_EVIDENCE", rminus2_target),
        ("gp_like_boundary_layer", "toy_profile_mismatch_expected", gp_like),
    ]

def compute_for_knot(knot: Dict, Np: int, mu: float, sigma: float, c4: float, R_outer: float, n_grid: int):
    L = float(knot["L_K"])
    chi_R = math.sqrt(mu * Np)
    E0 = Np * FOUR_PI_3 * L
    eta_K = 1.0 / (2.0 * chi_R * L)
    c2 = sigma / (4.0 * chi_R**2)
    E_eff = E0 * (1.0 - c2 / (L * L) + c4 / (L**4))
    alpha_inv_leading = E0 / 2.0
    alpha_inv_corrected = E_eff / 2.0
    rel_err_leading = (alpha_inv_leading - ALPHA_INV_COMPARISON) / ALPHA_INV_COMPARISON
    rel_err_corrected = (alpha_inv_corrected - ALPHA_INV_COMPARISON) / ALPHA_INV_COMPARISON
    p_hess = pressure_eta_hessian(E0, sigma=sigma, c4=c4)

    a_inner = max(eta_K * R_outer, 1e-7)
    target_Lambda = E_eff / 2.0
    target_K = E_eff / (8.0 * math.pi * R_outer)
    phase_rows = []
    for profile_name, profile_status, func in phase_profiles(a_inner, R_outer, E_eff):
        res = integrate_phase_hessian(a_inner, R_outer, func, n_grid=n_grid)
        ratio_Lambda = res["Lambda_phi"] / target_Lambda
        ratio_K = res["K_cell"] / target_K
        if profile_name == "rminus2_target_budget":
            gate_status = "PASS_IDENTITY_CHECK_TARGET_BUDGET_NOT_EVIDENCE"
        elif abs(ratio_Lambda - 1.0) < 1e-2:
            gate_status = "NEAR_TARGET_PROFILE_NEEDS_MICROSCOPIC_JUSTIFICATION"
        else:
            gate_status = "OPEN_MISMATCH"
        phase_rows.append({
            "knot": knot["knot"], "profile": profile_name, "profile_status": profile_status,
            "a_inner": res["a_inner"], "R_outer": res["R_outer"],
            "Lambda_phi": res["Lambda_phi"], "target_Lambda_Eeff_over_2": target_Lambda,
            "Lambda_ratio_to_target": ratio_Lambda, "K_cell": res["K_cell"],
            "target_K_Eeff_over_8piR": target_K, "K_ratio_to_target": ratio_K,
            "gate3_status": gate_status,
        })

    summary = {
        "knot": knot["knot"], "topology": knot["topology"], "L_K": L,
        "N_p": Np, "mu": mu, "chi_R": chi_R, "eta_K": eta_K,
        "E0_pressure_leading": E0, "sigma_conditional": sigma,
        "c2_conditional": c2, "E_eff_conditional": E_eff,
        "alpha_inv_leading": alpha_inv_leading,
        "rel_err_leading_vs_alpha_inv_comparison": rel_err_leading,
        "alpha_inv_corrected_conditional": alpha_inv_corrected,
        "rel_err_corrected_vs_alpha_inv_comparison": rel_err_corrected,
        "near_fine_structure_scale_leading_1e_minus_3": abs(rel_err_leading) < 1e-3,
        "near_fine_structure_scale_corrected_1e_minus_3": abs(rel_err_corrected) < 1e-3,
        "pressure_eta_hessian_numeric": p_hess["pressure_eta_hessian_numeric"],
        "pressure_eta_hessian_exact_model": p_hess["pressure_eta_hessian_exact_model"],
        "pressure_eta_hessian_status": p_hess["status"],
        "interpretation": (
            "trefoil_close_to_alpha_scale" if knot["knot"].startswith("trefoil") and abs(rel_err_corrected) < 1e-3 else
            "unknot_not_alpha_scale_in_this_finite_cell_formula" if knot["knot"].startswith("unknot") else
            "not_alpha_scale"
        )
    }
    pressure_rows = [{
        "knot": knot["knot"], "E0": E0, "sigma": sigma, "c4": c4, **p_hess,
        "note": "H_eta is conditional pressure-mode eta-Hessian; sigma must be derived by real pressure-mode operator."
    }]
    return summary, pressure_rows, phase_rows

def make_report(outdir: Path, summaries: List[Dict], Np: int) -> None:
    lines = []
    lines.append("# Three Hessian Gate Audit: trefoil versus unknot\n")
    lines.append("This is an audit script, not a theorem-complete derivation.\n")
    lines.append("## H1. Surface Hessian")
    lines.append(r"The surface Hessian eigenvalues are \(k_\ell=\ell(\ell+1)-2\).")
    lines.append(f"The active pressure-sector count is \\(N_p={Np}\\).\n")
    lines.append("## H2. Pressure eta-Hessian")
    lines.append(r"The script computes \(H_\eta=d^2E_{\rm pressure}/d\eta^2|_{\eta=0}=-2\sigma E_0\) for the conditional pressure model.")
    lines.append("This does not derive \\(\\sigma=11/3\\); it isolates the Hessian object needed for the BEM/NLS pressure-mode eta-scan.\n")
    lines.append("## H3. Phase Hessian / impedance")
    lines.append(r"The radial phase Hessian is \(\Lambda_\phi=4\pi/\int_a^R dr/[n(r)r^2]\).")
    lines.append("Target-budget profiles pass by construction and are labeled as identities, not evidence.\n")
    lines.append("## Fine-structure-scale comparison")
    for s in summaries:
        lines.append(f"### {s['knot']}")
        lines.append(f"- L_K = {s['L_K']:.12g}")
        lines.append(f"- leading alpha inverse = {s['alpha_inv_leading']:.12g}")
        lines.append(f"- conditional corrected alpha inverse = {s['alpha_inv_corrected_conditional']:.12g}")
        lines.append(f"- interpretation = `{s['interpretation']}`")
    lines.append("\nConclusion: in the current finite-cell formula, the unknot does not produce the observed fine-structure scale. The exterior far-field carrier may be unknotted/H^0-like, but the source-cell energy scale remains trefoil-like for the electron benchmark.")
    (outdir / "three_hessian_gate_report.md").write_text("\n".join(lines), encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="outputs_three_hessian_gate_audit")
    ap.add_argument("--lmax", type=int, default=8)
    ap.add_argument("--mu", type=float, default=1.0)
    ap.add_argument("--sigma", type=float, default=11.0/3.0, help="Conditional pressure-mode target sigma. Not derived.")
    ap.add_argument("--c4", type=float, default=0.0)
    ap.add_argument("--R-outer", type=float, default=1.0)
    ap.add_argument("--n-grid", type=int, default=20000)
    args = ap.parse_args()

    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    Np, surface_rows = surface_hessian_spectrum(args.lmax)
    write_csv(outdir / "surface_hessian_spectrum.csv", surface_rows)

    summaries, pressure_all, phase_all = [], [], []
    for knot in KNOTS:
        summary, pressure_rows, phase_rows = compute_for_knot(knot, Np, args.mu, args.sigma, args.c4, args.R_outer, args.n_grid)
        summaries.append(summary); pressure_all.extend(pressure_rows); phase_all.extend(phase_rows)

    write_csv(outdir / "three_hessian_comparison_summary.csv", summaries)
    write_csv(outdir / "pressure_eta_hessian_summary.csv", pressure_all)
    write_csv(outdir / "phase_hessian_impedance_profiles.csv", phase_all)
    make_report(outdir, summaries, Np)

    print("=" * 76)
    print("Three Hessian Gate Audit complete")
    print("=" * 76)
    print(f"N_p from surface Hessian: {Np}")
    for s in summaries:
        print(f"{s['knot']:14s} L_K={s['L_K']:.8g} alpha_inv_leading={s['alpha_inv_leading']:.8g} alpha_inv_corrected={s['alpha_inv_corrected_conditional']:.8g} {s['interpretation']}")
    print("\nKey status:")
    print("  H1 surface Hessian: N_p=4 derived.")
    print("  H2 pressure Hessian: object isolated; sigma=11/3 still conditional.")
    print("  H3 phase Hessian: operator implemented; target-budget pass is identity, not evidence.")
    print(f"\nOutputs written to: {outdir}")

if __name__ == "__main__":
    main()
