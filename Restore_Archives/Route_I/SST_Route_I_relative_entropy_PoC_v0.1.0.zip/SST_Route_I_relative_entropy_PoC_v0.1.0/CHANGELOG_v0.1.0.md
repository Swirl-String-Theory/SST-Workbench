# Changelog v0.1.0

## Why this is v0.1.0 rather than v0.0.9

Version 0.1.0 begins a new research phase. Versions 0.0.1--0.0.8 built and
falsified candidate routes from the effective torsion sector toward a unique
link coupling. Version 0.1.0 moves from algebraic coupling selectors to an
explicit resolved-carrier action calculation.

## Added

- Added the preregistered geometry ladder:
  `round ring -> resolved axisymmetric torus -> 3_1 -> mirror 3_1 -> 4_1`.
- Added a trimmed, hashable geometry source extracted from the current
  `ideal_favorites.txt` entries `0:1:1`, `3:1:1`, and `4:1:1`.
- Added exact action-convention separation:
  \[
  I=(2\pi)^{-1}\oint p\,dq,\qquad
  \mathscr A_{\rm cycle}=\oint p\,dq=2\pi I.
  \]
- Added the Rankine-rotor result
  \[
  I_{\rm rot}=L_{\rm core}=2E/\Omega,
  \]
  demonstrating that `E/Omega` is not generally the canonical action.
- Added resolved-tube energy, angular momentum, total action, full-cycle action,
  and action-per-ropelength calculations for the full ladder.
- Added parity checks for `3_1` versus its mirror.
- Added a Rosenhead-regularized Biot--Savart energy and relative-equilibrium
  diagnostic for each static atlas geometry.
- Added the local adjacency-cell matching equation
  \[
  \hbar\beta_Q=j_\phi a_\star(\beta_Q),
  \]
  and its unique conditional fixed point.
- Added a core-radius sensitivity scan over
  \(a_{\rm core}/r_c=0.25\ldots1.00\).
- Added explicit Coulomb-precertification and monometricity comparators.
- Added 13 automated theorem and provenance gates.
- Added a Research-Track CANON patch.

## Changed

- The object matched to \(\hbar\beta_Q\) is now the normalized action variable
  \(I\), not the full cycle integral and not automatically \(E/\Omega\).
- Total knot action is no longer assumed to be a universal link coupling.
  The calculation now distinguishes a global carrier action from a local
  adjacency-cell action.
- Static ideal-knot embeddings are treated as geometry inputs only. They are
  not assigned a recurrence frequency unless they pass a dynamical
  relative-equilibrium gate.

## Results

- The total Rankine-rotor action is species dependent:
  \[
  I_K/\hbar\simeq1.5707\;(0_1),\quad
  4.0917\;(3_1),\quad
  5.2584\;(4_1).
  \]
- The mirror trefoil agrees with the trefoil to numerical precision.
- The action density per unit ropelength is constant in the frozen uniform-core
  model, while the total action is not universal.
- The round ring passes as a rigidly translating relative equilibrium.
  The static ideal trefoil and figure-eight fail the 5% dynamical gate.
- The baseline local-cell match gives
  \[
  \beta_Q=4.5917160651,
  \quad a_\star/r_c=18.3668660,
  \quad c_T/c=0.06701475.
  \]
- This fixed point is Coulomb-compatible under the inherited finite-volume
  pre-gate, but it does not produce observed \(c\) and does not close the area
  density.
- The phase verdict depends strongly on the unresolved local core radius.

## Removed or rejected

- Rejected the equality `E/Omega = action` as a general rule.
- Rejected total-knot-action universality for the frozen Rankine tube model.
- Rejected extraction of a knot recurrence frequency from a static atlas shape
  that fails the relative-equilibrium gate.

## Open after v0.1.0

- Derive the local material density and core profile independently of the
  horn-envelope calibration.
- Derive \(a_{\rm core}/r_c\).
- Construct a certified periodic or relative-periodic orbit for `3_1` and `4_1`.
- Compute the reduced Floquet/action spectrum and test whether a local action
  quantum is species independent.
- Reconcile any selected \(\beta_Q\) with monometricity and the area coefficient.
