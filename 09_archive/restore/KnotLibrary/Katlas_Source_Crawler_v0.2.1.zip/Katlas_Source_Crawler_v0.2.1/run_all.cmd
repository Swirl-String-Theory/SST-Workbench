@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo SST Katlas Source Crawler v0.2.1
echo RDF download - offline catalog - validation
echo ============================================================
if not exist .venv\Scripts\python.exe (
  echo [1/4] Creating virtual environment...
  py -3 -m venv .venv || exit /b 1
) else (
  echo [1/4] Virtual environment already exists.
)
echo [2/4] Downloading official Katlas RDF datasets...
.venv\Scripts\python.exe -m katlas_source.cli --config config.json download || exit /b 1
echo [3/4] Building folder tree and offline catalogs...
.venv\Scripts\python.exe -m katlas_source.cli --config config.json build || exit /b 1
echo [4/4] Validating...
.venv\Scripts\python.exe -m katlas_source.cli --config config.json validate || exit /b 1
echo ============================================================
echo DONE
echo ============================================================
