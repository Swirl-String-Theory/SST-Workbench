"""Windows-safe local build helper for the SST ideal-trefoil Biot-Savart pybind11 backend.

The helper first uses the bundled headers at vendor/pybind11/include when present.
If they are absent, it falls back to an installed `pybind11` package.
"""
from __future__ import annotations

import glob
import os
import sys
from typing import Optional

MODULE_NAME = "sst_trefoil_biot"
CPP_FILENAME = "sst_trefoil_biot.cpp"


def base_dir(script_dir: Optional[str] = None) -> str:
    return script_dir or os.path.dirname(os.path.abspath(__file__))


def needs_recompile(script_dir: Optional[str] = None) -> bool:
    base = base_dir(script_dir)
    src = os.path.join(base, CPP_FILENAME)
    if not os.path.exists(src):
        return False
    binaries = [
        f for f in glob.glob(os.path.join(base, f"{MODULE_NAME}.*"))
        if f.endswith(".pyd") or f.endswith(".so")
    ]
    if not binaries:
        return True
    return os.path.getmtime(src) > max(os.path.getmtime(f) for f in binaries)


def _include_dirs(base: str):
    local_include = os.path.join(base, "vendor", "pybind11", "include")
    if os.path.exists(os.path.join(local_include, "pybind11", "pybind11.h")):
        return [local_include]
    try:
        import pybind11
        return [pybind11.get_include()]
    except ImportError as exc:
        raise ImportError(
            "pybind11 headers not found. Keep vendor/pybind11/include in this package or run `pip install pybind11`."
        ) from exc


def build_module(script_dir: Optional[str] = None):
    from setuptools import Extension, setup
    base = base_dir(script_dir)
    print(f"[*] Building {MODULE_NAME} C++ module via pybind11...")
    c_args = ["/O2", "/std:c++14"] if os.name == "nt" else ["-O3", "-std=c++14"]
    ext_modules = [
        Extension(
            MODULE_NAME,
            [CPP_FILENAME],
            include_dirs=_include_dirs(base),
            language="c++",
            extra_compile_args=c_args,
        )
    ]
    old_cwd = os.getcwd()
    old_argv = list(sys.argv)
    try:
        os.chdir(base)
        sys.argv = ["setup.py", "build_ext", "--inplace", "--build-temp", "_build_tmp"]
        setup(name=MODULE_NAME, ext_modules=ext_modules, script_args=["build_ext", "--inplace", "--build-temp", "_build_tmp"])
    finally:
        os.chdir(old_cwd)
        sys.argv = old_argv


def import_module(*, auto_build: bool = True, script_dir: Optional[str] = None):
    if auto_build and needs_recompile(script_dir):
        build_module(script_dir)
    import importlib
    return importlib.import_module(MODULE_NAME)


if __name__ == "__main__":
    if "--force" in sys.argv:
        build_module()
    elif needs_recompile():
        build_module()
    else:
        print(f"[*] {MODULE_NAME} is already up to date. Use --force to rebuild.")
