# A046 v0.2.0 blind report

Backend: **python**
Overall: **PIPELINE_QUALIFIED**

HWC basis: **REJECTED_AS_LOCAL_COMPLETE_BASIS**
UWS basis: **LOCAL_FIRST_ORDER_KINEMATICS_RECONSTRUCTED_NOT_VALIDATED_AS_GRAVITY**

## Three-layer chain

1. u -> clock/transport input
2. (omega_rel, S_ij) -> local first-order kinematics
3. Q_transport -> Phi_bulk through Poisson inversion

Rotation: omega_abs = omega_rel + 2 Omega_p.
Delay: Gamma(t)-Gamma(t-tau), Delta phi = omega*tau.

## Key measurements

- max |div u| = 2.775558e-15
- HWC equality error = 0.000000e+00
- strain-pair distance = 5.656854e-01
- UWS gradient reconstruction max relative L2 = 6.304149e-17
- exact pressure/clock lock relative L2 = 0.000000e+00
- Poisson reconstruction relative L2 = 2.846161e-16
- nonlocal Phi energy fraction = 6.546745e-02
- ABC curvature RMS = 2.325678e-03
- planetary flat-control curvature RMS = 0.000000e+00
- hemisphere mirror relative L2 = 0.000000e+00
- rotating objectivity relative L2 = 1.488012e-16
- delay phase error = 8.881784e-16 rad
- delay memory RMS = 5.048025e-01

## Gates

- G01_INCOMPRESSIBILITY: PASS
- G02_HWC_DEGENERACY_FOUND: PASS
- G03_UWS_DISTINGUISHES_PAIR: PASS
- G04_CLOCK_PRESSURE_EXACT_LOCK: PASS
- G05_POISSON_RECONSTRUCTION: PASS
- G06_POISSON_NONLOCALITY: PASS
- G07_METRIC_LORENTZ_SIGNATURE_ABC: PASS
- G08_METRIC_LORENTZ_SIGNATURE_NULL: PASS
- G09_NULL_CURVATURE: PASS
- G10_NONUNIFORM_CURVATURE: PASS
- G11_RIEMANN_PAIR_SYMMETRY: PASS
- G12_OBJECTIVITY: PASS
- G13_UWS_GRADIENT_RECONSTRUCTION: PASS
- G14_ABSOLUTE_VORTICITY_IDENTITY: PASS
- G15_HEMISPHERE_CYCLONIC_MIRROR: PASS
- G16_ZERO_ROTATION_LIMIT: PASS
- G17_ROTATING_OBJECTIVITY: PASS
- G18_PLANETARY_BACKGROUND_FLAT_CONTROL: PASS
- G19_DELAY_PHASE_RECOVERY: PASS
- G20_DELAY_ZERO_LIMIT: PASS
- G21_DELAY_MEMORY_NONTRIVIAL: PASS

## Scientific guard

Passing qualifies the preregistered kinematic, rotating-frame, delay, Poisson, and exploratory-geometry controls only. It does not establish physical gravity, a spacetime metric, or a universal coupling law.
