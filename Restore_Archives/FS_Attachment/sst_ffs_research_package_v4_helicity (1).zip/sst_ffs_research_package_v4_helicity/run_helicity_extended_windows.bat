@echo off
setlocal enabledelayedexpansion
if "%PYTHON%"=="" set PYTHON=python
for %%N in (512 768 1024) do (
  %PYTHON% scripts\sst_ffs_05_helicity_batch.py --ideal-file data\ideal.txt --config data\helicity_knot_config.csv --samples %%N --chunk 256 --outdir results_helicity_N%%N
  if errorlevel 1 exit /b 1
)
echo Done. Compare results_helicity_N512, N768, N1024.
