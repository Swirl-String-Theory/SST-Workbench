from pathlib import Path
import argparse, json
p=argparse.ArgumentParser(); p.add_argument('--campaign',required=True); p.add_argument('--config',required=True); a=p.parse_args()
cfg=json.loads(Path(a.config).read_text(encoding='utf-8'))
policy=cfg.get('backend_policy','prefer_native')
if policy in ('require_native','require_openmp'):
    try:
        from a054_blind import _native as n
    except Exception as e:
        raise RuntimeError('isolated runner cannot import native backend: '+repr(e)) from e
    if policy=='require_openmp' and not bool(getattr(n,'openmp_enabled',False)):
        raise RuntimeError('isolated runner native backend has OpenMP disabled: '+str(getattr(n,'__file__',None)))
    print('ISOLATED_NATIVE', {'file':str(getattr(n,'__file__',None)), 'openmp':bool(getattr(n,'openmp_enabled',False))})
from a054_blind.certify_v020 import run_certification
run_certification(Path(a.campaign),Path(a.config))
