#!/usr/bin/env bash
set -euo pipefail
python sst_route1_nonlinear_adjacency_phase_v0.0.7.py --output-dir output_v0.0.7
