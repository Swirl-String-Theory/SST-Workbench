# Source Audit v0.0.5

## Current source support

The active v0.8.28 Research Track supports three ingredients relevant to the
parallel programme:

- Route I explicitly identifies line-piercing entropy and vacuum line density as
  open coefficient targets.
- The compact link-field section distinguishes a literal fixed lattice, a
  regulator continuum limit, and relational/dynamical adjacency. Scenario C
  explicitly shifts the burden to an emergent correlation cone without a
  preferred microscopic spacing.
- The geometric/topological sector supplies protected boundary classes and knot
  labels, but no microstate degeneracy remotely sufficient to fix the
  gravitational area coefficient.

## New v0.0.5 analysis

1. Correlated Gaussian cells are used as a response model. The fixed-alphabet
   capacity bound is a model-independent counting guard.
2. Exponential knot-type growth is used only as a generous asymptotic audit;
   no extrapolated knot count is promoted to SST microphysics.
3. Weyl boundary-mode counting is used as the orthodox leading spectral count.
4. The observed Newton constant is used only to state the external deficit and
   inverse target. No candidate SST length is constructed from G or L_p.

## Conclusion

The three mechanisms are structurally related through the entropy budget, but
represent distinct microscopic tasks. v0.0.5 therefore retains all three in
parallel while forbidding correlation, hidden-mode, and topological labels from
being counted more than once.
