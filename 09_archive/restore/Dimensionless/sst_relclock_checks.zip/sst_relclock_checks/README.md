# SST relational-clock pre-canonisation checks

Numerical harness for the six blocking checks required before any part of the
relational / entropic-time construction of

> G. Barontini, *Testing the problem of time with cold atoms*,
> Phys. Rev. Research **8**, L022047 (2026), DOI 10.1103/1h9j-df4k

may be imported into the SST canon or its research-track companion.

**This suite does not test SST.** It tests whether a candidate import is a
well-defined observable at all. Every check is written so that a negative
result is as informative as a positive one, and the verdict strings are
generated from the data rather than asserted.

---

## Quick start

Windows:

```bat
run_all.bat              REM standard profile, all six checks
run_all.bat quick        REM ~1 min smoke run
run_all.bat full         REM high-resolution run
```

Linux / macOS:

```bash
./run_all.sh             # or: ./run_all.sh quick | ./run_all.sh full
```

Manual:

```bash
python -m pip install -r requirements.txt
python -m pytest -q tests          # 20 analytic self-tests, all must pass
python main.py --profile standard --out results_standard
python main.py --checks 2 3 --a 0.02 --v-floor 1e-4   # subset, re-declared params
```

Outputs land in `results_<profile>/`:

| file | contents |
|---|---|
| `REPORT.md` | human-readable audit report, tables and verdicts |
| `results.json` | full machine-readable record incl. all declared parameters |
| `check1_clock_scores.csv` | clock score table for spreadsheet use |
| `figures/*.png` | five diagnostic figures |

A completed reference run is bundled in `reference_run/` for comparison.

---

## Declared parameters

No regularisation parameter is implicit. Everything below is recorded verbatim
into `results.json`.

| parameter | flag | meaning |
|---|---|---|
| `a` | `--a` | core / Rosenhead–Moore regularisation radius (reduced units) |
| `v_floor` | `--v-floor` | velocity floor; `0` disables |
| `dt` | from `cfl · δ²/Γ` | timestep, δ = mean edge length |
| `N` | profile | filament nodes |
| `resample_every` | per-variant | arclength re-equidistribution; **dissipative**, reported as such |
| `n_star` | `--n-star` | bright/dark spectral cutoff (number of bright modes) |
| `seed` | `--seed` | ensemble perturbation seed |

**Units.** The integrator runs in reduced units with Γ = 1 and curve scale ≈ 1.
SST units enter *only* through the clock prefactors `t_c/Q_c`. Check 1 verifies
numerically that those prefactors cancel identically — which is the point.

---

## What each check does, and how to read it

### Check 6 — constant chain / CODATA hygiene
Builds the whole chain `(α, c, ℏ, mₑ) → v_swirl → ω_c → r_c → t_c → Γ₀ → Z_c →
F_max → E_c` from one declared CODATA release, then:

* **tautology ledger** — closes each "new scale" against its algebraic
  identity. All residuals ~1e-16 means `t_c`, `E_c`, `Γ₀`, `Z_c` are
  restatements of the Compton closure, not independent scales.
  Label: `[CALIBRATED ALGEBRAIC IDENTITY]`, never `[DERIVED]`.
* **anchor deviations** — canon anchors vs the exact chain, with the index of
  the first wrong significant digit.
* **proposed-value audit** — recomputes externally supplied numbers both from
  the canon anchors and from the exact chain, and reports how many significant
  digits are actually justified.

### Check 2 — helicity on a material tube (audit point M2)
`H = Γ² · Lk` for a thin uniformly framed tube (Moffatt–Ricca). `Lk = Wr + Tw`
(Călugăreanu–White–Fuller). The test is **not** whether `Wr` is constant — it
is whether the *sum* is frozen while writhe and twist exchange.

Read: `cancellation_ratio = min(range Wr, range Tw) / drift Lk`, and the
timestep ladder. A high ratio **plus** monotone convergence under refinement
means the residual is discretisation error, so `τ_H ≡ 0` in ideal dynamics and
`τ_H` is a reconnection counter, not a clock. The `with_resampling` and
`with_v_floor` rows show how much apparent `τ_H` pure numerical dissipation
manufactures.

### Check 3 — cutoff scan of the enstrophy clock (audit point M3)
Two *independent* `a`-dependencies, deliberately separated:

1. **definitional** — one fixed trajectory, `a` varied only inside
   `Z = Γ²L/(2πa²)`. Prediction: log–log slope exactly −2.
2. **dynamical** — `a` also changes the Biot–Savart regularisation, so the
   trajectory itself moves. This second sensitivity must be declared separately.

Also reports `max |τ̂_Z − τ̂_L|` after [0,1] normalisation. If that is ~1e-15,
the enstrophy clock *is* a rescaled length clock at fixed core radius.

### Check 4 — mode-basis robustness
`S_spec` and `τ_F` are computed in three bases (curvature, torsion, position
spectra) and the ensemble run-ordering is compared by Spearman ρ. **ρ ≥ 0.9 is
required** to treat `S_spec` as an observable. Below that, the clock is a
property of the chosen basis and must not be canonised without a
basis-selection principle derived from the substrate.

### Check 5 — Loschmidt reversal
Evolve to `t★`, flip the velocity, continue. Reports geometric return error,
`Lk` / `L` / `E` return errors, and — separately, as the audit requires — the
**signed** clock `τ̃_Q` and the **unsigned** clock `τ_Q`. Ideal outcome: tiny
return error, `τ̃_Q → 0`, and `τ_Q(2t★)/τ_Q(t★) → 2` exactly. That combination
proves the monotonicity of `τ_Q` is a construction artefact, not an arrow of
time. The three variants separate genuine irreversibility from numerical
dissipation (resampling) and from coarse-graining hysteresis.

### Check 1 — null-model benchmark (BLOCKING)
Every clock is normalised to [0,1] before scoring, so
`ℰ = ∫₀¹ Var_runs[Ŷ(τ̂)] dτ̂` is dimensionless and comparable across clocks.
Clocks are built from a spectral/flux driver pool; scoring uses **held-out
observables** (`kappa_max`, `Wr`, `Rg`) and a **held-out half of the ensemble**.

Two nulls:

* **null-A** — one shared random monotone warp. Weak: answers only "does *some*
  monotone reparametrisation help?".
* **null-B** — a random unit functional `w·Y` over the *same* driver pool,
  turned into a per-run activity clock `∫|d(w·Y)|`. `τ_Q` is one particular
  choice of `w`, so this is the matched null. **`p_nullB_matched` is the only
  number that licenses a claim.**

Beating lab time is not a result: `τ_Q` is by construction a monotone warp of
`t`, and monotone warps generically improve ensemble collapse. That is curve
registration, not physics.

---

## Reference-run results (profile `standard`, N=96, a=0.05, cfl=0.05, CODATA 2022)

| check | outcome |
|---|---|
| 6 | tautology ledger closes to ~1e-16. Anchor `r_c` wrong from significant digit **9** (`+6.94e-09`), `v_swirl` from digit 10, `F_max` from digit 7. Confirms patch `0004`. |
| 2 | `Wr` range 0.0513, `Tw` range 0.0589, `Lk` drift 7.5e-03; best cancellation ratio **47.3**; dt-ladder 7.5e-03 → 4.0e-04 → 2.4e-05. **M2 CONFIRMED.** |
| 3 | definitional slope **−2.000000**; dynamical slope −2.050; `max\|τ̂_Z − τ̂_L\|` = **3.9e-15**. **M3 CONFIRMED.** |
| 4 | minimum cross-basis Spearman ρ = **−0.273**. **NEGATIVE** — `S_spec` is not basis-robust. |
| 5 | geometric return error 7.5e-16, `τ̃_Q` returns to 1.2e-11, `τ_Q` ratio **2.000**. Monotonicity is a construction artefact. |
| 1 | prefactor-invariance residual **0.000e+00**. Best clock `τ_Ebright` ℰ=0.5344 vs lab time 0.5357 vs null-B median 0.6032, p05 0.5290 → `p_nullB = 0.096`. **NEGATIVE: no clock beats the matched null.** Both signed clocks come back `UNUSABLE (non-monotone)`. `τ_L` and `τ_Z` score identically. |

### Consequences for canonisation

1. Nothing here reaches `[DERIVED]`. The clock constructions stay
   `[SPECULATIVE]` / `[RESEARCH-TRACK]`.
2. The M2 negative is the one genuinely publishable result, and it is
   `[ORTHODOX]` in its mathematics (Moffatt 1969; Călugăreanu–White–Fuller) and
   `[DERIVED NEGATIVE]` as an SST statement.
3. `τ_Q` as an unsigned activity variable is **inconsistent** with the canon's
   own conserved-current definition of relational time
   (`∂_μ T ≈ ν₀⁻¹⟨j^ev_μ⟩`); only the signed `τ̃_Q` has that form, and check 1
   shows the signed variant is non-monotone and therefore unusable as a
   reparametrisation. That tension is the central open problem, not a detail.
4. `S_spec` / `τ_F` are blocked by check 4 until a substrate-derived
   basis-selection principle exists.

---

## Self-tests

`tests/test_selftests.py` contains 20 analytic acceptance gates, including:

* circle: `κ ≡ 1`, `τ ≡ 0`, `Wr = 0` exactly;
* trefoil: `Lk = Wr + Tw → −3`, integrality defect 6.0e-02 → 1.2e-02 → 2.4e-03
  → 4.2e-04 → 6.0e-05 for N = 48…768 — the joint acceptance gate for both the
  writhe and the twist implementations;
* vortex ring self-propagates rigidly (length, energy, gyration radius all
  conserved to <1e-4);
* `Lk` drift converges under timestep refinement;
* integer twist offsets shift `Tw` exactly; non-integer offsets are rejected;
* enstrophy scales as `a⁻²` to machine precision;
* the collapse score is invariant under clock rescaling by 1.234e-21;
* the canon `r_c` anchor is wrong in significant digit 9 (regression guard for
  patch `0004`).

If any self-test fails, none of the six checks may be reported.

---

## Layout

```
sst_relclock_checks/
  main.py                 CLI entrypoint
  run_all.bat/.sh         launchers
  requirements.txt
  sstrc/
    constants.py          CODATA chain, tautology ledger, anchor audit
    geom.py               resampling, spectral derivatives, κ/τ, writhe, frames, twist
    dyn.py                regularised Biot-Savart / LIA, RK4, invariants, spectra
    clocks.py             clock constructors, collapse score, null models
    checks.py             the six checks
    report.py             Markdown report generator
  tests/test_selftests.py
  reference_run/          completed standard-profile run
```

Pure Python + numpy/scipy/matplotlib. No C++ extension: the cost is dominated
by `O(N²)` Biot–Savart and writhe evaluations that numpy already vectorises,
and the standard profile completes in about two minutes. `dyn.velocity` is the
single seam to swap in a compiled kernel if the `full` profile becomes limiting.

## References

- G. Barontini, Phys. Rev. Research **8**, L022047 (2026). DOI 10.1103/1h9j-df4k
- H. K. Moffatt, *The degree of knottedness of tangled vortex lines*,
  J. Fluid Mech. **35**, 117 (1969). DOI 10.1017/S0022112069000991
- H. K. Moffatt and R. L. Ricca, *Helicity and the Călugăreanu invariant*,
  Proc. R. Soc. Lond. A **439**, 411 (1992). DOI 10.1098/rspa.1992.0159
- M. A. Berger and G. B. Field, *The topological properties of magnetic
  helicity*, J. Fluid Mech. **147**, 133 (1984). DOI 10.1017/S0022112084002019
- F. B. Fuller, *The writhing number of a space curve*, PNAS **68**, 815 (1971).
  DOI 10.1073/pnas.68.4.815
- S. Pigolotti, I. Neri, É. Roldán, F. Jülicher, *Generic properties of
  stochastic entropy production*, Phys. Rev. Lett. **119**, 140604 (2017).
  DOI 10.1103/PhysRevLett.119.140604
- S.-I. Amari, *Information Geometry and Its Applications*, Springer (2016).
  DOI 10.1007/978-4-431-55978-8

`[CITATION NEEDS VERIFICATION]` — none; all DOIs above are from the source
paper's own reference list or are standard, but re-verify Moffatt–Ricca 1992 and
Berger–Field 1984 page numbers against the publisher before quoting in canon.
