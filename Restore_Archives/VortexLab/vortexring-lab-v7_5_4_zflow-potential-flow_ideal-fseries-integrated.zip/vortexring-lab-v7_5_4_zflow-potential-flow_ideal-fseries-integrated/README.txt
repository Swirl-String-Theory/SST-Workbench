Vortexring Lab v7.5.4 — z-flow/potential-flow + ideal/fseries integrated

Basis:
  vortexring-lab-v7_5_4_dual-sidebar-ui_zflow-header-paired-docks (1).html

Deze build behoudt de volledige nieuwere potential-flow/UI-aanpassing:
- potential-flowlaag in het x-z-vlak;
- vrije stroming parallel aan de wereld-z-as;
- correcte C_p-controle: stagnatiepunt +1, schouder -3;
- potential flow standaard uit, stroomlijnmodus als standaard;
- header-dropdown voor weergave;
- gecombineerde FLOW + CILINDER-dock;
- gekoppelde linker/rechter docks.

Toegevoegd zonder bovenstaande code te vervangen:
- ideal_knots_data.js: 34 Brian Gilbert ideal/tight objecten;
- fourier_knots_data.js: 78 compacte .fseries-geometrieën;
- bronbewuste catalogusselectie en metadata;
- detectie van verschillende harmonische startindexen in de gegenereerde fseries-data.

Gebruik:
Plaats de HTML en beide JavaScript-databestanden in dezelfde map.

Validatie:
- HTML inline JavaScript: node --check geslaagd;
- beide databestanden: node --check geslaagd;
- unieke catalogus-ID's: 34 ideal, 78 fseries;
- potential-flow numerieke sanity checks geslaagd.
