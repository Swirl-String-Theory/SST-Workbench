from __future__ import annotations
import argparse, json, zipfile, re, shutil
from pathlib import Path
from sst_blind.multitopology import run_panel
ROOT=Path(__file__).resolve().parent
ARC=ROOT/'repro_inputs'/'source_archives'; CACHE=ROOT/'_archive_cache'

def prepare():
    CACHE.mkdir(exist_ok=True)
    kroot=CACHE/'knotplot'; froot=CACHE/'fremlin'
    if not kroot.exists():
        kroot.mkdir(); zipfile.ZipFile(ARC/'KnotPlot_RidgeRunner_Knots_Links.zip').extractall(kroot)
    if not froot.exists():
        froot.mkdir(); zipfile.ZipFile(ARC/'Fremlin_Knots_FourierSeries.zip').extractall(froot)
    return kroot,froot

def topology_class(stem):
    if stem.startswith('link_0.'): return 'unlink'
    if stem.startswith('link_'): return 'link'
    if stem.startswith('torus_'):
        try:
            p,q=map(int,stem.split('_')[1].split('.')); import math
            return 'torus_link' if math.gcd(p,q)>1 else 'torus_knot'
        except Exception:return 'torus'
    if stem.startswith('knot_0.'): return 'unknot'
    return 'knot'

def entries(include_fremlin=True):
    kroot,froot=prepare(); out=[]
    for p in sorted(kroot.glob('*_final.txt')):
        stem=p.name[:-10] # remove _final.txt
        mp=kroot/(stem+'_final.metrics.json')
        out.append(dict(source=stem,kind='knotplot',topology_class=topology_class(stem),path=str(p),metrics_path=str(mp)))
    if include_fremlin:
        for d in sorted(x for x in froot.iterdir() if x.is_dir()):
            exact=d/f'knot.{d.name}.fseries'; cand=exact if exact.exists() else next(iter(sorted(d.glob('*.fseries'))),None)
            if cand:
                cls='unknot' if d.name in ('1_1','0_1') else 'knot'
                out.append(dict(source='fremlin_'+d.name,kind='fseries',topology_class=cls,path=str(cand)))
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',default='configs/panel_survey.json');ap.add_argument('--out-dir',default='outputs_archive_survey');ap.add_argument('--backend',default='auto',choices=['auto','openmp','cpu','sycl','python']);ap.add_argument('--no-fremlin',action='store_true');a=ap.parse_args()
    e=entries(not a.no_fremlin);f,_,m=run_panel(e,a.config,a.out_dir,backend=a.backend);print(json.dumps({'datasets':len(e),'overall':f['overall'],'out_dir':a.out_dir},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
