@echo off
setlocal
cd /d "%~dp0"
call run_build_cpp.cmd || exit /b 1
call .venv\Scripts\activate.bat
python -m pip install pytest
python -m pytest -q || exit /b 1
python -m sst_thpcf.campaign --config configs\extended.json --backend native --root . --reveal --package
endlocal
