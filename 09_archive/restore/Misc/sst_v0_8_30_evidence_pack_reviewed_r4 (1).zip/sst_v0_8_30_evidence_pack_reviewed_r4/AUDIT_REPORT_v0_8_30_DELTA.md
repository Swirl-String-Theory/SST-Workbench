# SST Canon v0.8.30 evidence-pack delta audit -- reviewed revision 4

## Executive verdict

**[READY AS A SEMANTIC/PROVENANCE UPGRADE].**

The v0.8.28 evidence-pack Canon snapshot was upgraded directly to the reviewed
v0.8.30 snapshot. The patch includes the v0.8.29 density-provenance/epoch gate,
the v0.8.30 density ontology and historical VAM-7 provenance correction, and the
two review hotfixes already accepted in the predecessor evidence pack.

No new first-principles value for `rho_f` is claimed.

## Reproduced v0.8.30 delta status

| Layer | Result | Scope |
|---|---:|---|
| Delta numerical/source ledger | **15/15** | v0.8.29/v0.8.30 density semantics, units, provenance, no-promotion guards |
| Marker/reference checker | **25/25** | version, required labels, cross-file input, duplicate labels, unresolved references |
| Direct patch dry-run | **PASS** | reviewed v0.8.28 snapshot -> reviewed v0.8.30 snapshot |
| Patch roundtrip | **byte-identical** | both generated source files match packaged v0.8.30 snapshot |
| LaTeX build | **PASS** | 231 A4 pages; zero unresolved refs/citations and zero duplicate labels |
| Visual render check | **PASS** | title, density ontology, benchmark table, historical audit |

## Scientific delta

The upgrade separates four roles:

- `rho_sub [kg m^-3]`: unresolved material density of the substrate;
- `rho_f = rho_eff^(0) [kg m^-3]`: calibrated quasi-static effective response;
- `J_omega [kg m^-1]`: rotational/twist microinertia per volume;
- `mu_l [kg m^-1]`: resolved or effective line inertia.

The early VAM expression that generated the inherited decimal is registered as

```text
J_omega^VAM ~= 6.84e-7 kg m^-1,
```

not as a mass density. Its closed historical form is

```text
J_omega^VAM = 6 m_e^2 c / (alpha^5 hbar),
```

conditional on the historical frequency and effective-volume ansatzes.

## Retained non-claims

- `rho_sub = rho_f` is not asserted;
- `J_omega = rho_f ell^2` is not asserted without an independently derived
  profile, length, geometry factor, and participation law;
- the cosmological/SSDL route remains a Research Track consistency relation;
- two-significant-figure notation for `rho_f` is not an uncertainty interval;
- uncertainty in `rho_f` does not automatically propagate into `v_char`,
  `omega_c`, `r_c`, or the Compton chain.

## Evidence-pack review overlays

The predecessor's accepted printed-value and benchmark-status patches were
rebased onto v0.8.30. A breakable path command was also used for the long
archived benchmark filename to eliminate a visible margin overflow. These are
review/editorial changes only.

## Historical-suite status

The v0.8.28 99/99 and 111/111 ledgers are preserved unchanged. They remain valid
as evidence for the frozen numerical baseline, but were not relabelled as
v0.8.30 runs. The v0.8.30 changes are instead covered by the new 15/15 delta
ledger and 25/25 structural checker.
