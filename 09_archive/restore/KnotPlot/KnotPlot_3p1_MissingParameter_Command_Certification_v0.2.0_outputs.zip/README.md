# KnotPlot 3.1 Missing-Parameter Certification v0.2.1

Syntax-correction release of the small missing-parameter certification workbench.

## Correct KnotPlot parameter syntax

Confirmed on the target installation:

```text
charge = 12
power = 4
hooke = 2
```

v0.2.0 incorrectly generated bare commands such as `charge 12`, which KnotPlot
correctly reported as `unknown command`.

v0.2.1 generates:

```text
charge = value
hooke = value
power = value
timeincr = value
```

`charge`, `power`, and `hooke` have been confirmed by the user. `timeincr = value`
is deliberately still treated as a certification target: if this build rejects it,
that result is isolated to the `timeincr` family.

## One-parameter isolation

Each candidate assigns exactly one uncertain parameter. The other three remain at
`reset all` defaults.

| parameter | min | baseline | max |
|---|---:|---:|---:|
| charge | 3.75 | 15 | 60 |
| hooke | 0.25 | 1 | 4 |
| power | 4 | 6 | 8 |
| timeincr | 3.75 | 15 | 30 |

Certification checkpoints: `i00000`, `i00100`.

Only `CERTIFIED_EFFECTIVE` families proceed to the `i01000` extended stage.

## Extended-stage skip bug fixed

If no family certifies, v0.2.1 creates:

```text
analysis\EXTENDED_SKIPPED.flag
```

and `run_all.cmd` goes directly to output packaging. It no longer runs the
extended stage after printing that it was skipped.

## Run

```bat
run_dry.cmd
run_all.cmd
```

Expected selftest:

```text
SELFTEST PASS: 24 KPC scripts use one-parameter `name = value` isolation; extended-skip flow validated
```

Return the generated:

```text
KnotPlot_3p1_MissingParameter_Command_Certification_v0.2.1_outputs.zip
```

for analysis.
