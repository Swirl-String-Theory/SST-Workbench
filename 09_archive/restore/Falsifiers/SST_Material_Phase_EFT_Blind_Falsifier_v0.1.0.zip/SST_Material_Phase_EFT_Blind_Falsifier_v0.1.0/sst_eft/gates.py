from __future__ import annotations
import math, pathlib
import numpy as np
from . import native
from .geometry import relabel_variants, spectral_tail_fraction, fourier_smooth
from .io import read_modes
from .constants import R_C

def _reldiff(a,b): return abs(a-b)/max(abs(a),abs(b),1e-300)

def gate_g1_relabel(points,cfg,seed):
    n=int(cfg["g1_reparam_n"]); trials=int(cfg["g1_trials"])
    ref=native.resample(points,n); mr=native.metrics(ref); wr=native.writhe(ref)
    rows=[]; worst={"D0_rel":0.0,"total_curvature_rel":0.0,"writhe_abs":0.0}
    for name,q in relabel_variants(points,n,trials,seed):
        m=native.metrics(q); w=native.writhe(q)
        r={"variant":name,"D0_rel":_reldiff(float(m["D0"]),float(mr["D0"])),
           "total_curvature_rel":_reldiff(float(m["total_curvature"]),float(mr["total_curvature"])),
           "writhe_abs":abs(w-wr)}
        rows.append(r)
        for k in worst: worst[k]=max(worst[k],r[k])
    ok=(worst["D0_rel"]<=cfg["g1_D0_rel_max"] and worst["total_curvature_rel"]<=cfg["g1_total_curvature_rel_max"] and worst["writhe_abs"]<=cfg["g1_writhe_abs_max"])
    return {"gate":"G1","name":"material-coordinate/reparameterization proxy","status":"PASS" if ok else "FAIL","reference":{**mr,"writhe":wr},"worst":worst,"trials":rows,
            "scope_note":"Centerline reparameterization proxy only; not a full 3-D volume-preserving-diffeomorphism test."}

def gate_g2_phase_shift(points,cfg,seed):
    # Structural estimator test: a time-independent comoving gauge f(label) must cancel from D_t psi.
    n=int(cfg["g2_phase_n"]); rng=np.random.default_rng(seed^0x5A17)
    u=np.linspace(0,1,n,endpoint=False); dt=float(cfg["g2_dt_s"])
    winding=int(cfg["g2_winding"]); omega=2.5e3
    psi0=2*np.pi*winding*u + 0.17*np.sin(6*np.pi*u)
    psi1=psi0 + omega*dt + 0.03*np.sin(4*np.pi*u)*dt
    f=np.zeros_like(u)
    for m in range(1,7): f += rng.normal(scale=0.25/m)*np.sin(2*np.pi*m*u+rng.uniform(0,2*np.pi))
    rate=(psi1-psi0)/dt; rate_g=((psi1+f)-(psi0+f))/dt
    err=float(np.max(np.abs(rate-rate_g)))
    hol=2*np.pi*winding; hol_g=hol + (f[0]-f[0])
    herr=float(abs(hol-hol_g))
    ok=err<=cfg["g2_rate_abs_tol"] and herr<=cfg["g2_holonomy_abs_tol"]
    return {"gate":"G2","name":"comoving phase-shift/holonomy estimator","status":"STRUCTURAL_PASS" if ok else "STRUCTURAL_FAIL",
            "max_rate_difference_rad_s":err,"holonomy_difference_rad":herr,"winding":winding,
            "scope_note":"No physical phase data are inferred from a static centerline. This tests invariance of the estimator under psi -> psi + f(label)."}

def gate_g3_derivative_hierarchy(points,cfg):
    # EFT observables are evaluated after a pre-registered coarse-graining scale
    # (fixed Fourier harmonic cutoff), so polygon-corner UV noise cannot masquerade
    # as divergent higher derivatives when only the sampling density changes.
    kcut=int(cfg["g3_harmonic_cutoff"])
    rows=[]
    for n in cfg["g3_resolutions"]:
        q=fourier_smooth(points,int(n),kcut); m=native.metrics(q); k=native.curvature(q)
        rows.append({"n":int(n),"D0":float(m["D0"]),"D2":float(m["D2"]),"total_curvature":float(m["total_curvature"]),"tail_fraction":spectral_tail_fraction(k,float(cfg["g3_tail_start_fraction"]))})
    a,b=rows[-2],rows[-1]
    d0=_reldiff(a["D0"],b["D0"]); d2=_reldiff(a["D2"],b["D2"]); tail=b["tail_fraction"]
    nh=int(cfg["g3_resolutions"][-1]); raw=native.resample(points,nh); sm=fourier_smooth(points,nh,kcut)
    centered=raw-raw.mean(axis=0); scale=float(np.sqrt(np.mean(np.sum(centered*centered,axis=1))))
    removed=float(np.sqrt(np.mean(np.sum((raw-sm)**2,axis=1)))/max(scale,1e-300))
    ok=d0<=cfg["g3_D0_rel_max"] and d2<=cfg["g3_D2_rel_max"] and tail<=cfg["g3_tail_power_max"] and removed<=cfg["g3_removed_rms_fraction_max"]
    return {"gate":"G3","name":"derivative hierarchy / continuum convergence","status":"PASS" if ok else "FAIL","rows":rows,
            "top_pair":{"D0_rel":d0,"D2_rel":d2,"tail_fraction":tail,"removed_rms_fraction":removed,"harmonic_cutoff":kcut},
            "definitions":{"D0":"L * integral(kappa^2 ds)","D2":"L^3 * integral((d kappa/ds)^2 ds)"},
            "scope_note":"Higher derivatives are evaluated after a fixed pre-registered Fourier coarse-graining cutoff; removed_rms_fraction quantifies discarded UV geometry."}

def gate_g4_redundancy(points,cfg):
    n=int(cfg["g4_n"]); q=native.resample(points,n); m=native.metrics(q); L=float(m["length"]); ds=L/n; k=native.curvature(q)
    kp=(np.roll(k,-1)-k)/ds
    kpp=(np.roll(k,-1)-2*k+np.roll(k,1))/(ds*ds)
    lhs=float(np.sum(k*kpp)*ds); rhs=float(-np.sum(kp*kp)*ds)
    ibp=abs(lhs-rhs)/max(abs(lhs),abs(rhs),1e-300)
    td=float(np.sum((np.roll(k*k,-1)-k*k)/ds)*ds)
    td_norm=abs(td)/max(float(np.sum(k*k)*ds),1e-300)
    ok=ibp<=cfg["g4_ibp_rel_max"] and td_norm<=cfg["g4_total_derivative_rel_max"]
    return {"gate":"G4","name":"operator redundancy / discrete integration-by-parts","status":"STRUCTURAL_PASS" if ok else "STRUCTURAL_FAIL",
            "ibp_rel_residual":ibp,"total_derivative_rel_residual":td_norm,"lhs_int_kappa_kappapp":lhs,"rhs_minus_int_kappap2":rhs,
            "scope_note":"Tests operator-basis identities on a closed discretized centerline; it does not by itself prove a candidate SST action."}

def _fit_design(x,y,powers):
    x=np.asarray(x,float); y=np.asarray(y,float)
    xs=max(float(np.max(np.abs(x))),1e-300); ys=max(float(np.sqrt(np.mean(y*y))),1e-300)
    q=x/xs; z=y/ys
    A=np.column_stack([q**p for p in powers]); cscaled, *_=np.linalg.lstsq(A,z,rcond=None)
    coef=np.asarray([cscaled[j]*ys/(xs**p) for j,p in enumerate(powers)],float)
    pred=sum(coef[j]*x**p for j,p in enumerate(powers))
    rmse=float(np.sqrt(np.mean((y-pred)**2))); scale=max(float(np.sqrt(np.mean(y*y))),1e-300)
    return coef,pred,rmse/scale

def _loo_rel_rmse(x,y,powers):
    errs=[]
    for i in range(len(x)):
        mask=np.ones(len(x),bool); mask[i]=False
        c,_,_= _fit_design(x[mask],y[mask],powers)
        pred=sum(cj*x[i]**p for cj,p in zip(c,powers)); errs.append((y[i]-pred)**2)
    return float(np.sqrt(np.mean(errs))/max(np.sqrt(np.mean(y*y)),1e-300))

def gate_g5_modes(mode_path: pathlib.Path|None,cfg):
    if mode_path is None or not mode_path.exists():
        return {"gate":"G5","name":"low-k mode dispersion","status":"NOT_TESTED_NO_MODE_TABLE",
                "required_columns":["k_m_inv","omega_rad_s"],"scope_note":"Static centerlines contain no dynamical frequency data; no frequency is fabricated."}
    a=read_modes(mode_path)
    if len(a)<6: return {"gate":"G5","name":"low-k mode dispersion","status":"NOT_TESTED_INSUFFICIENT_MODES","n_modes":int(len(a))}
    k=a[:,0]; y=a[:,1]**2
    c2,p2,r2=_fit_design(k,y,[2]); c24,p24,r24=_fit_design(k,y,[2,4])
    cv2=_loo_rel_rmse(k,y,[2]); cv24=_loo_rel_rmse(k,y,[2,4])
    highfrac=float(abs(c24[1]*k.max()**4)/max(abs(c24[0]*k.max()**2)+abs(c24[1]*k.max()**4),1e-300))
    epsmax=float(k.max()*R_C)
    best=min(cv2,cv24)
    hierarchy_ok=(epsmax<=cfg["g5_epsilon_max"] and highfrac<=cfg["g5_high_order_fraction_max"])
    fit_ok=best<=cfg["g5_cv_rel_rmse_max"]
    status="PASS" if fit_ok and hierarchy_ok else "FAIL"
    return {"gate":"G5","name":"low-k mode dispersion","status":status,"n_modes":int(len(a)),"epsilon_max":epsmax,
            "model_k2":{"a2":float(c2[0]),"rel_rmse":r2,"loo_rel_rmse":cv2},
            "model_k2_k4":{"a2":float(c24[0]),"a4":float(c24[1]),"rel_rmse":r24,"loo_rel_rmse":cv24,"high_order_fraction_at_kmax":highfrac},
            "criterion":"omega^2 analytic in even low-k powers; hierarchy must remain perturbative."}

def overall_verdict(gates):
    by={g["gate"]:g["status"] for g in gates}
    if by.get("G1")!="PASS" or by.get("G3")!="PASS": return "STATIC_FAIL"
    if by.get("G2")=="STRUCTURAL_FAIL" or by.get("G4")=="STRUCTURAL_FAIL": return "PIPELINE_FAIL"
    if by.get("G5")=="FAIL": return "DYNAMIC_FAIL"
    if by.get("G5")=="PASS": return "FULL_PASS_WITH_MODE_DATA"
    return "PARTIAL_STATIC_PASS_NO_MODE_DATA"
