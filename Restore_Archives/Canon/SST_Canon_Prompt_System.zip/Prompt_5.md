# PROMPT 5 — VERIFICATION

MODE: CONSISTENCY CHECK

TASK:
- Check logic
- Check LaTeX
- Fix issues
