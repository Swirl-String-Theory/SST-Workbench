#!/usr/bin/env bash
set -euo pipefail
python sst_route1_common_foundation_v0.0.6.py --output-dir output_v0.0.6
