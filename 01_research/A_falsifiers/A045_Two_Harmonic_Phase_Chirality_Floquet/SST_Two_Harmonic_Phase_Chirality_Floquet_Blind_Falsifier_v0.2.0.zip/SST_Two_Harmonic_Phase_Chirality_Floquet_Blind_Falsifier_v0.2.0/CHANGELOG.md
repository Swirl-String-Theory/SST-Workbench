# CHANGELOG

## v0.2.0

- Adds frozen A038 trefoil seed ensemble with SHA-256 fail-closed admission.
- Freezes E010/PKLSA and A038 provenance artifacts.
- Replaces the v0.1.0 LIA reference evolution with a regularized nonlocal finite-core segment model.
- Rewrites the two-colour drive as an explicit planar waveform followed by a covariant trace-free strain map.
- Adds core-radius/mesh ladder support and temporal refinement certification.
- Separates `numerics_verdict` from `physics_verdict`.
- Keeps formal Floquet analysis at `SKIP_NO_CERTIFIED_RPO`.
