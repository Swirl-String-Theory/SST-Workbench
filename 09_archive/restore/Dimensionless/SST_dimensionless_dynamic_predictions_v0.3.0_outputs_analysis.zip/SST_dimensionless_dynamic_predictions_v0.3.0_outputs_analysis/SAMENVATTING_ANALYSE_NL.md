# Samenvatting outputanalyse — SST v0.3.0

## Hoofdverdict

De volledige B0–B8-ladder bevat 2726 officiële resultaatrijen. De rechte, bevroren axiale vortexbundel is numeriek consistent, maar stabiliseert de statische trefoil of figure-eight niet.

\[
\boxed{
\texttt{
RING-CONTROL-PASS /
RIGID-ROTATION-INVARIANCE-PASS /
CHIRAL-PARITY-PASS /
PHYSICAL-FLUX-SCALING-PASS /
DISCRETIZATION-CONVERGENCE-PASS /
CLOCK-KINEMATICS-PASS /
FROZEN-BUNDLE-STABILIZATION-FAIL
}
}
\]

## Belangrijkste resultaten

De geïsoleerde trefoil heeft gemiddeld een intrinsiek residu van ongeveer

\[
\epsilon_{\rm int}(3_1)\simeq0.2263,
\]

terwijl de gate

\[
\epsilon_{\rm int}<0.05
\]

vereist. De figure-eight zit rond \(0.4648\). Alleen de ring passeert.

Een grote-radius achtergrondvortex verandert het intrinsieke residu slechts op machineprecisie. Dit bevestigt dat pure solid-body-rotatie geen vormstabilisatie oplevert.

De hole-matched continue Rankine-bundel haalt geen stabiele trefoil. De brede validatiescan vindt als beste punt slechts ongeveer \(0.602\%\) verbetering:

\[
R_{\rm bundle}/R_{\rm hole}=2,\qquad
\Gamma_{\rm hole}=-0.25,\qquad
\epsilon_{\rm int}=0.219211.
\]

Dit blijft ver boven \(0.05\).

De chirale relatie is exact:

\[
\epsilon_{3_1}(\Gamma)
=
\epsilon_{\overline{3_1}}(-\Gamma).
\]

Bij hetzelfde circulatieteken verschillen trefoil en spiegel-trefoil wel; het maximale residuverschil is ongeveer \(0.04252\). De achtergrond detecteert dus chiraliteit, maar stabiliseert haar niet.

Voor fysieke buizen geldt correct:

\[
\Gamma_{\rm hole}=N\Gamma_{\rm tube}.
\]

Meer fysieke buizen verhogen totale flux, klokfrequentie en vervorming. Geen geteste fysieke-buizenconfiguratie verbetert de geïsoleerde trefoil.

Voor numerieke discretisatie geldt correct:

\[
\Gamma_{\rm tube}=\Gamma_{\rm hole}/N.
\]

De discrete bundel convergeert naar de continue Rankine-bundel. Bij \(N=91\) is de gemiddelde relatieve veldfout ongeveer \(7.4\times10^{-5}\) en de gemiddelde relatieve residufout ongeveer \(3.2\times10^{-4}\).

De klokrelatie

\[
\Omega_\Gamma=\frac{\Gamma_{\rm hole}}{2\pi R_{\rm bundle}^2}
\]

wordt numeriek correct uitgevoerd. Dit is nog een kinematische faseklok, geen afleiding van emergente proper time.

## Wetenschappelijke conclusie

Gefalsificeerd binnen het huidige model:

\[
\boxed{
\text{Een statische ideal-trefoil wordt niet gestabiliseerd door een bevroren,}
\atop
\text{rechte finite-radius axiale vortexbundel in het onderzochte parametergebied.}
}
\]

Nog open:

\[
\boxed{
\text{dynamisch buigen van de achtergrondbuizen, Kelvin-moden,}
\atop
\text{lokale vortexdichtheidsverandering en volledige wederzijdse inductie.}
}
\]

De logische volgende release is B6C: trefoil en axiale buizen gezamenlijk dynamisch evolueren, met topologiebehoud, terugreactie en Floquetanalyse.
