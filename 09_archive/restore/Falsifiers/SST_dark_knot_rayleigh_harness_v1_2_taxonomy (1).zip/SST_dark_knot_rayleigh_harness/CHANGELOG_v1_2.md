# CHANGELOG v1.2 — SSTcore Taxonomy Spine

Status: RESEARCH TRACK / TAXONOMY-ONLY GATING / MASS FUNCTIONAL UNCHANGED

## Added

- `schemas/sstcore_taxonomy_knot.schema.json`
  - Draft-2020-12 JSON schema for knot/link taxonomy records.
  - Keeps topology identity, hyperbolic volume, chirality sign, optional energy features, and compute provenance separate.

- `sst_dark_knot_harness/taxonomy.py`
  - Dependency-free seed records for `3_1` and `4_1`.
  - Optional SnapPy pathway when SnapPy is installed locally.
  - `compute_record(...)`, `compute_hvol_fields(...)`, `apply_mirror(...)`, `taxonomy_sector(...)`.
  - JSONL helpers: `load_jsonl`, `write_jsonl`, `lookup_record`.
  - Lightweight validator: `validate_record_light`.

- `taxonomy/compute_taxonomy.py`
  - CLI wrapper for generating/validating taxonomy records.

- `data/taxonomy_db.seed.jsonl`
  - Seed database with `3_1` and `4_1`.
  - `3_1`: torus, chiral, null hyperbolic volume.
  - `4_1`: hyperbolic, amphichiral, normalized volume 1, signed volume 0.

- `tests/test_taxonomy_light.py`
  - Verifies seed records, mirror sign convention, amphichiral cancellation, and sector gating.

- `examples/taxonomy_commands.txt`
  - Copy-paste commands for taxonomy generation and JSONL append mode.

## Changed

- `run_all_checks.py` now also runs taxonomy sanity checks and writes `taxonomy_checks.json`.
- Package version bumped to `0.3.0-research-track`.

## Important limitations

- `hvol_signed` is a taxonomy coordinate, not a topological invariant by itself. Hyperbolic volume is nonnegative and mirror-invariant; the sign is assigned only through `sigma_chi`.
- Chiral left/right labels depend on the declared mirror convention. Do not use them without a table/diagram convention.
- Unknown KnotPlot geometry is not automatically classified. Convert to PD/DT or table ID first.
- SnapPy is optional and not bundled.
