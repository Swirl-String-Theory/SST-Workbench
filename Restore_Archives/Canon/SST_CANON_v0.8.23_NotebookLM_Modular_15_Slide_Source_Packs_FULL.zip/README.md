# SST Canon v0.8.23 modular 15-slide source packs

This package is designed for Gemini Notebook / NotebookLM. Use one chapter PDF at a time to avoid repeated generic six-minute videos.

## How to use

1. Choose one chapter PDF.
2. Upload it to a fresh NotebookLM/Gemini Notebook context.
3. Paste the matching `_NOTEBOOKLM_PROMPT.txt`.
4. Request exactly 15 slides and preserve numbered order.

## Chapters

- `00_master_guide.pdf` - Master guide - modular 15-slide NotebookLM source strategy
- `01_genesis_impedance_provenance.pdf` - Genesis - impedance, resonance, provenance, and non-circularity
- `02_philosophical_prelude_ontology.pdf` - Philosophical Prelude - ontology, operational SR, and scope
- `03_formal_foundations_constants.pdf` - Formal Foundations - primitives, closures, and canonical scales
- `04_axiomatic_framework.pdf` - Axiomatic Framework - the eight commitments
- `05_consistency_labels_integrity.pdf` - Consistency, labels, dependency rules, and Canon integrity
- `06_geometry_topology_knotplot.pdf` - Geometry, topology, finite thickness, and KnotPlot provenance
- `07_swirl_em_linkfield.pdf` - Swirl-EM Bridge and relational link-field ontology
- `08_delay_modes_qss.pdf` - Delay, mode selection, response theory, and QSS
- `09_atomic_particle_mapping.pdf` - Atomic bridge and particle-candidate mapping
- `10_spectroscopy_precision.pdf` - Spectroscopic constraints and precision bridges
- `11_relational_time_gravity.pdf` - Relational time, clock fields, gravity, and tensor-speed constraints
- `12_unification_integration.pdf` - Unified interpretation and integration of prior Canon versions
- `13_limits_appendices_falsifiers.pdf` - Discussion, limits, appendices, and falsification map
- `14_research_topology_stability.pdf` - Research Track I - topology, stability, and finite-core numerical programme
- `15_research_em_gravity_link_action.pdf` - Research Track II - EM, gravity, relativity, inertia, and link action
- `16_research_dark_galactic_numerical.pdf` - Research Track III - dark sector, galactic law, and numerical execution

## Design rules

- Every chapter PDF has exactly 15 source pages.
- Every page maps to one intended slide.
- Each page has narrative purpose, evidence, message, source anchors, visual specification, and a do-not-generate instruction.
- The MAIN Canon remains the source of truth. These are input-shaping source packs, not new Canon.
