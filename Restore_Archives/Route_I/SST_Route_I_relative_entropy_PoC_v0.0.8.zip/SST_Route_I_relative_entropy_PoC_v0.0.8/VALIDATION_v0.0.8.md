# Validation record v0.0.8

## Release verdict

\[
\boxed{
\texttt{THREE-PATH-AUDIT-PASS / UNIQUE-BETA-NOT-DERIVED}
}
\]

The release succeeds as a three-path provenance and falsification audit. It
does **not** certify a unique physical value of \(\beta_Q\).

## Numerical tests

The full default run, including the deterministic hot/cold \(4^4\) Wilson
simulation, reports 10/10 passing logical gates:

1. calibrated horn-action identity reproduced;
2. exact duality map has the stated fixed point;
3. the fixed point gives \(a_\star=2r_c\) in the frozen neck family;
4. raw Wilson free energy is not stationary;
5. cell zero-point energy is not stationary;
6. zero-point energy density is not stationary;
7. normalized free-energy stationarity is caused by duality symmetry;
8. the self-dual candidate is confining in the current Wilson model;
9. impedance matching has an exact \(2\pi\) normalization ambiguity;
10. no unique selector has been derived.

## Determinism

A clean rerun reproduced these files byte-for-byte:

- `audit_report.json`;
- `route_comparison.csv`;
- `candidate_closures.csv`;
- `selfdual_wilson_mc.csv`.

The two Monte Carlo chains use fixed, distinct seeds and retain hot/cold start
separation.

## Python validation

```text
python -m py_compile sst_route1_beta_selection_v0.0.8.py
PASS
```

## Theorem PDF validation

- LaTeX compiled twice with `pdflatex -halt-on-error`;
- output: 5 A4 pages;
- all fonts embedded;
- rendered at 180 dpi with the project PDF validation tool;
- all five rendered pages inspected;
- no clipped equations, overlapping blocks, missing figures, or broken glyphs
  observed.

## CANON patch validation

Both patches were applied to the current loose sources:

- `SST_CANON-v0.8.28.tex`;
- `SST_CANON-v0.8.28-research-track.tex`.

After patching, the combined main CANON compiled successfully to 227 pages.
The inserted block remains explicitly labeled **[RESEARCH TRACK / NEGATIVE
SELECTION RESULT]** and does not promote the modified-Villain model or a value
of \(\beta_Q\) into CANON.

## Epistemic validation

The audit keeps these dependency distinctions explicit:

- Route A's normalized stationary point inherits Route B's exact duality;
- Route B changes the microscopic Wilson model;
- Route C inherits a calibrated horn-envelope identity and an unresolved phase
  normalization;
- the numerical occurrence of \(1/(2\pi)\) is therefore not counted three
  times.

## Remaining theorem target

\[
\boxed{
\mathcal J_K=\frac{E_K}{\omega_K}
\quad\text{or}\quad
\mathcal J_K=\oint p_K\,dq_K,
\qquad
\beta_Q=\frac{\mathcal J_K}{\hbar}
}
\]

This must be evaluated on the preregistered geometry ladder without
carrier-specific retuning.
