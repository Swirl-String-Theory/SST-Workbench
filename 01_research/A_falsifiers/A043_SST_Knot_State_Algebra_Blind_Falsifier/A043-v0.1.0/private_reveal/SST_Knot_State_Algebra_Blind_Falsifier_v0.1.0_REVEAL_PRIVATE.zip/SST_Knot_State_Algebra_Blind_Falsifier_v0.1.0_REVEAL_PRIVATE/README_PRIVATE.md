# PRIVATE REVEAL — keep outside the blind source tree

This archive contains historical targets/mappings used only after the blind campaign has written and sealed its discovery tables. Copy `private_reveal.json` next to neither the source package nor any BLIND output before reveal. `run_reveal.cmd` verifies its SHA-256 against the public commitment.

`denylist.txt` is the private blind-guard term list. Set `SST_PRIVATE_DENYLIST` to its absolute path before `run_all.cmd` for a full contamination scan. Its public commitment is `DENYLIST_COMMITMENT.sha256`.
