#!/usr/bin/env python3
"""
SST Route-I / quantum-relative-entropy numerical proof-of-concept.

This script audits, in a controlled 1D horizon model, the chain

    coherent pulse -> T_UU -> S_rel -> delta A

used by Dorau & Much (PRL 136, 091602, 2026), and compares the
energy-flux/entropy route with a linearized Raychaudhuri focusing route.
It also reports the canonical SST transverse-torsion material constants.

Important: this is an internal-consistency and convergence test of the
mathematical bridge under stated assumptions. It is not empirical proof
of SST, the Bekenstein-Hawking area law, or emergent Einstein dynamics.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable

import numpy as np

try:
    import matplotlib.pyplot as plt
except Exception:  # plotting is optional
    plt = None

PI = math.pi
C_LIGHT = 299_792_458.0  # m s^-1, exact
RHO_F = 7.0e-7  # kg m^-3, SST canonical effective fluid density


@dataclass(frozen=True)
class PulseParameters:
    amplitude: float = 0.01
    center: float = -2.0
    half_width: float = 0.75
    carrier: float = 2.5 * PI


@dataclass(frozen=True)
class AuditResult:
    n: int
    s_rel_flux: float
    s_rel_modular_plus: float
    s_rel_modular_minus: float
    delta_a_entropy: float
    delta_a_weighted_ricci: float
    delta_a_linear_ode: float
    delta_a_nonlinear_ode: float
    relerr_modular_plus: float
    relerr_modular_minus: float
    relerr_entropy_vs_ricci: float
    relerr_linear_ode_vs_ricci: float
    nonlinear_fractional_correction: float


def trapz(y: np.ndarray, x: np.ndarray) -> float:
    """NumPy-version-independent trapezoidal integration."""
    if hasattr(np, "trapezoid"):
        return float(np.trapezoid(y, x))
    return float(np.trapz(y, x))


def safe_relerr(value: float, reference: float) -> float:
    scale = max(abs(reference), np.finfo(float).tiny)
    return abs(value - reference) / scale


def compact_pulse(u: np.ndarray, p: PulseParameters) -> np.ndarray:
    """C-infinity compact bump with an internal carrier oscillation."""
    z = (u - p.center) / p.half_width
    out = np.zeros_like(u, dtype=float)
    inside = np.abs(z) < 1.0
    zi = z[inside]
    bump = np.exp(-1.0 / (1.0 - zi * zi))
    out[inside] = p.amplitude * bump * np.cos(p.carrier * zi)
    return out


def compact_pulse_du(u: np.ndarray, p: PulseParameters) -> np.ndarray:
    """Analytic derivative d phi / dU of compact_pulse."""
    z = (u - p.center) / p.half_width
    out = np.zeros_like(u, dtype=float)
    inside = np.abs(z) < 1.0
    zi = z[inside]
    one_minus = 1.0 - zi * zi
    bump = np.exp(-1.0 / one_minus)
    dbump_dz = bump * (-2.0 * zi / (one_minus * one_minus))
    dcarrier_dz = -p.carrier * np.sin(p.carrier * zi)
    out[inside] = (
        p.amplitude
        / p.half_width
        * (dbump_dz * np.cos(p.carrier * zi) + bump * dcarrier_dz)
    )
    return out


def symplectic_form(
    u: np.ndarray,
    f: np.ndarray,
    df_du: np.ndarray,
    g: np.ndarray,
    dg_du: np.ndarray,
    cross_section_area: float,
) -> float:
    """sigma(f,g)=A_perp int (f g' - g f') dU."""
    return cross_section_area * trapz(f * dg_du - g * df_du, u)


def modular_half_derivative(
    u: np.ndarray,
    p: PulseParameters,
    cross_section_area: float,
    finite_difference_step: float,
    dilation_sign: float,
) -> float:
    """
    Compute (1/2) d/dt sigma(phi^t,phi)|_0 by a central difference.

    phi^t(U)=phi(exp(dilation_sign*2*pi*t) U).
    The sign is exposed because horizon orientation/pullback conventions
    determine whether this expression equals +S_rel or -S_rel.
    """
    phi = compact_pulse(u, p)
    dphi = compact_pulse_du(u, p)

    def sigma_at(t: float) -> float:
        scale = math.exp(dilation_sign * 2.0 * PI * t)
        phi_t = compact_pulse(scale * u, p)
        dphi_t = scale * compact_pulse_du(scale * u, p)
        return symplectic_form(
            u, phi_t, dphi_t, phi, dphi, cross_section_area
        )

    h = finite_difference_step
    derivative = (sigma_at(h) - sigma_at(-h)) / (2.0 * h)
    return 0.5 * derivative


def cumulative_integral_to_zero(u: np.ndarray, values: np.ndarray) -> np.ndarray:
    """Return I(U_i)=int_{U_i}^{0} values(s) ds on an ascending grid."""
    result = np.zeros_like(values)
    # Integrate from the right endpoint toward negative U.
    for i in range(len(u) - 2, -1, -1):
        du = u[i + 1] - u[i]
        result[i] = result[i + 1] + 0.5 * du * (values[i] + values[i + 1])
    return result


def rk4_backward_from_zero(
    u: np.ndarray, source: Callable[[float], float]
) -> np.ndarray:
    """
    Solve dtheta/dU = -theta^2/2 - source(U), theta(0)=0,
    backward along an ascending U grid ending at U=0.
    """
    theta = np.zeros_like(u)

    def rhs(x: float, y: float) -> float:
        return -0.5 * y * y - source(x)

    for i in range(len(u) - 1, 0, -1):
        x0 = float(u[i])
        y0 = float(theta[i])
        h = float(u[i - 1] - u[i])  # negative
        k1 = rhs(x0, y0)
        k2 = rhs(x0 + 0.5 * h, y0 + 0.5 * h * k1)
        k3 = rhs(x0 + 0.5 * h, y0 + 0.5 * h * k2)
        k4 = rhs(x0 + h, y0 + h * k3)
        theta[i - 1] = y0 + h * (k1 + 2*k2 + 2*k3 + k4) / 6.0
    return theta


def run_audit(
    n: int,
    p: PulseParameters,
    alpha: float,
    cross_section_area: float,
    u_min: float,
    finite_difference_step: float,
) -> tuple[AuditResult, dict[str, np.ndarray]]:
    if n < 101:
        raise ValueError("n must be >= 101")
    if u_min >= p.center - p.half_width:
        raise ValueError("u_min must lie left of the pulse support")
    if p.center + p.half_width >= 0.0:
        raise ValueError("pulse support must remain strictly in U<0")

    u = np.linspace(u_min, 0.0, n)
    phi = compact_pulse(u, p)
    dphi = compact_pulse_du(u, p)
    t_uu = dphi * dphi

    weighted_flux = -cross_section_area * trapz(u * t_uu, u)
    s_rel_flux = 2.0 * PI * weighted_flux

    s_mod_plus = modular_half_derivative(
        u, p, cross_section_area, finite_difference_step, +1.0
    )
    s_mod_minus = modular_half_derivative(
        u, p, cross_section_area, finite_difference_step, -1.0
    )

    r_uu = alpha * t_uu
    delta_a_entropy = alpha * s_rel_flux / (2.0 * PI)
    delta_a_weighted_ricci = -cross_section_area * trapz(u * r_uu, u)

    theta_linear = cumulative_integral_to_zero(u, r_uu)
    delta_a_linear_ode = cross_section_area * trapz(theta_linear, u)

    # Evaluate the source analytically so RK4 is not tied to grid interpolation.
    def r_source(x: float) -> float:
        arr = np.asarray([x], dtype=float)
        return alpha * float(compact_pulse_du(arr, p)[0] ** 2)

    theta_nonlinear = rk4_backward_from_zero(u, r_source)
    delta_a_nonlinear_ode = cross_section_area * trapz(theta_nonlinear, u)

    result = AuditResult(
        n=n,
        s_rel_flux=s_rel_flux,
        s_rel_modular_plus=s_mod_plus,
        s_rel_modular_minus=s_mod_minus,
        delta_a_entropy=delta_a_entropy,
        delta_a_weighted_ricci=delta_a_weighted_ricci,
        delta_a_linear_ode=delta_a_linear_ode,
        delta_a_nonlinear_ode=delta_a_nonlinear_ode,
        relerr_modular_plus=safe_relerr(s_mod_plus, s_rel_flux),
        relerr_modular_minus=safe_relerr(s_mod_minus, s_rel_flux),
        relerr_entropy_vs_ricci=safe_relerr(
            delta_a_entropy, delta_a_weighted_ricci
        ),
        relerr_linear_ode_vs_ricci=safe_relerr(
            delta_a_linear_ode, delta_a_weighted_ricci
        ),
        nonlinear_fractional_correction=(
            (delta_a_nonlinear_ode - delta_a_linear_ode)
            / max(abs(delta_a_linear_ode), np.finfo(float).tiny)
        ),
    )

    arrays = {
        "u": u,
        "phi": phi,
        "dphi_du": dphi,
        "t_uu": t_uu,
        "r_uu": r_uu,
        "theta_linear": theta_linear,
        "theta_nonlinear": theta_nonlinear,
    }
    return result, arrays


def amplitude_scaling_test(
    n: int,
    p: PulseParameters,
    alpha: float,
    cross_section_area: float,
    u_min: float,
    finite_difference_step: float,
) -> float:
    r1, _ = run_audit(
        n, p, alpha, cross_section_area, u_min, finite_difference_step
    )
    p2 = PulseParameters(
        amplitude=2.0 * p.amplitude,
        center=p.center,
        half_width=p.half_width,
        carrier=p.carrier,
    )
    r2, _ = run_audit(
        n, p2, alpha, cross_section_area, u_min, finite_difference_step
    )
    return r2.s_rel_flux / r1.s_rel_flux


def zero_state_test(
    n: int,
    p: PulseParameters,
    alpha: float,
    cross_section_area: float,
    u_min: float,
    finite_difference_step: float,
) -> float:
    p0 = PulseParameters(
        amplitude=0.0,
        center=p.center,
        half_width=p.half_width,
        carrier=p.carrier,
    )
    r0, _ = run_audit(
        n, p0, alpha, cross_section_area, u_min, finite_difference_step
    )
    return max(
        abs(r0.s_rel_flux),
        abs(r0.delta_a_entropy),
        abs(r0.delta_a_linear_ode),
    )


def write_csv(path: Path, results: Iterable[AuditResult]) -> None:
    rows = [asdict(r) for r in results]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def make_plots(
    output_dir: Path,
    arrays: dict[str, np.ndarray],
    results: list[AuditResult],
) -> list[str]:
    if plt is None:
        return []

    generated: list[str] = []
    u = arrays["u"]

    fig = plt.figure(figsize=(8.0, 4.8))
    plt.plot(u, arrays["phi"], label=r"$\phi(U)$")
    plt.plot(u, arrays["t_uu"], label=r"$T_{UU}=(\partial_U\phi)^2$")
    plt.xlabel(r"Affine horizon coordinate $U$")
    plt.ylabel("Normalized field / flux")
    plt.title("Compact coherent horizon pulse")
    plt.legend()
    plt.tight_layout()
    path = output_dir / "pulse_and_flux.png"
    fig.savefig(path, dpi=180)
    plt.close(fig)
    generated.append(path.name)

    fig = plt.figure(figsize=(8.0, 4.8))
    plt.plot(u, arrays["theta_linear"], label="Linear Raychaudhuri")
    plt.plot(u, arrays["theta_nonlinear"], label="Nonlinear Raychaudhuri")
    plt.xlabel(r"Affine horizon coordinate $U$")
    plt.ylabel(r"Expansion $\theta(U)$")
    plt.title("Null-congruence focusing response")
    plt.legend()
    plt.tight_layout()
    path = output_dir / "raychaudhuri_response.png"
    fig.savefig(path, dpi=180)
    plt.close(fig)
    generated.append(path.name)

    ns = np.asarray([r.n for r in results], dtype=float)
    err_ode = np.asarray([r.relerr_linear_ode_vs_ricci for r in results])
    err_mod = np.asarray([r.relerr_modular_minus for r in results])
    positive_floor = np.finfo(float).eps

    fig = plt.figure(figsize=(8.0, 4.8))
    plt.loglog(ns, np.maximum(err_ode, positive_floor), marker="o", label="Raychaudhuri route")
    plt.loglog(ns, np.maximum(err_mod, positive_floor), marker="o", label="Modular route (matching orientation)")
    plt.xlabel("Grid points N")
    plt.ylabel("Relative error")
    plt.title("Numerical convergence")
    plt.legend()
    plt.tight_layout()
    path = output_dir / "convergence.png"
    fig.savefig(path, dpi=180)
    plt.close(fig)
    generated.append(path.name)

    return generated


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Numerical audit of the relative-entropy -> area-variation bridge."
    )
    parser.add_argument("--output-dir", default="sst_route1_poc_output")
    parser.add_argument("--grids", nargs="+", type=int, default=[101, 151, 201, 301, 501, 801, 1201, 2001])
    parser.add_argument("--amplitude", type=float, default=0.01)
    parser.add_argument("--center", type=float, default=-2.0)
    parser.add_argument("--half-width", type=float, default=0.75)
    parser.add_argument("--carrier", type=float, default=2.5 * PI)
    parser.add_argument("--alpha", type=float, default=8.0 * PI)
    parser.add_argument("--cross-section-area", type=float, default=1.0)
    parser.add_argument("--u-min", type=float, default=-4.0)
    parser.add_argument("--fd-step", type=float, default=1.0e-6)
    parser.add_argument("--no-plots", action="store_true")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    p = PulseParameters(
        amplitude=args.amplitude,
        center=args.center,
        half_width=args.half_width,
        carrier=args.carrier,
    )

    results: list[AuditResult] = []
    last_arrays: dict[str, np.ndarray] | None = None
    for n in args.grids:
        result, arrays = run_audit(
            n=n,
            p=p,
            alpha=args.alpha,
            cross_section_area=args.cross_section_area,
            u_min=args.u_min,
            finite_difference_step=args.fd_step,
        )
        results.append(result)
        last_arrays = arrays

    finest = results[-1]
    amplitude_ratio = amplitude_scaling_test(
        results[-1].n,
        p,
        args.alpha,
        args.cross_section_area,
        args.u_min,
        args.fd_step,
    )
    zero_residual = zero_state_test(
        results[-1].n,
        p,
        args.alpha,
        args.cross_section_area,
        args.u_min,
        args.fd_step,
    )

    k_t = RHO_F * C_LIGHT * C_LIGHT
    z_t = RHO_F * C_LIGHT

    # The source's written + dilation gives the opposite sign on this U<0
    # orientation; the - dilation convention matches the positive flux formula.
    matching_orientation = (
        "exp(-2*pi*t)" if finest.relerr_modular_minus < finest.relerr_modular_plus
        else "exp(+2*pi*t)"
    )

    tests = {
        "relative_entropy_nonnegative": finest.s_rel_flux >= -1e-13,
        "zero_state_vanishes": zero_residual < 1e-13,
        "quadratic_amplitude_scaling": abs(amplitude_ratio - 4.0) < 5e-6,
        "entropy_area_equals_weighted_ricci": finest.relerr_entropy_vs_ricci < 1e-12,
        "linear_raychaudhuri_converged": finest.relerr_linear_ode_vs_ricci < 5e-5,
        "one_modular_orientation_matches": min(
            finest.relerr_modular_plus, finest.relerr_modular_minus
        ) < 5e-5,
    }

    report = {
        "status": "PASS" if all(tests.values()) else "FAIL",
        "epistemic_scope": {
            "verified": [
                "For the chosen compact coherent pulse, T_UU=(dphi/dU)^2 gives nonnegative weighted flux.",
                "S_rel=-2*pi*int U*T_UU and deltaA=alpha*S_rel/(2*pi) agree numerically with -int U*R_UU when R_UU=alpha*T_UU.",
                "The linearized Raychaudhuri ODE reproduces the same area variation under theta(0)=0.",
                "The zero state gives zero entropy and zero focusing.",
                "The response scales quadratically with pulse amplitude.",
            ],
            "not_verified": [
                "That an SST torsion field defines an Araki-Uhlmann relative entropy.",
                "That SST possesses local Rindler/Killing horizons or a KMS state.",
                "The Bekenstein-Hawking area coefficient or Newton's constant from SST microphysics.",
                "The semiclassical Einstein equations as an empirical consequence of SST.",
            ],
        },
        "parameters": {
            "pulse": asdict(p),
            "alpha": args.alpha,
            "cross_section_area": args.cross_section_area,
            "u_min": args.u_min,
            "finite_difference_step": args.fd_step,
            "grids": args.grids,
        },
        "finest_grid_result": asdict(finest),
        "tests": tests,
        "amplitude_doubling_ratio_expected_4": amplitude_ratio,
        "zero_state_max_residual": zero_residual,
        "modular_orientation_audit": {
            "matching_orientation": matching_orientation,
            "note": (
                "With sigma(f,g)=int(f g'-g f')dU on U<0, the sign of the "
                "modular derivative depends on whether dilation acts as a pullback "
                "with exp(+2*pi*t) or exp(-2*pi*t), equivalently on horizon orientation."
            ),
        },
        "sst_transverse_torsion_constants_si": {
            "rho_f_kg_m-3": RHO_F,
            "c_T_m_s-1": C_LIGHT,
            "K_T_Pa": k_t,
            "Z_T_kg_m-2_s-1": z_t,
        },
    }

    write_csv(output_dir / "convergence.csv", results)
    with (output_dir / "audit_report.json").open("w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2)

    generated_plots: list[str] = []
    if not args.no_plots and last_arrays is not None:
        generated_plots = make_plots(output_dir, last_arrays, results)

    print("SST Route-I numerical proof-of-concept")
    print(f"Status: {report['status']}")
    print(f"Finest grid: N={finest.n}")
    print(f"S_rel (flux route): {finest.s_rel_flux:.12e}")
    print(f"deltaA entropy route: {finest.delta_a_entropy:.12e}")
    print(f"deltaA Ricci route:   {finest.delta_a_weighted_ricci:.12e}")
    print(f"deltaA Raychaudhuri:  {finest.delta_a_linear_ode:.12e}")
    print(f"modular matching orientation: {matching_orientation}")
    print(f"amplitude-doubling ratio: {amplitude_ratio:.12f} (expected 4)")
    print(f"K_T = rho_f*c^2 = {k_t:.12e} Pa")
    print(f"Z_T = rho_f*c   = {z_t:.12e} kg m^-2 s^-1")
    for name, passed in tests.items():
        print(f"[{'PASS' if passed else 'FAIL'}] {name}")
    print(f"Wrote: {output_dir / 'audit_report.json'}")
    print(f"Wrote: {output_dir / 'convergence.csv'}")
    for name in generated_plots:
        print(f"Wrote: {output_dir / name}")

    return 0 if all(tests.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
