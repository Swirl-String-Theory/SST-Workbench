#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, platform, sys
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
from sst_counterpulley import fallback
from sst_counterpulley.backend import load_backend
from sst_counterpulley._config import CPP_REL


def main() -> int:
    ap=argparse.ArgumentParser(description="Build/import native kernel and parity-check one deterministic filament case.")
    ap.add_argument("--force-build",action="store_true")
    ap.add_argument("--allow-python",action="store_true",help="Do not fail if only fallback is available.")
    ap.add_argument("--verbose",action="store_true")
    a=ap.parse_args()
    backend,name=load_backend(force_build=a.force_build,build_verbose=a.verbose)
    t=np.linspace(0,2*np.pi,24,endpoint=False)
    q=np.column_stack((np.cos(t),np.sin(t),0.15*np.sin(2*t)))
    eps=.07
    h_py=fallback.interaction_hamiltonian(q,q,1.0,1.0,eps)
    h=float(backend.interaction_hamiltonian(q,q,1.0,1.0,eps))
    rel=abs(h-h_py)/max(abs(h_py),1e-30)
    src=(ROOT/CPP_REL).read_bytes()
    result={
        "ok": bool(rel<1e-10 and (name=="cpp" or a.allow_python)),
        "backend": name,
        "interpreter": sys.executable,
        "python": sys.version,
        "platform": platform.platform(),
        "source_hash": hashlib.sha256(src).hexdigest(),
        "parity_relative_error": rel,
        "native_required": not a.allow_python,
    }
    print(json.dumps(result,indent=2))
    return 0 if result["ok"] else 1
if __name__=="__main__": raise SystemExit(main())
