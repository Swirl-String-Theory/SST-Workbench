# Gate 2 — scientific assessment

**G2_UNRESOLVED_NO_EULER_RELATIVE_EQUILIBRIUM**

Validated: mathematical volume-preserving shear maps, Piola vorticity push-forward, modal field continuation and frozen independent numerical checks.
Not validated: an Euler relative equilibrium, vanishing continuum stationary residual, or stability.

## Fixed-field holdouts

| Grid | R* direct | R* scalar Green | Velocity discrepancy | Raw divergence D* RMS |
|---:|---:|---:|---:|---:|
| 24³ | 1.4871e+05 | 43705 | 26.57% | 8544.2 |
| 32³ | 1.5463e+05 | 71638 | 17.72% | 7779.8 |
| 40³ | 1.534e+05 | 95757 | 12.56% | 7816 |
| 48³ | 1.3947e+05 | 97592 | 9.04% | 6932.8 |
| 64³ | 1.2581e+05 | 99951 | 5.40% | 5624.9 |

Box comparison at same cell size: PASS (numerical identity under enlarged box).

## Blocking criteria

1. No vanishing continuum Euler residual on a fixed physical domain.
2. Two independent quadrature routes do not yet agree to a qualified error bound.
3. Cartesian sampled vorticity divergence is not yet resolution-qualified.
4. No background cores or spectral stability conclusion is included.

Topological invariance is guaranteed by analytic diffeomorphism, not by an Euler equilibrium.
