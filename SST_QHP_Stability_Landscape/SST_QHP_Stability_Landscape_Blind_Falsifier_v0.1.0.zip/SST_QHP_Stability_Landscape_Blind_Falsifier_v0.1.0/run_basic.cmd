@echo off
setlocal
set "DATASET=%~1"
if "%DATASET%"=="" set "DATASET=..\..\KnotPlot\qhp"
set "OUT=%~2"
if "%OUT%"=="" set "OUT=outputs\basic"
call .venv\Scripts\activate.bat
if not exist "%DATASET%\qhp_metadata.csv" (
  echo ERROR: "%DATASET%\qhp_metadata.csv" not found.
  echo Run: run_metadata_template.cmd "%DATASET%" then fill q,h,p columns and rename to qhp_metadata.csv
  exit /b 2
)
python -m sst_qhp_falsifier.cli prepare "%DATASET%" "%OUT%\prepared" config\basic.json --metadata "%DATASET%\qhp_metadata.csv" || exit /b 1
python -m sst_qhp_falsifier.cli run "%OUT%\prepared" "%OUT%\blind" config\basic.json || exit /b 1
python -m sst_qhp_falsifier.cli analyze "%OUT%\blind" "%OUT%\analysis" config\basic.json || exit /b 1
python -m sst_qhp_falsifier.cli reveal "%OUT%\prepared" "%OUT%\analysis" "%OUT%\reveal" || exit /b 1
