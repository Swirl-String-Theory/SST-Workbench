# Qualification ledger: G1 versus later gates

| Gate | Scope | Status | Evidence |
|---|---|---|---|
| G1a | Smooth, compactly supported, exactly solenoidal continuum initial field | ANALYTIC PASS | Closed two-form, smooth radial derivative support |
| G1b | Geometric no-self-intersection for alpha=.35 and a=.20 | ANALYTIC PASS | Exact rational reach lower-bound proof > .210606825 |
| G1c | Flux, global framing, numeric helicity | NUMERICAL PASS / tolerance-limited | q=0 and q=1, 3 resolutions, Gauss integral and separate 3D free-space kernel helicity |
| G1d | Conservative solenoidal discretization | NUMERICAL PASS / diagnostic only | 3D Fourier Hodge projection, residual correction explicitly recorded and convergent |
| G2 | True Euler relative equilibrium (residual ->0 under refinement) | NOT EXECUTED | No Euler steady-state solver run |
| G3 | Linear, nonlinear, and non-normal stability | NOT EXECUTED | No eigenvalue / finite-time semigroup qualification |
| G4 | Fully coupled background-core stabilization | NOT EXECUTED | No coupled vortex-network simulation |

**Consequence:** The scientific claim `G1_PASS_FOR_DECLARED_ANALYTIC_AND_NUMERICAL_SCOPE` is *not* an existence or stability claim. It certifies one practical seed-qualification level, not all possible core profiles/knots.

The analytic field is compactly supported. The Fourier-Hodge projected grid is not strictly compactly supported; do not feed it uncritically to G2 or treat its tails as real physical background filaments. A compatible discretization preserving both support and the divergence constraint is preferable for subsequent production Euler runs.

Acceptance thresholds were frozen for v0.2 **after exploratory v0.1 measurements**; they were not set in a blinded holdout. The thresholds are embedded as literals in `src/assess.py` and evaluated on independent, stored results for q=0 and q=1. The run cannot be declared passed merely because the mathematical construction forces divergence zero; it also checks the difference between analytic sampled and discrete solenoidal grids plus the helicity convergence trend.
