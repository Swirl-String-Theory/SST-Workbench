"""
Canonical SST constant chain, derived from a single declared CODATA release.

Design rule (audit requirement 6): NOTHING in this module is hard-coded except
the canon anchor values that are being *tested*. Every derived quantity is
computed from (alpha, c, hbar, m_e) of one declared release. Mixed-release
bookkeeping is treated as a defect and is reported, not silently absorbed.

Chain (canon v0.8.x Compton closure):
    v_swirl  = alpha * c / 2
    omega_c  = m_e c^2 / hbar
    r_c      = v_swirl / omega_c              = alpha hbar / (2 m_e c)
    t_c      = r_c / v_swirl = 1 / omega_c    = hbar / (m_e c^2)
    Gamma_0  = 2 pi v_swirl^2 / omega_c = 2 pi v_swirl r_c
    Z_c      = v_swirl^2 r_c
    F_max    = hbar omega_c / (2 r_c)
    E_c      = 2 F_max r_c                    ( == m_e c^2 identically )
"""
from __future__ import annotations

import math
from dataclasses import dataclass, asdict

import scipy.constants as _sc


def codata_release() -> str:
    """Return the CODATA release actually backing scipy.constants."""
    try:
        from scipy.constants import _codata

        return str(_codata._current_codata)
    except Exception:  # pragma: no cover - defensive
        try:
            return str(_sc.codata._current_codata)  # type: ignore[attr-defined]
        except Exception:
            return "UNKNOWN (declare manually)"


# ---------------------------------------------------------------------------
# Canon anchor values as printed in CANON_SOURCE_HIERARCHY.md section 2.
# These are the values UNDER TEST. Do not "fix" them here.
# ---------------------------------------------------------------------------
CANON_ANCHORS = {
    "v_swirl": 1.09384563e6,
    "r_c": 1.40897017e-15,
    "rho_core": 3.8934358266918687e18,
    "rho_f": 7.0e-7,
    "F_swirl_max": 29.053507,
    "F_gr_max": 3.02563e43,
}

# ChatGPT-proposed derived scales, reproduced verbatim for auditing.
PROPOSED_VALUES = {
    "t_c": 1.28808868e-21,
    "Gamma_c": 9.68361920e-9,
    "Gamma_c_sq": 9.37724809e-17,
    "Z_c": 1.68583036e-3,
    "E_c_J": 8.18710494e-14,
    "E_c_keV": 510.9989,
}


@dataclass(frozen=True)
class SSTConstants:
    release: str
    alpha: float
    c: float
    hbar: float
    m_e: float
    e: float
    k_B: float
    v_swirl: float
    omega_c: float
    r_c: float
    t_c: float
    Gamma_0: float
    Gamma_0_sq: float
    Z_c: float
    F_swirl_max: float
    E_c: float
    m_e_c2: float

    def as_dict(self):
        return asdict(self)


def build_constants() -> SSTConstants:
    alpha = _sc.alpha
    c = _sc.c
    hbar = _sc.hbar
    m_e = _sc.m_e
    e = _sc.e
    k_B = _sc.k

    v = alpha * c / 2.0
    omega_c = m_e * c**2 / hbar
    r_c = v / omega_c
    t_c = 1.0 / omega_c
    Gamma_0 = 2.0 * math.pi * v * r_c
    F_max = hbar * omega_c / (2.0 * r_c)
    E_c = 2.0 * F_max * r_c

    return SSTConstants(
        release=codata_release(),
        alpha=alpha,
        c=c,
        hbar=hbar,
        m_e=m_e,
        e=e,
        k_B=k_B,
        v_swirl=v,
        omega_c=omega_c,
        r_c=r_c,
        t_c=t_c,
        Gamma_0=Gamma_0,
        Gamma_0_sq=Gamma_0**2,
        Z_c=v**2 * r_c,
        F_swirl_max=F_max,
        E_c=E_c,
        m_e_c2=m_e * c**2,
    )


def tautology_ledger(k: SSTConstants) -> list[dict]:
    """
    Each entry records a quantity that LOOKS like an independent scale but is
    algebraically forced by the Compton closure. rel_dev is the machine-level
    residual of the claimed identity.
    """
    return [
        {
            "quantity": "t_c",
            "claimed_as": "r_c / ||v_swirl||",
            "identically_equals": "1/omega_c = hbar/(m_e c^2)",
            "value": k.t_c,
            "rel_residual": k.t_c / (k.hbar / (k.m_e * k.c**2)) - 1.0,
            "label": "[CALIBRATED ALGEBRAIC IDENTITY]",
        },
        {
            "quantity": "E_c",
            "claimed_as": "2 F_swirl_max r_c",
            "identically_equals": "hbar*omega_c = m_e c^2",
            "value": k.E_c,
            "rel_residual": k.E_c / k.m_e_c2 - 1.0,
            "label": "[CALIBRATED ALGEBRAIC IDENTITY]",
        },
        {
            "quantity": "Gamma_0",
            "claimed_as": "2 pi r_c ||v_swirl||",
            "identically_equals": "(alpha^2/4) * h/m_e",
            "value": k.Gamma_0,
            "rel_residual": k.Gamma_0 / (k.alpha**2 / 4.0 * (2 * math.pi * k.hbar / k.m_e)) - 1.0,
            "label": "[CALIBRATED ALGEBRAIC IDENTITY]",
        },
        {
            "quantity": "Z_c",
            "claimed_as": "||v_swirl||^2 r_c",
            "identically_equals": "Gamma_0^2 / (4 pi^2 r_c)",
            "value": k.Z_c,
            "rel_residual": k.Z_c / (k.Gamma_0**2 / (4 * math.pi**2 * k.r_c)) - 1.0,
            "label": "[CALIBRATED ALGEBRAIC IDENTITY]",
        },
        {
            "quantity": "F_swirl_max",
            "claimed_as": "calibrated structural tension scale",
            "identically_equals": "m_e^2 c^3 / (alpha hbar)",
            "value": k.F_swirl_max,
            "rel_residual": k.F_swirl_max / (k.m_e**2 * k.c**3 / (k.alpha * k.hbar)) - 1.0,
            "label": "[CALIBRATED ALGEBRAIC IDENTITY]",
        },
    ]


def anchor_deviations(k: SSTConstants) -> list[dict]:
    """Canon anchor vs. exact chain. This is where patch 0004 shows up."""
    pairs = [
        ("v_swirl", k.v_swirl, CANON_ANCHORS["v_swirl"], "alpha*c/2"),
        ("r_c", k.r_c, CANON_ANCHORS["r_c"], "alpha*hbar/(2 m_e c)"),
        ("F_swirl_max", k.F_swirl_max, CANON_ANCHORS["F_swirl_max"], "hbar omega_c/(2 r_c)"),
    ]
    out = []
    for name, exact, anchor, formula in pairs:
        rel = anchor / exact - 1.0
        # first significant decimal digit at which anchor and exact disagree
        bad_digit = None
        if rel != 0.0:
            bad_digit = int(math.floor(-math.log10(abs(rel)))) + 1
        out.append(
            {
                "quantity": name,
                "formula": formula,
                "exact": exact,
                "canon_anchor": anchor,
                "rel_dev_anchor_minus_exact": rel,
                "first_wrong_significant_digit": bad_digit,
                "status": "OK" if abs(rel) < 1e-12 else "MISMATCH",
            }
        )
    return out


def proposed_value_audit(k: SSTConstants) -> list[dict]:
    """
    Re-derive the externally proposed numbers two ways:
      (a) from the canon anchors (reproducing the proposer's arithmetic),
      (b) from the exact CODATA chain.
    The gap between (a) and (b) is inherited constant-chain error.
    """
    a_v = CANON_ANCHORS["v_swirl"]
    a_r = CANON_ANCHORS["r_c"]
    a_F = CANON_ANCHORS["F_swirl_max"]

    from_anchor = {
        "t_c": a_r / a_v,
        "Gamma_c": 2 * math.pi * a_r * a_v,
        "Gamma_c_sq": (2 * math.pi * a_r * a_v) ** 2,
        "Z_c": a_v**2 * a_r,
        "E_c_J": 2 * a_F * a_r,
        "E_c_keV": 2 * a_F * a_r / k.e / 1e3,
    }
    from_exact = {
        "t_c": k.t_c,
        "Gamma_c": k.Gamma_0,
        "Gamma_c_sq": k.Gamma_0_sq,
        "Z_c": k.Z_c,
        "E_c_J": k.E_c,
        "E_c_keV": k.E_c / k.e / 1e3,
    }
    rows = []
    for key, proposed in PROPOSED_VALUES.items():
        va, ve = from_anchor[key], from_exact[key]
        rows.append(
            {
                "quantity": key,
                "proposed": proposed,
                "recomputed_from_canon_anchors": va,
                "recomputed_from_exact_chain": ve,
                "rel_err_proposed_vs_anchor": proposed / va - 1.0,
                "rel_err_proposed_vs_exact": proposed / ve - 1.0,
                "justified_sig_digits": _sig_digits(abs(proposed / ve - 1.0)),
            }
        )
    return rows


def _sig_digits(rel_err: float) -> int:
    if rel_err <= 0 or not math.isfinite(rel_err):
        return 15
    return max(1, int(math.floor(-math.log10(rel_err))))
