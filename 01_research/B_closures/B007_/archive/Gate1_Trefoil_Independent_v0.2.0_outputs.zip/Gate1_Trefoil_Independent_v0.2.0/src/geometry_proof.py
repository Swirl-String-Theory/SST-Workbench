"""Exact-rational and conservative analytic tube-reach certificate.

For T(2,3) torus curve X(phi) with R=1, a_torus=7/20:
D(m,d)^2/4 = sin(d)^2 [1+2a*cos(3m)*cos(3d/2)+a^2*cos(3m)^2]
                  + a^2*cos(d)^2*sin(3d/2)^2.
For d in [0,pi], m=(phi1+phi2)/2, d=shortest angular parameter difference |phi1-phi2| mod 2pi.
We only certify reach > 0.2, not exact reach.
"""
from __future__ import annotations
import math
import json
from fractions import Fraction as Q
import sympy as sp

A = Q(7,20)
D0 = Q(33,100)
CORE = Q(1,5)
K_BOUND = Q(8,5)

def certificate() -> dict:
    # For c=cos(3phi), v components in the local cylindrical basis:
    # v=(-3a sin 3phi,2(1+a cos3phi),3a cos3phi)
    # acceleration=(-9a cos3phi-4(1+a cos3phi), -12a sin3phi, -9a sin3phi)
    a,c,u,si = sp.symbols('a c u si',real=True)
    v = sp.Matrix([-3*a*si, 2*(1+a*c), 3*a*c])
    acc = sp.Matrix([-9*a*c-4*(1+a*c),-12*a*si,-9*a*si])
    vnorm2 = sp.expand(v.dot(v)).subs(si**2,1-c**2).expand()
    cross2 = sp.expand(v.cross(acc).dot(v.cross(acc)))
    cross2 = sp.expand(cross2.subs(si**4,(1-c**2)**2).subs(si**2,1-c**2))
    expr = sp.expand(sp.Rational(8,5)**2*vnorm2**3-cross2)
    # exact polynomial expressed on u=(c+1)/2, u in [0,1]
    p=sp.Poly(sp.expand(expr.subs(a,sp.Rational(7,20)).subs(c,2*u-1)),u)
    coeff=[sp.Rational(p.nth(k)) for k in range(p.degree()+1)]
    assert len(coeff)==7 and coeff[0]>0 and coeff[1]<0 and all(t>0 for t in coeff[2:])
    # Positive quadratic c0+c1*u+c2*u^2; remaining terms positive.
    discriminant = coeff[1]**2-4*coeff[0]*coeff[2]
    assert discriminant<0
    # Condition: any doubly-critical chord with half-parameter separation d<.33
    # cannot occur because arc length <2*d*vmax<pi/K_bound.
    vmax_sq=9*A*A+4*(1+A)**2
    vmax_upper=Q(2898,1000) # proven (2898/1000)^2 > vmax_sq
    assert vmax_upper**2 > vmax_sq
    short_arc_upper=2*D0*vmax_upper
    assert short_arc_upper < Q(314,100)/K_BOUND # pi > 3.14
    # Mid range d in [.33, pi-.33]: D >= 2(1-a)sin(.33).
    sin_lower=D0-D0**3/6  # Taylor bound for 0<=d<=0.33
    mid_chord_lower=2*(1-A)*sin_lower
    assert mid_chord_lower > 2*CORE
    # final d>=pi-.33: D>=2a*cos(.33)*cos(3*.33/2).
    cos_lower_1=1-D0**2/2
    cos_lower_2=1-(Q(3,2)*D0)**2/2
    far_chord_lower=2*A*cos_lower_1*cos_lower_2
    assert far_chord_lower > 2*CORE
    # K < 1.6 means local curvature radius > 0.625.
    lower_reach=min(1/K_BOUND, mid_chord_lower/2, far_chord_lower/2)
    assert lower_reach>CORE
    return {
        'status':'ANALYTIC_LOWER_BOUND_PROVED_FOR_THIS_PARAMETRIZATION',
        'parameter_exact':{'torus_minor_ratio':str(A),'core_radius':str(CORE),'half_angle_cutoff':str(D0),'curvature_bound':str(K_BOUND)},
        'identity':'D(m,d)^2/4=sin(d)^2*(1+2*a*cos(3*m)*cos(3*d/2)+a^2*cos(3*m)^2)+a^2*cos(d)^2*sin(3*d/2)^2',
        'positive_polynomial_coefficients_ascending_exact':[str(c) for c in coeff],
        'positive_quadratic_discriminant_exact':str(discriminant),
        'min_curvature_radius_bound':float(1/K_BOUND),
        'velocity_max_upper':float(vmax_upper),
        'short_arc_upper':float(short_arc_upper),
        'short_arc_curvature_limit_lower':float(Q(314,100)/K_BOUND),
        'mid_chord_length_lower':float(mid_chord_lower),
        'far_chord_length_lower':float(far_chord_lower),
        'reach_lower_bound_proven':float(lower_reach),
        'chosen_core_radius':float(CORE),
        'margin_lower_bound':float(lower_reach-CORE),
        'exact_reach_not_claimed':True,
        'proof_notes':[
            'Curvature bound kappa<8/5 from exact rational polynomial P(u)=(8/5)^2*|Xprime|^6-|Xprime cross Xsecond|^2, u=(cos(3phi)+1)/2.',
            'All polynomial coefficients for u^k,k>=2 positive, while constant + linear + quadratic has negative discriminant and positive leading coefficient.',
            'For d<.33 the shorter parameter arc has length <= d*vmax (conservatively <=2*d*vmax) < pi/kappa_max; its chord cannot be orthogonal to its initial tangent by integration of T(s) dot T(0)>=cos(kappa_max*s).',
            'For d in [.33,pi-.33] D>=2*(1-a)*sin(.33) and for d in [pi-.33,pi] D>=2*a*cos(.33)*cos(3*.33/2).',
            'The global reach=min(1/kappa_max,d_doubly_critical/2) therefore exceeds this conservative lower bound.',
        ]
    }

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',default='results/reach_certificate.json')
    args=parser.parse_args()
    from pathlib import Path
    result=certificate()
    Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k in ('status','reach_lower_bound_proven','margin_lower_bound')},indent=2))
