@echo off
setlocal EnableExtensions
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
pushd "%~dp0"
set "OUT=Gate2_Trefoil_FullField_v0.2.0-outputs"
call run_all.cmd
if errorlevel 1 goto :fail
echo [EXT] Separate q=1 isovortical orbit
python src\full_field.py --n 24 --modes 3 --iterations 3 --q 1 --out "%OUT%\q1_exploratory"
if errorlevel 1 goto :fail
echo [EXT] Larger holdouts on frozen q=0 candidate
python src\verify_independent.py --search "%OUT%\continuation\stage_3_n40_m5\search.json" --grids 48 64 80 96 --output "%OUT%\holdout_extended.json"
if errorlevel 1 goto :fail
popd
exit /b 0
:fail
popd
exit /b 1
