@echo off
setlocal
cd /d "%~dp0"
if not exist .venv py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -U pip setuptools wheel pybind11 numpy
set DISTUTILS_USE_SDK=1
set MSSdk=1
python setup.py build_ext --inplace
python -c "import sst_thpcf._native as n; print('native backend OK:', n.__doc__)"
endlocal
