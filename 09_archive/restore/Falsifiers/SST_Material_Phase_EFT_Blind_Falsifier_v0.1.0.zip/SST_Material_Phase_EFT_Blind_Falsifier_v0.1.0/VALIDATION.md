# Validation report — v0.1.0

Validated in the artifact runtime on 2026-08-21.

## Native C++ kernel

- Compiled `cpp/native.cpp` as a CPython extension with `g++ -O3 -std=c++17` and available pybind11 headers.
- Imported backend: `cpp-pybind11`.
- Native self-test: PASS.

## Synthetic closed-trefoil smoke campaign

A smooth torus-knot trefoil embedding with 800 samples was used only to validate mechanics (not as SST evidence).

- G1: PASS
- G2: STRUCTURAL_PASS
- G3: PASS
- G4: STRUCTURAL_PASS
- G5: PASS on a synthetic exactly generated `k^2+k^4` mode table
- Overall: `FULL_PASS_WITH_MODE_DATA`

The G5 fit recovered the generated coefficients to numerical precision.

## Blind-lock negative test

After `PREANALYSIS_LOCK.json` was created, a threshold in a copied config was changed. `run_blind.py` rejected the run with a non-zero exit status due to the config SHA-256 mismatch.

## Important scope limit

This validates the software mechanics and numerical identities. It does not validate SST, the physical existence of a swirl phase field, or the identification of `r_c` as an EFT cutoff.
