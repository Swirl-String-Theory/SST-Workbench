# SST Phase-Feedback Delay Knot Stability Blind Falsifier v0.2.0

v0.2.0 is the prospective successor to v0.1.7. It fixes pseudoreplication, prevents train/holdout leakage, measures loop delay with an independent Kelvin packet transport experiment, and uses a dimensionless nonlinear growth response.

## Confirmatory run

```bat
run_00_install.cmd
run_05_find_input.cmd
run_07_preview_dataset.cmd
run_08_verify_preregistration.cmd
run_all_blind.cmd
run_40_reveal.cmd
```

Or in one command:

```bat
run_all.cmd "C:\path\to\NEW_campaign\out"
```

If no path is supplied the resolver will auto-discover an input directory; for a prospective run, `run_07_preview_dataset.cmd` must still report at least 8 novel unique geometries.

`run_all.cmd` in **confirmatory** mode excludes all identity geometries already seen in the completed v0.1.7 campaign. If fewer than 8 novel unique geometries remain, the result is `INCONCLUSIVE` by preregistration.

## Retrospective audit of the old matrix

To test the code path on the existing v0.1.7 matrix without making a new confirmatory claim:

```bat
run_all_legacy_audit.cmd
```

This deduplicates the old matrix and reports `claim_status = RETROSPECTIVE_ONLY`.

## Outputs

- `blind_work/dataset_audit.json` — counts only, no source labels.
- `blind_work/sealed_manifest.json` — one row per unique blind geometry.
- `results/packet_delay_predictions.json` — packet transport and phase scores.
- `results/nonlinear_measurements.json` — unforced nonlinear growth.
- `results/BLIND_EVALUATION.json` — frozen blind decision.
- `results/REVEALED_EVALUATION.json` — source labels attached after reveal.
- `results/PREPARATION_AUDIT.json` — duplicate/preparation endpoint audit.

See `docs/PREREGISTRATION_v0.2.0.md` for the frozen gates.

## Primary/extended rule

`basic` is the sole primary confirmatory endpoint. `extended` is robustness-only and cannot rescue a basic FAIL.
