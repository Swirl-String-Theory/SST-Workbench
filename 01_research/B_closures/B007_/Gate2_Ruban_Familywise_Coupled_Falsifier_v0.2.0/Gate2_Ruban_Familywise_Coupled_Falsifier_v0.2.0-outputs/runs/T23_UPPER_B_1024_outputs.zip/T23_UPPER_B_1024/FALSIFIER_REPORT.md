# Gate2 Ruban Familywise Coupled Falsifier v0.2.0

Scientific conclusion: **G2_UNRESOLVED_NO_CERTIFIED_EQUILIBRIUM**.

## What this run tested
- Families: ['T_2_3']
- B0: [0.28, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.44, 0.48]
- Lambda: [3.4, 4.0]
- Paired reduced-filament scenarios: 36
- G3 promoted resolutions: 4096
- G4 coupled Euler pilot runs: 0

## Gate statuses
- G1: PASS_ANALYTIC_GEOMETRY_SCREEN_ONLY
- G2: PASS_REDUCED_SCREEN_EXECUTED_RESOLUTION_LIMITED
- G3: RANKING_PROVISIONAL_NUMERICAL_CONVERGENCE_UNRESOLVED
- G4: NOT_RUN_USER_DISABLED

## Physical interpretation
This pipeline screens analytic torus seed families. It neither solves a fully deformable stationary Euler boundary-value problem nor proves nonlinear stability. The 3D Euler pilot is a finite periodic Gaussian-mollified vortex field with back-reaction, not a continuum equilibrium certificate.
Averaging or long survival under a reduced filament model is not a vanishing Euler residual.
Frozen-parameter convergence of the full-component Euler residual and topology-preserving material simulation are required before G2 PASS.

## Selected seeds
- T_2_3 B0=0.40000, Lambda=4.00; N=[4096]; score=0.274831

## Provenance
- E010 v0.3.6 generator SHA-256: 2c73d35fd58c9f4bcb4ddbb336021883d0bdff44051105750a68fa0fc6a0c609
- E010 v0.3.6 config SHA-256: c7b29996e665296a99c376be044c66eb0ebefe31ecd516a3e53e9b908679890d
KnotPlot labels for six links are metadata only; corresponding curves were analytically generated, not imported.
