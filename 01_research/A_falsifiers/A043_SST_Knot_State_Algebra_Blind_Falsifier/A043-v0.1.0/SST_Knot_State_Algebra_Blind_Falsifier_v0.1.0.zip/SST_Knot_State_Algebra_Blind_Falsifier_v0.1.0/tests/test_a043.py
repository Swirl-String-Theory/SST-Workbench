import csv, json
from pathlib import Path
import numpy as np
from sst_knot_state_algebra.rational_lane import pair_statistics, TWIST_CHAIN
from sst_knot_state_algebra.algebra import closure_metrics, double_cover_metrics
from sst_knot_state_algebra.dynamics import relative_equilibrium_score
from sst_knot_state_algebra.sources import discover_pklsa


def test_rational_lane_no_special_pair_needed():
    rows=[]
    for i,k in enumerate(TWIST_CHAIN):
        rows.append({"topology":k,"invariant":"x","value":1.7+.19*i+.007*i*i,"provider":"synthetic"})
    r=pair_statistics(rows,qmax=7,permutations=30,seed=1)
    assert len(r)==2*(len(TWIST_CHAIN)-1)
    assert all(x['best_q']<=7 for x in r)


def test_so3_closure_but_not_spinor():
    G=np.zeros((3,3,3))
    G[0]=[[0,0,0],[0,0,-1],[0,1,0]]
    G[1]=[[0,0,1],[0,0,0],[-1,0,0]]
    G[2]=[[0,-1,0],[1,0,0],[0,0,0]]
    m=closure_metrics(G)
    assert m['closure_relative_residual']<1e-12
    d=double_cover_metrics([0,2*np.pi,4*np.pi],[1,1,1])
    assert d['overlap_2pi_real']>0.9  # ordinary SO(3), therefore must fail a spinorial gate


def test_relative_equilibrium_finite():
    t=np.linspace(0,2*np.pi,64,endpoint=False)
    p=np.c_[np.cos(t),np.sin(t),0*t]
    m=relative_equilibrium_score([p],backend='python',core=.05)
    assert np.isfinite(m['re_residual'])


def test_pklsa_family_bundle_expands_48_variants(tmp_path: Path):
    (tmp_path/'families').mkdir()
    n=8
    data=np.empty((48,n,3),float)
    for v in range(48):
        t=np.linspace(0,2*np.pi,n,endpoint=False)
        data[v]=np.c_[(1+.001*v)*np.cos(t),(1+.001*v)*np.sin(t),0*t]
    bundle=tmp_path/'families'/'00_knot_0p1.npz'
    np.savez_compressed(bundle,coordinates=data)
    (tmp_path/'manifests').mkdir()
    (tmp_path/'manifests'/'SOURCE_MAP.json').write_text(json.dumps([{"family":"knot_0.1","bundle":"families/00_knot_0p1.npz"}]))
    fields=['index','candidate_id','family','canonical_id','topology_class','family_index','variant_index','component_count','points_per_component','construction_method','source_record','legacy_ptsa_id','parameters_json']
    with (tmp_path/'CANDIDATES_FULL.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for v in range(48):
            w.writerow({'index':v,'candidate_id':f'PKLSA_TEST_{v:02d}','family':'knot_0.1','canonical_id':'0_1','topology_class':'unknot','family_index':0,'variant_index':v,'component_count':1,'points_per_component':n,'construction_method':'synthetic','source_record':'test','legacy_ptsa_id':'','parameters_json':'{}'})
    rows,audit=discover_pklsa(tmp_path)
    assert len(rows)==48
    assert audit['loaded_families']==1
    assert not audit['family_errors']
    assert {r['variant_index'] for r in rows}==set(range(48))
