# Changelog v0.0.8

- Added the raw Wilson free-energy stationarity test.
- Added the one-loop adjacency-length stationarity test.
- Added the duality-normalized free-energy construction.
- Added the exact modified-Villain electric--magnetic duality fixed point.
- Added a hot/cold Wilson Monte Carlo at \(\beta=1/(2\pi)\).
- Derived the link action impedance \(\mathcal J_\ell=\hbar\beta_Q\).
- Audited phase-action versus full-cycle impedance normalization.
- Identified the calibrated identity
  \(\rho_{\rm horn}\Gamma_0r_c^3\simeq\hbar\).
- Reclassified the apparent three-route agreement as a dependency collapse.
- Defined the resolved-knot action target for v0.0.9.
