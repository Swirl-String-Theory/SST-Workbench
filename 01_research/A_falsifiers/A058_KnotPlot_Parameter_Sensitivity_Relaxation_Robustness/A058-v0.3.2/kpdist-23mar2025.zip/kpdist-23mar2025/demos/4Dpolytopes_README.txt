Data for the 4D polytopes from 
http://astronomy.swin.edu.au/~pbourke/polyhedra/platonic4d/
