# Method

## Microstructure representation

The blind microstructure is an isotropic ensemble of divergence-free vortical Fourier modes. Directions \(\hat{\mathbf k}\) are sampled with a deterministic Fibonacci sphere. For every direction the code includes both orthonormal transverse polarizations, eliminating polarization-sampling bias.

This is a spectral Euler-vorticity microstructure, not a finite-core filament simulation. It is chosen for v0.1.0 because the affine Cauchy deformation law is exact and produces a clean falsifiable benchmark.

## Shear response

For each volume-preserving shear matrix \(F(\gamma)\), the code evaluates

\[
R(\gamma)=\left\langle
\frac{|F\boldsymbol\omega|^2}
{|F^{-T}\mathbf k|^2}
\right\rangle,
\]

normalized so that \(R(0)=1\). It fits the parity-even response

\[
\frac{R(+\gamma)+R(-\gamma)}{2}-1
=A_2\gamma^2+A_4\gamma^4.
\]

The measured Born modulus is reported as

\[
\frac{\mu_{\rm Born}}{\rho u_{\rm rms}^2}=A_2.
\]

## Why this is conservative

The deformation is Hamiltonian/frozen-in rather than dissipative. The campaign checks:

- even energy response under \(\gamma\to-\gamma\);
- exact return under the cycle \(F^{-1}F=I\);
- SO(3) objectivity when both microstructure and deformation are rotated;
- degeneracy of the two circular/helicity combinations.

These establish a conservative affine energy curvature. They do not establish a zero-frequency equilibrium shear modulus after nonlinear rearrangement.

## Required next step

A v0.2.x persistence campaign should evolve an isotropic vortical background under full 3D incompressible Euler dynamics, inject long-wavelength transverse probes, and measure poles of the retarded stress response. The decisive quantity is

\[
\lim_{k\to0}\frac{\omega_T(k)}{k}.
\]

A nonzero isotropic limit with vanishing attenuation in the continuum/time-step limits would support a true transverse wave sector. Relaxation to zero modulus would reject it.
