LIST {
	{ < knot_7.1_trial_001k_rr_010k_coarse_rr_050k_eqfinal.0.vect }
	{ < knot_7.1_trial_001k_rr_010k_coarse_rr_050k_eqfinal.0.struts.vect }
	{ < knot_7.1_trial_001k_rr_010k_coarse_rr_050k_eqfinal.0.dlen.vect }
	{ < knot_7.1_trial_001k_rr_010k_coarse_rr_050k_eqfinal.0.dVdt.vect }
}
