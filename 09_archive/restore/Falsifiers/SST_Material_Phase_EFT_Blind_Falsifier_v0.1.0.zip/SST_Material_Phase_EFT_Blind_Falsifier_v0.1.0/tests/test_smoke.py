import numpy as np
from sst_eft import native

def test_circle():
 t=np.linspace(0,2*np.pi,1000,endpoint=False); p=np.c_[np.cos(t),np.sin(t),0*t]
 q=native.resample(p,256); m=native.metrics(q)
 assert abs(m["length"]-2*np.pi)<2e-3
 assert abs(native.writhe(q))<1e-8
