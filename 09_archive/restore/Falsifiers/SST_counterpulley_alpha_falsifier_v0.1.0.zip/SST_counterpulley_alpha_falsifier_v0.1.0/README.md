# SST Counter-Pulley Alpha Falsifier v0.1.0

C++/pybind11 + Python falsification package for the hypothesis that two opposite circulation channels inside the ideal trefoil act as a hydrodynamic "pulley" and supply the small correction required by the SST geometric alpha baseline.

**Design rule:** the hydrodynamic solver is blind to the measured fine-structure constant. `sst_counterpulley/physics.py` contains no alpha value. Alpha enters only in the separate post-hoc module `sst_counterpulley/benchmark.py`.

## Hypothesis under test

Take an ideal trefoil centerline \(\mathbf X(s)\) with tube diameter \(D\). A closed Bishop material frame \((\mathbf t,\mathbf n,\mathbf b)\) defines two opposite channels

\[
\mathbf X_\pm(s)=\mathbf X(s)\pm a\,\mathbf n(s),
\qquad
\Gamma_+=+\Gamma,\quad \Gamma_-=-\Gamma.
\]

The pre-registered canonical geometry is

\[
\frac{a}{D}=\frac12,
\qquad
\frac{\epsilon}{D}=0.05,
\]

with \(\epsilon\) the Rosenhead-type regularization length used by the discrete filament kernel.  The regularized pair Hamiltonian is evaluated by midpoint quadrature,

\[
H_{ab}=\frac{\Gamma_a\Gamma_b}{8\pi}
\oint\!\oint
\frac{d\mathbf x_a\cdot d\mathbf x_b}
{\sqrt{|\mathbf x_a-\mathbf x_b|^2+\epsilon^2}}.
\]

Define

\[
E_{\rm self}=H_{++}+H_{--},\qquad
E_{\rm cross}=2H_{+-},
\]

and the parameter-free energy transfer factor

\[
G_E=\frac{E_{\rm self}+E_{\rm cross}}{E_{\rm self}},
\qquad
\delta_E=G_E-1.
\]

Only **after** the blind result is written do we test the explicit candidate mapping

\[
\alpha_{\rm pred}^{-1}
=\left(\frac{8\pi}{3}\mathcal L_{3_1}\right)G_E.
\]

This mapping is a falsifiable hypothesis, not a canonical SST identity.

## Bundled geometry

`data/ideal_3_1_1.txt` is the extracted `Id="3:1:1"` block from the user's `ideal.txt` knot table. Its metadata are

- `Conway="3"`
- `L="16.371637"`
- `D="1.000000"`
- 183 non-zero Fourier coefficient rows, up to harmonic 250.

The alpha baseline remains the independently pre-registered high-resolution trefoil ropelength

\[
\mathcal L_{3_1}=16.3714672385,
\]

so the geometry used by the flow calculation cannot silently redefine the alpha target.

## H0-H10 gates

| Gate | Test | Failure means |
|---|---|---|
| H0 | Blind protocol | alpha leaked into the hydrodynamic solver |
| H1 | Native/Python parity | C++ and fallback disagree numerically |
| H2 | Geometry/quadrature | centerline or offset-filament sampling is inadequate |
| H3 | Global sign reversal | scalar pair energy violates \((+,-)\leftrightarrow(-,+)\) invariance |
| H4 | Rigid invariance | result depends on translation/rotation |
| H5 | Scale collapse | dimensionless result depends on absolute scale |
| H6 | Resolution convergence | result is not numerically converged |
| H7 | Nuisance robustness | result depends too strongly on \(\epsilon/D\) or material-frame phase |
| H8 | First-order suppression | balanced counter-circulation does not suppress the odd/linear response |
| H9 | Parameter-free alpha hit | canonical blind correction misses the required alpha correction |
| H10 | No tuned in-core rescue | the predeclared in-core grid does not robustly reproduce the target |

A scientific failure of H7-H10 does **not** produce a non-zero process exit code. A non-zero code is reserved for numerical/protocol inconclusiveness.

## Windows quick start

```bat
install_requirements.cmd
build_native.cmd
native_preflight.cmd
run_quick.cmd
```

Full run:

```bat
run_full.cmd
```

Strict blind-then-benchmark workflow:

```bat
run_blind_then_benchmark.cmd
```

The benchmark command reads an already-written blind JSON file; it does not rerun the hydrodynamics.

## Manual commands

```bash
python -m pip install -r requirements.txt
python -m sst_counterpulley.build_ext_if_needed --force --strict

# Blind single case; no alpha imported
python run_blind.py --n 192 --offset-over-D 0.5 --eps-over-D 0.05 \
  --out audit_out/blind_canonical.json

# Only now compare with alpha
python run_benchmark.py audit_out/blind_canonical.json \
  --out audit_out/posthoc_alpha_benchmark.json

# H0-H10
python run_all_checks.py --out-dir audit_out_full

# Blind parameter sweep
python run_scan.py --n-values 64,96,128,192 \
  --offsets 0.05,0.10,0.20,0.30,0.40,0.50 \
  --eps-values 0.025,0.05,0.10,0.20
```

## Outputs

A full gate run writes:

- `audit_summary.json`
- `blind_canonical.json`
- `resolution_convergence.csv`
- `regularization_sweep.csv`
- `frame_phase_sweep.csv`
- `posthoc_alpha_benchmark.json`
- `posthoc_in_core_scan.csv`

The blind files can be archived/checksummed before the post-hoc benchmark is executed.

## Native/fallback contract

The package preserves the user's template behavior:

1. hash `cpp/native.cpp`;
2. rebuild `_native` only when required, unless `--force` is supplied;
3. try direct C++17 compilation;
4. fall back to a generated `setuptools build_ext --inplace` build;
5. if the native module is unavailable, use the NumPy/Python reference kernel.

`requirements.txt` explicitly contains **`setuptools`**, `wheel`, `pybind11`, `numpy`, and `pytest`.

## Interpretation boundaries

A positive H8 result alone does not derive alpha. It only supports the symmetry argument that a balanced counter-circulation construction can suppress an odd/first-order perturbation. For an alpha explanation to survive this v0.1.0 model, it must also give the correct correction magnitude without tuning and remain stable under regularization and material-frame choices.

If H9 fails by orders of magnitude, the correct conclusion is that **this specific energy-ratio mapping is falsified/unsupported**, not that all counter-vortex mechanisms are excluded. Alternative observables (phase holonomy, helicity transfer, or a constrained eigenmode) remain separate hypotheses and must be pre-registered before benchmarking.

## References

```latex
\begin{thebibliography}{9}

\bibitem{Saffman1992}
P. G. Saffman,
\emph{Vortex Dynamics},
Cambridge University Press (1992).
\href{https://doi.org/10.1017/CBO9780511624063}{doi:10.1017/CBO9780511624063}.

\bibitem{ChorinMarsden1993}
A. J. Chorin and J. E. Marsden,
\emph{A Mathematical Introduction to Fluid Mechanics}, 3rd ed.,
Springer (1993).
\href{https://doi.org/10.1007/978-1-4612-0883-9}{doi:10.1007/978-1-4612-0883-9}.

\bibitem{Bishop1975}
R. L. Bishop,
``There is More than One Way to Frame a Curve,''
\emph{American Mathematical Monthly} \textbf{82}, 246--251 (1975).
\href{https://doi.org/10.2307/2319846}{doi:10.2307/2319846}.

\end{thebibliography}
```
