from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3


def validate(config: dict, project_root: Path) -> dict:
    out_root = (project_root / config["output_root"]).resolve()
    db = out_root / "_catalog" / "catalog.sqlite3"
    issues: list[dict] = []
    counts = Counter()
    if not db.exists():
        raise FileNotFoundError(f"Missing catalog: {db}")
    con = sqlite3.connect(db)
    rows = con.execute("SELECT id,kind,crossings,family,relpath FROM objects ORDER BY kind,crossings,ordinal").fetchall()
    for katlas_id, kind, crossings, family, relpath in rows:
        counts[f"{kind}:{crossings}"] += 1
        p = out_root / relpath / "katlas.json"
        if not p.exists():
            issues.append({"id": katlas_id, "issue": "missing-katlas-json", "path": str(p)})
            continue
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:
            issues.append({"id": katlas_id, "issue": "invalid-json", "error": str(exc)})
            continue
        ident = data.get("identity", {})
        if ident.get("katlas_id") != katlas_id:
            issues.append({"id": katlas_id, "issue": "id-mismatch"})
        if int(ident.get("crossings", -1)) != crossings:
            issues.append({"id": katlas_id, "issue": "crossing-mismatch"})
        if crossings > int(config["max_crossings"]):
            issues.append({"id": katlas_id, "issue": "above-max-crossings"})
    con.close()
    report = {
        "schema": "SST-KATLAS-VALIDATION-1.0",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if not issues else "FAIL",
        "objects_total": len(rows),
        "counts": dict(sorted(counts.items())),
        "issues": issues,
        "notes": [
            "Missing individual presentation fields are not validation failures; Katlas coverage varies by object.",
            "12-crossing links are exported only if they are actually present in Links.rdf.gz; no IDs are fabricated."
        ]
    }
    path = out_root / "_catalog" / "VALIDATION_REPORT.json"
    path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report
