#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SST chi-phase package v10B.0
Track B: GP/NLSE core energy and ring-alpha extraction.

This module:
1. Solves the GP vortex ODE with a boundary-value solver (scipy solve_bvp).
2. Computes the full GP energy per unit length: kinetic + gradient + interaction.
3. Extracts the ring constant alpha_GP = 2 - C_GP.
4. Diagnoses the gap between alpha_GP(xi) and the NLS legacy value 1.61.

Authoring status: Research Track / CANON-compatible.

Key distinction from Track A (v10A.0):
- Track A: Euler / Biot-Savart.  Core has DISTRIBUTED vorticity (solid-body
  or smooth-matched profile).  Density uniform.
- Track B: GP / NLSE.  Core is IRROTATIONAL (v_theta = Gamma/2pi/r everywhere)
  with density DEPLETION rho = rho_0 * F^2(r).  Gradient and interaction
  energies included.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.integrate import solve_bvp, trapezoid
from scipy.optimize import brentq

# ---------------------------------------------------------------------------
# Physical / numerical constants
# ---------------------------------------------------------------------------
PHI = (1.0 + math.sqrt(5.0)) / 2.0
A0_STAR = (math.sqrt(385.0) - 13.0) / 4.0   # v6 chi-closure root
NLS_ALPHA_LEGACY = 1.61                       # legacy NLS notebook target
NLS_BETA_LEGACY  = 0.61


# ---------------------------------------------------------------------------
# GP vortex ODE
# ---------------------------------------------------------------------------
# Dimensionless form (xi = 1, hbar/m = 1, g rho_0 = 1/2):
#   F'' + F'/r - F/r^2 + F(1 - F^2) = 0
#   F(0) = 0,  F(inf) = 1
#
# Near-axis series: F(r) ~ C1 * r - (C1/8) * r^3 + O(r^5)
# Near-infinity:    F(r) ~ 1 - A * K1(sqrt(2) * r) + O(K1^2)

def _gp_rhs(r: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Right-hand side for scipy solve_bvp: y = [F, F']."""
    F, Fp = y
    r_safe = np.where(r < 1.0e-9, 1.0e-9, r)
    Fpp = -Fp / r_safe + F / r_safe**2 - F * (1.0 - F**2)
    return np.vstack([Fp, Fpp])


def _gp_bc(ya: np.ndarray, yb: np.ndarray, r_left: float = 0.02) -> np.ndarray:
    """Boundary conditions:
    - Left  (r = r_left << 1): F(r_left) = F'(r_left) * r_left   (near-axis: F ~ C*r)
    - Right (r = r_right):     F = 1
    """
    return np.array([ya[0] - ya[1] * r_left, yb[0] - 1.0])


def solve_gp_profile(
    r_left: float = 0.02,
    r_right: float = 20.0,
    n_init: int = 500,
    tol: float = 1.0e-10,
    max_nodes: int = 50_000,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, bool]:
    """Solve the GP vortex ODE on [r_left, r_right].

    Returns (r_arr, F_arr, Fp_arr, success).
    Uses the Pade approximation F ~ r/sqrt(r^2+2) as the initial mesh guess.
    """
    r_init = np.linspace(r_left, r_right, n_init)
    F_pade = r_init / np.sqrt(r_init**2 + 2.0)
    Fp_pade = 2.0 / (r_init**2 + 2.0)**1.5
    y_init = np.vstack([F_pade, Fp_pade])

    def bc(ya: np.ndarray, yb: np.ndarray) -> np.ndarray:
        return _gp_bc(ya, yb, r_left=r_left)

    sol = solve_bvp(
        _gp_rhs, bc, r_init, y_init,
        tol=tol, verbose=0, max_nodes=max_nodes,
    )
    return sol.x, sol.y[0], sol.y[1], bool(sol.success)


# ---------------------------------------------------------------------------
# Energy integrals
# ---------------------------------------------------------------------------

def compute_C_GP(
    r: np.ndarray,
    F: np.ndarray,
    Fp: np.ndarray,
    R_max: float,
    n_interp: int = 20_000,
) -> Dict[str, float]:
    """Compute the GP core constant C_GP and its decomposition.

    C_GP = integral_0^{R_max} [F^2/r + F'^2*r + (F^2-1)^2*r/4] dr - ln(R_max)

    Convergence: exponential in R_max once R_max >> xi = 1.

    The ring constant is: alpha_GP = 2 - C_GP  (with core radius a = xi in
    the thin-ring formula E = rho Gamma^2 R/2 [ln(8R/a) - alpha]).

    Returns a dict with C_GP, alpha_GP, and decomposed sub-integrals.
    """
    r_fine = np.linspace(r[0], min(R_max, r[-1] - 0.5), n_interp)
    F_fine = np.interp(r_fine, r, F)
    Fp_fine = np.interp(r_fine, r, Fp)

    integ_kin  = F_fine**2 / r_fine
    integ_grad = Fp_fine**2 * r_fine
    integ_int  = (F_fine**2 - 1.0)**2 * r_fine / 4.0

    I_kin  = float(trapezoid(integ_kin,  r_fine))
    I_grad = float(trapezoid(integ_grad, r_fine))
    I_int  = float(trapezoid(integ_int,  r_fine))

    C_kin  = I_kin - math.log(r_fine[-1])
    C_GP   = C_kin + I_grad + I_int
    alpha  = 2.0 - C_GP
    beta   = alpha - 1.0  # q = 0 line

    # Convention: to get legacy NLS alpha = 1.61, what effective core
    # radius a_eff must be used?
    a_eff_to_match_NLS = math.exp(2.0 - C_GP - NLS_ALPHA_LEGACY)

    return {
        "C_GP":                  C_GP,
        "C_kin":                 C_kin,
        "C_grad":                I_grad,
        "C_int":                 I_int,
        "C_decomp_sum":          C_kin + I_grad + I_int,
        "alpha_GP_a_eq_xi":      alpha,
        "beta_GP_q0_a_eq_xi":    beta,
        "NLS_legacy_alpha":      NLS_ALPHA_LEGACY,
        "NLS_legacy_beta":       NLS_BETA_LEGACY,
        "delta_alpha_raw":       alpha - NLS_ALPHA_LEGACY,
        "a_eff_to_match_NLS_xi": a_eff_to_match_NLS,
        "R_max_used":            float(r_fine[-1]),
        "virial_ratio_grad_int": I_grad / I_int if I_int > 0 else float("nan"),
    }


def convergence_table(
    r: np.ndarray,
    F: np.ndarray,
    Fp: np.ndarray,
    R_values: Optional[List[float]] = None,
    n_interp: int = 10_000,
) -> List[Dict[str, float]]:
    """Compute C_GP for a range of R_max values to show convergence."""
    if R_values is None:
        R_values = [4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 15.5]
    rows = []
    for Rv in R_values:
        if Rv > r[-1] - 0.5:
            continue
        res = compute_C_GP(r, F, Fp, R_max=Rv, n_interp=n_interp)
        rows.append({
            "R_max":    Rv,
            "C_GP":     res["C_GP"],
            "alpha_GP": res["alpha_GP_a_eq_xi"],
        })
    return rows


# ---------------------------------------------------------------------------
# Pade comparison
# ---------------------------------------------------------------------------

def pade_F(r: float | np.ndarray) -> float | np.ndarray:
    """Berloff Pade approximation: F_pade(r) = r / sqrt(r^2 + 2)."""
    return r / np.sqrt(r**2 + 2.0)


def pade_Fp(r: float | np.ndarray) -> float | np.ndarray:
    """Derivative of Pade: dF_pade/dr = 2 / (r^2 + 2)^{3/2}."""
    return 2.0 / (r**2 + 2.0)**1.5


def pade_C_GP(R_max: float = 15.0, n: int = 20_000) -> float:
    """C_GP from Pade approximation (approximate, for comparison only)."""
    r = np.linspace(0.001, R_max, n)
    F = pade_F(r)
    Fp = pade_Fp(r)
    integ = F**2 / r + Fp**2 * r + (F**2 - 1.0)**2 * r / 4.0
    return float(trapezoid(integ, r)) - math.log(R_max)


# ---------------------------------------------------------------------------
# Profile comparison table
# ---------------------------------------------------------------------------

def profile_comparison_rows(
    r_gp: np.ndarray,
    F_gp: np.ndarray,
) -> List[Dict[str, float]]:
    """Compare exact GP profile with Pade at selected radii."""
    r_check = [0.1, 0.2, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0, 8.0, 12.0]
    rows = []
    for ri in r_check:
        if ri >= r_gp[-1]:
            continue
        F_exact = float(np.interp(ri, r_gp, F_gp))
        F_pade_val = float(pade_F(ri))
        rows.append({
            "r":            ri,
            "F_exact":      F_exact,
            "F_pade":       F_pade_val,
            "delta_F":      F_exact - F_pade_val,
            "rho_exact":    F_exact**2,
            "rho_pade":     F_pade_val**2,
        })
    return rows


# ---------------------------------------------------------------------------
# Benchmark: verify alpha = 2 - C_core for known Euler models
# ---------------------------------------------------------------------------

def euler_benchmark_rows() -> List[Dict[str, float]]:
    """Compute C_core for hollow and Rankine cores; verify alpha = 2 - C_core."""
    rows = []

    # Hollow core: v_theta=0 for r<1, v_theta=1/r for r>1
    # e(R)/pi = integral_1^R 1/r dr = ln(R)
    # C_core = 0, alpha = 2
    rows.append({
        "model":            "hollow_Euler",
        "C_core_analytic":  0.0,
        "alpha_analytic":   2.0,
        "alpha_formula":    2.0 - 0.0,
        "match":            True,
    })

    # Rankine solid body: v_theta=r for r<1, v_theta=1/r for r>1
    # e(R)/pi = int_0^1 r^2*r dr + int_1^R r^{-2}*r dr = 1/4 + ln(R)
    # C_core = 1/4, alpha = 7/4
    rows.append({
        "model":            "Rankine_solid_Euler",
        "C_core_analytic":  0.25,
        "alpha_analytic":   7.0 / 4.0,
        "alpha_formula":    2.0 - 0.25,
        "match":            abs(2.0 - 0.25 - 7.0/4.0) < 1e-14,
    })

    return rows


# ---------------------------------------------------------------------------
# Summary dict
# ---------------------------------------------------------------------------

def run_track_b(
    r_left: float = 0.02,
    r_right: float = 20.0,
    R_eval: float = 12.0,
) -> Dict:
    """Run the full Track B computation and return a summary dict."""
    r, F, Fp, success = solve_gp_profile(r_left=r_left, r_right=r_right)
    if not success:
        raise RuntimeError("GP BVP solver did not converge.")

    C1_star = float(F[0]) / float(r[0])
    results = compute_C_GP(r, F, Fp, R_max=R_eval)
    conv_rows = convergence_table(r, F, Fp)
    profile_rows = profile_comparison_rows(r, F)
    euler_rows = euler_benchmark_rows()

    return {
        "success":        success,
        "n_nodes_bvp":    len(r),
        "C1_star":        C1_star,
        "pade_C1_star":   1.0 / math.sqrt(2.0),
        "core_results":   results,
        "convergence":    conv_rows,
        "profile":        profile_rows,
        "euler_benchmark": euler_rows,
    }


if __name__ == "__main__":
    import pprint
    res = run_track_b()
    pprint.pprint(res["core_results"])
