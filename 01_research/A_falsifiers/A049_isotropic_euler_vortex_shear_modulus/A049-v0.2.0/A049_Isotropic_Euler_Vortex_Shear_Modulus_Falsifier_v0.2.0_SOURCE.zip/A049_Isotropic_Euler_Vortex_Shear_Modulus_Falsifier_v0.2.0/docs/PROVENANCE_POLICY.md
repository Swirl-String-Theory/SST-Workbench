# Provenance policy

All blind numerical inputs, tolerances and output hashes are sealed before reveal. Canonical SST constants are absent from `configs/default.json` and enter only in `reveal.py` after successful seal verification. Python and native backends have separate evidence directories; native qualification requires explicit parity success.
