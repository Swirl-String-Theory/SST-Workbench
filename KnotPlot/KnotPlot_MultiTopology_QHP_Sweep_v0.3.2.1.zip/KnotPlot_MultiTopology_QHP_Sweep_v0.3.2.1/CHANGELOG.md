# v0.3.2.1

Fixes Stage-1 preparation failure:

```text
Component-count mismatch for 0.2.1: expected 2, parsed 1
```

`0.n.1` null controls are now synthesized directly as n separated equal-radius
unknotted circles. This guarantees the requested component count and keeps the
null topology explicit.

Examples:
- 0.2.1 -> 2 circles -> 600 beads -> [300,300]
- 0.3.1 -> 3 circles -> 900 beads -> [300,300,300]

Nontrivial links still use KnotPlot-exported geometry and strict component-count
validation.

QHP ranges, stages, timers, ETA logic, checkpointing and analysis are unchanged.
