# A049 v0.3.0 blind report

Backend: **python**
Pipeline: **PIPELINE_QUALIFIED**
Research question: **SUPPORTED_FOR_REGULARIZED_LINKED_FILAMENT_MICROCELL_ENSEMBLE**
Master-Factor Wave Closure: **NOT_CLOSED**

## Explicit linked-filament microstructure

- orientation isotropy Frobenius residual = 2.759409e-02
- initial Hopf |Lk|-1 max error = 1.153485e-02
- link change max = 1.119243e-03
- Hamiltonian energy drift = 2.592776e-03
- forward/backward shape residual = 2.538122e-15
- linked mu/rho = 1.713235443747e-02
- c_T/v_ref = 1.480338038223e-01
- max tested shear-plane spread = 5.856429e-02
- modulus persistence min ratio = 1.000000e+00
- applied-shear stress persistence min ratio = 9.941263e-01
- stored shear-energy relative drift max = 4.233210e-02
- linked-vs-unlinked modulus excess fraction = -8.900654e-03

## Master-Factor Wave Closure

- MF01 persistent modulus speed ratio: FAIL
- measured c_T/v_ref = 1.480338038223e-01; target = 5.000000000000e-01
- MF02 persistence: PASS
- MF03 non-overlap geometry: FAIL_TARGET_REQUIRES_CELL_OVERLAP
- target density scaling requires spacing/R = 1.332647e+00; non-overlap minimum = 3.000000e+00
- MF04 independent bulk-wave pole: NOT_REACHED_NO_INDEPENDENT_BULK_WAVE_POLE_TEST
- overall: NOT_CLOSED

## Qualification gates

- Q01_STATIC_TRANSVERSE_SAMPLING: PASS
- Q02_STATIC_A2_RECOVERY: PASS
- Q03_FILAMENT_ORIENTATION_ISOTROPY: PASS
- Q04_INITIAL_HOPF_LINKING: PASS
- Q05_UNLINKED_CONTROL: PASS
- Q06_HAMILTONIAN_ENERGY_DRIFT: PASS
- Q07_RK4_LOCAL_CONVERGENCE: PASS
- Q08_TIME_REVERSIBILITY: PASS
- Q09_OBJECTIVITY: PASS
- Q10_FILAMENT_RESOLUTION: PASS
- Q11_BARE_REST_EULER_NO_WAVE: PASS

## Hypothesis gates

- H01_NONZERO_LINKED_FILAMENT_SHEAR_MODULUS: PASS
- H02_MODULUS_PERSISTS_UNDER_BIOT_SAVART: PASS
- H03_MACRO_SHEAR_STRESS_PERSISTS: PASS
- H04_TOPOLOGY_PRESERVED: PASS
- H05_TRANSVERSE_STIFFNESS_ISOTROPIC_AT_TESTED_ORDER: PASS
- H06_CONSERVATIVE_REVERSIBLE_DYNAMICS: PASS
- H07_LINKING_IS_SPECIFIC_SOURCE_OF_MODULUS: FAIL

## Scope guard

v0.3.0 replaces the random spectral background by explicit closed finite-core regularized Biot-Savart vortex filaments. The ensemble consists of independent Hopf-linked microcells with a preregistered effective cell volume; it is not yet a connected continuum vortex network. Positive shear curvature and stress persistence therefore qualify this microcell model, not all Euler fluids.
