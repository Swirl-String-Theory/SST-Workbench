# BEMv18 extended local scan — up to 7 crossings plus selected higher knots

Deze variant is gemaakt voor jouw exacte request:

\[
3_1,\ldots,7_7
\]

dus alle knopen tot en met 7 crossings, plus:

\[
8_1,\quad 9_1,\quad 9_2,\quad 10_1,\quad 11_1,\quad 11_2
\]

voor zover ze in `ideal.txt` staan.

## Wat de parser vindt in jouw huidige `ideal.txt`

Beschikbaar:

```text
8_1
9_1
9_2
10_1
```

Niet aanwezig in de huidige `ideal.txt`:

```text
11_1
11_2
```

De totale beschikbare targetset is daarom 18 knopen:

```text
3_1
4_1
5_1, 5_2
6_1, 6_2, 6_3
7_1, 7_2, 7_3, 7_4, 7_5, 7_6, 7_7
8_1
9_1, 9_2
10_1
```

## Eerst alleen target-plan maken

```bash
python routeB_RT_bem_v18_extended_local_scan.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v18_upto7_plus_plan \
  --dry-run-plan
```

## Lokale productie-run

```bash
python routeB_RT_bem_v18_extended_local_scan.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v18_upto7_plus \
  --run \
  --n-center 24 \
  --n-theta 5 \
  --n-sphere 96 \
  --tube-fraction 0.30 \
  --outer-factor 3.0 \
  --pair-fit-min-M 8 \
  --length-samples 12000
```

## Snellere test-run

```bash
python routeB_RT_bem_v18_extended_local_scan.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v18_upto7_plus_fast \
  --run \
  --n-center 8 \
  --n-theta 3 \
  --n-sphere 14 \
  --tube-fraction 0.34 \
  --outer-factor 2.4 \
  --pair-fit-min-M 4 \
  --length-samples 2000
```

## Resume/skip

De wrapper runt per target één BEMv13-map:

```text
outputs_routeB_BEM_v18_upto7_plus/runs/<knot>/
```

Als `alpha_component_budget_v13.csv` al bestaat, slaat hij die target over.

Forceer opnieuw draaien met:

```bash
--force
```

## Aggregate outputs

Na de run komt de exponent-test hier:

```text
outputs_routeB_BEM_v18_upto7_plus/aggregate/
```

Belangrijkste bestanden:

```text
aggregate/bemv18_exponent_certificate.csv
aggregate/bemv18_length_exponent_scan.csv
aggregate/bemv18_raw_multiknot_budget.csv
```

Sterk resultaat:

```text
certificate_status = PASS_CANONICAL_B2_SELECTED
selected_formula = M^1 L^2
```

Zwakker maar bruikbaar:

```text
PASS_CANONICAL_SUBLEADING_BUT_NOT_BEST_SCORE
```

Mislukking of onvoldoende:

```text
FAIL_NOT_ENOUGH_KNOTS
FAIL_CANONICAL_B2_NOT_SUBLEADING
```

## Status

Dit blijft een alpha-blinde falsifier/provenance test. Het bewijst \(\alpha\) niet. Het test of de BEMv17 claim \(q_{-2}\Rightarrow b=2\) over meerdere gecertificeerde knooplengtes standhoudt.
