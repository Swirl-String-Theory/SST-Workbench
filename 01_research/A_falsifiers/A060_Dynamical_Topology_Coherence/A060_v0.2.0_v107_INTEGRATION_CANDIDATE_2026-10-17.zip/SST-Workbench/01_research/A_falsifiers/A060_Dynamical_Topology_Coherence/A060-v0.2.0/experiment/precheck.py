"""Engineering checks, outside the unfrozen official campaign."""
from pathlib import Path
import json,hashlib,itertools,sys
import numpy as np
from a060_preflight.__main__ import run as legacy_run
from a060_preflight.mechanics import landreman_field,finite_jacobian,diagnostics,rank_one_gate,rank_two,direct_spherical_flux,gradient_flux_prediction
from a060_preflight.projection import projection_demo

def source_audit(root):
    root=Path(root); lock=json.loads((root/'sources/REFERENCE_HASHES.json').read_text());rows=[]
    for x in lock['papers']:
        p=root/'sources/papers'/x['filename']
        actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
        rows.append({'source_id':x['source_id'],'expected':x['sha256'],'actual':actual,'status':'MATCH' if actual==x['sha256'] else ('SOURCE_HASH_MISMATCH' if actual else 'UNRESOLVED')})
    return {'papers':rows,'all_match':all(x['status']=='MATCH' for x in rows),'registry':'UNRESOLVED'}

def analytic_jacobian(x,eps):
    x=np.asarray(x,float);X,Y,Z=x;a=np.sqrt(1+eps);b=np.sqrt(1-eps)
    s=X*X/(a*a)+Y*Y/(b*b);F=np.sqrt(1-(1-s)**2-4*Z*Z)
    if F<=0 or s<=0:raise ValueError('inadmissible analytic point')
    ds=np.array([2*X/a**2,2*Y/b**2,0.]);dF=((1-s)*ds-np.array([0.,0.,4*Z]))/F
    n1=2*Z*X-a/b*F*Y;n2=2*Z*Y+b/a*F*X
    dn1=np.array([2*Z,0.,2*X])-a/b*(Y*dF+np.array([0.,F,0.]))
    dn2=np.array([0.,2*Z,2*Y])+b/a*(X*dF+np.array([F,0.,0.]))
    return np.stack([(dn1*s-n1*ds)/s**2,(dn2*s-n2*ds)/s**2,-ds])

def run_analytic(root):
    root=Path(root); legacy=legacy_run(root/'sources/papers',root/'sources/REFERENCE_HASHES.json')
    hs=[1e-3,5e-4,2.5e-4]; errors=[]; residual=[]; n=0
    for eps in [0.,.2,.5]:
        for point in itertools.product([.8,1.,1.2],[-.12,0.,.12],[-.04,0.,.04]):
            x=np.array(point);J=analytic_jacobian(x,eps);v=landreman_field(x,eps);n+=1
            errors.append([float(np.max(np.abs(finite_jacobian(lambda z:landreman_field(z,eps),x,h)-J))) for h in hs])
            residual.append(max(abs(np.trace(J)),float(np.max(np.abs(J@v+x*np.array([1,1,4])))),abs(-np.trace(J@J)-6)))
    err=np.max(errors,axis=0);ratios=err[:-1]/err[1:]
    volume={'samples':n,'h':hs,'max_jacobian_errors':err.tolist(),'refinement_ratios':ratios.tolist(),'max_analytic_residual':max(residual),'engineering_pass':bool(np.all(ratios>3.5) and max(residual)<1e-11)}
    proj={str(n):projection_demo(n) for n in [17,25,33]}
    rng=np.random.default_rng(1337);rotation_error=0.
    for _ in range(64):
        A=rng.normal(size=(3,3));A-=np.trace(A)/3*np.eye(3);R,_=np.linalg.qr(rng.normal(size=(3,3)))
        if np.linalg.det(R)<0:R[:,0]*=-1
        d1=diagnostics(A);d2=diagnostics(R@A@R.T)
        rotation_error=max(rotation_error,max(abs(d1[k]-d2[k]) for k in ['Q','R','f','m','Rs','Vs']))
    epsilons=np.logspace(-8,-2,13);exponents={}
    for sign in [-1,1]:
        ys=[max(abs(np.linalg.eigvals(rank_one_gate(eps=e,sign=sign)))) for e in epsilons]
        exponents['rank_one_'+str(sign)]=float(np.polyfit(np.log(epsilons),np.log(ys),1)[0])
    ys=[max(abs(np.linalg.eigvals(rank_two(eps=e)))) for e in epsilons]
    exponents['rank_two']=float(np.polyfit(np.log(epsilons),np.log(ys),1)[0])
    quad=[]
    for ell,nmu,nphi in itertools.product([.25,.7,1.5],[6,12,18],[12,24,36]):
        A=np.array([[1.,2.,0.],[.4,-.3,1.],[0.,.2,-.7]])
        rhs=gradient_flux_prediction(A,ell);lhs=direct_spherical_flux(A,ell,nmu,nphi)
        quad.append(abs(lhs-rhs)/(1+abs(rhs)))
    # Solenoidal cubic field u=(y+beta*y*y*z,z,x); symmetric increments at zero.
    # Cubic terms survive symmetric increments and give a retained higher-mode remainder.
    ell=.7;beta=.8;mu,w=np.polynomial.legendre.leggauss(36);phi=np.arange(72)*2*np.pi/72
    st=np.sqrt(1-mu**2)[:,None];nx=st*np.cos(phi);ny=st*np.sin(phi);nz=np.broadcast_to(mu[:,None],nx.shape)
    du=np.stack([ell*ny+beta*ell**3*ny**2*nz/4,ell*nz,ell*nx],axis=-1);normals=np.stack([nx,ny,nz],axis=-1)
    flux=float(-3/(4*ell)*np.sum(np.sum(du*du,axis=-1)*np.sum(du*normals,axis=-1)*w[:,None])/(2*72))
    A=np.array([[0.,1.,0.],[0.,0.,1.],[1.,0.,0.]])
    dipole=gradient_flux_prediction(A,ell)
    nonlinear={'diameter':ell,'beta':beta,'direct_flux':flux,'local_gradient_flux':dipole,'higher_mode_remainder':flux-dipole,'note':'Manufactured solenoidal cubic field; measured remainder retained, no turbulence claim.'}
    result={'schema':'A060-ENGINEERING-CONTROLS-1','certified':False,'legacy':legacy,'volume_refinement':volume,'projector_grids':proj,'rotation_max_error':rotation_error,'perturbation_exponents':exponents,'quadrature_max_error':max(quad),'nonaffine_remainder':nonlinear}
    result['engineering_pass']=bool(volume['engineering_pass'] and rotation_error<1e-10 and max(quad)<1e-12 and all(x['precheck_status']=='REFERENCE_PASS' for x in legacy['results'].values()))
    return result

def main():
    root=Path(__file__).resolve().parents[1];out=root/'evidence';out.mkdir(exist_ok=True)
    result=run_analytic(root); (out/'ENGINEERING_PRECHECK.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print('Engineering controls:', 'PASS' if result['engineering_pass'] else 'FAIL','/ NOT CERTIFIED')
    return 0 if result['engineering_pass'] else 2
if __name__=='__main__': raise SystemExit(main())
