# VortexLab v7.6.24f3

## Scope

Gerichte HUD-interactiehotfix bovenop v7.6.24f2. Er zijn geen wijzigingen aan de solver, benchmarkscenario's, KnotPlot-data, kandidaatwetten of researchgates.

## Opgelost

- Een ingeklapte LIVE/SPEC/STATS/SPARK-tab is opnieuw volledig klikbaar om uit te klappen.
- In ingeklapte toestand start slepen uitsluitend via de expliciete `⋮⋮`-grip of via de 9 px brede vensterrand.
- In uitgeklapte toestand blijft de volledige titelbalk sleepbaar.
- Een enkele klik op een uitgeklapte titelbalk klapt het venster niet onbedoeld in.
- Dubbelklik op titelbalk of rand wisselt open/dicht.
- `Shift` + dubbelklik dockt het venster terug en klapt het in.
- De minimale sleepdrempel is verhoogd van 4 px naar 6 px om klikjitter niet als drag te classificeren.
- De workflowstatus uit v7.6.24f2 wordt naar de f3-session key gemigreerd, zodat reeds behaalde ENGINE-ontgrendelingen niet onnodig verloren gaan.

## Regressiedekking

De ingebouwde T0e24c-selftest controleert nu:

- gesloten SPARK-body werkelijk verborgen;
- klik op gesloten tab opent;
- enkele klik op geopende titel houdt hem open;
- dubbelklik sluit;
- alle onderste widgets hebben drag-binding.

Een geïsoleerde Chromium-eventharness bevestigde daarnaast:

- gesloten titelcentrum sleept niet;
- gesloten grip sleept wel;
- geopende titel sleept wel;
- dubbelklik klapt in.

## Roadmap

v7.6.24f3 sluit de 7.6.24-stabilisatiereeks af. De volgende inhoudelijke versie is:

`v7.6.25 · continue DCSD/reach-solver`.
