from pathlib import Path
import csv
import hashlib
import json
import math
import os
import numpy as np

from .backend import energy_ratio_general, backend_name
from .reference import (
    fit_even_energy_coefficient,
    isotropy_tensor,
    transverse_residual,
    energy_ratio_helicity_pair,
    transverse_wave_ratio_from_A2,
    linearized_rest_euler_frequency,
)
from .sampling import paired_transverse_samples, rotation_matrix, shear_matrix


THEORY_A2 = 2.0 / 15.0
THEORY_MU_OVER_E0 = 4.0 / 15.0
THEORY_C_OVER_URMS = math.sqrt(THEORY_A2)


def _load_config(config_path):
    return json.loads(Path(config_path).read_text(encoding="utf-8"))


def _write_csv(path, fieldnames, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_seal(blind_dir):
    blind = Path(blind_dir)
    seal = blind / "BLIND_SEAL_SHA256.txt"
    if not seal.exists():
        return False, ["BLIND_SEAL_SHA256.txt missing"]
    expected = {}
    for line in seal.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        digest, rel = line.split("  ", 1)
        expected[rel] = digest
    errors = []
    for rel, digest in expected.items():
        p = blind / rel
        if not p.exists():
            errors.append(f"missing:{rel}")
        elif _sha256(p) != digest:
            errors.append(f"hash:{rel}")
    return len(errors) == 0, errors


def run_blind_campaign(config_path, out_dir):
    cfg = _load_config(config_path)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    tol = cfg["tolerances"]
    gammas = np.asarray(cfg["strain_amplitudes"], dtype=float)
    planes = list(cfg["shear_planes"])

    n_pair, w_pair, n_base, e1, e2 = paired_transverse_samples(cfg["n_directions"])

    trans_res = transverse_residual(n_pair, w_pair)
    iso = isotropy_tensor(n_base)
    iso_res = float(np.linalg.norm(iso - np.eye(3) / 3.0))

    scan_rows = []
    plane_fits = {}
    max_odd = 0.0
    max_helicity_split = 0.0

    for plane in planes:
        rplus = []
        rminus = []
        for g in gammas:
            fp = shear_matrix(+g, plane)
            fm = shear_matrix(-g, plane)
            rp = energy_ratio_general(n_pair, w_pair, fp)
            rm = energy_ratio_general(n_pair, w_pair, fm)
            rplus.append(rp)
            rminus.append(rm)
            even_delta = 0.5 * (rp + rm) - 1.0
            odd = 0.5 * (rp - rm)
            max_odd = max(max_odd, abs(odd))

            hp, hm = energy_ratio_helicity_pair(n_base, e1, e2, fp)
            max_helicity_split = max(max_helicity_split, abs(hp - hm))
            scan_rows.append({
                "plane": plane,
                "gamma": float(g),
                "R_plus": rp,
                "R_minus": rm,
                "even_delta": even_delta,
                "odd_component": odd,
                "helicity_plus_ratio": hp,
                "helicity_minus_ratio": hm,
            })

        fit = fit_even_energy_coefficient(gammas, rplus, rminus)
        fit["relative_error_vs_2_over_15"] = abs(fit["A2"] - THEORY_A2) / THEORY_A2
        fit["mu_over_energy_density"] = 2.0 * fit["A2"]
        fit["mu_over_rho_urms2"] = fit["A2"]
        fit["candidate_cT_over_urms"] = transverse_wave_ratio_from_A2(fit["A2"])
        plane_fits[plane] = fit

    A2_values = np.array([plane_fits[p]["A2"] for p in planes], dtype=float)
    A2_mean = float(np.mean(A2_values))
    A2_spread = float((np.max(A2_values) - np.min(A2_values)) / abs(A2_mean))
    c_ratio = transverse_wave_ratio_from_A2(A2_mean)

    # Exact objectivity check: rotate both microstructure and imposed deformation.
    rot_rows = []
    max_objectivity = 0.0
    g_obj = float(cfg["objectivity_strain"])
    f0 = shear_matrix(g_obj, "xy")
    ref_ratio = energy_ratio_general(n_pair, w_pair, f0)
    for j in range(int(cfg["rotation_trials"])):
        q = rotation_matrix(int(cfg["seed"]) + 1009 * (j + 1))
        nr = n_pair @ q.T
        wr = w_pair @ q.T
        fr = q @ f0 @ q.T
        rr = energy_ratio_general(nr, wr, fr)
        err = abs(rr - ref_ratio)
        max_objectivity = max(max_objectivity, err)
        rot_rows.append({"trial": j, "reference_ratio": ref_ratio, "rotated_ratio": rr, "abs_error": err})

    # Conservative cycle F^{-1}F = I.
    fcycle = np.linalg.inv(f0) @ f0
    cycle_ratio = energy_ratio_general(n_pair, w_pair, fcycle)
    cycle_error = abs(cycle_ratio - 1.0)

    # Bare homogeneous-rest Euler has no transverse linear restoring operator.
    kprobe = np.array([1.0, 2.0, -3.0])
    uprobe = np.cross(kprobe, np.array([0.3, -0.4, 0.8]))
    uprobe /= np.linalg.norm(uprobe)
    rest_accel_res, rest_transverse_res = linearized_rest_euler_frequency(kprobe, uprobe)

    master_target = float(cfg["master_factor_wave_gate"]["target_cT_over_reference_speed"])
    master_tol = float(cfg["master_factor_wave_gate"]["absolute_tolerance"])
    master_error = abs(c_ratio - master_target)
    required_rms_mapping = master_target / c_ratio if c_ratio > 0.0 else math.inf

    qualification_gates = {
        "Q01_TRANSVERSE_CONSTRAINT": trans_res < tol["transverse_max_abs"],
        "Q02_ORIENTATION_ISOTROPY": iso_res < tol["orientation_isotropy_fro_max"],
        "Q03_A2_THEORY_RECOVERY": abs(A2_mean - THEORY_A2) / THEORY_A2 < tol["A2_relative_error_max"],
        "Q04_SHEAR_PLANE_ISOTROPY": A2_spread < tol["plane_spread_relative_max"],
        "Q05_CONSERVATIVE_PARITY": max_odd < tol["odd_energy_abs_max"],
        "Q06_ROTATION_OBJECTIVITY": max_objectivity < tol["objectivity_abs_max"],
        "Q07_CYCLIC_REVERSIBILITY": cycle_error < tol["cycle_abs_max"],
        "Q08_HELICITY_DEGENERACY": max_helicity_split < tol["helicity_split_abs_max"],
        "Q09_BARE_REST_EULER_NO_WAVE": rest_accel_res < tol["rest_euler_operator_abs_max"],
    }
    qualification_gates = {k: bool(v) for k, v in qualification_gates.items()}

    hypothesis_gates = {
        "H01_NONZERO_AFFINE_BORN_MODULUS": A2_mean > tol["A2_nonzero_min"],
        "H02_POSITIVE_AFFINE_BORN_MODULUS": A2_mean > 0.0,
        "H03_ISOTROPIC_AFFINE_BORN_MODULUS": A2_spread < tol["plane_spread_relative_max"],
        "H04_CONSERVATIVE_FROZEN_IN_RESPONSE": (
            max_odd < tol["odd_energy_abs_max"] and cycle_error < tol["cycle_abs_max"]
        ),
    }
    hypothesis_gates = {k: bool(v) for k, v in hypothesis_gates.items()}

    master_gate = master_error <= master_tol

    pipeline_status = "PIPELINE_QUALIFIED" if all(qualification_gates.values()) else "PIPELINE_FAILED"
    affine_status = (
        "SUPPORTED_AT_FROZEN_IN_AFFINE_BORN_LEVEL"
        if all(hypothesis_gates.values()) and pipeline_status == "PIPELINE_QUALIFIED"
        else "NOT_SUPPORTED"
    )
    master_status = "PASS" if master_gate else "FAIL"

    summary = {
        "catalog_id": cfg.get("catalog_id", "A049"),
        "falsifier": "A049_isotropic_euler_vortex_shear_modulus_falsifier",
        "version": cfg["version"],
        "blind": True,
        "backend": backend_name(),
        "pipeline_status": pipeline_status,
        "research_question_status": affine_status,
        "relaxed_static_modulus_status": "NOT_TESTED_IN_V0.1.0",
        "propagating_wave_status": "CONDITIONAL_ON_MODULUS_PERSISTENCE_NOT_ESTABLISHED",
        "master_factor_wave_closure_status": master_status,
        "scope_guard": (
            "This release tests the instantaneous/frozen-in affine (Born) response of an isotropic "
            "Euler-vorticity spectral microstructure. It does not establish a nonzero zero-frequency "
            "relaxed shear modulus or a propagating vacuum-wave mode under full nonlinear Euler evolution."
        ),
        "analytic_benchmark": {
            "energy_ratio_quadratic_A2": THEORY_A2,
            "mu_over_energy_density": THEORY_MU_OVER_E0,
            "candidate_cT_over_urms": THEORY_C_OVER_URMS,
        },
        "measurements": {
            "n_directions": int(cfg["n_directions"]),
            "n_transverse_samples": int(len(n_pair)),
            "transverse_max_abs": trans_res,
            "orientation_tensor": iso.tolist(),
            "orientation_isotropy_fro": iso_res,
            "plane_fits": plane_fits,
            "A2_mean": A2_mean,
            "A2_plane_relative_spread": A2_spread,
            "mu_over_energy_density": 2.0 * A2_mean,
            "mu_over_rho_urms2": A2_mean,
            "candidate_cT_over_urms": c_ratio,
            "max_odd_energy_component": max_odd,
            "max_objectivity_abs": max_objectivity,
            "cycle_energy_ratio": cycle_ratio,
            "cycle_abs_error": cycle_error,
            "helicity_split_max_abs": max_helicity_split,
            "bare_rest_euler_acceleration_operator_abs": rest_accel_res,
            "bare_rest_euler_transverse_residual": rest_transverse_res,
        },
        "master_factor_wave_gate": {
            "target_cT_over_reference_speed": master_target,
            "measured_cT_over_urms": c_ratio,
            "absolute_error": master_error,
            "absolute_tolerance": master_tol,
            "status": master_status,
            "required_urms_over_reference_speed_for_exact_closure": required_rms_mapping,
            "guard": (
                "The gate assumes the blind reference microstructure RMS speed maps one-to-one to the "
                "revealed SST characteristic swirl speed. If a different mapping is independently derived, "
                "the closure must be re-evaluated without fitting it to this result."
            ),
        },
        "qualification_gates": qualification_gates,
        "hypothesis_gates": hypothesis_gates,
    }

    _write_csv(out / "shear_scan.csv", list(scan_rows[0].keys()), scan_rows)
    _write_csv(out / "rotation_objectivity.csv", list(rot_rows[0].keys()), rot_rows)
    (out / "blind_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    report = [
        "# A049 v0.1.0 blind report",
        "",
        f"Backend: **{summary['backend']}**",
        f"Pipeline: **{pipeline_status}**",
        f"Research question: **{affine_status}**",
        f"Master-Factor Wave Closure Gate: **{master_status}**",
        "",
        "## Core result",
        "",
        f"- fitted A2 = {A2_mean:.12e}",
        f"- analytic 2/15 = {THEORY_A2:.12e}",
        f"- mu/(rho u_rms^2) = {A2_mean:.12e}",
        f"- candidate c_T/u_rms = {c_ratio:.12e}",
        f"- shear-plane relative spread = {A2_spread:.12e}",
        f"- required RMS/reference mapping for 1/2 closure = {required_rms_mapping:.12e}",
        "",
        "## Scope",
        "",
        summary["scope_guard"],
    ]
    (out / "blind_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")

    print(json.dumps(summary, indent=2))
    if pipeline_status != "PIPELINE_QUALIFIED":
        raise SystemExit(1)
    return summary
