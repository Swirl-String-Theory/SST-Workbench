Private A058-v0.2.6 semantic mappings, conditional sector-context default probes, execution logs, and reveal material. The velocity-dependent sector is enabled with `velforce = on` and controlled by `velmag`; its GUI note recommends Undamped dynamics, while this campaign intentionally preserves the user-requested Damped + No-Collide regime as a compatibility/response test.

S3/spring fixed default contract for this KnotPlot build: `amech = on` then `spring = 1`; spring is setter-verified because it is not present in the runtime `parameters` dump.
