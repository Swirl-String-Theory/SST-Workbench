# SST chi-phase package v10B.0 — Track B: GP/NLSE vortex-ring constant

## Summary

v10B.0 is the Track B counterpart to v10A.0 (Euler / Biot-Savart).

It computes the vortex-ring constant alpha from the full GP/NLSE energy
functional, including density depletion, amplitude gradient, and
interaction terms.

## Key results

    C1* (axis slope of GP vortex) = 0.5831  (Pade: 0.7071, error 21% at axis)

    C_GP  = 0.133   decomposed as:
              C_kin  = -0.395  (KE deficit from density depletion)
              C_grad = +0.279  (F-gradient energy)
              C_int  = +0.249  (interaction / (F^2-1)^2 energy)

    alpha_GP(a = xi) = 2 - C_GP = 1.867

    NLS legacy target:  alpha = 1.61  (notebook, convention: a = 1.29 * xi)
    Difference:         +0.257  (+16%)

## Convention diagnosis

The gap between 1.867 and 1.61 is a **convention gap**, not a physics
discrepancy.

The ring energy formula is:

    E = rho Gamma^2 R/2 * [ln(8R/a) - alpha]

The value of alpha depends on which radius 'a' is inserted into ln(8R/a).

- Track B uses a = xi (healing length = 1 in our dimensionless units).
- The NLS legacy value 1.61 uses a_eff = 1.29 * xi, where the GP profile
  has F(a_eff) ≈ 0.63 (approximately the half-density radius).

Once the core-radius convention is fixed, both results are consistent.

## Track comparison

| Method                      | alpha      | a convention |
|-----------------------------|------------|--------------|
| Euler / hollow              | 2.000      | a = tube boundary |
| Euler / Rankine solid body  | 1.750      | a = tube boundary |
| Track A / smooth_a0* (Euler)| 1.505      | a = tube boundary |
| Track B / GP (this package) | **1.867**  | a = xi        |
| NLS legacy (notebook)       | 1.610      | a = 1.29 xi   |

## Epistemic status

Track B is a **CANON-compatible Research Track** result:
- Non-circular: GP ODE is solved from first principles (no free parameters).
- Convention-transparent: the gap to legacy NLS is explicitly tracked.
- Honest: does NOT derive alpha = 1.61 from GP dynamics with a = xi.

Open gate: SST must motivate which core-radius convention (a = xi, or
a = a_eff = 1.29 xi, or other) is physically correct in the vortex-filament
model.  Only then can the Track B result be directly compared with the NLS
notebook target.

## Run

```bash
python simulate_chi_phase_v10B0.py
```

## Exports

- `chi_v10B0_core_constants.csv`
- `chi_v10B0_convergence.csv`
- `chi_v10B0_profile_comparison.csv`
- `chi_v10B0_euler_benchmark.csv`
- `chi_v10B0_run_results_summary.txt`

## Relation to other packages

- v8: derives beta = alpha - 1 + q (non-circular, confirmed)
- v9: synthetic intercept roundtrip (pipeline test only)
- v10A.0: Euler/Biot-Savart, alpha_0 ~ 1.50 for smooth profiles
- **v10B.0**: GP/NLSE full energy, alpha = 1.87 (a = xi)
