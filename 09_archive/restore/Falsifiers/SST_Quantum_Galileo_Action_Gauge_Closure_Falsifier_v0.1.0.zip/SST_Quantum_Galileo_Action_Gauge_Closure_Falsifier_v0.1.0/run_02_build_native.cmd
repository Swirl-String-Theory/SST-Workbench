@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo [2/7] Build C++17 / pybind11 native backend
echo ============================================================
call .venv\Scripts\activate.bat
python setup.py build_ext --inplace
if errorlevel 1 (
  echo ERROR: native build failed.
  echo Install Visual Studio Build Tools with "Desktop development with C++".
  exit /b 1
)
python -c "import sst_qgi_native; print('native backend: cpp-pybind11')"
if errorlevel 1 exit /b 1
endlocal
