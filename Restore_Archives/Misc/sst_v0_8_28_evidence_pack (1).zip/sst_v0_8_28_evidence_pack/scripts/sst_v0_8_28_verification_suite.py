#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sst_v0_8_28_verification_suite.py
=================================
Consolidated, single-file numerical verification suite for the
**Swirl-String Theory (SST) Canon v0.8.28** (successor of the
v0.8.12 / v0.8.17 evidence-pack suites).

Scope rule (unchanged from earlier editions):
    This file is a *numerical claim ledger*.  It is NOT a LaTeX compilation
    test, NOT a proof of canon consistency, and NOT a derivation of anything.
    Every calibrated identity is labelled as such.  Sections that record an
    obstruction record NO pass/fail, because an obstruction is not a check
    that can be passed.

New in the v0.8.28 edition (delta vs v0.8.17 pack):
  * section `actionphase`  -- action-phase mass-shell clock bridge
      (canon Sec. "Action--Phase Mass--Shell Route to Internal Clock Dilation",
       eq:action_phase_mass_shell_hamiltonian ... eq:action_phase_shape_extremum_equivalence)
      including the fixed-momentum guard (Omega_0/gamma vs gamma*Omega_0)
      and the low-momentum inertia normalization M_0 = E_0/c^2.
  * section `massbaseline` -- the v0.8.26 transparency identity
      M_0(T) = 2 pi^3 rho_horn r_c^5/lambda_c^2 * L_tot(T) == (m_e/4) L_tot(T)
      (eq:pure_geometric_mass_baseline / eq:M0_me_quarter_reduction),
      i.e. the explicit demonstration that the "pure geometric baseline"
      is an electron-anchored length functional.
  * F_max Rydberg form pinned to the corrected 16 pi^2 coefficient
      (eq:Fmax_Rydberg, v0.8.26 [ERRATUM]) with an explicit 32 pi^2 guard.
  * Planck-suppressed F_max identity (eq:Fmax_planck_suppressed).
  * core sound speed c_s = vchar/sqrt(2) (eq:core_sound_speed_vchar_over_sqrt2).
  * kernel normalization scale guard (eq:kernel_normalization_scale_guard).
  * `sstcore_alignment` now calls the *installed* SSTcore package when present
    instead of mirroring C++ formulas by hand, and reports the code/canon
    version gap explicitly.

Usage:
  python3 sst_v0_8_28_verification_suite.py                 # all sections
  python3 sst_v0_8_28_verification_suite.py --list
  python3 sst_v0_8_28_verification_suite.py --only constants actionphase
  python3 sst_v0_8_28_verification_suite.py --json out.json
"""

import math
import sys
import json
import argparse

try:
    import numpy as np
    HAVE_NUMPY = True
except ImportError:
    HAVE_NUMPY = False

try:
    import SSTcore as sst
    HAVE_SSTCORE = True
    SSTCORE_VERSION = getattr(sst, "__version__", "unknown")
except Exception:
    HAVE_SSTCORE = False
    SSTCORE_VERSION = None

CANON_VERSION = "0.8.28"

# ===========================================================================
# CODATA-2018 constants  (the canon's own primitive input set)
# ===========================================================================
HBAR  = 1.054571817e-34
H     = 2.0*math.pi*HBAR
M_E   = 9.1093837015e-31
C     = 2.99792458e8
ALPHA = 7.2973525693e-3
E     = 1.602176634e-19
EPS0  = 8.8541878128e-12
G     = 6.67430e-11
KB    = 1.380649e-23
R_E   = E**2/(4*math.pi*EPS0*M_E*C**2)
R_INF = ALPHA**2*M_E*C/(4*math.pi*HBAR)
L_PLANCK = math.sqrt(HBAR*G/C**3)
T_PLANCK = math.sqrt(HBAR*G/C**5)

# Canon calibration set P_cal = {rho_f, vchar, omega_c}; alpha enters HERE.
VCHAR   = ALPHA*C/2.0                 # vchar = ||v_swirl|| = alpha c / 2
OMEGA_C = M_E*C**2/HBAR               # Compton angular frequency
R_C     = VCHAR/OMEGA_C               # = alpha hbar/(2 m_e c) = r_e/2
RHO_F   = 7.0e-7                      # sole genuinely free primitive (2 s.f.)

# External tabulated topological input (NOT derived in SST):
L_TREFOIL = 16.371637                 # ideal trefoil ropelength (Ashton et al. 2011)


# ===========================================================================
# Test harness
# ===========================================================================
class Suite:
    def __init__(self):
        self.records = []

    def check(self, claim, loc, tag, desc, got, expected, rel_tol=1e-6, unit=""):
        if expected == 0:
            rel = abs(got); ok = rel < rel_tol
        else:
            rel = abs(got-expected)/abs(expected); ok = rel <= rel_tol
        rec = dict(claim=claim, loc=loc, tag=tag, desc=desc,
                   got=float(got), expected=float(expected),
                   rel=float(rel), ok=bool(ok), unit=unit)
        self.records.append(rec)
        status = "PASS" if ok else "FAIL"
        print(f"  [{status}] claim {str(claim):>7} {tag:<14} {desc}")
        print(f"          got={got:.10g} {unit}  expected={expected:.10g} {unit}  "
              f"(rel.dev={rel:.2e}, tol={rel_tol:.0e})")
        return ok

    def check_max(self, claim, loc, tag, desc, got, maximum, unit=""):
        ok = got <= maximum
        self.records.append(dict(claim=claim, loc=loc, tag=tag, desc=desc,
                                 got=float(got), expected=float(maximum),
                                 rel=float(got/maximum) if maximum else float(got),
                                 ok=bool(ok), unit=unit))
        status = "PASS" if ok else "FAIL"
        print(f"  [{status}] claim {str(claim):>7} {tag:<14} {desc}")
        print(f"          got={got:.10g} {unit}  max={maximum:.10g} {unit}")
        return ok

    def check_min(self, claim, loc, tag, desc, got, minimum, unit=""):
        ok = got >= minimum
        self.records.append(dict(claim=claim, loc=loc, tag=tag, desc=desc,
                                 got=float(got), expected=float(minimum),
                                 rel=float(got/minimum) if minimum else float(got),
                                 ok=bool(ok), unit=unit))
        status = "PASS" if ok else "FAIL"
        print(f"  [{status}] claim {str(claim):>7} {tag:<14} {desc}")
        print(f"          got={got:.10g} {unit}  min={minimum:.10g} {unit}")
        return ok

    def note(self, claim, tag, text):
        self.records.append(dict(claim=claim, tag=tag, desc=text, note=True, ok=None))
        print(f"  [INFO ] claim {str(claim):>7} {tag:<14} {text}")

    def summary(self):
        graded = [r for r in self.records if r.get("ok") is not None]
        npass = sum(1 for r in graded if r["ok"])
        return npass, len(graded)


def header(title):
    print()
    print("="*78)
    print(title)
    print("="*78)


# ===========================================================================
# SECTION: constants -- primitive chain, tension scales, EMG numerics
# ===========================================================================
def sec_constants(S):
    header("SECTION constants  -- primitive calibration chain and tension scales")

    S.check(3, "eq:omega_c_compton", "[ORTHODOX]",
            "omega_c = m_e c^2/hbar", OMEGA_C, M_E*C**2/HBAR, unit="rad/s")
    S.note(3, "[PRECISION]",
           f"canon RT prints omega_c = 7.76344066e20 s^-1; CODATA-2018 chain gives "
           f"{OMEGA_C:.9e} s^-1 (rel.dev {abs(OMEGA_C-7.76344066e20)/OMEGA_C:.1e}) "
           f"-> last printed digit should read ...071, not ...066")

    S.check(5, "eta_0 = vchar/c", "[CALIBRATED]",
            "eta_0 = alpha/2 (alpha is INJECTED here, not derived)", VCHAR/C, ALPHA/2)

    S.check(2, "eq:rc_definition", "[DERIVED]",
            "r_c = vchar/omega_c", R_C, VCHAR/OMEGA_C, unit="m")
    S.check(2, "eq:rc_definition", "[CALIBRATED]",
            "r_c = alpha hbar/(2 m_e c)", R_C, ALPHA*HBAR/(2*M_E*C), unit="m")
    S.check(2, "eq:rc_definition", "[CALIBRATED]",
            "r_c = r_e/2 (Compton--electron-radius closure)", R_C, R_E/2, unit="m")
    S.check(2, "canonical numeric anchor", "[CALIBRATED]",
            "r_c = 1.40897017e-15 m", R_C, 1.40897017e-15, rel_tol=1e-8, unit="m")
    S.check(5, "canonical numeric anchor", "[CALIBRATED]",
            "vchar = 1.09384563e6 m/s", VCHAR, 1.09384563e6, rel_tol=1e-8, unit="m/s")

    Gamma0 = 2*math.pi*R_C*VCHAR
    S.check(4, "eq:gamma0 / eq:gamma0_reparam", "[DERIVED-in-chain]",
            "Gamma_0 = 2 pi r_c vchar = 2 pi vchar^2/omega_c",
            Gamma0, 2*math.pi*VCHAR**2/OMEGA_C, unit="m^2/s")
    S.check(4, "eq:pauli_barrier_numeric (Gamma_0 anchor)", "[CALIBRATED]",
            "Gamma_0 ~ 9.6836e-9 m^2/s", Gamma0, 9.6836e-9, rel_tol=1e-4, unit="m^2/s")

    rhoE = 0.5*RHO_F*VCHAR**2
    rhoM = rhoE/C**2
    S.check(7, "density hierarchy / eq:canonical_emg_numerical_hierarchy", "[CALIBRATED]",
            "rho_E = 1/2 rho_f vchar^2 = 4.1877439e5 Pa (rho_f free, 2 s.f.)",
            rhoE, 4.1877439e5, rel_tol=1e-6, unit="Pa")
    S.check(7, "density hierarchy", "[ORTHODOX]",
            "rho_m = rho_E/c^2", rhoM, rhoE/C**2, unit="kg/m^3")

    rho_horn = M_E*C**2/(2*math.pi*VCHAR**2*R_C**3)
    S.check(8, "eq:core_density / eq:rho_horn_eff", "[CALIBRATED]",
            "rho_horn = m_e c^2/(2 pi vchar^2 r_c^3) = 3.8934e18 kg/m^3",
            rho_horn, 3.8934e18, rel_tol=1e-4, unit="kg/m^3")
    S.check(8, "eq:pure_geometric_mass_baseline guard", "[CALIBRATED]",
            "rho_m/rho_horn ~ 1.20e-30 (symbol-collision factor, canon guard)",
            rhoM/rho_horn, 1.20e-30, rel_tol=5e-3)

    c_s = VCHAR/math.sqrt(2.0)
    S.check("L-cs", "eq:core_sound_speed_vchar_over_sqrt2", "[DERIVED-CONDITIONAL]",
            "c_s = Gamma_0/(2 sqrt2 pi r_c) = vchar/sqrt2 = 7.73465663e5 m/s",
            c_s, 7.73465663e5, rel_tol=1e-8, unit="m/s")
    S.check("L-cs", "eq:core_sound_speed_vchar_over_sqrt2", "[DERIVED]",
            "identity Gamma_0/(2 sqrt2 pi r_c) == vchar/sqrt2",
            Gamma0/(2*math.sqrt(2)*math.pi*R_C), c_s, unit="m/s")

    Fmax = HBAR*OMEGA_C/(2*R_C)
    S.check(13, "eq:Fmax_def", "[CALIBRATED]",
            "F_max = hbar omega_c/(2 r_c) = vchar hbar/(2 r_c^2)",
            Fmax, VCHAR*HBAR/(2*R_C**2), unit="N")
    S.check(13, "eq:Fmax_def numeric", "[CALIBRATED]",
            "F_max = 29.053507 N (canon printed value)",
            Fmax, 29.053507, rel_tol=1e-6, unit="N")
    S.note(13, "[PRECISION]",
           f"CODATA-2018 chain gives F_max = {Fmax:.7f} N; canon prints 29.053507 N "
           f"(rel.dev {abs(Fmax-29.053507)/Fmax:.1e}). The 7th significant digit of the "
           f"printed constant should read 29.053510.")
    S.check(14, "eq:Fmax_em", "[CALIBRATED]",
            "F_max = e^2/(16 pi eps0 r_c^2)", Fmax, E**2/(16*math.pi*EPS0*R_C**2), unit="N")
    S.check(14, "eq:Fmax_hac", "[CALIBRATED]",
            "F_max = h alpha c/(8 pi r_c^2)", Fmax, H*ALPHA*C/(8*math.pi*R_C**2), unit="N")
    S.check(14, "eq:Fmax_rho", "[CALIBRATED]",
            "F_max = pi r_c^2 rho_horn vchar^2 (rho_calc retired, v0.8.26)",
            Fmax, math.pi*R_C**2*rho_horn*VCHAR**2, unit="N")
    S.check(14, "eq:Fmax_planck_suppressed", "[CALIBRATED]",
            "F_max = (c^4/4G) alpha (r_c/l_P)^-2",
            Fmax, (C**4/(4*G))*ALPHA*(R_C/L_PLANCK)**(-2), unit="N")

    # --- v0.8.26 ERRATUM guard: 16 pi^2, not 32 pi^2 -----------------------
    F_ryd_16 = 16*math.pi**2*HBAR*R_INF**2*C/ALPHA**5
    F_ryd_32 = 32*math.pi**2*HBAR*R_INF**2*C/ALPHA**5
    S.check(15, "eq:Fmax_Rydberg [ERRATUM v0.8.26]", "[CALIBRATED]",
            "F_max = 16 pi^2 hbar R_inf^2 c/alpha^5", F_ryd_16, Fmax, rel_tol=1e-9, unit="N")
    S.check(15, "eq:Fmax_Rydberg 32pi^2 guard", "[GUARD]",
            "32 pi^2 form == 2 F_max (must NOT equal F_max)", F_ryd_32, 2*Fmax,
            rel_tol=1e-9, unit="N")
    S.check(15, "eq:Rydberg_Fmax", "[CALIBRATED]",
            "R_inf = F_max alpha^3/(4 pi m_e c^2)",
            Fmax*ALPHA**3/(4*math.pi*M_E*C**2), R_INF, unit="1/m")
    S.check(15, "eq:Rydberg_SST", "[CALIBRATED]",
            "R_inf = vchar^3/(pi r_c c^3)  (m_e hidden in r_c, alpha in both)",
            VCHAR**3/(math.pi*R_C*C**3), R_INF, unit="1/m")
    S.note(15, "[CIRCULARITY]",
           "eq:Rydberg_SST reduces exactly to R_inf = alpha^2 m_e c/(4 pi hbar): "
           "consistency check, NOT an independent derivation.")

    Fgr = C**4/(4*G); alpha_g = G*M_E**2/(HBAR*C)
    S.check(16, "eq:Fmax_ratio", "[CALIBRATED]",
            "F_max/F_gr = 4 alpha_g/alpha", Fmax/Fgr, 4*alpha_g/ALPHA)
    S.check(16, "eq:Fgr", "[ORTHODOX]",
            "F_gr = c^4/4G ~ 3.02563e43 N", Fgr, 3.02563e43, rel_tol=1e-5, unit="N")

    Fpp = E**2/(4*math.pi*EPS0*R_C**2)
    S.check(17, "eq:Coulomb_core", "[CALIBRATED]",
            "F_pp(r_c) = 4 F_max (quarter-Coulomb; arithmetic identity)", Fpp, 4*Fmax)

    Ke = Fmax/(2*R_C)
    S.check(18, "eq:omega_spring", "[CONDITIONAL DERIVED]",
            "omega_spring = sqrt(K_e/m_e) = omega_c/alpha  (n=2 POSITED)",
            math.sqrt(Ke/M_E), OMEGA_C/ALPHA, unit="rad/s")
    S.check(18, "eq:Espring", "[CONDITIONAL DERIVED]",
            "E_spring = 1/2 K_e r_c^2 = m_e c^2/8  (n=2 POSITED)",
            0.5*Ke*R_C**2, M_E*C**2/8, unit="J")

    S.check(32, "eq:canonical_gswirl_compton_reduction", "[CALIBRATED]",
            "G_swirl = vchar c^3 t_p^2/(r_c m_e) == G  (t_p imports orthodox G)",
            VCHAR*C**3*T_PLANCK**2/(R_C*M_E), G, rel_tol=1e-9, unit="m^3/kg/s^2")
    S.note(32, "[CIRCULARITY]",
           "t_p = sqrt(hbar G/c^5) contains G; the reduction is an algebraic closure, "
           "not a derivation of Newton's constant.")

    S_t = math.sqrt(1-VCHAR**2/C**2)
    S.check(33, "eq:canonical_emg_numerical_hierarchy", "[DERIVED]",
            "Swirl-Clock S(t) at vchar", S_t, 0.9999933436, rel_tol=1e-9)
    S.check(33, "eq:canonical_emg_numerical_hierarchy", "[DERIVED]",
            "optical index n_gamma-1 = 1/S - 1", 1/S_t-1, 6.6564858e-6, rel_tol=1e-7)


# ===========================================================================
# SECTION: gate -- alpha gate and kernel normalization guard
# ===========================================================================
def sec_gate(S):
    header("SECTION gate  -- 4/alpha geometric gate, BG-1 audit, kernel scale guard")

    lam_nonred = H/(M_E*C)
    S.check(12, "eq:alpha_gate_numeric_guard", "[CALIBRATED]",
            "lambda_c/(pi r_c) = 4/alpha REQUIRES the NON-reduced lambda_c = h/(m_e c)",
            lam_nonred/(math.pi*R_C), 4.0/ALPHA)
    S.check(12, "eq:alpha_gate_numeric_guard numeric", "[CALIBRATED]",
            "4/alpha = 5.48144e2", 4.0/ALPHA, 5.48144e2, rel_tol=1e-5)
    lam_red = HBAR/(M_E*C)
    S.note(12, "[BG-1]",
           f"reduced-lambda gate = {lam_red/(math.pi*R_C):.4f} = (4/alpha)/(2 pi) "
           f"= {(4/ALPHA)/(2*math.pi):.4f}; canon must keep the non-reduced definition.")
    S.note(12, "[ALPHA-GATE GUARD]",
           "lambda_c/(pi r_c) = 4/alpha is a calibrated rewriting; it is NOT a "
           "derivation of the fine-structure constant.")

    rhoE = 0.5*RHO_F*VCHAR**2
    rhoM = rhoE/C**2
    S.check(12, "eq:kernel_normalization_scale_guard", "[CALIBRATED]",
            "rho_m r_c^3 = 1.30330e-56 kg", rhoM*R_C**3, 1.30330e-56,
            rel_tol=1e-4, unit="kg")
    S.check(12, "eq:kernel_normalization_scale_guard", "[CALIBRATED]",
            "rho_m r_c^3 = 1.43072e-26 m_e", rhoM*R_C**3/M_E, 1.43072e-26, rel_tol=1e-4)
    Xi_needed = M_E/(rhoM*R_C**3*(4/ALPHA))
    S.check(12, "eq:kernel_normalization_scale_guard", "[CALIBRATED]",
            "electron-scale kernel must reach Xi ~ 1.28e23 (medium-to-particle hierarchy)",
            Xi_needed, 1.28e23, rel_tol=5e-3)
    S.note(12, "[CRITICAL NOTE]",
           "Xi coefficients are therefore calibrated matching coefficients carrying a "
           "1e23 hierarchy, not order-unity topological invariants.")


# ===========================================================================
# SECTION: actionphase -- NEW in v0.8.28
# ===========================================================================
def sec_actionphase(S):
    header("SECTION actionphase  -- action-phase mass-shell clock bridge (v0.8.28)")

    E0 = M_E*C**2
    Om0 = OMEGA_C

    def H_of_P(P):
        return math.sqrt(P*P*C*C + E0*E0)

    # --- Hamilton equations, exact algebra --------------------------------
    for beta in (0.1, 0.5, 0.9, 0.99, 0.999):
        gamma = 1.0/math.sqrt(1.0-beta*beta)
        P = gamma*E0*beta/C**2*C          # P = gamma E0 V/c^2 with V = beta c
        Hh = H_of_P(P)
        V = P*C*C/Hh                       # eq:action_phase_translation_velocity
        d_shell = (Hh*Hh - P*P*C*C - E0*E0)/E0**2
        d_V = V*Hh/(P*C*C) - 1.0
        Omega = (E0/Hh)*Om0                # eq:action_phase_lab_phase_rate
        d_Om = Omega*Hh/(Om0*E0) - 1.0
        S.check("AP-shell", "eq:rt_action_phase_residual_vector", "[DERIVED]",
                f"Delta_shell = 0 at V/c={beta}", d_shell, 0.0, rel_tol=1e-12)
        S.check("AP-V", "eq:rt_action_phase_residual_vector", "[DERIVED]",
                f"Delta_V = 0 at V/c={beta}", d_V, 0.0, rel_tol=1e-12)
        S.check("AP-Om", "eq:rt_action_phase_residual_vector", "[DERIVED]",
                f"Delta_Omega = 0 at V/c={beta}", d_Om, 0.0, rel_tol=1e-12)
        S.check("AP-gam", "eq:action_phase_mass_shell_clock_factor", "[DERIVED]",
                f"E_0/H = 1/gamma at V/c={beta}", E0/Hh, 1.0/gamma, rel_tol=1e-12)

    # --- fixed-momentum guard (canon: dH/dI at fixed P, NOT at fixed V) ----
    beta = 0.9
    gamma = 1.0/math.sqrt(1.0-beta*beta)
    fixedP_rate = Om0/gamma
    fixedV_rate = gamma*Om0
    S.check("AP-guard", "fixed-momentum guard", "[DERIVED]",
            "fixed-P angle rate = Omega_0/gamma", fixedP_rate, Om0/gamma, rel_tol=1e-12,
            unit="rad/s")
    S.check_min("AP-guard", "fixed-momentum guard", "[GUARD]",
                "fixed-V derivative gamma*Omega_0 differs by gamma^2 (must NOT be used)",
                fixedV_rate/fixedP_rate, gamma*gamma*(1-1e-12))
    S.note("AP-guard", "[CRITICAL NOTE]",
           "Differentiating H = gamma(V) E_0 at fixed V answers a different question; "
           "canon v0.8.28 explicitly forbids substituting it for the clock rate.")

    # --- Compton specialization table (RT companion) -----------------------
    OMC_PRINTED = 7.76344066e20
    table = [(0.0, 1.0, 7.76344066e20),
             (0.9, 0.435889894, 3.38400533e20),
             (0.99, 0.141067360, 1.09516808e20),
             (0.999, 0.044710178, 3.47104812e19)]
    for beta, inv_gamma_ref, Om_ref in table:
        inv_gamma = math.sqrt(1.0-beta*beta)
        S.check("AP-tab", "RT Compton specialization table", "[ORTHODOX]",
                f"1/gamma at V/c={beta}", inv_gamma, inv_gamma_ref, rel_tol=1e-8)
        S.check("AP-tab", "eq:rt_action_phase_compton_frequency", "[DERIVED]",
                f"Omega_e(V) = omega_c/gamma at V/c={beta} (vs RT printed value)",
                OMC_PRINTED*inv_gamma, Om_ref, rel_tol=1e-8, unit="1/s")

    # --- low-momentum inertia normalization -------------------------------
    P_small = 1e-4*E0/C
    exact = H_of_P(P_small) - E0
    newton_1 = P_small**2/(2*(E0/C**2))          # canon: M_0 = E_0/c^2
    newton_2 = P_small**2/(2*(2*E0/C**2))        # rejected: M = 2 E_0/c^2
    S.check("AP-inertia", "eq:action_phase_low_momentum_expansion", "[DERIVED]",
            "H - E_0 -> P^2/(2 M_0) with M_0 = E_0/c^2", newton_1, exact, rel_tol=1e-7,
            unit="J")
    S.check_min("AP-inertia", "eq:core_torsion_impedance_gate_main", "[GUARD]",
                "inertia 2E_0/c^2 fails the same expansion by a factor 2",
                exact/newton_2, 2.0*(1-1e-6))

    # --- no-shape-deformation consequence ---------------------------------
    # H(P,I,q) = sqrt(P^2c^2 + E0(q)^2); check dH/dq = (E0/H) dE0/dq and that
    # the rest-shape extremum is P-independent for a separable bridge.
    def E0_of_q(q, q_star=0.37):
        return M_E*C**2*(1.0 + 0.5*(q-q_star)**2)

    def H_of_Pq(P, q):
        return math.sqrt(P*P*C*C + E0_of_q(q)**2)

    def argmin_q(P, lo=0.0, hi=1.0):
        # golden-section minimization of H over q
        gr = (math.sqrt(5.0)-1.0)/2.0
        a, b = lo, hi
        for _ in range(300):
            c1 = b - gr*(b-a); c2 = a + gr*(b-a)
            if H_of_Pq(P, c1) < H_of_Pq(P, c2):
                b = c2
            else:
                a = c1
        return 0.5*(a+b)

    # (a) exact gradient identity dH/dq = (E_0/H) dE_0/dq  -- machine precision
    h = 1e-7
    for beta, q in ((0.5, 0.2), (0.9, 0.6), (0.99, 0.9)):
        gam = 1.0/math.sqrt(1-beta*beta)
        P = gam*M_E*C*beta
        dH = (H_of_Pq(P, q+h)-H_of_Pq(P, q-h))/(2*h)
        dE0 = (E0_of_q(q+h)-E0_of_q(q-h))/(2*h)
        S.check("AP-shape", "eq:action_phase_shape_extremum_equivalence", "[DERIVED]",
                f"dH/dq == (E_0/H) dE_0/dq at V/c={beta}, q={q}",
                dH, (E0_of_q(q)/H_of_Pq(P, q))*dE0, rel_tol=1e-7)

    # (b) Delta_q from an explicit constrained minimizer (resolution-limited)
    q_rest = argmin_q(0.0)
    max_shift = 0.0
    for beta in (0.5, 0.9, 0.99):
        gam = 1.0/math.sqrt(1-beta*beta)
        P = gam*M_E*C*beta
        max_shift = max(max_shift, abs(argmin_q(P)-q_rest)/0.37)
    S.check_max("AP-shape", "eq:rt_action_phase_residual_vector", "[DERIVED]",
                "Delta_q at the minimizer resolution floor (separable bridge)",
                max_shift, 1e-5)
    S.note("AP-shape", "[NUMERICAL FLOOR]",
           f"Delta_q = {max_shift:.2e} is set by the flatness of H near the minimum "
           f"(~sqrt(eps)); the exact statement is the gradient identity above, which "
           f"holds to 1e-7.")
    S.note("AP-shape", "[FALSIFIER]",
           "A reproducible non-zero Delta_q under refinement is evidence for an explicit "
           "momentum-shape coupling H_Pq, NOT for translation-induced flattening. "
           "See scripts/rt_action_phase_residuals.py for the discriminating counter-model.")
    S.note("AP", "[BRIDGE STATUS]",
           "H = sqrt(P^2c^2+E_0^2) and the internal action-angle pair are IMPORTED, "
           "not derived from the substrate. Canon label: [ORTHODOX FORM / SST BRIDGE / "
           "CONDITIONAL DERIVATION]; the open theorem target is unchanged.")


# ===========================================================================
# SECTION: massbaseline -- v0.8.26 transparency identity
# ===========================================================================
def sec_massbaseline(S):
    header("SECTION massbaseline  -- 'pure geometric baseline' transparency identity")

    rho_horn = M_E*C**2/(2*math.pi*VCHAR**2*R_C**3)
    lam_c = H/(M_E*C)
    L_tot = L_TREFOIL

    M0_geom = 2*math.pi**3*rho_horn*(R_C**5/lam_c**2)*L_tot
    M0_alg = (M_E/4.0)*L_tot
    S.check(40, "eq:pure_geometric_mass_baseline -> eq:M0_me_quarter_reduction",
            "[CALIBRATED]",
            "2 pi^3 rho_horn r_c^5/lambda_c^2 * L_tot == (m_e/4) L_tot (machine precision)",
            M0_geom, M0_alg, rel_tol=1e-12, unit="kg")
    S.check(40, "eq:M0_me_quarter_reduction anchor", "[CALIBRATED]",
            "M_0(T)/L_tot(T) = 2.277346e-31 kg = m_e/4",
            M0_geom/L_tot, 2.277346e-31, rel_tol=1e-6, unit="kg")
    S.check(40, "eq:M0_me_quarter_reduction consequence", "[CALIBRATED]",
            "M_0(3_1) = (1/4) L_3_1 m_e = 4.0929 m_e (does NOT reproduce m_e)",
            M0_geom/M_E, 4.0929, rel_tol=1e-4, unit="m_e")
    S.check(40, "r_c/lambda_c closure", "[CALIBRATED]",
            "r_c/lambda_c = alpha/(4 pi) (all alpha cancels in M_0)",
            R_C/lam_c, ALPHA/(4*math.pi))
    S.note(40, "[CRITICAL NOTE]",
           "The branch is an electron-anchored length functional, not a geometric mass "
           "prediction; m_e enters through rho_horn and must not be re-reported as output.")


# ===========================================================================
# SECTION: topology -- torus self-linking SL = pq (target-free)
# ===========================================================================
def sec_topology(S):
    header("SECTION topology  -- SL_tor(T(p,q)) = pq, target-free (eq:SL_torus_pq)")
    if not HAVE_NUMPY:
        S.note(20, "[SKIP]", "numpy required for the Gauss linking integral")
        return

    def gauss_linking(A, B):
        Am = 0.5*(A+np.roll(A, -1, 0)); dA = np.roll(A, -1, 0)-A
        Bm = 0.5*(B+np.roll(B, -1, 0)); dB = np.roll(B, -1, 0)-B
        s = 0.0
        for i in range(len(Am)):
            r = Am[i]-Bm; rn = np.linalg.norm(r, axis=1); rn[rn < 1e-12] = 1e-12
            cr = np.cross(np.broadcast_to(dA[i], dB.shape), dB)
            s += np.sum(np.einsum('ij,ij->i', r, cr)/rn**3)
        return s/(4*math.pi)

    def torus_knot_and_normal(p, q, R=2.0, a=0.7, n=2000):
        t = np.linspace(0, 2*math.pi, n, endpoint=False)
        rho = R + a*np.cos(q*t)
        curve = np.stack([rho*np.cos(p*t), rho*np.sin(p*t), a*np.sin(q*t)], 1)
        U = np.stack([np.cos(q*t)*np.cos(p*t),
                      np.cos(q*t)*np.sin(p*t), np.sin(q*t)], 1)
        return curve, U

    eps, all_ok = 0.04, True
    for (p, q) in [(2, 3), (2, 5), (2, 7), (2, 9), (2, 11), (3, 2), (3, 4)]:
        curve, U = torus_knot_and_normal(p, q)
        SL = gauss_linking(curve, curve+eps*U)
        ok = abs(abs(SL)-p*q) < 0.05
        all_ok &= ok
        print(f"    T({p},{q}): SL={SL:8.3f}  |SL|={abs(SL):6.3f}  pq={p*q:3d}  "
              f"{'PASS' if ok else 'FAIL'}  (sign = chirality sector)")
    S.records.append(dict(claim=20, loc="eq:SL_torus_pq", tag="[DERIVED]",
                          desc="SL_tor(T(p,q)) = pq, no target injected", ok=bool(all_ok)))
    print(f"    => target-free SL_tor = pq. The pq+1 lepton ladder = pq [DERIVED] "
          f"+ 1 [CONDITIONAL, spinor sector].  {'PASS' if all_ok else 'FAIL'}")
    S.note(20, "[DERIVED NEGATIVE]",
           "Ordinary U(1) closure minimizes E(chi) at chi=0 (boson). chi=+-1 requires "
           "the spinorial/Z_2 sector; theta=pi remains [POSIT, pinned by observation].")


# ===========================================================================
# SECTION: biotsavart -- A_K -> 1/(4 pi)
# ===========================================================================
def sec_biotsavart(S):
    header("SECTION biotsavart  -- Biot-Savart logarithmic coefficient A_K -> 1/(4 pi)")
    if not HAVE_NUMPY:
        S.note(45, "[SKIP]", "numpy required")
        return

    n = 1500
    t = np.linspace(0, 2*math.pi, n, endpoint=False)
    x = np.sin(t)+2*np.sin(2*t); y = np.cos(t)-2*np.cos(2*t); z = -np.sin(3*t)
    r = np.stack([x, y, z], 1)
    rp = np.roll(r, -1, 0)-r
    ds = np.linalg.norm(rp, axis=1)
    L = ds.sum(); ds_mean = ds.mean()
    That = rp/np.linalg.norm(rp, axis=1, keepdims=True)

    def E_bs(a):
        Etot = 0.0
        for i in range(n):
            d = r-r[i]; dist = np.sqrt((d*d).sum(1)+a*a)
            contr = (That@That[i])*ds*ds[i]/dist; contr[i] = 0.0
            Etot += contr.sum()
        return Etot/(8*math.pi)

    aa = np.array([2.0, 3.0, 4.5, 6.0, 8.0, 11.0])*ds_mean
    Es = np.array([E_bs(a) for a in aa])
    xK = np.log(L/aa); yK = Es/L
    A = np.vstack([xK, np.ones_like(xK)]).T
    (AK, _aK), *_ = np.linalg.lstsq(A, yK, rcond=None)
    S.check(45, "Route-3 Biot-Savart plateau", "[DERIVED]",
            "A_K trends to 1/(4 pi) (coarse run; torch sweep gives ratio 0.99992)",
            AK, 1/(4*math.pi), rel_tol=0.30)
    S.note(45, "[LIMIT]", f"A_K = {AK:.5f}, A_K*4pi = {AK*4*math.pi:.3f} "
                          f"(target 1.000; coarse single-curve demonstrator)")
    S.note(45, "[ORTHODOX]",
           f"ideal trefoil ropelength L_3_1 = {L_TREFOIL} is an EXTERNAL tabulated "
           f"invariant (Ashton-Cantarella-Piatek-Rawdon 2011), not an SST output.")


# ===========================================================================
# SECTION: onsager -- Kosterlitz-Thouless transition (SST-15 complement)
# ===========================================================================
def sec_onsager(S):
    header("SECTION onsager  -- 2D point-vortex KT transition (SST-15 complement)")
    Gamma = 2*math.pi*R_C*VCHAR
    T_KT = RHO_F*Gamma**2/(4*math.pi*KB)
    S.check("SST-15", "Onsager 2D point-vortex", "[DERIVED]",
            "T_KT = rho_f Gamma_0^2/(4 pi k_B) (closed form, dimension-checked)",
            T_KT, RHO_F*Gamma**2/(4*math.pi*KB), unit="K")
    S.note("SST-15", "[INFO]", f"T_KT = {T_KT:.6e} K at canonical (rho_f, Gamma_0); "
                               f"linear in rho_f, hence 2-s.f. accuracy only.")


# ===========================================================================
# SECTION: delay -- DDE locked-mode condition
# ===========================================================================
def sec_delay(S):
    header("SECTION delay  -- DDE locked-mode condition (eq:mode_condition)")
    omega0, kappa, tau = 1.0, 0.3, 2.0

    def residual(Om):
        return Om - omega0 + kappa*math.sin(Om*tau)

    def derivative(Om):
        return 1.0 + kappa*tau*math.cos(Om*tau)

    Om = omega0
    for _ in range(200):
        Om = omega0 - kappa*math.sin(Om*tau)

    S.check(26, "eq:mode_condition", "[CODE=CANON]",
            "Omega = omega_0 - kappa sin(Omega tau)", residual(Om), 0.0, rel_tol=1e-9)
    h = 1e-6
    fd = (residual(Om+h)-residual(Om-h))/(2*h)
    S.check(26, "delay_mode_selector Newton derivative", "[CODE=CANON]",
            "f'(Omega) = 1 + kappa tau cos(Omega tau)", derivative(Om), fd, rel_tol=1e-6)


# ===========================================================================
# SECTION: alpha -- OBSTRUCTION ledger (NOT a derivation)
# ===========================================================================
def sec_alpha(S):
    header("SECTION alpha  -- finite-cell coincidence + ppm OBSTRUCTION (not a derivation)")
    lead = 8*math.pi/3*L_TREFOIL
    gap_ppm = (lead-1/ALPHA)/(1/ALPHA)*1e6
    S.check(46, "eq:alpha_lead_finite_cell", "[BRIDGE ANSATZ]",
            "(8 pi/3) L_3_1 = 137.15471 (canon printed leading value)",
            lead, 137.15471, rel_tol=1e-6)
    S.check(46, "eq:alpha_lead_finite_cell ppm", "[COINCIDENCE]",
            "gap to CODATA alpha^-1 = 866 ppm", gap_ppm, 866.0, rel_tol=1e-3, unit="ppm")
    S.note(46, "[OBSTRUCTION]",
           "ppm closure needs w_perp = 1.0675; the round value 1 reaches only 10.5 ppm, "
           "and the GP core proxy gives w_perp ~ 2.076 (-157 ppm, wrong side).")
    S.note(46, "[NON-IDENTIFIABLE]",
           "the 10.5 ppm residual is absorbable by any of five sub-percent coefficients; "
           "G_0 (provenance) and G_1 (identifiability) block closure before Hessian work.")
    S.note(46, "[STATUS]",
           "alpha is NOT derived. Defensible content: alpha-free sub-per-mille leading "
           "coincidence with partially derived N_p = 4, plus a localized obstruction.")
    # deliberately no pass/fail on the obstruction itself


# ===========================================================================
# SECTION: pauli -- cutoff-calibrated benchmark
# ===========================================================================
def sec_pauli(S):
    header("SECTION pauli  -- Pauli-barrier benchmark ~7.6 eV (eq:pauli_barrier_numeric)")
    G0 = 2*math.pi*R_C*VCHAR
    a0 = 2*R_C/(ALPHA*ALPHA)
    L = 2*math.pi*a0
    a_cut = R_C
    V = (RHO_F*G0*G0/(4*math.pi))*(L/a_cut)
    S.check(38, "eq:pauli_barrier_scale", "[CALIBRATED]",
            "rho_f Gamma_0^2/(4 pi) (L/a_cut) with a_cut=r_c -> ~7.69 eV",
            V/E, 7.69365, rel_tol=1e-3, unit="eV")
    S.check(38, "eq:pauli_barrier_numeric", "[CALIBRATED]",
            "canon order-of-magnitude anchor 1.23e-18 J", V, 1.23e-18,
            rel_tol=2e-2, unit="J")
    S.check(38, "eq:pauli_barrier_acut_scaling", "[DERIVED]",
            "V(a_cut) scales as r_c/a_cut (factor 2 test)",
            (RHO_F*G0*G0/(4*math.pi))*(L/(2*R_C)), V/2.0, unit="J")
    S.note(38, "[CRITICAL NOTE]",
           "a_cut is a legacy UV regularization scale, NOT the resolved tube radius "
           "a_core; this is a benchmark, not a derivation of Pauli exclusion.")


# ===========================================================================
# SECTION: em_qed -- swirl<->EM normalization
# ===========================================================================
def sec_em_qed(S):
    header("SECTION em_qed  -- swirl/EM normalization, B_core = B_QED")
    B_core = (M_E/E)*OMEGA_C
    B_qed = M_E*M_E*C*C/(E*HBAR)
    S.check(61, "eq:canonical_em_prefactor_guard", "[CALIBRATED]",
            "(m_e/e) omega_c == m_e^2 c^2/(e hbar) == B_QED", B_core, B_qed, unit="T")
    S.check(67, "eq:canonical_qed_field_guard", "[ORTHODOX]",
            "B_QED = 4.414e9 T (Schwinger critical field)", B_qed, 4.4140052e9,
            rel_tol=1e-5, unit="T")
    wrong = (E/M_E)*OMEGA_C
    S.check_min(61, "inverted-prefactor guard", "[GUARD]",
                "(e/m_e) omega_c is not a tesla-valued quantity (rejected form)",
                wrong, 1e25)


# ===========================================================================
# SECTION: sstcore_alignment -- live SSTcore vs canon v0.8.28
# ===========================================================================
def sec_sstcore_alignment(S):
    header(f"SECTION sstcore_alignment  -- installed SSTcore {SSTCORE_VERSION} vs canon "
           f"v{CANON_VERSION}")
    if not HAVE_SSTCORE:
        S.note("code", "[SKIP]", "SSTcore not installed (pip install SSTcore)")
        return

    S.note("code", "[VERSION GAP]",
           f"SSTcore {SSTCORE_VERSION} vs canon v{CANON_VERSION}: the code mirror lags "
           f"the canon; alignment below is only for the primitive-chain layer.")

    K = sst.SSTCanonicalConstants
    T = sst.SSTTensionScales

    om = K.compton_angular_frequency(M_E, C, HBAR)
    S.check(3, "SSTcore:compton_angular_frequency", "[CODE=CANON]",
            "code omega_c == canon omega_c", om, OMEGA_C, unit="rad/s")

    rc = K.core_radius_from_compton_anchor(VCHAR, om)
    S.check(2, "SSTcore:core_radius_from_compton_anchor", "[CODE=CANON]",
            "code r_c == vchar/omega_c", rc, R_C, unit="m")

    g0a = K.circulation_quantum(rc, VCHAR)
    g0b = K.circulation_quantum_from_v_omega(VCHAR, om)
    S.check(4, "SSTcore:circulation_quantum(_from_v_omega)", "[CODE=CANON]",
            "2 pi r_c vchar == 2 pi vchar^2/omega_c", g0a, g0b, unit="m^2/s")
    S.check(4, "SSTcore:circulation_quantum vs canon", "[CODE=CANON]",
            "code Gamma_0 == canon Gamma_0", g0a, 2*math.pi*R_C*VCHAR, unit="m^2/s")

    rhoE = K.swirl_energy_density(RHO_F, VCHAR)
    S.check(7, "SSTcore:swirl_energy_density", "[CODE=CANON]",
            "0.5 rho_f vchar^2", rhoE, 0.5*RHO_F*VCHAR**2, unit="Pa")
    rhoM = K.mass_equivalent_density(rhoE, C)
    S.check(7, "SSTcore:mass_equivalent_density", "[CODE=CANON]",
            "rho_m = rho_E/c^2", rhoM, 0.5*RHO_F*VCHAR**2/C**2, unit="kg/m^3")

    rho_horn_code = K.horn_envelope_density(M_E, C, VCHAR, rc)
    rho_horn_alias = K.core_density_closure(M_E, C, VCHAR, rc)
    S.check(8, "SSTcore:horn_envelope_density == core_density_closure", "[CODE=CANON]",
            "alias holds (patch 0002 lineage)", rho_horn_code, rho_horn_alias,
            unit="kg/m^3")
    S.check(8, "SSTcore:horn_envelope_density vs eq:core_density", "[CODE=CANON]",
            "code rho_horn == m_e c^2/(2 pi vchar^2 r_c^3)",
            rho_horn_code, M_E*C**2/(2*math.pi*VCHAR**2*R_C**3), unit="kg/m^3")

    lam_full = K.full_compton_wavelength(HBAR, M_E, C)
    gate = K.geometric_gate(lam_full, rc)
    S.check(12, "SSTcore:geometric_gate", "[CODE=CANON]",
            "gate uses the NON-reduced lambda_c -> 4/alpha (BG-1 resolved)",
            gate, 4.0/ALPHA)

    F_code = K.f_swirl_max(HBAR, om, rc)
    F_ten = T.F_swirl_max(HBAR, om, rc)
    S.check(13, "SSTcore:f_swirl_max == SSTTensionScales.F_swirl_max", "[CODE=CANON]",
            "two code paths agree", F_code, F_ten, unit="N")
    S.check(13, "SSTcore:f_swirl_max vs eq:Fmax_def", "[CODE=CANON]",
            "code F_max == hbar omega_c/(2 r_c)", F_code, HBAR*OMEGA_C/(2*R_C), unit="N")

    R_code = K.rydberg_sst(VCHAR, rc, C)
    S.check(15, "SSTcore:rydberg_sst", "[CODE=CANON]",
            "code R_inf == vchar^3/(pi r_c c^3)", R_code, R_INF, unit="1/m")

    ag = T.gravitational_fine_structure(G, M_E, HBAR, C)
    ratio = T.tension_ratio_from_couplings(ag, ALPHA)
    Fgr = T.F_gr_max(C, G)
    S.check(16, "SSTcore:tension_ratio_from_couplings", "[CODE=CANON]",
            "4 alpha_g/alpha == F_max/F_gr", ratio, F_code/Fgr)

    Fpp = T.coulomb_force_at_core(E, EPS0, rc)
    S.check(17, "SSTcore:coulomb_force_at_core", "[CODE=CANON]",
            "e^2/(4 pi eps0 r_c^2) == 4 F_max", Fpp, 4*F_code, unit="N")

    wsp = T.electron_spring_frequency(F_code, rc, M_E, 2.0)
    S.check(18, "SSTcore:electron_spring_frequency", "[CODE=CANON]",
            "sqrt(K_e/m_e) == omega_c/alpha (n=2)", wsp, OMEGA_C/ALPHA, unit="rad/s")
    Esp = T.electron_spring_energy(F_code, rc, 2.0)
    S.check(18, "SSTcore:electron_spring_energy", "[CODE=CANON]",
            "0.5 K_e r_c^2 == m_e c^2/8 (n=2)", Esp, M_E*C**2/8, unit="J")

    # signature: compute_G_swirl(v_swirl, t_p, F_max, r_c, c)
    Gs = sst.SSTGravity.compute_G_swirl(VCHAR, T_PLANCK, F_code, rc, C)
    S.check(32, "SSTcore:compute_G_swirl", "[CODE=CANON]",
            "code G_swirl == G (t_p imports orthodox G)", Gs, G, rel_tol=1e-6,
            unit="m^3/kg/s^2")

    sc = K.swirl_clock(VCHAR, C)
    S.check(33, "SSTcore:swirl_clock", "[CODE=CANON]",
            "S(t) = sqrt(1-v^2/c^2)", sc, math.sqrt(1-VCHAR**2/C**2))

    ck = sst.ChronosKelvinTransport
    om_code = ck.omega_from_swirl_clock(sc, rc, C)
    vort_code = ck.vorticity_from_swirl_clock(sc, rc, C)
    S.check(9, "SSTcore:vorticity_from_swirl_clock", "[CODE=CANON]",
            "vorticity == 2 * omega_from_swirl_clock (patch 0001 convention)",
            vort_code, 2.0*om_code, unit="rad/s")

    # --- API gaps against v0.8.28 -----------------------------------------
    missing = []
    for name in ("action_phase_mass_shell", "mass_shell_hamiltonian",
                 "internal_clock_dilation", "action_phase_residuals"):
        if not any(name in n for n in dir(sst)):
            missing.append(name)
    S.note("code", "[API GAP]",
           "no SSTcore entry point for the v0.8.28 action-phase mass-shell bridge "
           f"(searched: {', '.join(missing)}); residuals live only in "
           "scripts/rt_action_phase_residuals.py.")
    S.note("code", "[CODE LAG]",
           "SSTcore exposes no M_0(T) = (m_e/4) L_tot(T) transparency helper; the "
           "v0.8.26 identity is verified here in Python only.")


# ===========================================================================
# SECTION: galactic -- research-track fit machinery (synthetic demo)
# ===========================================================================
def sec_galactic(S):
    header("SECTION galactic  -- swirl flat-tail fit machinery (research-track)")
    if not HAVE_NUMPY:
        S.note(42, "[SKIP]", "numpy required")
        return

    rng = np.random.default_rng(0)
    r = np.linspace(0.5, 18.0, 24)
    Vdisk = 120.0*np.sqrt(r)/np.sqrt(r+2.0)
    Vgas = 30.0*r/(r+6.0)
    Vbul = 80.0*np.exp(-r/1.5)
    Yd_true, Yb_true = 0.5, 0.7
    signed = lambda V: V*np.abs(V)
    Vbar2 = signed(Vgas) + Yd_true*signed(Vdisk) + Yb_true*signed(Vbul)
    Ctail_true, rs_true = 110.0, 3.0
    Vsw = Ctail_true*(1-np.exp(-r/rs_true))
    Vtrue = np.sqrt(np.maximum(Vbar2, 0) + Vsw**2)
    errV = np.full_like(r, 5.0)
    Vobs = Vtrue + rng.normal(0, errV)

    y = signed(Vobs) - signed(Vgas)
    w = 1.0/np.maximum((2.0*np.abs(Vobs)*errV)**2, 1e-12)
    best = None
    for rs in np.linspace(0.3, max(r)*1.5, 200):
        g = (1.0-np.exp(-r/rs))**2
        X = np.column_stack([signed(Vdisk), signed(Vbul), g])
        Wsqrt = np.sqrt(w)
        coef, *_ = np.linalg.lstsq(X*Wsqrt[:, None], y*Wsqrt, rcond=None)
        coef = np.clip(coef, 0.0, None)
        Vmodel = np.sqrt(np.maximum(signed(Vgas) + X@coef, 0.0))
        chi2 = float(np.sum(((Vobs-Vmodel)/errV)**2))
        if best is None or chi2 < best["chi2"]:
            best = dict(chi2=chi2, rs=float(rs), Yd=float(coef[0]), Yb=float(coef[1]),
                        Ctail=float(np.sqrt(coef[2])), Vmodel=Vmodel)

    chi2_red = best["chi2"]/max(len(r)-4, 1)
    S.check_max(42, "swirl flat-tail fitter", "[RESEARCH-TRACK]",
                "chi2/dof <= 1.5 on noisy synthetic data (machinery sanity only)",
                chi2_red, 1.5)
    S.note(42, "[RESEARCH-TRACK]",
           f"synthetic recovery: Y_disk={best['Yd']:.3f} (truth {Yd_true}), "
           f"Y_bul={best['Yb']:.3f} (truth {Yb_true}), C_tail={best['Ctail']:.1f} km/s "
           f"(truth {Ctail_true}), r_s={best['rs']:.2f} kpc (truth {rs_true})")
    S.note(42, "[OPEN]",
           "r_s is fitted, not derived; the coherence-length lemma is OPEN and no SPARC "
           "data is bundled. Unscreened galaxy-scale use of rho_f remains falsifiable.")


# ===========================================================================
# Section registry + CLI
# ===========================================================================
SECTIONS = {
    "constants":         sec_constants,
    "gate":              sec_gate,
    "actionphase":       sec_actionphase,
    "massbaseline":      sec_massbaseline,
    "topology":          sec_topology,
    "biotsavart":        sec_biotsavart,
    "onsager":           sec_onsager,
    "delay":             sec_delay,
    "alpha":             sec_alpha,
    "pauli":             sec_pauli,
    "em_qed":            sec_em_qed,
    "sstcore_alignment": sec_sstcore_alignment,
    "galactic":          sec_galactic,
}

NOT_BUNDLED = """
NOT BUNDLED / STILL OPEN (v0.8.28):
  * rho_f provenance: no independent calibration observable is stated in canon.
    Everything linear in rho_f (rho_E, rho_m, Pauli benchmark, dark-sector
    amplitudes, T_KT) inherits a few-percent uncertainty. No claim above that
    precision may be promoted.
  * alpha ppm closure: blocked at gates G_0 (input provenance) and G_1
    (identifiability). Not a derivation.
  * theta = pi superselection: [POSIT, pinned by observed fermion statistics];
    requires the Z_2 Hopf term via pi_4(S^2).
  * action-phase bridge: H = sqrt(P^2c^2+E_0^2) is imported, not derived from
    the substrate; open theorem target unchanged in v0.8.28.
  * KAM-T stage-1 numerics, boost-symmetry-breaking bound, and the full torch
    robustness sweep (N=32000) are not bundled.
  * SSTcore lags the canon; see section sstcore_alignment for [API GAP] items.
"""


def main():
    ap = argparse.ArgumentParser(
        description=f"SST Canon v{CANON_VERSION} numerical claim ledger")
    ap.add_argument("--list", action="store_true", help="list sections and exit")
    ap.add_argument("--only", nargs="+", metavar="SEC", help="run only these sections")
    ap.add_argument("--json", metavar="FILE", help="write machine-readable results")
    args = ap.parse_args()

    if args.list:
        print("Available sections:", ", ".join(SECTIONS)); return

    to_run = args.only if args.only else list(SECTIONS)
    bad = [s for s in to_run if s not in SECTIONS]
    if bad:
        print("Unknown section(s):", bad, "\nAvailable:", ", ".join(SECTIONS)); sys.exit(2)

    print("#"*78)
    print(f"# SST Canon v{CANON_VERSION} -- consolidated numerical claim verification suite")
    print(f"# numpy:   {'yes' if HAVE_NUMPY else 'NO (topology/biotsavart/galactic skipped)'}")
    print(f"# SSTcore: {SSTCORE_VERSION if HAVE_SSTCORE else 'not installed'}")
    print("#"*78)

    S = Suite()
    for name in to_run:
        SECTIONS[name](S)

    npass, ntot = S.summary()
    header(f"RESULT: {npass}/{ntot} graded checks passed "
           f"({len(to_run)} section(s): {', '.join(to_run)})")
    print(NOT_BUNDLED)

    if args.json:
        clean = [{k: v for k, v in r.items() if k != "note"} for r in S.records]
        with open(args.json, "w") as f:
            json.dump({"canon_version": CANON_VERSION,
                       "sstcore_version": SSTCORE_VERSION,
                       "passed": npass, "total": ntot, "records": clean},
                      f, indent=2, default=str)
        print(f"[wrote {args.json}]")

    sys.exit(0 if npass == ntot else 1)


if __name__ == "__main__":
    main()
