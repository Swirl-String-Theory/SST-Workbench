#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from sst_counterpulley.core import DEFAULT_DATA, run_blind_case, write_json

def main() -> int:
    ap=argparse.ArgumentParser(description="Run one blind counter-pulley hydrodynamic case. No alpha value is imported.")
    ap.add_argument("--data",default=str(DEFAULT_DATA))
    ap.add_argument("--id",default="3:1:1")
    ap.add_argument("--n",type=int,default=128)
    ap.add_argument("--offset-over-D",type=float,default=0.5)
    ap.add_argument("--eps-over-D",type=float,default=0.05)
    ap.add_argument("--force-python",action="store_true")
    ap.add_argument("--force-build",action="store_true")
    ap.add_argument("--build-verbose",action="store_true")
    ap.add_argument("--out",default="audit_out/blind_single.json")
    a=ap.parse_args()
    r=run_blind_case(data_path=a.data,knot_id=a.id,n=a.n,offset_over_D=a.offset_over_D,
                     eps_over_D=a.eps_over_D,force_python=a.force_python,
                     force_build=a.force_build,build_verbose=a.build_verbose)
    write_json(a.out,r)
    print(json.dumps(r,indent=2))
    return 0
if __name__=="__main__": raise SystemExit(main())
