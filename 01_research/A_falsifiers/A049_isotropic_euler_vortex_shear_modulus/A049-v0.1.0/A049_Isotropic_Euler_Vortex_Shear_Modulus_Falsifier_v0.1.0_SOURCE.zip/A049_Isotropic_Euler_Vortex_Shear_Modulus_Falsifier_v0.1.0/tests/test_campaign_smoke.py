from pathlib import Path
import json
from sst_vortex_shear.campaign import run_blind_campaign


def test_campaign_smoke(tmp_path):
    root = Path(__file__).resolve().parents[1]
    cfg = json.loads((root / "configs" / "default.json").read_text(encoding="utf-8"))
    cfg["n_directions"] = 1600
    cfg["tolerances"]["orientation_isotropy_fro_max"] = 6e-5
    cfg["tolerances"]["A2_relative_error_max"] = 2e-4
    cfg["tolerances"]["plane_spread_relative_max"] = 2e-4
    cfg["tolerances"]["odd_energy_abs_max"] = 3e-6
    p = tmp_path / "cfg.json"
    p.write_text(json.dumps(cfg), encoding="utf-8")
    s = run_blind_campaign(p, tmp_path / "out")
    assert s["pipeline_status"] == "PIPELINE_QUALIFIED"
    assert s["research_question_status"] == "SUPPORTED_AT_FROZEN_IN_AFFINE_BORN_LEVEL"
