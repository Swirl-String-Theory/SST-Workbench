@echo off
setlocal
if "%~1"=="" (echo Usage: %~nx0 ^<private_reveal.json^> [blind_output_dir] & exit /b 2)
set "OUT=%~2"
if "%OUT%"=="" set "OUT=SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs\basic"
call .venv\Scripts\activate.bat
python run_reveal.py "%OUT%" "%~1" || exit /b 1
python tools\pack_outputs.py SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs ..\SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs_REVEALED.zip --revealed || exit /b 1
