# Blind summary

Mode: **extended**

Cases: **49**

## Overall opaque statuses

- FAIL: 1
- INDETERMINATE: 48

A static-centerline-only `INDETERMINATE` is expected: absent phase/volume/probe data are never manufactured from geometry.

Freeze SHA-256: `0028f09cdbf9b6adb3c4a00e1af22ffbf97f19f23e1dff96277e92e31168bd1a`
