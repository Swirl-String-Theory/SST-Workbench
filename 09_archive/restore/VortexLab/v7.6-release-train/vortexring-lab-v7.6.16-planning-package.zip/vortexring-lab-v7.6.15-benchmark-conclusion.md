# VortexLab v7.6.15 — gevalideerde SPEC CLOCK-benchmarkconclusie

## Formele uitkomst

Twee onafhankelijke benchmarkexports leveren dezelfde tien scenarioresultaten:

- `ENGINE=PASS`
- `RESEARCH_PROXY=FAIL`

De exacte herhaling bevestigt dat de benchmarkrunner deterministisch is en dat v7.6.15 uitsluitend de eindstatusweergave heeft gecorrigeerd.

## Wat de benchmark heeft uitgesloten

De volgende verklaringen voor de fase–veld-mismatch zijn door de benchmark uitgesloten:

1. **Integratorbootstrap of te grote eerste stap.** Alle tien runs kalibreren bij `tPhys=0`; de grootste eerste stap is `0.05 s`.
2. **Afspeelsnelheid.** De resultaten bij 1×, 4× en 16× zijn exact gelijk voor afstand, faseproxy en geïntegreerde lag.
3. **Cilinderhoogte.** Bij `bgFlow=none` en uitgeschakelde bundel zijn totale hoogten van 1 m en 5 m exact equivalent.
4. **Inactieve BEM.** BEM aan/uit geeft bij uitgeschakelde bundel exact dezelfde resultaten.
5. **Grote autonome proxy-drift.** De nuldriftrun blijft binnen de engineering-gate.
6. **Gebroken A/B-symmetrie.** De traversalwissel keert het teken om met slechts circa 0.0097% magnitudemismatch.

## Structurele mismatch

Voor de baseline geldt

\[
\Delta\ln R_{AB}^{\rm phase-null}
=-1.6000277198249802\times10^{-9},
\]

terwijl de formele veldroute de bracket

\[
-2.2237823518222577\times10^{-22}
\leq
\Delta\ln R_{AB}^{\rm field}
\leq
2.220124051410927\times10^{-22}
\]

oplevert. De schaalverhouding is

\[
\frac{\left|\Delta\ln R_{AB}^{\rm phase-null}\right|}
{\max\left|\Delta\ln R_{AB}^{\rm field}\right|}
=7.195073378084202\times10^{12}.
\]

Dit verschil is te groot om als tolerantie-, afrondings- of resolutie-effect te behandelen. Het mag niet worden gecorrigeerd door een fitfactor of aangepaste SST-parameter.

## Wetenschappelijke interpretatie

De huidige fase-nullroute gebruikt

\[
\delta_i=
\frac{\Omega_i^{\rm full}-\Omega_i^{\rm iso}}
{|\Omega_i^{\rm iso}|},
\qquad
\Delta\ln R_{AB}^{\rm phase-null}
=
\ln(1+\delta_A-\delta_{A,0})
-
\ln(1+\delta_B-\delta_{B,0}).
\]

De veldroute gebruikt daarentegen de wederzijdse tangentiële Biot–Savart-snelheid in een formele log-klokbracket. De benchmark toont dat deze twee routes niet door numerieke uitvoering toevallig uiteenlopen; zij representeren momenteel verschillende observabelen of verschillende overdrachtswetten.

De juiste vervolgvraag is daarom niet hoe de proxy numeriek binnen de veldbracket kan worden gedwongen, maar:

> Welk deel van de body-Ω-faseproxy is daadwerkelijk wederzijds Biot–Savart-signaal, en welk deel ontstaat door geometrie, parametrisatie en rigid-motion-projectie?

## Besluit voor de volgende versie

v7.6.16 wordt gepland als een strikt passieve proxy-decompositiebenchmark. De bestaande faseproxy blijft ongewijzigd en niet-canoniek totdat de decompositie aantoont welke component de schaal van \(\Delta\ln R_{AB}^{\rm phase-null}\) domineert.
