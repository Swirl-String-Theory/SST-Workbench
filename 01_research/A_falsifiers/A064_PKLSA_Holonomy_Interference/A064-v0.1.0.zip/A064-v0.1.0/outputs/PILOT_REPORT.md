# A064 v0.1.0 — Source-aware numerical pilot

Required gates PASS: 33; FAIL: 0. Unresolved scientific gates: 6.

This report is not a blind run or physical SST validation. The toy Z2 charge was fixed before looking at geometry. See gate records for independent numerical checks.
