# SST chi-phase package v9 — alpha/beta ring-constant intercept audit

Status: **Research Track / audit scaffold**.

v9 is the successor to v8.  v8 derived the robust relation

\[
\beta = \alpha - 1 + q,
\qquad q=\frac{d\ln a}{d\ln R}.
\]

v9 adds the log-subtracted alpha-intercept machinery:

\[
E(R,a)=\frac12\rho\Gamma^2R\left[\ln\left(\frac{8R}{a}\right)-\alpha\right],
\]

so

\[
\alpha_{\rm eff}(R/a)=\ln\left(\frac{8R}{a}\right)-\frac{2E}{\rho\Gamma^2R}.
\]

The canon-level target would be

\[
\alpha=\lim_{a/R\to0}\alpha_{\rm eff}(R/a).
\]

This package does **not** yet solve the full vortex-ring Biot--Savart or NLSE/GP core energy.  It verifies the formula pipeline, target table, and synthetic intercept fitting.  A future v10 should replace the synthetic energy by an independent ring-energy solver.

## Run

```powershell
python simulate_chi_phase_v9.py
python simulate_chi_phase_v9.py --python
python sst_chi_phase_v9_build.py --force
```

## Outputs

- `exports/chi_v9_alpha_beta_targets.csv`
- `exports/chi_v9_synthetic_alpha_intercept.csv`
- `exports/chi_v9_run_results_summary.txt`
- plots when matplotlib is available

## Important interpretation

v9 is canon-safe for the formula

\[
\alpha_{\rm eff}=\ln(8R/a)-2E/(\rho\Gamma^2R)
\]

and for

\[
\beta=\alpha-1+q.
\]

It is **not** a canon proof of the absolute legacy NLS value \(\alpha=1.61\).  That requires an independent vortex-ring energy calculation or NLSE/GP matched-core calculation.
