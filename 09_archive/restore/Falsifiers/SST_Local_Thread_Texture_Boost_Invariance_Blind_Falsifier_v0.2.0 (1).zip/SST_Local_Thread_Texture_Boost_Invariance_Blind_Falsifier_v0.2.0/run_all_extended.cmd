@echo off
setlocal
cd /d "%~dp0"
set "DATASET=%~1"
if "%DATASET%"=="" set "DATASET=..\..\KnotPlot\knots\final"
echo ============================================================
echo SST Explicit Closed Vortex-Thread Blind Falsifier v0.2.0
echo EXTENDED + prior-holdout certification chain
echo Dataset: %DATASET%
echo ============================================================
echo [1/5] Install / update environment
call run_install.cmd
if errorlevel 1 goto :fail
echo [2/5] Strict native build
call run_build_native.cmd
if errorlevel 1 goto :fail
echo [3/5] Native-vs-Python + closed-thread + boost selftest
call run_selftest.cmd
if errorlevel 1 goto :fail
echo [4/5] Blind EXTENDED fixed-core N=128,256,512 campaign
call run_extended.cmd "%DATASET%"
if errorlevel 1 goto :fail
echo [5/5] Prior-v0.1 holdout certification N=512,1024 and temporal 8,16
call run_holdout_certification.cmd "%DATASET%"
if errorlevel 1 goto :fail
echo ============================================================
echo PASS - extended and holdout chains completed.
echo ============================================================
exit /b 0
:fail
echo ============================================================
echo FAIL - extended chain stopped with errorlevel %errorlevel%
echo ============================================================
exit /b %errorlevel%
