# Private reveal material

Generated reveal mappings belong here and must not be included in BLIND archives. `run_python.cmd` creates `reveal_map.json` only after the blind metrics have been sealed.
