#!/usr/bin/env bash
set -euo pipefail
python derive_blind.py --config config/reference.yaml
python run_campaign.py --config config/reference.yaml
python score_target.py --input outputs/blind_result.json --campaign outputs/campaign_summary.json || true
