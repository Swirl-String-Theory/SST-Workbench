# Route-A/L2 photon-gas consistency falsifier

## Executive verdict

The proposed `g_T = 9(4*pi)^2` factor is not a non-fitted degeneracy theorem. The integer `9` is a valid component count for a vector-valued 2-form in three dimensions. The factor `(4*pi)^2` is not a count; it is an angular measure. Without a derived orientation cell it is a convention and it double-counts degrees of freedom in a Weyl mode count.

## Photon-gas control

For a massless field in 3D, Weyl counting gives

```tex
dN/(V d\omega) = g \omega^2/(2\pi^2 c^3).
```

The angular integral over propagation directions is already inside the coefficient. For photons, `g=2` transverse polarizations. Adding `4*pi` or `(4*pi)^2` would make the blackbody energy density too large by exactly that factor. This falsifies the generic rule “Weyl × internal degeneracy × angular measure”.

## L2 consequence

The paired-Weyl baseline coefficient is `[2/(6*pi^2)]^2`. Multiplying only by the orthodox torsion component count gives

```tex
[2/(6\pi^2)]^2 	imes 9 = 1/\pi^4.
```

The old trial coefficient `16/pi^2` requires an extra factor

```tex
(16/pi^2)/(1/pi^4) = 16*pi^2 = (4*pi)^2.
```

That is the same angular measure rejected by the photon-gas control. Thus the L2 candidate becomes a matching ansatz, not a derivation.

## Remaining sublemma L2-a

After Hodge dualizing the bivector index, 3D torsion becomes a `3x3` matrix. The rotation decomposition is

```tex
9 = 3 \oplus 1 \oplus 5.
```

The valid next problem is to determine which of these irreducible sectors are physical transverse horizon-piercing channels and whether SST derives a quantized orientation phase cell.
