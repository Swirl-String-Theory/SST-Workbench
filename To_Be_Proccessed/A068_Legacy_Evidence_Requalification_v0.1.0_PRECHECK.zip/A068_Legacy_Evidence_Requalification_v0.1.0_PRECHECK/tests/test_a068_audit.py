import json
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from a068_audit import discover,write_outputs,sha256_file

class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.f=(self.root/'01_research'/'A_falsifiers')
        self.f.mkdir(parents=True)
    def tearDown(self):
        self.tmp.cleanup()
    def mk(self,name,versions=()):
        a=self.f/name
        a.mkdir()
        for version in versions:
            (a/version).mkdir()
        return a
    def test_duplicate_ids_never_overwrite(self):
        self.mk('A059_variant_1',('A059-v0.1.0',))
        self.mk('A059_variant_2')
        d=discover(self.root,{})
        self.assertEqual(d['family_directory_count'],2)
        self.assertEqual(d['unique_family_id_count'],1)
        self.assertEqual(len(d['duplicate_id_folders']['A059']),2)
    def test_no_false_physics_pass(self):
        self.mk('A021_trefoil',('A021-v0.1.0',))
        d=discover(self.root,{'A021':{'claim_scope':'KNOT_PHYSICS'}})
        self.assertFalse(d['families'][0]['physical_claim_requalified'])
        self.assertEqual(d['families'][0]['status'],'REQUALIFICATION_REQUIRED')
    def test_analytic_nonknot_not_failed_for_pklsa(self):
        self.mk('A001_analytic')
        d=discover(self.root,{'A001':{'claim_scope':'ANALYTIC_NON_KNOT'}})
        self.assertEqual(d['families'][0]['status'],'OUT_OF_SCOPE_PKLSA')
    def test_known_fail_not_reclassified(self):
        self.mk('A010_orbit')
        d=discover(self.root,{'A010':{'claim_scope':'KNOT_PHYSICS','known_failed_claim_gates':['H10']}})
        self.assertEqual(d['families'][0]['status'],'REQUALIFICATION_REQUIRED')
        self.assertTrue(d['families'][0]['contains_known_failed_claims'])
    def test_source_read_only_and_hash(self):
        d=self.mk('A008_modes',('A008-v0.2.0',))
        f=d/'README.md'
        f.write_text('frozen geometry',encoding='utf8')
        before=sha256_file(f)
        z=discover(self.root,{})
        self.assertEqual(before,sha256_file(f))
        self.assertIn(before,[a['sha256'] for a in z['families'][0]['pinned_metadata_hashes']])
    def test_no_directory_errors(self):
        with self.assertRaises(ValueError):
            discover(self.root/'no_such_root',{})
    def test_report_has_no_pass(self):
        self.mk('A021_trefoil')
        p=discover(self.root,{})
        out=self.root/'new_outputs'
        write_outputs(p,out)
        self.assertTrue((out/'REQUALIFICATION_LEDGER.json').exists())
        self.assertFalse(p['families'][0]['source_native_verified'])
        self.assertEqual(json.loads((out/'REQUALIFICATION_LEDGER.json').read_text())['unique_family_id_count'],1)

if __name__=='__main__':
    unittest.main()
