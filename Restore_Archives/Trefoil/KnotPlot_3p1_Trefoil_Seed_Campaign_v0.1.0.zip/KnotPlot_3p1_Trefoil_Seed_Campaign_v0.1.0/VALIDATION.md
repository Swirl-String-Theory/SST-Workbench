# VALIDATION

Release validation performed in the artifact environment:

- Frozen seed count: **38**
- Synthetic \((2,3)\) torus-trefoil safety screen: **38/38 PASS**
- Synthetic initial identity128 uniqueness: **38/38**
- Preregistration lock: **PASS**
- Static production KPC generation: **38/38 PASS**
- Fixed checkpoints in every production script:
  `i00000`, `i01000`, `i04000`, `i10000`
- `run_all.cmd` contains the preregistration verifier before exporting/generating
  the real prospective seed set.

The artifact environment cannot execute the user's installed KnotPlot binary.
The actual base export and 38 relaxation runs therefore occur on the target
Windows workstation through the sibling `KnotPlot.lnk`.

The dense-curve homotopy clearance test is a numerical topology-safety screen,
not a formal knot proof. KnotPlot independently records `safe`, `dowker`, and
`alex -1` at the initial and final production checkpoints.
