# Evidence delta: SST Canon v0.8.28 -> v0.8.30

## Included changes

### v0.8.29

- strengthens the `rho_f` provenance guard;
- distinguishes a point calibration from a confidence interval;
- adds the dependency guard preventing unsupported propagation into the
  electron/Compton chain;
- audits the SSDL/cosmological lift through epoch-invariance, covariance,
  large-number, and force-hierarchy guards.

### v0.8.30

- introduces `rho_sub`, `rho_eff^(0)`, `J_omega`, and `mu_l` as distinct roles;
- keeps `rho_f` as the backward-compatible alias of `rho_eff^(0)`;
- uses `rho_sub` in the material incompressibility axiom without assigning a
  numerical value;
- forbids interpreting `rho_f |omega|^2/2` as an energy density without an
  independently derived squared length;
- traces the inherited `7e-7` decimal to VAM-7 and corrects its dimensional
  interpretation to `kg m^-1`;
- rejects the old cosmological `kg m^-3` confirmation as a unit error.

## Evidence-pack-only overlays

- reviewed `omega_c` printed precision carried forward;
- exact-closure benchmark table explicitly marked non-predictive;
- long benchmark archive path made line-breakable.

## Not included

The following are deliberately outside this v0.8.30 evidence delta:

- v0.8.31 rotor/twist/participation audit;
- v0.8.32 Biot--Savart tension preregistration;
- any new SSTcore API;
- any promotion of `rho_f` to a derived primitive;
- any empirical validation of SST ontology.
