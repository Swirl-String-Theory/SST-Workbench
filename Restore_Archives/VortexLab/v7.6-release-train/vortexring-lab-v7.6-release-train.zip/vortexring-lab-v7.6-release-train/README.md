# VortexRing Lab v7.6 release train

## Aanbevolen versie

Open `latest/vortexring-lab-v7.6.7.html`. Houd `ideal_knots_data.js` en `fourier_knots_data.js` in dezelfde map.

## Inhoud

- `releases/`: alle cumulatieve snapshots v7.6.0–v7.6.7.
- `diffs/`: unified diffs tussen opeenvolgende releases.
- `latest/`: de actuele geconsolideerde release.
- `sources/`: oorspronkelijke Gilbert- en `.fseries`-bronnen plus gegenereerde JavaScriptcatalogi.
- `docs/`: swirl-clock- en afstandssweepprotocollen.
- `CHANGELOG.md`: volledige releasegeschiedenis.
- `MIGRATION_FROM_7_5_4.md`: mapping van oude conflicterende bestandsnamen.
- `SHA256SUMS.txt`: integriteitscontrole.

## Status

De speculative swirl-clock blijft duidelijk **Research Track / niet canon / zonder solverkoppeling**.
