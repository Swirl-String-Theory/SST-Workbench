// SST chi-phase package v10A.0
// Track A Euler/Biot-Savart ring-alpha prototype.
// Standalone C++ reference implementation for the rankine_solid benchmark.
//
// Build:
//   c++ -O3 -std=c++17 sst_chi_phase_v10A0.cpp -o sst_chi_phase_v10A0
//
// Run:
//   ./sst_chi_phase_v10A0
//
// This is intentionally minimal. The Python runner is the primary interface.

#include <cmath>
#include <iostream>
#include <vector>
#include <iomanip>
#include <stdexcept>

struct Result {
    double eps;
    int nr;
    int ntheta;
    int ndelta;
    double energy;
    double alpha_eff;
};

Result ring_energy_rankine_solid(
    double eps,
    double R = 1.0,
    double rho = 1.0,
    double gamma = 1.0,
    int nr = 8,
    int ntheta = 24,
    int ndelta = 0,
    double nd_scale = 90.0,
    int nd_min = 900
) {
    if (eps <= 0.0) throw std::runtime_error("eps must be positive");
    const double pi = std::acos(-1.0);
    const double a = eps * R;
    if (ndelta <= 0) {
        ndelta = std::max(nd_min, static_cast<int>(std::ceil(nd_scale / eps)));
    }

    const int N = nr * ntheta;
    std::vector<double> radial_major(N), z(N), omega_weight(N);

    const double dr = a / nr;
    const double dtheta = 2.0 * pi / ntheta;
    const double vref = gamma / (2.0 * pi * a); // f(1)=1
    // solid-body f=x => omega=(vref/a)*(1+1)=2 vref/a
    const double omega = 2.0 * vref / a;

    int idx = 0;
    for (int i = 0; i < nr; ++i) {
        double x = (i + 0.5) / static_cast<double>(nr);
        double r = a * x;
        for (int j = 0; j < ntheta; ++j) {
            double th = (j + 0.5) * dtheta;
            double rm = R + r * std::cos(th);
            double zz = r * std::sin(th);
            double jac = rm * r;
            double weight = jac * dr * dtheta;
            radial_major[idx] = rm;
            z[idx] = zz;
            omega_weight[idx] = omega * weight;
            ++idx;
        }
    }

    const double ddelta = 2.0 * pi / ndelta;
    double total = 0.0;

    for (int k = 0; k < ndelta; ++k) {
        double delta = (k + 0.5) * ddelta;
        double cd = std::cos(delta);
        double sd = std::sin(delta);

        double sum = 0.0;
        for (int i = 0; i < N; ++i) {
            double x0 = radial_major[i];
            double y0 = 0.0;
            double z0 = z[i];
            double wi = omega_weight[i];
            for (int j = 0; j < N; ++j) {
                double xp = radial_major[j] * cd;
                double yp = radial_major[j] * sd;
                double zp = z[j];
                double dx = x0 - xp;
                double dy = y0 - yp;
                double dz = z0 - zp;
                double dist = std::sqrt(dx*dx + dy*dy + dz*dz);
                sum += wi * omega_weight[j] / dist;
            }
        }
        total += ddelta * cd * sum;
    }

    double energy = rho * 0.25 * total;
    double alpha_eff = std::log(8.0 * R / a) - 2.0 * energy / (rho * gamma * gamma * R);
    return Result{eps, nr, ntheta, ndelta, energy, alpha_eff};
}

int main() {
    std::vector<double> eps_values = {0.10, 0.075, 0.055, 0.04, 0.03};

    std::cout << "SST chi-phase v10A.0 C++ rankine_solid benchmark\n";
    std::cout << "eps,nr,ntheta,ndelta,energy,alpha_eff\n";
    std::cout << std::setprecision(17);

    for (double eps : eps_values) {
        Result r = ring_energy_rankine_solid(eps);
        std::cout << r.eps << ","
                  << r.nr << ","
                  << r.ntheta << ","
                  << r.ndelta << ","
                  << r.energy << ","
                  << r.alpha_eff << "\n";
    }

    std::cout << "Expected thin-ring benchmark alpha ≈ 7/4 = 1.75\n";
    return 0;
}
