# Figure 3 data and code

This folder contains only the data, fitting code, and plotting code needed for
Figure 3.

## Contents

- `data/`: four CSV files, one per plotted dataset. Every available point from
  the first point through the final displayed marker is included.
- `code/fit_tau.py`: independently fits
  `sigma(tau) = A * tau^(-1/2)` using all rows in each CSV. It uses
  inverse-variance weights calculated from the error bars in log space and
  writes `results/fit_parameters.csv` and
  `results/fit_lines.csv`.
- `code/fig3_plot.py`: plots only rows with `plot_point=True` and reads the
  fitted lines from `results/fit_lines.csv`.
- `results/`: fit outputs, `Fig3.pdf`, and `Fig3.png`.

All text in `Fig3.pdf` uses DejaVu Sans and is embedded as subsetted
TrueType fonts.

## Data columns

`tau_s`, `allan_deviation`, `errorbar_lower`, `errorbar_upper`, `edf`,
`plot_point`.

The error-bar columns are absolute lower and upper confidence bounds, not
error magnitudes. The bounds correspond to the 68.3% confidence
intervals used in the figure.

`edf` is the effective degrees of freedom used to calculate the confidence
bounds. It is retained as source-data information and is not used directly
in the fit.

For fitting, the log-space error is calculated as
`(ln(errorbar_upper) - ln(errorbar_lower)) / 2`, and the weight is the
inverse square of this error.

## Run

From the `Fig3` folder, run:

```text
python -m pip install -r requirements.txt
python code/fit_tau.py
python code/fig3_plot.py
```
