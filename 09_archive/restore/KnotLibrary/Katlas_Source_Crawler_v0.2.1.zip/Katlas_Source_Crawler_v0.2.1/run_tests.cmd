@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
.venv\Scripts\python.exe -m tests.test_naming || exit /b 1
.venv\Scripts\python.exe -m tests.test_parser || exit /b 1
.venv\Scripts\python.exe -m unittest tests.test_page_fetch -v || exit /b 1
.venv\Scripts\python.exe -m unittest tests.test_aliases -v || exit /b 1
echo PASS all tests
