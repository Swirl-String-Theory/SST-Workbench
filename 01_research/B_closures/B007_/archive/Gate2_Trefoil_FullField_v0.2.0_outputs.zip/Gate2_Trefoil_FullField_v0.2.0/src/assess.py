"""Evidence-first G2 assessor. No numerical gate can be PASS on mere minimization."""
import argparse,csv,hashlib,json,time
from pathlib import Path
import numpy as np

def load(p):return json.loads(Path(p).read_text())
def assess(stage_file,holdout_file,outdir):
    stage=load(stage_file);holdout=load(holdout_file)
    records=holdout['independent_holdouts'];fixed=[r for r in records if abs(r['box']-4.4)<1e-10]
    if not fixed:raise ValueError('Missing matching fixed box holdouts')
    rs=[r['direct_BS_curl4']['Rstar'] for r in fixed]
    kernel_rel=[r['reconstruction_relative_velocity_disagreement'] for r in fixed]
    divs=[r['direct_BS_curl4']['rms_Dstar'] for r in fixed]
    mapcheck=stage['map_checks']
    analytic=mapcheck['det_jacobian_max_error_from_one']<1e-10 and mapcheck['inverse_error_max']<1e-10
    # Compare equal physical grid spacings, not equal n, and common reference-volume normalization
    boxpairs=[]
    for r in records:
        for other in records:
            if other['box']<=r['box']+1e-9 or abs(other['dx']-r['dx'])>1e-12:continue
            ar=r['direct_BS_curl4']['Rstar'];br=other['direct_BS_curl4']['Rstar']
            boxpairs.append({'base_n':r['n'],'outer_n':other['n'],'base_box':r['box'],'outer_box':other['box'],
                    'relative_Rstar_difference':abs(ar-br)/max(abs(ar),abs(br),1e-300)})
    boxok=bool(boxpairs) and all(p['relative_Rstar_difference']<1e-8 for p in boxpairs)
    large=rs[-1]>0 and kernel_rel[-1]>.01
    nonmonotone=bool(np.any(np.diff(rs)>0))
    rows=[]
    for r in records:
        rows.append({'n':r['n'],'box':r['box'],'dx':r['dx'],
          'Rstar_frozen_direct':r['direct_BS_curl4']['Rstar'],
          'Rstar_frozen_independent_green':r['scalar_green_curl4']['Rstar'],
          'Rstar_frozen_curl2':r['direct_BS_curl2']['Rstar'],
          'velocity_disagreement':r['reconstruction_relative_velocity_disagreement'],
          'raw_Dstar_rms':r['direct_BS_curl4']['rms_Dstar'],
          'discrete_support_margin_cells':r['core_sampled_boundary_cell_margin']})
    report={'project':'Gate2_Trefoil_FullField','version':'v0.2.0',
       'overall':'G2_UNRESOLVED_NO_EULER_RELATIVE_EQUILIBRIUM',
       'technical_gates':{'vol_preserving_diffeomorphism':'PASS' if analytic else 'FAIL',
         'whole_field_pushforward':'PASS_SOFTWARE' if mapcheck['piola_forward_consistency_max_error']<1e-10 else 'FAIL',
         'fixed_q_leaf':'PASS_SOFTWARE',
         'candidate_search_executed':'PASS_SOFTWARE',
         'frozen_holdouts_executed':'PASS_SOFTWARE' if len(fixed)>=3 else 'NOT_RUN',
         'matched_dx_box_comparison':'PASS_SOFTWARE' if boxok else 'UNRESOLVED'},
       'scientific_gates':{'G2_exact_relative_equilibrium':'NOT_ESTABLISHED',
         'continuum_zero_residual':'NOT_ESTABLISHED',
         'independent_method_agreement':'NOT_ESTABLISHED',
         'discrete_solenoidal_convergence':'NOT_ESTABLISHED',
         'G3_linear_stability':'NOT_EVALUATED',
         'background_cores':'NOT_EVALUATED'},
       'evidence':{'seed_q':stage['config']['q'],'search_n':stage['config']['n'],
         'modal_parameters':len(stage['coefficients']),
         'fit_U':stage['trace'][-1]['U'],'fit_Omega':stage['trace'][-1]['Omega'],
         'search_relative_baseline':stage['trace'][0]['relative_residual'],
         'search_relative_final':stage['trace'][-1]['relative_residual'],
         'holdout_residual_Rstar':rs,'holdout_grid_sizes':[r['n'] for r in fixed],
         'holdout_velocity_relative_disagreement':kernel_rel,
         'holdout_discrete_Dstar_rms':divs,
         'nonmonotone_residual':nonmonotone,
         'matched_dx_box_evidence':boxpairs,
         'map_checks':mapcheck},
       'nonclaims':['No exact or converged Euler trefoil relative equilibrium found.',
           'Finite-dimensional volume-preserving shear orbit is not the unrestricted isovortical orbit.',
           'Grid sampled field is not analytically solenoidal under its FD discrete divergence; no Hodge projection was used.',
           'Measured decreasing raw discrete divergence does not establish solver convergence.',
           'No numerical spectral stability, no backreacting background filaments, no nonexistence proof.',
           'No SST parameters or SI calibration entered seed selection.']}
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    (out/'G2_ASSESSMENT.json').write_text(json.dumps(report,indent=2)+'\n')
    with (out/'holdout_table.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    lines=['# Gate 2 — scientific assessment','',f"**{report['overall']}**",'',
       'Validated: mathematical volume-preserving shear maps, Piola vorticity push-forward, modal field continuation and frozen independent numerical checks.',
       'Not validated: an Euler relative equilibrium, vanishing continuum stationary residual, or stability.','',
       '## Fixed-field holdouts','',
       '| Grid | R* direct | R* scalar Green | Velocity discrepancy | Raw divergence D* RMS |',
       '|---:|---:|---:|---:|---:|']
    for r in fixed:
        lines.append(f"| {r['n']}³ | {r['direct_BS_curl4']['Rstar']:.5g} | {r['scalar_green_curl4']['Rstar']:.5g} | {100*r['reconstruction_relative_velocity_disagreement']:.2f}% | {r['direct_BS_curl4']['rms_Dstar']:.5g} |")
    lines+=['',f"Box comparison at same cell size: {'PASS (numerical identity under enlarged box)' if boxok else 'UNRESOLVED'}.",
       '', '## Blocking criteria','',
       '1. No vanishing continuum Euler residual on a fixed physical domain.',
       '2. Two independent quadrature routes do not yet agree to a qualified error bound.',
       '3. Cartesian sampled vorticity divergence is not yet resolution-qualified.',
       '4. No background cores or spectral stability conclusion is included.',
       '', 'Topological invariance is guaranteed by analytic diffeomorphism, not by an Euler equilibrium.']
    (out/'G2_STATUS.md').write_text('\n'.join(lines)+'\n')
    return report

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--search',required=True);p.add_argument('--holdout',required=True);p.add_argument('--out',required=True)
    args=p.parse_args();r=assess(args.search,args.holdout,args.out)
    print(r['overall'])
if __name__=='__main__':main()
