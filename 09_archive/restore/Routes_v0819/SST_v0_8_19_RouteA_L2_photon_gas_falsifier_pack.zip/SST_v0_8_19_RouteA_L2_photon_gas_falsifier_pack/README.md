# SST v0.8.19 Route-A/L2 Photon-Gas Falsifier Pack

This pack implements the recommended internal consistency test for the L2 torsion-degeneracy candidate.

## Verdict

The factor `dim(R^3 tensor Lambda^2 R^3)=9` is retained as an orthodox bulk component count. The angular factor `(4*pi)^2` fails as a non-fitted degeneracy factor: a Weyl-counting rule multiplied by extra solid-angle measures fails the photon-gas control by exactly those factors.

Therefore:

- `dim = 9` -> `[ORTHODOX]`
- `(4*pi)^2` -> `[NOT DERIVED — measure convention / double-counting risk]`
- `g_T = 9(4*pi)^2` -> `[MATCHING ANSATZ]`, not a derivation

## Main files

- `scripts/routeA_L2_photon_gas_falsifier.py` — executable falsifier.
- `results/routeA_L2_photon_gas_falsifier_results.json` — machine-readable result.
- `results/routeA_L2_photon_gas_falsifier_report.md` — short report.
- `canon_blocks/SST_CANON-v0.8.19-routeA-L2-photon-gas-falsifier-block.tex` — canon-ready research-track replacement paragraph.
- `docs/ROUTE_A_L2_PHOTON_GAS_FALSIFIER_REPORT.md` — reviewer-facing explanation.
- `review_prompts/CLAUDE_GEMINI_ROUTE_A_L2_PHOTON_FALSIFIER_PROMPT.md` — prompt for external review.

## Run

```bash
python scripts/routeA_L2_photon_gas_falsifier.py
```

## Consequence for L2

The next valid L2 task is not coefficient search. It is the horizon-restricted torsion-mode problem:

1. Project 3D torsion into irreps `9 = 3 + 1 + 5`.
2. Determine which irreps are transverse physical channels at a horizon crossing.
3. Derive any orientation phase cell from SST dynamics, not from a chosen steradian convention.
