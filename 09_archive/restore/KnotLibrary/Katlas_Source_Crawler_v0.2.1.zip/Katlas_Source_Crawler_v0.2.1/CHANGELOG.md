# Changelog

## v0.2.1

- Added Fremlin/SST-friendly direct duplicate layer for selected higher-crossing knots.
- Added `knots/10/10_1`, `knots/10/10_2`, and `knots/10/10_124` convenience duplicates while retaining canonical sharded Rolfsen storage.
- Added `11_1 -> K11a367` and `11_2 -> K11a247` mappings with direct `knots/11/11_1` and `knots/11/11_2` duplicates.
- Added per-duplicate `ALIAS.json`; canonical `katlas.json` identity remains unchanged.
- Added SQLite `aliases` table and `_catalog/aliases.json` export.
- `lookup` and `fetch-page` now resolve friendly aliases.
- Curated fetches automatically synchronize `page.wikitext` into friendly duplicate folders.
- Expanded `sst_curated` from the supplied `knots_ideal_favorites.txt`: added `8_1`, `8_3`, `8_9`, `8_12`, `8_17`, `10_1`, `10_2`, `K11a367`, `K11a247`, and `L8a1` while retaining prior favorites.
- Added `curated/fremlin_favorites.json` containing identity mappings only.
- Added alias validation and automated alias/snapshot synchronization tests.

## v0.2.0

- Added `fetch-profile` CLI command for restart-safe batch page snapshots.
- Added `sst_curated` profile: all knots and links through 7 crossings plus `8_19`, `9_1`, `9_2`, `10_124`.
- Added `run_fetch_curated.cmd` and one-click `run_all_curated.cmd`.
- Added per-run JSON fetch report with URL, status, size, SHA-256, attempt count and errors.
- Added sequential polite delay, retry and exponential backoff.
- Existing `page.wikitext` snapshots are skipped unless `--force` is supplied.
