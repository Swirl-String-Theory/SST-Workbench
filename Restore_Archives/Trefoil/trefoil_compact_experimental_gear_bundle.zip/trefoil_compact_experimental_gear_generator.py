import math
import numpy as np
import trimesh
from scipy.optimize import brentq

R = 15.221053514957278
r = 4.843062482031861
a = 3.459330344308472
P = 58.116749784382336
N_TEETH = 18
TOOTH_HEIGHT = 0.95
TOOTH_WIDTH_BETA = 0.23
TOOTH_SHARPNESS = 1.8
ROOT_RELIEF = 0.18

def wrap_angle(x):
    return (x + np.pi) % (2 * np.pi) - np.pi

def gamma(u):
    return np.array([
        (R + r * np.cos(3 * u)) * np.cos(2 * u),
        (R + r * np.cos(3 * u)) * np.sin(2 * u),
        r * np.sin(3 * u),
    ], dtype=float)

def dgamma(u):
    return np.array([
        -3 * r * np.sin(3 * u) * np.cos(2 * u) - 2 * (R + r * np.cos(3 * u)) * np.sin(2 * u),
        -3 * r * np.sin(3 * u) * np.sin(2 * u) + 2 * (R + r * np.cos(3 * u)) * np.cos(2 * u),
        3 * r * np.cos(3 * u),
    ], dtype=float)

def ddgamma(u):
    return np.array([
        -9 * r * np.cos(3 * u) * np.cos(2 * u) + 12 * r * np.sin(3 * u) * np.sin(2 * u) - 4 * (R + r * np.cos(3 * u)) * np.cos(2 * u),
        -9 * r * np.cos(3 * u) * np.sin(2 * u) - 12 * r * np.sin(3 * u) * np.cos(2 * u) - 4 * (R + r * np.cos(3 * u)) * np.sin(2 * u),
        -9 * r * np.sin(3 * u)
    ], dtype=float)

def frenet_frame(u):
    g1 = dgamma(u)
    T = g1 / np.linalg.norm(g1)
    g2 = ddgamma(u)
    B = np.cross(g1, g2)
    B = B / np.linalg.norm(B)
    N = np.cross(B, T)
    N = N / np.linalg.norm(N)
    return T, N, B

def X(u, beta, radius=None):
    if radius is None:
        radius = a
    _, N, B = frenet_frame(u)
    return gamma(u) + radius * (np.cos(beta) * N + np.sin(beta) * B)

def screw_phase_residual(beta, u, c):
    p = X(u, beta, a)
    phi = math.atan2(p[1], p[0]) - 2 * np.pi * p[2] / P
    return wrap_angle(phi - c)

def roots_at_u(u, c):
    bs = np.linspace(-np.pi, np.pi, 401)
    vals = np.array([screw_phase_residual(b, u, c) for b in bs])
    roots = []
    for i in range(len(bs) - 1):
        v1, v2 = vals[i], vals[i + 1]
        if abs(v1) < 1e-4:
            roots.append(bs[i])
        elif v1 * v2 < 0:
            try:
                roots.append(brentq(lambda b: screw_phase_residual(b, u, c), bs[i], bs[i + 1]))
            except ValueError:
                pass
    uniq = []
    for rt in roots:
        if not uniq or min(abs(wrap_angle(rt - q)) for q in uniq) > 1e-3:
            uniq.append(rt)
    return uniq

def nearest_root(u, c, beta_prev):
    roots = roots_at_u(u, c)
    if not roots:
        return None
    scores = [abs(wrap_angle(rt - beta_prev)) for rt in roots]
    return roots[int(np.argmin(scores))]

def solve_local_exact_lane():
    c = 0.0
    du = 0.002
    u = 0.0
    b = 0.0
    up = [(u, b)]
    while True:
        u2 = u + du
        rt = nearest_root(u2, c, b)
        if rt is None:
            break
        up.append((u2, rt))
        u, b = u2, rt
    u = 0.0
    b = 0.0
    down = [(u, b)]
    while True:
        u2 = u - du
        rt = nearest_root(u2, c, b)
        if rt is None:
            break
        down.append((u2, rt))
        u, b = u2, rt
    lane = list(reversed(down[1:])) + up
    return np.array([p[0] for p in lane]), np.array([p[1] for p in lane])

u_exact, beta_exact = solve_local_exact_lane()
A = np.column_stack([
    np.ones_like(u_exact),
    np.sin(u_exact), np.cos(u_exact),
    np.sin(2*u_exact), np.cos(2*u_exact),
    np.sin(3*u_exact), np.cos(3*u_exact),
    np.sin(4*u_exact), np.cos(4*u_exact),
])
coef, *_ = np.linalg.lstsq(A, beta_exact, rcond=None)

def beta_center_approx(u):
    basis = np.array([
        1.0,
        np.sin(u), np.cos(u),
        np.sin(2*u), np.cos(2*u),
        np.sin(3*u), np.cos(3*u),
        np.sin(4*u), np.cos(4*u),
    ])
    return float(np.dot(coef, basis))

def tooth_profile(phase):
    c = np.cos(phase)
    if c <= 0:
        return 0.0
    return c ** TOOTH_SHARPNESS

def build_trefoil_gear_mesh(nu=520, nb=104):
    u_vals = np.linspace(0, 2*np.pi, nu, endpoint=False)
    b_vals = np.linspace(0, 2*np.pi, nb, endpoint=False)
    verts = np.zeros((nu * nb, 3), dtype=float)

    for i, u in enumerate(u_vals):
        beta0 = beta_center_approx(u)
        tooth_mod = tooth_profile(N_TEETH * u)
        for j, beta in enumerate(b_vals):
            db = wrap_angle(beta - beta0)
            lane_weight = math.exp(-0.5 * (db / TOOTH_WIDTH_BETA) ** 2)
            radius = a + TOOTH_HEIGHT * tooth_mod * lane_weight
            radius -= ROOT_RELIEF * tooth_mod * math.exp(-0.5 * (wrap_angle(db - np.pi) / 0.33) ** 2)
            verts[i * nb + j] = X(u, beta, radius)

    faces = []
    for i in range(nu):
        i2 = (i + 1) % nu
        for j in range(nb):
            j2 = (j + 1) % nb
            v00 = i * nb + j
            v10 = i2 * nb + j
            v11 = i2 * nb + j2
            v01 = i * nb + j2
            faces.append([v00, v10, v11])
            faces.append([v00, v11, v01])

    return trimesh.Trimesh(vertices=verts, faces=np.array(faces), process=True)

if __name__ == "__main__":
    mesh = build_trefoil_gear_mesh()
    mesh.export("trefoil_compact_experimental_gear.stl")
    mesh.export("trefoil_compact_experimental_gear.obj")
    print("Exported trefoil_compact_experimental_gear.stl")
