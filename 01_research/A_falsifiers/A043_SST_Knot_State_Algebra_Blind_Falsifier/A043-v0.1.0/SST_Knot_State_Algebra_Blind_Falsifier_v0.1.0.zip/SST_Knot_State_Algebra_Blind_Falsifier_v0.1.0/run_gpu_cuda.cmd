@echo off
setlocal
set SST_BACKEND=cupy
call run_all_extended.cmd --backend cupy %*
