# Gate2 Trefoil FullField v0.2.0 — DEVELOPMENT / NOT CERTIFIED

**Scientific state:** `G2_UNRESOLVED_NO_EULER_RELATIVE_EQUILIBRIUM`.

## Purpose

A self-contained, dimensionless, topology-preserving *whole-vorticity-field*
relative-equilibrium search. This does not introduce SST constants. It extends
Gate1's analytic smooth divergence-free trefoil field and Gate2 v0.1.0's Euler
residual by allowing invertible volume-preserving changes of the full field.

**Scope limit:** the optimization explores a **finite-dimensional subfamily**
of the full isovortical orbit (three successively composed analytic shears,
with 1–5 transverse polynomial modes each). It is NOT a search over every
volume-preserving diffeomorphism, nor a proof of equilibrium/nonexistence.

## Windows installation and execution

From a command prompt in the extracted project folder:

```cmd
python -m pip install -r requirements.txt
run_all.cmd
```

Optional larger computational campaign:

```cmd
run_all_extended.cmd
```

The default run launches: 14 software tests; a fixed-`q=0` three-stage
continuation (`20³/6`, `32³/12`, `40³/15` coefficients); frozen holdout grids
`24³, 32³, 40³, 48³, 64³`; a matched-grid-spacing enlarged-box test;
and the evidence-first assessment.

Outputs go to `./Gate2_Trefoil_FullField_v0.2.0-outputs/`.

## Methods (exact statements and approximations)

1. Each analytic map is a shear: `x_i -> x_i + f(x_j,x_k)`. Its inverse is
   exact (`x_i -> x_i - f`) and the determinant of its Jacobian equals 1.
2. The *continuum* vorticity field transforms by `omega_new(Phi(X)) =
   D Phi(X) omega_G1(X)`. This preserves material flux, volume and vortex-line
   knot topology. Smooth shears are global; they are NOT compactly supported
   diffeomorphisms, but their bounded displacement preserves compact support of
   the already compact vorticity field.
3. The analytic original field is re-evaluated on every new grid. We do NOT
   load a previously Hodge-projected raster as the primary seed.
4. The objective is the **complete 3D** stationary relative Euler-vorticity
   residual `curl((K[omega]-U ez-Omega ez×x)×omega)`, not centerline drift.
5. Translation `U`, rotation `Omega` are fitted as linear least-squares
   coefficients for each trial. Gauss-Newton modal steps use finite-difference
   directional Jacobian columns, Tikhonov **numerical trust damping** and a
   monotone line search. This is NOT physical dissipation, regularization of
   the Euler equation, nor an infinite-dimensional Newton–Krylov solver.
6. Source sampling, 4th-order curl and grid midpoint Biot–Savart have numerical
   errors. In holdout runs an **independent scalar Green-potential reconstruction**
   and 2nd-order curl are also reported. Solver discrepancies are visible.
7. Acceptance uses frozen coefficients, `U`, and `Omega` on holdout grids.
   Refit values are reported separately and never used as the held-out metric.
8. Internal twist `q` is fixed per isovortical leaf and never secretly tuned
   to lower the residual. `q=1` is a separately identified exploratory run.

## Key completed run (26 October 2026)

- Three-stage continuation: `20³/6` -> `32³/12` -> `40³/15` modes.
- Final search-grid relative residual: **0.66023 -> 0.65749** (stage three).
- Frozen holdout direct Biot–Savart residual is large and not a certified zero.
- Map inverse, det Jacobian, and Piola tests pass at floating-point precision.
- Independent free-space reconstruction differs materially at available grids.
- Matched-dx larger-box comparison agrees for the tested candidate and method.
- **14/14 software regression tests PASS** (not a physical certification).

See:

- `Gate2_Trefoil_FullField_v0.2.0-outputs/G2_STATUS.md`
- `Gate2_Trefoil_FullField_v0.2.0-outputs/G2_ASSESSMENT.json`
- `Gate2_Trefoil_FullField_v0.2.0-outputs/holdout_table.csv`
- `docs/MATHEMATICS_AND_GATES.md`

## Stop criteria and nonclaims

- If frozen Euler residual does not approach zero with independent spatial
  refinement **and** independent reconstruction, report `G2_UNRESOLVED`.
- If candidate approaches coefficient bounds, stop and label `BOUNDARY_DRIFT`;
  a bound-selected solution is not a physical optimum.
- Do not Hodge-project a field merely to obtain false zero divergence.
- Do not report a stationary trefoil if sampled curl residual is large.
- Do not treat mathematical topology preservation as dynamic shape stability.
- No stability, background-core coupling, or physical SST claim is tested.
- No global nonexistence statement follows from failure of this modal search.

## Provenance and reproducibility

Source `g1_seed.py` and `gate2.py` are vendored unchanged from the earlier
Gate2 v0.1.0 package. A machine-readable `PROVENANCE.json` records hashes
of the original packages and this release, and a `FILE_CHECKSUMS.json` hashes
all delivered source, documentation, tests, and output files (except itself).

Dependencies: NumPy, SciPy, pytest. Run with Python 3.10+ (64-bit recommended).
CPU-oriented; no native GPU/SYCL speedup or parity is claimed.
