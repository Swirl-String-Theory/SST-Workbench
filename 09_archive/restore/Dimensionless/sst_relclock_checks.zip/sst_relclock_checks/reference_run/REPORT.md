# SST relational-clock pre-canonisation report

Generated 2026-08-05 21:03:46 | profile `standard` | python 3.12.3 | numpy 2.4.4

**Scope.** This suite tests whether the relational/entropic-time construction of Barontini (PRR **8**, L022047, 2026) survives translation into SST as a canonisable object. It does not test SST.

**Declared parameters.** `a=0.05`, `Gamma=1.0`, `cfl=0.05`, `dt=None`, `steps=1500`, `sample_every=15`, `resample_every=0`, `v_floor=0.0`, `model=bs`, `lia_R=1.0`, `N=96`, `reverse_at=None`


## Executive verdict

- **check 1** — CONFIRMED: t_c/Q_c prefactors cancel identically; SST constants carry no falsifiable content in this test. | NEGATIVE: no candidate clock beats the matched random-functional null at p<=0.05 on held-out runs. Improvement over lab time is a curve-registration artefact, not information.

- **check 2** — Wr range 0.0513, Tw range 0.0589, Lk drift 7.528e-03; best cancellation ratio 47.3 at 'finer_N_1.7x'; dt-ladder drift ['7.53e-03', '3.98e-04', '2.42e-05']. M2 CONFIRMED: Lk is frozen at least an order of magnitude below the individual Wr/Tw excursions AND the residual drift converges under timestep refinement, so it is discretisation error, not physics. Helicity on a material tube is conserved, tau_H vanishes in ideal dynamics, and tau_H is a reconnection counter rather than a clock. Compare with_resampling and with_v_floor to see how much apparent tau_H pure numerical dissipation manufactures.

- **check 3** — Definitional slope d ln tau_Z / d ln a = -2.000000 (exact prediction -2). Dynamical slope = -2.0504; the difference is the trajectory's own a-dependence, a SECOND and independent cutoff sensitivity that must be declared separately. After [0,1] normalisation tau_Z and tau_L differ by at most 3.886e-15: M3 CONFIRMED, the enstrophy clock is a rescaled length clock at fixed core radius.

- **check 4** — NEGATIVE: minimum cross-basis Spearman rho = -0.273 < 0.9. The run ordering produced by the spectral entropy clock is NOT invariant under the choice of mode basis, so S_spec (and tau_S, tau_F built on it) is a property of the chosen basis rather than of the swirl string. It must not be canonised as an observable without a basis-selection principle derived from the substrate.

- **check 5** — Ideal branch: geometric return error 7.475e-16, signed clock returns to 1.151e-11 of zero, while the unsigned clock keeps growing (final/at-reversal = 2.000, ideal value 2.000). This separates the four candidate explanations: a value near 2 with small return error means the monotonicity of tau_Q is a construction artefact, NOT an arrow of time. Compare the resampling and v_floor rows to isolate numerical dissipation from coarse-graining hysteresis.

- **check 6** — Single declared release: CODATA 2022. Worst canon-anchor deviation is F_swirl_max at -1.106e-07 relative, first wrong significant digit #7. Every entry in the tautology ledger closes to machine precision, confirming that t_c, E_c, Gamma_0 and Z_c are algebraic restatements of the Compton closure and not independent scales.


## Check 6 — constant chain / CODATA hygiene

Declared release: **CODATA 2022**

### Tautology ledger

| quantity | claimed_as | identically_equals | value | rel_residual | label |
|---|---|---|---|---|---|
| t_c | r_c / ||v_swirl|| | 1/omega_c = hbar/(m_e c^2) | 1.28809e-21 | +0.000e+00 | [CALIBRATED ALGEBRAIC IDENTITY] |
| E_c | 2 F_swirl_max r_c | hbar*omega_c = m_e c^2 | 8.18711e-14 | -1.110e-16 | [CALIBRATED ALGEBRAIC IDENTITY] |
| Gamma_0 | 2 pi r_c ||v_swirl|| | (alpha^2/4) * h/m_e | 9.68362e-09 | +2.220e-16 | [CALIBRATED ALGEBRAIC IDENTITY] |
| Z_c | ||v_swirl||^2 r_c | Gamma_0^2 / (4 pi^2 r_c) | 0.00168583 | -1.110e-16 | [CALIBRATED ALGEBRAIC IDENTITY] |
| F_swirl_max | calibrated structural tension scale | m_e^2 c^3 / (alpha hbar) | 29.0535 | -1.110e-16 | [CALIBRATED ALGEBRAIC IDENTITY] |

### Canon anchor vs exact chain

| quantity | formula | exact | canon_anchor | rel_dev_anchor_minus_exact | first_wrong_significant_digit | status |
|---|---|---|---|---|---|---|
| v_swirl | alpha*c/2 | 1.0938456311e+06 | 1.0938456300e+06 | -9.801e-10 | 10 | MISMATCH |
| r_c | alpha*hbar/(2 m_e c) | 1.4089701602e-15 | 1.4089701700e-15 | +6.939e-09 | 9 | MISMATCH |
| F_swirl_max | hbar omega_c/(2 r_c) | 2.9053510213e+01 | 2.9053507000e+01 | -1.106e-07 | 7 | MISMATCH |

### Externally proposed values, re-derived

| quantity | proposed | recomputed_from_canon_anchors | recomputed_from_exact_chain | rel_err_proposed_vs_exact | justified_sig_digits |
|---|---|---|---|---|---|
| t_c | 1.28808868e-21 | 1.28808868e-21 | 1.28808867e-21 | +1.052e-08 | 7 |
| Gamma_c | 9.6836192e-09 | 9.6836192e-09 | 9.68361915e-09 | +5.598e-09 | 8 |
| Gamma_c_sq | 9.37724809e-17 | 9.37724809e-17 | 9.37724798e-17 | +1.215e-08 | 7 |
| Z_c | 0.00168583036 | 0.00168583036 | 0.00168583035 | +4.981e-09 | 8 |
| E_c_J | 8.18710494e-14 | 8.18710494e-14 | 8.18710579e-14 | -1.036e-07 | 6 |
| E_c_keV | 510.9989 | 510.998898 | 510.998951 | -9.920e-08 | 7 |


## Check 2 — helicity on a material tube (audit point M2)

H = Gamma^2 * Lk (Moffatt-Ricca, thin uniformly framed tube). Wr and Tw both move; the test is whether their SUM is frozen.

### Writhe convergence (Gauss double integral)

| N | writhe | delta_vs_prev |
|---|---|---|
| 48 | -3.38373 | None |
| 96 | -3.34652 | 0.0372176 |
| 192 | -3.33892 | 0.00759507 |
| 384 | -3.3374 | 0.00151743 |

Timestep ladder drift: [0.007528454948838803, 0.00039775910478612175, 2.42203359093196e-05] | converging: **True** | best cancellation ratio: **47.3**

### Solver-tolerance ladder

| variant | N | dt | a | model | resample_every | v_floor | Wr_range | Tw_range | Lk_abs_drift_max | cancellation_ratio | static_integrality_defect | drift_over_static_defect | E_rel_drift | L_rel_change | tau_H_total |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| baseline | 96 | 1.175e-03 | 0.05 | bs | 0 | 0 | 0.0513479 | 0.0588764 | 7.528e-03 | 6.8 | 1.231e-02 | 0.611 | 1.697e-02 | 0.0242247 | 7.528e-03 |
| finer_dt_4x | 96 | 2.938e-04 | 0.05 | bs | 0 | 0 | 0.00661189 | 0.00700965 | 3.978e-04 | 16.6 | 1.231e-02 | 0.032 | 5.509e-04 | 0.00102834 | 3.978e-04 |
| finer_dt_16x | 96 | 7.344e-05 | 0.05 | bs | 0 | 0 | 0.000431047 | 0.000455268 | 2.422e-05 | 17.8 | 1.231e-02 | 0.002 | 3.246e-05 | 6.15537e-05 | 2.422e-05 |
| finer_N_1.7x | 160 | 4.252e-04 | 0.05 | bs | 0 | 0 | 0.0208841 | 0.0213256 | 4.414e-04 | 47.3 | 3.681e-03 | 0.120 | 1.651e-04 | 0.00176264 | 4.414e-04 |
| smaller_a | 96 | 1.175e-03 | 0.025 | bs | 0 | 0 | 0.0522667 | 0.0599445 | 7.678e-03 | 6.8 | 1.231e-02 | 0.623 | 3.405e-02 | 0.0245987 | 7.678e-03 |
| with_resampling | 96 | 1.175e-03 | 0.05 | bs | 25 | 0 | 0.0629634 | 0.0643443 | 1.381e-03 | 45.6 | 1.231e-02 | 0.112 | 5.409e-03 | 0.0182994 | 1.381e-03 |
| with_v_floor | 96 | 1.175e-03 | 0.05 | bs | 0 | 0.001 | 0.0513479 | 0.0588764 | 7.528e-03 | 6.8 | 1.231e-02 | 0.611 | 1.697e-02 | 0.0242247 | 7.528e-03 |
| LIA | 96 | 1.175e-03 | 0.05 | lia | 0 | 0 | 0.00532865 | 0.00085645 | 4.549e-03 | 0.2 | 1.231e-02 | 0.369 | 1.329e-02 | 7.21854e-07 | 4.549e-03 |


## Check 3 — cutoff scan of the enstrophy clock (audit point M3)

### (i) Definitional: fixed trajectory, `a` varied only inside Z

| a_over_a0 | a | tau_Z_total | tau_Z_times_a2 |
|---|---|---|---|
| 0.5 | 0.025 | 9.078553e+01 | 5.6740954639e-02 |
| 1 | 0.05 | 2.269638e+01 | 5.6740954639e-02 |
| 2 | 0.1 | 5.674095e+00 | 5.6740954639e-02 |

log-log slope = **-2.000000** (exact prediction −2)

### (ii) Dynamical: `a` also changes the trajectory

| a_over_a0 | a | tau_Z_total | tau_L_total | L_rel_change | kappa_max_final | Lk_abs_drift |
|---|---|---|---|---|---|---|
| 0.5 | 0.025 | 9.218689e+01 | 3.620171e-01 | 0.0245987 | 1.52601 | 7.678e-03 |
| 1 | 0.05 | 2.269638e+01 | 3.565139e-01 | 0.0242247 | 1.55078 | 7.528e-03 |
| 2 | 0.1 | 5.372808e+00 | 3.375835e-01 | 0.0229384 | 1.53364 | 7.057e-03 |

log-log slope = **-2.0504**


## Check 4 — mode-basis robustness

| basis_a | basis_b | spearman_rho | p |
|---|---|---|---|
| curvature | torsion | -0.2727 | 0.446 |
| curvature | position | +0.0424 | 0.907 |
| torsion | position | +0.4667 | 0.174 |

Collapse score per basis: `curvature` = 0.63332, `torsion` = 0.58101, `position` = 0.71595


## Check 5 — Loschmidt reversal

| variant | geometric_return_error | Lk_return_error | L_return_rel_error | E_return_rel_error | tau_Q_unsigned_at_reversal | tau_Q_unsigned_final | tau_Q_signed_return_error | S_spec_hysteresis | S_spec_range |
|---|---|---|---|---|---|---|---|---|---|
| no_resampling | 7.475e-16 | 4.441e-16 | 1.207e-16 | 0.000e+00 | 116.225 | 232.451 | 1.151e-11 | 2.487e-14 | 0.234721 |
| resampling_25 | 3.405e-03 | 1.666e-04 | 3.153e-03 | 3.754e-03 | 115.884 | 191.98 | 4.022e+01 | 3.758e-03 | 0.182973 |
| v_floor_1e-3 | 7.475e-16 | 4.441e-16 | 1.207e-16 | 0.000e+00 | 116.225 | 232.451 | 1.151e-11 | 2.487e-14 | 0.234721 |


## Check 1 — null-model benchmark (BLOCKING)

Scored observables (held out from every clock): kappa_max, Wr, Rg

Prefactor-invariance residual: **0.000e+00** (must be ~0: proves `t_c/Q_c` carries no falsifiable content)

| clock | status | E_heldout | E_calib | eff_dof | p_nullA | p_nullB_matched |
|---|---|---|---|---|---|---|
| t_lab | ok | 0.53572 | 0.56083 | 10.1 | 0.5988 | 0.1118 |
| tau_E | ok | 0.61177 | 0.74623 | 1.59 | 0.9182 | 0.5409 |
| tau_Ebright | ok | 0.53437 | 0.68365 | 2.64 | 0.5948 | 0.09581 |
| tau_S | ok | 0.63002 | 0.69335 | 4.29 | 0.9481 | 0.6387 |
| tau_F | ok | 0.60883 | 0.61888 | 2.27 | 0.9062 | 0.517 |
| tau_L | ok | 0.60022 | 0.71846 | 1.69 | 0.8862 | 0.495 |
| tau_Z | ok | 0.60022 | 0.71846 | 1.69 | 0.8862 | 0.495 |
| tau_H | ok | 0.63921 | 0.82428 | 6.01 | 0.9661 | 0.6826 |
| tauSigned_Ebright | UNUSABLE — non-monotone: cannot serve as a reparametrisation |  |  |  |  |  |
| tauPair_Ebright_Rg | UNUSABLE — non-monotone: cannot serve as a reparametrisation |  |  |  |  |  |

Null-A (shared random monotone warp): median 0.52439, p05 0.46712

Null-B (matched random functional over the same driver pool): median 0.60317, p05 0.52897


> **Reading rule.** `p_nullB_matched` is the only number that licenses a claim. A clock that beats lab time but not null-B has demonstrated curve registration, not physics.


## Epistemic labelling of anything exported from this run

- Clock *constructions* (tau_Q, tau_S, tau_F, tau_G): `[SPECULATIVE]` / `[RESEARCH-TRACK]`.
- Helicity freeze on a material tube: `[ORTHODOX]` (Moffatt 1969; Calugareanu-White-Fuller), and as an SST statement `[DERIVED NEGATIVE]`.
- Enstrophy-clock cutoff scaling: `[DERIVED]` from the Rankine-core definition, with `[CRITICAL NOTE]` on the undeclared-`a` reproducibility gap.
- t_c, E_c, Gamma_0, Z_c: `[CALIBRATED ALGEBRAIC IDENTITY]`, never `[DERIVED]`.
