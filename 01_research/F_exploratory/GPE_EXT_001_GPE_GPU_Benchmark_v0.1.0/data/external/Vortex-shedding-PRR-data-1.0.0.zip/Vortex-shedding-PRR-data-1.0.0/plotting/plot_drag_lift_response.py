"""Recreate the drag/lift response summary figure from merged data."""

from __future__ import annotations

import numpy as np
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
from matplotlib import colors
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

from _common import FIGURE_DIR, load_merged, setup_matplotlib


SERIES = [(0.9, 20, "p", "C4")]
FIGSIZE = (3.375, 4.0)
SAVE_NAME = "drag_lift_response.png"


setup_matplotlib()
merged = load_merged()

fig = plt.figure(figsize=FIGSIZE)
gs = gridspec.GridSpec(2, 1, figure=fig, hspace=0.12, height_ratios=[3, 1])
ax_drag = fig.add_subplot(gs[0])
ax_freq = fig.add_subplot(gs[1])

ms = 2.5
mew = 0.7
alpha = 0.3
ratio = 0.7

for V0, sigma, marker, color in SERIES:
    subset = merged[(merged[:, 0] == V0) & (merged[:, 1] == sigma) & (merged[:, 2] < 0.7)]
    if subset.size == 0:
        raise RuntimeError(f"No merged rows found for V0={V0}, sigma={sigma}.")

    Mach = subset[:, 2]
    vc = subset[:, 3][0]
    F_D = subset[:, 13]
    F_L = subset[:, 12]
    f_shed = subset[:, 4]
    f_drag = subset[:, 5].copy()

    ax_drag.plot(Mach, F_D, "o", mec="royalblue", ms=ms, mfc=colors.to_rgba("royalblue", alpha=alpha), mew=mew, label=r"$F_\mathrm{D}/F_{\mu}$")
    ax_drag.plot(Mach, F_L, "s", mec="orangered", ms=ms, mfc=colors.to_rgba("orangered", alpha=alpha), mew=mew, label=r"$F_\mathrm{L}/F_{\mu}$")
    ax_drag.set_xlim(0.1, 0.67)
    ax_drag.set_ylim(bottom=-0.3, top=9.2)
    ax_drag.set_xticklabels([])
    ax_drag.legend(loc="center", bbox_to_anchor=(0.5, 1.06), frameon=False, fontsize=8, ncol=2, columnspacing=5)
    ax_drag.text(-0.12, 1.0, "(a)", transform=ax_drag.transAxes, fontsize=8, va="top", ha="left")

    mask_low = Mach <= 0.32
    ax_freq.plot(Mach[~mask_low], f_shed[~mask_low], "s", mec="orangered", ms=ms, mfc=colors.to_rgba("orangered", alpha=alpha), mew=mew)

    idx = np.where(np.isclose(Mach[mask_low], 0.29))[0]
    f_drag_masked = f_drag[mask_low]
    if idx.size:
        f_drag_masked[idx] = 0.0081
    idx = np.where(np.isclose(Mach[mask_low], 0.305))[0]
    if idx.size:
        f_drag_masked[idx] = 0.0083

    ax_freq.plot(Mach[mask_low], f_drag_masked, "o", mec="royalblue", ms=ms, mfc=colors.to_rgba("royalblue", alpha=alpha), mew=mew)
    ax_freq.set_xlim(0.1, 0.67)
    ax_freq.set_yticks([0, 0.002, 0.004, 0.006, 0.008, 0.01])
    ax_freq.set_yticklabels([0, 2, 4, 6, 8, 10])
    ax_freq.text(0.06, 1.02, r"$10^{-3}$ $f \, \tau$", transform=ax_freq.transAxes, ha="center", va="bottom")
    ax_freq.text(-0.12, 1.0, "(b)", transform=ax_freq.transAxes, fontsize=8, va="top", ha="left")
    ax_freq.set_xlabel(r"$v_0/c_\mathrm{s0}$", labelpad=0)

    ax_inset = inset_axes(ax_drag, width="30%", height="30%", loc="upper left", bbox_to_anchor=(0.05, 0.0, 1, 1), bbox_transform=ax_drag.transAxes)
    x_c = 0.1
    xx1 = np.logspace(np.log10(0.002), 1, 50)
    yy1 = 0.6 * (xx1 / x_c) ** 0.5
    xx2 = np.logspace(np.log10(0.002), np.log10(1), 50)
    yy2 = 0.6 * (xx2 / x_c) ** 2.0 * 0.8
    ax_inset.plot(xx1, yy1, ls="dotted", c="k", lw=0.5, alpha=0.7)
    ax_inset.plot(xx2, yy2, "--", c="k", lw=0.5, alpha=0.7)
    ax_inset.loglog(Mach - vc, F_D, "o", ms=ms * ratio, mec="royalblue", mfc=colors.to_rgba("royalblue", alpha=0.3), mew=0.5)
    ax_inset.set_aspect("equal")
    ax_inset.set_xlabel(r"$(v_0-v_\mathrm{c})/c_\mathrm{s}$", fontsize=6, labelpad=1)
    ax_inset.tick_params(axis="both", which="both", labelsize=6)
    ax_inset.set_xlim(0.002, 1)
    ax_inset.set_ylim(40 / 500, 40)

    ax_inset2 = inset_axes(ax_drag, width="30%", height="30%", loc="upper left", bbox_to_anchor=(0.37, 0.0, 1, 1), bbox_transform=ax_drag.transAxes)
    ax_inset2.set_box_aspect(1)
    mask_lift = (0.26 < Mach) & (Mach < 0.4)
    ax_inset2.plot(Mach[mask_lift], F_L[mask_lift], "s", mec="orangered", ms=ms * ratio, mfc=colors.to_rgba("orangered", alpha=0.3), mew=0.5)
    ax_inset2.set_xlabel(r"$v_0/c_\mathrm{s}$", fontsize=6, labelpad=1)
    ax_inset2.set_xticks([0.3, 0.35, 0.4])
    ax_inset2.set_xlim(0.26, 0.4)
    ax_inset2.tick_params(axis="both", which="both", labelsize=6)
    ax_inset2.set_yticks([0, 0.2, 0.4, 0.6])
    ax_inset2.set_ylim(-0.05, 0.7)

    ax_drag.vlines(x=0.33, ymin=-2.0, ymax=2.3, colors="grey", linestyles="--", linewidth=0.9, alpha=0.9)
    ax_freq.axvline(0.33, color="grey", linestyle="--", lw=0.8, alpha=0.9, zorder=5)
    ax_inset2.axvline(0.33, color="grey", linestyle="--", lw=0.6, alpha=0.9, zorder=5)
    ax_inset.axvline(0.33 - vc, color="grey", linestyle="--", lw=0.6, alpha=0.9, zorder=5)

    ax_drag.text(0.2, 1.7, rf"$v_c/c_\mathrm{{s0}}={vc:.2f}$", fontsize=8, va="top", ha="center")
    ax_drag.annotate("", xy=(vc, 0.2), xytext=(vc, 1.2), arrowprops=dict(facecolor="blue", lw=1, arrowstyle="->", mutation_scale=8))
    ax_drag.text(0.33, 3.8, r"$v_{{\rm th}}/c_\mathrm{{s0}}=0.33$", fontsize=8, va="top", ha="center")
    ax_drag.annotate("", xy=(0.33, 2.3), xytext=(0.33, 3.3), arrowprops=dict(facecolor="blue", lw=1, arrowstyle="->", mutation_scale=8))
    ax_inset.text(0.15, 0.73, "(i)", transform=ax_inset.transAxes, fontsize=8)
    ax_inset2.text(0.15, 0.73, "(ii)", transform=ax_inset2.transAxes, fontsize=8)

fig.subplots_adjust(left=0.12, right=0.97, top=0.94, bottom=0.08, hspace=0.05)

out = FIGURE_DIR / SAVE_NAME
fig.savefig(out, dpi=600)
plt.close(fig)
print(f"saved {out}")
