from __future__ import annotations
from pathlib import Path
from typing import Any
import numpy as np

from .backend import load_backend
from .benchmark import benchmark_blind
from .core import DEFAULT_DATA, prepare_centerline, write_csv, write_json
from .geometry import make_counter_channels, resample_closed, rigid_transform
from .physics import compute_blind


def _gate(name: str, passed: bool, value: Any, criterion: str, note: str = "") -> dict[str, Any]:
    return {"gate": name, "pass": bool(passed), "value": value, "criterion": criterion, "note": note}


def _G_from_channels(plus, minus, *, D: float, eps_over_D: float, gamma_plus: float,
                     gamma_minus: float, backend) -> float:
    n = len(plus)
    p = resample_closed(np.asarray(plus), n)
    m = resample_closed(np.asarray(minus), n)
    eps = eps_over_D * D
    Hpp=float(backend.interaction_hamiltonian(p,p,gamma_plus,gamma_plus,eps))
    Hmm=float(backend.interaction_hamiltonian(m,m,gamma_minus,gamma_minus,eps))
    Hpm=float(backend.interaction_hamiltonian(p,m,gamma_plus,gamma_minus,eps))
    return (Hpp+Hmm+2.0*Hpm)/(Hpp+Hmm)


def run_gates(*, out_dir: str | Path = "audit_out", data_path: str | Path = DEFAULT_DATA,
              force_python: bool = False, force_build: bool = False, build_verbose: bool = False,
              quick: bool = False) -> dict[str, Any]:
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    gates: list[dict[str, Any]] = []

    # H0 — alpha must be absent from blind physics code.
    blind_src = (Path(__file__).resolve().parent / "physics.py").read_text(encoding="utf-8")
    h0 = ("137.035" not in blind_src and "ALPHA_INV" not in blind_src)
    gates.append(_gate("H0_blind_protocol", h0, {"alpha_literal_in_physics": not h0},
                       "physics.py contains neither alpha benchmark literal nor ALPHA_INV symbol"))

    n0 = 96 if quick else 192
    center, meta = prepare_centerline(data_path=data_path, n=n0)
    D=float(meta["D_metadata"])

    # H1 — native/fallback numerical parity.
    csmall,_=prepare_centerline(data_path=data_path,n=48)
    pyres=compute_blind(csmall,D=D,offset_over_D=.35,eps_over_D=.08,force_python=True,skip_build=True)
    natres=compute_blind(csmall,D=D,offset_over_D=.35,eps_over_D=.08,force_python=force_python,
                         force_build=force_build,build_verbose=build_verbose)
    parity=abs(pyres.G_energy-natres.G_energy)
    h1=(parity<1e-10)
    gates.append(_gate("H1_native_python_parity",h1,parity,"|G_native-G_python| < 1e-10",
                       f"active backend={natres.backend}; native parity becomes substantive when C++ is available"))

    # H2 — centerline and offset-channel quadrature sanity.
    seg=np.linalg.norm(np.roll(center,-1,axis=0)-center,axis=1)
    seg_cv=float(np.std(seg)/np.mean(seg))
    plus,minus,_,_=make_counter_channels(center,.5*D)
    # independent resampling is part of the registered quadrature protocol
    pe=resample_closed(plus,len(plus)); me=resample_closed(minus,len(minus))
    pcv=float(np.std(np.linalg.norm(np.roll(pe,-1,axis=0)-pe,axis=1))/np.mean(np.linalg.norm(np.roll(pe,-1,axis=0)-pe,axis=1)))
    mcv=float(np.std(np.linalg.norm(np.roll(me,-1,axis=0)-me,axis=1))/np.mean(np.linalg.norm(np.roll(me,-1,axis=0)-me,axis=1)))
    h2=seg_cv<5e-3 and pcv<1e-2 and mcv<1e-2 and meta["knot_id"]=="3:1:1"
    gates.append(_gate("H2_geometry_quadrature",h2,{"center_segment_cv":seg_cv,"plus_segment_cv":pcv,"minus_segment_cv":mcv,
                                                    "L_metadata":meta["L_metadata"],"D_metadata":D},
                       "center CV <0.5%; independently resampled channel CVs <1%"))

    base=compute_blind(center,D=D,offset_over_D=.5,eps_over_D=.05,force_python=force_python,skip_build=True)
    write_json(out/"blind_canonical.json",{"protocol":"BLIND_HYDRODYNAMICS_NO_ALPHA_INPUT","geometry":meta,"observables":base.to_dict()})

    # H3 — reversing both circulations must leave scalar energy ratio unchanged.
    rev=compute_blind(center,D=D,offset_over_D=.5,eps_over_D=.05,gamma_plus=-1,gamma_minus=1,
                      force_python=force_python,skip_build=True)
    dsign=abs(base.G_energy-rev.G_energy)
    gates.append(_gate("H3_global_sign_reversal",dsign<1e-10,dsign,"G(+,-)=G(-,+) within 1e-10"))

    # H4 — Euclidean invariance, transforming already-defined material channels to avoid frame-gauge contamination.
    backend,_=load_backend(force_python=force_python,skip_build=True)
    G0=_G_from_channels(plus,minus,D=D,eps_over_D=.05,gamma_plus=1,gamma_minus=-1,backend=backend)
    Gt=_G_from_channels(rigid_transform(plus),rigid_transform(minus),D=D,eps_over_D=.05,
                        gamma_plus=1,gamma_minus=-1,backend=backend)
    drigid=abs(G0-Gt)
    gates.append(_gate("H4_rigid_invariance",drigid<2e-8,drigid,"rigid transform changes G by <2e-8"))

    # H5 — scale collapse when D, epsilon, offsets and coordinates scale together.
    scale=2.731
    Gs=_G_from_channels(plus*scale,minus*scale,D=D*scale,eps_over_D=.05,
                        gamma_plus=1,gamma_minus=-1,backend=backend)
    dscale=abs(G0-Gs)
    gates.append(_gate("H5_scale_collapse",dscale<2e-8,dscale,"uniform scaling changes G by <2e-8"))

    # H6 — resolution convergence. Full ladder is deliberately stricter.
    Ns=[64,96,128] if quick else [128,192,256,384]
    conv=[]
    for n in Ns:
        c,_=prepare_centerline(data_path=data_path,n=n)
        rr=compute_blind(c,D=D,offset_over_D=.5,eps_over_D=.05,force_python=force_python,skip_build=True)
        conv.append({"n":n,"G_energy":rr.G_energy,"delta_energy_rel":rr.delta_energy_rel})
    tail_rel=abs(conv[-1]["G_energy"]-conv[-2]["G_energy"])/max(abs(conv[-1]["G_energy"]),1e-30)
    threshold=.02 if quick else .01
    gates.append(_gate("H6_resolution_convergence",tail_rel<threshold,tail_rel,
                       f"last-two relative G change <{100*threshold:.1f}%"))
    write_csv(out/"resolution_convergence.csv",conv)

    # H7 — nuisance robustness: core regularization and arbitrary material-frame phase.
    eps_list=[.025,.05,.10,.20]
    erows=[]
    for eps in eps_list:
        rr=compute_blind(center,D=D,offset_over_D=.5,eps_over_D=eps,force_python=force_python,skip_build=True)
        erows.append({"eps_over_D":eps,"G_energy":rr.G_energy,"delta_energy_rel":rr.delta_energy_rel})
    ed=np.array([r["delta_energy_rel"] for r in erows])
    espread=(float(np.max(ed))-float(np.min(ed)))/max(abs(float(np.mean(ed))),1e-30)
    phases=np.linspace(0,2*np.pi,8,endpoint=False)
    prows=[]
    for phase in phases:
        rr=compute_blind(center,D=D,offset_over_D=.5,eps_over_D=.05,phase=float(phase),
                         force_python=force_python,skip_build=True)
        prows.append({"phase_rad":float(phase),"G_energy":rr.G_energy,"delta_energy_rel":rr.delta_energy_rel})
    pd=np.array([r["delta_energy_rel"] for r in prows])
    pspread=(float(np.max(pd))-float(np.min(pd)))/max(abs(float(np.mean(pd))),1e-30)
    h7=(np.all(np.sign(ed)==np.sign(ed[0])) and espread<.35 and pspread<.20)
    gates.append(_gate("H7_nuisance_robustness",h7,{"eps_relative_spread":espread,"phase_relative_spread":pspread,
                                                      "same_eps_sign":bool(np.all(np.sign(ed)==np.sign(ed[0])))},
                       "same sign; eps spread <35%; material-frame phase spread <20%"))
    write_csv(out/"regularization_sweep.csv",erows); write_csv(out/"frame_phase_sweep.csv",prows)

    # H8 — test the proposed first-order cancellation around balanced counter-circulation.
    eta=.02
    def imb(e):
        return compute_blind(center,D=D,offset_over_D=.5,eps_over_D=.05,gamma_plus=1+e,gamma_minus=-(1-e),
                             force_python=force_python,skip_build=True)
    rp,rm,r0=imb(eta),imb(-eta),imb(0.0)
    odd=(rp.G_energy-rm.G_energy)/(2*eta)
    even2=(rp.G_energy+rm.G_energy-2*r0.G_energy)/(eta*eta)
    odd_ratio=abs(odd)/max(abs(even2),1e-30)
    gates.append(_gate("H8_first_order_suppression",odd_ratio<.10,
                       {"odd_derivative":odd,"second_even_proxy":even2,"odd_over_even":odd_ratio},
                       "|odd derivative|/|even second proxy| <0.10"))

    # H9/H10 — post-hoc only. Neither result feeds back into the blind solver.
    bench=benchmark_blind(base.to_dict())
    write_json(out/"posthoc_alpha_benchmark.json",bench)
    target=bench["target_delta_rel"]
    mismatch=abs(base.delta_energy_rel-target)/max(abs(target),1e-30)
    gates.append(_gate("H9_parameter_free_alpha_hit",mismatch<.10,
                       {"mismatch_in_target_correction_units":mismatch,"blind_delta_rel":base.delta_energy_rel,
                        "target_delta_rel":target},
                       "canonical blind correction within 10% of required alpha correction"))

    offs=[.05,.10,.20,.30,.40,.50]
    scan=[]
    for off in offs:
        for eps in eps_list:
            rr=compute_blind(center,D=D,offset_over_D=off,eps_over_D=eps,force_python=force_python,skip_build=True)
            relerr=abs(rr.delta_energy_rel-target)/max(abs(target),1e-30)
            scan.append({"offset_over_D":off,"eps_over_D":eps,"G_energy":rr.G_energy,
                         "delta_energy_rel":rr.delta_energy_rel,"target_units_error":relerr})
    best=min(scan,key=lambda r:r["target_units_error"])
    hits=[r for r in scan if r["target_units_error"]<.10]
    gates.append(_gate("H10_no_tuned_in_core_rescue",len(hits)>=3,{"best":best,"hit_count_within_10pct":len(hits)},
                       ">=3 predeclared in-core grid points land within 10% of target",
                       "One isolated best-fit point is not accepted as a derivation."))
    write_csv(out/"posthoc_in_core_scan.csv",scan)

    numerical_ok=all(g["pass"] for g in gates[:7])  # H0-H6
    physical_ok=all(g["pass"] for g in gates[7:])  # H7-H10
    if not numerical_ok:
        verdict="INCONCLUSIVE_NUMERICS"
    elif physical_ok:
        verdict="SURVIVES_V0_1_0"
    else:
        verdict="FALSIFIED_OR_UNSUPPORTED_SIMPLE_COUNTERPULLEY_ENERGY_MAPPING"
    summary={"audit_name":"SST counter-pulley alpha falsifier v0.1.0","verdict":verdict,"quick":bool(quick),
             "gates":gates,"canonical_blind":base.to_dict(),"posthoc_benchmark":bench}
    write_json(out/"audit_summary.json",summary)
    return summary
