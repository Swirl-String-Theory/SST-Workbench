# Three Hessian Gate Audit

Run:

```bash
python compute_three_hessian_gate_audit.py
```

The script computes three Hessian objects for both the trefoil and the unknot:

1. Surface Hessian: \(k_\ell=\ell(\ell+1)-2\), giving \(N_p=4\).
2. Pressure eta-Hessian: \(H_\eta=-2\sigma E_0\). This isolates the Gate 2 object but does not derive \(\sigma=11/3\).
3. Phase Hessian / impedance: \(\Lambda_\phi=4\pi/\int_a^R dr/[n(r)r^2]\).

The current finite-cell formula gives \(\alpha_{\rm lead}^{-1}=(8\pi/3)L_K\). With \(L_{3_1}=16.371637\), the trefoil lies near the fine-structure scale. With \(L_{\rm unknot}=\pi\), the unknot gives \(8\pi^2/3\approx26.32\), so the unknot does not produce the observed fine-structure scale in this reduction.

Interpretation: the far-field carrier can be unknotted/H^0-like, but the electron source-cell energy scale remains trefoil-like in the present finite-cell model.
