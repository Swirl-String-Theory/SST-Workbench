# PROMPT 3 — SECTION EXPANSION

MODE: FULL EXPANSION

TASK:
Expand one section into full LaTeX.

RULES:
- Full derivations
- No logical jumps
- Use \label and \ref
