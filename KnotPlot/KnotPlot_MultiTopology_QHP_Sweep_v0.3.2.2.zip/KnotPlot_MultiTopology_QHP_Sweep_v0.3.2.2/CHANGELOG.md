# v0.3.2.2

Fixes real-link preparation after:

```text
Component-count mismatch for 2.2.1: expected 2, parsed 1
```

The full-link `coords` export is no longer used to recover component boundaries.

For every nontrivial multi-component topology:
1. reconstruct/reload original topology;
2. `keep 0`; export component 0;
3. reconstruct/reload original topology;
4. `keep 1`; export component 1;
5. continue for every expected component;
6. measure each isolated component's closed arclength;
7. distribute the exact total bead budget proportionally;
8. uniformly resample each component;
9. combine prepared components into one frozen multi-component input.

This uses KnotPlot's own 0-based component selection and is independent of the
formatting of full-link `coords`.

Synthetic 0.n.1 controls, stages, q/h/p values, timers and ETA are unchanged.
