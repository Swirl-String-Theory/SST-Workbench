# Work task — A068 v0.4.1 historical 2015 seeds

1. In the current Google Drive A068 folder, download only the named
   `A068_v0.4.1_Framework_v1.0.8_HISTORICAL_TREFOIL_PRESETUP.zip`.
2. Before unpack/install, verify SHA-256 package manifest and 40 original historical XYZ
   files; note external historical archive v0.2.0 vs internal manifest v0.1.0.
3. Use existing **official** SST Falsifier Framework v1.0.8 at
   `C:\workspace\projects\SST-Workbench\06_templates\SST_Falsifier_Framework\SST_Falsifier_Framework_v1.0.8`.
4. Execute `SETUP_A068.cmd` to create ONLY NEW `A068-v0.4.1` and freeze locally.
   Never overwrite `A068-v0.4.0` or alter frozen private commitments.
5. From new instance run pytest, `run_all.cmd BASIC`, `run_all.cmd FULL`,
   `run_all.cmd CERTIFY`. Verify all source output manifests.
6. Upload the new official BLIND ZIPs/PDFs, per-run gate ledgers, and
   `HISTORICAL_2015_EULER_MODEL_DIAGNOSTICS.json` into the A068 parent folder.
7. Report historic A/B material-torus tangency, full-vector endpoint translation
   control (identity rotation only), independently computed Euler tangent-FD check,
   and N600 vs N1200 centerline sampling sensitivity.
8. Classify historic A/B as **two geometric seed families, zero qualified physical
   dynamics providers**. Do not claim Floquet clock confirmation from manufactured
   or tangent operator tests; leave G3 physically UNRESOLVED and reveal blocked.
