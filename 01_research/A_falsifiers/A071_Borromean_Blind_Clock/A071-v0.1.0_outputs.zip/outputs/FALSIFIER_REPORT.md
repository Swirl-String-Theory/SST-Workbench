# A006 Blind Borromean & Swirl Clock Falsifier v0.1.0

DEVELOPMENT / UNQUALIFIED; no physical SST claims

Source archive SHA-256: 176da1ea176031952b499389eebc68cc150bb7ef378ebeb1c4cabd399d8bbd21

Contract SHA-256: 0ea3154e15df62a33436744b59da76d48566309f6b3b1b3f4ff30212279dec7b

Source population: 64 triple-component nominal Borromean candidates; 2 masked holdout families.

Model: dimensionless unforced midpoint Rosenhead Biot-Savart filament surrogate.

Source topology: component knot labels supplied but not independently verified; Milnor triple-link invariant unresolved.

Selected comparison: same coordinates as an isolated twist knot, pairs and triple; optional translated unlinked controls.

Qualification: B1-B9 remain unresolved/not run. B2 fails on undersampled runs.

Stability: a small-growth ratio is only a finite-horizon diagnostic, not a proof of asymptotic stability.

Clock: no demonstrated reproducible intrinsic frequency or local proper-time relationship.

Guan, Zuccher & Liu (2025), Physics of Fluids 37, 024126, doi:10.1063/5.0252708 (independent compressible GPE benchmark).

Batch 20261022T164057970351Z_BASIC_SUMMARY.json (BASIC), cases=2, all unresolved for B9.

  BX_1652FB1EA96667: triple endpoint shape errors [0.002094, 0.002283, 0.010788]; B2 FAIL

  BX_222EFCC1EF2E64: triple endpoint shape errors [0.01102, 0.012204, 0.008029]; B2 FAIL

Batch 20261022T164058613417Z_FULL_SUMMARY.json (FULL), cases=2, all unresolved for B9.

  BX_1652FB1EA96667: triple endpoint shape errors [0.079187, 0.08298, 0.117869]; B2 FAIL

  BX_222EFCC1EF2E64: triple endpoint shape errors [0.116829, 0.114802, 0.099873]; B2 FAIL

Batch 20261022T164848736080Z_BASIC_SUMMARY.json (BASIC), cases=2, all unresolved for B9.

  BX_1652FB1EA96667: triple endpoint shape errors [0.002094, 0.002283, 0.010788]; B2 FAIL

  BX_222EFCC1EF2E64: triple endpoint shape errors [0.01102, 0.012204, 0.008029]; B2 FAIL

Batch 20261022T164849108246Z_FULL_SUMMARY.json (FULL), cases=6, all unresolved for B9.

  BX_1652FB1EA96667: triple endpoint shape errors [0.079187, 0.08298, 0.117869]; B2 FAIL

  BX_222EFCC1EF2E64: triple endpoint shape errors [0.116829, 0.114802, 0.099873]; B2 FAIL

  BX_30A8C3775F4465: triple endpoint shape errors [0.073965, 0.077871, 0.115065]; B2 FAIL
