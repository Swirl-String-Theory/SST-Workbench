import json,hashlib
from pathlib import Path
import numpy as np
import pytest
from experiment.readiness import require_ready,CampaignNotReady,implementation_integrity
from experiment.precheck import source_audit,analytic_jacobian
from a060_preflight.mechanics import landreman_field,finite_jacobian,diagnostics
from sst_falsifier.science_contract import assert_science_contract
from sst_falsifier.source_registry import assert_source_contract
from sst_falsifier.gates import assert_gate_plan,load_gate_plan,GateLedger
ROOT=Path(__file__).resolve().parents[1]
def test_sources(): assert source_audit(ROOT)['all_match']
def test_contracts():
    assert_science_contract(ROOT/'science_contract.json');assert_source_contract(ROOT/'source_contract.json');assert_gate_plan(ROOT/'gate_plan.json')
def test_mapping():
    sc=json.loads((ROOT/'science_contract.json').read_text())
    assert all(s['gate']=='G2' for s in sc['steps'][1:])
    gates=load_gate_plan(ROOT/'gate_plan.json')
    assert [g.gate_id for g in gates]==['G'+str(i) for i in range(10)]
    assert all(g.enabled for g in gates)
    assert [g.requires for g in gates]==[()]+[('G'+str(i),) for i in range(9)]
def test_freeze_guard():
    with pytest.raises(CampaignNotReady):require_ready(ROOT)
def test_missing_providers_not_passed():
    assert not (ROOT/'preregistration/FROZEN_PROTOCOL.json').exists()
    p=json.loads((ROOT/'blind_policy.json').read_text());assert p['block_reveal_on_unresolved']
    assert p['reveal_allowed_after_modes']==['CERTIFY']
def test_implementation_integrity(): assert implementation_integrity(ROOT)[0]
def test_zero_tensor():
    with pytest.raises(ValueError):diagnostics(np.zeros((3,3)))
@pytest.mark.parametrize('eps',[-.1,1.,1.2])
def test_invalid_epsilon(eps):
    with pytest.raises(ValueError):landreman_field([1.,.1,.01],eps)
def test_domain_rejection():
    for x in [[0,0,0],[3,0,0],[1,0,1]]:
        with pytest.raises(ValueError):landreman_field(x)
def test_independent_jacobian():
    for eps in [0.,.2,.5]:
        x=np.array([1.04,.16,.04]);J=analytic_jacobian(x,eps)
        assert np.max(np.abs(J-finite_jacobian(lambda y:landreman_field(y,eps),x,1e-5)))<1e-8
