#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
CHECK_ONLY="${CHECK_ONLY:-0}"
cd "$ROOT"

MAIN="SST_CANON-v0.8.20.tex"
RT="SST_CANON-v0.8.20-research-track.tex"
EXPECTED_MAIN="748c53ffa89d181ac2a0d2dd38f27e575f05e2aac9465b0ee0673e6b8f40e698"
EXPECTED_RT="3d011afcf7fd1c837d0f1eeed24d16b7fcee17818d0ad71fb01bdb6ece9b96e3"

actual_main="$(sha256sum "$MAIN" | awk '{print $1}')"
actual_rt="$(sha256sum "$RT" | awk '{print $1}')"

[[ "$actual_main" == "$EXPECTED_MAIN" ]] || { echo "Base hash mismatch: $MAIN" >&2; exit 2; }
[[ "$actual_rt" == "$EXPECTED_RT" ]] || { echo "Base hash mismatch: $RT" >&2; exit 2; }

patches=(
  "patches/0001-helicity-forms-mapping-class.diff"
  "patches/0002-isoperimetric-domain-spectrum.diff"
  "patches/0003-ridgerunner-certification.diff"
)

for patch in "${patches[@]}"; do
  echo "Checking $patch"
  git apply --check "$patch"
  if [[ "$CHECK_ONLY" != "1" ]]; then
    echo "Applying $patch"
    git apply "$patch"
  fi
done

if [[ "$CHECK_ONLY" == "1" ]]; then
  echo "Alle patches zijn toepasbaar; niets gewijzigd."
else
  echo "Alle drie subpatches zijn toegepast."
fi
