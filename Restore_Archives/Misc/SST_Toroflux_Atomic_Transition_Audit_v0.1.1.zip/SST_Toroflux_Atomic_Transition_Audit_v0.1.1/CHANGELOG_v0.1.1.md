# CHANGELOG — v0.1.1

## Purpose

v0.1.1 converts the Toroflux/atomic-transition intuition into preregistered mathematical gates
and immediately tests the minimal model.

## Added

- Minimal axisymmetric potential-flow Hamiltonian for a flat bound state.
- Unique-radius theorem at fixed circulation.
- Conditional \(r_n\propto n^2\), \(E_n\propto-1/n^2\) scaling audit.
- Exact comparison between the CANON circulation quantum and one atomic action quantum.
- Exact integer-compatibility gate.
- Absolute radius and binding-energy normalization gates.
- Literal core-as-orbit scale-separation gate.
- Single phase-slip transition gate.
- Factor-15 multiplicity audit.
- Machine-readable gate ledger and deterministic solver.
- Non-release speculative insert.

## Changed

- “Electron jumps between literal heights” is replaced by a distinction between:
  - microscopic core geometry;
  - atomic-scale external envelope;
  - transition channel.
- The sprite/giant-jet analogy is retained only as transition morphology, not as a derivation of spectral quantization.

## Rejected

- Fixed-circulation potential flow as a generator of a complete \(n\)-ladder.
- Identification of one CANON \(\Gamma_0\) with one unit of atomic orbital action.
- Literal stretching of the resolved electron core to the atomic radius.
- A single-\(\Gamma_0\) phase slip as a \(\Delta n=1\) transition.
- Naive use of the Toroflux coefficient 15 to repair the action or wave-speed deficit.

## Still open

- A separate external-envelope action quantum.
- A Delaunay/action-angle derivation of the atomic spectrum.
- Dynamic flat↔spindle solutions with positive reach and fixed topology.
- Floquet transition modes and selection rules.
- A physical role for the Toroflux factor 15 in a coupling matrix or barrier.
