# SST Contra-Swirl Bridge v0.5 — Spectral EPR/CISS Fusion Audit

Status: **STRICT-SPECTRAL-AUDIT-NEEDS-MORE-DATA**
Score: **64.000/100**

## Canonical SST constants used

- ||v_swirl|| = 1.09384563e+06 m s^-1
- r_c = 1.40897017e-15 m
- rho_f = 7.00000000e-07 kg m^-3
- kappa_SST = 2*pi*r_c*||v_swirl|| = 9.68361920e-09 m^2 s^-1
- H_unit = 2*kappa_SST^2 = 1.87544962e-16 m^4 s^-2

## Gates

- files_parsed: 8
- figures_parsed: 8
- channel_spectra: 20
- pairwise_tests: 16
- fig2_enantiomer_data: True
- fig4_chiral_control_data: True
- robust_chiral_control_contrast: False
- enantiomer_asymmetry_present: False
- direct_full_spectrum_signflip: False
- bootstrap_robust: False
- svd_chirality_mode_present: True
- time_domain_traces_available: False
- score: 64.0
- status: STRICT-SPECTRAL-AUDIT-NEEDS-MORE-DATA

## Interpretation

The supplied files are magnetic-field-domain EPR spectra S(B), not time-domain decoherence traces R(t). Therefore v0.5 can strengthen the spectral CISS/SST canon-candidate claim but cannot promote the bridge hypothesis to CANON by itself.

The central field-domain proxy is

```text
H_spec_tilde = integral |S_b(B)-S_a(B)| dB / [integral |S_a(B)| dB + integral |S_b(B)| dB]
```

The chirality-odd decomposition for a paired spectral comparison is

```text
S_odd(B)  = 0.5 * [S_b(B)-S_a(B)]
S_even(B) = 0.5 * [S_b(B)+S_a(B)]
f_odd = integral S_odd(B)^2 dB / integral [S_odd(B)^2 + S_even(B)^2] dB
```

## Strongest pairwise contrasts

- Fig2b: (en 2)-1 vs 2 (chiral_vs_control), contrast=0.185619, odd_fraction=0.0181286
- Fig2b: (en 1)-1 vs 2 (chiral_vs_control), contrast=0.182792, odd_fraction=0.0170645
- Fig4b: achiral vs chiral (chiral_vs_achiral), contrast=0.16776, odd_fraction=0.0264905
- Fig2d: (S)-1 vs 2 (chiral_vs_control), contrast=0.137962, odd_fraction=0.0104332
- Fig2d: (R)-1 vs 2 (chiral_vs_control), contrast=0.115339, odd_fraction=0.00689994
- Fig2a: (en 1)-1 vs 2 (chiral_vs_control), contrast=0.110618, odd_fraction=0.00794078
- Fig4d: achiral vs chiral (chiral_vs_achiral), contrast=0.0921678, odd_fraction=0.00578674
- Fig2a: (en 2)-1 vs 2 (chiral_vs_control), contrast=0.0667967, odd_fraction=0.00305732

## Bootstrap robustness

Robust contrast pass count: 0/16

## SVD modes

- mode 1: explained variance = 0.548733, cumulative = 0.548733
- mode 2: explained variance = 0.347426, cumulative = 0.896159
- mode 3: explained variance = 0.0379367, cumulative = 0.934096
- mode 4: explained variance = 0.0318049, cumulative = 0.965901
- mode 5: explained variance = 0.0205393, cumulative = 0.98644
- mode 6: explained variance = 0.00678435, cumulative = 0.993225

## Canon policy

- This result may support [SPECTRAL-CISS-CANON-CANDIDATE-DATA].
- It cannot by itself establish [CANON], because the required time-domain decoherence gate R_chi(t) ~ exp(-Gamma_phi t) is not present in these files.
- The next required external information is raw or processed time-resolved EPR traces, replicate uncertainties, or figure metadata mapping the spectra to delay times/temperatures/bridge lengths.