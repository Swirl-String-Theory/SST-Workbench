"""Recreate the time-averaged flow-field figure from raw public outputs."""

from __future__ import annotations

import numpy as np
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Circle
from matplotlib.ticker import FixedFormatter, FixedLocator, MultipleLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

from _common import FIGURE_DIR, find_psi_dir, parse_snapshot_time, setup_matplotlib

from functions import velocity_field
from Helmholtz_decompose import H_decompos
import variable as var


V0 = 0.9
SIGMA = 20
SPEED = 0.55
TIME_MIN = 2000.0
TIME_MAX = 10000.0
CROP_SLICE = (slice(150, 350), slice(600, 800))
FIGSIZE = (3.375, 3.375)
SAVE_NAME = "time_averaged_flow_field.png"


setup_matplotlib()

custom_cmap = LinearSegmentedColormap.from_list(
    "BlueOrange_CB",
    [(0.00, "#2a80d6"), (0.30, "#9ecae1"), (0.50, "#f7f7f7"), (0.70, "#fdd0a2"), (1.00, "#b2182b")],
)

psi_dir = find_psi_dir(V0, SIGMA, SPEED)
psi_files = [path for path in sorted(psi_dir.glob("psi_time:*.npy"), key=parse_snapshot_time) if TIME_MIN <= parse_snapshot_time(path) <= TIME_MAX]
if not psi_files:
    raise RuntimeError(f"No psi snapshots found in [{TIME_MIN}, {TIME_MAX}] for {psi_dir}.")

data_arr = np.asarray([np.load(path) for path in psi_files])

density_mean = np.mean(np.abs(data_arr) ** 2, axis=0)
irr_x_mean = np.zeros_like(density_mean)
irr_y_mean = np.zeros_like(density_mean)
vx_mean = np.zeros_like(density_mean)
vy_mean = np.zeros_like(density_mean)

for psi in data_arr:
    phase = np.arctan2(psi.imag, psi.real)
    vx, vy = velocity_field(phase)
    (vx_irr, vy_irr), _ = H_decompos(vx, vy, vx.shape[1], vx.shape[0], var.dx, var.dy)
    irr_x_mean += vx_irr - SPEED
    irr_y_mean += vy_irr
    vx_mean += vx - SPEED
    vy_mean += vy

count = len(data_arr)
vx_mean /= count
vy_mean /= count
irr_x_mean /= count
irr_y_mean /= count
irr = np.sqrt(irr_x_mean**2 + irr_y_mean**2)
v_mean = np.sqrt(vx_mean**2 + vy_mean**2)

density_crop = density_mean[CROP_SLICE]
v_crop = v_mean[CROP_SLICE]
irr_crop = irr[CROP_SLICE]
mach_crop = irr_crop - np.sqrt(density_crop)

fig = plt.figure(figsize=FIGSIZE)
gs = gridspec.GridSpec(2, 2, width_ratios=[1, 1], wspace=0.05, hspace=0.25, top=0.93, bottom=0.1, left=0.08, right=0.98)
axes = [fig.add_subplot(gs[i, j]) for i in range(2) for j in range(2)]

images = []
images.append(axes[0].imshow(density_crop, aspect="equal", cmap="Blues_r", vmin=0, vmax=1.0))
images.append(axes[1].imshow(v_crop, aspect="equal", cmap="Reds", vmin=0.0, vmax=1.0))
images.append(axes[2].imshow(irr_crop, aspect="equal", cmap="Reds", vmin=0.0, vmax=1.0))
images.append(axes[3].imshow(mach_crop, cmap=custom_cmap, vmin=-0.6, vmax=0.6))
axes[3].contour(mach_crop, levels=[0.0], colors="k", linewidths=0.8)
axes[0].add_patch(Circle((100, 100), 40, color="k", ls="--", lw=0.5, fill=False))

major_ticks = [0, 100, 200]
major_labels = ["-50", "0", "50"]
labels = [
    r"$\overline{{\rho}}(\mathbf{{r}})$",
    r"$|\overline{{\mathbf{{v}}}}(\mathbf{{r}})|$",
    r"$|\overline{{\mathbf{{v}}_\mathrm{{irr}}}}(\mathbf{{r}})|$",
    r"$\overline{{\mathbf{{v}}_\mathrm{{irr}}}}-\overline{{c_\mathrm{{s}}}}$",
]

for idx, (ax, label) in enumerate(zip(axes, labels)):
    ax.set_xticks(major_ticks)
    ax.set_xticklabels(major_labels)
    ax.set_yticks(major_ticks)
    ax.set_yticklabels(major_labels)
    ax.xaxis.set_major_locator(FixedLocator(major_ticks))
    ax.xaxis.set_major_formatter(FixedFormatter(major_labels))
    ax.yaxis.set_major_locator(FixedLocator(major_ticks))
    ax.yaxis.set_major_formatter(FixedFormatter(major_labels))
    ax.xaxis.set_minor_locator(MultipleLocator(50))
    ax.yaxis.set_minor_locator(MultipleLocator(50))
    ax.tick_params(axis="x", which="minor", length=2)
    ax.tick_params(axis="y", which="minor", length=2)
    ax.text(0.75, 0.15, label, transform=ax.transAxes, fontsize=8, va="center", ha="center", color="black")

axes[0].set_xticklabels([])
axes[1].set_xticklabels([])
axes[1].set_yticklabels([])
axes[3].set_yticklabels([])
axes[0].set_ylabel(r"$y/\xi$", labelpad=1)
axes[2].set_ylabel(r"$y/\xi$", labelpad=1)
axes[2].set_xlabel(r"$x/\xi$", labelpad=1)
axes[3].set_xlabel(r"$x/\xi$", labelpad=1)
axes[3].tick_params(axis="both", which="both", color="white", labelcolor="black")

ticks_list = [[0, 1], [0, 1], [0, 1], [-0.6, 0.6]]
ticklabels_list = [["0", r"$\rho_0$"], ["0", r"$c_{{\rm s0}}$"], ["0", r"$c_{{\rm s0}}$"], [r"-0.6$c_{{\rm s0}}$", r"0.6$c_{{\rm s0}}$"]]
for ax, image, ticks, ticklabels in zip(axes, images, ticks_list, ticklabels_list):
    cax = inset_axes(ax, width="40%", height="4%", loc="lower left", bbox_to_anchor=(0.6, 1.05, 1, 1), bbox_transform=ax.transAxes, borderpad=0)
    cbar = plt.colorbar(image, cax=cax, orientation="horizontal")
    cbar.ax.tick_params(labelsize=7)
    cbar.ax.xaxis.set_ticks_position("top")
    cbar.ax.xaxis.set_label_position("top")
    cbar.ax.tick_params(pad=1.5)
    cbar.set_ticks(ticks)
    cbar.set_ticklabels(ticklabels)

for ax, panel in zip(axes, ["(a)", "(b)", "(c)", "(d)"]):
    ax.text(0.05, 0.95, panel, transform=ax.transAxes, fontsize=8, va="top", ha="left")

out = FIGURE_DIR / SAVE_NAME
fig.savefig(out, dpi=600)
plt.close(fig)
print(f"saved {out}")
