# Derivation of beta = alpha - 1 + q

Assume the thin-ring asymptotic form

\[
E(R,a)=\frac12\rho\Gamma^2R\left[L-\alpha\right],
\quad
L=\ln\frac{8R}{a}.
\]

Let the core radius change with major radius according to

\[
q=\frac{d\ln a}{d\ln R}=\frac{R}{a}\frac{da}{dR}.
\]

Then

\[
\frac{dL}{dR}=\frac1R-\frac1a\frac{da}{dR}=\frac{1-q}{R}.
\]

Thus

\[
\frac{dE}{dR}
=\frac12\rho\Gamma^2\left[L-\alpha+1-q\right].
\]

The vortex-ring impulse is

\[
P=\rho\Gamma\pi R^2,
\quad
\frac{dP}{dR}=2\rho\Gamma\pi R.
\]

Therefore

\[
U=\frac{dE}{dP}
=\frac{\Gamma}{4\pi R}\left[L-\alpha+1-q\right].
\]

Comparing with

\[
U=\frac{\Gamma}{4\pi R}\left[L-\beta\right]
\]

gives

\[
\boxed{\beta=\alpha-1+q.}
\]

For fixed core radius, \(q=0\), so \(\beta=\alpha-1\).  For constant toroidal
core volume, \(R a^2=\mathrm{const}\), hence \(q=-1/2\), so
\(\beta=\alpha-3/2\).
