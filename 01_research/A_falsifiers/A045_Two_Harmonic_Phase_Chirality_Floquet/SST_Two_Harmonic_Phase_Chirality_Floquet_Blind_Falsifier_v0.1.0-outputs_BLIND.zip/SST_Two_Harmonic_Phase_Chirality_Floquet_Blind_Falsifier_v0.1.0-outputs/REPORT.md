# SST_Two_Harmonic_Phase_Chirality_Floquet_Blind_Falsifier v0.1.0 — Python reference run

Status: **PRELIMINARY_SURVIVED**
Backend: `python`

## Scope
Dimensionless local-induction reference dynamics with a trace-free two-harmonic strain drive. This release tests the preregistered dynamical-symmetry architecture; it does **not** certify a finite-core SST mechanism.

## Gates
- G0_trefoil_C3_geometry: PASS — {'value': 9.316514800833359e-16, 'threshold': 0.001, 'pass': True}
- G1_one_drive_class_has_exact_C3_dynamic_symmetry: PASS — {'blind_value_min': 8.406059530379491e-15, 'threshold': 1e-10, 'pass': True}
- G2_blind_equivariance_low_branch: PASS — {'value': 7.779107146664009e-16, 'threshold': 0.003, 'pass': True}
- G3_blind_control_separation: PASS — {'value': 7505934953831.497, 'threshold_min': 3.0, 'pass': True}
- G4_numerical_length_drift: PASS — {'value': 1.3246719187082159e-06, 'threshold': 0.1, 'pass': True}

## Formal Floquet gate
SKIP_FORMAL_FLOQUET: no certified periodic orbit / finite-core closure in v0.1.0
