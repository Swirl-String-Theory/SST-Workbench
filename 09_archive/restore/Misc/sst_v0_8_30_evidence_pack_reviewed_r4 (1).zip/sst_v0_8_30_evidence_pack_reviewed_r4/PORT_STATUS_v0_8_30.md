# v0.8.30 evidence-pack port status

| Item | v0.8.30 status | Action |
|---|---|---|
| v0.8.28 numerical suites | Historical baseline retained | Do not relabel as v0.8.30 runs. |
| v0.8.29 density provenance/SSDL audit | Integrated | Covered by direct patch and marker checks. |
| v0.8.30 density ontology | Integrated | `rho_f` is effective response; `rho_sub` remains unresolved. |
| Historical VAM-7 decimal provenance | Integrated in Research Track | Keep `J_omega^VAM` separate from `rho_f`. |
| Accepted omega precision hotfix | Rebased | Present in reviewed v0.8.30 snapshot. |
| Accepted benchmark tautology guard | Rebased | Present with layout-safe archive path. |
| Held `F_swirl^max` printed-value change | Still held | Requires explicit canonical rebaselining. |
| SSTcore action--phase API | Still absent in historical 0.8.18 wheel | Requires current source-tree implementation. |
| v0.8.31 participation audit | Not part of this pack | Separate subsequent evidence delta. |
| v0.8.32 tension protocol | Not part of this pack | Separate preregistration package. |
