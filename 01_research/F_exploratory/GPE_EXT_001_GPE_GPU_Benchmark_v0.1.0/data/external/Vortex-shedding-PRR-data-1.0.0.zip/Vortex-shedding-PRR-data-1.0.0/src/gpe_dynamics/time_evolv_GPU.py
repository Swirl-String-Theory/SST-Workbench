import numpy as np
import cupy as cp
import cupy.fft as cufft

from variable import *                 # Nx, Ny, dx, dy, xmax, ymax, dt, Nt, acceleration_time, ...
from imag_time_evolv import *          # img_time_calculator
# from functions import Plot            # 필요 시 활성화
# from GPE_dynamics_KJH.package.vortex_GPU_legacy import vortex_detect

# --------------------------------------------------
# k-space grid (GPU, complex64)
# --------------------------------------------------
kx = cp.fft.fftfreq(Nx, d=(2*xmax/Nx)) * (2*cp.pi)
ky = cp.fft.fftfreq(Ny, d=(2*ymax/Ny)) * (2*cp.pi)
omega_x, omega_y = cp.meshgrid(kx, ky)

k2 = omega_x**2 + omega_y**2
omega_x = omega_x.astype(cp.complex64)
omega_y = omega_y.astype(cp.complex64)
k2      = k2.astype(cp.complex64)

Gamma = cp.array(Gamma, dtype=cp.complex64)

class time_evolver:
    """
    RK4 half-step (Strang splitting) 
    """
    def __init__(self, V0, v, v_fin, sigma, obstacle_position, V_prime):
        self.psi  = cp.zeros((Ny, Nx), dtype=cp.complex64)
        self.phase = cp.zeros((Ny, Nx), dtype=cp.float64)

        self.V0 = V0
        self.v = v
        self.v_fin = v_fin
        self.sigma = sigma
        self.obstacle_position = obstacle_position

        # Potential on GPU
        self.V_prime = cp.array(V_prime, dtype=cp.complex64)

        # ----- potential/Γ related constants/ masks -----
        # exp(-i(V'+1)dt)
        self.exp_V_const = cp.exp(-1j * (self.V_prime + 1.0) * dt).astype(cp.complex64)

        # Γ masks/constants 
        self.mask_pos = (Gamma.real > 0.01)
        self.mask_neg = ~self.mask_pos

        if self.mask_pos.any():
            Gp = Gamma[self.mask_pos]
            self.exp_iG_dt_pos = cp.exp((1j + Gp) * dt).astype(cp.complex64)
            self.exp_2G_dt_pos = cp.exp(2*Gp*dt).astype(cp.complex64)
            self.expo_pos      = (-0.5j/Gp - 0.5).astype(cp.complex64)

        self.exp_i_dt = cp.exp(1j*dt).astype(cp.complex64)

        # ----- linear operation buffers -----
        self._psi_k  = cp.empty((Ny, Nx), dtype=cp.complex64)
        self._tmp_k  = cp.empty((Ny, Nx), dtype=cp.complex64)
        self._lap_x  = cp.empty((Ny, Nx), dtype=cp.complex64)
        self._dpsi_k = cp.empty((Ny, Nx), dtype=cp.complex64)
        self._dpsi_x = cp.empty((Ny, Nx), dtype=cp.complex64)

        self.Plot_flag = False
        self.path_figures = "outputs"

        # (optional) cuFFT warmup: reduce overhead of first call
        _tmp = cp.zeros((Ny, Nx), dtype=cp.complex64)
        cufft.fft2(_tmp); cufft.ifft2(_tmp)

    # --------------------------------------------------
    # linear RHS: dψ/dt = i( v kx - 0.5 k^2 ) ψ̂  (in k)
    #           + FFT[ Γ * IFFT( -0.5 k^2 ψ̂ ) ]
    # return: real space dψ/dt (complex64)
    # --------------------------------------------------
    def _rhs_linear(self, psi, vel):
        # ψ̂
        self._psi_k[...] = cufft.fft2(psi)

        # res1_k = i*(vel*kx - 0.5 k^2) * ψ̂
        cp.multiply(1j*(vel*omega_x - 0.5*k2), self._psi_k, out=self._tmp_k)

        # lap_x = IFFT( -0.5 k^2 * ψ̂ )
        cp.multiply(-0.5*k2, self._psi_k, out=self._dpsi_k)
        self._lap_x[...] = cufft.ifft2(self._dpsi_k)

        # Γ * lap_x  → FFT
        self._lap_x[...] = self._lap_x * Gamma
        self._dpsi_k[...] = cufft.fft2(self._lap_x)

        # dψ_k = res1_k + Γ∇²ψ (in k)
        cp.add(self._tmp_k, self._dpsi_k, out=self._dpsi_k)

        # dψ/dt (물리)
        self._dpsi_x[...] = cufft.ifft2(self._dpsi_k)
        return self._dpsi_x

    # --------------------------------------------------
    # potential part(nonlinear) full-step (dt )
    # Γ>0.01 : ψ -> ψ * exp((i+Γ)dt) * exp(-i(V'+1)dt) * (1 + |ψ|^2 (e^{2Γdt}-1))^{-0.5j/Γ - 0.5}
    # Γ<=0.01: ψ -> ψ * exp(i dt) * exp(-i(V'+1)dt) * exp(-i |ψ|^2 dt)
    # --------------------------------------------------
    def _potential_fullstep(self, psi_in):
        n = cp.abs(psi_in)**2
        psi_out = cp.empty_like(psi_in)

        if self.mask_pos.any():
            denom = 1.0 + n[self.mask_pos]*(self.exp_2G_dt_pos - 1.0)
            term  = cp.power(denom, self.expo_pos)
            psi_out[self.mask_pos] = psi_in[self.mask_pos] \
                                     * self.exp_iG_dt_pos * self.exp_V_const[self.mask_pos] * term

        if self.mask_neg.any():
            phase = self.exp_i_dt * self.exp_V_const[self.mask_neg] * cp.exp(-1j*n[self.mask_neg]*dt)
            psi_out[self.mask_neg] = psi_in[self.mask_neg] * phase

        return psi_out

    # --------------------------------------------------
    # RK4 half-step (h = dt/2) for linear part
    # --------------------------------------------------
    def _rk4_halfstep_linear(self, psi, vel):
        h = 0.5*dt
        k1 = self._rhs_linear(psi, vel)
        k2 = self._rhs_linear(psi + 0.5*h*k1, vel)
        k3 = self._rhs_linear(psi + 0.5*h*k2, vel)
        k4 = self._rhs_linear(psi + h*k3, vel)
        return psi + h*( (1.0/6.0)*k1 + (1.0/3.0)*k2 + (1.0/3.0)*k3 + (1.0/6.0)*k4 )

    # --------------------------------------------------
    # single timestep: Strang (Linear half) → (Potential full) → (Linear half)
    # return: current velocity
    # --------------------------------------------------
    def time_evolv(self, tt):
        # velocity in acceleration phase: v(t) = v + (v_fin - v)/acceleration_time * t
        if self.v + (self.v_fin - self.v)/acceleration_time * tt < self.v_fin:
            vel_now = self.v + (self.v_fin - self.v)/acceleration_time * tt
        else:
            vel_now = self.v_fin

        # (1) linear half-step (RK4)
        psi1 = self._rk4_halfstep_linear(self.psi, vel_now)

        # (2) potential full-step
        psi2 = self._potential_fullstep(psi1)

        # (3) linear half-step (RK4)
        self.psi = self._rk4_halfstep_linear(psi2, vel_now)

        return vel_now

    # --------------------------------------------------
    # full simulation
    # --------------------------------------------------
    def wavefunction(self):
        print("generate ground state")
        trial = img_time_calculator(self.V_prime, self.v).make_init()
        print("ground state done!")
        self.psi = cp.array(trial, dtype=cp.complex64)

        hit_t, hit_v = 0.0, self.v

        for i in range(Nt):
            tt = i*dt
            vel = self.time_evolv(tt)

            if self.Plot_flag and (i % 100 == 0 or i == Nt-1):
                dens = cp.asnumpy(cp.abs(self.psi)**2)
                ph   = cp.asnumpy(cp.angle(self.psi))
                Plot(dens, tt, vel, "Dyn Number density", self.path_figures)
                Plot(ph,   tt, vel, "Dyn Phase",         self.path_figures)

        return (tt, vel)


# --------------------------------------------------
# example execution (필요 시 수정)
# --------------------------------------------------
if __name__ == "__main__":
    V = 1.1 * np.exp(-2*((xx - obstacle_position)**2 + yy**2) / 10.0**2)
    V_prime = V - 1.0

    te = time_evolver(V0=0.0, v=0.01, v_fin=0.26, sigma=10.0,
                      obstacle_position=obstacle_position,
                      V_prime=V_prime)
    te.Plot_flag = False

    from time import time
    t0 = time()
    t_hit, v_hit = te.wavefunction()
    t1 = time()
    print(f"elapsed: {(t1-t0):.3f} s, hit=({t_hit:.4f}, {v_hit:.4f})")
