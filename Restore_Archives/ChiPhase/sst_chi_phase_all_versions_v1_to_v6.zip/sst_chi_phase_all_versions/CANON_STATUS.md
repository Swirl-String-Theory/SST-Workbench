# CANON / Research Track Status

This combined package gathers the chi-phase packages v1 through v6.

## Correct interpretation

The robust, non-tautological result is **not** the unconditional identity

\[
c_\chi = v_{\rm swirl}.
\]

The better Research Track formula is

\[
c_\chi^2
=
\frac{\int_A \rho(r)\,v_\theta(r)^2 r_\perp^2\,dA}
{\int_A \rho(r)\,r_\perp^2\,dA}
=
\langle v_\theta^2\rangle_{r^2,\rho}.
\]

Thus \(c_\chi=v_{\rm swirl}\) only follows when \(v_{\rm swirl}\) is defined or independently derived as the \(r^2,\rho\)-weighted RMS swirl speed of the resolved core.

## Version status

- **v1**: archive. Shared-moment consistency check. Useful for implementation sanity only.
- **v2**: archive. Shape/anisotropy consistency check under the same shared-moment ansatz.
- **v3**: active Research Track. Profile-derived stiffness extractor; breaks the tautology.
- **v4**: active Research Track. Four-profile core admissibility selector.
- **v5**: active Research Track. Profile-zoo selector: Euler/Rankine, smooth-matched, Lamb-Oseen, NLSE/GP, Gaussian.
- **v6**: active Research Track. Analytic/numeric root selector for the smooth-matched polynomial family.

## v6 key result

For

\[
f_{a_0}(x)=x\left[a_0+(3-2a_0)x^2+(a_0-2)x^4\right],
\]

with \(f(0)=0\), \(f(1)=1\), and \(f'(1)=-1\), uniform density gives

\[
\left(\frac{c_\chi}{v_{\rm ref}}\right)^2
=
\frac{2a_0^2+13a_0+78}{105}.
\]

The root \(c_\chi/v_{\rm ref}=1\) is

\[
a_0^\star=\frac{\sqrt{385}-13}{4}\approx1.6553542176.
\]

This is close to, but not equal to, \(\varphi\approx1.6180339887\).

## Open problem before canonization

The remaining canonization bottleneck is a genuine Euler/NLSE/variational derivation selecting the physical core profile, not merely fitting or closing against \(c_\chi/v_{\rm ref}=1\).
