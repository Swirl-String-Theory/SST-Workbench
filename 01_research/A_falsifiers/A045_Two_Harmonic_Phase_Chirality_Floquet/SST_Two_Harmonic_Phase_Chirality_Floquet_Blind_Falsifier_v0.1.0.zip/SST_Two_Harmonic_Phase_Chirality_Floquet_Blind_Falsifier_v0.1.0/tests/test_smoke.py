import json, math
from sst_thpcf.geometry import torus_trefoil
from sst_thpcf.dynamics import evolve

def test_python_smoke():
    cfg={"omega":1.0,"a1":1.0,"a2":0.65,"phase":0.0,"chirality":"CNR","drive_strength":0.005,"beta_lia":0.002,"envelope":"flat","total_time":0.2,"dt":0.01,"reparam_every":0}
    X=torus_trefoil(48)
    Y=evolve(X,cfg,"python")
    assert Y.shape==X.shape
