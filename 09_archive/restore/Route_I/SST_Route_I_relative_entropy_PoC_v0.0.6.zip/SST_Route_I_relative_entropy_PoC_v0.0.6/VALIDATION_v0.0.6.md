# Validation v0.0.6

- Python syntax: `PASS` (`python -m py_compile`).
- Deterministic rerun: `PASS`; both CSV outputs are byte-identical.
- Chain residuals: exactly zero for all audited sizes.
- Betti numbers: exactly `(1,3,3,1)` for all audited sizes.
- Physical positive-mode count: exactly `2 N^3 - 2`.
- Boundary trace rank: exactly `2 N^2` for `N=3,4,5,6`.
- All 16 automated gates: `PASS`.
- LaTeX theorem source: `PASS`; compiled with `pdflatex`.

The validation certifies only the frozen linearized common foundation. It does
not certify the nonlinear compact phase or derive the physical adjacency scale.
