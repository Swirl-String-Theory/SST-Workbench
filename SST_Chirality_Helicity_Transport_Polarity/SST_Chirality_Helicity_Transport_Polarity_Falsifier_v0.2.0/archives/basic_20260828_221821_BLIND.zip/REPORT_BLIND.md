# SST Chirality–Helicity Transport Polarity Falsifier v0.2.0 — Blind Analysis

**Blindness:** source name/path, family, original/mirror role and parse provenance were not read. The reveal mapping is not present in this output directory.

## Gate counts

```json
{
  "INDETERMINATE_SHAPE_DRIFT": 1,
  "INVALID_TRAJECTORY_TIMESTEP": 5
}
```

## Independent pair statistics

- Independent source mirror pairs: 6
- corr(|Xi_H|, |Pi|): Pearson = 0.291487
- corr ranks: Spearman = 0.485714
- pair-invariant beta signs: negative=4, positive=2, finite n=6

## Pair gates

| pair | C | N | a/L | Xi odd | RE max | RE parity | |Pi| | Pi odd | launch Pi odd max | exc rel.std | log amp | shape drift | status |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| P0001 | 3 | 72 | 0.025 | 1.77e-10 | 0.252 | 1.1e-16 | 0.0342 | 2.18e-13 | 1.77e-12 | 0.247 | 1.96 | 0.519 | INDETERMINATE_SHAPE_DRIFT |
| P0002 | 1 | 72 | 0.025 | 0 | 0.824 | 1.35e-16 | 0.131 | 6.38e-12 | 8.54e-12 | 0.117 | 9.11 | 2 | INVALID_TRAJECTORY_TIMESTEP |
| P0003 | 1 | 72 | 0.025 | 4.73e-16 | 0.681 | 2.45e-16 | 0.394 | 9.81e-14 | 2.94e-13 | 0.174 | 6.74 | 1.75 | INVALID_TRAJECTORY_TIMESTEP |
| P0004 | 1 | 72 | 0.025 | 0 | 0.541 | 0 | 0.206 | 1.37e-13 | 1.7e-13 | 0.776 | 3.22 | 0.468 | INVALID_TRAJECTORY_TIMESTEP |
| P0005 | 2 | 72 | 0.025 | 0 | 0.529 | 0 | 0.796 | 9.76e-16 | 4.74e-14 | 0.000704 | 4.68 | 0.808 | INVALID_TRAJECTORY_TIMESTEP |
| P0006 | 2 | 72 | 0.025 | 5.88e-17 | 0.558 | 0 | 0.189 | 1.55e-11 | 4.72e-11 | 0.978 | 10.4 | 2.54 | INVALID_TRAJECTORY_TIMESTEP |

## Interpretation order

A `PASS_*` is only reachable after parity, timestep/mesh, relative-equilibrium, shape-drift, gauge and amplification gates. Mirror symmetry alone is therefore not counted as a physical detection.
