# Route B BEMv12 Fourier-convention audit

BEMv12 investigates the BEMv11 length provenance mismatch:

\[
L_{\rm Fourier}\neq L_{\rm database}.
\]

It checks:

1. Fourier convention variants,
2. derivative vs polygon arclength,
3. global scale normalization,
4. printed coefficient rounding sensitivity.

No observed alpha is used.

## Outputs

```text
fourier_convention_audit.csv
coefficient_rounding_sensitivity.csv
scale_normalization_audit.csv
alpha_leading_v12_budget.csv
fourier_convention_report.md
run_config_v12.json
```

## Fast run

```bash
python routeB_RT_bem_v12_fourier_convention_audit.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v12_fourier \
  --ideal-xml-knot-ids 0:1:1,3:1:1,4:1:1 \
  --samples 32000 \
  --rounding-trials 80 \
  --rounding-samples 6000
```

## Larger rounding run

```bash
python routeB_RT_bem_v12_fourier_convention_audit.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v12_fourier_hi \
  --ideal-xml-knot-ids 0:1:1,3:1:1,4:1:1 \
  --samples 64000 \
  --rounding-trials 300 \
  --rounding-samples 12000
```

## Interpretation

If convention variants do not fix the mismatch, but coefficient rounding can plausibly move the arclength by the observed amount, then the `L` column is the correct provenance anchor and the printed Fourier block is only an approximation.
