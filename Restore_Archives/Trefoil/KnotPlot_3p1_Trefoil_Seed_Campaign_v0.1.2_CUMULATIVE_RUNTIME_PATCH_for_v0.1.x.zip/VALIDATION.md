# VALIDATION — v0.1.2

Release validation:

- Frozen seed manifest: **byte-identical to v0.1.0**
- Frozen seed count: **38**
- Synthetic (2,3) trefoil safety screen: **38/38 PASS**
- Synthetic identity128 uniqueness: **38/38**
- Runtime topology diagnostics: `safe`, `dowker`, `lnknum`
- `alex -1`: **absent from all generated/base KPC scripts**
- Static production KPC generation: **38/38 PASS**
- Checkpoints: `i00000`, `i01000`, `i04000`, `i10000`
- Runner ignores known KnotPlot pre-banner startup noise only when expected
  output files are actually present.

The v0.1.0 target run failed before `base_3p1_300.*` was written. Therefore no
prospective seed geometry or i10000 endpoint was generated before this hotfix.

Real KnotPlot execution remains target-machine work.

## v0.1.2 file-system regression

- Parsed `save`/`coords` target parents are created with
  `mkdir(parents=True, exist_ok=True)` before KnotPlot launches.
- Runtime directory placeholders are included in the release ZIP.
- Scientific preregistration lock is byte-identical to v0.1.1.
