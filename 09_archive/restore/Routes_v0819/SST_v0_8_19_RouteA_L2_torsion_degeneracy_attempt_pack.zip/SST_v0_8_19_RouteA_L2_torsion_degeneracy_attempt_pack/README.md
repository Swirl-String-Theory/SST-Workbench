# SST v0.8.19 Route A L2 torsion-degeneracy attempt

Status: `[RESEARCH-TRACK] [L2-DERIVATION-ATTEMPT] [NOT CANON] [NO FREE SCAN]`

This pack continues the Route-A task: derive `Lambda_L` or a non-fitted torsion degeneracy.

It does **not** claim a Planck-time derivation. It tests one sharper candidate for the missing degeneracy:

```tex
g_T = dim(R^3 \otimes Lambda^2 R^3) (4 pi)^2 = 9(4 pi)^2 = 144 pi^2.
```

When this candidate multiplies the preregistered paired 3D Weyl/radial channel count,

```tex
K_pair = [2/(6 pi^2)]^2,
```

the coefficient becomes exactly

```tex
K_pair * 144 pi^2 = 16/pi^2.
```

Numerical result:

- target sigma_pierce Lambda_L = `1.914036558578934e+69 m^-2`
- Cartan-angular candidate = `1.925039396852048e+69 m^-2`
- ratio to target = `1.005748499538213`
- model Planck time / reference Planck time = `0.997138083132867`
- exact entropy normalization required = `0.994284356833888 nats`
- exact rho_f sync required = `7.040239496767492e-07 kg m^-3`

Verdict: this is a **better L2 candidate**, not a derivation. It derives a plausible non-fitted degeneracy factor, but still leaves four open assumptions:

1. why `rho_core/rho_f` is a state-depth/impedance degeneracy;
2. why Route A uses paired causal cells, giving `(c/vchar)^6`;
3. why the paired `(4 pi)^2` angular measure is not double-counted by Weyl's volume coefficient;
4. why sigma_pierce should be near one nat.

Run:

```bash
python scripts/routeA_L2_torsion_degeneracy_attempt.py --out-json results/check.json --out-csv results/check.csv
```
