#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SST Contra-Swirl Bridge Test v0.5 — Spectral EPR/CISS Fusion Audit
=====================================================================

Purpose
-------
This script extends the v0.4 spectral EPR/CISS audit into a stronger
field-domain canon-candidate audit for Swirl-String Theory (SST). It is designed
to auto-import the CASTLE/Eckvahl Science 2023 Figure 2 / Figure 4 text files,
but it also accepts compatible field-swept EPR text/CSV files.

Core capabilities
-----------------
1. Auto-discover and parse field-swept spectra from files matching:
   CASTLE-NWU-UNIPR-Eckvahl-Science2023-Fig*.txt
2. Convert wide figure files into a normalized long-format dataset.
3. Apply baseline correction using edge-linear baseline fitting.
4. Compute channel-level spectral features.
5. Compute pairwise chirality metrics:
   - spectral contrast index
   - odd/even decomposition
   - odd power fraction
   - sign-flip correlation
   - same-phase correlation
   - chiral/achiral RMS enhancement
6. Perform bootstrap robustness over magnetic-field windows.
7. Perform SVD/PCA-like mode extraction on normalized spectra.
8. Build an SST feature bank for future classifiers and SSTcore ingestion.
9. Generate plots, CSVs, JSON audit output, and a Markdown summary.

Canon-status policy
-------------------
This script may return SPECTRAL-CISS-CANON-CANDIDATE-DATA, but it will not return
CANON because the supplied figure files are field-domain spectral sweeps S(B),
not raw time-resolved decoherence traces R(t).

Author: generated with ChatGPT for Omar Iskandarani's SST workflow
License: user-local research utility; adapt freely.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import shutil
import sys
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
except Exception:  # pragma: no cover
    plt = None


# -----------------------------------------------------------------------------
# SST canonical constants
# -----------------------------------------------------------------------------
V_SWIRL = 1.09384563e6  # m s^-1, ||v_swirl||
R_C = 1.40897017e-15   # m
RHO_F = 7.0e-7         # kg m^-3
KAPPA_SST = 2.0 * math.pi * R_C * V_SWIRL
H_UNIT = 2.0 * KAPPA_SST * KAPPA_SST


# -----------------------------------------------------------------------------
# Data containers
# -----------------------------------------------------------------------------
@dataclass
class ChannelMeta:
    figure_id: str
    source_file: str
    channel: str
    channel_type: str
    chirality_class: int
    field_column_index: int
    signal_column_index: int


@dataclass
class AuditGates:
    files_parsed: int
    figures_parsed: int
    channel_spectra: int
    pairwise_tests: int
    fig2_enantiomer_data: bool
    fig4_chiral_control_data: bool
    robust_chiral_control_contrast: bool
    enantiomer_asymmetry_present: bool
    direct_full_spectrum_signflip: bool
    bootstrap_robust: bool
    svd_chirality_mode_present: bool
    time_domain_traces_available: bool
    score: float
    status: str


# -----------------------------------------------------------------------------
# Utility helpers
# -----------------------------------------------------------------------------
def safe_float(x) -> float:
    if x is None:
        return float("nan")
    s = str(x).strip().replace("\ufeff", "")
    if s == "" or s.lower() in {"nan", "none", "null"}:
        return float("nan")
    try:
        return float(s)
    except Exception:
        return float("nan")


def figure_id_from_path(path: Path) -> str:
    m = re.search(r"(Fig\d+[a-z]?)", path.name, re.IGNORECASE)
    if m:
        return m.group(1).replace("fig", "Fig")
    return path.stem


def classify_channel(channel: str) -> Tuple[str, int]:
    """Return (channel_type, chirality_class)."""
    c = str(channel).strip().replace("\ufeff", "")
    cl = c.lower()
    # Explicit controls
    if "achiral" in cl:
        return "achiral_control", 0
    if cl in {"2", "control", "ctrl", "reference", "ref"} or cl.endswith("\t2"):
        return "control", 0
    # Chiral aggregate
    if "chiral" in cl and "achiral" not in cl:
        return "chiral_aggregate", +1
    # R/S labels
    if re.search(r"\(\s*r\s*\)", cl) or cl.startswith("r") or "(r)-" in cl:
        return "enantiomer_R", +1
    if re.search(r"\(\s*s\s*\)", cl) or cl.startswith("s") or "(s)-" in cl:
        return "enantiomer_S", -1
    # en 1 / en 2 labels: convention only. v0.5 does not claim absolute R/S.
    if "en 1" in cl or "en1" in cl:
        return "enantiomer_1", +1
    if "en 2" in cl or "en2" in cl:
        return "enantiomer_2", -1
    return "unknown", 0


def robust_trapz(y: np.ndarray, x: np.ndarray) -> float:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 2:
        return float("nan")
    return float(np.trapezoid(y[mask], x[mask]))


def rms(y: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(y)
    if mask.sum() == 0:
        return float("nan")
    return float(np.sqrt(np.mean(y[mask] ** 2)))


def pearson(a: np.ndarray, b: np.ndarray) -> float:
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return float("nan")
    aa = a[mask] - np.mean(a[mask])
    bb = b[mask] - np.mean(b[mask])
    den = np.sqrt(np.sum(aa * aa) * np.sum(bb * bb))
    if den == 0:
        return float("nan")
    return float(np.sum(aa * bb) / den)


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


# -----------------------------------------------------------------------------
# Parsing
# -----------------------------------------------------------------------------
def read_table_loose(path: Path) -> pd.DataFrame:
    """Read TXT/CSV robustly with tab/comma/semicolon/whitespace fallback.

    CASTLE/Eckvahl text exports may be UTF-16LE with BOM, despite the .txt
    extension. The parser therefore tries several encodings before separator
    fallbacks.
    """
    encodings = ["utf-8-sig", "utf-16", "utf-16le", "latin1"]
    seps = ["\t", ",", ";", r"\s+"]
    last_exc = None
    for enc in encodings:
        for sep in seps:
            try:
                df = pd.read_csv(path, sep=sep, engine="python", dtype=str, encoding=enc)
                if df.shape[1] >= 2:
                    return df
            except Exception as exc:
                last_exc = exc
                continue
    raise last_exc if last_exc else RuntimeError(f"Unable to read {path}")


def drop_unit_row(df: pd.DataFrame) -> pd.DataFrame:
    if len(df) == 0:
        return df
    first = [str(x).strip().lower() for x in df.iloc[0].values]
    unit_like = sum(1 for x in first if x in {"mt", "a.u.", "au", "arb", ""})
    numeric_like = sum(1 for x in first if np.isfinite(safe_float(x)))
    if unit_like > 0 and numeric_like == 0:
        return df.iloc[1:].reset_index(drop=True)
    # Fig4 second header often: mT blank blank. If first cell mT and others empty.
    if len(first) > 0 and first[0] == "mt":
        return df.iloc[1:].reset_index(drop=True)
    return df


def parse_file(path: Path) -> pd.DataFrame:
    """Parse one figure file into long format."""
    df0 = read_table_loose(path)
    df0.columns = [str(c).strip().replace("\ufeff", "") for c in df0.columns]
    df0 = drop_unit_row(df0)
    figure_id = figure_id_from_path(path)

    long_rows: List[dict] = []
    cols = list(df0.columns)

    # Identify numeric columns. Convert all to floats in a side array.
    numeric = {}
    for c in cols:
        numeric[c] = df0[c].map(safe_float).to_numpy(dtype=float)

    # Case A: columns alternate field/signal/field/signal/field/signal.
    # e.g., B (mT), (en 1)-1, B (mT).1, (en 2)-1, B (mT).2, 2
    field_like = [i for i, c in enumerate(cols) if ("field" in c.lower() or "b (mt" in c.lower() or c.lower().startswith("b"))]
    used_pairs = []
    if len(field_like) >= 2:
        for fi in field_like:
            si = fi + 1
            if si < len(cols):
                field_col = cols[fi]
                sig_col = cols[si]
                if sig_col in field_like:
                    continue
                x = numeric[field_col]
                y = numeric[sig_col]
                if np.isfinite(x).sum() >= 3 and np.isfinite(y).sum() >= 3:
                    ctype, chirality = classify_channel(sig_col)
                    for xv, yv in zip(x, y):
                        if np.isfinite(xv) and np.isfinite(yv):
                            long_rows.append({
                                "figure_id": figure_id,
                                "source_file": path.name,
                                "field_mT": float(xv),
                                "channel": sig_col.strip(),
                                "channel_type": ctype,
                                "chirality_class": chirality,
                                "signal_raw": float(yv),
                                "field_column": field_col,
                                "signal_column": sig_col,
                            })
                    used_pairs.append((field_col, sig_col))
        if long_rows:
            return pd.DataFrame(long_rows)

    # Case B: one field column + multiple signal channels.
    field_col = None
    for c in cols:
        cl = c.lower()
        if "field" in cl or "b (mt" in cl or cl == "b" or cl.startswith("b "):
            field_col = c
            break
    if field_col is None:
        field_col = cols[0]

    x = numeric[field_col]
    for si, sig_col in enumerate(cols):
        if sig_col == field_col:
            continue
        y = numeric[sig_col]
        if np.isfinite(y).sum() < 3:
            continue
        ctype, chirality = classify_channel(sig_col)
        for xv, yv in zip(x, y):
            if np.isfinite(xv) and np.isfinite(yv):
                long_rows.append({
                    "figure_id": figure_id,
                    "source_file": path.name,
                    "field_mT": float(xv),
                    "channel": sig_col.strip(),
                    "channel_type": ctype,
                    "chirality_class": chirality,
                    "signal_raw": float(yv),
                    "field_column": field_col,
                    "signal_column": sig_col,
                })

    return pd.DataFrame(long_rows)


def discover_files(input_dir: Path, pattern: str) -> List[Path]:
    files = sorted(input_dir.glob(pattern))
    if not files:
        # fallback: any likely txt/csv containing Fig in name
        files = sorted(list(input_dir.glob("*Fig*.txt")) + list(input_dir.glob("*Fig*.csv")))
    return [p for p in files if p.is_file()]


# -----------------------------------------------------------------------------
# Baseline correction and features
# -----------------------------------------------------------------------------
def edge_linear_baseline(x: np.ndarray, y: np.ndarray, edge_frac: float = 0.12) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 5:
        return np.zeros_like(y)
    xs = x[mask]
    ys = y[mask]
    order = np.argsort(xs)
    xs = xs[order]
    ys = ys[order]
    n = len(xs)
    k = max(2, int(round(edge_frac * n)))
    xb = np.concatenate([xs[:k], xs[-k:]])
    yb = np.concatenate([ys[:k], ys[-k:]])
    try:
        m, b = np.polyfit(xb, yb, 1)
        return m * x + b
    except Exception:
        return np.full_like(y, np.nanmedian(yb))


def preprocess_long(long_df: pd.DataFrame, edge_frac: float = 0.12) -> pd.DataFrame:
    out = []
    keys = ["figure_id", "source_file", "channel"]
    for (fig, src, ch), g in long_df.groupby(keys, sort=True):
        gg = g.sort_values("field_mT").copy()
        x = gg["field_mT"].to_numpy(dtype=float)
        y = gg["signal_raw"].to_numpy(dtype=float)
        base = edge_linear_baseline(x, y, edge_frac=edge_frac)
        yc = y - base
        scale = rms(yc)
        if not np.isfinite(scale) or scale == 0:
            scale = 1.0
        gg["baseline_linear"] = base
        gg["signal_bc"] = yc
        gg["signal_norm"] = yc / scale
        out.append(gg)
    if not out:
        return long_df.copy()
    return pd.concat(out, ignore_index=True)


def compute_channel_metrics(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (fig, src, ch), g in df.groupby(["figure_id", "source_file", "channel"], sort=True):
        g = g.sort_values("field_mT")
        x = g["field_mT"].to_numpy(float)
        y = g["signal_bc"].to_numpy(float)
        yr = g["signal_raw"].to_numpy(float)
        abs_area = robust_trapz(np.abs(y), x)
        signed_area = robust_trapz(y, x)
        power_area = robust_trapz(y * y, x)
        rr = rms(y)
        peak_abs = float(np.nanmax(np.abs(y))) if np.isfinite(y).any() else float("nan")
        if np.isfinite(y).sum() >= 2 and np.nansum(np.abs(y)) > 0:
            center = robust_trapz(x * np.abs(y), x) / max(abs_area, 1e-300)
            var = robust_trapz(((x - center) ** 2) * np.abs(y), x) / max(abs_area, 1e-300)
            width = math.sqrt(max(var, 0.0))
        else:
            center = width = float("nan")
        ctype = str(g["channel_type"].iloc[0])
        chirality = int(g["chirality_class"].iloc[0])
        rows.append({
            "figure_id": fig,
            "source_file": src,
            "channel": ch,
            "channel_type": ctype,
            "chirality_class": chirality,
            "n_points": int(len(g)),
            "field_min_mT": float(np.nanmin(x)),
            "field_max_mT": float(np.nanmax(x)),
            "rms_raw": rms(yr),
            "rms_bc": rr,
            "peak_abs_bc": peak_abs,
            "abs_area_bc": abs_area,
            "signed_area_bc": signed_area,
            "power_area_bc": power_area,
            "center_of_abs_power_mT": center,
            "width_abs_power_mT": width,
        })
    return pd.DataFrame(rows)


def interpolate_pair(ga: pd.DataFrame, gb: pd.DataFrame, n_grid: int = 800) -> Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]]:
    xa = ga["field_mT"].to_numpy(float)
    ya = ga["signal_bc"].to_numpy(float)
    xb = gb["field_mT"].to_numpy(float)
    yb = gb["signal_bc"].to_numpy(float)
    maska = np.isfinite(xa) & np.isfinite(ya)
    maskb = np.isfinite(xb) & np.isfinite(yb)
    xa, ya = xa[maska], ya[maska]
    xb, yb = xb[maskb], yb[maskb]
    if len(xa) < 5 or len(xb) < 5:
        return None
    ia = np.argsort(xa)
    ib = np.argsort(xb)
    xa, ya = xa[ia], ya[ia]
    xb, yb = xb[ib], yb[ib]
    xmin = max(float(np.nanmin(xa)), float(np.nanmin(xb)))
    xmax = min(float(np.nanmax(xa)), float(np.nanmax(xb)))
    if not np.isfinite(xmin) or not np.isfinite(xmax) or xmax <= xmin:
        return None
    grid = np.linspace(xmin, xmax, n_grid)
    ya_i = np.interp(grid, xa, ya)
    yb_i = np.interp(grid, xb, yb)
    return grid, ya_i, yb_i


def pair_category(a_type: str, b_type: str, a_chi: int, b_chi: int) -> str:
    types = {a_type, b_type}
    if "achiral_control" in types and "chiral_aggregate" in types:
        return "chiral_vs_achiral"
    if {a_chi, b_chi} == {-1, +1}:
        return "enantiomer_pair"
    if 0 in {a_chi, b_chi} and (a_chi != b_chi):
        return "chiral_vs_control"
    return "other_pair"


def compute_pairwise_metrics(df: pd.DataFrame, n_grid: int = 800) -> pd.DataFrame:
    rows = []
    grouped = dict(tuple(df.groupby(["figure_id", "channel"], sort=True)))
    # Work per figure to avoid meaningless cross-figure pairs.
    for fig, figdf in df.groupby("figure_id", sort=True):
        channels = sorted(figdf["channel"].unique())
        for i in range(len(channels)):
            for j in range(i + 1, len(channels)):
                cha, chb = channels[i], channels[j]
                ga = figdf[figdf["channel"] == cha]
                gb = figdf[figdf["channel"] == chb]
                interp = interpolate_pair(ga, gb, n_grid=n_grid)
                if interp is None:
                    continue
                x, ya, yb = interp
                a_type = str(ga["channel_type"].iloc[0])
                b_type = str(gb["channel_type"].iloc[0])
                a_chi = int(ga["chirality_class"].iloc[0])
                b_chi = int(gb["chirality_class"].iloc[0])
                diff = yb - ya
                even = 0.5 * (yb + ya)
                odd = 0.5 * (yb - ya)
                denom_abs = robust_trapz(np.abs(ya), x) + robust_trapz(np.abs(yb), x)
                contrast = robust_trapz(np.abs(diff), x) / max(denom_abs, 1e-300)
                odd_power = robust_trapz(odd * odd, x)
                even_power = robust_trapz(even * even, x)
                odd_frac = odd_power / max(odd_power + even_power, 1e-300)
                same_corr = pearson(ya, yb)
                signflip_corr = pearson(ya, -yb)
                rms_a = rms(ya)
                rms_b = rms(yb)
                rms_ratio_b_over_a = rms_b / max(rms_a, 1e-300)
                # Field-domain helicity proxy = same as contrast, retained under SST naming.
                h_spec_proxy = contrast
                h_spec_dimensional_proxy = h_spec_proxy * H_UNIT
                rows.append({
                    "figure_id": fig,
                    "channel_a": cha,
                    "channel_b": chb,
                    "channel_type_a": a_type,
                    "channel_type_b": b_type,
                    "chirality_a": a_chi,
                    "chirality_b": b_chi,
                    "pair_category": pair_category(a_type, b_type, a_chi, b_chi),
                    "n_grid": int(len(x)),
                    "field_min_mT": float(x[0]),
                    "field_max_mT": float(x[-1]),
                    "spectral_contrast_index": float(contrast),
                    "odd_fraction_power": float(odd_frac),
                    "same_phase_corr": float(same_corr),
                    "signflip_corr": float(signflip_corr),
                    "rms_a": float(rms_a),
                    "rms_b": float(rms_b),
                    "rms_ratio_b_over_a": float(rms_ratio_b_over_a),
                    "abs_diff_area": robust_trapz(np.abs(diff), x),
                    "odd_power_area": float(odd_power),
                    "even_power_area": float(even_power),
                    "sst_hspec_proxy": float(h_spec_proxy),
                    "sst_hspec_dimensional_proxy_m4_s2": float(h_spec_dimensional_proxy),
                    "best_phase_relation": "signflip" if np.isfinite(signflip_corr) and signflip_corr > same_corr else "same_or_mixed",
                })
    return pd.DataFrame(rows)


# -----------------------------------------------------------------------------
# Bootstrap and SVD
# -----------------------------------------------------------------------------
def bootstrap_pair_metrics(df: pd.DataFrame, n_boot: int = 300, window_frac: float = 0.55, n_grid: int = 800, seed: int = 1234) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for fig, figdf in df.groupby("figure_id", sort=True):
        channels = sorted(figdf["channel"].unique())
        # Only bootstrap meaningful pairs: chiral vs achiral or opposite chirality.
        for i in range(len(channels)):
            for j in range(i + 1, len(channels)):
                cha, chb = channels[i], channels[j]
                ga = figdf[figdf["channel"] == cha]
                gb = figdf[figdf["channel"] == chb]
                a_type = str(ga["channel_type"].iloc[0])
                b_type = str(gb["channel_type"].iloc[0])
                a_chi = int(ga["chirality_class"].iloc[0])
                b_chi = int(gb["chirality_class"].iloc[0])
                cat = pair_category(a_type, b_type, a_chi, b_chi)
                if cat not in {"chiral_vs_achiral", "enantiomer_pair", "chiral_vs_control"}:
                    continue
                interp = interpolate_pair(ga, gb, n_grid=n_grid)
                if interp is None:
                    continue
                x, ya, yb = interp
                n = len(x)
                win = max(20, int(round(window_frac * n)))
                if win >= n:
                    starts = np.array([0])
                else:
                    starts = rng.integers(0, n - win, size=n_boot)
                contrasts = []
                odd_fracs = []
                signcorrs = []
                for st in starts:
                    sl = slice(int(st), int(st) + win)
                    xx, aa, bb = x[sl], ya[sl], yb[sl]
                    diff = bb - aa
                    even = 0.5 * (bb + aa)
                    odd = 0.5 * (bb - aa)
                    denom_abs = robust_trapz(np.abs(aa), xx) + robust_trapz(np.abs(bb), xx)
                    contrasts.append(robust_trapz(np.abs(diff), xx) / max(denom_abs, 1e-300))
                    op = robust_trapz(odd * odd, xx)
                    ep = robust_trapz(even * even, xx)
                    odd_fracs.append(op / max(op + ep, 1e-300))
                    signcorrs.append(pearson(aa, -bb))
                contrasts = np.asarray(contrasts, dtype=float)
                odd_fracs = np.asarray(odd_fracs, dtype=float)
                signcorrs = np.asarray(signcorrs, dtype=float)
                rows.append({
                    "figure_id": fig,
                    "channel_a": cha,
                    "channel_b": chb,
                    "pair_category": cat,
                    "n_boot": int(len(contrasts)),
                    "contrast_median": float(np.nanmedian(contrasts)),
                    "contrast_q05": float(np.nanquantile(contrasts, 0.05)),
                    "contrast_q95": float(np.nanquantile(contrasts, 0.95)),
                    "odd_fraction_median": float(np.nanmedian(odd_fracs)),
                    "odd_fraction_q05": float(np.nanquantile(odd_fracs, 0.05)),
                    "odd_fraction_q95": float(np.nanquantile(odd_fracs, 0.95)),
                    "signflip_corr_median": float(np.nanmedian(signcorrs)),
                    "signflip_corr_q05": float(np.nanquantile(signcorrs, 0.05)),
                    "signflip_corr_q95": float(np.nanquantile(signcorrs, 0.95)),
                    "robust_contrast_pass": bool(np.nanquantile(contrasts, 0.05) > 0.15),
                    "robust_odd_pass": bool(np.nanquantile(odd_fracs, 0.05) > 0.15),
                })
    return pd.DataFrame(rows)


def build_svd_modes(df: pd.DataFrame, n_grid: int = 1000, max_modes: int = 6) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Return svd_summary, svd_scores, svd_modes.

    Spectra are interpolated to a global magnetic-field grid and normalized by RMS.
    """
    if df.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    xmin = float(df["field_mT"].min())
    xmax = float(df["field_mT"].max())
    grid = np.linspace(xmin, xmax, n_grid)
    spectra = []
    meta = []
    for (fig, ch), g in df.groupby(["figure_id", "channel"], sort=True):
        g = g.sort_values("field_mT")
        x = g["field_mT"].to_numpy(float)
        y = g["signal_bc"].to_numpy(float)
        mask = np.isfinite(x) & np.isfinite(y)
        if mask.sum() < 5:
            continue
        x, y = x[mask], y[mask]
        order = np.argsort(x)
        x, y = x[order], y[order]
        yi = np.interp(grid, x, y, left=0.0, right=0.0)
        rr = rms(yi)
        if np.isfinite(rr) and rr > 0:
            yi = yi / rr
        spectra.append(yi)
        meta.append({
            "figure_id": fig,
            "channel": ch,
            "channel_type": str(g["channel_type"].iloc[0]),
            "chirality_class": int(g["chirality_class"].iloc[0]),
        })
    if len(spectra) < 2:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    X = np.vstack(spectra)
    # Remove channel-wise mean to emphasize shape.
    X = X - X.mean(axis=1, keepdims=True)
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    explained = (S * S) / np.sum(S * S)
    summary = []
    for k in range(min(max_modes, len(S))):
        summary.append({
            "mode": k + 1,
            "singular_value": float(S[k]),
            "explained_variance_fraction": float(explained[k]),
            "cumulative_explained_variance": float(np.sum(explained[: k + 1])),
        })
    score_rows = []
    for i, m in enumerate(meta):
        row = dict(m)
        for k in range(min(max_modes, len(S))):
            row[f"mode_{k+1}_score"] = float(U[i, k] * S[k])
        score_rows.append(row)
    mode_rows = []
    for idx, field in enumerate(grid):
        row = {"field_mT": float(field)}
        for k in range(min(max_modes, len(S))):
            row[f"mode_{k+1}"] = float(Vt[k, idx])
        mode_rows.append(row)
    return pd.DataFrame(summary), pd.DataFrame(score_rows), pd.DataFrame(mode_rows)


def svd_chirality_mode_present(svd_scores: pd.DataFrame) -> bool:
    if svd_scores.empty:
        return False
    mode_cols = [c for c in svd_scores.columns if c.startswith("mode_") and c.endswith("_score")]
    if not mode_cols:
        return False
    # Test whether any mode separates chirality_class +1 and 0 or +1 and -1 by >0.5 pooled sigma.
    for c in mode_cols[:4]:
        groups = []
        for chi in [-1, 0, +1]:
            vals = svd_scores.loc[svd_scores["chirality_class"] == chi, c].to_numpy(float)
            vals = vals[np.isfinite(vals)]
            if len(vals) >= 2:
                groups.append((chi, vals))
        for i in range(len(groups)):
            for j in range(i + 1, len(groups)):
                vi, vj = groups[i][1], groups[j][1]
                pooled = math.sqrt(float(np.var(vi) + np.var(vj)) / 2.0) if len(vi) > 1 and len(vj) > 1 else 0.0
                diff = abs(float(np.mean(vi) - np.mean(vj)))
                if pooled > 0 and diff / pooled > 0.5:
                    return True
                if pooled == 0 and diff > 0:
                    return True
    return False


# -----------------------------------------------------------------------------
# Canon scoring and SST feature bank
# -----------------------------------------------------------------------------
def make_sst_feature_bank(channel_metrics: pd.DataFrame, pair_metrics: pd.DataFrame, bootstrap: pd.DataFrame, svd_scores: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if not pair_metrics.empty:
        for _, r in pair_metrics.iterrows():
            rows.append({
                "feature_family": "pairwise_field_domain",
                "figure_id": r["figure_id"],
                "entity_a": r["channel_a"],
                "entity_b": r["channel_b"],
                "pair_category": r["pair_category"],
                "sst_feature": "field_domain_helicity_proxy",
                "value": r["sst_hspec_proxy"],
                "unit": "dimensionless",
                "sst_interpretation": "normalized spectral contrast; candidate proxy for chirality-odd SST bridge response",
            })
            rows.append({
                "feature_family": "pairwise_field_domain",
                "figure_id": r["figure_id"],
                "entity_a": r["channel_a"],
                "entity_b": r["channel_b"],
                "pair_category": r["pair_category"],
                "sst_feature": "dimensional_helicity_scaled_proxy",
                "value": r["sst_hspec_dimensional_proxy_m4_s2"],
                "unit": "m^4 s^-2",
                "sst_interpretation": "dimensionless spectral proxy multiplied by 2*kappa_SST^2; not an absolute helicity measurement",
            })
            rows.append({
                "feature_family": "pairwise_field_domain",
                "figure_id": r["figure_id"],
                "entity_a": r["channel_a"],
                "entity_b": r["channel_b"],
                "pair_category": r["pair_category"],
                "sst_feature": "odd_fraction_power",
                "value": r["odd_fraction_power"],
                "unit": "dimensionless",
                "sst_interpretation": "fraction of pair spectral power in chirality-odd component",
            })
    if not bootstrap.empty:
        for _, r in bootstrap.iterrows():
            rows.append({
                "feature_family": "bootstrap_field_windows",
                "figure_id": r["figure_id"],
                "entity_a": r["channel_a"],
                "entity_b": r["channel_b"],
                "pair_category": r["pair_category"],
                "sst_feature": "bootstrap_contrast_q05",
                "value": r["contrast_q05"],
                "unit": "dimensionless",
                "sst_interpretation": "5th percentile of spectral contrast under magnetic-field window bootstrap",
            })
    if not svd_scores.empty:
        for _, r in svd_scores.iterrows():
            mode_cols = [c for c in svd_scores.columns if c.startswith("mode_") and c.endswith("_score")]
            for c in mode_cols[:3]:
                rows.append({
                    "feature_family": "svd_global_modes",
                    "figure_id": r["figure_id"],
                    "entity_a": r["channel"],
                    "entity_b": "",
                    "pair_category": r["channel_type"],
                    "sst_feature": c,
                    "value": r[c],
                    "unit": "a.u.",
                    "sst_interpretation": "global normalized spectral mode score; useful for chirality/spectral classifier",
                })
    return pd.DataFrame(rows)


def score_audit(df: pd.DataFrame, channel_metrics: pd.DataFrame, pair_metrics: pd.DataFrame, bootstrap: pd.DataFrame, svd_scores: pd.DataFrame) -> AuditGates:
    files_parsed = int(df["source_file"].nunique()) if not df.empty else 0
    figures_parsed = int(df["figure_id"].nunique()) if not df.empty else 0
    channel_spectra = int(df.groupby(["figure_id", "channel"]).ngroups) if not df.empty else 0
    pairwise_tests = int(len(pair_metrics)) if not pair_metrics.empty else 0

    fig2_enantiomer_data = bool(((df["channel_type"].str.contains("enantiomer", na=False)).any()) and (df["figure_id"].str.contains("Fig2", na=False).any())) if not df.empty else False
    fig4_chiral_control_data = bool((df["figure_id"].str.contains("Fig4", na=False).any()) and set(df["channel_type"].unique()).issuperset({"achiral_control", "chiral_aggregate"})) if not df.empty else False

    chiral_pairs = pair_metrics[pair_metrics["pair_category"] == "chiral_vs_achiral"] if not pair_metrics.empty else pd.DataFrame()
    en_pairs = pair_metrics[pair_metrics["pair_category"] == "enantiomer_pair"] if not pair_metrics.empty else pd.DataFrame()
    robust_chiral_control_contrast = bool((not chiral_pairs.empty) and (chiral_pairs["spectral_contrast_index"].median() > 0.20) and (chiral_pairs["rms_ratio_b_over_a"].replace([np.inf, -np.inf], np.nan).median() > 1.2 or (1 / chiral_pairs["rms_ratio_b_over_a"].replace([0, np.inf, -np.inf], np.nan)).median() > 1.2))
    enantiomer_asymmetry_present = bool((not en_pairs.empty) and (en_pairs["spectral_contrast_index"].median() > 0.05))
    direct_full_spectrum_signflip = bool((not en_pairs.empty) and (en_pairs["signflip_corr"].max() > 0.80) and (en_pairs["best_phase_relation"] == "signflip").any())
    bootstrap_robust = bool((not bootstrap.empty) and (bootstrap["robust_contrast_pass"].mean() >= 0.50))
    svd_chi = svd_chirality_mode_present(svd_scores)
    time_domain_traces_available = False

    score = 0.0
    score += 10.0 if files_parsed >= 8 else min(10.0, files_parsed * 1.25)
    score += 10.0 if figures_parsed >= 8 else min(10.0, figures_parsed * 1.25)
    score += 10.0 if channel_spectra >= 16 else min(10.0, channel_spectra * 0.625)
    score += 12.0 if fig2_enantiomer_data else 0.0
    score += 14.0 if fig4_chiral_control_data else 0.0
    score += 16.0 if robust_chiral_control_contrast else 0.0
    score += 12.0 if enantiomer_asymmetry_present else 0.0
    score += 8.0 if bootstrap_robust else 0.0
    score += 8.0 if svd_chi else 0.0
    # Bonus only; absence is not a failure for spectral candidate.
    score += 0.0 if not direct_full_spectrum_signflip else 4.0
    score = min(100.0, score)

    if score >= 85.0 and fig4_chiral_control_data and robust_chiral_control_contrast:
        status = "SPECTRAL-CISS-CANON-CANDIDATE-DATA"
    elif score >= 65.0:
        status = "SPECTRAL-CISS-RESEARCH-TRACK-PASS"
    else:
        status = "STRICT-SPECTRAL-AUDIT-NEEDS-MORE-DATA"

    return AuditGates(
        files_parsed=files_parsed,
        figures_parsed=figures_parsed,
        channel_spectra=channel_spectra,
        pairwise_tests=pairwise_tests,
        fig2_enantiomer_data=fig2_enantiomer_data,
        fig4_chiral_control_data=fig4_chiral_control_data,
        robust_chiral_control_contrast=robust_chiral_control_contrast,
        enantiomer_asymmetry_present=enantiomer_asymmetry_present,
        direct_full_spectrum_signflip=direct_full_spectrum_signflip,
        bootstrap_robust=bootstrap_robust,
        svd_chirality_mode_present=svd_chi,
        time_domain_traces_available=time_domain_traces_available,
        score=float(score),
        status=status,
    )


# -----------------------------------------------------------------------------
# Plotting
# -----------------------------------------------------------------------------
def plot_overlays(df: pd.DataFrame, outdir: Path) -> None:
    if plt is None:
        return
    for fig, gfig in df.groupby("figure_id", sort=True):
        fig_obj = plt.figure(figsize=(9, 5))
        ax = fig_obj.add_subplot(1, 1, 1)
        for ch, g in gfig.groupby("channel", sort=True):
            g = g.sort_values("field_mT")
            ax.plot(g["field_mT"], g["signal_bc"], label=str(ch), linewidth=1.2)
        ax.set_title(f"v0.5 baseline-corrected spectra — {fig}")
        ax.set_xlabel("Magnetic field B (mT)")
        ax.set_ylabel("Baseline-corrected signal (a.u.)")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.25)
        fig_obj.tight_layout()
        fig_obj.savefig(outdir / f"v05_spectral_overlay_{fig}.png", dpi=180)
        plt.close(fig_obj)


def barplot(df: pd.DataFrame, xcol: str, ycol: str, outpath: Path, title: str, ylabel: str) -> None:
    if plt is None or df.empty or xcol not in df or ycol not in df:
        return
    d = df.copy()
    d["label"] = d[xcol].astype(str)
    fig_obj = plt.figure(figsize=(10, 5))
    ax = fig_obj.add_subplot(1, 1, 1)
    ax.bar(np.arange(len(d)), d[ycol].astype(float))
    ax.set_xticks(np.arange(len(d)))
    ax.set_xticklabels(d["label"], rotation=60, ha="right", fontsize=7)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(True, axis="y", alpha=0.25)
    fig_obj.tight_layout()
    fig_obj.savefig(outpath, dpi=180)
    plt.close(fig_obj)


def plot_pair_metrics(pair_metrics: pd.DataFrame, outdir: Path) -> None:
    if plt is None or pair_metrics.empty:
        return
    d = pair_metrics.copy()
    d["pair_label"] = d["figure_id"].astype(str) + ": " + d["channel_a"].astype(str) + " vs " + d["channel_b"].astype(str)
    d_sig = d[d["pair_category"].isin(["chiral_vs_achiral", "enantiomer_pair", "chiral_vs_control"])].copy()
    if d_sig.empty:
        d_sig = d.copy()
    barplot(d_sig, "pair_label", "spectral_contrast_index", outdir / "v05_pairwise_spectral_contrast_index.png", "v0.5 pairwise spectral contrast", "contrast index")
    barplot(d_sig, "pair_label", "odd_fraction_power", outdir / "v05_pairwise_odd_fraction_power.png", "v0.5 pairwise chirality-odd power fraction", "odd fraction")
    barplot(d_sig, "pair_label", "signflip_corr", outdir / "v05_pairwise_signflip_corr.png", "v0.5 sign-flip correlation", "corr(S_a, -S_b)")


def plot_bootstrap(bootstrap: pd.DataFrame, outdir: Path) -> None:
    if plt is None or bootstrap.empty:
        return
    d = bootstrap.copy()
    d["pair_label"] = d["figure_id"].astype(str) + ": " + d["channel_a"].astype(str) + " vs " + d["channel_b"].astype(str)
    fig_obj = plt.figure(figsize=(10, 5))
    ax = fig_obj.add_subplot(1, 1, 1)
    x = np.arange(len(d))
    med = d["contrast_median"].astype(float).to_numpy()
    lo = d["contrast_q05"].astype(float).to_numpy()
    hi = d["contrast_q95"].astype(float).to_numpy()
    ax.errorbar(x, med, yerr=[med - lo, hi - med], fmt="o", capsize=3)
    ax.set_xticks(x)
    ax.set_xticklabels(d["pair_label"], rotation=60, ha="right", fontsize=7)
    ax.set_title("v0.5 bootstrap over magnetic-field windows")
    ax.set_ylabel("spectral contrast index")
    ax.grid(True, alpha=0.25)
    fig_obj.tight_layout()
    fig_obj.savefig(outdir / "v05_bootstrap_window_contrast.png", dpi=180)
    plt.close(fig_obj)


def plot_svd(svd_summary: pd.DataFrame, svd_modes: pd.DataFrame, outdir: Path) -> None:
    if plt is None or svd_summary.empty:
        return
    fig_obj = plt.figure(figsize=(7, 4))
    ax = fig_obj.add_subplot(1, 1, 1)
    ax.bar(svd_summary["mode"], svd_summary["explained_variance_fraction"])
    ax.set_xlabel("SVD mode")
    ax.set_ylabel("Explained variance fraction")
    ax.set_title("v0.5 global spectral modes")
    ax.grid(True, axis="y", alpha=0.25)
    fig_obj.tight_layout()
    fig_obj.savefig(outdir / "v05_svd_explained_variance.png", dpi=180)
    plt.close(fig_obj)

    if not svd_modes.empty:
        fig_obj = plt.figure(figsize=(9, 5))
        ax = fig_obj.add_subplot(1, 1, 1)
        mode_cols = [c for c in svd_modes.columns if c.startswith("mode_")]
        for c in mode_cols[:4]:
            ax.plot(svd_modes["field_mT"], svd_modes[c], label=c)
        ax.set_xlabel("Magnetic field B (mT)")
        ax.set_ylabel("mode amplitude (a.u.)")
        ax.set_title("v0.5 SVD spectral basis modes")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.25)
        fig_obj.tight_layout()
        fig_obj.savefig(outdir / "v05_svd_basis_modes.png", dpi=180)
        plt.close(fig_obj)


# -----------------------------------------------------------------------------
# Output
# -----------------------------------------------------------------------------
def write_summary(outdir: Path, gates: AuditGates, pair_metrics: pd.DataFrame, bootstrap: pd.DataFrame, svd_summary: pd.DataFrame) -> None:
    lines = []
    lines.append("# SST Contra-Swirl Bridge v0.5 — Spectral EPR/CISS Fusion Audit")
    lines.append("")
    lines.append(f"Status: **{gates.status}**")
    lines.append(f"Score: **{gates.score:.3f}/100**")
    lines.append("")
    lines.append("## Canonical SST constants used")
    lines.append("")
    lines.append(f"- ||v_swirl|| = {V_SWIRL:.8e} m s^-1")
    lines.append(f"- r_c = {R_C:.8e} m")
    lines.append(f"- rho_f = {RHO_F:.8e} kg m^-3")
    lines.append(f"- kappa_SST = 2*pi*r_c*||v_swirl|| = {KAPPA_SST:.8e} m^2 s^-1")
    lines.append(f"- H_unit = 2*kappa_SST^2 = {H_UNIT:.8e} m^4 s^-2")
    lines.append("")
    lines.append("## Gates")
    lines.append("")
    for k, v in asdict(gates).items():
        lines.append(f"- {k}: {v}")
    lines.append("")
    lines.append("## Interpretation")
    lines.append("")
    lines.append("The supplied files are magnetic-field-domain EPR spectra S(B), not time-domain decoherence traces R(t). Therefore v0.5 can strengthen the spectral CISS/SST canon-candidate claim but cannot promote the bridge hypothesis to CANON by itself.")
    lines.append("")
    lines.append("The central field-domain proxy is")
    lines.append("")
    lines.append("```text")
    lines.append("H_spec_tilde = integral |S_b(B)-S_a(B)| dB / [integral |S_a(B)| dB + integral |S_b(B)| dB]")
    lines.append("```")
    lines.append("")
    lines.append("The chirality-odd decomposition for a paired spectral comparison is")
    lines.append("")
    lines.append("```text")
    lines.append("S_odd(B)  = 0.5 * [S_b(B)-S_a(B)]")
    lines.append("S_even(B) = 0.5 * [S_b(B)+S_a(B)]")
    lines.append("f_odd = integral S_odd(B)^2 dB / integral [S_odd(B)^2 + S_even(B)^2] dB")
    lines.append("```")
    lines.append("")
    if not pair_metrics.empty:
        lines.append("## Strongest pairwise contrasts")
        lines.append("")
        top = pair_metrics.sort_values("spectral_contrast_index", ascending=False).head(8)
        for _, r in top.iterrows():
            lines.append(f"- {r['figure_id']}: {r['channel_a']} vs {r['channel_b']} ({r['pair_category']}), contrast={r['spectral_contrast_index']:.6g}, odd_fraction={r['odd_fraction_power']:.6g}")
        lines.append("")
    if not bootstrap.empty:
        lines.append("## Bootstrap robustness")
        lines.append("")
        robust_count = int(bootstrap["robust_contrast_pass"].sum())
        lines.append(f"Robust contrast pass count: {robust_count}/{len(bootstrap)}")
        lines.append("")
    if not svd_summary.empty:
        lines.append("## SVD modes")
        lines.append("")
        for _, r in svd_summary.head(6).iterrows():
            lines.append(f"- mode {int(r['mode'])}: explained variance = {r['explained_variance_fraction']:.6g}, cumulative = {r['cumulative_explained_variance']:.6g}")
        lines.append("")
    lines.append("## Canon policy")
    lines.append("")
    lines.append("- This result may support [SPECTRAL-CISS-CANON-CANDIDATE-DATA].")
    lines.append("- It cannot by itself establish [CANON], because the required time-domain decoherence gate R_chi(t) ~ exp(-Gamma_phi t) is not present in these files.")
    lines.append("- The next required external information is raw or processed time-resolved EPR traces, replicate uncertainties, or figure metadata mapping the spectra to delay times/temperatures/bridge lengths.")
    (outdir / "canon_spectral_fusion_summary.md").write_text("\n".join(lines), encoding="utf-8")


def write_outputs(outdir: Path, df: pd.DataFrame, channel_metrics: pd.DataFrame, pair_metrics: pd.DataFrame, bootstrap: pd.DataFrame, svd_summary: pd.DataFrame, svd_scores: pd.DataFrame, svd_modes: pd.DataFrame, feature_bank: pd.DataFrame, gates: AuditGates, make_plots: bool, make_zip: bool, script_path: Path) -> Optional[Path]:
    ensure_dir(outdir)
    df.to_csv(outdir / "spectral_long_v05.csv", index=False)
    channel_metrics.to_csv(outdir / "channel_metrics_v05.csv", index=False)
    pair_metrics.to_csv(outdir / "pairwise_spectral_metrics_v05.csv", index=False)
    bootstrap.to_csv(outdir / "bootstrap_window_metrics_v05.csv", index=False)
    svd_summary.to_csv(outdir / "svd_summary_v05.csv", index=False)
    svd_scores.to_csv(outdir / "svd_scores_v05.csv", index=False)
    svd_modes.to_csv(outdir / "svd_modes_v05.csv", index=False)
    feature_bank.to_csv(outdir / "sst_feature_bank_v05.csv", index=False)
    pd.DataFrame([asdict(gates)]).to_csv(outdir / "canon_spectral_fusion_gates_v05.csv", index=False)
    (outdir / "audit_result_v05.json").write_text(json.dumps(asdict(gates), indent=2), encoding="utf-8")
    write_summary(outdir, gates, pair_metrics, bootstrap, svd_summary)

    # Compatibility bridge: approximate v0.3 schema without pretending time-domain data.
    v03 = []
    if not pair_metrics.empty:
        for _, r in pair_metrics.iterrows():
            v03.append({
                "molecule_id": f"{r['figure_id']}::{r['channel_a']}_vs_{r['channel_b']}",
                "chirality": int(np.sign(r["chirality_b"] - r["chirality_a"])) if (r["chirality_b"] != r["chirality_a"]) else 0,
                "bridge_length_m": float("nan"),
                "temperature_K": float("nan"),
                "time_s": float("nan"),
                "signal": r["spectral_contrast_index"],
                "signal_uncertainty": float("nan"),
                "method": "EPR_FIELD_DOMAIN_PROXY_NOT_TIME_RESOLVED",
            })
    pd.DataFrame(v03).to_csv(outdir / "v03_proxy_field_domain_not_time_resolved_v05.csv", index=False)

    if make_plots:
        plot_overlays(df, outdir)
        plot_pair_metrics(pair_metrics, outdir)
        plot_bootstrap(bootstrap, outdir)
        plot_svd(svd_summary, svd_modes, outdir)

    zip_path = None
    if make_zip:
        zip_path = outdir.with_suffix(".zip")
        if zip_path.exists():
            zip_path.unlink()
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            # include script
            if script_path.exists():
                zf.write(script_path, arcname=script_path.name)
            for p in sorted(outdir.rglob("*")):
                if p.is_file():
                    zf.write(p, arcname=str(Path(outdir.name) / p.relative_to(outdir)))
    return zip_path


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def run(args: argparse.Namespace) -> Tuple[AuditGates, Optional[Path]]:
    input_dir = Path(args.input_dir).resolve()
    outdir = Path(args.outdir).resolve()
    ensure_dir(outdir)
    files = discover_files(input_dir, args.pattern)
    if not files:
        raise SystemExit(f"No input files found in {input_dir} matching {args.pattern!r} or fallback *Fig*.txt/csv")

    parsed = []
    parse_errors = []
    for p in files:
        try:
            d = parse_file(p)
            if not d.empty:
                parsed.append(d)
            else:
                parse_errors.append({"file": str(p), "error": "empty parse"})
        except Exception as exc:
            parse_errors.append({"file": str(p), "error": repr(exc)})
    if not parsed:
        raise SystemExit(f"No parseable spectra. Errors: {parse_errors}")
    long_df = pd.concat(parsed, ignore_index=True)
    long_df = preprocess_long(long_df, edge_frac=args.edge_frac)

    channel_metrics = compute_channel_metrics(long_df)
    pair_metrics = compute_pairwise_metrics(long_df, n_grid=args.grid_points)
    bootstrap = bootstrap_pair_metrics(long_df, n_boot=args.bootstrap, window_frac=args.window_frac, n_grid=args.grid_points, seed=args.seed)
    svd_summary, svd_scores, svd_modes = build_svd_modes(long_df, n_grid=args.svd_grid, max_modes=args.max_modes)
    feature_bank = make_sst_feature_bank(channel_metrics, pair_metrics, bootstrap, svd_scores)
    gates = score_audit(long_df, channel_metrics, pair_metrics, bootstrap, svd_scores)

    # Parse errors log
    if parse_errors:
        pd.DataFrame(parse_errors).to_csv(outdir / "parse_errors_v05.csv", index=False)

    zip_path = write_outputs(
        outdir=outdir,
        df=long_df,
        channel_metrics=channel_metrics,
        pair_metrics=pair_metrics,
        bootstrap=bootstrap,
        svd_summary=svd_summary,
        svd_scores=svd_scores,
        svd_modes=svd_modes,
        feature_bank=feature_bank,
        gates=gates,
        make_plots=args.plot,
        make_zip=args.zip,
        script_path=Path(__file__).resolve(),
    )
    return gates, zip_path


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="SST v0.5 field-domain spectral EPR/CISS fusion audit")
    p.add_argument("--input-dir", default=".", help="Directory containing CASTLE/Eckvahl Fig*.txt files")
    p.add_argument("--pattern", default="CASTLE-NWU-UNIPR-Eckvahl-Science2023-Fig*.txt", help="Glob pattern for input files")
    p.add_argument("--outdir", default="sst_bridge_v0_5_fusion_audit_results", help="Output directory")
    p.add_argument("--edge-frac", type=float, default=0.12, help="Fraction of spectrum edges used for linear baseline fit")
    p.add_argument("--grid-points", type=int, default=900, help="Interpolation grid points for pairwise metrics")
    p.add_argument("--bootstrap", type=int, default=400, help="Bootstrap samples over magnetic-field windows")
    p.add_argument("--window-frac", type=float, default=0.55, help="Window fraction for bootstrap")
    p.add_argument("--svd-grid", type=int, default=1200, help="Global grid points for SVD mode extraction")
    p.add_argument("--max-modes", type=int, default=6, help="Maximum SVD modes to save")
    p.add_argument("--seed", type=int, default=1234, help="Random seed for bootstrap")
    p.add_argument("--plot", action="store_true", help="Generate PNG plots")
    p.add_argument("--zip", action="store_true", help="Create output zip")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_argparser()
    args = parser.parse_args(argv)
    gates, zip_path = run(args)
    print(json.dumps(asdict(gates), indent=2))
    if zip_path:
        print(f"ZIP: {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
