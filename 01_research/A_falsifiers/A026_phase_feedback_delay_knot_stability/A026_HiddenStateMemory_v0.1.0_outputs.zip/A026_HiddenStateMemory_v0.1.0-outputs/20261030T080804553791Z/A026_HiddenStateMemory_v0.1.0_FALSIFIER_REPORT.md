# A026 - Hidden-State Memory & Backreaction

**Status: DEVELOPMENT_ONLY / PHYSICAL_EULER_UNRESOLVED / SWIRL_CLOCK_NOT_TESTED.**

This standalone sidecar report is not an official Framework v1.1.0 RC2 report.

## 01. Executive scientific verdict

This sidecar checks a narrowly defined question: can hidden conservative modes create observational memory and return energy when only one mode is measured? A synthetic benchmark validates the diagnostic, but does not certify a three-dimensional incompressible Euler field or an intrinsic SST Swirl Clock.

## 02. Research question

At identical currently observed knot state, can the prior observed trajectory improve held-out predictions because omitted background vorticity modes contain physical state information? Is any inferred phase frequency dynamically qualified?

## 03. Existing-family and novelty audit

A026 tests phase-feedback delay and Kelvin transport; A049 tests effective transverse rigidity; A068/A069 address phase clocks. This sidecar adds a matched-current-versus-history prediction comparison. It is not a replacement for, or a new certified version of, these families.

## 04. Sources and provenance

Paper: Muruga, Ginot, Loos and Bechinger (2026), Nature Physics, doi:10.1038/s41567-026-03442-w. Closest project source: A026 v0.2.1 README and A049 v0.4.1 README. Every generated run records its input and code hashes; a new external provider must be independently qualified.

## 05. Physics scope and assumptions

3D incompressible inviscid Euler, no forcing, is the future target. Current executable proof is a two-mode linear, conservative Hamiltonian benchmark with SI-unit positions and a reference mass of 1 kg. No molecular viscosity, stochastic bath, Euler pressure solver or knot topology is represented in the executable benchmark.

## 06. State-space and observables

Observable current features are x(t), xdot(t). History features are x(t-delay), xdot(t-delay). Oracle adds hidden y(t), ydot(t). Prediction target is x(t+horizon). A separate future Euler adapter must export a preregistered geometric scalar q and its true derivative, with independent trial IDs.

## 07. Equations and dimensionality

Benchmark: xddot + omegaK^2*x + g*y=0; yddot + omegaB^2*y + g*x=0. Here [omega]=s^-1, [g]=s^-2. Energy E=m/2*(xdot^2+ydot^2+omegaK^2*x^2+omegaB^2*y^2+2*g*x*y) has units joule. Eliminating y yields a sinusoidal memory kernel, not a viscous constitutive law.

## 08. Null, alternative and preregistered criteria

H0: with coupling g=0, past features do not improve future prediction beyond current position and velocity; upper 95% bootstrap limit on relative root-mean-square error gain must stay below 0.05. H1 synthetic: with g=2 s^-2, lower 95% gain bound must exceed 0.20. Euler science gates require new thresholds registered before exposure.

## 09. Dataset and sampling

Each synthetic sample is one independently seeded complete trajectory, sampled at fixed observation time t=2.1 s, delay 0.65 s and horizon 0.75 s. Training and test are split by complete trajectory. Independent bootstrap resamples test trajectories. Target-only Gaussian measurement noise is included to avoid zero-error ratios.

## 10. Comparison method

Fit ordinary least-squares predictions using train-only standardization: (i) current state, (ii) current plus history, and (iii) full-state oracle. Measure out-of-sample RMSE and improvement 1-RMSE_history/RMSE_current. Bootstrap 400 times on independent test trajectory IDs.

## 11. Verification and negative controls

Check analytic energy invariance, decoupled null, coupled positive, duplicate trial rejection, non-finite rejection and minimum independent sample size. The synthetic positive cannot be used as Euler evidence. Future controls need shuffled history with matched current, stationary-history drift checks, and uncertainty under finite measurement resolution.

## 12. Numerical qualification

For a real 3D Euler conclusion: independent spatial, temporal, finite-core and domain convergence at common final physical time; divergence/momentum, energy/helicity/circulation residuals and knot isotopy checks. A filament regularizer and spectral Gaussian core are not interchangeable. These tests are NOT EXECUTED here.

## 13. Hidden-state test result

The data table and numerical decision ledger appear below. The result qualifies the algebraic numerical method only; it does not prove a background network restores a trefoil or sustains a clock.

```json
{
  "gates": {
    "G0": {
      "status": "PASS",
      "reason": "Exact Hamiltonian energy max relative error 9.088e-16"
    },
    "G1": {
      "status": "PASS",
      "reason": "Decoupled null: gain upper 95% < 0.05"
    },
    "G2": {
      "status": "PASS",
      "reason": "Coupled positive: gain lower 95% > 0.20"
    },
    "G2B": {
      "status": "PASS",
      "reason": "Randomly permuted history must not improve the independent holdout prediction"
    },
    "G3": {
      "status": "PASS",
      "reason": "Full-state oracle closes the hidden-mode information gap in the synthetic linear system"
    },
    "G4": {
      "status": "NOT_EXECUTED",
      "reason": "No 3D Euler model/provider or dynamic background core supplied"
    },
    "G5": {
      "status": "NOT_EXECUTED",
      "reason": "Spatial, time, finite-core and box convergence missing"
    },
    "G6": {
      "status": "NOT_EXECUTED",
      "reason": "Native Euler energy, circulation, helicity, topology not independently measured"
    },
    "G7": {
      "status": "NOT_EXECUTED",
      "reason": "No phase-locked intrinsic clock, no operational tau measurement"
    },
    "G8": {
      "status": "NOT_EXECUTED",
      "reason": "No independently executed scientific 2-of-3 backend parity"
    },
    "G9": {
      "status": "NOT_APPLICABLE",
      "reason": "No reveal targets; no secret labels or fitted SST constants"
    }
  },
  "results": {
    "case_coupled": {
      "n_train": 1050,
      "n_test": 450,
      "rmse_current_m": 0.002932370412817291,
      "rmse_history_m": 0.00018647581150279093,
      "relative_rmse_gain": 0.9364078253253029,
      "ci95_gain": [
        0.9304063719363107,
        0.9418534210118383
      ],
      "diagnostic_history_signal": true,
      "holdout_group": "independent_trajectories",
      "bootstrap_unit": "independent_trajectories",
      "seed": 20261029,
      "rmse_full_state_oracle_m": 0.00018647581150279315
    },
    "case_decoupled": {
      "n_train": 1050,
      "n_test": 450,
      "rmse_current_m": 0.0001866097164276152,
      "rmse_history_m": 0.00018660971642761525,
      "relative_rmse_gain": -2.220446049250313e-16,
      "ci95_gain": [
        -1.9984014443252818e-15,
        1.3350431871117482e-15
      ],
      "diagnostic_history_signal": false,
      "holdout_group": "independent_trajectories",
      "bootstrap_unit": "independent_trajectories",
      "seed": 20261029,
      "rmse_full_state_oracle_m": 0.0001864758115027943
    },
    "case_history_shuffled": {
      "n_train": 1050,
      "n_test": 450,
      "rmse_current_m": 0.002932370412817291,
      "rmse_history_m": 0.002960005171810838,
      "relative_rmse_gain": -0.009424034178205032,
      "ci95_gain": [
        -0.015482940757946406,
        -0.00358404317354904
      ],
      "diagnostic_history_signal": false,
      "holdout_group": "independent_trajectories",
      "bootstrap_unit": "independent_trajectories",
      "seed": 20261029,
      "rmse_full_state_oracle_m": 0.00018647581150279315
    },
    "energy_relmax": 9.088348017962412e-16
  }
}
```

## 14. Swirl Clock test

Absolute time t_abs is the underlying evolution parameter. An operational phase clock requires a stable phase theta and measured Omega=dtheta/dt_abs. Only after demonstrable phase coherence, environmental perturbation controls and full converged dynamics may d tau/dt_abs=Omega/Omega_ref be evaluated. No clock law is inferred in this release.

## 15. Falsifiers, confounders and status

Critical confounders: incomplete observation, noisy current state, remeshing, nonstationary sampling, shared trajectories across splits, numerical stabilization, and unresolved Euler core. Physical statuses remain UNRESOLVED / NOT EXECUTED, even if all synthetic smoke gates PASS.

## 16. Reproduction, outputs and bibliography

Run run_all.cmd TEST followed by run_all.cmd BASIC. Run EULER only with source-audited NPZ independent trajectories. Output produces machine-readable gate ledgers, science report and SHA-256 archive. Citations: Muruga et al. (2026), DOI 10.1038/s41567-026-03442-w; Mori (1965), DOI 10.1143/PTP.33.423; Sagawa & Ueda (2012), DOI 10.1103/PhysRevE.85.021104.
