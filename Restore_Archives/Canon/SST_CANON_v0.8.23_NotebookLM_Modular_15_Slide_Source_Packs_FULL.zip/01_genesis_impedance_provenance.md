# Genesis - impedance, resonance, provenance, and non-circularity

## Slide 1/15 - SST did not begin as a vortex theory

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Earliest route: stored field energy, capacitance, resonance, and quantum jump.
- Vorticity and knots entered later as the formal dynamical language.
- The Canon must preserve this order.

**Single slide message:** Earliest route: stored field energy, capacitance, resonance, and quantum jump.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 2/15 - Notebook and proto-Canon provenance

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Notebook 2012 contains raw resonance and torus intuitions.
- DOC2013-CANON-001 is the first synthesis attempt.
- They establish origin, not automatic correctness.

**Single slide message:** Notebook 2012 contains raw resonance and torus intuitions.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 3/15 - Historical capacitance route

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- E = Q^2/(2 C_cap) gives stored field energy.
- C_cap = epsilon A/D encodes geometric susceptibility.
- v = f lambda connects excitation speed, frequency, and scale.
- E = h f was interpreted as a transition law.

**Single slide message:** E = Q^2/(2 C_cap) gives stored field energy.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 4/15 - Capacitance and impedance are one algebraic route

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- The capacitance expression can be rewritten as an impedance expression.
- That clarifies physics but does not create an independent derivation.
- A second route must come from bound response or topology.

**Single slide message:** The capacitance expression can be rewritten as an impedance expression.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 5/15 - Fine structure as impedance mismatch

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- alpha_SST = kappa_Z Z_link/Z_jump is a theorem target.
- Z_link belongs to free propagation.
- Z_jump belongs to bound transition response.
- Neither may be defined by alpha, e, h, or c.

**Single slide message:** alpha_SST = kappa_Z Z_link/Z_jump is a theorem target.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 6/15 - Non-circularity rule

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Known constants may be used for calibrated consistency tests.
- They may not appear upstream in their own prediction.
- Every major relation needs a dependency entry.

**Single slide message:** Known constants may be used for calibrated consistency tests.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 7/15 - Three valid modes of use

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Symbolic mode keeps primitives symbolic.
- Calibrated mode tests internal closure with current values.
- Prediction mode uses only observables not used in calibration.

**Single slide message:** Symbolic mode keeps primitives symbolic.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 8/15 - Non-circular route to c_T

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Free propagation speed should follow from response coefficients.
- c_T = a_l sqrt(K_l/I_l) in the link-action route.
- c_T = 1/sqrt(epsilon_l mu_l) in the IR response route.

**Single slide message:** Free propagation speed should follow from response coefficients.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 9/15 - Relativity in the origin story

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Early notes linked internal cycles to time and mass.
- Modern SST reconstructs local spacetime with vortex clocks and torsion signals.
- Relative motion changes operational decomposition.

**Single slide message:** Early notes linked internal cycles to time and mass.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 10/15 - KnotPlot as modern provenance

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Bound states need finite-thickness representatives.
- KnotPlot seeds are not final certificates.
- Ridgerunner/contact maps connect intuition to mechanical candidates.

**Single slide message:** Bound states need finite-thickness representatives.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 11/15 - Source authority hierarchy

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- MAIN Canon is normative.
- Research track holds candidates and protocols.
- Notebooks, chats, and generated videos need promotion before Canon use.

**Single slide message:** MAIN Canon is normative.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 12/15 - Extended epistemic labels

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- [ORIGIN] preserves historical intuition.
- [HYPOTHESIS] marks proposals.
- [DERIVED] marks consequences of assumptions.
- [CALIBRATED] and [PREDICTION] must remain distinct.

**Single slide message:** [ORIGIN] preserves historical intuition.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 13/15 - Immediate theorem targets

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Derive Z_link from the link action.
- Derive Z_jump from bound transition response.
- Derive Q0 and J0 without inserting e or h.
- Test monometricity and universal local c_T.

**Single slide message:** Derive Z_link from the link action.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 14/15 - Preregistered falsifiers

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Hidden dependencies on c,h,e,alpha invalidate prediction claims.
- Non-universal link modes threaten monometricity.
- No convergence of bound response defeats the impedance interpretation.

**Single slide message:** Hidden dependencies on c,h,e,alpha invalidate prediction claims.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.

## Slide 15/15 - Genesis closing thesis

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST starts as a classical search for quantum excitation structure.
- Vorticity and knots supply later mechanical language.
- v0.8.23 formalizes both origin and discipline.

**Single slide message:** SST starts as a classical search for quantum excitation structure.

**Source anchors:** Author Origin Note; Genesis; Historical Notebook and Proto-Canon Provenance Register.

**Visual specification:** Timeline plus dependency ledger: notes -> proto-Canon -> link field -> current Canon.

**Do not generate:** Do not turn Genesis into a biography or complete proof.
