@echo off
setlocal
cd /d "%~dp0"
where knotplot.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: knotplot.exe not found on PATH.
  echo Open KnotPlot manually and run: ^< 99_run_all_matrix.kpc
  exit /b 1
)
echo Running KnotPlot 3.1 FULL relaxation matrix...
knotplot.exe -nog < 99_run_all_matrix.kpc > full_matrix_console.log 2>&1
set RC=%ERRORLEVEL%
echo Finished with exit code %RC%.
echo Console log: full_matrix_console.log
exit /b %RC%
