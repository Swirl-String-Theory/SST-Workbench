# SST CANON v0.8.19 architecture patch bundle

Purpose: merge-safe architecture feedback bundle for `SST_CANON-v0.8.19.tex` and `SST_CANON-v0.8.19-research-track.tex`.

Status: EDITORIAL / CANON-ARCHITECTURE PATCH. These patches do not add a new physical lemma, constant, or canonized theorem. They clarify proof order, theorem targets, and falsification discipline.

## New architecture patches

Apply in this order:

1. `new_architecture_patches/0001_main_architecture_guards.patch`
   - Renames `Formal Foundations` to `Formal Calibration Chain and Derived Consequences`.
   - Adds a dependency guard after `sec:foundations`.
   - Adds architecture-overlays to the labeling convention.
   - Adds `Core Axiom Falsification Matrix` in the Consistency Framework.

2. `new_architecture_patches/0002_main_theorem_target_guards.patch`
   - Adds EM bridge-status guard.
   - Adds Euler-to-Maxwell theorem target at the EMG prefactor bridge.
   - Adds `Monometricity Gate for Swirl-Clock Universality` in the main Relational Time section.

3. `new_architecture_patches/0003_main_architecture_audit_appendix.patch`
   - Adds an appendix recording accepted architecture feedback and merge discipline.

4. `new_architecture_patches/0004_research_track_architecture_theorem_routes.patch`
   - Adds research-track proof routes for Euler-to-Maxwell, monometricity/species-cone, and parameter-frozen weak-sector falsifiers.

## Existing user patches copied for convenience

Existing uploaded patches are copied unchanged under `existing_unapplied_patches/`:

- `SST_CANON-v0.8.19-ssdl-research-track.patch`
- `SST_CANON-v0.8.19_chronos_kelvin_hitting_conditions.patch`
- `SST_CANON-v0.8.19_contact-pressure-saturation.patch`
- `SST_CANON-v0.8.19_rank9_contact_channels.patch`

Recommended order with existing patches:

```bash
patch -p2 < new_architecture_patches/0001_main_architecture_guards.patch
patch -p2 < new_architecture_patches/0002_main_theorem_target_guards.patch
patch -p2 < new_architecture_patches/0003_main_architecture_audit_appendix.patch
patch -p2 < new_architecture_patches/0004_research_track_architecture_theorem_routes.patch

# Then apply research-track/local-sector patches.
# For patches with a/ b/ headers use -p1; for /mnt/data or direct filename headers use -p0/-p1 as appropriate.
```

## Patched preview files

The folder also contains preview files with only the four new architecture patches applied:

- `SST_CANON-v0.8.19_architecture-patched-preview.tex`
- `SST_CANON-v0.8.19-research-track_architecture-patched-preview.tex`

These previews do not include SSDL/contact/Chronos/rank9 patches.

## Merge-conflict discipline

This bundle intentionally does not physically move the full Axiomatic Framework section ahead of the calibration chain. A broad section move is the highest-conflict operation. Instead, patch 0001 adds a dependency guard and section-title correction. A true reorder should be done later as a dedicated cleanup branch after all sector patches are applied.


## CRLF-safe copies of existing patches

Because the uploaded `SST_CANON-v0.8.19*.tex` files use CRLF line endings, some older LF-only patches can fail with `different line endings`. For convenience, this bundle includes CRLF/relative-path copies under:

- `existing_unapplied_patches_crlf_relative/`

Use `patch --binary` with these copies. Tested order:

```bash
patch --binary -p0 < new_architecture_patches/0001_main_architecture_guards.patch
patch --binary -p0 < new_architecture_patches/0002_main_theorem_target_guards.patch
patch --binary -p0 < new_architecture_patches/0003_main_architecture_audit_appendix.patch
patch --binary -p0 < new_architecture_patches/0004_research_track_architecture_theorem_routes.patch

patch --binary -p1 < existing_unapplied_patches_crlf_relative/SST_CANON-v0.8.19_chronos_kelvin_hitting_conditions.crlf.patch
patch --binary -p0 < existing_unapplied_patches_crlf_relative/SST_CANON-v0.8.19_contact-pressure-saturation.crlf.patch
patch --binary -p0 < existing_unapplied_patches_crlf_relative/SST_CANON-v0.8.19_rank9_contact_channels.crlf.patch
patch --binary -p0 < existing_unapplied_patches_crlf_relative/SST_CANON-v0.8.19-ssdl-research-track.relative.crlf.patch
```

This sequence was smoke-tested against the uploaded v0.8.19 files. The SSDL patch was path-normalized from `/mnt/data/...` to a relative target so it will not accidentally patch an absolute sandbox path.
