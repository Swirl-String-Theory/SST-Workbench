# Route B BEMv14 certified-length convergence

BEMv14 is the convergence-grid version of BEMv13.

BEMv13 computes:

\[
\alpha^{-1}_{\rm pred,blind}
=
\frac12\left[
N_{\rm soft}V_{\rm soft}L_{\rm cert}
+
\frac{\Delta F_{\rm pair}}{\mathcal N_q}
\right].
\]

BEMv14 checks whether the chosen normalizer \(q\), especially

\[
\mathcal N_q=M_{\max}L_{\rm cert}^2,
\]

remains stable under mesh/tube/outer-boundary refinement.

No observed alpha is used.

## Outputs

```text
certified_convergence_grid.csv
certified_stability_summary.csv
alpha_budget_v14_convergence.csv
certified_convergence_report.md
run_config_v14.json
runs/<run_id>/   # only when BEMv14 launches BEMv13 internally
```

## Reuse existing BEMv13 folders

```bash
python routeB_RT_bem_v14_certified_convergence.py \
  --from-bemv13-outdirs outputs_routeB_BEM_v13_certified \
  --outdir outputs_routeB_BEM_v14_from_v13
```

One folder is diagnostic only and cannot pass the full convergence gate.

## Fast internal grid

```bash
python routeB_RT_bem_v14_certified_convergence.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v14_fast \
  --n-center-list 8,10,12 \
  --n-theta-list 3,3,4 \
  --n-sphere-list 14,18,24 \
  --tube-fraction-list 0.38,0.32,0.28 \
  --outer-factor-list 2.2,2.6,3.0
```

## Larger paired grid

```bash
python routeB_RT_bem_v14_certified_convergence.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v14 \
  --n-center-list 24,32,40,48 \
  --n-theta-list 5,6,7,8 \
  --n-sphere-list 96,144,196,256 \
  --tube-fraction-list 0.35,0.30,0.25,0.20 \
  --outer-factor-list 2.4,2.8,3.2,3.6 \
  --pair-fit-min-M 10
```

## Stability gate

A normalizer passes only if:

```text
n_runs >= min_grid_runs
pass_fraction = 1
alpha_inv_blind_v13_cv_abs <= alpha_cv_threshold
abs_correction_ratio_max <= subleading_threshold
```

Defaults:

```text
min_grid_runs = 3
alpha_cv_threshold = 0.01
subleading_threshold = 0.05
```

This is still a falsifier/provenance gate, not the final derivation.
