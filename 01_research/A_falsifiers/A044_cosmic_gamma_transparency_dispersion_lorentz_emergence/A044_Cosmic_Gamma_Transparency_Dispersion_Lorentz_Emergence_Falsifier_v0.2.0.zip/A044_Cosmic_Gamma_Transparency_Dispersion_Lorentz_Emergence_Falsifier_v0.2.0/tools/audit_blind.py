from pathlib import Path
import sys
FORBIDDEN=("rho_core","rho_f","r_c","v_circlearrow","circlearrowleft","SST_PHOTON_EIGENMODE")
root=Path(sys.argv[1] if len(sys.argv)>1 else "SST_Cosmic_Gamma_Transparency_Dispersion_Lorentz_Emergence_Falsifier_v0.2.0-outputs/blind")
text="\n".join(p.read_text(encoding="utf-8",errors="ignore") for p in root.rglob("*") if p.is_file())
hits=[x for x in FORBIDDEN if x.lower() in text.lower()]
if hits:
    print("BLIND LEAKAGE FAIL",hits); raise SystemExit(2)
print("BLIND LEAKAGE PASS")
