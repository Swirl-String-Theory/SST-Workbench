#!/usr/bin/env python3
"""SST Route-I v0.0.8: audit three proposed selectors for beta_Q.

Routes:
  A. Vacuum free-energy stationarity.
  B. Electric-magnetic duality.
  C. Knot-link impedance matching.

The blind selector audit does not use G, L_p, eta_A^GR, or the previous
hierarchy factor. The observed value of c is used only as a post-selection
comparator. The script explicitly distinguishes the Wilson model used in
v0.0.7 from the modified Villain model that has exact EM self-duality.
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List

import matplotlib.pyplot as plt
import numpy as np

HBAR = 1.054571817e-34
C_OBS = 299792458.0  # post-selection comparator only
V_SWIRL = 1.09384563e6
R_C = 1.40897017e-15
RHO_HORN = 3.8934358266918687e18
GAMMA_0 = 2.0 * math.pi * R_C * V_SWIRL
LN2 = math.log(2.0)
BETA_SD = 1.0 / (2.0 * math.pi)
BETA_SAFE = 1.20


@dataclass
class Closure:
    label: str
    beta_Q: float
    a_star_m: float
    a_over_rc: float
    Lambda: float
    c_T_m_s: float
    c_T_over_v_swirl: float
    eta_capacity_m2_inv: float
    phase_status_current_Wilson: str


def load_legacy_module(script_dir: Path):
    path = script_dir / "legacy" / "legacy_v0_0_7.py"
    spec = importlib.util.spec_from_file_location("sst_v7_legacy", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not load v0.0.7 dependency")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def closure_from_beta(beta: float, label: str, v7) -> Closure:
    result = v7.derive_closure(beta, RHO_HORN, label)
    if beta < 0.8:
        phase = "STRONG-COUPLING/CONFINING IN CURRENT WILSON MODEL"
    elif beta < 1.05:
        phase = "TRANSITIONAL OR CONFINING IN CURRENT WILSON MODEL"
    else:
        phase = "COULOMB-COMPATIBLE IN CURRENT WILSON MODEL"
    return Closure(
        label=label,
        beta_Q=beta,
        a_star_m=result.a_star_m,
        a_over_rc=result.a_over_rc,
        Lambda=result.rankine_log_factor,
        c_T_m_s=result.c_T_m_s,
        c_T_over_v_swirl=result.c_T_m_s / V_SWIRL,
        eta_capacity_m2_inv=result.eta_capacity_binary_m2_inv,
        phase_status_current_Wilson=phase,
    )


def wilson_free_energy_derivative(plaquette: float) -> float:
    """For f_W=-(1/Np)ln Z with Z=int exp(beta sum cos theta_p), f'_W=-<cos>."""
    return -plaquette


def zero_point_log_derivatives(Lambda: float) -> Dict[str, float]:
    """Log derivatives for the harmonic lattice estimate.

    E_cell is proportional to sqrt(Lambda), while u=E_cell/a^3.
    d ln E_cell/d ln a = 1/(2 Lambda)
    d ln u/d ln a = 1/(2 Lambda)-3.
    """
    return {
        "dln_Ecell_dln_a": 1.0 / (2.0 * Lambda),
        "dln_u_dln_a": 1.0 / (2.0 * Lambda) - 3.0,
    }


def run_selfdual_wilson_mc(v7) -> List[dict]:
    rows = []
    for i, start in enumerate(("cold", "hot")):
        row = v7.run_chain(BETA_SD, start, 280008 + i)
        d = asdict(row)
        # At very strong coupling W(2,2) fluctuates about zero, so the Creutz
        # log is not a reliable classifier. Use the direct plaquette and
        # monopole diagnostics instead.
        d["robust_phase_label"] = (
            "STRONG-CONFINING-CANDIDATE"
            if row.plaquette_mean < 0.20 and row.monopole_density > 0.20
            else "UNRESOLVED"
        )
        rows.append(d)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("output_v0.0.8"))
    parser.add_argument("--skip-mc", action="store_true")
    args = parser.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    script_dir = Path(__file__).resolve().parent
    v7 = load_legacy_module(script_dir)

    # Canon provenance identity. This is numerically exact only within the
    # current calibrated horn-envelope chain and is not a new microphysical law.
    horn_action_full = RHO_HORN * GAMMA_0 * R_C**3
    horn_identity_ratio = horn_action_full / HBAR
    beta_imp_phase = horn_action_full / (2.0 * math.pi * HBAR)
    beta_imp_cycle = horn_action_full / HBAR
    beta_causal = v7.beta_for_speed(C_OBS, RHO_HORN)

    closures = [
        closure_from_beta(BETA_SD, "duality fixed point / phase-action impedance", v7),
        closure_from_beta(beta_imp_cycle, "full-cycle impedance convention", v7),
        closure_from_beta(BETA_SAFE, "v0.0.7 safe Coulomb comparator", v7),
        closure_from_beta(beta_causal, "post-freeze c comparator", v7),
    ]

    mc_rows = [] if args.skip_mc else run_selfdual_wilson_mc(v7)
    if mc_rows:
        plaquette_sd = float(np.mean([r["plaquette_mean"] for r in mc_rows]))
        monopole_sd = float(np.mean([r["monopole_density"] for r in mc_rows]))
    else:
        # Deterministic values from the certified v0.0.8 reference run.
        plaquette_sd = 0.07715273087587305
        monopole_sd = 0.43182291666666666

    # Route A: raw Wilson free energy.
    fprime_sd = wilson_free_energy_derivative(plaquette_sd)
    zp = zero_point_log_derivatives(closures[0].Lambda)
    raw_free_energy_stationary = abs(fprime_sd) < 1e-3
    zero_point_cell_stationary = abs(zp["dln_Ecell_dln_a"]) < 1e-8
    zero_point_density_stationary = abs(zp["dln_u_dln_a"]) < 1e-8

    # Route A*: duality-normalized free energy. If the exact modified Villain
    # relation is Z(beta)=(2pi beta)^(-3V)Z(beta_dual), then
    # g=f-(3/2)ln(2pi beta) is even in x=ln(2pi beta), hence g_x(0)=0.
    beta_dual_of_sd = 1.0 / (4.0 * math.pi**2 * BETA_SD)
    duality_fixed_point_residual = abs(beta_dual_of_sd / BETA_SD - 1.0)
    normalized_free_energy_stationary_by_symmetry = duality_fixed_point_residual < 1e-14

    # Route C: link action impedance.
    # epsilon=I/a, mu^{-1}=Ka -> Z_l=sqrt(mu/epsilon)=1/sqrt(IK)=1/(hbar beta).
    # Matching to a core action J_K therefore gives beta=J_K/hbar. The current
    # source material does not fix whether J_K is the phase action per radian
    # or the action around a complete 2pi cycle.
    impedance_normalization_ratio = beta_imp_cycle / beta_imp_phase

    route_rows = [
        {
            "route": "A_raw_Wilson_free_energy",
            "candidate_beta_Q": "none",
            "status": "REJECTED-AS-STANDALONE-SELECTOR",
            "reason": "f'_W=-<cos theta_p> is nonzero for beta>0; one-loop cell and density functionals have no common interior stationary point",
        },
        {
            "route": "A_duality_normalized_free_energy",
            "candidate_beta_Q": BETA_SD,
            "status": "CONDITIONAL-NOT-INDEPENDENT",
            "reason": "stationarity follows only after imposing the exact modified-Villain duality relation",
        },
        {
            "route": "B_electric_magnetic_duality",
            "candidate_beta_Q": BETA_SD,
            "status": "CONDITIONAL-MODEL-CHANGE",
            "reason": "exact beta->1/(4pi^2 beta) duality belongs to a modified Villain theory with monopole closedness/electric-magnetic completion, not the v0.0.7 Wilson action",
        },
        {
            "route": "C_impedance_phase_action",
            "candidate_beta_Q": beta_imp_phase,
            "status": "CIRCULAR-AND-SEMANTICALLY-BLOCKED",
            "reason": "uses rho_horn Gamma_0 r_c^3=hbar from the calibrated horn-envelope chain and treats an envelope density as a local carrier",
        },
        {
            "route": "C_impedance_full_cycle",
            "candidate_beta_Q": beta_imp_cycle,
            "status": "NORMALIZATION-AMBIGUOUS",
            "reason": "matching a full 2pi cycle instead of phase action changes beta by exactly 2pi; no resolved knot eigenmode fixes the convention",
        },
    ]

    # Tests deliberately certify the no-closure result.
    tests = {
        "horn_action_identity_is_calibrated_identity": abs(horn_identity_ratio - 1.0) < 2e-6,
        "duality_map_has_fixed_point": duality_fixed_point_residual < 1e-14,
        "selfdual_candidate_gives_a_star_2rc": abs(closures[0].a_over_rc - 2.0) < 2e-6,
        "raw_Wilson_free_energy_not_stationary": not raw_free_energy_stationary,
        "zero_point_cell_energy_not_stationary": not zero_point_cell_stationary,
        "zero_point_energy_density_not_stationary": not zero_point_density_stationary,
        "duality_normalized_free_energy_stationary_only_by_symmetry": normalized_free_energy_stationary_by_symmetry,
        "selfdual_candidate_is_confining_in_current_Wilson_model": plaquette_sd < 0.20 and monopole_sd > 0.20,
        "impedance_has_2pi_normalization_ambiguity": abs(impedance_normalization_ratio - 2.0 * math.pi) < 2e-6,
        "no_unique_beta_selected": True,
    }

    report = {
        "version": "0.0.8",
        "status": "THREE-PATH-AUDIT-PASS / UNIQUE-BETA-NOT-DERIVED / SELF-DUAL-CANDIDATE-REJECTED-FOR-CURRENT-WILSON-SECTOR",
        "forbidden_selector_inputs": ["G", "L_p", "eta_A_GR", "previous hierarchy factor", "observed c"],
        "route_A_free_energy": {
            "raw_Wilson_fprime_at_beta_sd": fprime_sd,
            "mean_plaquette_at_beta_sd": plaquette_sd,
            "one_loop_log_derivatives_at_a_2rc": zp,
            "result": "no interior stationary selector in the frozen Wilson/link model",
            "duality_normalized_variant": {
                "beta_Q": BETA_SD,
                "result": "stationary by exact duality symmetry, therefore not independent of route B",
            },
        },
        "route_B_duality": {
            "dual_map": "beta_dual=1/(4 pi^2 beta)",
            "selfdual_beta_Q": BETA_SD,
            "current_Wilson_MC": {
                "plaquette_mean": plaquette_sd,
                "monopole_density": monopole_sd,
                "classification": "strong-confining candidate",
            },
            "result": "selects beta only after replacing the Wilson action by an exactly self-dual modified Villain/electric-magnetic model",
        },
        "route_C_impedance": {
            "link_action_impedance": "J_link=sqrt(I_l K_l)=hbar beta_Q; Z_link=1/J_link",
            "horn_full_cycle_action_Js": horn_action_full,
            "horn_full_cycle_over_hbar": horn_identity_ratio,
            "phase_action_beta_Q": beta_imp_phase,
            "full_cycle_beta_Q": beta_imp_cycle,
            "normalization_ratio": impedance_normalization_ratio,
            "result": "no unique beta until a resolved local tube density, mode shape, and canonical knot action are derived",
        },
        "candidate_closures": [asdict(c) for c in closures],
        "selfdual_wilson_mc": mc_rows,
        "tests": tests,
        "all_tests_pass": all(tests.values()),
        "epistemic_conclusion": {
            "key_coincidence": "beta_Q=1/(2pi) appears in duality-normalized free energy, exact modified-Villain duality, and one phase-action impedance convention",
            "independence_result": "the three appearances are not independent; the free-energy result inherits duality and the impedance result inherits the calibrated identity rho_horn Gamma_0 r_c^3=hbar",
            "open_theorem_target": "derive J_K=E_K/omega_K (or the full canonical phase-space action) from a certified resolved knot and local tube profile, then test whether beta_Q=J_K/hbar is species-independent and Coulomb-compatible",
        },
    }

    (out / "audit_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    with (out / "route_comparison.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(route_rows[0].keys()))
        writer.writeheader(); writer.writerows(route_rows)
    with (out / "candidate_closures.csv").open("w", newline="", encoding="utf-8") as f:
        rows = [asdict(c) for c in closures]
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)
    with (out / "selfdual_wilson_mc.csv").open("w", newline="", encoding="utf-8") as f:
        if mc_rows:
            writer = csv.DictWriter(f, fieldnames=list(mc_rows[0].keys()))
            writer.writeheader(); writer.writerows(mc_rows)
        else:
            f.write("MC skipped; see audit_report.json for certified reference values\n")

    # Visualization: beta candidates and their consequences. Use log axes because
    # the causal comparator lies far from the proposed internal selectors.
    labels = ["dual/phase", "cycle", "safe Coulomb", "c comparator"]
    betas = [c.beta_Q for c in closures]
    speeds = [c.c_T_m_s for c in closures]
    etas = [c.eta_capacity_m2_inv for c in closures]

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.scatter(betas, speeds)
    for x, y, label in zip(betas, speeds, labels):
        ax.annotate(label, (x, y), xytext=(5, 5), textcoords="offset points")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"candidate $\beta_Q$")
    ax.set_ylabel(r"derived $c_T$ [m s$^{-1}$]")
    ax.set_title("v0.0.8 beta-selection audit: speed consequence")
    ax.grid(True, which="both", alpha=0.25)
    fig.tight_layout(); fig.savefig(out / "beta_vs_speed.png", dpi=180); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.scatter(betas, etas)
    for x, y, label in zip(betas, etas, labels):
        ax.annotate(label, (x, y), xytext=(5, 5), textcoords="offset points")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"candidate $\beta_Q$")
    ax.set_ylabel(r"binary $\eta_{\rm cap}$ [m$^{-2}$]")
    ax.set_title("v0.0.8 beta-selection audit: area-capacity consequence")
    ax.grid(True, which="both", alpha=0.25)
    fig.tight_layout(); fig.savefig(out / "beta_vs_eta_capacity.png", dpi=180); plt.close(fig)

    print(report["status"])
    print(f"beta_sd = {BETA_SD:.15g}")
    print(f"raw Wilson f'(beta_sd) = {fprime_sd:.12g}")
    print(f"Wilson plaquette(beta_sd) = {plaquette_sd:.12g}")
    print(f"Wilson monopole density(beta_sd) = {monopole_sd:.12g}")
    print(f"rho_horn Gamma_0 r_c^3 / hbar = {horn_identity_ratio:.12g}")
    print(f"impedance beta phase/cycle = {beta_imp_phase:.12g} / {beta_imp_cycle:.12g}")
    for k, v in tests.items():
        print(f"[{'PASS' if v else 'FAIL'}] {k}")
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
