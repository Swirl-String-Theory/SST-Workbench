from __future__ import annotations
from pathlib import Path
import json,shutil

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/"campaign_config.json").read_text(encoding="utf-8"))
RES=ROOT/"seeds/resolved_manifest.json"

def yn(v): return "on" if v else "off"

def relax_lines():
    r=CFG["relaxation"]
    return [
        f"mode {r['mode']}",
        "centre",
        f"fitto mindist {CFG['fitto_mindist']}",
        f"collision {r['collision']}",
        f"close = {r['close']}",
        f"max-dr = {r['max-dr']}",
        f"mechforce = {yn(r['mechforce'])}",
        f"elecforce = {yn(r['elecforce'])}",
        f"bendforce = {yn(r['bendforce'])}",
        f"charge {r['charge']}",
        f"hooke {r['hooke']}",
        f"power {r['power']}",
        f"timeincr {r['timeincr']}",
        f"bencon = {r['bencon']}",
        f"stusplit = {r['stusplit']}",
        f"dstep = {r['dstep']}",
        f"bradius = {r['bradius']}",
        f"cradius = {r['cradius']}",
        f"energy model {r['energy_model']}",
    ]

def checkpoint(cid,it):
    tag=f"i{it:05d}"
    out="__CAMPAIGN_ROOT__/out"
    lines=[
        "centre","energy","writhe","length","rog",
        f"save {out}/{cid}_{tag}.k float",
        f"coords {out}/{cid}_{tag}.txt",
    ]
    if it in (0,10000):
        lines += ["safe","dowker","alex -1"]
    return lines

def main():
    if not RES.is_file():
        raise SystemExit("ERROR: seeds/resolved_manifest.json missing; run run_10_generate_seeds.cmd first.")
    d=json.loads(RES.read_text(encoding="utf-8"))
    rows=[r for r in d["seeds"] if r["safety_pass"]]
    kd=ROOT/"kpc/full"
    if kd.exists(): shutil.rmtree(kd)
    kd.mkdir(parents=True)
    index=[]
    for row in rows:
        cid=f"{row['seed_id']}_{row['family']}"
        lines=[
            "% AUTO-GENERATED Trefoil Seed Campaign v0.1.0",
            f"% candidate={cid}",
            "reset all",
            f"load __CAMPAIGN_ROOT__/seeds/{row['file']}",
            *relax_lines(),
            *checkpoint(cid,0),
            "ago 1000",
            *checkpoint(cid,1000),
            "ago 3000",
            *checkpoint(cid,4000),
            "ago 6000",
            *checkpoint(cid,10000),
            "stop",
        ]
        p=kd/f"{cid}.kpc"
        p.write_text("\n".join(lines)+"\n",encoding="utf-8",newline="\n")
        index.append({"candidate":cid,"script":str(p.relative_to(ROOT)),"seed_file":row["file"]})
    (kd/"index.json").write_text(json.dumps(index,indent=2)+"\n",encoding="utf-8")
    print(f"[KPC] generated {len(index)} full relaxation scripts")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
