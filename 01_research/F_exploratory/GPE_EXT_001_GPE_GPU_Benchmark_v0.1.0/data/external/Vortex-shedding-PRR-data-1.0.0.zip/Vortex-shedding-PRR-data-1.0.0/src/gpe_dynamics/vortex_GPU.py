import numpy as np
from variable import *  
from scipy.signal import argrelmin
from scipy import spatial
import cupy as cp

# w=int(30//dx)
wx=wx//dx-3
wy=wy//dy-3
# w=40

# def vortex_check(Phase,V0,sigma):
    
#     obstacle_idx = int(obstacle_position*Nx/2/R_x+Nx//2)
#     target_idx = int(R_thomas*Nx/2/R_x)
#     temp = Phase[Ny//2][:obstacle_idx-target_idx-5]
#     temp = np.diff(temp[::2])
#     discon_idx = np.where(np.abs(temp)>=1.5*np.pi)

#     return discon_idx[0]

def vortex_detect(density,phase,V0,sigma):
    if V0>1:
        R_thomas = 5//dx+sigma*np.sqrt(np.log(V0)/2)
    else:
        R_thomas = 5//dx
    obst_x = int(obstacle_position*Nx/2/R_x+Nx//2)
    obst_y = Ny//2
    minimas = argrelmin(density)
    X,Y=minimas[1],minimas[0]
    true_vortex=[]
    temp = []

    for i in range(len(X)):
        if density[Y[i],X[i]]<0.2:
            if (X[i]-obst_x)**2+(Y[i]-obst_y)**2>R_thomas**2:
                # if X[i]<=wx+5 or X[i]>=Nx-wx-5 or Y[i]<=wy+5 or Y[i]>=Ny-wy-5:
                temp.append([Y[i],X[i]])

    temp = np.array(temp)
    
    
    if len(temp)==0:
        return []
    else:
        overlap_len=1000000000
        count = 0
        while True:
            if len(temp)<=count:
                break
            distance,index = spatial.KDTree(temp).query(temp[count],k=10)
            distance,index = distance[1:],index[1:]
            overlap_idx = index[np.where(distance<=int(3//dx))]
            overlap_len = len(overlap_idx)
            temp = np.delete(temp,overlap_idx,axis=0)
            count+=1
            



        X_,Y_ = np.array(temp)[:,1],np.array(temp)[:,0]


        vortex_=[]
        for i in range(len(X_)):
    
            X,Y = X_[i],Y_[i]
            l = int(2//dx)
            if X+int(2//dx)>=Nx-int(2//dx) or Y+int(2//dx)>=Ny-int(2//dx):
                continue
            else:   
                x_list = list(range(X-l,X+l+1)) + [X+l]*(2*l-1) + list(range(X-l,X+l+1))[::-1] + [X-l]*(2*l-1)
                y_list = [Y+l]*(2*l+1) + list(range(Y-l+1,Y+l))[::-1] + [Y-l]*(2*l+1) + list(range(Y-l+1,Y+l))
                integral = 0
                for k in range(len(x_list)-1):
                    if np.abs(np.angle(np.exp(1j*(phase[y_list[k+1],x_list[k+1]] - phase[y_list[k],x_list[k]]))))>=0.3*np.pi:
                        integral +=0
                    else:
                        integral = integral +  np.angle(np.exp(1j*(phase[y_list[k+1],x_list[k+1]] - phase[y_list[k],x_list[k]])))
                integral = integral + np.angle(np.exp(1j*(phase[y_list[0],x_list[0]] - phase[y_list[-1],x_list[-1]])))
                
                if (integral)>0.9*np.pi:
                    vortex_.append([X,Y,1])
                elif integral<-0.9*np.pi:
                    vortex_.append([X,Y,-1])


        return np.array(vortex_)


def phase_mask(plus_coord,minus_coord,iteration):
    x = np.linspace(0,2*np.pi,Nx)
    y = np.linspace(0,2*np.pi,Ny)
    xx,yy = np.meshgrid(x,y)
    xx_gpu = cp.array(xx)
    yy_gpu = cp.array(yy)

    
    ## plus_coord or minus_coord is aligned as the real coord order(x,y)

    plus_coord0 = [plus_coord[0]/Nx*2*np.pi,plus_coord[1]/Ny*2*np.pi]
    minus_coord0 = [minus_coord[0]/Nx*2*np.pi, minus_coord[1]/Ny*2*np.pi]
    
    # print(plus_coord0,minus_coord0)

    X_plus = xx - plus_coord0[0] 
    Y_plus = yy - plus_coord0[1]
    X_minus = xx - minus_coord0[0]
    Y_minus = yy - minus_coord0[1]
    
    result = np.zeros((Ny,Nx))
    for n in range(-iteration,iteration+1):
        result += np.arctan(np.tanh((Y_minus+2*np.pi*n)/2)*np.tan((X_minus-np.pi)/2))
        result -= np.arctan(np.tanh((Y_plus+2*np.pi*n)/2)*np.tan((X_plus-np.pi)/2))
        result += np.pi*(np.heaviside(X_plus,0) - np.heaviside(X_minus,0))
    result-=(plus_coord0[0]-minus_coord0[0])/2/np.pi*yy
    result -= xx*np.heaviside(np.abs(plus_coord0[1]-minus_coord0[1])-np.pi,0)
    result += yy*np.heaviside(np.abs(plus_coord0[0]-minus_coord0[0])-np.pi,0)
    result -= np.pi*np.heaviside(np.abs(plus_coord0[0]-minus_coord0[0])-np.pi,0)
    
    return cp.array(result)

def vortex_unwinder(time_evol_class, vortex_pos_list, r):
    unwind_number = 0
    if len(vortex_pos_list) == 0:
        return 0

    iter = 5
    vortex_pos_temp = []

    # counter the vortices near the boundary
    for temp in vortex_pos_list:
        if temp[1] < wy//2 or temp[1] > Ny - wy//2 or temp[0] < wx//2 or temp[0] > Nx - wx//2:
            vortex_pos_temp.append(temp)

    vortex_pos = np.array(vortex_pos_temp)
    if len(vortex_pos) == 0:
        return 0

    vortex_p = vortex_pos[vortex_pos[:, 2] == 1]
    vortex_m = vortex_pos[vortex_pos[:, 2] == -1]

    # sorting
    vortex_m = np.array(sorted(vortex_m, key=lambda k: (k[0] - (Nx - wx//2)) % Nx))
    vortex_p = np.array(sorted(vortex_p, key=lambda k: (k[0] - (Nx - wx//2)) % Nx))

    phase_sum = cp.zeros_like(time_evol_class.psi.real)  # float array, shape = psi

    count = 0
    while vortex_p.size > 0 and vortex_m.size > 0 and count < 20:

        if (vortex_p[0, 0] - (Nx - wx//2)) % Nx <= (vortex_m[0, 0] - (Nx - wx//2)) % Nx:

            distance, index = spatial.KDTree(vortex_m[:, :2]).query(vortex_p[0, :2], k=2)
            distance, index = distance[0], index[0]
            if distance < r:
                if vortex_p[0, 0] > Nx - wx//2:
                    count += 1
                    continue
                else:
                    phase_sum += (-1.0) * phase_mask(vortex_m[index, :2], vortex_p[0, :2], iter)
                    unwind_number += 2
                    vortex_p = np.delete(vortex_p, [0], axis=0)
                    vortex_m = np.delete(vortex_m, [index], axis=0)
            else:
                count += 1
                continue
        else:

            distance, index = spatial.KDTree(vortex_p[:, :2]).query(vortex_m[0, :2], k=2)
            distance, index = distance[0], index[0]
            if distance < r:
                if vortex_m[0, 0] > Nx - wx//2:
                    count += 1
                    continue
                else:
                    phase_sum += (-1.0) * phase_mask(vortex_m[0, :2], vortex_p[index, :2], iter)
                    unwind_number += 2
                    vortex_p = np.delete(vortex_p, [index], axis=0)
                    vortex_m = np.delete(vortex_m, [0], axis=0)
            else:
                count += 1
                continue
        count += 1


    if vortex_p.size != 0:
        temp_p = vortex_p[np.where(vortex_p[:, 0] > Nx - wx//2)]
        if temp_p.size != 0:
            len1, len2 = 10001, 10000
            while len1 > len2 and len2 > 0:
                len1 = len2
                # exp(+1j * phase_mask(plus, [wx, y]))
                phase_sum += (1.0) * phase_mask(temp_p[0, :2],[wx//2, temp_p[0, 1]], iter)
                temp_p = np.delete(temp_p, [0], axis=0)
                len2 = len(temp_p)

    if vortex_m.size != 0:
        temp_m = vortex_m[np.where(vortex_m[:, 0] > Nx - wx//2)]
        if temp_m.size != 0:
            len1, len2 = 10001, 10000
            while len1 > len2 and len2 > 0:
                len1 = len2
                # exp(+1j * phase_mask([wx, y], minus))
                phase_sum += (-1.0) * phase_mask(temp_m[0, :2],[wx//2, temp_m[0, 1]],iter)
                temp_m = np.delete(temp_m, [0], axis=0)
                len2 = len(temp_m)

    time_evol_class.psi *= cp.exp(1j * phase_sum)

    return unwind_number

        