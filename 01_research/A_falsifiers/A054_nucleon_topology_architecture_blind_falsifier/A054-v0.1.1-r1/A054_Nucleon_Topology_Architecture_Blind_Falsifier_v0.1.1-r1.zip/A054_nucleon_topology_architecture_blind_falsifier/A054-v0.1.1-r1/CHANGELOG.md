# Changelog

## v0.1.1-r1 — 2026-10-06

- Hotfix only: robust canonical/marker-based E010/E011 discovery.
- `run_all.cmd` now requires `PREPARED_FULL` and stops before a partial control campaign can be mistaken for the full factorial tournament.
- Added `run_controls.cmd` for intentionally running only diagnostic analytic controls.
- UPSTREAM_PLAN records resolved E010/E011 paths relative to the Workbench root.
- No scientific thresholds, factor levels, polarity gates, or physics operators changed.

## v0.1.1 — 2026-10-06

- Full-factorial skeleton × binary twist-knot × polarity design.
- Prospective two-normalization polarity gate.
- Complete 5_2/6_1 assignment cube and provider-stratum envelope.
- Mutual-energy separation response diagnostics.
- Constant-final-time spatial dynamics convergence and extended temporal refinement.
- Independent C++/NumPy backend qualification.
- Stronger blind seal and semantics.

## v0.1.0

- Initial blind nucleon topology architecture tournament.
