Reference quick native run. Scientific conclusions must use the full resolution ladder, not this quick campaign.
