@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo KnotPlot Missing-Parameter Certification v0.2.0
echo ============================================================
call run_00_certify.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call run_10_analyze_certification.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call run_20_extended_certified.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call run_30_analyze_extended.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call run_90_pack_outputs.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
echo ============================================================
echo DONE
echo See analysis\CERTIFICATION.md and analysis\EXTENDED.md
echo ============================================================
exit /b 0
