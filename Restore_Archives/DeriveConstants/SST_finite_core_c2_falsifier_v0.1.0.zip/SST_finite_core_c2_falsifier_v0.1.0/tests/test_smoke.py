from pathlib import Path
import yaml

from finite_core_falsifier.model import derive_coefficients
from finite_core_falsifier.provenance import scan_text_files


def test_blind_derivation_smoke():
    root = Path(__file__).resolve().parents[1]
    cfg_path = root / "config" / "reference.yaml"
    cfg = yaml.safe_load(cfg_path.read_text())
    cfg["profile"]["n_grid"] = 64
    result = derive_coefficients(cfg, cfg_path.parent)
    assert result["profile"]["success"]
    assert result["closure"]["sigma"] > 0
    assert result["closure"]["c2"] > 0


def test_target_leakage_scanner():
    root = Path(__file__).resolve().parents[1]
    paths = [root / "derive_blind.py", root / "finite_core_falsifier" / "model.py", root / "config" / "reference.yaml"]
    assert scan_text_files(paths) == []
