#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SST chi-phase package v7: legacy vortex-ring alpha/beta target comparator.

v7 is the follow-up to v6. It does not recalc v6 only. It compares the v6
smooth-matched closure root a0* against old vortex-ring constants, especially
NLS alpha=1.61,beta=0.61 from the legacy note.

Epistemic status:
- v7 does not derive alpha_eff,beta_eff from a vortex-ring energy calculation.
- It is a target comparator and roadmap filter.
- The output is useful for deciding whether the v6 root is close to historical
  NLS/ring constants and what still needs a real ring-energy derivation.
"""
from __future__ import annotations

import argparse
import csv
import math
import os
import time
from typing import Dict, List

import matplotlib.pyplot as plt
import numpy as np

from sst_chi_phase_v7_py import (
    A0_STAR,
    PHI,
    NLS_ALPHA,
    NLS_BETA,
    bisection_root,
    c_over_v_smooth,
    c2_over_v2_smooth,
    evaluate_at_a0,
    legacy_rows,
    nearest_targets,
    smooth_matched_poly,
    special_points,
    sweep_a0,
)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
EXPORT_DIR = os.path.join(SCRIPT_DIR, "exports")
os.makedirs(EXPORT_DIR, exist_ok=True)

C = 2.99792458e8
ALPHA = 7.2973525693e-3
M_E = 9.1093837015e-31
HBAR = 1.054571817e-34
RHO_F = 7.0e-7
V_SWIRL = ALPHA * C / 2.0
OMEGA_C = (M_E * C**2) / HBAR
R_C = V_SWIRL / OMEGA_C


def try_cpp_backend(force_python: bool = False):
    if force_python:
        return None, "python-forced"
    try:
        from sst_chi_phase_v7_build import import_module
        return import_module(auto_build=True, script_dir=SCRIPT_DIR), "cpp"
    except Exception as exc:
        print(f"[!] C++ backend unavailable ({exc}). Using pure Python backend.")
        return None, "python-fallback"


def write_csv(path: str, rows: List[Dict[str, object]]):
    if not rows:
        return
    keys = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
    print(f"[*] CSV saved: {path}")


def plot_root_and_targets(sweep_rows, legacy):
    a = np.array([r["a0"] for r in sweep_rows], dtype=float)
    c = np.array([r["c_over_v"] for r in sweep_rows], dtype=float)

    plt.figure(figsize=(11, 6))
    plt.plot(a, c, label=r"smooth-matched $c_\chi/v_{\rm ref}$")
    plt.axhline(1.0, color="k", linestyle="--", label=r"closure target $c/v=1$")
    plt.axvline(A0_STAR, color="r", linestyle="-", label=rf"$a_0^\star={A0_STAR:.6f}$")
    plt.axvline(PHI, color="g", linestyle=":", label=rf"$\varphi={PHI:.6f}$")
    plt.axvline(NLS_ALPHA, color="m", linestyle="-.", label=rf"NLS $\alpha={NLS_ALPHA:.3f}$")
    for row in legacy:
        alpha = float(row["alpha"])
        if row["key"] not in {"nls_legacy"}:
            plt.axvline(alpha, color="0.65", linestyle=":", alpha=0.7)
    plt.xlabel(r"$a_0$ used as smooth-matched shape parameter")
    plt.ylabel(r"$c_\chi/v_{\rm ref}$")
    plt.title("v7: v6 closure root compared with legacy vortex-ring constants")
    plt.grid(True)
    plt.legend(fontsize=8)
    plt.tight_layout()
    path = os.path.join(EXPORT_DIR, "chi_v7_root_vs_legacy_alpha.png")
    plt.savefig(path, dpi=150)
    print(f"[*] Plot saved: {path}")


def plot_target_bars(legacy):
    labels = [r["key"].replace("_", "\n") for r in legacy]
    cvals = [float(r["c_over_v"]) for r in legacy]
    deltas = [float(r["a0_minus_a0_star"]) for r in legacy]
    colors = ["tab:purple" if r["key"] == "nls_legacy" else "tab:blue" for r in legacy]

    plt.figure(figsize=(11, 5))
    plt.bar(range(len(labels)), cvals, color=colors)
    plt.axhline(1.0, color="k", linestyle="--")
    plt.xticks(range(len(labels)), labels, fontsize=8)
    plt.ylabel(r"$c_\chi/v_{\rm ref}$ if $a_0=\alpha_{\rm legacy}$")
    plt.title("v7 legacy alpha targets inserted into smooth-matched family")
    plt.grid(True, axis="y", alpha=0.4)
    plt.tight_layout()
    path = os.path.join(EXPORT_DIR, "chi_v7_legacy_target_speed_bars.png")
    plt.savefig(path, dpi=150)
    print(f"[*] Plot saved: {path}")

    plt.figure(figsize=(11, 5))
    plt.bar(range(len(labels)), deltas, color=colors)
    plt.axhline(0.0, color="k", linestyle="--")
    plt.xticks(range(len(labels)), labels, fontsize=8)
    plt.ylabel(r"$\alpha_{\rm legacy}-a_0^\star$")
    plt.title("v7 distance between legacy alpha targets and v6 closure root")
    plt.grid(True, axis="y", alpha=0.4)
    plt.tight_layout()
    path = os.path.join(EXPORT_DIR, "chi_v7_legacy_alpha_distance.png")
    plt.savefig(path, dpi=150)
    print(f"[*] Plot saved: {path}")


def plot_profile_comparison():
    x = np.linspace(0.0, 1.0, 1400)
    plt.figure(figsize=(10, 6))
    for label, a0, style in [
        (r"$a_0^\star$ closure root", A0_STAR, "-"),
        (r"NLS $\alpha=1.61$", NLS_ALPHA, "--"),
        (r"$\varphi$", PHI, ":"),
        (r"solid core target $\alpha=1.75$", 1.75, "-."),
    ]:
        y = np.array([smooth_matched_poly(float(xx), a0) for xx in x])
        plt.plot(x, y, style, label=f"{label} ({a0:.6f})")
    plt.xlabel(r"$x=r/a_{\rm core}$")
    plt.ylabel(r"$f(x)=v_\theta/v_{\rm ref}$")
    plt.title("v7 selected smooth-matched profiles")
    plt.grid(True)
    plt.legend(fontsize=8)
    plt.tight_layout()
    path = os.path.join(EXPORT_DIR, "chi_v7_selected_profiles.png")
    plt.savefig(path, dpi=150)
    print(f"[*] Plot saved: {path}")


def plot_beta_relations(legacy):
    labels = [r["key"].replace("_", "\n") for r in legacy]
    rel1 = [float(r["beta_minus_alpha_minus_1"]) for r in legacy]
    rel15 = [float(r["beta_minus_alpha_minus_3_over_2"]) for r in legacy]
    xx = np.arange(len(labels))
    width = 0.38
    plt.figure(figsize=(11, 5))
    plt.bar(xx - width/2, rel1, width, label=r"$\beta-(\alpha-1)$")
    plt.bar(xx + width/2, rel15, width, label=r"$\beta-(\alpha-3/2)$")
    plt.axhline(0.0, color="k", linestyle="--")
    plt.xticks(xx, labels, fontsize=8)
    plt.ylabel("relation residual")
    plt.title("v7 legacy beta-relation diagnostics")
    plt.grid(True, axis="y", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    path = os.path.join(EXPORT_DIR, "chi_v7_beta_relation_residuals.png")
    plt.savefig(path, dpi=150)
    print(f"[*] Plot saved: {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--python", action="store_true", help="force pure-Python backend")
    parser.add_argument("--sweep-count", type=int, default=1001)
    args = parser.parse_args()
    t0 = time.time()

    cpp, backend = try_cpp_backend(args.python)
    if cpp is not None:
        cpp_root = float(cpp.analytic_root())
        cpp_bisect = float(cpp.bisection_root())
    else:
        cpp_root = float("nan")
        cpp_bisect = float("nan")

    a0_star = A0_STAR
    a0_bisect = bisection_root()
    nls_eval = evaluate_at_a0(NLS_ALPHA)
    phi_eval = evaluate_at_a0(PHI)
    legacy = legacy_rows()
    specials = special_points()
    near = nearest_targets()
    sweep = sweep_a0(0.5, 2.5, args.sweep_count)

    print("=" * 88)
    print("SST chi-phase v7 legacy vortex-ring alpha/beta target comparator")
    print("=" * 88)
    print(f"[*] backend = {backend}")
    print(f"[*] rho_f   = {RHO_F:.8e} kg m^-3")
    print(f"[*] v_swirl = {V_SWIRL:.8e} m s^-1")
    print(f"[*] omega_c = {OMEGA_C:.8e} s^-1")
    print(f"[*] r_c     = {R_C:.8e} m")
    print("[*] v7 status: target comparator, not alpha_eff/beta_eff derivation.")
    print(f"    a0_star = {a0_star:.16f}")
    print(f"    bisection root = {a0_bisect:.16f}")
    print(f"    phi = {PHI:.16f}")
    print(f"    NLS alpha = {NLS_ALPHA:.8f}, beta = {NLS_BETA:.8f}")
    print(f"    c(NLS alpha)/v = {nls_eval['c_over_v']:.12f}")
    print(f"    c(phi)/v       = {phi_eval['c_over_v']:.12f}")

    write_csv(os.path.join(EXPORT_DIR, "chi_v7_legacy_targets.csv"), legacy)
    write_csv(os.path.join(EXPORT_DIR, "chi_v7_special_points.csv"), specials)
    write_csv(os.path.join(EXPORT_DIR, "chi_v7_a0_sweep.csv"), sweep)

    plot_root_and_targets(sweep, legacy)
    plot_target_bars(legacy)
    plot_profile_comparison()
    plot_beta_relations(legacy)

    summary_path = os.path.join(EXPORT_DIR, "chi_v7_run_results_summary.txt")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("SST chi-phase v7 legacy vortex-ring alpha/beta target comparator\n")
        f.write("===============================================================\n")
        f.write(f"backend                                      = {backend}\n")
        f.write(f"rho_f                                        = {RHO_F:.16e} kg m^-3\n")
        f.write(f"v_swirl                                      = {V_SWIRL:.16e} m s^-1\n")
        f.write(f"omega_c                                      = {OMEGA_C:.16e} s^-1\n")
        f.write(f"r_c                                          = {R_C:.16e} m\n\n")
        f.write("Key status:\n")
        f.write("v7 compares legacy vortex-ring alpha/beta targets to the v6 smooth-matched\n")
        f.write("closure root. It does not derive physical alpha_eff,beta_eff from ring energy.\n\n")
        f.write("Smooth-matched family:\n")
        f.write("f_a(x)=x[a+(3-2a)x^2+(a-2)x^4], f(0)=0, f(1)=1, f'(1)=-1\n")
        f.write("c^2/v^2=(2a^2+13a+78)/105\n\n")
        f.write(f"a0_star closure root                         = {a0_star:.16e}\n")
        f.write(f"a0_star bisection                            = {a0_bisect:.16e}\n")
        f.write(f"cpp analytic root                            = {cpp_root:.16e}\n")
        f.write(f"cpp bisection root                           = {cpp_bisect:.16e}\n")
        f.write(f"phi                                          = {PHI:.16e}\n")
        f.write(f"a0_star - phi                                = {a0_star - PHI:.16e}\n")
        f.write(f"legacy NLS alpha                             = {NLS_ALPHA:.16e}\n")
        f.write(f"legacy NLS beta                              = {NLS_BETA:.16e}\n")
        f.write(f"a0_star - NLS alpha                          = {a0_star - NLS_ALPHA:.16e}\n")
        f.write(f"c(NLS alpha)/v                               = {nls_eval['c_over_v']:.16e}\n")
        f.write(f"c(phi)/v                                     = {phi_eval['c_over_v']:.16e}\n")
        f.write(f"nearest legacy alpha to a0_star              = {near['nearest_alpha_to_a0_star_key']} ({near['nearest_alpha_to_a0_star_alpha']})\n")
        f.write(f"nearest legacy closure target                = {near['nearest_closure_key']} c/v={near['nearest_closure_c_over_v']}\n\n")
        f.write("Legacy target rows:\n")
        for row in legacy:
            f.write(f"- {row['key']}: alpha={row['alpha']}, beta={row['beta']}, c/v if a0=alpha={row['c_over_v']:.12f}, delta_to_root={row['a0_minus_a0_star']:.12e}\n")
        f.write("\nInterpretation:\n")
        f.write("NLS alpha=1.61 lies close to the v6 closure root but does not equal it.\n")
        f.write("The comparison is suggestive only; a real v8/v7.1 must derive alpha_eff and beta_eff\n")
        f.write("from a vortex-ring energy/impulse calculation rather than identifying alpha with a0.\n")
    print(f"[*] Summary saved: {summary_path}")
    print("=" * 88)
    print("Summary")
    print("=" * 88)
    print(f"a0_star                = {a0_star:.16f}")
    print(f"NLS alpha              = {NLS_ALPHA:.16f}")
    print(f"a0_star - NLS alpha    = {a0_star - NLS_ALPHA:.8e}")
    print(f"c(NLS alpha)/v         = {nls_eval['c_over_v']:.12f}")
    print(f"phi                    = {PHI:.16f}")
    print(f"c(phi)/v               = {phi_eval['c_over_v']:.12f}")
    print(f"summary                = {summary_path}")
    print(f"elapsed                = {time.time() - t0:.2f} s")
    print("[*] PASS: v7 target comparison completed. Not a ring-constant derivation.")


if __name__ == "__main__":
    main()
