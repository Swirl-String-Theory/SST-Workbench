# Gate2 Ruban Familywise Coupled Falsifier v0.2.2

Scientific conclusion: **G2_UNRESOLVED_NO_CERTIFIED_EQUILIBRIUM**.

## What this run tested
- Families: ['T_3_3', 'T_3_6', 'T_3_9', 'T_6_15', 'T_6_21', 'T_6_9', 'BORRO_FLAT', 'BORRO_BALANCED', 'BORRO_5_5_6_TIGHT', 'BORRO_6_6_5_SOFT']
- B0: [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32]
- Lambda: [3.4, 4.0, 5.0, 6.0, 7.0]
- Paired reduced-filament scenarios: 1000
- G3 promoted resolutions: 2048
- G4 coupled Euler pilot runs: 0
- G2 fit: compare (compare ranks via free 6-parameter fit), weighting=arclength

## Gate statuses
- G1: PASS_GEOMETRY_SCREEN_IMPORTED_TOPOLOGY_UNRESOLVED
- G2: PASS_REDUCED_SCREEN_EXECUTED_RESOLUTION_LIMITED
- G3: RANKING_PROVISIONAL_NUMERICAL_CONVERGENCE_UNRESOLVED
- G4: NOT_RUN_USER_DISABLED

## Physical interpretation
This pipeline screens analytic torus seeds and/or user-imported, provenance-verified link geometries. It neither solves a fully deformable stationary Euler boundary-value problem nor proves nonlinear stability. The 3D Euler pilot is a finite periodic Gaussian-mollified vortex field with back-reaction, not a continuum equilibrium certificate.
Averaging or long survival under a reduced filament model is not a vanishing Euler residual.
G2/G3 optional free-space 6-parameter rigid-velocity fit is NOT applied to cubic-periodic G4 Euler, which has no arbitrary continuous rotation symmetry.
Imported link qualification reports source geometry only: Milnor mu123, knot labels, and full isotopy remain UNRESOLVED.
Frozen-parameter convergence of the full-component Euler residual and topology-preserving material simulation are required before G2 PASS.

## Selected seeds
- BORRO_BALANCED B0=N/A (imported fixed geometry), Lambda=3.40; N=[2048]; score=0.672249
- T_6_21 B0=0.32, Lambda=3.40; N=[2048]; score=0.675451
- T_6_15 B0=0.32, Lambda=3.40; N=[2048]; score=0.706454
- T_6_9 B0=0.32, Lambda=3.40; N=[2048]; score=0.746887
- BORRO_FLAT B0=N/A (imported fixed geometry), Lambda=3.40; N=[2048]; score=0.758466
- T_3_3 B0=0.18, Lambda=3.40; N=[2048]; score=0.792162
- T_3_6 B0=0.08, Lambda=3.40; N=[2048]; score=0.922093
- T_3_9 B0=0.06, Lambda=3.40; N=[2048]; score=0.944808
- BORRO_6_6_5_SOFT B0=N/A (imported fixed geometry), Lambda=3.40; N=[2048]; score=1.00025
- BORRO_5_5_6_TIGHT B0=N/A (imported fixed geometry), Lambda=3.40; N=[2048]; score=1.00261

## Provenance
- E010 v0.3.6 generator SHA-256: 2c73d35fd58c9f4bcb4ddbb336021883d0bdff44051105750a68fa0fc6a0c609
- E010 v0.3.6 config SHA-256: c7b29996e665296a99c376be044c66eb0ebefe31ecd516a3e53e9b908679890d
Analytic torus families: E010 v0.3.6; BORRO_* custom geometries: supplied imported XYZ/TXT, original hashes retained. The custom links have UNRESOLVED Milnor mu123 and full link isotopy. No Borromean identity or stable Euler equilibrium is asserted.
