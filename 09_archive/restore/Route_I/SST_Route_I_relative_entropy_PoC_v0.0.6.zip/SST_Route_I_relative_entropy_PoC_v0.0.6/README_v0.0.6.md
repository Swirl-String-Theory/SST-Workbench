# SST Route I — Common Microscopic Foundation v0.0.6

## Doel

Dit pakket maakt de gemeenschappelijke fundering onder de drie branches uit
v0.0.5. Correlaties, topologische labels en boundary modes worden niet langer
als drie losse vermenigvuldigingsfactoren behandeld. Ze worden uit één en
hetzelfde compact-\(U(1)\) cellulaire linkmodel berekend.

## Release-oordeel

\[
\boxed{
\texttt{FOUNDATION-PASS / ABSOLUTE-SCALE-OPEN / NONPERTURBATIVE-PHASE-OPEN}
}
\]

Alle zestien automatische gates slagen.

## Hoofdresultaten

Voor een periodieke driedimensionale cellulaire graph zijn exact gevonden:

\[
(b_0,b_1,b_2,b_3)=(1,3,3,1),
\]

\[
N_{\mathrm{zero}}=3,
\qquad
N_{\mathrm{rad}}=2N^3-2.
\]

Bij het fijnste raster \(N=6\):

\[
N_{\mathrm{rad}}=430,
\qquad
N_{\mathrm{zero}}=3.
\]

De boundary trace heeft stabiel twee fysieke kanalen per relationele
oppervlaktecel:

\[
\boxed{\nu_{\mathrm{ch}}=2}.
\]

Daaruit volgt blind:

\[
\boxed{
n_{\mathrm{ch}}=\frac{2}{a_\star^2},
\qquad
\eta_{\mathrm{cap}}^{(q=2)}
=\frac{2\ln2}{a_\star^2}.
}
\]

De fysieke adjacencylengte \(a_\star\) is niet gekozen of terugberekend.

Global boundary topology levert slechts

\[
\eta_{\mathrm{top,global}}
=\frac{2\ln q}{N^2a_\star^2}\to0,
\]

en is dus niet extensief.

Voor de bevroren weak-field puls geeft dezelfde modecovariantie bij \(N=6\):

\[
\chi_{\mathrm{corr}}=0.645716,
\qquad
\frac{d_{\mathrm{rate}}}{\ln2}=8.54414\times10^{-4}.
\]

Correlaties leveren hier een eindige order-one herweging en geen verborgen
hiërarchiefactor.

## Uitvoeren

Linux/macOS:

```bash
./run_v0.0.6.sh
```

Windows:

```bat
run_v0.0.6.bat
```

Of direct:

```bash
python sst_route1_common_foundation_v0.0.6.py \
  --output-dir output_v0.0.6
```

## Belangrijkste output

- `output_v0.0.6/audit_report.json`
- `output_v0.0.6/common_foundation_refinement.csv`
- `output_v0.0.6/branch_B_defect_dilution.csv`
- `output_v0.0.6/gap_scaling.png`
- `output_v0.0.6/channel_and_topology_scaling.png`
- `output_v0.0.6/correlation_entropy_rates.png`
- `output_v0.0.6/defect_dilution.png`

## Wat nu gesloten is

- één gedeelde microscopic ledger voor A, B en C;
- exact chain-complex en gauge bookkeeping;
- twee transversale harmonic branches;
- een stabiele dimensionless boundary-channel coefficient;
- bewijs dat globale homologie geen extensieve area law levert;
- covariance-response zonder verborgen modes.

## Wat nog open blijft

1. derivatie van \(a_\star\), \(I_\ell\) en \(K_\ell\) uit nonlinear SST
   adjacency energy;
2. dynamische edge birth/death en een echt non-Bravais relationeel netwerk;
3. nonperturbatieve Coulomb/deconfinement-certificatie;
4. een beschermde extensieve lokale topologische alphabet;
5. een blinde SI-waarde van \(\eta_A^{\mathrm{SST}}\).

## Volgende theorem target

\[
\boxed{
\text{deriveer }a_\star,I_\ell,K_\ell
\text{ en certificeer de nonperturbatieve deconfined phase.}
}
\]

## Referenties

```latex
\begin{thebibliography}{9}

\bibitem{Wilson1974}
K.~G.~Wilson,
\newblock Confinement of quarks,
\newblock \emph{Physical Review D} \textbf{10}, 2445--2459 (1974).
\newblock doi:10.1103/PhysRevD.10.2445.

\bibitem{KogutSusskind1975}
J.~Kogut and L.~Susskind,
\newblock Hamiltonian formulation of Wilson's lattice gauge theories,
\newblock \emph{Physical Review D} \textbf{11}, 395--408 (1975).
\newblock doi:10.1103/PhysRevD.11.395.

\bibitem{Kogut1979}
J.~B.~Kogut,
\newblock An introduction to lattice gauge theory and spin systems,
\newblock \emph{Reviews of Modern Physics} \textbf{51}, 659--713 (1979).
\newblock doi:10.1103/RevModPhys.51.659.

\bibitem{Dodziuk1976}
J.~Dodziuk,
\newblock Finite-difference approach to the Hodge theory of harmonic forms,
\newblock \emph{American Journal of Mathematics} \textbf{98}, 79--104 (1976).
\newblock doi:10.2307/2373615.

\bibitem{ArnoldFalkWinther2006}
D.~N.~Arnold, R.~S.~Falk, and R.~Winther,
\newblock Finite element exterior calculus, homological techniques, and applications,
\newblock \emph{Acta Numerica} \textbf{15}, 1--155 (2006).
\newblock doi:10.1017/S0962492906210018.

\end{thebibliography}
```
