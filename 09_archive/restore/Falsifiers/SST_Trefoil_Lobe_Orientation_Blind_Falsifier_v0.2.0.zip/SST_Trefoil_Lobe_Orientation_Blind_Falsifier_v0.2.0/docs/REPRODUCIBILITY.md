# Reproducibility and immutable release history

## Goal

A single v0.2.0 archive contains enough project history to recover the exact older implementations and re-run their conclusions against the same two trefoil inputs.

## Bundled canonical inputs

```text
repro_inputs/knot.3_1.fseries
repro_inputs/knot_3.1_final.txt
```

These are copies of the exact Fremlin and KnotPlot/RidgeRunner `3_1` files used for the v0.2.0 reference validation. Their hashes are recorded in `repro_inputs/INPUTS.sha256`.

The normal campaign scripts still default to the user's working-copy paths under `C:\workspace\projects\SST-Workbench\KnotPlot\...`. The bundled copies are for reproducibility and historical comparison; they are not silently substituted into a normal run.

## Bundled immutable releases

```text
release_history/SST_Trefoil_Lobe_Orientation_Blind_Falsifier_v0.1.0.zip
release_history/SST_Trefoil_Lobe_Orientation_Blind_Falsifier_v0.1.1.zip
```

Their hashes are recorded in `release_history/INDEX.sha256`. Do not edit these archives. A future v0.3.x release should include all earlier immutable release ZIPs, not only the immediately previous one.

## Recalculate historical conclusions

BASIC:

```bat
run_reproduce_history_basic.cmd
```

EXTENDED:

```bat
run_reproduce_history_extended.cmd
```

The reproduction driver extracts each older release into `_history_work/`, creates an isolated `.venv_history` for that release, installs its original requirements, and executes its own `run_blind.py` and original config against the same bundled input files. Results are written to `_history_results/`.

This is intentionally slower than merely copying old JSON: the purpose is to recompute the conclusion from the archived implementation.

## Decision-rule continuity

v0.2.0 keeps the v0.1 critical gate set unchanged:

```text
G0, G2, G3, G4, G6
```

G7–G11 are diagnostic gates. Therefore a v0.2.0 FAIL cannot become PASS merely because the new diagnostics are favorable, and older conclusions are not rewritten retrospectively.
