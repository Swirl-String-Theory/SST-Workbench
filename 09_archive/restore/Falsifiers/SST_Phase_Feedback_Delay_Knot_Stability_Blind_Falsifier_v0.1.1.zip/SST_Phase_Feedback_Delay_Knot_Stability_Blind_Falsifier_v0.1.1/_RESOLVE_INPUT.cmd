@echo off
rem NOTE: intentionally no SETLOCAL. Exports INPUT to caller.
if not "%~1"=="" (
  set "INPUT=%~1"
  goto :validate
)

set "INPUT="
if exist "%~dp0..\..\KnotPlot\KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0" set "INPUT=%~dp0..\..\KnotPlot\KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0"
if not defined INPUT if exist "%~dp0..\KnotPlot\KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0" set "INPUT=%~dp0..\KnotPlot\KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0"

rem Fallback for alternate folder naming: find a matching relaxation-matrix directory.
if not defined INPUT for /d %%D in ("%~dp0..\..\KnotPlot\*MultiDynamics*Relaxation*Matrix*v0.1.0*") do if not defined INPUT set "INPUT=%%~fD"
if not defined INPUT for /d %%D in ("%~dp0..\KnotPlot\*MultiDynamics*Relaxation*Matrix*v0.1.0*") do if not defined INPUT set "INPUT=%%~fD"

:validate
if not defined INPUT (
  echo ERROR: No KnotPlot relaxation-matrix input directory could be resolved.
  echo Pass it explicitly, e.g. run_all.cmd "C:\workspace\solo_projects\SST-Workbench\KnotPlot\KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0"
  exit /b 1
)
if not exist "%INPUT%" (
  echo ERROR: Input directory does not exist:
  echo   %INPUT%
  exit /b 1
)
for %%I in ("%INPUT%") do set "INPUT=%%~fI"
echo [PFD] Input: %INPUT%
exit /b 0
