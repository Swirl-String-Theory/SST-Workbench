# A069 v0.3.1 - HISTORICAL TREFOIL GEOMETRY CANDIDATE

Built as a versioned copy of the actual A069-v0.3.0 file tree from Google Drive (2026-10-17), with the two historical 2015 trefoil XYZ geometries from this conversation and additional D3H tests. Uses ONLY pinned framework v1.0.9 installed separately. Never use v1.0.7 to run A069-v0.3.1.

**Status: DEVELOPMENT / NOT FROZEN / NOT CERTIFIED.** The included source files are reconstructed from Drive, but this is not an official certified report from your PC. The uploaded historical geometry is not a qualified source of Euler/PKLSA dynamics.

Windows: place A069-v0.3.1 alongside A069-v0.3.0 under Workbench/01_research/A_falsifiers/A069_3D_SwirlClock_Emergence. Verify framework 1.0.9 installation. `python -m pytest -q -o addopts="" tests`, `python run_historical_trefoils.py`, then `run_all.cmd FREEZE`, `run_all.cmd BASIC`, `run_all.cmd REPORT_ONLY`. Only the framework may create real private commitments, FREEZE proof, BLIND archive and official PDF.

New G20-G22 are STATIC geometric diagnostic passes; G23-G24 unresolved. Inherited G0-G19 semantics preserved. A061 source-independent physical transfer remains blocked.

See docs/HISTORICAL_TREFOIL_V031.md and source patch README.
