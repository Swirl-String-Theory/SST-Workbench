# Falsifier report - Gate2_Ruban_Familywise_Coupled_Falsifier v0.1.0

Scientific verdict: **G2_UNRESOLVED_NO_CERTIFIED_EQUILIBRIUM**.

## Falsifier question
Can a fully back-reacting grid of initially parallel vortex cores form a genuine relative Euler equilibrium with a finite-core trefoil?

## Executed gates
- G1: 84 geometry seeds; 12 embeddings, 7 B values each. Geometric screening only, no exact reach certificate.
- G2: 84 nominal scans and 84 perturbed scans via regularized filament induction. NOT full Euler.
- G3: 12 independent filament-resolution comparisons at 128,256,512 points; ranking is provisional.
- G4: 4 fully coupled Fourier Euler pilot cases, frozen-U holdout at 24 cubed; periodic Gaussian vorticity; no U/Omega continuum root.

## Primary falsification gates
1. Full residual for every material vortex component tends to zero under independent spatial refinement, with solution fields converging in sufficient norm. **NOT MET**.
2. Divergence tends to zero independently of projection and alias-filter artifacts. **PARTIALLY DIAGNOSTIC ONLY**.
3. Circulation and material knot/link topology preserved for a nonzero finite-core tube. **NOT CERTIFIED**.
4. Spatial and temporal convergence at common final physical time and independent solvers. **NOT CERTIFIED**.
5. Periodic boundary/return-limb independence and true z-axis rotational symmetry when Omega is used. **NOT TESTED / OMEGA NOT PERMITTED**.

## Provenance
- E010 source archive SHA256: `63274fcd25cb12753830c7578ebeb948c01027a9a551299cbe58af3458e36c6f`
- All E010 seed and perturbed-shape SHA256 values verified against FAMILY_INDEX.
- Catalog family ID: UNASSIGNED pending current SST-Workbench catalog audit.

## Scientific interpretation
No seed ranking and no decrease in a coarse numerical proxy may be promoted to Euler equilibrium or physical stability.
The present stage 4 is an initial direct-dynamics test, **not** an equilibrium optimizer.

## Execution / artifacts
Source configurations and exact per-seed output records are in G1, G2, G3, G4 files.
Run tests before producing results and then invoke `run_all.cmd` or `run_all.sh`.
