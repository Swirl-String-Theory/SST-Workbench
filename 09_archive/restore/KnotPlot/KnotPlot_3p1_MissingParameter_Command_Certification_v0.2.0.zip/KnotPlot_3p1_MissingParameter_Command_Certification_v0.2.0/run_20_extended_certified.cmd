@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist analysis\CERTIFICATION.json (echo ERROR: run certification analysis first.^& exit /b 2)
for /f "usebackq delims=" %%P in (`python -c "import json;d=json.load(open(r'analysis\CERTIFICATION.json'));print(' '.join(d.get('certified_effective',[])))"`) do set "PARAMS=%%P"
if "%PARAMS%"=="" (echo No parameters certified effective. Extended stage skipped.^& exit /b 0)
echo Certified parameters: %PARAMS%
python run_knotplot_stage.py --stage extended --params %PARAMS%
exit /b %ERRORLEVEL%
