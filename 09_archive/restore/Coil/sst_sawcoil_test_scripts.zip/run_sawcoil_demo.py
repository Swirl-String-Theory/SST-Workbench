"""Run a compact demo of all four SawShape coil test scripts."""
from __future__ import annotations
import subprocess
import sys

scripts = [
    [sys.executable, "/mnt/data/01_pwm_spectrum.py", "--duty", "0.382", "--harmonics", "40"],
    [sys.executable, "/mnt/data/01_pwm_spectrum.py", "--duty", "0.5", "--harmonics", "40"],
    [sys.executable, "/mnt/data/02_sawshape_geometry.py", "--radius", "0.05", "--pairs", "20"],
    [sys.executable, "/mnt/data/03_biot_savart_scan.py", "--radius", "0.05", "--duty", "0.382", "--current", "10", "--f0", "1000000", "--harmonics", "15", "--res", "25"],
    [sys.executable, "/mnt/data/04_fr_scaling_test.py"],
]

for cmd in scripts:
    print("\n$", " ".join(cmd))
    subprocess.run(cmd, check=True)
print("\nDone. Outputs in /mnt/data/sawcoil_out")
