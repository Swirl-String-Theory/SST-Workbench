# Three Hessian Gate Audit: trefoil versus unknot

This is an audit script, not a theorem-complete derivation.

## H1. Surface Hessian
The surface Hessian eigenvalues are \(k_\ell=\ell(\ell+1)-2\).
The active pressure-sector count is \(N_p=4\).

## H2. Pressure eta-Hessian
The script computes \(H_\eta=d^2E_{\rm pressure}/d\eta^2|_{\eta=0}=-2\sigma E_0\) for the conditional pressure model.
This does not derive \(\sigma=11/3\); it isolates the Hessian object needed for the BEM/NLS pressure-mode eta-scan.

## H3. Phase Hessian / impedance
The radial phase Hessian is \(\Lambda_\phi=4\pi/\int_a^R dr/[n(r)r^2]\).
Target-budget profiles pass by construction and are labeled as identities, not evidence.

## Fine-structure-scale comparison
### trefoil_3_1
- L_K = 16.371637
- leading alpha inverse = 137.154705404
- conditional corrected alpha inverse = 137.037437828
- interpretation = `trefoil_close_to_alpha_scale`
### unknot_0_1
- L_K = 3.14159265359
- leading alpha inverse = 26.3189450696
- conditional corrected alpha inverse = 25.7078339585
- interpretation = `unknot_not_alpha_scale_in_this_finite_cell_formula`

Conclusion: in the current finite-cell formula, the unknot does not produce the observed fine-structure scale. The exterior far-field carrier may be unknotted/H^0-like, but the source-cell energy scale remains trefoil-like for the electron benchmark.