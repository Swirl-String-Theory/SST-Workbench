# A054 v0.1.0 — BLIND report

- Cases: **82** = 35 knots + 47 links.
- Backend: **cpp**.
- SM particle labels visible to blind stage: **no**.
- Historical particle mapping visible to blind stage: **no**.
- PD-derived embedding ensemble: 2 replicates, 40 points/component.
- Main output: frozen feature vectors and unsupervised pair-neighbor distances.

## Scientific scope

The Gauss/Neumann, bending, contact and presentation-robustness quantities in v0.1.0 are **screening observables** on deterministic 3D realizations of the PD presentations. They are not PKLSA-relaxed ideal geometry, not a solved Euler vortex, and not particle masses. A particle claim is therefore prohibited at this stage.

The reveal layer may test whether pre-existing hypotheses or SM mass-ratio patterns are unusually close to the frozen spectrum, with explicit look-elsewhere diagnostics.
