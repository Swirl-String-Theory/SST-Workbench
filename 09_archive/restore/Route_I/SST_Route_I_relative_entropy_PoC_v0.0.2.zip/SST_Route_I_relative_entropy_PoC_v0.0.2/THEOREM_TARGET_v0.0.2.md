# Theorem Target v0.0.2 — Canonical Torsion-Field Normalization

## Status

\[
\boxed{\text{DERIVED-CONDITIONAL}}
\]

The result is derived exactly for one linear transverse polarization of the
quadratic SST torsion layer. It does not yet establish the SST horizon/KMS
structure or derive the stiffness \(K_T\) from substrate microphysics.

## Starting point

For a transverse displacement polarization \(A\), the current SST Research
Track uses

\[
\mathcal L_T
=
\frac12\rho_{\!f}(\partial_t A)^2
-
\frac12K_T(\nabla A)^2,
\qquad
c_T^2=\frac{K_T}{\rho_{\!f}}.
\]

Introduce the length-valued causal time coordinate

\[
x^0=c_Tt,
\qquad
dt=\frac{dx^0}{c_T}.
\]

The action becomes

\[
S_T
=
\frac12\int dx^0\,d^3x
\left[
\rho_{\!f}c_T(\partial_0A)^2
-
\frac{K_T}{c_T}(\nabla A)^2
\right].
\]

Since

\[
\rho_{\!f}c_T
=
\frac{K_T}{c_T}
=
\sqrt{\rho_{\!f}K_T}
=:Z_T,
\]

one obtains

\[
S_T
=
\frac{Z_T}{2}\int dx^0\,d^3x
\left[(\partial_0A)^2-(\nabla A)^2\right].
\]

## Canonical normalization theorem

Define

\[
\boxed{
\Phi_T=\sqrt{Z_T}\,A
}
\]

Then

\[
\boxed{
S_T
=
\frac12\int dx^0\,d^3x
\left[(\partial_0\Phi_T)^2-(\nabla\Phi_T)^2\right].
}
\]

The physical Hamiltonian is simultaneously transformed to

\[
H_T
=
\frac12\int d^3x
\left[
\rho_{\!f}(\partial_tA)^2+K_T(\nabla A)^2
\right]
=
\frac{c_T}{2}\int d^3x
\left[
(\partial_0\Phi_T)^2+(\nabla\Phi_T)^2
\right].
\]

The canonical two-form is preserved because

\[
P_A=Z_T\partial_0A,
\qquad
P_{\Phi}=\partial_0\Phi_T,
\]

and therefore

\[
\int d^3x\,\delta P_A\wedge\delta A
=
\int d^3x\,\delta P_{\Phi}\wedge\delta\Phi_T.
\]

## Quantum and dimensionless fields

The quantum-normalized dimensionful field is

\[
\boxed{
\varphi_T
=
\frac{\Phi_T}{\sqrt{\hbar}}
=
\sqrt{\frac{Z_T}{\hbar}}\,A.
}
\]

Dimensional check:

\[
[Z_T]=\mathrm{kg\,m^{-2}\,s^{-1}},
\qquad
\left[\sqrt{\frac{Z_T}{\hbar}}\right]=\mathrm{m^{-2}},
\qquad
[\varphi_T]=\mathrm{m^{-1}}.
\]

If the numerical affine coordinate is

\[
u=\frac{U}{L_\star},
\]

then the dimensionless field used in the horizon script is

\[
\boxed{
\widehat\phi
=L_\star\varphi_T
=L_\star\sqrt{\frac{Z_T}{\hbar}}\,A.
}
\]

Thus the requested normalization is not a scale-free number:

\[
\boxed{
\mathcal N_T(L_\star)
=L_\star\sqrt{\frac{Z_T}{\hbar}}.
}
\]

## Canonical numerical values

Using

\[
\rho_{\!f}=7.0\times10^{-7}\ \mathrm{kg\,m^{-3}},
\qquad
c_T=c=2.99792458\times10^8\ \mathrm{m\,s^{-1}},
\]

one obtains

\[
K_T=\rho_{\!f}c^2
=6.2912862511577\times10^{10}\ \mathrm{Pa},
\]

\[
Z_T=\rho_{\!f}c
=2.098547206\times10^2\ \mathrm{kg\,m^{-2}\,s^{-1}},
\]

\[
\sqrt{Z_T}=14.4863632634,
\qquad
\sqrt{\frac{Z_T}{\hbar}}
=1.41065655434\times10^{18}\ \mathrm{m^{-2}}.
\]

For \(L_\star=1\ \mathrm m\),

\[
\mathcal N_T
=1.41065655434\times10^{18}\ \mathrm{m^{-1}}.
\]

For \(L_\star=r_c=1.40897017\times10^{-15}\ \mathrm m\),

\[
\mathcal N_T(r_c)
=1.98757300518\times10^3\ \mathrm{m^{-1}}.
\]

A fixed numerical coefficient amplitude \(\widehat\phi_0=0.01\) would then
correspond to

\[
A_0(r_c)
=\frac{0.01}{\mathcal N_T(r_c)}
=5.03126\times10^{-6}\ \mathrm m,
\]

which is vastly larger than \(r_c\). The scale sweep accordingly finds a
maximum linear strain of order \(9.28\times10^9\). Therefore the old normalized
pulse cannot be interpreted as a literal linear core-scale displacement without
reducing its amplitude by many orders of magnitude. This is a validity gate,
not a failure of the canonical normalization theorem.

## Numerical verification

The bundled script verifies:

\[
\varepsilon_S=1.33\times10^{-16},
\qquad
\varepsilon_H=1.17\times10^{-16},
\qquad
\varepsilon_\Omega=0,
\]

for the action, physical Hamiltonian, and symplectic form respectively. The
field round trip

\[
\widehat\phi\rightarrow A\rightarrow\widehat\phi
\]

closes with relative error \(1.26\times10^{-16}\).

## Remaining theorem gates

1. Derive \(K_T\) and \(c_T\) from substrate microphysics without same-step use
   of measured \(c\).
2. Show that the relevant torsion sector reduces to independent transverse
   canonical polarizations in the required regime.
3. Derive the local horizon/KMS modular structure.
4. Fix \(L_\star\) from the SST clock/horizon construction.
5. Only then identify the canonical \(\varphi_T\) with the coherent field used
   in the relative-entropy theorem.

## Reference

```latex
\begin{thebibliography}{9}

\bibitem{DorauMuch2026}
P.~Dorau and A.~Much,
\newblock From quantum relative entropy to the semiclassical Einstein equations,
\newblock \emph{Physical Review Letters} \textbf{136}, 091602 (2026).
\newblock doi:10.1103/lmq8-nsty.
\newblock arXiv:2510.24491.

\end{thebibliography}
```
