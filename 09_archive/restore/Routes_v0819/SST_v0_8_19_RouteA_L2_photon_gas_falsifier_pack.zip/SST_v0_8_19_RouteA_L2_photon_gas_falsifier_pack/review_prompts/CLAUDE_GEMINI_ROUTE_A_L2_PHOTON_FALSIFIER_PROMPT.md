Please audit this SST Route-A/L2 falsifier.

Claim to test: the previous candidate `g_T = 9(4*pi)^2` should be downgraded from non-fitted degeneracy to matching ansatz.

Key question: Does a Weyl mode-counting prescription allow multiplication by an extra angular solid-angle factor after the Weyl coefficient has already integrated over the k-sphere?

Use the photon gas as a control. For photons, Weyl counting plus two transverse polarizations must reproduce the blackbody coefficient. If the prescription predicts `2*4*pi` or `2*(4*pi)^2` photon degeneracy, the prescription is invalid.

Please check:
1. The photon-gas density-of-states coefficient.
2. Whether `(4*pi)^2` is a measure convention rather than a degeneracy count.
3. Whether `dim(R^3 tensor Lambda^2 R^3)=9` is the only orthodox component count retained.
4. Whether the torsion irrep decomposition `9=3+1+5` should be treated as the next L2-a horizon-projection problem.
5. Whether the canon block correctly labels `(4*pi)^2` as `[NOT DERIVED]` and `g_T=9(4*pi)^2` as `[MATCHING ANSATZ]`.
