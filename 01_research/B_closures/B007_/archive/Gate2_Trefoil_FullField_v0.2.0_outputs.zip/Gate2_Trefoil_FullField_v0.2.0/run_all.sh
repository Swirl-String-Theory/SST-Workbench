#!/usr/bin/env bash
set -euo pipefail
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$(dirname "$0")"
OUT="Gate2_Trefoil_FullField_v0.2.0-outputs"
python -m pytest -q tests | tee "$OUT/pytest.log"
python src/continuation.py --resume --stages 20:2:2 32:4:4 40:5:1 --out "$OUT/continuation"
python src/verify_independent.py --search "$OUT/continuation/stage_3_n40_m5/search.json" --grids 24 32 40 48 64 --box-control
python src/assess.py --search "$OUT/continuation/stage_3_n40_m5/search.json" --holdout "$OUT/continuation/stage_3_n40_m5/holdout.json" --out "$OUT"
