#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="${1:-../../provenance/canon_snapshot_v0_8_28}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/patched"
MAIN_OLD="$BASE_DIR/SST_CANON-v0.8.28.tex"
RT_OLD="$BASE_DIR/SST_CANON-v0.8.28-research-track.tex"
[[ -f "$MAIN_OLD" && -f "$RT_OLD" ]] || { echo "Missing v0.8.28 baseline files in $BASE_DIR" >&2; exit 2; }
rm -rf "$OUT" && mkdir -p "$OUT"
patch --batch -o "$OUT/SST_CANON-v0.8.30.tex" "$MAIN_OLD" < "$HERE/0001-main-canon-v0.8.28-to-v0.8.30.diff"
patch --batch -o "$OUT/SST_CANON-v0.8.30-research-track.tex" "$RT_OLD" < "$HERE/0002-research-track-v0.8.28-to-v0.8.30.diff"
( cd "$HERE" && sha256sum -c SHA256SUMS.outputs.txt )
echo "Created $OUT"
