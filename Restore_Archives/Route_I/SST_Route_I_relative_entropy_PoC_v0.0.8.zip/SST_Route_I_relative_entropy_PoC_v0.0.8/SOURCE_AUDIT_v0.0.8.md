# Source and provenance audit v0.0.8

## Current SST sources

The audit uses the current loose files as authoritative:

- `SST_CANON-v0.8.28.tex`;
- `SST_CANON-v0.8.28-research-track.tex`.

Relevant canon constraints:

1. the compact link action is a Research-Track model-selection hypothesis;
2. \(c_T=a_\ell\sqrt{K_\ell/I_\ell}\) must be derived before comparison with
   observed \(c\);
3. \(\rho_{\rm horn}\) is an envelope normalization density, not a resolved
   local tube density;
4. the bound-mode impedance target requires a certified finite-thickness knot
   domain and may not be replaced by scalar ropelength;
5. source normalization, transition action, and impedance normalization remain
   theorem targets.

## External primary sources

### Exact lattice duality

M. Anosova, C. Gattringer, and T. Sulejmanpasic,
"Self-dual U(1) lattice field theory with a theta-term," JHEP 04 (2022) 120,
arXiv:2201.09468.

The modified Villain construction gives

\[
Z(\beta)=(2\pi\beta)^{-3V}Z(1/(4\pi^2\beta)).
\]

It additionally imposes closedness constraints that remove lattice monopoles,
or introduces matched electric and magnetic matter. This is not the standard
Wilson action used in the v0.0.7 Monte Carlo.

### Wilson/Kogut--Susskind template

K. G. Wilson, "Confinement of quarks," Phys. Rev. D 10, 2445 (1974).

J. B. Kogut and L. Susskind, "Hamiltonian formulation of Wilson's lattice gauge
theories," Phys. Rev. D 11, 395 (1975).

These support the structural lattice-gauge template, not the SST physical
identification or the value of \(\beta_Q\).

## Provenance conclusion

The value \(1/(2\pi)\) occurs through:

- the fixed point of the exact modified-Villain duality;
- stationarity of a free energy normalized to that exact duality;
- the phase-per-radian convention applied to the calibrated horn identity.

These are dependent uses of two inputs, not three independent derivations.
