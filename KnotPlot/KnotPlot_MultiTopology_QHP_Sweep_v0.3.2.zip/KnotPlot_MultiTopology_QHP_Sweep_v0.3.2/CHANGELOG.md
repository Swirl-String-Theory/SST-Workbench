# v0.3.2

- Live console heartbeat during active KnotPlot processes.
- Elapsed time, checkpoint progress, run ETA and campaign ETA.
- Persistent `progress.log` and `timings.csv`.
- `--progress-every` option.
- KPC `CHECKPOINT` markers.
- Added Stage 1/2/3/4 CMD runners.
- Stage 1 explicitly includes 0.1, 0.2.1 and 0.3.1 null controls.
- Stage 2: torus family.
- Stage 3: twist-knot ladder.
- Stage 4: broad remainder screen with lighter defaults.
