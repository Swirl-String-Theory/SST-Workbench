# Recovered MultiTopology QHP report

- campaign: `stage1_screen_30k_v2`
- complete runs: **90/90**
- empty original metrics CSVs: **1980**
- logs containing broken data-format diagnostics: **90**
- late window: `[15000, 18000, 22500, 30000]`

## Metric semantics

- authoritative geometry: saved `.k float` checkpoint states
- length: sum of closed component arclengths
- Rg: global bead-weighted radius of gyration
- safeness: not reconstructed or invented

## Direct late-E gate passes

| topology | run | alpha | q | h | p | median E | drift/1000 | span |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| LINK_5p2p1 | LINK_5p2p1__QHP_0000 | 0 | 42.0586 | 1.43298 | 6.215 | 0.00019253382 | 1.1628087e-05 | 0.00017453842 |
| LINK_6p3p3 | LINK_6p3p3__QHP_0004 | 0.8 | 43.92932 | 1.462916 | 6.299 | 0.00028799294 | 2.353373e-06 | 3.6130677e-05 |

## Final-checkpoint EXPAND/CONTRACT crossings

| topology | alpha* | q* | h* | p* | dL/L0 | dRg/Rg0 |
|---|---:|---:|---:|---:|---:|---:|
| KNOT_3p1 | 0.5263766 | 43.289479 | 1.452677 | 6.2702695 | -0.0020745998 | 0.0020745998 |
| KNOT_4p1 | 0.13361478 | 42.371045 | 1.4379799 | 6.2290296 | -0.0025912135 | 0.0025912135 |
| KNOT_5p2 | 0.73945088 | 43.787732 | 1.4606503 | 6.2926423 | -0.0049640588 | 0.0049640588 |
| KNOT_8p19 | 0.32010503 | 42.807134 | 1.4449583 | 6.248611 | -0.0031137305 | 0.0031137305 |
| LINK_5p2p1 | 0.063617125 | 42.207362 | 1.4353606 | 6.2216798 | -0.0012188561 | 0.0012188561 |
| LINK_6p3p3 | 0.86276395 | 44.076087 | 1.4652646 | 6.3055902 | -0.00071405633 | 0.00071405633 |

## Integrity finding

The original KnotPlot `data format` path is not authoritative for this recovered report.
The saved geometry states are complete and are analyzed directly.
