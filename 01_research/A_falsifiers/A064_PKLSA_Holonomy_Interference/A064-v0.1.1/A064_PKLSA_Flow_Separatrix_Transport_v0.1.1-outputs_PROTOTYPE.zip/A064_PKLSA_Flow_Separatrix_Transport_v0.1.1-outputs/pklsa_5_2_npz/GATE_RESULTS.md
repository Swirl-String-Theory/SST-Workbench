# A064 gate results
- Mode: `SNAPSHOTS_MODEL_RECONSTRUCTION`
- Evidence: `geometry_derived_regularized_biot_savart_simulation`
- Discovery SHA-256: `53435831533c38de3d313fba644bfece3192eaee44d28834857499ccbb0c20f5`
- Divergence (p95 dx/U): `0.01472`
- Candidate identified: `True`
- Feature status: `DYNAMICAL_STATUS_UNRESOLVED`
- True separatrix manifold gate: `UNRESOLVED_NOT_CONSTRUCTED`
- Overall: `UNRESOLVED`
