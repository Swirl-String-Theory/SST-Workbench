#!/usr/bin/env python3
"""Evaluate version-frozen G1 scope gates and write a machine-readable status.

These tolerances were fixed after exploratory v0.1 measurements, so this is not a
blind holdout certification. This is a practical G1 tier, not rigorous interval
bounds on grid discretization error or Euler equilibrium stability.
"""
import json,math,sys,hashlib
from pathlib import Path
from geometry_proof import certificate

BASE=Path(__file__).resolve().parents[1]

def assess():
    g=certificate()
    datasets={str(q):json.loads((BASE/'results'/f'q{q}.json').read_text()) for q in (0,1)}
    checks={
      'G1_GEOMETRY_CORE_INSIDE_ANALYTICALLY_PROVED_REACH_LOWER_BOUND': g['reach_lower_bound_proven']>.2,
      'G1_FRAMING_LINKING_WRTW_1024': all(abs(dat['gauss']['closure_error'])<5e-6 and abs(dat['gauss']['gauss_linking']+6)<1e-6 for dat in datasets.values()),
      'G1_FLUX_ALL_PHASE_SAMPLES': all(dat['max_flux_relative_error']<1e-10 for dat in datasets.values()),
      'G1_POINTWISE_ANALYTIC_SOLENOIDAL_FD_CONVERGENCE':all(
        abs(dat['pointwise_fd'][i+1]['divergence']) <.05*abs(dat['pointwise_fd'][i]['divergence'])
        for dat in datasets.values() for i in range(0,len(dat['pointwise_fd']),3)),
      'G1_RAW_3D_SPECTRAL_DIVERGENCE_DECAYS_64_96_128':all(
        all(dat['grids'][i]['spectral_raw_divergence_rms']>dat['grids'][i+1]['spectral_raw_divergence_rms'] for i in (0,1))
        for dat in datasets.values()),
      'G1_PROJECTION_ERROR_BELOW_ONE_PERCENT_AT_128':all(dat['grids'][-1]['projection_relative_L2_correction']<.01 for dat in datasets.values()),
      'G1_PROJECTION_ERROR_DECAYS_64_96_128':all(
        all(dat['grids'][i]['projection_relative_L2_correction']>dat['grids'][i+1]['projection_relative_L2_correction'] for i in (0,1))
        for dat in datasets.values()),
      'G1_SPECTRALLY_PROJECTED_DIVERGENCE_MACHINE_PRECISION':all(dat['grids'][-1]['projected_spectral_divergence_rms']<1e-12 for dat in datasets.values()),
      'G1_HELICITY_FREE_SPACE_BIOT_SAVART_WITHIN_ONE_PERCENT_AT_128':all(dat['grids'][-1]['relative_helicity_error_projected']<.01 for dat in datasets.values()),
      'G1_HELICITY_ERROR_DECAYS_64_96_128':all(
        all(dat['grids'][i]['relative_helicity_error_projected']>dat['grids'][i+1]['relative_helicity_error_projected'] for i in (0,1))
        for dat in datasets.values()),
    }
    result={
     'version':'v0.2.0','status':'GATE1_PASS_FOR_DECLARED_ANALYTIC_AND_NUMERICAL_SCOPE' if all(checks.values()) else 'GATE1_FAIL_OR_UNRESOLVED',
     'checks':checks,'passed':sum(checks.values()),'total':len(checks),
     'scope':'one dimensionless smooth T(2,3) torus trefoil, alpha=0.35,a=0.20, q=0 and q=1, 64^3/96^3/128^3 sampled and projected grids',
     'not_proven':['Exact reach value (only strict conservative lower bound is proved)',
                   'Rigorous a posteriori error bound for FFT/free-space Biot-Savart helicity',
                   'Uniform error bound for all 3D grid points and all perturbations',
                   'Euler relative equilibrium / Arnold stability / background-core stabilization'],
     'thresholds':{'gauss_Wr_plus_Tw_minus_Lk':5e-6,'flux_relative_error':1e-10,'pointwise_FD_step_reduction_factor':.05,
                    'projected_divergence_rms':1e-12,'relative_projected_field_correction':.01,
                    'relative_helicity_free_space':.01},
     'reaches_proof':g['reach_lower_bound_proven'],
     'metrics':{q:{'l0':dat['assumptions']['L0'], 'helicity_target':dat['assumptions']['helicity_analytic_candidate'],
                   'helicity_n128':dat['grids'][-1]['helicity_projected_free_space'],
                   'projection_n128':dat['grids'][-1]['projection_relative_L2_correction'],
                   'grid_spectral_divergence_raw_n128':dat['grids'][-1]['spectral_raw_divergence_rms'],
                   'grid_spectral_divergence_projected_n128':dat['grids'][-1]['projected_spectral_divergence_rms']}
                for q,dat in datasets.items()}
    }
    (BASE/'results'/'gate1_qualification.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    outcome=assess()
    print(outcome['status'],outcome['passed'],'/',outcome['total'])
    sys.exit(0 if outcome['status'].startswith('GATE1_PASS') else 1)
