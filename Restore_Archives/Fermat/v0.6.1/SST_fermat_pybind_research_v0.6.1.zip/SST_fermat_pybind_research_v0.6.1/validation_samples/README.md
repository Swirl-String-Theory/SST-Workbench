# v0.6.1 validation samples

These files are software-validation artifacts, not physical certifications.

- `python_fallback_smoke_campaign_summary.json`: four-stage smoke campaign, exit status success.
- `python_fallback_smoke_axis_audit.json`: low-resolution axis-offset/tilt audit.
- `python_fallback_smoke_mode_projection.json`: low-resolution residual Fourier diagnostic.
- `full_requested_grid_python_N256_summary.json`: all 2730 requested parameter combinations evaluated at low resolution to validate grid generation, controls, and reporting.

All physical certification flags remain false.
