# SST Canon Prompt System

This package contains a modular AI prompt workflow for generating:

Swirl-String-Theory_Canon-v0.8.0.tex

Workflow:
MASTER_PROMPT.md → run sequence
Then expand sections iteratively.

Designed for Deep Research + Agent Mode.
