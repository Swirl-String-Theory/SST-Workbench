# SST Chirality–Helicity Transport Polarity Falsifier — Blind Analysis

**Identity status:** source identity, knot family and original/mirror assignment were not read.

## Gate counts

```json
{
  "INDETERMINATE_EXCITATION_SENSITIVE": 2,
  "NULL_NO_DIRECTIONAL_SIGNAL": 1,
  "PASS_MIRROR_ODD_TRANSPORT": 3
}
```

## Anonymous helicity/transport association

- Pearson $r$ = -0.561581
- Spearman $\rho$ = -0.629371

## Pair gates

| pair | N | a/L | XiH odd | spectrum parity | Pi odd | |Pi| | excitation rel.std | status |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| P0001 | 96 | 0.025 | 1e-15 | 1.28e-12 | 0.000651 | 0.164 | 0.216 | PASS_MIRROR_ODD_TRANSPORT |
| P0002 | 96 | 0.025 | 4.12e-15 | 1.03e-12 | 0.0258 | 0.0521 | 2.33 | INDETERMINATE_EXCITATION_SENSITIVE |
| P0003 | 96 | 0.025 | 4.98e-16 | 2.22e-12 | 0.0619 | 0.0898 | 0.385 | PASS_MIRROR_ODD_TRANSPORT |
| P0004 | 96 | 0.025 | 0 | 1.13e-12 | 0.000321 | 0.0082 | 3.88 | NULL_NO_DIRECTIONAL_SIGNAL |
| P0005 | 96 | 0.025 | 7.48e-17 | 5.87e-13 | 0.00394 | 0.138 | 1.36 | INDETERMINATE_EXCITATION_SENSITIVE |
| P0006 | 96 | 0.025 | 0 | 1.44e-12 | 0.00051 | 0.15 | 0.072 | PASS_MIRROR_ODD_TRANSPORT |
