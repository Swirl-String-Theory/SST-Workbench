# SST Falsifier Framework changelog

## v1.0.9 — 2026-10-17 — CANONICAL_FROZEN

- Promotes the verified v1.0.8 source line with its non-overwriting run identity and exclusive-create archiving intact; source parent verified against 99/99 manifest hashes.
- Replaces interim PDF output-manifest hash with immutable create-once `SCIENCE_EVIDENCE_MANIFEST.json` digest, while preserving a distinct final `OUTPUT_MANIFEST.json` for output integrity.
- Adds independent portable UTF-8 newline-normalized protocol diagnostic SHA; **byte-exact protocol bundle SHA remains authoritative**, including for reveal/commitment checks.
- Corrects generated gate-table widths/status overflow and visually audits a generated A4 PDF. Does not introduce mandatory TeX dependency beyond existing basic report packages.
- Adds optional LaTeX engine selection and `REPORT_ONLY` safe unique PDF rerendering with sidecar provenance and no output-tree mutation.
- Adds reveal preflight requirement for immutable science evidence and associated regression tests.
- Validates 72 Python regression tests; two-run v1.0.8 archival smoke and v1.0.9 report-only smoke, plus generated PDFs.
- No scientific gates or thresholds, C++/SYCL/DD32 kernels, data admissibility, backend precision-authority, or preregistered physics changed.
- Source freeze does not certify a new target-machine Windows/Arc A770 hardware run. Retain historical instances pinned to old versions.

# SST Falsifier Framework changelog

## v1.0.8 — 2026-10-13 — LOCAL VALIDATED CANDIDATE

- New per-run identity (`RUN_ID.json`, UTC microsecond timestamp + secure random suffix).
- Existing canonical `*-outputs` folder moved to a unique immutable archive before each fresh blind run; no deletions and no changed working path for pipelines.
- ZIPs and PDF reports include run ID and BLIND/REVEALED phase; exclusive-create prevents accidental overwrite.
- Per-instance exclusive lock prevents concurrent runs/reveals; a surviving stale lock requires a manual inspection and removal.
- Blind scanning excludes **historical run archives** but continues scanning current falsifier-owned source, current outputs, reports and configs.
- BLIND and REVEALED PDF report metadata use separate files; automatic TeX report includes run identity, and v1.0.8 escapes common Unicode technical symbols.
- Parent v1.0.7 `CANONICAL_FROZEN` files preserved verbatim; scientific gate logic, numerical thresholds and backends unchanged.
- Local regression and full PDF/ZIP smoke verified; user-machine CPU/SYCL certification not rerun.


## v1.0.7 — 2026-10-07 — CANONICAL FREEZE

Maintenance release built directly from the user-supplied canonical v1.0.6 archive (ZIP SHA-256 `24629848e3befcde67c02a935fc78347560ac42107043fbc14aaabdf146ee60d`).

- Fixes blind-scan ownership scope: standard runtime/build/vendor trees (`.venv`, `venv`, `env`, caches, `build`, `dist`, `.git`, `node_modules`) are excluded from forbidden-term scanning.
- Falsifier-owned source, configs, reports and blind outputs remain fail-closed scanned.
- Adds regression tests proving a forbidden term inside `.venv/site-packages` is ignored while the same term in instance-owned source is still detected.
- Retains the complete v1.0.6 strict framework bootstrap, pytest bootstrap, `run_python`, reveal preflight/integrity, stale-reveal cleanup, backend authority, numerical kernels and precision thresholds unchanged.
- No scientific gate semantics, numerical kernel, threshold, commitment format, reveal rule or backend policy changed.

## v1.0.6 — 2026-10-07 — CANONICAL FREEZE

Consolidated hardening release based on v1.0.4 after review of all three parallel v1.0.5 artifacts.

- Adds package-safe `run_python.cmd` + `run_python.py` for instance-local helpers.
- Adds pytest bootstrap through instance-local `conftest.py`.
- Adds a single strict `framework_bootstrap.py` used by pytest and `run_instance.py`.
- Explicit environment override and `.sst_framework_root` are authoritative; invalid pins fail closed.
- Removes acceptance of an arbitrary already-importable/editable framework in place of the instance pin.
- Legacy autodiscovery is restricted to the canonical nested `06_templates/SST_Falsifier_Framework/` family and runs only when no explicit pin exists.
- Adds public non-mutating `reveal_eligibility()` and `REVEAL_IF_ALLOWED`.
- Reveal preflight now verifies gate-ledger self-hash, run-summary binding and exact blind output-manifest/tree integrity before trusting gate state.
- A successful reveal writes `REVEAL_DECISION.json` before final manifest generation and `_REVEALED.zip` packaging.
- New blind runs purge stale reveal ledgers/decisions, `revealed/`, revealed ZIP, output `POST_RUN_DISCUSSION.tex`, and the previously published parent PDF.
- Preserves v1.0.4 numerical kernels, backend authority, DD32 thresholds, C++/MSVC provenance and oneAPI link-environment behavior unchanged.
- Restores the v1.0.4 manifest contract: `MANIFEST_SHA256.txt` is the SHA-256 of `PACKAGE_MANIFEST.json`, not a full checksum list.
- v1.0.5 candidate/frozen artifacts are development provenance only and are superseded for new work.

## v1.0.4 — 2026-10-07 — CANONICAL FREEZE

- Frozen canonical baseline for all new SST falsifiers; supersedes the three legacy falsifier templates for new work.
- Source is derived directly from the user-supplied locally validated v1.0.3 snapshot, not from an earlier development copy.
- Includes the final Windows MSVC + Intel oneAPI environment merge (`vcvars64`/`VsDevCmd` then oneAPI `setvars`) and records both `msvcrt_path` and `libmmd_path`.
- Includes validated Arc A770 SYCL FP32 and DD32/FP32x2 lanes; DD32 remains non-IEEE, nominal ~48-bit significand, binary32 exponent range, and `SCREENING_ONLY`.
- Includes automatic TeX-to-PDF report publication beside the falsifier version directory.
- Includes fail-closed G5 replication semantics separating synthetic-control replication from independent cross-source replication.
- Includes actual setuptools compiler provenance for C++/OpenMP certification.
- Runtime environments, caches and compiled artifacts are excluded from the canonical source release. Target-machine JSON selftest evidence is retained under `validation/hardware/`.
- v1.0.4 is immutable: future fixes or feature changes require v1.0.5 or later.

## v1.0.3 — 2026-10-07

- Added automatic LaTeX report rendering and publication: a report TeX inside an output tree is compiled in an isolated temporary build directory and the clean PDF is published beside the falsifier version folder as `<version-folder>_FALSIFIER_REPORT.pdf`.
- Added `REPORT_RENDER.json`; missing LaTeX is non-fatal by default and can be made strict with `report.pdf_required=true`.
- Fixed A056-style report data safety by documenting that generated table values must be LaTeX-escaped before rendering.
- Fixed the oneAPI 2026 DD32 linker regression: when `setvars.bat` leaves `LIB` unset/incomplete, the SYCL builder now locates `libmmd.lib` under the active compiler installation and prepends its directory to `LIB`.
- Records `libmmd_path` and the effective `LIB` in SYCL build provenance.
- MSVC + oneAPI link-environment hotfix: load `vcvars64`/`VsDevCmd` first, then oneAPI `setvars`, and merge `PATH`/`LIB`/`LIBPATH`/`INCLUDE` so Intel cannot drop `msvcrt.lib` / Windows SDK paths; record `msvc_env_script` and `msvcrt_path` in SYCL provenance/fingerprint.
- Batch-environment capture uses a temporary wrapper `.cmd` so `Program Files` paths are not broken by Windows `list2cmdline` re-quoting.
- Added reusable replication-evidence semantics with `evidence_class = synthetic_control | simulation | independent_source | experimental`.
- Synthetic controls may close an implementation-control replication check but can never close a scientific cross-source replication gate.
- Cross-source support now requires independent/experimental evidence plus distinct independence/provenance families; identical explicit generator IDs fail closed.
- Added regression tests for synthetic pseudo-replication, independent replication, report PDF placement and the Intel compiler-math-library locator.

## v1.0.2 — 2026-10-07

- Fixed C++/pybind compiler provenance: the recorded compiler now comes from the actual setuptools build command instead of the first generic `c++.exe` on `PATH`.
- Added compiler family, compiler version, MSVC toolset, Python ABI and actual compile flags to the native build fingerprint/provenance record.
- Retained the Windows short-object-path hotfix that prevents MSVC C1083 failures from mirrored absolute source paths.
- Retained automatic Intel oneAPI environment activation for SYCL build/link/runtime (`setvars.bat` / `oneapi-vars.bat`).
- Restored the historical SST `sycl-dd32` precision route as DD32 / FP32x2 double-single arithmetic.
- Added `DS{float hi,lo}`, TwoSum/QuickTwoSum addition, FMA-residual multiplication, corrected division, two-step Newton square root and DD accumulation in the SYCL Biot--Savart kernel.
- DD32 keeps coordinates in FP64 transport until the worker-host hi/lo split and recombines `(hi,lo)` to host FP64 only after GPU execution.
- SYCL worker protocol upgraded to v3 with explicit DD32 command and precision metadata.
- SYCL compilation now includes `-fp-model=precise` because DD32 error-free transforms must not be broken by fast-math reassociation.
- Backend selftest expanded to three velocity scenarios plus a deterministic directional finite-difference stress test.
- DD32 acceptance restored from the earlier SST GPU work: velocity relative-L2 <= `1e-8`, directional stress <= `2e-6`, and >= `20x` improvement versus ordinary FP32.
- Added `run_all.cmd DD32` / `run_sycl_dd32_smoke.cmd` and `build/DD32_PARITY_SMOKE.json`.
- DD32 remains `SCREENING_ONLY`: it is not IEEE FP64 and CPU/Python FP64 remain confirmatory/reference lanes.
- Removed all framework/template discovery fallbacks under `04_tools/D_proof`; canonical template discovery is under `06_templates/SST_Falsifier_Framework/`.
- Added DD32 numerical-method documentation and report-template references.

## v1.0.1

- Added strict three-backend numerical parity selftest (`run_02_backend_selftest.cmd`).
- Added deterministic circular and trefoil common-kernel scenarios.
- Python/NumPy FP64 is the reference; C++ FP64 and SYCL FP32/FP64 are compared with explicit relative-L2 tolerances.
- `run_all.cmd ALL` performs setup, framework tests, then backend parity.
- Backend unavailability is a hard failure in the parity test; no silent fallback.

## v1.0.0

- Unified blind/multi-library, C++/pybind11 and SYCL audit infrastructure.
- Immutable create-once protocol freezing with per-file and bundle hashes.
- Gate dependency DAG enforcement; no out-of-order PASS.
- HMAC-SHA256 opaque IDs with private key rather than reversible public-salt hashing.
- Nonced reveal commitments.
- Mandatory blind-tree contamination scan, including `.tex`.
- Strict backend certification: requested/actual backend and authority must match.
- Deterministic output ZIPs and clean-source checks.
- Added human/machine scientific contract and mandatory LaTeX falsifier report.
