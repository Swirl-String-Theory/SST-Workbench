# Changelog

## v0.2.0 — explicit closed-thread physics upgrade

- Replaced v0.1.0 radial potential-flow and affine-strain proxies with explicit closed vortex filaments.
- Added local large-source-radius bundle approximation appropriate to Earth-/Sun-like source directions.
- Added remote return-flux closures and G5 near/mid/far locality convergence.
- Added multi-step midpoint RK2 evolution with knot self-induced velocity recomputed every substep.
- Added primary + secondary nonparallel bundle case.
- Added circulation-weight thread-density gradient case.
- Added shared hidden orientation set across every topology.
- Added fixed core radii based on a resolution-independent reference \(R_g\).
- Added G10 resolution convergence classification.
- Added C++17 `filament_velocity` and full `evolve_frozen_background` kernels.
- Retained pure-Python reference implementation and strict native-vs-Python selftest.
- Added `run_all_highres.cmd` and `config/highres.json`.
- Kept bridge claims epistemically separate from structural/covariance claims.
