from __future__ import annotations
import argparse, copy, json, shutil, time
from pathlib import Path
from sst_thread_falsifier.campaign import run_full

def rel(a,b,floor=1e-14): return abs(a-b)/max(abs(a),abs(b),floor)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",default="config/extended.json")
    ap.add_argument("--dataset",default=r"..\..\KnotPlot\knots\final")
    ap.add_argument("--out",default=None)
    ap.add_argument("--force-python",action="store_true")
    ap.add_argument("--skip-build",action="store_true")
    ap.add_argument("--overwrite",action="store_true")
    a=ap.parse_args(); cfg=json.loads(Path(a.config).read_text(encoding="utf-8")); ladder=list(cfg.get("resample_ladder",[128,256,512]))
    out=Path(a.out or f"outputs_extended_{time.strftime('%Y%m%d_%H%M%S')}")
    if out.exists() and a.overwrite: shutil.rmtree(out)
    out.mkdir(parents=True,exist_ok=True); reports=[]
    for n in ladder:
        c=copy.deepcopy(cfg); c["resample_n"]=int(n); c.pop("resample_ladder",None); c.pop("temporal_steps_ladder",None)
        cp=out/f"config_N{n}.json"; cp.write_text(json.dumps(c,indent=2),encoding="utf-8")
        reports.append((int(n),run_full(cp,a.dataset,out/f"N{n}",a.force_python,a.skip_build)))
    by_path={}
    for n,rep in reports:
        for d in rep["datasets"]:
            g=d["gates"]
            by_path.setdefault(d["source_path"],[]).append({
                "N":n,"overall_v020_status":d["overall_v020_status"],"structural_status":d["structural_status"],"thread_model_status":d["thread_model_status"],
                "radial_orientation_mean":g["G9_orientation_ensemble"]["mean"],"boost_null":g["G1_common_boost_covariance"]["shape_rms_over_rg"],
                "return_relative":g["G6_return_flux_independence"]["relative_to_main_response"],"source_limit_far":g["G7_radial_to_parallel_source_distance_limit"]["far_source_vs_parallel"]})
    std=float(cfg.get("spatial_convergence_standard_tol",0.02)); cert=float(cfg.get("spatial_convergence_certified_tol",0.005)); rows=[]
    for p,rr in by_path.items():
        rr=sorted(rr,key=lambda x:x["N"]); change=None; tier="INSUFFICIENT"
        if len(rr)>=2:
            change=rel(rr[-2]["radial_orientation_mean"],rr[-1]["radial_orientation_mean"])
            tier="CERTIFIED_PASS" if change<=cert else ("STANDARD_PASS" if change<=std else "FAIL")
        model_ok=all(x["overall_v020_status"]=="PASS" for x in rr)
        status="PASS" if model_ok and tier in ("CERTIFIED_PASS","STANDARD_PASS") else "FAIL"
        rows.append({"source_path":p,"rows":rr,"highest_two_orientation_mean_relative_change":change,"standard_tol":std,"certified_tol":cert,"convergence_tier":tier,"status":status})
    overall="PASS" if rows and all(x["status"]=="PASS" for x in rows) else "FAIL"
    summary={"overall_extended_status":overall,"ladder":ladder,"fixed_core_radius_rg":cfg["knot_core_radius_rg"],"spatial_convergence":rows,
             "interpretation":"All N use the same knot_core_radius/Rg and the same final geometric time. PASS requires v0.2.0 structural+thread-model gates at each N and <=2% convergence of orientation-averaged explicit-thread response between the highest two N. <=0.5% is CERTIFIED_PASS."}
    (out/"extended_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps({"out":str(out),"overall_extended_status":overall,"ladder":ladder,"datasets":len(rows)},indent=2)); raise SystemExit(0 if overall=="PASS" else 2)
if __name__=="__main__": main()
