# SST chi-phase package v8 — alpha/beta ring-constant derivation audit

This package is the v8 successor to the chi-phase profile sequence.  It does
**not** claim to derive the absolute vortex-ring core constant \(\alpha\) from a
first-principles SST/NLSE core equation.  Instead it derives the robust thin-ring
Hamiltonian relation between the legacy constants \(\alpha\) and \(\beta\), then
compares the legacy table from `notebook_2015_paginas_49_51.tex` with the v6
smooth-matched \(\chi\)-closure root.

## Key derivation

The legacy note uses

\[
E = \frac12\rho\Gamma^2R\left[\ln\left(\frac{8R}{a}\right)-\alpha\right],
\]

\[
V = \frac{\Gamma}{4\pi R}\left[\ln\left(\frac{8R}{a}\right)-\beta\right].
\]

Let

\[
q:=\frac{d\ln a}{d\ln R}.
\]

Using the vortex-ring impulse

\[
P=\rho\Gamma\pi R^2
\]

and \(V=dE/dP\), one obtains

\[
\boxed{\beta=\alpha-1+q.}
\]

Therefore:

- fixed core radius / constant-pressure-like constraint: \(q=0\), hence \(\beta=\alpha-1\);
- constant toroidal core volume \(R a^2=\mathrm{const}\): \(q=-1/2\), hence \(\beta=\alpha-3/2\).

This reproduces the legacy notebook relations.

## Relation to v6

v6 selected the smooth-matched polynomial closure root

\[
a_0^* = \frac{\sqrt{385}-13}{4}\approx1.6553542176
\]

from \(c_\chi/v_{ref}=1\).  v8 compares this number against:

- nonlinear Schrödinger target \((\alpha,\beta)=(1.61,0.61)\),
- golden ratio \(\varphi\approx1.61803\),
- classical table targets \(1,3/2,7/4,2\).

The NLS target lies on \(q=0\) exactly because \(0.61=1.61-1\), but this package
does not derive \(\alpha=1.61\).  It only checks the relation structure and the
numerical proximity to the v6 closure root.

## Run

```powershell
python simulate_chi_phase_v8.py
python simulate_chi_phase_v8.py --python
python sst_chi_phase_v8_build.py --force
```

## Status

Research Track audit package.  It is canon-safe for the relation

\[
\beta=\alpha-1+q,
\]

but not yet canon-safe for an absolute prediction of \(\alpha\) or \(\beta\)
without an independent SST/NLSE core equation.
