# KnotPlot 3.1 Missing-Parameter Command Certification v0.2.0

This is deliberately **not** another full MultiDynamics/catalog campaign.
It only repairs the knowledge gap left by the previous run for four controls:

- `charge`
- `hooke`
- `power`
- `timeincr`

The earlier force-ablation, bend/`bencon`, `close`, and `max-dr` results are left untouched.

## Why this package is small

The previous logs showed the four controls above as rejected in that historical run. The current KnotPlot manual documents them as numeric relaxation commands using **no equal sign** (`charge value`, `hooke value`, `power value`, `timeincr value`). This package therefore certifies the command path experimentally before treating any sweep as science.

Official command reference: https://knotplot.com/manual/commands.html

## Design

Common preparation for all candidates (followed by exactly one of `charge value`, `hooke value`, `power value`, or `timeincr value`):

```text
reset all
load 3.1
refine nbeads 300
mode cb
centre
fitto mindist 1.05
collision fast
close = 1
max-dr = 0.01
mechforce = on
elecforce = on
bendforce = off
bencon = 1
```

Each certification candidate explicitly sets **only the parameter under test**. The other three uncertain controls remain at KnotPlot's `reset all` defaults. This deliberately prevents one rejected command from contaminating another command's certification.

| parameter | min | baseline | max |
|---|---:|---:|---:|
| charge | 3.75 | 15 | 60 |
| hooke | 0.25 | 1 | 4 |
| power | 4 | 6 | 8 |
| timeincr | 3.75 | 15 | 30 |

### Stage A — certification

12 short candidates, checkpoints `i00000` and `i00100`.
A family is `CERTIFIED_EFFECTIVE` only if:

1. KnotPlot does not reject the swept command;
2. all three candidates have the same parsed XYZ geometry at `i00000`;
3. the three `i00100` states are not all identical and have non-zero aligned RMS separation.

Other possible statuses:

- `ACCEPTED_NO_EFFECT_AT_100`
- `REJECTED_BY_KNOTPLOT`
- `INVALID_NONCOMMON_START`
- `RUN_FAILED`

### Stage B — 1000-iteration sensitivity

Only `CERTIFIED_EFFECTIVE` families are rerun to `i01000`. The analyzer reports length, radius of gyration, turning-angle statistics, unique hashes and Kabsch-aligned min→max RMS.

## Running

Place/extract this folder directly under the same KnotPlot workspace that contains `KnotPlot.lnk`, e.g.

```text
C:\workspace\projects\SST-Workbench\KnotPlot\
    KnotPlot.lnk
    KnotPlot_3p1_MissingParameter_Command_Certification_v0.2.0\
```

First verify the package itself:

```bat
run_dry.cmd
```

Then one click:

```bat
run_all.cmd
```

Or staged:

```bat
run_00_certify.cmd
run_10_analyze_certification.cmd
run_20_extended_certified.cmd
run_30_analyze_extended.cmd
run_90_pack_outputs.cmd
```

## Important runtime choice

This intentionally uses the **same successful invocation pattern as the historical v0.1.1 campaign**:

```text
KnotPlot.exe -nog
```

with stdin redirected from each KPC and the shortcut's `Start in` directory as CWD. It does **not** use the later catalogue/read-path preflight machinery.

## Outputs

```text
logs/cert/*.log
logs/cert/*.audit.json
out/cert/*.k + *.txt
analysis/CERTIFICATION.json
analysis/CERTIFICATION.md

logs/extended/*.log
out/extended/*.k + *.txt
analysis/EXTENDED.json
analysis/EXTENDED.md
```

At the end, `run_all.cmd` automatically creates `KnotPlot_3p1_MissingParameter_Command_Certification_v0.2.0_outputs.zip`. Send that ZIP back for analysis.
