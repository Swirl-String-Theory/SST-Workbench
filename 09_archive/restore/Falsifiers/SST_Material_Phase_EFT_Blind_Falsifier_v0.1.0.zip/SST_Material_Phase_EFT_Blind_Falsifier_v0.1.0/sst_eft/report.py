from __future__ import annotations
import csv, json, pathlib

def _plots(out: pathlib.Path, r: dict):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return
    pdir=out/"plots"; pdir.mkdir(parents=True,exist_ok=True)
    by={g["gate"]:g for g in r["gates"]}
    g3=by.get("G3",{})
    rows=g3.get("rows",[])
    if rows:
        n=[x["n"] for x in rows]
        d0=[x["D0"]/rows[-1]["D0"] for x in rows]
        d2=[x["D2"]/rows[-1]["D2"] for x in rows]
        plt.figure(figsize=(7.2,4.5))
        plt.plot(n,d0,"o-",label="D0 / D0(highest N)")
        plt.plot(n,d2,"s-",label="D2 / D2(highest N)")
        plt.xscale("log",base=2); plt.xlabel("arclength samples N"); plt.ylabel("normalized invariant")
        plt.title(f"{r['blind_id']} derivative convergence"); plt.grid(True,alpha=0.25); plt.legend(); plt.tight_layout()
        plt.savefig(pdir/f"{r['blind_id']}_G3_convergence.png",dpi=160); plt.close()
    g1=by.get("G1",{})
    trials=g1.get("trials",[])
    if trials:
        names=[x["variant"] for x in trials]
        x=list(range(len(names)))
        plt.figure(figsize=(8.0,4.8))
        plt.plot(x,[max(v["D0_rel"],1e-16) for v in trials],"o-",label="D0 relative difference")
        plt.plot(x,[max(v["total_curvature_rel"],1e-16) for v in trials],"s-",label="total-curvature relative difference")
        plt.plot(x,[max(v["writhe_abs"],1e-16) for v in trials],"^-",label="writhe absolute difference")
        plt.yscale("log"); plt.xticks(x,names,rotation=45,ha="right"); plt.ylabel("invariance error")
        plt.title(f"{r['blind_id']} reparameterization robustness"); plt.grid(True,alpha=0.25); plt.legend(); plt.tight_layout()
        plt.savefig(pdir/f"{r['blind_id']}_G1_relabel.png",dpi=160); plt.close()

def write_report(outdir, cfg, results, lock):
    out=pathlib.Path(outdir); (out/"per_blind").mkdir(parents=True,exist_ok=True)
    rows=[]
    for r in results:
        (out/"per_blind"/f"{r['blind_id']}.json").write_text(json.dumps(r,indent=2),encoding="utf-8")
        _plots(out,r)
        g={x["gate"]:x["status"] for x in r["gates"]}
        rows.append({"blind_id":r["blind_id"],"overall":r["overall"],**g})
    with (out/"blind_summary.csv").open("w",newline="",encoding="utf-8") as f:
        fields=["blind_id","overall","G1","G2","G3","G4","G5"]
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    counts={}
    for r in rows: counts[r["overall"]]=counts.get(r["overall"],0)+1
    md=["# Blind campaign report","",f"Config SHA256: `{lock['config_sha256']}`",f"Accepted curves: {lock['accepted']}","","## Locked verdict counts",""]
    md += [f"- {k}: {v}" for k,v in sorted(counts.items())]
    md += ["","## Interpretation","","G1 and G3 are empirical static-geometry gates. G2 and G4 are structural invariance/redundancy gates. G5 is only empirical when an SI mode table is present. A `PARTIAL_STATIC_PASS_NO_MODE_DATA` is **not** a validation of SST phase-clock dynamics."]
    (out/"BLIND_REPORT.md").write_text("\n".join(md)+"\n",encoding="utf-8")
    locked={"config_sha256":lock["config_sha256"],"verdicts":rows}
    (out/"LOCKED_VERDICTS.json").write_text(json.dumps(locked,indent=2),encoding="utf-8")
