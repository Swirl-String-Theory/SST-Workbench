#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fig. 1e — data points with axes, fully boxed panel (no extra ticks).
The CSV contains the final plotted x, y, and y-error values, so this script
performs no data selection, centering, or normalization.

Plot style:
  - all four spines (bottom / left / top / right) are shown;
  - no ticks on the top and right spines (only bottom & left ticks);
  - unit "kHz" placed above the right end of the x-axis;
  - small figure size, fixed ticks.
12K data only (b_12k/ interval data): blue open circles with error bars.

Dataset layout (Fig1e):
  Fig1e/
    data/    fig1e_12kmod.csv   (plot-ready data)
    code/    fig1e_plot.py      (this script)
    results/ fig1e.png / fig1e.pdf   (outputs)
Paths below are adapted to this layout (data/ and results/).
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager

# ============================================================
# Font: Matplotlib's bundled DejaVu Sans, embedded as TrueType in PDF
# ============================================================
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]
plt.rcParams["pdf.fonttype"] = 42  # embed TrueType fonts in PDF
plt.rcParams["mathtext.fontset"] = "dejavusans"
plt.rcParams["axes.unicode_minus"] = False   # use ASCII hyphen in tick labels
plt.rcParams["axes.linewidth"] = 0.5   # spine (axes border) width — adjust here

# ============================================================
# Paths (adapted to the Fig1e dataset layout)
# ============================================================
BASE = os.path.dirname(os.path.abspath(__file__))
D12 = os.path.join(BASE, "..", "data")
FIG_DIR = os.path.join(BASE, "..", "results")
os.makedirs(FIG_DIR, exist_ok=True)

C12 = "#5079BA"   # blue — 12 K
MEW = 0.8          # circle edge width — independent of spine width
FIGW, FIGH = 3.65/2.54, 4.2/2.54   # small-panel figure size (inches)
EXPORT_PAD_INCHES = 0.02  # protects the outer half of the boxed spines

# ============================================================
# Load the three plot-ready columns
# ============================================================
DATA_FILE = os.path.join(D12, "fig1e_12kmod.csv")
COLUMNS = [
    "Frequency_offset_kHz",
    "Normalized_signal",
    "Normalized_signal_error",
]

df = pd.read_csv(DATA_FILE)
if list(df.columns) != COLUMNS:
    raise ValueError(f"Expected exactly these CSV columns: {COLUMNS}")

df = df.apply(pd.to_numeric, errors="raise").sort_values(COLUMNS[0])
if df.isna().any().any():
    raise ValueError("The plotting CSV contains missing values.")
if (df[COLUMNS[2]] < 0).any():
    raise ValueError("Normalized_signal_error must be non-negative.")

off12 = df[COLUMNS[0]].to_numpy(dtype=float)
disp12 = df[COLUMNS[1]].to_numpy(dtype=float)
err12 = df[COLUMNS[2]].to_numpy(dtype=float)
print(f"Loaded {len(df)} plot points from {DATA_FILE}")

# ============================================================
# Plot — data points with axes, fully boxed panel
# ============================================================
fig, ax = plt.subplots(figsize=(FIGW, FIGH))

# 12K blue points with error bars (open circles)
ax.errorbar(off12, disp12, yerr=err12,
            fmt="o", ms=2, capsize=0,
            color=C12, ecolor=C12,
            elinewidth=0.5, zorder=3,
            mfc="none", mew=MEW)  # circle edge width set by MEW above

# Ranges and ticks
#   x range includes every selected point within +-150 kHz.
XLIM = (-135, 135)
YLIM = (-1.0, 1.0)
XTICKS = [-100, 0, 100]
YTICKS = [-1, 0, 1]
ax.set_xlim(*XLIM)
ax.set_ylim(*YLIM)
ax.set_xticks(XTICKS)
ax.set_yticks(YTICKS)

# Boxed panel: all four spines visible, but ticks only on bottom & left
ax.tick_params(direction="in", top=False, right=False, labelsize=7,
               width=plt.rcParams["axes.linewidth"])  # ticks same width as spines

# Label: unit above the right end of the x-axis.
ax.annotate("kHz", xy=(1, 0), xycoords="axes fraction",
            xytext=(-3, 3), textcoords="offset points",
            ha="right", va="bottom", fontsize=8)

# ============================================================
# Save with a small physical margin so tight cropping does not clip the box.
# ============================================================
out_png = os.path.join(FIG_DIR, "fig1e.png")
out_pdf = os.path.join(FIG_DIR, "fig1e.pdf")

fig.savefig(out_png, dpi=600, transparent=True,
            bbox_inches="tight", pad_inches=EXPORT_PAD_INCHES)
fig.savefig(out_pdf, transparent=True,
            bbox_inches="tight", pad_inches=EXPORT_PAD_INCHES)
plt.close(fig)

print(f"\nSaved: {out_png}")
print(f"       {out_pdf}")
