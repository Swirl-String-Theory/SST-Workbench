# Swirl-EM Bridge and relational link-field ontology

## Slide 1/15 - Why EM bridge is separate

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Material vorticity and link-field torsion are distinct.
- Photon/R-phase excitations belong to the free transverse sector.
- EM fields are effective bridge variables.

**Single slide message:** Material vorticity and link-field torsion are distinct.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 2/15 - Minimal transverse field sector

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- A_eff represents transverse torsion/director response.
- It supports wave propagation under an effective action.
- It is not compressional sound.

**Single slide message:** A_eff represents transverse torsion/director response.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 3/15 - Photon / unknot sector

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Photon-like excitation is a free R-phase/link pulse.
- It need not be a closed material knot.
- It should not leave permanent material circulation.

**Single slide message:** Photon-like excitation is a free R-phase/link pulse.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 4/15 - R-to-T closure threshold

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Radiation-to-bound transitions require closure gates.
- Conservation bookkeeping is mandatory.
- Transition claims remain bridge/research until derived.

**Single slide message:** Radiation-to-bound transitions require closure gates.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 5/15 - Swirl pressure law

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Pressure gradients mediate effective acceleration.
- Exact incompressible pressure is a constraint field.
- Causal interpretation needs torsion/clock dynamics.

**Single slide message:** Pressure gradients mediate effective acceleration.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 6/15 - Lorentz-type force as swirl stress

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Force density can be stress-like.
- The bridge must reproduce Lorentz-like effects without arbitrary sources.
- Direct vorticity sources are constrained/rejected where invalid.

**Single slide message:** Force density can be stress-like.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 7/15 - Minimal effective Lagrangian

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Kinetic and curl terms give transverse propagation.
- Speed follows from stiffness over inertia.
- This is the continuum limit of link action.

**Single slide message:** Kinetic and curl terms give transverse propagation.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 8/15 - Relational link-field interpretation

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Torsion lives on relations between elements.
- A_eff is coarse-grained link connection.
- curl A_eff is link curvature, not material vorticity.

**Single slide message:** Torsion lives on relations between elements.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 9/15 - Maxwell-Faraday reconstruction

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Curl equations can arise from connection definitions.
- Response coefficients provide speed and impedance.
- EM-like behavior must be derived, not renamed.

**Single slide message:** Curl equations can arise from connection definitions.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 10/15 - No acoustic light in exact SST

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Exact incompressibility removes ordinary longitudinal sound.
- Luminal candidate is transverse torsion/link response.
- Analogue methods require the correct operator.

**Single slide message:** Exact incompressibility removes ordinary longitudinal sound.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 11/15 - Energy and Poynting-like flow

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Link-field sector carries energy density and flux.
- Poynting-like form belongs to effective EM bridge.
- Energy transport need not create new material vortices.

**Single slide message:** Link-field sector carries energy density and flux.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 12/15 - Charge/source problem

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Topological source Q0 must be derived or defined.
- It cannot equal e in zero-legacy mode by fiat.
- Gauss-like source laws are bridge targets.

**Single slide message:** Topological source Q0 must be derived or defined.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 13/15 - Free-sector impedance

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Z_link = sqrt(mu_l/epsilon_l) is the impedance target.
- c_T = 1/sqrt(epsilon_l mu_l) is the speed target.
- Speed and impedance are different combinations of response.

**Single slide message:** Z_link = sqrt(mu_l/epsilon_l) is the impedance target.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 14/15 - EM bridge falsifiers

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Longitudinal physical photon mode would fail the bridge.
- Low-energy non-monometricity threatens Lorentz universality.
- Target-constant source normalization invalidates zero-legacy derivation.

**Single slide message:** Longitudinal physical photon mode would fail the bridge.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.

## Slide 15/15 - EM/link closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Matter is finite-core bound structure.
- Light is free transverse link-field pulse.
- Coupling is impedance and transition response.

**Single slide message:** Matter is finite-core bound structure.

**Source anchors:** Swirl-EM Bridge; Minimal Relational Link-Field Action; Genesis impedance path.

**Visual specification:** Two-layer diagram: material vortex field and relational link field.

**Do not generate:** Do not call link curvature material vorticity, and do not import acoustic sound.
