#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sst_dark_knot_harness.taxonomy import (
    apply_mirror,
    compute_record,
    run_taxonomy_checks,
    taxonomy_sector,
    validate_record_light,
)


def main() -> int:
    rec3 = compute_record("3_1", prefer_snappy=False)
    rec4 = compute_record("4_1", prefer_snappy=False)
    assert not validate_record_light(rec3)
    assert not validate_record_light(rec4)
    assert rec3["vol_hyperbolic"] is None
    assert rec4["hvol_norm"] == 1.0
    assert rec4["hvol_signed"] == 0.0
    assert apply_mirror(rec3)["sigma_chi"] == -1
    assert apply_mirror(rec4)["sigma_chi"] == 0
    assert taxonomy_sector(rec3)["sector"] == "lepton_track"
    assert taxonomy_sector(rec4)["sector"] == "inert_neutrino_candidate"
    checks = run_taxonomy_checks()
    assert checks["ok"], checks
    print("taxonomy light checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
