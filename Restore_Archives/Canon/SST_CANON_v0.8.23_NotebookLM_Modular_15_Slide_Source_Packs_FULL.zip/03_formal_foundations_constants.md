# Formal Foundations - primitives, closures, and canonical scales

## Slide 1/15 - Primitive structure

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Incompressible, inviscid substrate description.
- Vortex filaments and circulation sectors carry topology.
- Canonical constants are anchors unless independently derived.

**Single slide message:** Incompressible, inviscid substrate description.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 2/15 - Core and horn discipline

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- r_c is the localized core radius.
- Horn/envelope radius is derived or contextual.
- Scale confusion creates false closure.

**Single slide message:** r_c is the localized core radius.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 3/15 - Circulation quantization

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Discrete circulation supplies hydrodynamic labels.
- Gamma_0 is a circulation scale.
- Its numerical provenance matters for c or alpha claims.

**Single slide message:** Discrete circulation supplies hydrodynamic labels.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 4/15 - Bounded-domain Biot-Savart

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Velocity reconstruction depends on domain assumptions.
- Boundaries can introduce artifacts.
- Tests must record boundary conditions.

**Single slide message:** Velocity reconstruction depends on domain assumptions.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 5/15 - Hodge decomposition

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Velocity needs exact, coexact, and harmonic/circulation parts.
- Local curl alone is insufficient.
- Topology metadata is required.

**Single slide message:** Velocity needs exact, coexact, and harmonic/circulation parts.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 6/15 - Energy and mass relation

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Mass is localized/trapped energy.
- rho_E and rho_m need c^2 bookkeeping.
- Geometry-density chains need dimensional checks.

**Single slide message:** Mass is localized/trapped energy.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 7/15 - Swirl velocity constraint

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- v_swirl is bound characteristic swirl speed.
- It is not automatically free torsion speed c_T.
- Its ratio to c_T is central to alpha/impedance hypotheses.

**Single slide message:** v_swirl is bound characteristic swirl speed.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 8/15 - Swirl-clock definition

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Clock rate depends on carrier-local motion and internal structure.
- Internal swirl and external motion must not be merged.
- Axiom 7 formalizes operational clocking.

**Single slide message:** Clock rate depends on carrier-local motion and internal structure.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 9/15 - Density hierarchy

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- rho_f: effective fluid density.
- rho_E: swirl energy density.
- rho_m = rho_E/c^2: mass-equivalent density.

**Single slide message:** rho_f: effective fluid density.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 10/15 - Chronos-Kelvin invariant

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Kelvin circulation constrains transport.
- Clock-radius transport must respect topology.
- Reconnection needs explicit gates.

**Single slide message:** Kelvin circulation constrains transport.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 11/15 - Canonical master equation

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Organizes topology, geometry, density, and mass.
- It is a dependency skeleton, not a fitting machine.
- Every kernel/gate needs status.

**Single slide message:** Organizes topology, geometry, density, and mass.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 12/15 - Geometric representation

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Closed curves, tubes, and envelopes define carrier shapes.
- Geometric proxies require certification before physics.
- Connects to KnotPlot/Ridgerunner.

**Single slide message:** Closed curves, tubes, and envelopes define carrier shapes.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 13/15 - Dependency summary

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Primitive symbols feed closures.
- Calibrated anchors feed consistency tests.
- Predictions must be downstream of inputs.

**Single slide message:** Primitive symbols feed closures.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 14/15 - Maximal swirl tension

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- F_swirl^max is a canonical tension scale.
- Its provenance matters.
- It can be calibration or validation depending on context.

**Single slide message:** F_swirl^max is a canonical tension scale.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.

## Slide 15/15 - Foundations closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Foundations define variables, scales, dimensions, and dependencies.
- They prepare the axiom layer.
- They block speed/radius/density conflation.

**Single slide message:** Foundations define variables, scales, dimensions, and dependencies.

**Source anchors:** Formal Foundations; Genesis dependency rules.

**Visual specification:** Stacked foundation blocks with dimension and dependency arrows.

**Do not generate:** Do not use one speed/radius/density symbol for multiple concepts.
