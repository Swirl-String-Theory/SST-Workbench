# A044 v0.2.0 blind report

**Verdict:** `BLIND_WINDOWS_FROZEN`

The blind phase did not read SST constants or candidate identity.

## Published observability gates

- Conventional expected count: ~`1.0e-96` vs 5% one-event threshold `0.05129329` -> **FAIL**.
- ALP-only upper expected count: ~`1.0e-04` -> **FAIL**.

## Constraint windows

| class | primary lower [GeV] | upper [GeV] | status |
|---|---:|---:|---|
| n1_nonbirefringent | 0.000000e+00 | 1.220000e+21 | PASS |
| n1_birefringent | 3.600000e+34 | 1.220000e+21 | FAIL |
| n2_nonbirefringent | 0.000000e+00 | 2.030000e+13 | PASS |
| n2_birefringent | 1.300000e+11 | 2.030000e+13 | PASS |

## Derived diagnostics

- n=1: at 300 TeV the head-on soft-photon threshold moves from 8.703998e-04 eV to 1.931302e-02 eV at the published transparency upper scale (uplift ×22.2).
- n=2: at 300 TeV the head-on soft-photon threshold moves from 8.703998e-04 eV to 1.725032e-02 eV at the published transparency upper scale (uplift ×19.8).
- n=1: simple common-emission TOF inversion gives E* = [4.820151e+18, 5.708352e+18] GeV for the observed LHAASO-to-Carpet delay window; this is conditional, not a hard bound.
- n=2: simple common-emission TOF inversion gives E* = [1.553189e+12, 1.690244e+12] GeV for the observed LHAASO-to-Carpet delay window; this is conditional, not a hard bound.

SST comparison is intentionally deferred to reveal.
