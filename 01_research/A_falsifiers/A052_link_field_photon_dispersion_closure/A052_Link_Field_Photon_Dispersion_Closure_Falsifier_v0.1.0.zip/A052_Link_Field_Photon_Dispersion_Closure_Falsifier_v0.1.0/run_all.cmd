@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist .venv py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pytest -q
python -m a052_lfpdcf.run --mode all --root . --outputs outputs
powershell -NoProfile -Command "if(Test-Path '..\A052_Link_Field_Photon_Dispersion_Closure_Falsifier_v0.1.0-outputs_BLIND.zip'){Remove-Item '..\A052_Link_Field_Photon_Dispersion_Closure_Falsifier_v0.1.0-outputs_BLIND.zip' -Force}; Compress-Archive -Path 'outputs\blind\*' -DestinationPath '..\A052_Link_Field_Photon_Dispersion_Closure_Falsifier_v0.1.0-outputs_BLIND.zip' -Force"
powershell -NoProfile -Command "if(Test-Path '..\A052_Link_Field_Photon_Dispersion_Closure_Falsifier_v0.1.0-outputs_REVEALED.zip'){Remove-Item '..\A052_Link_Field_Photon_Dispersion_Closure_Falsifier_v0.1.0-outputs_REVEALED.zip' -Force}; Compress-Archive -Path 'outputs\revealed\*' -DestinationPath '..\A052_Link_Field_Photon_Dispersion_Closure_Falsifier_v0.1.0-outputs_REVEALED.zip' -Force"
endlocal
