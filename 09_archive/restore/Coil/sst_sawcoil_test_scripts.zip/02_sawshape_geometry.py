from __future__ import annotations
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_sawcoil_common import SawShapeParams, build_three_phase_sawshape, write_csv


def main() -> None:
    ap = argparse.ArgumentParser(description="Build and plot 3-phase SawShape coil geometry.")
    ap.add_argument("--slots", type=int, default=40)
    ap.add_argument("--fwd", type=int, default=11)
    ap.add_argument("--back", type=int, default=-9)
    ap.add_argument("--pairs", type=int, default=20)
    ap.add_argument("--radius", type=float, default=0.05, help="constant coil radius [m]")
    ap.add_argument("--radius-top", type=float, default=None, help="top radius for bowl [m]")
    ap.add_argument("--height", type=float, default=0.0, help="bowl height [m]")
    ap.add_argument("--profile", choices=["linear", "exponential", "inverse_exponential"], default="linear")
    ap.add_argument("--samples", type=int, default=12)
    ap.add_argument("--outdir", default="/mnt/data/sawcoil_out")
    args = ap.parse_args()

    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    rt = args.radius if args.radius_top is None else args.radius_top
    params = SawShapeParams(
        slots=args.slots, step_forward=args.fwd, step_backward=args.back, n_pairs=args.pairs,
        radius_bottom=args.radius, radius_top=rt, height=args.height,
        profile=args.profile, samples_per_segment=args.samples,
    )
    coils = build_three_phase_sawshape(params)

    for i, pts in enumerate(coils):
        rows = [[k, *row] for k, row in enumerate(pts)]
        write_csv(outdir / f"sawshape_phase_{i+1}.csv", ["i", "x_m", "y_m", "z_m"], rows)

    fig = plt.figure(figsize=(7.5, 7.0))
    ax = fig.add_subplot(111, projection="3d")
    for i, pts in enumerate(coils):
        ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], lw=1.7, label=f"phase {i+1}")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]"); ax.set_zlabel("z [m]")
    ax.set_title(f"3-phase SawShape S={args.slots}, +{args.fwd},{args.back}")
    ax.legend()
    lim = max(args.radius, rt) * 1.15
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
    if args.height == 0:
        ax.set_zlim(-lim, lim)
    plt.tight_layout()
    png_path = outdir / "sawshape_geometry.png"
    plt.savefig(png_path, dpi=160); plt.close()
    print(f"Wrote phase CSVs and {png_path}")


if __name__ == "__main__":
    main()
