# Parallel Research Plan v0.0.5

## Branch A — correlation spectrum

1. Measure the covariance operator of boundary piercing/mode observables in
   vacuum simulations.
2. Diagonalize the covariance in the pulse-coupled signal sector.
3. Measure the relative-entropy rate and compare it with the channel-capacity
   rate.
4. Reject any enhancement that requires unbooked hidden modes or singular
   covariance under refinement.

## Branch B — internal topological alphabet

1. Specify which protected labels exist at a single boundary channel: winding,
   framing, chirality, compact-link flux, braid sector, or another invariant.
2. Prove finiteness and derive the state count from the action and boundary
   conditions.
3. Measure transition barriers and verify that labels are dynamically usable on
   the Route-I timescale.
4. Separate centreline knot complexity from genuine internal field topology.

## Branch C — sub-core boundary spectrum

1. Select exactly one microscopic adjacency scenario from the Research Track.
2. Derive the UV spectral density and Weyl coefficient without fitting G.
3. Demonstrate positive energy, stable refinement, deconfinement, isotropy, and
   a finite correlation cone.
4. Calculate the resulting eta_A and compare with the gravitational audit only
   after all parameters are frozen.

## Merge gate

The branches merge only through

\[
\eta_{\rm cap}=n_{\rm ch}h_{\rm rate},
\qquad
\eta_{\rm rel}=n_{\rm ch}d_{\rm rate}.
\]

A successful model must satisfy both the coefficient and reversible-capacity
gates without reusing the same hidden degree of freedom in more than one
branch.
