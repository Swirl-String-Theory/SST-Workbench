# KnotPlot 3.1 Multi-Dynamics Relaxation Matrix v0.1.0

Goal: generate a controlled ensemble of relaxed trefoil geometries so that downstream
Euler / finite-core Biot-Savart / RPO / Floquet stability can be compared without
confounding force parameters.

## Fixed baseline

- seed: `load 3.1`
- beads: `nbeads 300`
- normalization: `fitto mindist 1.05`
- collision: `fast`
- close: 1.0
- max-dr: 0.01
- mechanical: on
- electric: on
- bending: on
- charge: 15
- Hooke: 1
- power: 6
- time increment: 15
- bencon: 1
- stusplit: 0
- dstep: 1
- bradius: 0.1
- cradius: 0.05
- energy model: MD

The explicit values `charge=15`, `hooke=1`, `timeincr=15`, `power=6` match the
values shown in KnotPlot's documented dynamics panel. They are written explicitly
so that a reset or installation-default change cannot silently change a campaign.

## Why `nbeads 300` instead of `refine nbeads 300`

The KnotPlot manual defines `nbeads value` as setting an absolute bead count, whereas
`refine N` multiplies the current bead count by N. For a controlled matrix we therefore
use `nbeads 300`.

## Why `ago`

`go N` runs relaxation in the background. `ago N` performs the requested number of
iterations atomically. Using `ago` guarantees that the following `save` is a true
checkpoint after the intended iteration count.

## Checkpoints

Most candidates save at cumulative iterations:

- 0
- 1,000
- 4,000
- 10,000

Each checkpoint writes:

- KnotPlot float geometry: `*.k`
- coordinate export: `*.txt`

The command window also computes MD energy, writhe, length, radius of gyration,
and the Alexander determinant (`alex -1`) at checkpoints.

## Families

- `10_force_ablation_matrix.kpc`: M / ME / MB / MEB
- `20_charge_sweep_ME.kpc`: q = 3.75, 7.5, 15, 30, 60
- `30_bend_sweep_MB.kpc`: bencon = 0.25, 0.5, 1, 2, 4
- `40_power_sweep_ME.kpc`: power = 4, 5, 6, 7, 8
- `50_close_sweep_MEB.kpc`: close = 0.50, 0.65, 0.80, 0.95, 1.00
- `60_hooke_sweep_ME.kpc`: Hooke = 0.25, 0.5, 1, 2, 4
- `70_maxdr_sweep_MEB.kpc`: max-dr = 0.0025, 0.005, 0.01, 0.02, 0.04
- `80_timeincr_sweep_MEB.kpc`: timeincr = 3.75, 7.5, 15, 22.5, 30
- `90_charge_anneal_MEB.kpc`: q = 60 -> 30 -> 15 -> 7.5 -> 0

## Recommended execution

For the scientifically most informative first pass:

    < 98_run_core_matrix.kpc

For the complete matrix:

    < 99_run_all_matrix.kpc

Or use `run_core.cmd` / `run_all.cmd` if `knotplot.exe` is on PATH.

## Interpretation

KnotPlot dynamics are candidate-generation dynamics only. Do NOT identify the
lowest KnotPlot MD energy with SST hydrodynamic stability.

After generation, all candidate geometries should be:
1. uniformly resampled in arc length,
2. normalized identically,
3. assigned the same circulation and finite-core radius,
4. tested blind under the same Euler / finite-core Biot-Savart stability pipeline.

The key question is whether stable downstream candidates cluster around particular
KnotPlot preparation variables or dimensionless geometric observables.

## References

R. G. Scharein, *KnotPlot Manual*, current KnotPlot documentation.
https://knotplot.com/doc/KnotPlot-Manual.pdf

R. G. Scharein, *Interactive Topological Drawing*, M.Sc. thesis,
University of British Columbia, 1998.
https://www.knotplot.com/thesis/thesis_letter.pdf

J. K. Simon, "Energy functions for polygonal knots",
Journal of Knot Theory and Its Ramifications 3 (1994), 299-320.
DOI: 10.1142/S0218216594000234
