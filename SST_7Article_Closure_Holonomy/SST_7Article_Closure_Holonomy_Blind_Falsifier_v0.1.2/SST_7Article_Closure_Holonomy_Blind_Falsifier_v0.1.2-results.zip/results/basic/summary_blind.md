# Blind summary

Mode: **basic**

Cases: **49**

## Overall opaque statuses

- INDETERMINATE: 49

A static-centerline-only `INDETERMINATE` is expected: absent phase/volume/probe data are never manufactured from geometry.

Dataset snapshot: `edf42d9c2fe543bd3015299745063fddbb3abc217886f165cdd5285100c6a35a`
Blind state: `edf42d9c2fe543bd30152997_h3000.json`
Freeze SHA-256: `560146f7bd1e8a2f06f9c0d0d480acffc982abbf8b13cf9cd519118cf04941de`
