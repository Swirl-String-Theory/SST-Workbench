# A055 v0.1.1 — REVEALED report

Blind seal verified: `d37edd603832556a922251128905ab1e3bd46eefad47f58d92ef743bad3cb1dd`.

## Historical VAM/SST quark check

Historical mapping: `u -> 5_2`, `d -> 6_1` (twist-knot pair).

- Raw diagnostic knot-space rank: **484/595** (fraction 0.813445).
- Raw diagnostic distance: **3.36886662**.
- Qualified knot-space rank: **484/595** (fraction 0.813445), distance 3.36886662.

Unlike v0.1.0, the scientific rank is withheld if either topology fails the preregistered resolution/CV gates.

## Exploratory SM mass-pattern reveal

- **charged_leptons**: best valid common all-atlas proxy `abs_neumann_energy` -> ['3_1', 'L8a21', 'L8n8']; log-RMS=2.0353; null fraction=0.227723; eligible cases=82.
- **up_quarks**: best valid common all-atlas proxy `abs_neumann_energy` -> ['3_1', 'L8n1', 'L8n8']; log-RMS=3.31489; null fraction=0.158416; eligible cases=82.
- **down_quarks**: best valid common all-atlas proxy `abs_neumann_energy` -> ['3_1', '7_6', 'L8n8']; log-RMS=1.47911; null fraction=0.039604; eligible cases=82.
- **massive_EW_Higgs**: best valid common all-atlas proxy `min_distance` -> ['L8a9', '8_20', '8_19']; log-RMS=0.000116554; null fraction=0.178218; eligible cases=82.

Each valid search uses **100** null targets at the same total log-mass span.  The intermediate log-position is randomized and the complete eligible triplet search is repeated analytically through the exact lower envelope of candidate error quadratics.  Full null values are stored in `SM_NULL_DISTRIBUTIONS.csv.gz`.

## v0.1.1 domain corrections

- `linking_strength` is **links only**. Knot values are never replaced by `1e-6` or any other artificial floor.
- `abs_writhe` is not used in mixed knot/link fits.
- `contact_ratio` is diagnostic only because it scales explicitly with segment resolution.
- `min_distance` after common length normalization replaces it as the contact observable.
- Zero/non-positive values required by a logarithmic ratio fit are excluded, not shifted.

## Mandatory interpretation limits

1. v0.1.1 does **not** identify a knot/link with an SM particle.
2. PD-derived embeddings are presentation ensembles, not PKLSA ideal/relaxed vortex equilibria.
3. Higgs spin-0/scalar dynamics, gauge charge, color, chirality, weak isospin, lifetime and couplings are **not tested**.
4. Quark masses are scheme/scale dependent; their reveal remains diagnostic only.
5. Promotion to v0.2.0 requires PKLSA/finite-core dynamical observables under the same blind/domain/convergence protocol.
