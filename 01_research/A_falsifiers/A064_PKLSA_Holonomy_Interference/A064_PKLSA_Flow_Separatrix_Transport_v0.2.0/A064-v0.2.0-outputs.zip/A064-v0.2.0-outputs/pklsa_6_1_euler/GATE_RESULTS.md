# A064 gate results
- Mode: `EULER_SIMULATION_MODEL`
- Evidence: `geometry_initialized_periodic_3d_euler_model`
- Discovery SHA-256: `ff3f1e58e1943334f3cc6ae80f854915e774a6245dc5a952be11cebf4446fe3f`
- Divergence (p95 dx/U): `0.00679`
- Candidate identified: `True`
- Feature status: `PERMEABLE_NONMATERIAL_FEATURE`
- True separatrix manifold gate: `UNRESOLVED_NOT_CONSTRUCTED`
- Overall: `CANDIDATE_FALSIFIED_AS_MATERIAL_AT_TESTED_SCALE`
