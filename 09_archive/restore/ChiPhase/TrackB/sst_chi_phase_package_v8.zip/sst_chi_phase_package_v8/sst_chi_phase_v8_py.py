#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SST chi-phase package v8: alpha/beta ring-constant derivation audit.

This module does NOT claim to derive the absolute vortex-ring core constant
alpha from a resolved SST/NLSE core equation.  It derives the robust Hamiltonian
relation between alpha and beta under a core-radius constraint and compares
legacy targets with the chi-phase smooth-matched closure root from v6.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple

PHI = (1.0 + math.sqrt(5.0)) / 2.0
A0_STAR = (math.sqrt(385.0) - 13.0) / 4.0

@dataclass(frozen=True)
class LegacyRingModel:
    name: str
    alpha: float
    beta: float
    q_expected: float | None
    source_note: str

LEGACY_MODELS: List[LegacyRingModel] = [
    LegacyRingModel("solid_core_constant_volume", 7.0 / 4.0, 1.0 / 4.0, -0.5, "notebook: vaste kern + constant volume"),
    LegacyRingModel("hollow_core_constant_volume", 2.0, 1.0 / 2.0, -0.5, "notebook: holle kern + constant volume"),
    LegacyRingModel("hollow_core_constant_pressure", 3.0 / 2.0, 1.0 / 2.0, 0.0, "notebook: holle kern + constante druk"),
    LegacyRingModel("hollow_core_surface_tension", 1.0, 0.0, 0.0, "notebook: holle kern + oppervlaktespanning"),
    LegacyRingModel("nonlinear_schrodinger", 1.61, 0.61, 0.0, "notebook: Non-lineaire Schrödinger"),
]

CONSTRAINTS: Dict[str, float] = {
    "fixed_core_radius_or_pressure": 0.0,
    "constant_toroidal_core_volume": -0.5,
    "expanding_core_example_q_plus_half": 0.5,
}


def beta_from_alpha_q(alpha: float, q: float) -> float:
    """Hamiltonian thin-ring scaling relation: beta = alpha - 1 + q."""
    return alpha - 1.0 + q


def alpha_from_beta_q(beta: float, q: float) -> float:
    """Inverse relation: alpha = beta + 1 - q."""
    return beta + 1.0 - q


def q_eff(alpha: float, beta: float) -> float:
    """Effective logarithmic core-radius scaling q = d ln a / d ln R implied by alpha,beta."""
    return beta - alpha + 1.0


def smooth_matched_c2_over_v2(a0: float) -> float:
    """v6 analytic closure curve for f_a0(x)=x[a0+(3-2a0)x^2+(a0-2)x^4]."""
    return (2.0 * a0 * a0 + 13.0 * a0 + 78.0) / 105.0


def smooth_matched_c_over_v(a0: float) -> float:
    return math.sqrt(smooth_matched_c2_over_v2(a0))


def smooth_matched_root_bisection(lo: float = 0.0, hi: float = 3.0, tol: float = 1e-15, max_iter: int = 200) -> float:
    """Solve smooth_matched_c2_over_v2(a0)-1=0."""
    def f(x: float) -> float:
        return smooth_matched_c2_over_v2(x) - 1.0
    flo = f(lo)
    fhi = f(hi)
    if flo * fhi > 0:
        raise ValueError("bisection bracket does not straddle root")
    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        fm = f(mid)
        if abs(fm) < tol or 0.5 * (hi - lo) < tol:
            return mid
        if flo * fm <= 0:
            hi = mid
            fhi = fm
        else:
            lo = mid
            flo = fm
    return 0.5 * (lo + hi)


def legacy_table_rows() -> List[Dict[str, float | str]]:
    rows = []
    for m in LEGACY_MODELS:
        q = q_eff(m.alpha, m.beta)
        row = {
            "name": m.name,
            "alpha": m.alpha,
            "beta": m.beta,
            "q_eff": q,
            "q_expected": "" if m.q_expected is None else m.q_expected,
            "beta_pred_from_expected_q": "" if m.q_expected is None else beta_from_alpha_q(m.alpha, m.q_expected),
            "beta_residual_expected_q": "" if m.q_expected is None else beta_from_alpha_q(m.alpha, m.q_expected) - m.beta,
            "c_over_v_if_a0_equals_alpha": smooth_matched_c_over_v(m.alpha),
            "alpha_minus_a0_star": m.alpha - A0_STAR,
            "note": m.source_note,
        }
        rows.append(row)
    return rows


def target_comparison_rows() -> List[Dict[str, float | str]]:
    targets = [
        ("a0_star_v6_closure", A0_STAR),
        ("phi", PHI),
        ("NLS_alpha_legacy", 1.61),
        ("smooth_default_a0_2", 2.0),
        ("gradient_energy_min_7_over_4", 7.0 / 4.0),
        ("curvature_energy_min_7_over_3", 7.0 / 3.0),
        ("shape_energy_min_1_over_2", 0.5),
    ]
    rows = []
    for name, a0 in targets:
        c2 = smooth_matched_c2_over_v2(a0)
        c = math.sqrt(c2)
        rows.append({
            "target": name,
            "a0_or_alpha": a0,
            "c2_over_v2": c2,
            "c_over_v": c,
            "c_over_v_minus_1": c - 1.0,
            "beta_if_alpha_and_q0": beta_from_alpha_q(a0, 0.0),
            "beta_if_alpha_and_q_minus_half": beta_from_alpha_q(a0, -0.5),
            "delta_to_phi": a0 - PHI,
            "delta_to_NLS_alpha": a0 - 1.61,
            "delta_to_a0_star": a0 - A0_STAR,
        })
    return rows


def alpha_beta_lines(alpha_min: float = 0.8, alpha_max: float = 2.4, n: int = 321) -> List[Dict[str, float]]:
    rows = []
    for i in range(n):
        alpha = alpha_min + (alpha_max - alpha_min) * i / (n - 1)
        rows.append({
            "alpha": alpha,
            "beta_q0": beta_from_alpha_q(alpha, 0.0),
            "beta_q_minus_half": beta_from_alpha_q(alpha, -0.5),
            "beta_q_plus_half": beta_from_alpha_q(alpha, 0.5),
        })
    return rows


def derive_summary() -> Dict[str, float | str]:
    a0_num = smooth_matched_root_bisection()
    nls_alpha = 1.61
    nls_beta = 0.61
    return {
        "a0_star_analytic": A0_STAR,
        "a0_star_bisection": a0_num,
        "a0_star_minus_phi": A0_STAR - PHI,
        "a0_star_minus_NLS_alpha": A0_STAR - nls_alpha,
        "phi": PHI,
        "c_phi_over_v": smooth_matched_c_over_v(PHI),
        "c_NLS_alpha_over_v": smooth_matched_c_over_v(nls_alpha),
        "NLS_q_eff": q_eff(nls_alpha, nls_beta),
        "NLS_beta_pred_q0": beta_from_alpha_q(nls_alpha, 0.0),
        "NLS_beta_residual_q0": beta_from_alpha_q(nls_alpha, 0.0) - nls_beta,
        "a0_star_beta_if_q0": beta_from_alpha_q(A0_STAR, 0.0),
        "a0_star_beta_if_q_minus_half": beta_from_alpha_q(A0_STAR, -0.5),
        "status": "derives beta-alpha-q relation; compares legacy alpha/beta; does not derive absolute alpha from first-principles core dynamics",
    }

if __name__ == "__main__":
    print(derive_summary())
