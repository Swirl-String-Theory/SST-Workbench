# Route B BEM v3 audit

Input: `/mnt/data/outputs_routeB_idealxml_fast/idealxml_sampled_ideal_used.txt`
SHA256: `008cbfeadbf51ebe447595c070c34950e14ccefee40cfd872f9f901f56acafd8`

## Backend
Area-symmetric BEM/Steklov with parallel-transport tube frames and screened self terms.

## Global G6
- `global_control_gate_G6`: `SKIP`
- `global_control_note`: `Need 0_1 and 3_1 controls`
- `alpha_map_status`: `NO_CANONICAL_ALPHA_MAP_SPECIFIED__NO_FIT_PERFORMED`

## Per-knot
### 3_1
- `S_logdet`: `0.986111012076`
- `S_trace`: `5.10003665311`
- `G3`: `PASS`
- `G4`: `PASS` rel `0.000e+00`
- `G5`: `PASS` rel `3.598e-02`
- status: `BEM_V3_ROUTE_B_CANDIDATE_NOT_ALPHA_DERIVATION`

### 4_1
- `S_logdet`: `0.992517646175`
- `S_trace`: `5.09475385593`
- `G3`: `PASS`
- `G4`: `PASS` rel `0.000e+00`
- `G5`: `PASS` rel `3.109e-02`
- status: `BEM_V3_ROUTE_B_CANDIDATE_NOT_ALPHA_DERIVATION`

### 5_1_1
- `S_logdet`: `0.986333824887`
- `S_trace`: `5.09985059813`
- `G3`: `PASS`
- `G4`: `PASS` rel `0.000e+00`
- `G5`: `PASS` rel `4.189e-02`
- status: `BEM_V3_ROUTE_B_CANDIDATE_NOT_ALPHA_DERIVATION`

## Interpretation
Passing this audit does not derive alpha. It only means this BEM v3 candidate survives the chosen falsifiers.