# Reviewer blocker audit

- BEM-only control confirms the BEM term does not independently select E0.
- E_star is close to E_p^NLS; classify the result as pressure-selected with BEM compliance shift.
- Far-field and phase certificates are internal identities unless Lambda_phi is measured independently.
- Strongest label: closure-derived / derived within the minimal finite-cell shell model, not first-principles QED alpha.
