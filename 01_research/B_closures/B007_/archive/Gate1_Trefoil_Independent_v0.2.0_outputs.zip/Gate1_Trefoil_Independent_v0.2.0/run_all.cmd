@echo off
setlocal
cd /d "%~dp0"
if not exist results mkdir results
python src\geometry_proof.py --out results\reach_certificate.json || exit /b 1
python src\qualify.py --q 0 --grids 64 96 128 --helicity-grids 64 96 128 --save-seed-grid 128 --output results\q0.json || exit /b 1
python src\qualify.py --q 1 --grids 64 96 128 --helicity-grids 64 96 128 --save-seed-grid 128 --output results\q1.json || exit /b 1
python src\assess.py || exit /b 1
python -m pytest -q tests || exit /b 1
echo Gate 1 qualification completed under its declared numerical scope.
