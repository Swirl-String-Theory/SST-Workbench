"""Post-hoc alpha benchmark for v0.3 coupled Kelvin/Floquet eigenmode clock.

This is the only solver-side module containing the alpha benchmark value.  It is
never imported by blind_gates.py.
"""
from __future__ import annotations
import math
from typing import Any
from .constants import TREFOIL_ROPELENGTH_HIRES

ALPHA_INV_BENCHMARK = 137.035999177


def alpha0_inverse(ropelength: float = TREFOIL_ROPELENGTH_HIRES) -> float:
    return (8.0*math.pi/3.0)*float(ropelength)


def _row(name: str, h: float, a0: float, target: float, alpha_inv: float, note: str) -> dict[str, Any]:
    pred=a0+float(h)
    return {"candidate":name,"note":note,"phase_turns_additive":float(h),"alpha_inverse_pred":float(pred),
            "target_delta_abs":float(target),"absolute_error_inverse":float(abs(pred-alpha_inv)),
            "error_in_target_correction_units":float(abs(float(h)-target)/max(abs(target),1e-30)),
            "within_10pct_of_required_correction":bool(abs(float(h)-target)<=.10*abs(target))}


def benchmark_blind_summary(blind_summary: dict[str, Any], *, ropelength: float=TREFOIL_ROPELENGTH_HIRES,
                            alpha_inv: float=ALPHA_INV_BENCHMARK) -> dict[str, Any]:
    a0=alpha0_inverse(ropelength); target=float(alpha_inv-a0)
    can=blind_summary["canonical_blind"]["canonical"]
    hs=float(can["floquet_phase_signed_turns"]); he=float(can["floquet_phase_scalar_defect_turns"])
    rows=[_row("signed_floquet_eigenphase",hs,a0,target,alpha_inv,
               "raw orientation-covariant phase; no sign repair or fit"),
          _row("parity_even_phase_defect",he,a0,target,alpha_inv,
               "diagnostic scalarization -|h_F|; reported separately, not allowed to rescue the signed primary")]
    ladder=[]
    for r in blind_summary.get("resolution_ladder",[]):
        h=float(r["phase_turns"]); err=abs(h-target)/max(abs(target),1e-30)
        ladder.append({"n":int(r["n"]),"blind_phase_turns":h,"target_units_error":float(err),"within_10pct":bool(err<=.10)})
    near=[r for r in ladder if r["within_10pct"]]
    blind_pass=all(bool(g["pass"]) for g in blind_summary.get("gates",[]))
    primary=rows[0]
    h13=bool(primary["within_10pct_of_required_correction"] and blind_pass)
    if not blind_pass:
        verdict="FALSIFIED_OR_UNSUPPORTED_BEFORE_ALPHA_MATCH_CAN_COUNT"
    elif not primary["within_10pct_of_required_correction"]:
        verdict="BLIND_DYNAMIC_CLOCK_SURVIVES_BUT_MISSES_ALPHA"
    else:
        verdict="SURVIVES_V0_3_0_BLIND_AND_ALPHA_GATES"
    return {"benchmark_phase":"POST_HOC_ONLY_AFTER_H0_H12_ARCHIVE",
            "mapping":"alpha_inverse_pred=(8*pi/3)*L_trefoil+h_F; coefficient fixed to 1; no fitted parameter",
            "alpha_inverse_benchmark":float(alpha_inv),"ropelength_alpha_baseline":float(ropelength),
            "alpha0_inverse":float(a0),"target_delta_abs":target,
            "primary_candidate":primary,"candidates":rows,
            "pre_unblinding_resolution_ladder_benchmarked_afterward":ladder,
            "preconverged_near_hit_count":len(near),"preconverged_near_hits":near,
            "all_blind_H0_H12_pass":blind_pass,
            "H13_parameter_free_alpha_hit":{"pass":h13,"criterion":"all H0-H12 pass AND canonical signed h_F within 10% of required correction"},
            "verdict":verdict}
