"""A069 v0.3.1 historical two-seed STATIC-only diagnostic regressions."""
from pathlib import Path
import hashlib, json, math, shutil, tempfile
import numpy as np
from experiment.historical_trefoils import NAMES,DATA,curve,derivative,analytic_length,crossings,load_seed,evaluate

def test_exact_source_pins_and_meshes():
    d=evaluate()
    assert d['status']=='PASS_STATIC_DIAGNOSTIC_ONLY'
    assert d['gates']=={'G20':'PASS','G21':'PASS','G22':'PASS','G23':'UNRESOLVED','G24':'UNRESOLVED'}
    for seed in NAMES:
        assert d['results'][seed]['meshes']['600']['sha_pass']
        assert d['results'][seed]['meshes']['1200']['sha_pass']

def test_periodicity_and_tangent():
    for seed in NAMES:
        for t in np.linspace(.13,5.8,7):
            assert np.linalg.norm(curve(seed,t)-curve(seed,t+2*math.pi))<3e-14
            h=1e-6
            assert np.linalg.norm((curve(seed,t+h)-curve(seed,t-h))/(2*h)-derivative(seed,t))<2e-9

def test_two_numerical_resolutions():
    for seed in NAMES:
        a600,_=load_seed(seed,600);a1200,_=load_seed(seed,1200)
        assert np.max(np.linalg.norm(a600-a1200[::2],axis=1))<3e-12
        assert np.max(np.linalg.norm(np.diff(np.vstack([a1200,a1200[0]]),axis=0),axis=1))>0

def test_analytic_xy_crossings():
    assert [x['sign'] for x in crossings(NAMES[0])]==[1,1,1]
    assert [x['sign'] for x in crossings(NAMES[1])]==[-1,-1,-1]
    for seed in NAMES:
        a=crossings(seed);b=crossings(seed,mirror=True)
        assert sum(x['sign'] for x in a)==-sum(x['sign'] for x in b)
        assert all(x['vertical_separation']>0.35 for x in a)

def test_mirror_geometry_length_not_a_vs_b_match():
    for seed in NAMES:
        a,_=load_seed(seed,1200)
        b=a*np.array([-1.,1.,1.])
        assert abs(np.sum(np.linalg.norm(np.roll(a,-1,axis=0)-a,axis=1)) - np.sum(np.linalg.norm(np.roll(b,-1,axis=0)-b,axis=1)))<1e-12
    assert abs(analytic_length(NAMES[0])-analytic_length(NAMES[1]))>10

def test_tampering_fails_closed():
    with tempfile.TemporaryDirectory() as temp:
        tmp=Path(temp)
        for p in DATA.iterdir():shutil.copy2(p,tmp/p.name)
        bad=tmp/f'{NAMES[0]}_N600_arclength.xyz'
        bad.write_text(bad.read_text().replace('2.5000000000000000e+00','2.6000000000000000e+00',1))
        result=evaluate(tmp)
        assert result['gates']['G20']=='FAIL'
        assert result['physical_pklsa_dynamics_ready'] is False

def test_missing_file_fails_closed():
    with tempfile.TemporaryDirectory() as temp:
        tmp=Path(temp)
        for p in DATA.iterdir():shutil.copy2(p,tmp/p.name)
        (tmp/f'{NAMES[1]}_N1200_arclength.xyz').unlink()
        assert evaluate(tmp)['gates']['G20']=='FAIL'

def test_no_clock_promotion():
    v=evaluate()
    assert v['gates']['G23']=='UNRESOLVED' and v['gates']['G24']=='UNRESOLVED'
    assert not v['operational_clock_predicted']
    assert not v['intrinsic_phase_frequency_measured']
    assert v['independent_physical_provider_count']==0
