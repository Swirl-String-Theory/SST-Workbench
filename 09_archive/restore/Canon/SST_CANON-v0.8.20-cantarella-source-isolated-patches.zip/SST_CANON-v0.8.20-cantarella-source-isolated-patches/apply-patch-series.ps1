param(
    [string]$Root = ".",
    [switch]$CheckOnly
)

$ErrorActionPreference = "Stop"
Set-Location $Root

$expected = @{
    "SST_CANON-v0.8.20.tex" = "748c53ffa89d181ac2a0d2dd38f27e575f05e2aac9465b0ee0673e6b8f40e698"
    "SST_CANON-v0.8.20-research-track.tex" = "3d011afcf7fd1c837d0f1eeed24d16b7fcee17818d0ad71fb01bdb6ece9b96e3"
}

foreach ($file in $expected.Keys) {
    if (-not (Test-Path $file)) {
        throw "Ontbrekend basisbestand: $file"
    }
    $actual = (Get-FileHash -Algorithm SHA256 $file).Hash.ToLowerInvariant()
    if ($actual -ne $expected[$file]) {
        throw "Base hash mismatch voor $file. Verwacht $($expected[$file]), ontvangen $actual"
    }
}

$patches = @(
    "patches/0001-helicity-forms-mapping-class.diff",
    "patches/0002-isoperimetric-domain-spectrum.diff",
    "patches/0003-ridgerunner-certification.diff"
)

foreach ($patch in $patches) {
    Write-Host "Controleren: $patch"
    & git apply --check $patch
    if ($LASTEXITCODE -ne 0) { throw "git apply --check faalde voor $patch" }

    if (-not $CheckOnly) {
        Write-Host "Toepassen: $patch"
        & git apply $patch
        if ($LASTEXITCODE -ne 0) { throw "git apply faalde voor $patch" }
    }
}

if ($CheckOnly) {
    Write-Host "Alle patches zijn toepasbaar; niets gewijzigd."
} else {
    Write-Host "Alle drie subpatches zijn toegepast."
}
