@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" run_campaign.py --stage continuation --progress-every=60
exit /b %ERRORLEVEL%
