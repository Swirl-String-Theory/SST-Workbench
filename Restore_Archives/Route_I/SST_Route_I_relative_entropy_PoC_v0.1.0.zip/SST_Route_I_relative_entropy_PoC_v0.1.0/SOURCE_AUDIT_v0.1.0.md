# Source audit v0.1.0

## Authority order used

1. Current loose `SST_CANON-v0.8.28.tex`.
2. Current loose `SST_CANON-v0.8.28-research-track.tex`.
3. `SSTcore-source-bundle-0.8.28.zip` for implementation consistency.
4. Current `ideal_favorites.txt` for the geometry ladder.
5. Uploaded ropelength papers for the distinction between static tight geometry
   and dynamical vortex equilibrium.

## Source-supported statements

### Action-angle convention

The current main CANON defines an internal action-angle pair \((I,\theta)\) with

\[
\Omega_0(I)=\frac{dE_0}{dI}.
\]

It also warns that the electron specialization
\(I_e=E_0/\omega_c=\hbar\) is a calibrated identity, not an independent
quantization derivation. v0.1.0 therefore uses the Hamiltonian action variable,
not a generic `energy divided by rate` rule.

### Transition-action target

The current main CANON explicitly requests a transition action from a closed
phase-space cycle rather than setting it to \(h\) or \(\hbar\). It also states
that scalar ropelength alone cannot provide a bound-mode impedance.

### Core-density and radius guard

The current main CANON states that \(\rho_{\rm horn}^{\rm eff}\) is an effective
horn-envelope normalization, not a measured local tube density, and that a
resolved model must introduce a separate core radius/profile. Consequently the
v0.1.0 Rankine result is explicitly conditional.

### Geometry inputs

The current `ideal_favorites.txt` provides:

\[
\mathcal L(0_1)=6.283185,
\quad
\mathcal L(3_1)=16.371637,
\quad
\mathcal L(4_1)=21.043322.
\]

The mirror trefoil is produced by a parity reflection of the same certified
Fourier embedding; it is not a separately tuned geometry.

### Static geometry versus dynamics

The ropelength sources establish thickness-constrained or approximately tight
static centerlines. They do not establish that those centerlines are relative
equilibria or periodic orbits of the finite-core Biot--Savart/Euler dynamics.
The v0.1.0 recurrence-frequency gate is therefore necessary.

## New derivations in v0.1.0

For a uniform Rankine core with
\(v_\theta(r)=\Omega r\), \(v_s=\Omega a\), centerline length \(L\),

\[
E_K=\frac14\rho\pi a^2v_s^2L,
\]

\[
I_K=\frac{1}{2\pi}\oint p_\phi\,d\phi
=L_{\rm core}
=\frac12\rho\pi a^3v_sL,
\]

and therefore

\[
\frac{E_K}{\Omega}=\frac{I_K}{2}.
\]

This factor-two result is independent of knot type; the total action scales
with centerline length.

The local-cell selector is a new Research-Track matching hypothesis:

\[
\hbar\beta_Q=j_\phi a_\star(\beta_Q),
\qquad
j_\phi=\frac12\rho\pi v_sa^3.
\]

It is not present as a theorem in the source CANON and is not promoted by this
package.
