# Exact-rational reach lower-bound certificate (the present curve only)

Let

\[
X(\phi)=((1+a\cos3\phi)\cos2\phi,(1+a\cos3\phi)\sin2\phi,a\sin3\phi),\quad a=7/20.
\]

Let two points differ by the shortest angular parameter separation `d in (0,pi]`; write their midpoint parameter `m`. Direct trigonometric expansion gives the **exact squared chord identity**:

\[
\frac{\|X(m-d/2)-X(m+d/2)\|^2}{4}
=\sin^2d\,[1+2a\cos(3m)\cos(3d/2)+a^2\cos^2(3m)]
+a^2\cos^2d\sin^2(3d/2).
\]

The bracket equals `(1+a c cosA)^2 + a^2 c^2 sin^2A` with `c=cos3m`, `A=3d/2`, therefore it is at least `(1-a)^2`.

## Curvature cap

In local cylindrical coordinates,

\[
X'=(-3a\sin3\phi,\,2(1+a\cos3\phi),\,3a\cos3\phi)
\]

and

\[
X''=(-9a\cos3\phi-4(1+a\cos3\phi),\,-12a\sin3\phi,\,-9a\sin3\phi).
\]

Thus

\[
\kappa^2=\frac{|X'\times X''|^2}{|X'|^6}.
\]

The exact rational polynomial

\[
P(u)=\frac{64}{25}|X'|^6-|X'\times X''|^2,
\qquad u=\frac{1+\cos3\phi}{2}\in[0,1]
\]

has coefficients, in ascending powers of `u`:

```
[5490201327/100000000,
 -207584237/6250000,
  919353141/6250000,
  118459166/390625,
  117593777/390625,
  41950272/390625,
  7529536/390625]
```

All coefficients of `u^k` for `k>=2` are positive; the leading `u^2` and the constant/linear terms form a strictly positive quadratic, because the discriminant is negative (`-4875068972896329431/156250000000000`). Hence `P(u)>0` on `[0,1]`, proving `kappa < 8/5 = 1.6` and focal radius `> 5/8 = 0.625`.

## Excluding short double-critical chords

The speed satisfies

\[
|X'|^2=9a^2+4(1+a\cos3\phi)^2 \le 9a^2+4(1+a)^2 < (2.898)^2.
\]

Let `d0=33/100=0.33`. For `0<d<d0` the parameter arc between the points has length at most `d*2.898 <= 0.95634`; even the conservative bound `2*d*2.898 < 1.91268` is below `pi/1.6 > 1.9625`. With `kappa<1.6`, the scalar product of the chord with the starting unit tangent is strictly positive for any such arc. Thus **these pairs cannot be doubly critical**.

## Lower bounds for other chords

For `d0 <= d <= pi-d0`, the exact chord identity yields

\[
D(d,m)\ge 2(1-a)\sin d \ge 2(1-a)\sin d_0
>2(1-a)(d_0-d_0^3/6)=0.42121365.
\]

For `pi-d0 <= d <= pi`, the second positive term gives

\[
D(d,m)\ge 2a|\cos d|\,|\sin(3d/2)|
\ge 2a\cos(d_0)\cos(3d_0/2)
>2a(1-d_0^2/2)(1-(3d_0/2)^2/2)
=0.5807958139375.
\]

Therefore every doubly-critical chord has length `>0.42121365`, and the minimum focal radius is `>0.625`. Using the thickness/reach characterization for a smooth embedded closed curve:

\[
\boxed{\operatorname{reach}(X)>\min(0.625,0.42121365/2)=0.210606825.}
\]

This strictly exceeds `a_core=0.20`. It does **not** establish the *exact* reach of the curve.

## Independent test

The script `tests/test_gate1.py` evaluates the chord identity at nontrivial pairs independently of the polynomial proof; `src/seed_core_v010.py` separately computes curvature from `X'`, `X''`, and validates the antipodal doubly-critical family. The certificate itself uses rational symbolic arithmetic through SymPy.

**Reference**: O. Gonzalez and J. H. Maddocks, 1999, *Global curvature, thickness, and the ideal shapes of knots*, PNAS 96, 4769–4773. DOI `10.1073/pnas.96.9.4769`.
