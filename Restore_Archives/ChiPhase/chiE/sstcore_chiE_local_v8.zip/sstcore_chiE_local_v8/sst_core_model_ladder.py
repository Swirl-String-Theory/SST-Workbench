from __future__ import annotations

import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List

import numpy as np

PI = math.pi
TARGET_CHI_E = 2.0 * PI
TARGET_XI_E = 1.0 / (2.0 * PI)


def require_positive(name: str, value: float) -> None:
    if not (value > 0.0) or not math.isfinite(value):
        raise ValueError(f"{name} must be finite and positive, got {value!r}")


def require_lambda(lambda_: float) -> None:
    require_positive("lambda_", lambda_)
    if lambda_ < 1.0:
        raise ValueError("embedded toroidal-core guard requires lambda_=R/a0 >= 1")


def chi_from_xi(xi: float) -> float:
    return 4.0 * PI * PI * xi


def xi_from_chi(chi: float) -> float:
    return chi / (4.0 * PI * PI)


def v0_from_gamma_a0(Gamma0: float, a0: float) -> float:
    require_positive("Gamma0", Gamma0)
    require_positive("a0", a0)
    return Gamma0 / (2.0 * PI * a0)


def xi_cavitation(lambda_: float) -> float:
    require_lambda(lambda_)
    return 0.25 * lambda_


def chi_cavitation(lambda_: float) -> float:
    return chi_from_xi(xi_cavitation(lambda_))


def xi_regularized_filament(lambda_: float, epsilon: float = 1.0, n: int = 8192) -> float:
    """Regularized circular-filament Neumann energy in Xi normalization.

    Xi_fil = lambda^2/4 int_0^{2pi} cos(theta)
             / sqrt(4 lambda^2 sin^2(theta/2)+epsilon^2) dtheta.
    This is a diagnostic finite-core kernel, not a canonical exterior Dirichlet solve.
    """
    require_lambda(lambda_)
    require_positive("epsilon", epsilon)
    if n < 128:
        raise ValueError("n must be >= 128")
    h = 2.0 * PI / int(n)
    total = 0.0
    for k in range(int(n)):
        theta = (k + 0.5) * h
        denom = math.sqrt(4.0 * lambda_ * lambda_ * math.sin(0.5 * theta) ** 2 + epsilon * epsilon)
        total += math.cos(theta) / denom
    return 0.25 * lambda_ * lambda_ * h * total


# ---------------------------------------------------------------------------
# Test 1: finite-core toroidal balance with solid Rankine interior
# ---------------------------------------------------------------------------

def density_profile_g(q: float, profile: str = "rankine", shape: float = 1.0, normalize_boundary: bool = True) -> float:
    """Dimensionless swirl profile g(q)=v_theta(q a0)/v0 for 0<=q<=1.

    rankine:       g(q)=q
    polynomial:    g(q)=2q-q^3, regular and boundary-normalized
    lamb_oseen:    g(q)=(1-exp(-shape*q^2))/(q*(1-exp(-shape))) if normalized,
                   else (1-exp(-shape*q^2))/q
    nlse_tanh:     g(q)=tanh(shape*q)/tanh(shape) if normalized,
                   else tanh(shape*q)
    """
    if q < 0.0 or q > 1.0 or not math.isfinite(q):
        raise ValueError("q must be in [0,1]")
    p = profile.lower().strip().replace("-", "_")
    if p in {"rankine", "solid", "constant_density"}:
        return q
    if p in {"polynomial", "poly", "smooth_poly"}:
        return 2.0 * q - q ** 3
    require_positive("shape", shape)
    if p in {"lamb_oseen", "oseen", "gaussian"}:
        if q == 0.0:
            val = shape * q
        else:
            val = (1.0 - math.exp(-shape * q * q)) / q
        if normalize_boundary:
            val /= (1.0 - math.exp(-shape))
        return val
    if p in {"nlse_tanh", "tanh", "gp_tanh"}:
        val = math.tanh(shape * q)
        if normalize_boundary:
            val /= math.tanh(shape)
        return val
    raise ValueError(f"Unknown profile {profile!r}")


def profile_integral_I(profile: str = "rankine", shape: float = 1.0, normalize_boundary: bool = True, n: int = 4096) -> float:
    """I_profile = int_0^1 q g(q)^2 dq by midpoint quadrature."""
    if n < 128:
        raise ValueError("n must be >= 128")
    h = 1.0 / int(n)
    total = 0.0
    for k in range(int(n)):
        q = (k + 0.5) * h
        g = density_profile_g(q, profile=profile, shape=shape, normalize_boundary=normalize_boundary)
        total += q * g * g
    return h * total


def chi_internal_profile(lambda_: float, profile: str = "rankine", shape: float = 1.0, normalize_boundary: bool = True, n: int = 4096) -> float:
    """Internal finite-core torus energy coefficient in chi normalization.

    chi_int = 2*pi^2*lambda * int_0^1 q g(q)^2 dq.
    The torus Jacobian curvature term integrates exactly because int cos(eta)deta=0.
    """
    require_lambda(lambda_)
    return 2.0 * PI * PI * lambda_ * profile_integral_I(profile, shape, normalize_boundary, n)


def xi_internal_profile(lambda_: float, profile: str = "rankine", shape: float = 1.0, normalize_boundary: bool = True, n: int = 4096) -> float:
    return xi_from_chi(chi_internal_profile(lambda_, profile, shape, normalize_boundary, n))


@dataclass(frozen=True)
class FiniteCoreBalanceResult:
    lambda_: float
    epsilon: float
    profile: str
    shape: float
    normalize_boundary: bool
    profile_integral: float
    Xi_external_regularized: float
    Xi_internal: float
    Xi_total: float
    chi_external_regularized: float
    chi_internal: float
    chi_E: float
    target_residual: float
    status: str = "RESEARCH-TRACK / FINITE-CORE DIAGNOSTIC / NOT CANONIZED"


def evaluate_finite_core_balance(lambda_: float = 1.0, epsilon: float = 1.0, profile: str = "rankine", shape: float = 1.0, normalize_boundary: bool = True, n_theta: int = 8192, n_profile: int = 4096) -> FiniteCoreBalanceResult:
    xi_ext = xi_regularized_filament(lambda_, epsilon=epsilon, n=n_theta)
    I = profile_integral_I(profile, shape, normalize_boundary, n_profile)
    chi_int = 2.0 * PI * PI * lambda_ * I
    xi_int = xi_from_chi(chi_int)
    xi_total = xi_ext + xi_int
    chi_total = chi_from_xi(xi_total)
    return FiniteCoreBalanceResult(
        lambda_=float(lambda_), epsilon=float(epsilon), profile=str(profile), shape=float(shape),
        normalize_boundary=bool(normalize_boundary), profile_integral=float(I),
        Xi_external_regularized=float(xi_ext), Xi_internal=float(xi_int), Xi_total=float(xi_total),
        chi_external_regularized=float(chi_from_xi(xi_ext)), chi_internal=float(chi_int),
        chi_E=float(chi_total), target_residual=float((chi_total - TARGET_CHI_E) / TARGET_CHI_E),
    )


# ---------------------------------------------------------------------------
# Test 3: classic asymptotic model table
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AsymptoticModelSpec:
    name: str
    alpha_E: float
    beta_V: float
    family: str


ASYMPTOTIC_MODEL_TABLE: List[AsymptoticModelSpec] = [
    AsymptoticModelSpec("solid_core_constant_volume", 7.0 / 4.0, 1.0 / 4.0, "solid"),
    AsymptoticModelSpec("hollow_core_constant_volume", 2.0, 1.0 / 2.0, "hollow"),
    AsymptoticModelSpec("hollow_core_constant_pressure", 3.0 / 2.0, 1.0 / 2.0, "hollow"),
    AsymptoticModelSpec("hollow_core_surface_tension", 1.0, 0.0, "hollow"),
    AsymptoticModelSpec("nonlinear_schrodinger", 1.61, 0.61, "smooth"),
]


def xi_asymptotic_ring(lambda_: float, alpha_E: float) -> float:
    require_lambda(lambda_)
    return 0.5 * lambda_ * (math.log(8.0 * lambda_) - alpha_E)


def speed_bracket(lambda_: float, beta_V: float) -> float:
    require_lambda(lambda_)
    return math.log(8.0 * lambda_) - beta_V


def alpha_required_for_target(lambda_: float, target_chi: float = TARGET_CHI_E) -> float:
    require_lambda(lambda_)
    target_xi = xi_from_chi(target_chi)
    return math.log(8.0 * lambda_) - 2.0 * target_xi / lambda_


@dataclass(frozen=True)
class AsymptoticModelResult:
    name: str
    family: str
    lambda_: float
    alpha_E: float
    beta_V: float
    Xi_E: float
    chi_E: float
    target_residual: float
    speed_bracket: float
    speed_bracket_positive: bool
    alpha_required_for_2pi: float
    alpha_offset_from_required: float
    beta_relation_constant_pressure_error: float
    beta_relation_constant_volume_error: float
    status: str = "RESEARCH-TRACK / THIN-RING ASYMPTOTIC BENCHMARK / NOT CANONIZED"


def evaluate_asymptotic_model(spec: AsymptoticModelSpec, lambda_: float = 1.0) -> AsymptoticModelResult:
    xi = xi_asymptotic_ring(lambda_, spec.alpha_E)
    chi = chi_from_xi(xi)
    sf = speed_bracket(lambda_, spec.beta_V)
    ar = alpha_required_for_target(lambda_)
    return AsymptoticModelResult(
        name=spec.name, family=spec.family, lambda_=float(lambda_), alpha_E=float(spec.alpha_E), beta_V=float(spec.beta_V),
        Xi_E=float(xi), chi_E=float(chi), target_residual=float((chi - TARGET_CHI_E) / TARGET_CHI_E),
        speed_bracket=float(sf), speed_bracket_positive=bool(sf > 0.0), alpha_required_for_2pi=float(ar),
        alpha_offset_from_required=float(spec.alpha_E - ar),
        beta_relation_constant_pressure_error=float(spec.beta_V - (spec.alpha_E - 1.0)),
        beta_relation_constant_volume_error=float(spec.beta_V - (spec.alpha_E - 1.5)),
    )


# ---------------------------------------------------------------------------
# Test 4: surface tension / interface term
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SurfaceTensionResult:
    lambda_: float
    epsilon: float
    Sigma: float
    base_mode: str
    chi_base: float
    chi_sigma: float
    chi_E: float
    target_residual: float
    Sigma_required_for_2pi: float
    positive_sigma_can_hit_target: bool
    status: str = "RESEARCH-TRACK / SURFACE-TENSION PARAMETER SWEEP / NOT CANONIZED"


def chi_surface_tension(lambda_: float, Sigma: float) -> float:
    """chi_sigma = 2*pi^2*lambda*Sigma, where Sigma=sigma/(P_vac*a0)."""
    require_lambda(lambda_)
    if not math.isfinite(Sigma):
        raise ValueError("Sigma must be finite")
    return 2.0 * PI * PI * lambda_ * Sigma


def sigma_required_for_target(lambda_: float, chi_base: float, target_chi: float = TARGET_CHI_E) -> float:
    require_lambda(lambda_)
    return (target_chi - chi_base) / (2.0 * PI * PI * lambda_)


def base_chi_for_surface_mode(lambda_: float, epsilon: float, base_mode: str = "hollow", n: int = 8192) -> float:
    mode = base_mode.lower().strip().replace("-", "_")
    chi_K = chi_from_xi(xi_regularized_filament(lambda_, epsilon, n))
    chi_cav = chi_cavitation(lambda_)
    if mode in {"kinetic", "kinetic_only"}:
        return chi_K
    if mode in {"hollow", "kinetic_plus_cavity", "total"}:
        return chi_K + chi_cav
    if mode in {"cavity_only", "cavitation"}:
        return chi_cav
    raise ValueError("base_mode must be kinetic_only, hollow, or cavity_only")


def evaluate_surface_tension(lambda_: float = 1.0, epsilon: float = 1.0, Sigma: float = 0.0, base_mode: str = "hollow", n: int = 8192) -> SurfaceTensionResult:
    chi_base = base_chi_for_surface_mode(lambda_, epsilon, base_mode, n)
    chi_sig = chi_surface_tension(lambda_, Sigma)
    chi = chi_base + chi_sig
    req = sigma_required_for_target(lambda_, chi_base)
    return SurfaceTensionResult(
        lambda_=float(lambda_), epsilon=float(epsilon), Sigma=float(Sigma), base_mode=str(base_mode),
        chi_base=float(chi_base), chi_sigma=float(chi_sig), chi_E=float(chi),
        target_residual=float((chi - TARGET_CHI_E) / TARGET_CHI_E),
        Sigma_required_for_2pi=float(req), positive_sigma_can_hit_target=bool(req >= 0.0),
    )


# ---------------------------------------------------------------------------
# IO helpers
# ---------------------------------------------------------------------------

def rows_to_dicts(rows: Iterable[Any]) -> List[Dict[str, Any]]:
    return [asdict(r) for r in rows]


def write_csv(path: str | Path, rows: Iterable[Any]) -> None:
    rows_list = rows_to_dicts(rows)
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not rows_list:
        return
    with p.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows_list[0].keys()))
        writer.writeheader()
        writer.writerows(rows_list)


def write_json(path: str | Path, payload: Dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
