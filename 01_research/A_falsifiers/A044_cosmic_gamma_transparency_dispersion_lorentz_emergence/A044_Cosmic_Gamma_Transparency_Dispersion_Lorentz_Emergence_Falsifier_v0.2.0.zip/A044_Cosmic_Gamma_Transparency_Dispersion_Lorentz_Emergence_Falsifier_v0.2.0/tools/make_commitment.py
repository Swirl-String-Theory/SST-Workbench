from pathlib import Path
import hashlib, sys
p=Path(sys.argv[1] if len(sys.argv)>1 else "private/candidate.json")
if not p.exists():
    print("No candidate file; commitment not created."); raise SystemExit(0)
h=hashlib.sha256(p.read_bytes()).hexdigest()
out=Path("data/public/reveal_commitment_sha256.txt")
out.write_text(h+"\n",encoding="utf-8")
print(h)
