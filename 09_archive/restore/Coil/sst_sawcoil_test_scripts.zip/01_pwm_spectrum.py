from __future__ import annotations
import argparse
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_sawcoil_common import pwm_fourier_unipolar, write_csv


def main() -> None:
    ap = argparse.ArgumentParser(description="PWM Fourier spectrum for SawShape coil tests.")
    ap.add_argument("--duty", type=float, default=0.382, help="PWM duty cycle, 0..1")
    ap.add_argument("--harmonics", type=int, default=40)
    ap.add_argument("--current", type=float, default=1.0, help="Pulse current amplitude [A]")
    ap.add_argument("--outdir", default="/mnt/data/sawcoil_out")
    args = ap.parse_args()

    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    c = pwm_fourier_unipolar(args.duty, args.harmonics, args.current)
    rows = []
    for n in range(args.harmonics + 1):
        sinus_amp = abs(c[0]) if n == 0 else 2.0 * abs(c[n])
        rows.append([n, c[n].real, c[n].imag, abs(c[n]), sinus_amp, math.atan2(c[n].imag, c[n].real)])
    csv_path = outdir / f"pwm_spectrum_d{args.duty:.4f}.csv"
    write_csv(csv_path, ["n", "c_real_A", "c_imag_A", "abs_c_A", "real_sinus_amplitude_A", "phase_rad"], rows)

    ns = np.arange(1, args.harmonics + 1)
    amps = np.array([2.0 * abs(c[n]) for n in ns])
    plt.figure(figsize=(9, 4.5))
    plt.stem(ns, amps)
    plt.xlabel("harmonic n")
    plt.ylabel("sinusoidal harmonic amplitude [A]")
    plt.title(f"Unipolar PWM spectrum, duty={args.duty:.4f}")
    plt.grid(True, alpha=0.3)
    png_path = outdir / f"pwm_spectrum_d{args.duty:.4f}.png"
    plt.tight_layout(); plt.savefig(png_path, dpi=160); plt.close()

    print(f"Wrote {csv_path}")
    print(f"Wrote {png_path}")


if __name__ == "__main__":
    main()
