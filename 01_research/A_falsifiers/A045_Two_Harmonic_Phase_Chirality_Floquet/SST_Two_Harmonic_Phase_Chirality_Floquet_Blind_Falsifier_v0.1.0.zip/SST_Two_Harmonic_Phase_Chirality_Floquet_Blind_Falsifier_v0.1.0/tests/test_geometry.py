from sst_thpcf.geometry import torus_trefoil, c3_geometry_residual

def test_trefoil_c3():
    X = torus_trefoil(96)
    assert c3_geometry_residual(X) < 1e-3
