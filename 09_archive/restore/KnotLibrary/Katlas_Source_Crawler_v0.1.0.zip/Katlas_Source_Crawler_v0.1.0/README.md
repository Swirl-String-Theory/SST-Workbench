# SST Katlas Source Crawler v0.1.0

Offline Knot Atlas source builder for knots and links through 12 crossings.

## Why RDF instead of scraping every wiki page?

Knot Atlas publishes a Take Home Database. This package downloads the official small RDF archives:

- `Rolfsen.rdf.gz` — Rolfsen knot table (through 10 crossings)
- `Knots11.rdf.gz` — 11-crossing Hoste-Thistlethwaite knots
- `Knots12.rdf.gz` — 12-crossing knots
- `Links.rdf.gz` — Thistlethwaite links

This avoids thousands of page requests and preserves Katlas invariant/presentation fields as source data.

## Output layout

Katlas identifiers are never renamed.

```text
Katlas_Source/
  _source/
    Rolfsen.rdf.gz
    Knots11.rdf.gz
    Knots12.rdf.gz
    Links.rdf.gz
    SOURCE_MANIFEST.json
  _catalog/
    catalog.sqlite3
    catalog.jsonl
    catalog.csv
    BUILD_REPORT.json
    VALIDATION_REPORT.json
  knots/
    03/3_1/
      katlas.json
      source.rdf.nt
    09/9_2/
      katlas.json
      source.rdf.nt
    10/rolfsen/0001-0050/10_1/...
    11/alternating/0001-0050/K11a1/...
    11/nonalternating/0001-0050/K11n1/...
    12/alternating/0001-0050/K12a1/...
    12/nonalternating/0001-0050/K12n1/...
  links/
    02/L2a1/...
    09/L9a1/...
    10/alternating/0001-0050/L10a1/...
    10/nonalternating/0001-0050/L10n1/...
    11/...
    12/...  # only if the official Links.rdf.gz actually contains these IDs
```

Crossings 0-9 remain shallow and easy to browse. Crossings 10-12 are sharded in groups of 50.

## Per-object `katlas.json`

Every object retains:

- exact Katlas ID and table identity;
- crossing number, alternating/nonalternating family when encoded by the ID;
- all RDF invariants verbatim;
- normalized presentation aliases for PD, Gauss, DT, Conway, braid, Morse and arc forms when present;
- source archive and canonical Katlas page URL.

This is a topology/catalog source, not a 3D geometry source. It complements Fremlin/KnotPlot/Ridgerunner coordinates rather than replacing them.

## One-click Windows run

```bat
run_all.cmd
```

Stages:

1. create `.venv`;
2. download the four official RDF archives;
3. build per-knot/per-link folders plus SQLite/JSONL/CSV indexes;
4. validate IDs, paths and crossing limits.

No pip packages are required.

## Lookup

```bat
run_lookup.cmd 3_1
run_lookup.cmd 9_2
run_lookup.cmd K12a1
run_lookup.cmd L9a24
```

## Optional raw wiki snapshot

Bulk data comes from RDF. If a specific page's raw MediaWiki source is useful:

```bat
run_fetch_page.cmd 3_1
```

This adds `page.wikitext` beside that object's `katlas.json`. It is intentionally on-demand so normal catalog creation does not hammer the wiki.

## Offline SQLite examples

```sql
SELECT id, conway, dt
FROM objects
WHERE crossings <= 9 AND kind='knot';

SELECT id, crossings, family, pd
FROM objects
WHERE kind='link' AND crossings BETWEEN 10 AND 12;

SELECT object_id, value
FROM invariants
WHERE predicate='Jones_Polynomial';
```

## Reproducibility

`_source/SOURCE_MANIFEST.json` records URL, file size, SHA-256, download time, ETag and Last-Modified when supplied by the server.

The importer does not invent missing 12-crossing link pages or IDs. It exports only identities found in the official RDF data.
