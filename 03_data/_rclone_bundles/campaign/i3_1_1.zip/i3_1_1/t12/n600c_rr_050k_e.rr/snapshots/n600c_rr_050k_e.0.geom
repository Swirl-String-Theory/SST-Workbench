LIST {
	{ < n600c_rr_050k_e.0.vect }
	{ < n600c_rr_050k_e.0.struts.vect }
	{ < n600c_rr_050k_e.0.dlen.vect }
	{ < n600c_rr_050k_e.0.dVdt.vect }
}
