# A064 gate results
- Mode: `SNAPSHOTS_MODEL_RECONSTRUCTION`
- Evidence: `geometry_derived_regularized_biot_savart_simulation`
- Discovery SHA-256: `bab05425520078e6fccc13098a8b18c484a6de502cc5b0161e423f501e36f743`
- Divergence (p95 dx/U): `0.018027`
- Candidate identified: `True`
- Feature status: `DYNAMICAL_STATUS_UNRESOLVED`
- True separatrix manifold gate: `UNRESOLVED_NOT_CONSTRUCTED`
- Overall: `UNRESOLVED`
