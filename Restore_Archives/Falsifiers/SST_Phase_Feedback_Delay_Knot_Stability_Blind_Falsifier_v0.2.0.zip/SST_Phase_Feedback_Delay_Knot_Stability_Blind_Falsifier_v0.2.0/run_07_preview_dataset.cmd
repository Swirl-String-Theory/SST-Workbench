@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call run_05_find_input.cmd "%~1" || exit /b %ERRORLEVEL%
set "INPUT="
for /f "usebackq delims=" %%I in ("build\resolved_input.txt") do if not defined INPUT set "INPUT=%%I"
set "PYTHONPATH=%CD%\src;%CD%"
.venv\Scripts\python.exe preview_dataset.py "%INPUT%" --registry "reference\v0.1.7_seen_canonical64_sha256.json"
exit /b %ERRORLEVEL%
