# Fig. 2

Final plotted data and plotting code for Fig. 2.

```text
pip install -r requirements.txt
python code/plot_fig2_main.py
```

Outputs: `results/Fig2.png` and `results/Fig2.pdf`.

The script uses only the included CSV files and images. Fitting and theory
calculation code is not included.

The PDF embeds all figure text in DejaVu Sans as editable TrueType fonts (PDF
font type 42), rather than Type 3 glyphs. This includes mathematical labels,
scientific notation, panel letters, and spectral-line labels. The scale bars
and the `5 mm` labels in panels g and h are drawn by the plotting code as
vector lines and editable DejaVu Sans TrueType text; they are not rasterized
into the crystal photographs. Use the PDF for journal submission and the PNG
only as a raster preview.
