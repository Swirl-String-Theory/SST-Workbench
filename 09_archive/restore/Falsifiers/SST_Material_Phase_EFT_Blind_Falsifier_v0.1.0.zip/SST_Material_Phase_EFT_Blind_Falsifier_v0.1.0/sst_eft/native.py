from __future__ import annotations
import math
import numpy as np
try:
    from sst_eft_native import load
    _n=load(); _err=None
except Exception as e:
    _n=None; _err=e

def native_available(): return _n is not None

def backend_name(): return "cpp-pybind11" if _n is not None else "python-fallback"

def require_native():
    if _n is None: raise RuntimeError(f"native extension unavailable: {_err!r}")
    return _n

def _clean(points):
    p=np.asarray(points,float)
    if p.ndim!=2 or p.shape[1]!=3 or len(p)<4: raise ValueError("points must be (N,3), N>=4")
    if len(p)>4 and np.linalg.norm(p[0]-p[-1]) < 1e-14*max(1.0,float(np.linalg.norm(p,axis=1).max())): p=p[:-1]
    return p

def _py_resample(points,n):
    p=_clean(points); q=np.roll(p,-1,axis=0); seg=np.linalg.norm(q-p,axis=1); cum=np.r_[0,np.cumsum(seg)]; L=cum[-1]
    s=np.arange(n)*L/n; idx=np.searchsorted(cum[1:],s,side="right"); den=seg[idx]; t=((s-cum[idx])/np.where(den>0,den,1))[:,None]
    return p[idx]*(1-t)+q[idx]*t

def _py_metrics(points):
    p=_clean(points); n=len(p); L=float(np.linalg.norm(np.roll(p,-1,axis=0)-p,axis=1).sum()); ds=L/n
    d2=(np.roll(p,-1,axis=0)-2*p+np.roll(p,1,axis=0))/(ds*ds); k=np.linalg.norm(d2,axis=1); dk=(np.roll(k,-1)-k)/ds
    intk=float(k.sum()*ds); intk2=float((k*k).sum()*ds); intdk2=float((dk*dk).sum()*ds)
    return {"n":n,"length":L,"ds":ds,"total_curvature":intk,"int_kappa2":intk2,"int_dkappa2":intdk2,"D0":L*intk2,"D2":L**3*intdk2,"kappa_max":float(k.max())}

def _py_curvature(points):
    p=_clean(points); n=len(p); L=float(np.linalg.norm(np.roll(p,-1,axis=0)-p,axis=1).sum()); ds=L/n
    return np.linalg.norm((np.roll(p,-1,axis=0)-2*p+np.roll(p,1,axis=0))/(ds*ds),axis=1)

def _py_writhe(points):
    p=_clean(points); n=len(p); e=np.roll(p,-1,axis=0)-p; m=(np.roll(p,-1,axis=0)+p)/2; L=np.linalg.norm(e,axis=1).sum(); eps=1e-14*max(1.0,float(L)); sm=0.0
    for i in range(n):
        for j in range(i+1,n):
            d=j-i
            if d<=1 or d>=n-1: continue
            r=m[i]-m[j]; r2=float(r@r); rr=math.sqrt(r2)
            if rr<eps: continue
            sm += float(r@np.cross(e[i],e[j]))/(r2*rr)
    return sm/(2*math.pi)

def resample(points,n):
    if _n is not None: return np.asarray(_n.resample_closed_curve(np.asarray(points,float),int(n)))
    return _py_resample(points,int(n))

def metrics(points):
    if _n is not None: return dict(_n.curve_metrics(np.asarray(points,float)))
    return _py_metrics(points)

def curvature(points):
    if _n is not None: return np.asarray(_n.curvature_uniform(np.asarray(points,float)))
    return _py_curvature(points)

def writhe(points):
    if _n is not None: return float(_n.approx_writhe(np.asarray(points,float)))
    return float(_py_writhe(points))
