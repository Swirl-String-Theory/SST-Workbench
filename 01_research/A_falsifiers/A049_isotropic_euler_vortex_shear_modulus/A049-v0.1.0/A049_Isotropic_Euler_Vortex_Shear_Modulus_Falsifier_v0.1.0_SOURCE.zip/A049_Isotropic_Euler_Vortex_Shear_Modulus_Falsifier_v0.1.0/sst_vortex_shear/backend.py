import os
import numpy as np
from . import reference


def _native_module():
    mode = os.environ.get("SST_BACKEND", "auto").lower()
    if mode == "python":
        return None
    try:
        import vortex_shear_native
        return vortex_shear_native
    except Exception as exc:
        if mode == "native":
            raise RuntimeError(
                "SST_BACKEND=native requested, but vortex_shear_native could not be imported. "
                "Build it first with build_native.cmd."
            ) from exc
        return None


def backend_name():
    return "native" if _native_module() is not None else "python"


def energy_ratio_general(nvec, omega_dir, deformation):
    native = _native_module()
    n = np.ascontiguousarray(np.asarray(nvec, dtype=float))
    w = np.ascontiguousarray(np.asarray(omega_dir, dtype=float))
    f = np.ascontiguousarray(np.asarray(deformation, dtype=float))
    if native is None:
        return reference.energy_ratio_general(n, w, f)
    return float(native.energy_ratio_general(n, w, f))
