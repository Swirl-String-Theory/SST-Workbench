#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Static marker/reference checker for the reviewed SST Canon v0.8.30 snapshot."""
from __future__ import annotations
import argparse, json, os, re
from collections import Counter
from pathlib import Path

EXPECTED_VERSION = "0.8.30"
REQUIRED_MAIN = [
    (r"\\newcommand\{\\canonversion\}\{0\.8\.30\}", "canonversion pinned to 0.8.30"),
    (r"subsec:density_ontology_v0830", "density ontology anchor"),
    (r"eq:density_ontology_v0830", "density ontology equation"),
    (r"eq:rhof_effective_response_alias", "rho_f effective-response alias"),
    (r"eq:rotational_translational_inertia_bridge_target", "rotational/translational bridge target"),
    (r"\\newcommand\{\\rhoSub\}", "rho_sub macro"),
    (r"\\newcommand\{\\rhoEff\}", "rho_eff macro"),
    (r"\\newcommand\{\\Jomega\}", "J_omega macro"),
    (r"\\newcommand\{\\muell\}", "mu_l macro"),
    (r"CALIBRATED / PROVENANCE GUARD", "calibrated density provenance guard"),
    (r"DEPENDENCY GUARD", "primitive dependency guard"),
    (r"CANON / NON-IDENTIFICATION", "density-role non-identification guard"),
    (r"Axiom~1 does not numerically identify", "Axiom-1 level-separation guard"),
    (r"Exact-closure benchmark ledger", "reviewed benchmark tautology guard"),
]
REQUIRED_RT = [
    (r"subsec:rt_historical_rhof_provenance_audit", "historical density provenance audit"),
    (r"eq:rt_vam7_historical_microinertia", "historical VAM microinertia equation"),
    (r"eq:rt_vam7_microinertia_closed_form", "closed-form historical microinertia"),
    (r"kg\\,m\^{-1\}", "historical unit corrected to kg m^-1"),
    (r"not define a mass density", "explicit historical non-density statement"),
    (r"sec:rt_rhof_cosmological_impedance_route", "cosmological impedance route anchor"),
    (r"epoch-invariant", "epoch-invariance gate"),
    (r"7\.76344071\\times10\^\{20\}", "reviewed omega_c precision correction"),
]
LABEL_TOKENS = ["[ORTHODOX]", "[DERIVED]", "[CALIBRATED]", "[SPECULATIVE]",
                "[CRITICAL NOTE]", "[RESEARCH]", "[MATCHING ANSATZ]",
                "[REFORMULATION]", "[DERIVED NEGATIVE]"]

def read(path: str) -> str:
    return Path(path).read_text(encoding="utf-8", errors="replace")

def marker_checks(text: str, required, filename: str, results: list[dict]) -> None:
    for pattern, desc in required:
        ok = re.search(pattern, text) is not None
        results.append({"file": filename, "kind": "marker", "desc": desc, "ok": ok, "pattern": pattern})
        print(f"  [{'PASS' if ok else 'FAIL'}] {filename}: {desc}")

def labels(text: str) -> list[str]:
    return re.findall(r"\\label\{([^}]*)\}", text)

def refs(text: str) -> set[str]:
    return set(re.findall(r"\\(?:ref|eqref|pageref)\{([^}]*)\}", text))

def main() -> int:
    ap = argparse.ArgumentParser(description="SST Canon v0.8.30 marker checker")
    ap.add_argument("main")
    ap.add_argument("rt")
    ap.add_argument("--json")
    args = ap.parse_args()
    for p in (args.main, args.rt):
        if not os.path.exists(p):
            print(f"ERROR: missing file {p}")
            return 2
    mt, rt = read(args.main), read(args.rt)
    mn, rn = os.path.basename(args.main), os.path.basename(args.rt)
    results: list[dict] = []
    print("#"*78)
    print("# SST Canon v0.8.30 reviewed snapshot marker check")
    print("#"*78)
    print("\n-- main markers --")
    marker_checks(mt, REQUIRED_MAIN, mn, results)
    print("\n-- research-track markers --")
    marker_checks(rt, REQUIRED_RT, rn, results)

    all_labels = labels(mt) + labels(rt)
    dupes = sorted(k for k,v in Counter(all_labels).items() if v > 1)
    ok = not dupes
    results.append({"kind":"structure","desc":"no duplicate labels across main+RT","ok":ok,"detail":dupes})
    print(f"  [{'PASS' if ok else 'FAIL'}] combined labels: {len(all_labels)} total, {len(dupes)} duplicates")

    defined = set(all_labels)
    all_refs = refs(mt) | refs(rt)
    unresolved = sorted(all_refs - defined)
    ok = not unresolved
    results.append({"kind":"structure","desc":"no unresolved refs across main+RT","ok":ok,"detail":unresolved})
    print(f"  [{'PASS' if ok else 'FAIL'}] combined references: {len(all_refs)} refs, {len(unresolved)} unresolved")

    input_ok = "\\input{SST_CANON-v0.8.30-research-track}" in mt
    results.append({"kind":"structure","desc":"main inputs v0.8.30 research track","ok":input_ok})
    print(f"  [{'PASS' if input_ok else 'FAIL'}] main input points to v0.8.30 research track")

    census = {token: mt.count(token)+rt.count(token) for token in LABEL_TOKENS}
    results.append({"kind":"census","desc":"epistemic label census","ok":None,"detail":census})
    print("\n-- label census --")
    for k,v in sorted(census.items(), key=lambda kv: -kv[1]):
        print(f"  {k:<22} {v}")

    graded = [r for r in results if r["ok"] is not None]
    passed = sum(bool(r["ok"]) for r in graded)
    print("\n"+"="*78)
    print(f"RESULT: {passed}/{len(graded)} required checks passed")
    print("="*78)
    payload = {"canon_version": EXPECTED_VERSION, "passed": passed, "total": len(graded), "results": results}
    if args.json:
        Path(args.json).write_text(json.dumps(payload, indent=2)+"\n", encoding="utf-8")
        print(f"[wrote {args.json}]")
    return 0 if passed == len(graded) else 1

if __name__ == "__main__":
    raise SystemExit(main())
