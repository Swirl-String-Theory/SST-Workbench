# Revealed summary

Freeze SHA-256: `c8cfdf2fd67a88b818ad657a3ac349719bb1ce3e0f7ccdd4a998b26848fcfbfd`

| Case | Split | Overall | Source |
|---|---|---|---|
| C3BF9E6F3140E | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_0.1_final.txt` |
| C735E8D103207 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_10.123_final.txt` |
| C6D9FFA71A806 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_10.1_final.txt` |
| C6FF0EAE2EB48 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_3.1_final.txt` |
| CBD839C47F77D | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_4.1_final.txt` |
| CC74FAD4B15B1 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_5.1_final.txt` |
| C229A693227C3 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_5.2_final.txt` |
| C3E82D1B95230 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_6.1_final.txt` |
| C951379EE5967 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_6.2_final.txt` |
| C3FF1CA3856CA | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_6.3_final.txt` |
| CD5668769AF62 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.1_final.txt` |
| C9C47B1A204D4 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.2_final.txt` |
| CA202A911B72B | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.3_final.txt` |
| CF0BDC28E9E96 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.4_final.txt` |
| C54FAA8F76211 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_8.17_final.txt` |
| C54DFFED96BA9 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_8.18_final.txt` |
| C49A9795CF8EE | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_8.1_final.txt` |
| CB8D4B1EE8809 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_9.1_final.txt` |
| C625259D85242 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_9.2_final.txt` |
| CD97BC55AD461 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_9.35_final.txt` |
| CEFE67299F341 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_0.2.1_final.txt` |
| C5FEEB60EC6B9 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_0.3.1_final.txt` |
| CCFEF3769076B | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_2.2.1_final.txt` |
| C4971410EC4DF | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_4.2.1_final.txt` |
| C88FE6CAB3666 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_5.2.1_final.txt` |
| C117A832D66F0 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.2.1_final.txt` |
| C3B9233A5AD44 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.3.1_final.txt` |
| C4341E12FB5D7 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.3.2_final.txt` |
| CBAB65A5A75D7 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.3.3_final.txt` |
| C4993271639B6 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_7.2.5_final.txt` |
| CE524E3DAA394 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_7.2.6_final.txt` |
| C86DAA084C7F1 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_7.2.8_final.txt` |
| C9BD858FA88D4 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_8.2.1_final.txt` |
| C0E09086D4FAC | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_9.2.20_final.txt` |
| C1463EAE65D0B | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_9.2.40_final.txt` |
| C8306F6F2A3F4 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.11_final.txt` |
| C4C40710043A8 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.3_final.txt` |
| C8F064078C18C | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.4_final.txt` |
| CC72913123696 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.5_final.txt` |
| C99F0BFBEFBCF | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.6_final.txt` |
| C2152E43FAD48 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.7_final.txt` |
| C79A57F5D1503 | holdout | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.8_final.txt` |
| C141FD7F58339 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.9_final.txt` |
| CCBCF2D07BB5B | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_3.3_final.txt` |
| C3882AA6451BB | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_3.6_final.txt` |
| C2A093A6A7903 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_3.9_final.txt` |
| CB9658A34C75B | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_6.15_final.txt` |
| C274A6EE61F3B | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_6.21_final.txt` |
| CFAE124A3FC80 | train | INDETERMINATE | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_6.9_final.txt` |
