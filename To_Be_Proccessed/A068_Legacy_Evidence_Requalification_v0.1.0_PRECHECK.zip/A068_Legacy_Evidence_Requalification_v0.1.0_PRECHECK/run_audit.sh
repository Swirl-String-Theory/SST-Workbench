#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 1 ]]; then echo 'Usage: ./run_audit.sh /path/to/SST-Workbench' >&2; exit 2; fi
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
python3 "$SCRIPT_DIR/src/a068_audit.py" --workbench "$1" --out "$SCRIPT_DIR/outputs/local_audit"
