# A044 v0.2.0 patch notes

This is intentionally an **A044 upgrade**, not a new A052 family, because the existing A044 question already is cosmic gamma transparency / dispersion / emergent Lorentz behavior.

Changes relative to A044-v0.1.0:

- final PRL source replaces accepted-preprint status;
- primary conventional count follows the Letter's `~10^-96` wording;
- ALP-only insufficiency becomes an explicit blind gate;
- pair-production threshold uplift diagnostic added;
- simple cosmological timing inversion added as a conditional diagnostic;
- published Ofengeim--Piran nonlinear timing-scale compatibility added;
- arbitrary independently-derived `delta_v_over_c = 1-v_g/c` candidate interface added (avoids catastrophic cancellation for tiny deviations);
- SST closure remains open unless a frozen candidate payload is supplied;
- legacy v0.1 lower constraints retained explicitly for continuity and marked by provenance.

- v0.1 lower-bound intersections are now explicitly tagged `CONDITIONAL` for arbitrary SST candidates; this avoids treating model-sector assumptions as universal while preserving the numerical regression checks.
