These benchmarks can be run by selecting the menu entry 

Control panel-->Benchmarks

from the KnotPlot popup menu.



To access the popup menu, right click in the Control Panel

or Monitor windows.



For purposes of consistency across platforms, click on 

the "resize view window" button if the window doesn't

appear to be 700x700 pixels in size.



