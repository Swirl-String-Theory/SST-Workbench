from pathlib import Path
import argparse
from a054_blind.blind import run_blind
p=argparse.ArgumentParser(); p.add_argument('--campaign',required=True); p.add_argument('--config',required=True); a=p.parse_args(); run_blind(Path(a.campaign),Path(a.config))
