# SST Route I Relative-Entropy PoC v0.0.2

Version 0.0.2 retains all v0.0.1 checks and adds the next theorem target:
canonical normalization of the SST transverse torsion field.

## Added in v0.0.2

The script derives and verifies

\[
\Phi_T=\sqrt{Z_T}\,A,
\qquad
Z_T=\sqrt{\rho_{\!f}K_T}=\rho_{\!f}c_T,
\]

\[
\varphi_T=\sqrt{\frac{Z_T}{\hbar}}\,A,
\qquad
\widehat\phi=L_\star\varphi_T.
\]

It checks the transformed action, physical Hamiltonian, canonical symplectic
form, and dimensionless-field round trip. It also sweeps the normalization over
\(L_\star=1\ \mathrm m\), \(1\ \mathrm{mm}\), and \(r_c\), exposing whether a
fixed dimensionless pulse remains in the linear displacement regime.

## Run

```bash
python sst_relative_entropy_route1_poc_v0.0.2.py \
  --output-dir output
```

Use a different affine normalization scale:

```bash
python sst_relative_entropy_route1_poc_v0.0.2.py \
  --normalization-length-scale 0.001 \
  --output-dir output_mm
```

Test an independently proposed torsion stiffness:

```bash
python sst_relative_entropy_route1_poc_v0.0.2.py \
  --torsion-stiffness 1.0e10 \
  --output-dir output_KT_test
```

## Default result

All ten automated tests pass. The new normalization errors are

\[
\varepsilon_S=1.33\times10^{-16},
\qquad
\varepsilon_H=1.17\times10^{-16},
\qquad
\varepsilon_\Omega=0.
\]

The relative-entropy and Raychaudhuri results remain unchanged from v0.0.1.

## Output

- `audit_report.json`: full theorem statement, numerical values, tests, and open gates;
- `normalization_scale_sweep.csv`: scale-dependent displacement/strain audit;
- `convergence.csv`: horizon integral convergence;
- three diagnostic PNG figures.

Read `THEOREM_TARGET_v0.0.2.md` for the complete derivation and dimensional
analysis.

## Epistemic status

\[
\boxed{\text{DERIVED-CONDITIONAL}}
\]

The canonical field redefinition follows from the quadratic Research-Track
Lagrangian. The physical realization of the QFT horizon state, the value of
\(K_T\), the KMS condition, and the affine scale \(L_\star\) remain open.
