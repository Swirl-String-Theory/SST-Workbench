#!/usr/bin/env python3
"""
s2_sine_gordon_breather.py  —  AUDIT §1  (conversation turn 10)

CLAIM UNDER TEST
    A soliton governed by a relativistic wave operator (box) carries an internal
    clock that, under a Lorentz boost, dilates by EXACTLY gamma and contracts in
    width by EXACTLY 1/gamma. This is what an SST swirl-clock must do and what a
    Galilean (incompressible-Euler) soliton does NOT do.

    The sine-Gordon breather is the concrete witness:
        phi(x,t) = 4 arctan[ (eta/omega) sin(omega t) / cosh(eta x) ],  eta = sqrt(1-omega^2)
    rest internal period T0 = 2*pi/omega, rest width ~ 1/eta   (units c = 1).

METHOD (purely numerical, no fitting of the answer)
    Boost to velocity v:  x' = gamma(x - v t),  t' = gamma(t - v x).
    1) Measure the oscillation period of the boosted field along the soliton
       worldline x = v t (via FFT) -> compare to gamma * T0.
    2) Measure the spatial width of the boosted field at a fixed lab time
       -> compare to (rest width)/gamma.

STATUS OF RESULT:  [DERIVED]  (sine-Gordon is Lorentz-invariant; the dilation is exact)
"""
import numpy as np

def breather(x, t, omega):
    eta = np.sqrt(1.0 - omega**2)
    return 4.0*np.arctan((eta/omega)*np.sin(omega*t)/np.cosh(eta*x))

def boosted(x, t, omega, v):
    g = 1.0/np.sqrt(1.0 - v**2)
    xp = g*(x - v*t)
    tp = g*(t - v*x)
    return breather(xp, tp, omega)

omega = 0.6
v     = 0.8
gamma = 1.0/np.sqrt(1.0 - v**2)
eta   = np.sqrt(1.0 - omega**2)
T0    = 2*np.pi/omega
w0    = 1.0/eta                      # rest-frame characteristic width

# ---- 1) period along the worldline x = v t ----
tt = np.linspace(0, 20*T0, 200000)
signal = boosted(v*tt, tt, omega, v)
sig = signal - signal.mean()
freqs = np.fft.rfftfreq(len(tt), d=(tt[1]-tt[0]))
amp   = np.abs(np.fft.rfft(sig))
f_peak = freqs[np.argmax(amp)]
T_meas = 1.0/f_peak
T_pred = gamma*T0
print("="*64)
print("CLOCK DILATION (sine-Gordon breather)")
print("="*64)
print(f"omega={omega}  v={v}  gamma={gamma:.6f}")
print(f"rest internal period T0      = {T0:.6f}")
print(f"measured lab period          = {T_meas:.6f}")
print(f"predicted gamma*T0           = {T_pred:.6f}")
print(f"ratio T_meas/(gamma*T0)      = {T_meas/T_pred:.5f}   (claim 1.000)")
assert abs(T_meas/T_pred - 1.0) < 0.01

# ---- 2) spatial width via RMS of the TIME-AVERAGED energy density (removes breathing + phase winding) ----
def energy_rms_width(vv):
    """RMS spatial width of the period-averaged energy density of the (boosted) breather."""
    g = 1.0/np.sqrt(1.0 - vv**2) if vv != 0 else 1.0
    Tlab = g*T0
    xi = np.linspace(-30, 30, 6001)          # comoving coordinate xi = x - v t
    dxi = xi[1]-xi[0]
    ts = np.linspace(0, Tlab, 240, endpoint=False)
    ebar = np.zeros_like(xi)
    h = 1e-4
    for tl in ts:
        xx = xi + vv*tl
        phi   = boosted(xx,     tl,   omega, vv)
        phi_t = (boosted(xx, tl+h, omega, vv) - boosted(xx, tl-h, omega, vv))/(2*h)
        phi_x = (boosted(xx+h, tl,  omega, vv) - boosted(xx-h, tl,  omega, vv))/(2*h)
        e = 0.5*phi_t**2 + 0.5*phi_x**2 + (1 - np.cos(phi))
        ebar += e
    ebar /= len(ts)
    norm = np.trapezoid(ebar, dx=dxi)
    mean = np.trapezoid(xi*ebar, dx=dxi)/norm
    var  = np.trapezoid((xi-mean)**2*ebar, dx=dxi)/norm
    return np.sqrt(var)

sig_rest = energy_rms_width(0.0)
sig_boost = energy_rms_width(v)
print("\n"+"="*64)
print("LENGTH CONTRACTION (RMS width of period-averaged energy density)")
print("="*64)
print(f"rest RMS width      sigma_0  = {sig_rest:.5f}")
print(f"boosted RMS width   sigma_v  = {sig_boost:.5f}")
print(f"ratio sigma_0/sigma_v        = {sig_rest/sig_boost:.5f}   (claim gamma = {gamma:.5f})")
assert abs((sig_rest/sig_boost)/gamma - 1.0) < 0.03

print("\n>>> A box-governed soliton clock dilates by exactly gamma and contracts by 1/gamma.")
print(">>> A Galilean (incompressible-Euler) soliton does neither: it just translates. [DERIVED]")
print("\nALL §1-breather CHECKS PASSED.")
