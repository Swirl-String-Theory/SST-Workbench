# Changelog v0.0.3

- Replaced the arbitrary `--normalization-length-scale` input by
  `--clock-log-gradient`.
- Derived
  \(L_\star=1/|\partial_n\ln\mathcal S|=c_T^2/a_\chi\).
- Added effective Rindler-coordinate and constant-acceleration audits.
- Fixed the modular orientation geometrically as
  \(U\to e^{-2\pi t}U\).
- Added complex-time KMS certification for the accelerated Wightman function.
- Added Unruh--DeWitt detector detailed-balance tests.
- Added KMS scale and detector-gap CSV outputs.
- Preserved all v0.0.1--v0.0.2 tests.
- Reclassified the targeted gate as
  `CLOSED-CONDITIONAL / EFFECTIVE-SECTOR THEOREM`.
