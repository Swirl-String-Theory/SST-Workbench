# A064 gate results
- Mode: `SNAPSHOTS_MODEL_RECONSTRUCTION`
- Evidence: `geometry_derived_regularized_biot_savart_simulation`
- Discovery SHA-256: `e50d436b40fb9027a64677fdfde6196dde663aa7dde149253a816d78e90e2046`
- Divergence (p95 dx/U): `0.0087355`
- Candidate identified: `True`
- Feature status: `DYNAMICAL_STATUS_UNRESOLVED`
- True separatrix manifold gate: `UNRESOLVED_NOT_CONSTRUCTED`
- Overall: `UNRESOLVED`
