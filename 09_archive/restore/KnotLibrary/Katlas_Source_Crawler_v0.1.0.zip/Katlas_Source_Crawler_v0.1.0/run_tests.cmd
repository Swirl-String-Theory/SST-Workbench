@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
.venv\Scripts\python.exe tests\test_naming.py || exit /b 1
.venv\Scripts\python.exe tests\test_parser.py || exit /b 1
