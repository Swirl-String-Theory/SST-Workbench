# SST Canon v0.8.28 — evidence pack

Successor to `sst_v0_8_17_evidence_pack_port`. Built directly against the
v0.8.28 canon files in Project Knowledge, not ported by relabelling.

**Read `AUDIT_REPORT_v0_8_28.md` first.** This README is the manifest and
run instructions only.

---

## Contents

```
AUDIT_REPORT_v0_8_28.md        referee-style audit (verdict, issues, recommendations)
README.md                      this file

scripts/
  sst_v0_8_28_verification_suite.py   13-section numerical claim ledger (111 graded checks)
  rt_action_phase_residuals.py        v0.8.28 residual protocol + discriminating counter-model
  check_canon_markers.py              static LaTeX marker / structural checker

patches/
  0001-precision-fmax-printed-value.patch          F_max: 29.053507 -> 29.053510 N (2 sites)
  0002-precision-omega-c-and-rt-clock-table.patch  omega_c: ...066 -> ...071 (8 sites) + 3 table values
  0003-benchmark-table-tautology-guard.patch       benchmark table: mark closure inputs as inputs

results/
  suite_results_v0_8_28.json          machine-readable ledger
  suite_stdout.txt                    full run log
  suite_stderr.txt                    (empty)
  rt_action_phase_residuals.json      Model A / Model B / fixed-V guard tables
  rt_action_phase_residuals_stdout.txt
  canon_marker_report.json            marker + label census + ref analysis
  canon_marker_stdout.txt
  environment.json                    versions this pack was run under
```

## How to run

```bash
pip install numpy SSTcore --break-system-packages     # SSTcore optional but recommended

python3 scripts/sst_v0_8_28_verification_suite.py --json results/suite_results_v0_8_28.json
python3 scripts/rt_action_phase_residuals.py         --json results/rt_action_phase_residuals.json
python3 scripts/check_canon_markers.py  MAIN.tex RT.tex --json results/canon_marker_report.json
```

`check_canon_markers.py` defaults to `/mnt/project/SST_CANON-v0_8_28*.tex`; pass
your local paths as the first two arguments.

Suite sections can be run individually:

```bash
python3 scripts/sst_v0_8_28_verification_suite.py --list
python3 scripts/sst_v0_8_28_verification_suite.py --only constants actionphase massbaseline
```

Exit code is 0 only when every graded check passes.

## Applying the patches

```bash
cd /path/to/canon
patch -p1 --dry-run -i .../patches/0001-precision-fmax-printed-value.patch
patch -p1 --dry-run -i .../patches/0002-precision-omega-c-and-rt-clock-table.patch
patch -p1 --dry-run -i .../patches/0003-benchmark-table-tautology-guard.patch
```

Merge order `0001 → 0002 → 0003`, verified sequentially in this container.
Line endings are preserved as found: CRLF for `SST_CANON-v0_8_28.tex`, LF for
`SST_CANON-v0_8_28-research-track.tex`. Patch `0001`/`0003` touch the main canon,
`0002` touches the research track only. After applying, `check_canon_markers.py`
still returns 27/27.

## Run recorded in `results/`

| | |
|---|---|
| Canon | v0.8.28 (main 7313 lines, RT 11152 lines) |
| Suite | **111/111 graded checks passed**, 13 sections |
| Residual harness | Model A max residual `4.35e-07`; Model B max `Delta_q` `1.94e-01`, monotone; guard `PASS` |
| Marker check | **27/27 required**, 0 duplicate labels, 0 unresolved refs, 49 cross-document pointers (resolved via `\input`) |
| Python / numpy / SSTcore | 3.12 / 2.4.4 / **0.8.18** |

## Scope and limits

This pack is a **numerical claim ledger plus a static marker checker**. It is
not a LaTeX compilation test, not a proof of canon consistency, and not
evidence for SST. Most passing checks are `[CALIBRATED]` identities that are
forced once `vchar = alpha c/2` is adopted; the ledger labels each one at the
point of use. The `alpha` section deliberately records **no** pass/fail,
because an obstruction is not a check that can be passed.

Open items carried forward unchanged: `rho_f` provenance, `alpha` ppm closure
(blocked at gates `G_0`/`G_1`), `theta = pi` superselection, KAM-T stage-1
numerics, and the boost-symmetry-breaking bound.
