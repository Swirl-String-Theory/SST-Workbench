# Relational time, clock fields, gravity, and tensor-speed constraints

## Slide 1/15 - Canonical time ontology

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Underlying ordering parameter exists.
- Observable proper time is reconstructed from vortex clocks.
- Substrate time and proper time are distinct.

**Single slide message:** Underlying ordering parameter exists.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 2/15 - Swirl-clock and local proper time

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Stable internal cycles define local clocks.
- Clock rate is carrier-local.
- Connects internal structure to observed time.

**Single slide message:** Stable internal cycles define local clocks.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 3/15 - Carrier-local turnover scale

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Turnover time is tied to core and swirl scales.
- It differs from free torsion travel time.
- Separating time scales prevents errors.

**Single slide message:** Turnover time is tied to core and swirl scales.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 4/15 - Conserved-current observables

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Observables are built from physical exchanges.
- They avoid direct substrate coordinates.
- Supports operational relativity.

**Single slide message:** Observables are built from physical exchanges.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 5/15 - Time-of-arrival field observable

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Arrival times define radar distance/simultaneity.
- Must be insensitive to hidden substrate motion at low energy.
- Links pulses to local spacetime.

**Single slide message:** Arrival times define radar distance/simultaneity.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 6/15 - Clock broadening and continuum

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Many carriers produce coarse clock fields.
- Internal distributions may broaden clocks.
- Continuum averaging needs discipline.

**Single slide message:** Many carriers produce coarse clock fields.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 7/15 - Gravity and geometry connection

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Clock-rate gradients can be read geometrically.
- Pressure and density enter gravity response.
- Weak-field limits must be recovered.

**Single slide message:** Clock-rate gradients can be read geometrically.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 8/15 - Clock field and foliation

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Clock field encodes rate relative to substrate ordering.
- Foliation is bookkeeping background.
- Observed geometry emerges from clocks and signals.

**Single slide message:** Clock field encodes rate relative to substrate ordering.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 9/15 - Clock-sector action

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- A clock action can yield field equations.
- Coefficients require provenance.
- Must be compatible with vortex/link sectors.

**Single slide message:** A clock action can yield field equations.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 10/15 - Poisson limit

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Weak-field Poisson-like limit is required.
- Density source and pressure response are distinct.
- No-monopole and boundary conditions matter.

**Single slide message:** Weak-field Poisson-like limit is required.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 11/15 - Tensor-mode speed constraint

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Observed tensor-speed constrains gravity-like propagation.
- Light/tensor/matter cones must align where required.
- Monometricity is a theorem target.

**Single slide message:** Observed tensor-speed constrains gravity-like propagation.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 12/15 - Tensor-speed naturalness

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Shared link cone makes equal speeds natural.
- Separate sector coefficients make equality tuning.
- Motivates monometricity tests.

**Single slide message:** Shared link cone makes equal speeds natural.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 13/15 - EM-gravity closure

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- EM-like link field and clock/gravity response must be compatible.
- The same operational speed cannot be double-defined inconsistently.

**Single slide message:** EM-like link field and clock/gravity response must be compatible.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 14/15 - Triadic gravity response

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Mass-energy, pressure/source, and clock response form a triad.
- Each leg requires derivation and test.
- Failure in one leg limits the corollary.

**Single slide message:** Mass-energy, pressure/source, and clock response form a triad.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.

## Slide 15/15 - Time/gravity closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST reconstructs local time from vortex matter.
- Gravity is a clock/pressure/geometric bridge.
- Full Einstein dynamics remains research.

**Single slide message:** SST reconstructs local time from vortex matter.

**Source anchors:** Relational Time Framework; Clock field; Poisson limit; tensor-speed constraint; Relativity Emergence Ladder.

**Visual specification:** Alice/Bob radar clocks over a pressure/clock-field background.

**Do not generate:** Do not claim full Einstein equations are already derived.
