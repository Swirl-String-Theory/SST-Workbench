# Surface-spectrum derivation of N_p=4

## Result

Status: `DERIVED_IN_SPHERICAL_SURFACE_VARIATION`

Retained modes: `[0, 1]`

N_p retained: `4`


For a spherical boundary perturbation

\[ r(\Omega)=R[1+\epsilon f(\Omega)]. \]

The fixed-volume second variation of area is

\[ \delta^2 A = \frac{R^2}{2}\int_{S^2}(|\nabla_S f|^2-2f^2)\,d\Omega. \]

For \(f=Y_{\ell m}\), the stiffness is

\[ k_\ell=\ell(\ell+1)-2=(\ell-1)(\ell+2). \]

Thus \(\ell=0\) is the volume/compression pressure mode, \(\ell=1\) is the translation/centre-displacement sector, and \(\ell\ge2\) are positive-stiffness shape modes.

\[ N_p=\dim H_0+\dim H_1=1+3=4. \]


## Epistemic status

This closes the N_p=4 gate inside the spherical finite-cell surface variation. It does not claim that nonspherical finite-core corrections are negligible; that remains a robustness test.
