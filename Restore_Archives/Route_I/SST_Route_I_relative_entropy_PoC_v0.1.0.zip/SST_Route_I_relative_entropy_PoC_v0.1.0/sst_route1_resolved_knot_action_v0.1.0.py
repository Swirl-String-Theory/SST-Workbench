#!/usr/bin/env python3
"""SST Route-I v0.1.0: resolved-knot action ladder and local-cell selector.

This release distinguishes three objects that were conflated in earlier drafts:

  I_K       = (1/2pi) integral p dq       canonical action variable,
  A_cycle   = integral p dq = 2pi I_K    full phase-space cycle integral,
  E/Omega   = I_K only for a linear oscillator with E=Omega I.

For the frozen Rankine rotor, E/Omega = I_K/2.  The script evaluates the
preregistered geometry ladder ring -> resolved torus -> 3_1 -> mirror 3_1 -> 4_1,
checks parity and species universality, tests regularized Biot-Savart relative-
equilibrium residuals, and solves the local adjacency-cell action match

    hbar beta_Q = j_phi a_star(beta_Q)

without using G, L_p, eta_A^GR, or observed c as selector inputs.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import brentq
from scipy.special import lambertw

VERSION = "0.1.0"
HBAR = 1.054571817e-34
C_OBS = 299792458.0  # post-selection comparator only
V_SWIRL = 1.09384563e6
R_C = 1.40897017e-15
RHO_F = 7.0e-7
RHO_HORN = 3.8934358266918687e18  # calibrated horn-envelope branch
GAMMA_0 = 2.0 * math.pi * R_C * V_SWIRL
LN2 = math.log(2.0)
BETA_COULOMB_PRECERT = 1.05  # inherited finite-volume pre-certification threshold


@dataclass(frozen=True)
class FourierKnot:
    source_id: str
    source_ropelength: float
    coeffs: tuple[tuple[int, np.ndarray, np.ndarray], ...]


@dataclass
class ActionRow:
    label: str
    topology: str
    geometry_source: str
    model_layer: str
    source_ropelength_rad: float
    numerical_ropelength_rad: float
    length_relative_error: float
    core_radius_ratio: float
    core_energy_J: float | None
    core_turnover_rad_s: float | None
    E_over_Omega_Js: float | None
    E_over_Omega_over_hbar: float | None
    canonical_rotor_action_Js: float | None
    beta_total_action: float | None
    full_cycle_action_Js: float | None
    full_cycle_over_hbar: float | None
    beta_per_unit_ropelength: float | None
    biot_savart_energy_J: float
    transit_frequency_rad_s: float
    beta_BS_transit_proxy: float
    relative_equilibrium_residual: float
    rigid_translation_m_s: float
    rigid_rotation_rad_s: float
    recurrence_frequency_status: str
    epistemic_status: str


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_knot_xml(path: Path, source_id: str) -> FourierKnot:
    root = ET.parse(path).getroot()
    for ab in root.findall("AB"):
        if ab.attrib.get("Id") != source_id:
            continue
        coeffs: list[tuple[int, np.ndarray, np.ndarray]] = []
        for c in ab.findall("Coeff"):
            i = int(c.attrib["I"])
            A = np.fromstring(c.attrib["A"], sep=",")
            B = np.fromstring(c.attrib["B"], sep=",")
            if A.shape != (3,) or B.shape != (3,):
                raise ValueError(f"Malformed coefficient in {source_id}")
            coeffs.append((i, A, B))
        return FourierKnot(source_id, float(ab.attrib["L"]), tuple(coeffs))
    raise KeyError(f"Knot {source_id!r} not found in {path}")


def write_trimmed_geometry(path: Path, knots: Sequence[FourierKnot]) -> None:
    lines = ["<DATA Title=\"v0.1.0 preregistered action ladder\">"]
    for knot in knots:
        lines.append(f'  <AB Id="{knot.source_id}" L="{knot.source_ropelength:.12g}" D="1.0">')
        for i, A, B in knot.coeffs:
            af = ",".join(f"{x:.12g}" for x in A)
            bf = ",".join(f"{x:.12g}" for x in B)
            lines.append(f'    <Coeff I="{i}" A="{af}" B="{bf}" />')
        lines.append("  </AB>")
    lines.append("</DATA>")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def evaluate_fourier(knot: FourierKnot, n: int = 8192) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    x = np.zeros((n, 3), dtype=float)
    for i, A, B in knot.coeffs:
        x += np.cos(i * t)[:, None] * A + np.sin(i * t)[:, None] * B
    return x


def resample_closed(x: np.ndarray, n: int) -> tuple[np.ndarray, float]:
    xx = np.vstack([x, x[0]])
    seg = np.linalg.norm(np.diff(xx, axis=0), axis=1)
    s = np.concatenate([[0.0], np.cumsum(seg)])
    total = float(s[-1])
    targets = np.linspace(0.0, total, n, endpoint=False)
    out = np.column_stack([np.interp(targets, s, xx[:, k]) for k in range(3)])
    return out, total


def segment_geometry(x: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    xp = np.roll(x, -1, axis=0)
    dl = xp - x
    mid = 0.5 * (x + xp)
    return dl, mid, float(np.linalg.norm(dl, axis=1).sum())


def regularized_biot_savart(x: np.ndarray, cutoff: float, rho: float, gamma: float) -> tuple[float, np.ndarray, np.ndarray, np.ndarray, float]:
    """Rosenhead-regularized filament energy and velocity.

    E = rho gamma^2/(8pi) int int dX.dX'/sqrt(|X-X'|^2+a^2)
    v = gamma/(4pi) int dX' x (x-X')/(|x-X'|^2+a^2)^(3/2)

    This is a diagnostic surrogate, not a certified finite-core Euler solution.
    """
    dl, mid, length = segment_geometry(x)
    n = len(mid)
    pair_sum = 0.0
    velocity = np.zeros_like(mid)
    for i0 in range(0, n, 64):
        p = mid[i0 : i0 + 64]
        dpi = dl[i0 : i0 + 64]
        diff = p[:, None, :] - mid[None, :, :]
        r2 = np.sum(diff * diff, axis=2)
        pair_sum += float(np.sum((dpi @ dl.T) / np.sqrt(r2 + cutoff * cutoff)))
        cross = np.cross(dl[None, :, :], diff)
        velocity[i0 : i0 + 64] = gamma / (4.0 * math.pi) * np.sum(
            cross / (r2 + cutoff * cutoff)[:, :, None] ** 1.5,
            axis=1,
        )
    energy = rho * gamma * gamma / (8.0 * math.pi) * pair_sum
    return energy, velocity, mid, dl, length


def fit_relative_equilibrium(mid: np.ndarray, dl: np.ndarray, velocity: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    """Fit normal velocity to V + Omega x (X-Xc), removing tangential gauge."""
    center = mid.mean(axis=0)
    r = mid - center
    tangent = dl / np.linalg.norm(dl, axis=1)[:, None]
    projectors = np.eye(3)[None, :, :] - tangent[:, :, None] * tangent[:, None, :]
    blocks: list[np.ndarray] = []
    rhs: list[np.ndarray] = []
    for i in range(len(mid)):
        rx, ry, rz = r[i]
        r_cross = np.array([[0.0, -rz, ry], [rz, 0.0, -rx], [-ry, rx, 0.0]])
        # Omega x r = - r x Omega.
        map6 = np.hstack([np.eye(3), -r_cross])
        blocks.append(projectors[i] @ map6)
        rhs.append(projectors[i] @ velocity[i])
    A = np.vstack(blocks)
    b = np.concatenate(rhs)
    u, *_ = np.linalg.lstsq(A, b, rcond=None)
    pred = A @ u
    residual = float(np.linalg.norm(b - pred) / max(np.linalg.norm(b), 1e-300))
    return u[:3], u[3:], residual


def rankine_core_quantities(length: float, core_radius: float, rho: float = RHO_HORN, surface_speed: float = V_SWIRL) -> dict[str, float]:
    """Resolved solid-body Rankine core integrated along a tube centerline.

    v_theta(r)=Omega r, Omega=v_surface/a.
    E = (rho pi a^2 v_surface^2/4) L.
    L_phi = (rho pi a^3 v_surface/2) L.
    For a rotor, I_action=(1/2pi) integral p_phi dphi=L_phi, while E/Omega=L_phi/2.
    """
    omega = surface_speed / core_radius
    energy = 0.25 * rho * math.pi * core_radius**2 * surface_speed**2 * length
    angular_momentum = 0.5 * rho * math.pi * core_radius**3 * surface_speed * length
    return {
        "omega": omega,
        "energy": energy,
        "E_over_Omega": energy / omega,
        "I_rotor": angular_momentum,
        "A_cycle": 2.0 * math.pi * angular_momentum,
        "j_per_length": angular_momentum / length,
    }


def lambda_rankine(a_star: float) -> float:
    return math.log(a_star / (2.0 * R_C)) + 0.25


def a_star_from_beta(beta_q: float, rho_neck: float = RHO_HORN) -> float:
    c0 = 2.0 * math.pi * beta_q * HBAR / (rho_neck * GAMMA_0 * R_C**2)
    arg = c0**2 * math.exp(0.5) / (2.0 * R_C**2)
    z = 0.5 * float(lambertw(arg).real)
    if not z > 0.0:
        raise ValueError("Lambert-W closure returned non-positive branch")
    return c0 / math.sqrt(z)


def closure_from_beta(beta_q: float, rho_neck: float = RHO_HORN) -> dict[str, float]:
    a_star = a_star_from_beta(beta_q, rho_neck)
    lam = lambda_rankine(a_star)
    I_l = 0.5 * math.pi * rho_neck * R_C**4 * a_star
    K_l = rho_neck * GAMMA_0**2 * a_star * lam / (2.0 * math.pi**3)
    c_t = a_star * math.sqrt(K_l / I_l)
    return {
        "beta_Q": beta_q,
        "a_star_m": a_star,
        "a_over_rc": a_star / R_C,
        "lambda_rankine": lam,
        "I_l_kg_m2": I_l,
        "K_l_J": K_l,
        "c_T_m_s": c_t,
        "c_T_over_c": c_t / C_OBS,
        "eta_capacity_binary_m2_inv": 2.0 * LN2 / a_star**2,
    }


def local_cell_matching_root(core_radius_ratio: float, rho_tube: float = RHO_HORN, rho_neck: float = RHO_HORN) -> dict[str, float | str]:
    a_core = core_radius_ratio * R_C
    j_prime = 0.5 * rho_tube * math.pi * V_SWIRL * a_core**3

    def residual(beta: float) -> float:
        return j_prime * a_star_from_beta(beta, rho_neck) / HBAR - beta

    grid = np.geomspace(1e-8, 1e5, 1800)
    roots: list[float] = []
    prev_x = float(grid[0])
    prev_f = residual(prev_x)
    for x in grid[1:]:
        x = float(x)
        fx = residual(x)
        if prev_f == 0.0 or prev_f * fx < 0.0:
            roots.append(float(brentq(residual, prev_x, x, xtol=1e-14, rtol=1e-13)))
        prev_x, prev_f = x, fx
    if len(roots) != 1:
        return {
            "core_radius_ratio": core_radius_ratio,
            "root_count": len(roots),
            "status": "NO-UNIQUE-ROOT",
        }
    beta = roots[0]
    closure = closure_from_beta(beta, rho_neck)
    return {
        "core_radius_ratio": core_radius_ratio,
        "root_count": 1,
        "beta_Q": beta,
        "a_star_m": closure["a_star_m"],
        "a_over_rc": closure["a_over_rc"],
        "c_T_m_s": closure["c_T_m_s"],
        "c_T_over_c": closure["c_T_over_c"],
        "eta_capacity_binary_m2_inv": closure["eta_capacity_binary_m2_inv"],
        "phase_status": "COULOMB-COMPATIBLE" if beta >= BETA_COULOMB_PRECERT else "BELOW-COULOMB-PRECERT",
        "status": "UNIQUE-CONDITIONAL-ROOT",
    }


def write_csv(path: Path, rows: Iterable[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("geometry/ideal_ladder.xml"))
    parser.add_argument("--output-dir", type=Path, default=Path("output_v0.1.0"))
    parser.add_argument("--samples", type=int, default=192)
    args = parser.parse_args()
    source = args.source
    if not source.is_absolute():
        source = Path(__file__).resolve().parent / source
    out = args.output_dir
    if not out.is_absolute():
        out = Path(__file__).resolve().parent / out
    out.mkdir(parents=True, exist_ok=True)

    ring = parse_knot_xml(source, "0:1:1")
    trefoil = parse_knot_xml(source, "3:1:1")
    figure8 = parse_knot_xml(source, "4:1:1")

    base_shapes: dict[str, tuple[FourierKnot, bool]] = {
        "round ring filament": (ring, False),
        "axisymmetric Rankine torus": (ring, False),
        "trefoil 3_1": (trefoil, False),
        "mirror trefoil overline{3_1}": (trefoil, True),
        "figure-eight 4_1": (figure8, False),
    }

    action_rows: list[ActionRow] = []
    convergence_rows: list[dict] = []
    cached: dict[tuple[str, int, bool], dict] = {}

    # Resolution audit. The final action table uses args.samples; two bracketing
    # resolutions expose static-atlas and regularization sensitivity.
    resolutions = sorted(set([max(64, args.samples // 2), args.samples, args.samples * 2]))
    for label, (knot, mirror) in base_shapes.items():
        for n in resolutions:
            dense = evaluate_fourier(knot)
            x_unit, raw_length = resample_closed(dense, n)
            if mirror:
                x_unit[:, 0] *= -1.0
            x = x_unit * R_C
            E_bs, velocity, mid, dl, length = regularized_biot_savart(x, R_C, RHO_HORN, GAMMA_0)
            trans, rotation, rel_res = fit_relative_equilibrium(mid, dl, velocity)
            cached[(label, n, mirror)] = {
                "x": x,
                "length": length,
                "raw_dense_length": raw_length,
                "E_bs": E_bs,
                "translation": trans,
                "rotation": rotation,
                "rel_res": rel_res,
            }
            convergence_rows.append({
                "label": label,
                "samples": n,
                "numerical_ropelength_rad": length / R_C,
                "source_ropelength_rad": knot.source_ropelength,
                "length_relative_error": abs(length / R_C - knot.source_ropelength) / knot.source_ropelength,
                "biot_savart_energy_J": E_bs,
                "relative_equilibrium_residual": rel_res,
                "rigid_translation_m_s": float(np.linalg.norm(trans)),
                "rigid_rotation_rad_s": float(np.linalg.norm(rotation)),
            })

    n = args.samples
    for label, (knot, mirror) in base_shapes.items():
        d = cached[(label, n, mirror)]
        length = float(d["length"])
        E_bs = float(d["E_bs"])
        trans_norm = float(np.linalg.norm(d["translation"]))
        rot_norm = float(np.linalg.norm(d["rotation"]))
        rel_res = float(d["rel_res"])
        omega_transit = 2.0 * math.pi * V_SWIRL / length
        beta_bs_transit = E_bs / (HBAR * omega_transit)

        resolved = label != "round ring filament"
        if resolved:
            core = rankine_core_quantities(length, R_C)
            beta_total = core["I_rotor"] / HBAR
            beta_per_rop = beta_total / (length / R_C)
            recurrence_status = (
                "RIGID-TRANSLATING RELATIVE EQUILIBRIUM; NO CENTERLINE ROTATION FREQUENCY"
                if label == "axisymmetric Rankine torus" and rel_res < 1e-4
                else "STATIC ATLAS SHAPE FAILS 5% RELATIVE-EQUILIBRIUM GATE"
                if rel_res >= 0.05
                else "RELATIVE-EQUILIBRIUM CANDIDATE"
            )
            status = "DERIVED-CONDITIONAL RANKINE ROTOR / BS DIAGNOSTIC"
            row = ActionRow(
                label=label,
                topology="0_1" if "torus" in label else "3_1" if "trefoil" in label else "4_1",
                geometry_source=knot.source_id,
                model_layer="resolved Rankine tube + regularized filament diagnostic",
                source_ropelength_rad=knot.source_ropelength,
                numerical_ropelength_rad=length / R_C,
                length_relative_error=abs(length / R_C - knot.source_ropelength) / knot.source_ropelength,
                core_radius_ratio=1.0,
                core_energy_J=core["energy"],
                core_turnover_rad_s=core["omega"],
                E_over_Omega_Js=core["E_over_Omega"],
                E_over_Omega_over_hbar=core["E_over_Omega"] / HBAR,
                canonical_rotor_action_Js=core["I_rotor"],
                beta_total_action=beta_total,
                full_cycle_action_Js=core["A_cycle"],
                full_cycle_over_hbar=core["A_cycle"] / HBAR,
                beta_per_unit_ropelength=beta_per_rop,
                biot_savart_energy_J=E_bs,
                transit_frequency_rad_s=omega_transit,
                beta_BS_transit_proxy=beta_bs_transit,
                relative_equilibrium_residual=rel_res,
                rigid_translation_m_s=trans_norm,
                rigid_rotation_rad_s=rot_norm,
                recurrence_frequency_status=recurrence_status,
                epistemic_status=status,
            )
        else:
            row = ActionRow(
                label=label,
                topology="0_1",
                geometry_source=knot.source_id,
                model_layer="centerline filament only",
                source_ropelength_rad=knot.source_ropelength,
                numerical_ropelength_rad=length / R_C,
                length_relative_error=abs(length / R_C - knot.source_ropelength) / knot.source_ropelength,
                core_radius_ratio=1.0,
                core_energy_J=None,
                core_turnover_rad_s=None,
                E_over_Omega_Js=None,
                E_over_Omega_over_hbar=None,
                canonical_rotor_action_Js=None,
                beta_total_action=None,
                full_cycle_action_Js=None,
                full_cycle_over_hbar=None,
                beta_per_unit_ropelength=None,
                biot_savart_energy_J=E_bs,
                transit_frequency_rad_s=omega_transit,
                beta_BS_transit_proxy=beta_bs_transit,
                relative_equilibrium_residual=rel_res,
                rigid_translation_m_s=trans_norm,
                rigid_rotation_rad_s=rot_norm,
                recurrence_frequency_status="RIGID TRANSLATION ONLY; STATIC RING DOES NOT SUPPLY A PERIODIC CENTERLINE ACTION",
                epistemic_status="ORTHODOX FILAMENT DIAGNOSTIC / NO ACTION CLAIM",
            )
        action_rows.append(row)

    # Core-radius sensitivity and the independent local-cell fixed-point selector.
    sensitivity_rows: list[dict] = []
    for chi in [0.25, 0.50, 0.75, 0.80, 0.85, 0.90, 0.95, 1.00]:
        fixed = local_cell_matching_root(chi)
        for label, (knot, mirror) in base_shapes.items():
            if label == "round ring filament":
                continue
            length = float(cached[(label, n, mirror)]["length"])
            core = rankine_core_quantities(length, chi * R_C)
            sensitivity_rows.append({
                "core_radius_ratio": chi,
                "label": label,
                "beta_total_action": core["I_rotor"] / HBAR,
                "E_over_Omega_over_hbar": core["E_over_Omega"] / HBAR,
                "beta_per_unit_ropelength": core["I_rotor"] / HBAR / (length / R_C),
                "local_cell_beta_Q": fixed.get("beta_Q"),
                "local_cell_a_over_rc": fixed.get("a_over_rc"),
                "local_cell_c_T_m_s": fixed.get("c_T_m_s"),
                "local_cell_phase_status": fixed.get("phase_status"),
            })

    local_roots = [local_cell_matching_root(x) for x in [0.25, 0.50, 0.75, 0.80, 0.85, 0.90, 0.95, 1.00]]
    baseline_root = local_cell_matching_root(1.0)

    # Tests.
    resolved_rows = [r for r in action_rows if r.canonical_rotor_action_Js is not None]
    tre = next(r for r in resolved_rows if r.label == "trefoil 3_1")
    mir = next(r for r in resolved_rows if r.label.startswith("mirror trefoil"))
    tor = next(r for r in resolved_rows if r.label == "axisymmetric Rankine torus")
    fig = next(r for r in resolved_rows if r.label == "figure-eight 4_1")
    beta_values = [float(r.beta_total_action) for r in resolved_rows]
    tests = {
        "action_convention_rotor_factor_two": all(
            abs((r.canonical_rotor_action_Js or 0.0) / (2.0 * (r.E_over_Omega_Js or 1.0)) - 1.0) < 2e-12
            for r in resolved_rows
        ),
        "full_cycle_is_2pi_action": all(
            abs((r.full_cycle_action_Js or 0.0) / (2.0 * math.pi * (r.canonical_rotor_action_Js or 1.0)) - 1.0) < 2e-12
            for r in resolved_rows
        ),
        "mirror_trefoil_action_parity": abs((tre.beta_total_action or 0.0) - (mir.beta_total_action or 0.0)) < 2e-10,
        "mirror_trefoil_BS_energy_parity": abs(tre.biot_savart_energy_J / mir.biot_savart_energy_J - 1.0) < 2e-10,
        "total_action_not_species_universal": max(beta_values) / min(beta_values) > 2.0,
        "local_action_density_uniform": max(float(r.beta_per_unit_ropelength) for r in resolved_rows) - min(float(r.beta_per_unit_ropelength) for r in resolved_rows) < 2e-12,
        "ring_relative_equilibrium_translation_pass": tor.relative_equilibrium_residual < 1e-4,
        "trefoil_static_atlas_not_relative_equilibrium": tre.relative_equilibrium_residual > 0.05,
        "figure8_static_atlas_not_relative_equilibrium": fig.relative_equilibrium_residual > 0.05,
        "baseline_local_cell_root_unique": baseline_root.get("root_count") == 1,
        "baseline_local_cell_root_Coulomb_compatible": float(baseline_root.get("beta_Q", 0.0)) >= BETA_COULOMB_PRECERT,
        "baseline_local_cell_speed_not_observed_c": abs(float(baseline_root.get("c_T_over_c", 0.0)) - 1.0) > 0.5,
        "core_radius_sensitivity_changes_phase_verdict": any(r.get("phase_status") == "BELOW-COULOMB-PRECERT" for r in local_roots) and any(r.get("phase_status") == "COULOMB-COMPATIBLE" for r in local_roots),
    }

    report = {
        "version": VERSION,
        "status": "ACTION-CONVENTION-CLOSED / TOTAL-KNOT-UNIVERSALITY-REJECTED / LOCAL-CELL-SELECTOR-CONDITIONAL / DYNAMIC-EIGENMODE-OPEN",
        "forbidden_selector_inputs": ["G", "L_p", "eta_A_GR", "previous hierarchy factor", "observed c"],
        "source": {
            "geometry_file": str(source.relative_to(Path(__file__).resolve().parent)),
            "geometry_sha256": sha256(source),
            "ids": ["0:1:1", "3:1:1", "4:1:1"],
        },
        "action_convention": {
            "canonical_action": "I=(1/2pi) integral p dq",
            "full_cycle_integral": "A_cycle=integral p dq=2pi I",
            "harmonic_oscillator": "I=E/Omega",
            "Rankine_rotor": "I=L_core=2E/Omega",
            "beta_matching_object": "beta_Q=I_cell/hbar, not A_cycle/hbar and not automatically E/(hbar Omega)",
        },
        "action_ladder": [asdict(r) for r in action_rows],
        "local_cell_selector": {
            "equation": "hbar beta_Q = j_phi a_star(beta_Q)",
            "j_phi": "rho_tube pi v_surface a_core^3 / 2",
            "baseline_core_radius_ratio": 1.0,
            "baseline_result": baseline_root,
            "sensitivity": local_roots,
            "interpretation": "unique only under frozen Rankine profile, horn-envelope density branch, a_core choice, and v0.0.7 neck closure",
        },
        "dynamic_gate": {
            "method": "normal-velocity least-squares fit to rigid translation plus rotation under Rosenhead-regularized Biot-Savart",
            "threshold": 0.05,
            "result": "round ring passes as translating relative equilibrium; static ideal trefoil and figure-eight fail and therefore do not supply certified recurrence frequencies",
        },
        "tests": tests,
        "all_tests_pass": all(tests.values()),
        "epistemic_conclusion": {
            "closed": [
                "2pi and factor-two action convention",
                "parity equality of 3_1 and mirror under parity-even tube/filament energies",
                "non-universality of total resolved-tube rotor action",
            ],
            "conditional_new_candidate": "local adjacency-cell action matching gives beta_Q approximately 4.591716 for a_core=r_c",
            "not_closed": [
                "local material density/profile of the resolved tube",
                "physical core radius a_core relative to r_c",
                "certified periodic knot orbit and Floquet eigenfrequency",
                "c_T=c monometricity",
                "absolute area density",
            ],
        },
    }

    (out / "audit_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    write_csv(out / "action_ladder.csv", [asdict(r) for r in action_rows])
    write_csv(out / "resolution_convergence.csv", convergence_rows)
    write_csv(out / "core_radius_sensitivity.csv", sensitivity_rows)
    write_csv(out / "local_cell_fixed_points.csv", local_roots)

    # Plots.
    labels = [r.label for r in resolved_rows]
    betas = [float(r.beta_total_action) for r in resolved_rows]
    fig_obj, ax = plt.subplots(figsize=(9.2, 5.0))
    ax.bar(labels, betas)
    ax.axhline(BETA_COULOMB_PRECERT, linestyle="--", linewidth=1.0, label="finite-volume Coulomb pre-gate")
    ax.set_ylabel(r"total rotor action $I_K/\hbar$")
    ax.set_title("v0.1.0 resolved-tube total action ladder")
    ax.tick_params(axis="x", rotation=18)
    ax.legend()
    fig_obj.tight_layout()
    fig_obj.savefig(out / "total_action_ladder.png", dpi=190)
    plt.close(fig_obj)

    fig_obj, ax = plt.subplots(figsize=(8.6, 4.8))
    ax.bar([r.label for r in action_rows], [r.relative_equilibrium_residual for r in action_rows])
    ax.axhline(0.05, linestyle="--", linewidth=1.0, label="5% relative-equilibrium gate")
    ax.set_ylabel("normal-velocity residual")
    ax.set_title("Static atlas geometry under regularized Biot-Savart flow")
    ax.tick_params(axis="x", rotation=18)
    ax.legend()
    fig_obj.tight_layout()
    fig_obj.savefig(out / "relative_equilibrium_residuals.png", dpi=190)
    plt.close(fig_obj)

    fig_obj, ax = plt.subplots(figsize=(8.4, 4.8))
    chis = [float(r["core_radius_ratio"]) for r in local_roots]
    root_betas = [float(r.get("beta_Q", math.nan)) for r in local_roots]
    ax.plot(chis, root_betas, marker="o")
    ax.axhline(BETA_COULOMB_PRECERT, linestyle="--", linewidth=1.0, label="finite-volume Coulomb pre-gate")
    ax.set_xlabel(r"resolved core ratio $a_{\rm core}/r_c$")
    ax.set_ylabel(r"local-cell fixed point $\beta_Q$")
    ax.set_yscale("log")
    ax.set_title("v0.1.0 local action matching sensitivity")
    ax.legend()
    fig_obj.tight_layout()
    fig_obj.savefig(out / "local_cell_beta_sensitivity.png", dpi=190)
    plt.close(fig_obj)

    print(report["status"])
    for key, value in tests.items():
        print(f"[{'PASS' if value else 'FAIL'}] {key}")
    print("baseline local-cell beta_Q =", baseline_root.get("beta_Q"))
    print("baseline a_star/r_c =", baseline_root.get("a_over_rc"))
    print("baseline c_T/c =", baseline_root.get("c_T_over_c"))
    print("wrote", out)
    return 0 if report["all_tests_pass"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
