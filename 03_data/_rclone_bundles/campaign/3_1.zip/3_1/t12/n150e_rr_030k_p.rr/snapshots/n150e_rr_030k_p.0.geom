LIST {
	{ < n150e_rr_030k_p.0.vect }
	{ < n150e_rr_030k_p.0.struts.vect }
	{ < n150e_rr_030k_p.0.dlen.vect }
	{ < n150e_rr_030k_p.0.dVdt.vect }
}
