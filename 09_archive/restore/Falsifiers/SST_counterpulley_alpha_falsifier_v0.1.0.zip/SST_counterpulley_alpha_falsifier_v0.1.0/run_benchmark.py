#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from sst_counterpulley.benchmark import benchmark_blind
from sst_counterpulley.core import write_json

def main() -> int:
    ap=argparse.ArgumentParser(description="Post-hoc alpha benchmark for an already-written blind JSON result.")
    ap.add_argument("blind_json")
    ap.add_argument("--out",default="audit_out/posthoc_alpha_benchmark.json")
    a=ap.parse_args()
    src=json.loads(Path(a.blind_json).read_text(encoding="utf-8"))
    obs=src.get("observables",src)
    r=benchmark_blind(obs)
    write_json(a.out,r)
    print(json.dumps(r,indent=2))
    return 0
if __name__=="__main__": raise SystemExit(main())
