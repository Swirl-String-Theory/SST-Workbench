# Manifest

- `README.md` (1616 bytes)
- `canon_blocks/SST_CANON-v0.8.19-routeA-L2-photon-gas-falsifier-block.tex` (3120 bytes)
- `docs/ROUTE_A_L2_PHOTON_GAS_FALSIFIER_REPORT.md` (1659 bytes)
- `results/routeA_L2_photon_gas_falsifier_report.md` (944 bytes)
- `results/routeA_L2_photon_gas_falsifier_results.json` (2762 bytes)
- `review_prompts/CLAUDE_GEMINI_ROUTE_A_L2_PHOTON_FALSIFIER_PROMPT.md` (1058 bytes)
- `scripts/routeA_L2_photon_gas_falsifier.py` (6077 bytes)
