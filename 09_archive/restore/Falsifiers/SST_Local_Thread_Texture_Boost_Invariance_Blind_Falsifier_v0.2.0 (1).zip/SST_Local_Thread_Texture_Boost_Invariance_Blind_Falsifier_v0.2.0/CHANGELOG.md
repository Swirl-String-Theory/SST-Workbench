# CHANGELOG — v0.2.0

## Why this release exists

v0.2.0 is driven directly by the real `outputs_extended_20260820_195749` v0.1.0 campaign.

That campaign covered 49 accepted geometries and gave a clean numerical/infrastructure result:

- common-boost null at \(N=512\): median \(4.32\times10^{-16}R_g\), maximum \(3.15\times10^{-15}R_g\);
- translation covariance: median \(1.38\times10^{-14}R_g\), maximum \(2.09\times10^{-13}R_g\);
- rotation covariance: median \(1.81\times10^{-15}R_g\), maximum \(2.08\times10^{-14}R_g\);
- old radial-proxy \(N=256\rightarrow512\) convergence: median \(3.87\times10^{-4}\), worst \(1.4815\%\);
- old director-proxy convergence: median \(3.94\times10^{-4}\), worst \(1.7507\%\).

The two largest old radial holdouts were:

1. `link_0.3.1_final.txt` — 1.4815%;
2. `torus_6.21_final.txt` — 1.0288%.

Those numbers justified tightening the old 20% convergence gate and, more importantly, exposed that the v0.1.0 bridge physics itself was too weak.

## Scientific changes

### 1. Removed the radial potential-flow proxy

Removed

\[
\mathbf v\propto\frac{\mathbf r}{(r^2+a^2)^{3/2}}.
\]

It was a prescribed radial velocity field, not a bundle of vortex filaments.  With nonzero regularization it was not even exactly incompressible.

### 2. Removed the affine director-strain proxy

Removed

\[
\mathbf v=A\left(\mathbf n\mathbf n-\frac13\mathbf I\right)\frac{\mathbf x-\mathbf x_c}{R_g}.
\]

It was trace-free and incompressible, but symmetric/curl-free and therefore not an explicit vortex-thread background.

### 3. Replaced both by closed vortex loops

Every local active thread now has an anti-parallel remote return path and connectors.  The discrete vorticity current has no endpoints.  This prevents an implicit vorticity monopole from being hidden at an “Earth” source.

### 4. Added remote return-flux convergence

The same local active strands are run with return paths at 12, 24 and 48 \(R_g\).  The main result uses the far return.  G6 checks that moving the return from 24 to 48 \(R_g\) no longer materially changes the local response.

### 5. Added radial-to-parallel source-distance limit

For fixed local strand centers and circulation, increasing source distance must make the radial directions approach a parallel bundle.  G7 checks this explicit geometric limit rather than fitting a preferred result.

### 6. Added a second source

A second hidden source direction is generated from the same precommitted spherical direction set.  “Sun” is only a mnemonic label in v0.2.0; the strength and distance are uncalibrated stress-test parameters.

## Numerical changes

### 7. One-step Euler -> multi-step RK4

The old one-step identity

\[
\Delta\mathbf X=\Delta t\,\mathbf v_{\rm bg}
\]

made bridge response almost tautological.  v0.2.0 recomputes the knot self-field and background field at every RK4 stage, so later response depends on the evolved geometry.

### 8. Fixed physical core during spatial refinement

v0.1.0 used

\[
a_k=0.75\,\Delta s,
\]

so increasing \(N\) simultaneously changed resolution and the regularization model.  v0.2.0 instead keeps

\[
a_k/R_g=0.10
\]

fixed throughout the \(N\)-ladder.

### 9. Added finite straight-segment background kernel

The explicit background loops use a finite-segment Biot--Savart kernel in both C++ and pure Python.  This makes far return paths cheap and removes a second discretization ladder from the background geometry.

### 10. Tightened convergence classification

The v0.1.0 20% spatial threshold was much looser than the observed data.  v0.2.0 uses:

- `STANDARD_PASS`: <= 2%;
- `CERTIFIED_PASS`: <= 0.5%.

Temporal holdout certification uses:

- standard <= 1%;
- certified <= 0.2%.

### 11. Prior-release holdouts are frozen

`link_0.3.1_final.txt` and `torus_6.21_final.txt` are selected because they were the two worst old radial-convergence cases.  They are not selected after viewing v0.2.0 results.

### 12. Same hidden orientation ensemble for every topology

The v0.1.0 campaign drew a separate random source direction per geometry.  v0.2.0 freezes one hidden Fibonacci-sphere direction set and applies it to every knot/link, allowing topology response to be compared without orientation confounding.

## Epistemic change

`G8-G12` are no longer called “conditional bridge PASS” gates.  They are **measured predictions** of the explicit vortex-thread stress-test model.  The hard model gates are covariance, closed-filament validity, remote-return convergence and the large-source-distance limit.
