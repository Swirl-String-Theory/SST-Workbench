LIST {
	{ < n150c_rr_050k_e.0.vect }
	{ < n150c_rr_050k_e.0.struts.vect }
	{ < n150c_rr_050k_e.0.dlen.vect }
	{ < n150c_rr_050k_e.0.dVdt.vect }
}
