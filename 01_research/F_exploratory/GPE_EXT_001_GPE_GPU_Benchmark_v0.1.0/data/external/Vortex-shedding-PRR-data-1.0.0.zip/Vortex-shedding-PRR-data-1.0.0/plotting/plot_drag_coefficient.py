"""Recreate the drag-coefficient summary figure from merged data."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.lines import Line2D
from matplotlib.gridspec import GridSpec
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from scipy.optimize import curve_fit

from _common import FIGURE_DIR, load_merged, setup_matplotlib


V0_TARGETS = [0.7, 0.9]
INTV = 1
RATIO = 0.6
YERR_CUTOFF = 10
MS = 2.5
MEW = 0.5
SAVE_NAME = "drag_coefficient.png"


def power_model(Re, A, alpha):
    return A * Re ** (-alpha)


def collect_points_for_v0(merged, v0_target):
    return merged[
        (merged[:, 0] == v0_target)
        & (merged[:, 6] > 0)
        & np.isfinite(merged[:, 7])
        & np.isfinite(merged[:, 9])
        & (merged[:, 2] < 0.7)
    ]


def fit_for_range(Re_all, cd_all, re_min, re_max):
    mask = (Re_all >= re_min) & (Re_all <= re_max) & np.isfinite(Re_all) & np.isfinite(cd_all) & (cd_all > 0)
    re_fit, y_fit = Re_all[mask], cd_all[mask]
    if len(re_fit) < 3:
        return None
    err_fit = 0.1 * y_fit.clip(min=1e-6)
    return curve_fit(power_model, re_fit, y_fit, p0=[np.max(y_fit), 1.0], bounds=([0.0, 0.0], [np.inf, 4.0]), sigma=err_fit, absolute_sigma=True, maxfev=200000)[0]


def make_legend_bins():
    return {"sigma_handles": [], "sigma_labels": [], "seen_sigma": set()}


setup_matplotlib()
merged = load_merged()
sigma_palette = ["k", "C0", "C1", "C2", "C3", "C4", "C5", "C6", "C7"]
markers = ["<", "o", "s", "^", "D", "h", ">", "<"]
unique_sigmas = sorted(np.unique(merged[:, 1]))
sigma_styles = {float(s): (markers[i % len(markers)], sigma_palette[i % len(sigma_palette)]) for i, s in enumerate(unique_sigmas)}


def plot_panel(ax, v0_target, legend_bins):
    sub = collect_points_for_v0(merged, v0_target)
    if sub.size == 0:
        ax.text(0.5, 0.5, f"No data for V0/mu={v0_target}", transform=ax.transAxes, ha="center", va="center")
        return

    for sigma, (marker, color) in sigma_styles.items():
        subset = sub[np.isclose(sub[:, 1], sigma)]
        if subset.size == 0:
            continue

        re_vals = subset[::INTV, 7]
        fd_vals = subset[::INTV, -1]
        cd_vals = 2 * fd_vals / (subset[::INTV, 2] ** 2 - subset[::INTV, 3] ** 2) / subset[::INTV, 6]
        yerr = np.sqrt(
            subset[::INTV, 9] ** 2
            * ((0.5 / subset[::INTV, 6]) ** 2 + (2 * subset[::INTV, 3] / (subset[::INTV, 2] ** 2 - subset[::INTV, 3] ** 2) * 0.001) ** 2)
        )

        mask = (yerr < YERR_CUTOFF) & (cd_vals < 17)
        re_vals, cd_vals, yerr = re_vals[mask], cd_vals[mask], yerr[mask]
        ax.plot(re_vals, cd_vals, marker=marker, linestyle="none", mec=color, mfc=colors.to_rgba(color, alpha=0.3), mew=MEW, markersize=MS)
        for re_value, cd_value, yerr_value in zip(re_vals, cd_vals, yerr):
            ax.errorbar(re_value, cd_value, yerr=yerr_value, linestyle="none", c=color, capsize=1.5, elinewidth=0.5, capthick=0.5, alpha=0.8)

        if sigma not in legend_bins["seen_sigma"]:
            h_sigma = Line2D([0], [0], marker=marker, color="none", mfc=colors.to_rgba(color, alpha=0.3), mec=color, markersize=MS, mew=MEW, linestyle="none")
            legend_bins["sigma_handles"].append(h_sigma)
            legend_bins["sigma_labels"].append(rf"$\sigma/\xi={sigma:.0f}$")
            legend_bins["seen_sigma"].add(sigma)

    re_all = sub[:, 7]
    cd_all = sub[:, 9]
    mask = cd_all < 17
    re_all, cd_all = re_all[mask], cd_all[mask]
    fit_low = fit_for_range(re_all, cd_all, 0.01, 1)
    fit_high = fit_for_range(re_all, cd_all, 2, np.max(re_all) * 1.2)

    re_pos = re_all[re_all > 0]
    if re_pos.size > 0:
        re_grid = np.logspace(np.log10(0.001), np.log10(100), 400)
        if fit_low is not None:
            A, alpha = fit_low
            re_sub = re_grid[(re_grid >= 0.01) & (re_grid <= 2)]
            ax.plot(re_sub, power_model(re_sub, A, alpha), ":", lw=0.7, color="k", alpha=0.9)
        if fit_high is not None:
            A, alpha = fit_high
            re_sub = re_grid[re_grid >= 2]
            ax.plot(re_sub, power_model(re_sub, A, alpha), "--", lw=0.7, color="k", alpha=0.9)

    axins = inset_axes(ax, width="45%", height="60%", loc="upper right", borderpad=1)
    for sigma, (marker, color) in sigma_styles.items():
        subset = sub[np.isclose(sub[:, 1], sigma)]
        if subset.size == 0:
            continue
        re_vals = subset[::INTV, 7]
        cd_vals = subset[::INTV, 9]
        yerr = np.sqrt(
            subset[::INTV, 9] ** 2
            * ((0.5 / subset[::INTV, 6]) ** 2 + (2 * subset[::INTV, 3] / (subset[::INTV, 2] ** 2 - subset[::INTV, 3] ** 2) * 0.001) ** 2)
        )
        mask = (yerr < YERR_CUTOFF) & (cd_vals < 17)
        re_vals, cd_vals = re_vals[mask], cd_vals[mask]
        pos = (re_vals > 0) & (cd_vals > 0)
        axins.plot(re_vals[pos], cd_vals[pos], marker=marker, linestyle="none", mec=color, mfc=colors.to_rgba(color, alpha=0.3), mew=0.7 * RATIO, markersize=MS * RATIO)

    if re_pos.size > 0:
        re_grid = np.logspace(np.log10(0.0001), np.log10(100), 400)
        if fit_low is not None:
            A, alpha = fit_low
            re_sub = re_grid[(re_grid >= 0.01) & (re_grid <= 2)]
            axins.plot(re_sub, power_model(re_sub, A, alpha), ":", lw=0.5, color="k", alpha=0.9)
            x_low = np.sqrt(0.01 * 0.7)
            y_low = power_model(x_low, A, alpha)
            axins.text(x_low + 0.1, y_low * 1.2, rf"$\alpha={alpha:.2f}$", ha="left", va="bottom", fontsize=6)
        if fit_high is not None:
            A, alpha = fit_high
            re_sub = re_grid[re_grid >= 2]
            axins.plot(re_sub, power_model(re_sub, A, alpha), "--", lw=0.5, color="k", alpha=0.9)
            x_high = np.sqrt(0.7 * np.max(re_pos))
            y_high = power_model(x_high, A, alpha)
            axins.text(x_high + 6, y_high * 1.5, rf"$\alpha={alpha:.2f}$", ha="center", va="bottom", fontsize=6)

    axins.set_xlim(0.01, 40)
    axins.set_ylim(0.5, 25)
    axins.set_xscale("log")
    axins.set_yscale("log")
    axins.tick_params(axis="both", which="major", labelsize=6)
    axins.grid(True, which="both", ls=":")
    axins.set_xlabel(r"$\rm Re_s$", labelpad=0)
    axins.set_ylabel(r"$C_\mathrm{D}$", labelpad=0)


fig = plt.figure(figsize=(3.375, 4.2))
gs = GridSpec(2, 1, figure=fig, hspace=0.05, left=0.15, bottom=0.1, right=0.97)
ax_top = fig.add_subplot(gs[0, 0])
ax_bot = fig.add_subplot(gs[1, 0])
legend_bins = make_legend_bins()

plot_panel(ax_top, V0_TARGETS[0], legend_bins)
ax_top.set_ylabel(r"$C_\mathrm{D}$")
ax_top.set_xlim(-1.5, 24)
ax_top.set_ylim(0, 17)
ax_top.grid(False)
ax_top.tick_params(labelbottom=False)
ax_top.text(0.2, 0.9, r"$V_0/\mu=0.7$", transform=ax_top.transAxes, fontsize=8)
ax_top.text(-0.16, 0.94, "(a)", transform=ax_top.transAxes, fontsize=8)

plot_panel(ax_bot, V0_TARGETS[1], legend_bins)
ax_bot.set_xlabel(r"$\rm Re_s$")
ax_bot.set_ylabel(r"$C_\mathrm{D}$")
ax_bot.set_xlim(-1.5, 24)
ax_bot.set_ylim(0, 17)
ax_bot.grid(False)
ax_bot.text(-0.16, 0.94, "(b)", transform=ax_bot.transAxes, fontsize=8)
ax_bot.text(0.2, 0.9, r"$V_0/\mu=0.9$", transform=ax_bot.transAxes, fontsize=8)

if legend_bins["sigma_handles"]:
    fig.legend(legend_bins["sigma_handles"], legend_bins["sigma_labels"], ncol=len(legend_bins["sigma_handles"]), frameon=False, loc="upper left", bbox_to_anchor=(0.1, 1.02), handletextpad=0.3, columnspacing=1.0, fontsize=8)

out = FIGURE_DIR / SAVE_NAME
fig.savefig(out, dpi=600)
plt.close(fig)
print(f"saved {out}")
