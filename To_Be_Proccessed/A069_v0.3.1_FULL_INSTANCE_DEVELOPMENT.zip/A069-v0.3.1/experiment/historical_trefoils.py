"""A069 v0.3.1 historical trefoil diagnostics; NO intrinsic clock inference.

All inputs are historical parametric geometric samples, never qualified Euler or PKLSA states.
G20-G22 are geometric regression gates. G23-G24 MUST remain UNRESOLVED until
separately supplied prequalified 3D Euler core dynamics and intrinsic material phase.
"""
from __future__ import annotations
import hashlib,json,math
from pathlib import Path
import numpy as np
from scipy.integrate import quad

NAMES = ("A_Fourier_2015_p32", "B_Torus_2015_p66")
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "historical_trefoils"

def _sha(b): return hashlib.sha256(b).hexdigest()

def curve(seed,t):
    t=np.asarray(t)
    if seed==NAMES[0]:
        return np.stack((np.cos(t)+1.5*np.cos(2*t),np.sin(t)-1.5*np.sin(2*t),.35*np.sin(3*t)),axis=-1)
    if seed==NAMES[1]:
        return np.stack(((2+np.cos(3*t))*np.cos(2*t),(2+np.cos(3*t))*np.sin(2*t),np.sin(3*t)),axis=-1)
    raise ValueError(f"Unknown historical seed: {seed}")

def derivative(seed,t):
    t=np.asarray(t)
    if seed==NAMES[0]:
        return np.stack((-np.sin(t)-3*np.sin(2*t),np.cos(t)-3*np.cos(2*t),1.05*np.cos(3*t)),axis=-1)
    if seed==NAMES[1]:
        R=2+np.cos(3*t); Rprime=-3*np.sin(3*t)
        return np.stack((Rprime*np.cos(2*t)-2*R*np.sin(2*t),Rprime*np.sin(2*t)+2*R*np.cos(2*t),3*np.cos(3*t)),axis=-1)
    raise ValueError(seed)

def analytic_length(seed):
    return quad(lambda v:float(np.linalg.norm(derivative(seed,v))),0,2*math.pi,epsabs=1e-11,epsrel=1e-11,limit=300)[0]

def crossings(seed, mirror=False):
    """Analytic parameter pairs for XY-projection crossings; signed over/under test."""
    if seed==NAMES[0]:
        d=math.acos(1/3)
        pairs=[(s+d,s-d) for s in (0,2*math.pi/3,4*math.pi/3)]
    elif seed==NAMES[1]:
        pairs=[(t,t+math.pi) for t in (math.pi/6,math.pi/2,5*math.pi/6)]
    else: raise ValueError(seed)
    out=[]
    for t,u in pairs:
        X,Y=curve(seed,t),curve(seed,u)
        dX,dY=derivative(seed,t),derivative(seed,u)
        if mirror:
            X=X*np.array([-1,1,1]);Y=Y*np.array([-1,1,1])
            dX=dX*np.array([-1,1,1]);dY=dY*np.array([-1,1,1])
        err=float(np.linalg.norm((X-Y)[:2])); dz=float(X[2]-Y[2])
        cross=float(np.cross(dX,dY)[2])
        if err>1e-10 or abs(dz)<1e-8 or abs(cross)<1e-8: raise ValueError('invalid transverse crossing')
        signed=int(np.sign(dz*cross))
        out.append({'t':float(t%(2*math.pi)),'u':float(u%(2*math.pi)),
                    'xy_error':err,'vertical_separation':abs(dz),'sign':signed})
    return out

def load_seed(seed,n,data=DATA):
    name=f'{seed}_N{n}_arclength.xyz'
    path=Path(data)/name
    arr=np.loadtxt(path,comments='#',dtype=np.float64)
    if arr.shape!=(n,3) or not np.isfinite(arr).all():raise ValueError('shape or finite coordinates invalid')
    return arr,path

def evaluate(data=DATA):
    data=Path(data)
    manifest_path=data/'original_manifest.json'
    try:
        manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    except (OSError,ValueError) as exc:
        return {'schema':'A069-HISTORICAL-TREFOIL-GEOMETRY-1','status':'FAIL_MANIFEST',
                'G20':'FAIL','G21':'FAIL','G22':'FAIL','G23':'UNRESOLVED','G24':'UNRESOLVED','error':str(exc)}
    results={};g20=True;g21=True;g22=True
    for seed in NAMES:
        expected=manifest['seeds'][seed]
        target=analytic_length(seed)
        info={'analytic_length_dimensionless':target,'historical_page':expected['historical_page'],
              'orientation_preserved':True,'is_physical_state':False,
              'has_finite_core_vorticity':False,'has_material_time_series':False,'meshes':{}}
        for n in (600,1200):
            key=f'{seed}_N{n}_arclength.xyz'
            try:
                arr,p=load_seed(seed,n,data)
                actual=_sha(p.read_bytes()); pinned=expected['files'][key]['sha256']; verified=actual==pinned
                segment=np.linalg.norm(np.roll(arr,-1,axis=0)-arr,axis=1)
                path_length=float(np.sum(segment)); mean=float(np.mean(segment))
                cv=float(np.std(segment)/mean)
                closure=float(np.linalg.norm(arr[-1]-arr[0]));
                agreement=(abs(path_length-target)/target < (7e-5 if n==600 else 2e-5)
                           and cv<1e-4 and abs(closure/mean-1)<2e-4)
                nonduplicate=bool(np.linalg.norm(arr[-1]-arr[0])>0.5*mean)
                info['meshes'][str(n)]={'sha256':actual,'expected_sha256':pinned,'sha_pass':verified,
                  'polygon_arclength_dimensionless':path_length,'relative_length_error':abs(path_length-target)/target,
                  'edge_coefficient_of_variation':cv,'periodic_closure_edge_ratio':closure/mean,
                  'no_duplicated_terminal_point':nonduplicate,'sampling_pass':agreement and nonduplicate}
                g20 &= verified and nonduplicate
                g21 &= agreement and nonduplicate
            except (OSError,ValueError,KeyError) as exc:
                info['meshes'][str(n)]={'error':str(exc),'sha_pass':False,'sampling_pass':False}
                g20=False;g21=False
        try:
            c=crossings(seed); mirror=crossings(seed,mirror=True)
            writhe=sum(v['sign'] for v in c)
            mirror_writhe=sum(v['sign'] for v in mirror)
            reference=3 if seed==NAMES[0] else -3
            parity=(len(c)==3 and writhe==reference and mirror_writhe==-reference
                    and max(x['xy_error'] for x in c)<1e-10)
            info['crossings']={'n':len(c),'crossing_signs':[x['sign'] for x in c],
               'projection_writhe':writhe,'reflected_projection_writhe':mirror_writhe,
               'max_projection_intersection_error':max(x['xy_error'] for x in c),
               'min_vertical_crossing_clearance_dimensionless':min(x['vertical_separation'] for x in c),
               'sign_mirror_pass':parity}
            g22 &= parity
        except ValueError as exc:
            info['crossings']={'error':str(exc),'sign_mirror_pass':False};g22=False
        results[seed]=info
    gate={'G20':'PASS' if g20 else 'FAIL','G21':'PASS' if g21 else 'FAIL',
          'G22':'PASS' if g22 else 'FAIL','G23':'UNRESOLVED','G24':'UNRESOLVED'}
    return {'schema':'A069-HISTORICAL-TREFOIL-GEOMETRY-1','status':'PASS_STATIC_DIAGNOSTIC_ONLY' if all((g20,g21,g22)) else 'FAIL_STATIC_DIAGNOSTIC',
      'provenance':'2015-notebook-pages-32-and-66-analytic-with-scanned-originals',
      'basis':'dimensionless XYZ sampled in arc length; no physical core, circulation, density or timestep',
      'gates':gate,'physical_pklsa_dynamics_ready':False,'intrinsic_phase_frequency_measured':False,
      'operational_clock_predicted':False,'independent_physical_provider_count':0,
      'mirroring_note':'A vs B are not geometric reflections of one another; each has its own exact reflected control',
      'results':results}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,default=DATA);ap.add_argument('--out',type=Path)
    args=ap.parse_args();d=evaluate(args.data);s=json.dumps(d,indent=2,sort_keys=True)+'\n'
    if args.out: args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(s,encoding='utf8')
    print(s);raise SystemExit(0 if d['status']=='PASS_STATIC_DIAGNOSTIC_ONLY' else 1)
