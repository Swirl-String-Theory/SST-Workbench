#!/usr/bin/env python3
"""
derive_pressure_mode_cutoff_surface_spectrum.py

Surface-spectrum derivation/audit for the pressure-mode cutoff N_p=4.

For a perturbed spherical boundary

    r(Omega) = R [1 + epsilon f(Omega)],

the area functional at fixed volume has second variation

    delta^2 A_fixed-volume = (R^2/2) int_{S^2} (|grad_S f|^2 - 2 f^2) dOmega.

For a spherical harmonic f = Y_lm,

    int |grad_S Y_lm|^2 dOmega = l(l+1) int |Y_lm|^2 dOmega,

so the shape stiffness is

    k_l = l(l+1) - 2 = (l-1)(l+2).

Therefore:
  * l=0 is the volume/compression mode and is retained as a scalar pressure
    degree of freedom.
  * l=1 has k_1=0: the three translation / centre-displacement modes.
  * l>=2 has k_l>0: quadrupolar and higher shape modes, integrated out at
    zeroth order.

The retained pressure manifold is H_0 plus H_1, giving N_p = 1+3 = 4.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Dict, List


def write_csv(path: Path, rows: List[Dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def surface_mode_table(lmax: int, area_stiffness: float = 1.0, compression_stiffness: float = 1.0) -> List[Dict]:
    rows = []
    for ell in range(lmax + 1):
        degeneracy = 2 * ell + 1
        if ell == 0:
            raw_shape_stiffness = ""
            effective_stiffness = compression_stiffness
            classification = "retained_volume_pressure_mode"
            retained = True
            reason = "l=0 is the scalar volume/compression pressure constraint."
        elif ell == 1:
            raw_shape_stiffness = 0.0
            effective_stiffness = 0.0
            classification = "retained_translation_center_displacement"
            retained = True
            reason = "l=1 has zero fixed-volume surface stiffness: rigid translation/centre displacement."
        else:
            raw_shape_stiffness = ell * (ell + 1) - 2
            effective_stiffness = area_stiffness * raw_shape_stiffness
            classification = "integrated_out_shape_mode"
            retained = False
            reason = "l>=2 has positive fixed-volume shape stiffness and is not a zeroth-order pressure sector."
        rows.append({
            "ell": ell,
            "degeneracy": degeneracy,
            "laplacian_eigenvalue_l_lplus1": ell * (ell + 1),
            "fixed_volume_shape_stiffness_l_lplus1_minus_2": raw_shape_stiffness,
            "effective_stiffness": effective_stiffness,
            "retained_in_minimal_pressure_manifold": retained,
            "classification": classification,
            "reason": reason,
        })
    return rows


def compute_summary(rows: List[Dict]) -> Dict:
    retained = [r["ell"] for r in rows if r["retained_in_minimal_pressure_manifold"]]
    retained_degeneracy = sum(r["degeneracy"] for r in rows if r["retained_in_minimal_pressure_manifold"])
    shape_positive = True
    for r in rows:
        if r["ell"] >= 2:
            val = r["fixed_volume_shape_stiffness_l_lplus1_minus_2"]
            if not (isinstance(val, (int, float)) and val > 0):
                shape_positive = False
    pass_gate = retained == [0, 1] and retained_degeneracy == 4 and shape_positive
    return {
        "retained_ell_modes": str(retained),
        "N_p_retained": retained_degeneracy,
        "all_l_ge_2_positive_shape_stiffness": shape_positive,
        "pass_Np4_surface_spectrum_gate": pass_gate,
        "status": "DERIVED_IN_SPHERICAL_SURFACE_VARIATION" if pass_gate else "FAILED_OR_INCOMPLETE",
    }


def optional_delay_audit(rows: List[Dict], damping_base: float, damping_shape: float, retention_margin: float) -> List[Dict]:
    out = []
    for r in rows:
        ell = r["ell"]
        if ell == 0:
            gamma = damping_base
        elif ell == 1:
            gamma = 0.0
        else:
            gamma = damping_base + damping_shape * float(r["fixed_volume_shape_stiffness_l_lplus1_minus_2"])
        retained_dynamically = ell <= 1 and gamma <= retention_margin
        suppressed_dynamically = ell >= 2 and gamma > retention_margin
        out.append({
            "ell": ell,
            "geometric_classification": r["classification"],
            "damping_gamma": gamma,
            "retained_dynamically": retained_dynamically,
            "suppressed_dynamically": suppressed_dynamically,
            "status": "retained" if retained_dynamically else ("suppressed" if suppressed_dynamically else "ambiguous"),
        })
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--lmax", type=int, default=8)
    ap.add_argument("--area-stiffness", type=float, default=1.0)
    ap.add_argument("--compression-stiffness", type=float, default=1.0)
    ap.add_argument("--include-delay-audit", action="store_true")
    ap.add_argument("--damping-base", type=float, default=0.05)
    ap.add_argument("--damping-shape", type=float, default=0.20)
    ap.add_argument("--retention-margin", type=float, default=0.10)
    ap.add_argument("--outdir", default="outputs_surface_mode_cutoff")
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    rows = surface_mode_table(args.lmax, args.area_stiffness, args.compression_stiffness)
    summary = compute_summary(rows)

    write_csv(outdir / "surface_mode_cutoff_table.csv", rows)
    write_csv(outdir / "surface_mode_cutoff_summary.csv", [summary])

    if args.include_delay_audit:
        delay_rows = optional_delay_audit(rows, args.damping_base, args.damping_shape, args.retention_margin)
        write_csv(outdir / "surface_mode_cutoff_delay_audit.csv", delay_rows)

    derivation_rows = [
        {
            "step": "area_second_variation_fixed_volume",
            "formula": "delta2 A = (R^2/2) int_S2 (|grad_S f|^2 - 2 f^2) dOmega",
            "status": "geometric_second_variation",
        },
        {
            "step": "spherical_harmonic_identity",
            "formula": "int |grad_S Y_lm|^2 dOmega = l(l+1) int |Y_lm|^2 dOmega",
            "status": "standard_S2_spectrum",
        },
        {
            "step": "shape_stiffness",
            "formula": "k_l = l(l+1)-2 = (l-1)(l+2)",
            "status": "derived",
        },
        {
            "step": "retained_modes",
            "formula": "l=0 volume/compression; l=1 translation zero modes",
            "status": "derived_in_spherical_surface_reduction",
        },
        {
            "step": "mode_count",
            "formula": "N_p = dim H_0 + dim H_1 = 1 + 3 = 4",
            "status": "derived_in_spherical_surface_reduction",
        },
    ]
    write_csv(outdir / "surface_mode_cutoff_derivation_steps.csv", derivation_rows)

    report = []
    report.append("# Surface-spectrum derivation of N_p=4\n")
    report.append("## Result\n")
    report.append(f"Status: `{summary['status']}`\n")
    report.append(f"Retained modes: `{summary['retained_ell_modes']}`\n")
    report.append(f"N_p retained: `{summary['N_p_retained']}`\n")
    report.append("\nFor a spherical boundary perturbation\n")
    report.append(r"\[ r(\Omega)=R[1+\epsilon f(\Omega)]. \]" + "\n")
    report.append("The fixed-volume second variation of area is\n")
    report.append(r"\[ \delta^2 A = \frac{R^2}{2}\int_{S^2}(|\nabla_S f|^2-2f^2)\,d\Omega. \]" + "\n")
    report.append("For \(f=Y_{\\ell m}\), the stiffness is\n")
    report.append(r"\[ k_\ell=\ell(\ell+1)-2=(\ell-1)(\ell+2). \]" + "\n")
    report.append("Thus \(\\ell=0\) is the volume/compression pressure mode, \(\\ell=1\) is the translation/centre-displacement sector, and \(\\ell\\ge2\) are positive-stiffness shape modes.\n")
    report.append(r"\[ N_p=\dim H_0+\dim H_1=1+3=4. \]" + "\n")
    report.append("\n## Epistemic status\n")
    report.append("This closes the N_p=4 gate inside the spherical finite-cell surface variation. It does not claim that nonspherical finite-core corrections are negligible; that remains a robustness test.\n")
    (outdir / "surface_mode_cutoff_report.md").write_text("\n".join(report), encoding="utf-8")

    tex = r"""\section{Surface-spectrum derivation of the pressure cutoff \(N_p=4\)}
\label{app:surface-spectrum-Np4}

Let the spherical cell boundary be perturbed as
\[
  r(\Omega)=R[1+\epsilon f(\Omega)].
\]
At fixed volume, the second variation of the surface area is
\[
  \delta^2 A
  =
  \frac{R^2}{2}
  \int_{S^2}
  \left(
  |\nabla_{S^2}f|^2-2f^2
  \right)d\Omega.
\]
Expanding in spherical harmonics, \(f=Y_{\ell m}\), and using
\[
  \int_{S^2}|\nabla_{S^2}Y_{\ell m}|^2d\Omega
  =
  \ell(\ell+1)\int_{S^2}|Y_{\ell m}|^2d\Omega,
\]
gives the fixed-volume shape stiffness
\[
  k_\ell
  =
  \ell(\ell+1)-2
  =
  (\ell-1)(\ell+2).
\]
Thus \(k_1=0\): the \(\ell=1\) sector consists of the three rigid
translation/centre-displacement modes.  For \(\ell\ge2\), \(k_\ell>0\), so
these modes are positive-stiffness quadrupolar and higher shape modes.  The
\(\ell=0\) mode is not a fixed-volume shape mode; it is the scalar
volume/compression pressure degree of freedom and is retained separately.

The minimal pressure manifold is therefore
\[
  \mathcal P_{\rm min}
  =
  \mathcal H_0\oplus\mathcal H_1,
\]
and hence
\[
  N_p
  =
  \dim\mathcal H_0+\dim\mathcal H_1
  =
  1+3
  =
  4.
\]
This derives \(N_p=4\) inside the spherical finite-cell surface variation.  The
remaining robustness task is to verify that nonspherical finite-core
corrections do not promote \(\ell\ge2\) shape modes into the leading pressure
manifold.
"""
    (outdir / "surface_mode_cutoff_appendix_snippet.tex").write_text(tex, encoding="utf-8")

    try:
        import matplotlib.pyplot as plt
        ell = [r["ell"] for r in rows]
        stiff = []
        for r in rows:
            val = r["fixed_volume_shape_stiffness_l_lplus1_minus_2"]
            stiff.append(0 if val == "" else val)
        fig, ax = plt.subplots(figsize=(7.5, 4.8))
        ax.plot(ell, stiff, marker="o")
        ax.axhline(0.0, linestyle="--")
        ax.set_xlabel(r"$\ell$")
        ax.set_ylabel(r"$k_\ell=\ell(\ell+1)-2$")
        ax.set_title("Fixed-volume surface shape stiffness")
        fig.tight_layout()
        fig.savefig(outdir / "surface_mode_stiffness.png", dpi=180)
        plt.close(fig)
    except Exception:
        pass

    print("Surface-spectrum derivation of N_p=4")
    print("=" * 72)
    print(f"status              : {summary['status']}")
    print(f"retained ell modes  : {summary['retained_ell_modes']}")
    print(f"N_p retained        : {summary['N_p_retained']}")
    print(f"l>=2 positive       : {summary['all_l_ge_2_positive_shape_stiffness']}")
    print(f"pass gate           : {summary['pass_Np4_surface_spectrum_gate']}")
    print(f"\nWrote {outdir}")


if __name__ == "__main__":
    main()
