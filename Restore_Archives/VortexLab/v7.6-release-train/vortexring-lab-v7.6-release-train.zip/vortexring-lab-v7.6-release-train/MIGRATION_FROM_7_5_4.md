# Migratie van de conflicterende v7.5.4-bestanden

| Oude bestandsnaam | Nieuwe ondubbelzinnige versie |
|---|---|
| `vortexring-lab-v7_5_4_dual-sidebar-ui_zflow-header-paired-docks (1).html` | `v7.6.0` |
| `vortexring-lab-v7_5_4_dual-sidebar-ui_zflow-header-paired-docks_ideal-and-fseries.html` | `v7.6.1` |
| `vortexring-lab-v7_5_4_dual-sidebar-ui_zflow-header-paired-docks_separate-fseries-dropdown.html` | `v7.6.2` |
| `vortexring-lab-v7_5_4_zflow_separate-fseries_sst-overlays.html` | `v7.6.3` |
| `vortexring-lab-v7_5_4_zflow_separate-fseries_flat-diagnostics.html` | `v7.6.4` |
| `vortexring-lab-v7_5_4_zflow_separate-fseries_speculative-swirl-clock.html` | `v7.6.5` |
| `vortexring-lab-v7_5_4_zflow_separate-fseries_speculative-swirl-clock-distance-control.html` | `v7.6.6` |
| `vortexring-lab-v7_5_4_zflow_separate-fseries_speculative-swirl-clock-preset-logging.html` | `v7.6.7` |

Gebruik voor nieuw werk uitsluitend `latest/vortexring-lab-v7.6.7.html` of de expliciete map van een oudere release.
