from __future__ import annotations
from pathlib import Path
import json
from sst_falsifier_core.blind import verify_reveal
from sst_falsifier_core.util import write_json

def reveal(blind_out,private_json,commitment="REVEAL_COMMITMENT.sha256"):
    ok,expected,actual=verify_reveal(private_json,commitment)
    if not ok: raise RuntimeError(f"reveal commitment mismatch expected={expected} actual={actual}")
    out=Path(blind_out); private=json.loads(Path(private_json).read_text(encoding="utf-8"))
    discovery=json.loads((out/"G3_rational_discovery.json").read_text(encoding="utf-8")) if (out/"G3_rational_discovery.json").exists() else []
    rows=[]
    for h in private.get("historical_hypotheses",[]):
        a,b=h["pair"]
        # Pair is located by chain index after seal; no pair was privileged in discovery.
        from .rational_lane import TWIST_CHAIN
        try: idx=TWIST_CHAIN.index(a); assert TWIST_CHAIN[idx+1]==b
        except Exception: idx=None
        matches=[r for r in discovery if r.get("chain_index")==idx] if idx is not None else []
        rows.append({"hypothesis_id":h["id"],"pair":h["pair"],"private_targets":h.get("target_rationals",[]),"preexisting_blind_tests":matches})
    summary_path=out/"SCIENTIFIC_SUMMARY.json"
    summary=json.loads(summary_path.read_text(encoding="utf-8")) if summary_path.exists() else {}
    eligible=summary.get("combined_bridge")=="ELIGIBLE_FOR_PRIVATE_REVEAL"
    rep={"schema":"SST-KSA-REVEAL-1","commitment_expected":expected,"commitment_actual":actual,"combined_bridge_pre_reveal_eligible":eligible,"historical_comparison":rows,
         "guard":"A reveal match is evidential only if the corresponding blind multiplicity gate passed. Reveal cannot repair failed/unresolved G3, G5X, or G6."}
    rev=out/"revealed";rev.mkdir(parents=True,exist_ok=True);write_json(rev/"REVEAL_REPORT.json",rep);return rep
