@echo off
setlocal
cd /d "%~dp0"
set "OUT=%~1"
if "%OUT%"=="" set "OUT=outputs\extended"
.venv\Scripts\python.exe run_reveal.py --out "%OUT%"
