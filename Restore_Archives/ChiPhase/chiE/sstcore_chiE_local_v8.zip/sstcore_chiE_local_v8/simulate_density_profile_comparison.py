#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_core_model_ladder import (
    TARGET_CHI_E,
    evaluate_finite_core_balance,
    rows_to_dicts,
    write_csv,
    write_json,
)

SCRIPT_DIR = Path(__file__).resolve().parent
EXPORT_DIR = SCRIPT_DIR / "exports"
EXPORT_DIR.mkdir(exist_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare constant-density and smooth finite-core profiles.")
    parser.add_argument("--lambda", dest="lambda_", type=float, default=1.0)
    parser.add_argument("--epsilon", type=float, default=1.0)
    parser.add_argument("--shape-min", type=float, default=0.5)
    parser.add_argument("--shape-max", type=float, default=6.0)
    parser.add_argument("--shape-count", type=int, default=24)
    parser.add_argument("--n-theta", type=int, default=8192)
    parser.add_argument("--n-profile", type=int, default=4096)
    args = parser.parse_args()

    t0 = time.time()
    rows = []
    # Fixed profiles
    for profile in ["rankine", "polynomial"]:
        rows.append(evaluate_finite_core_balance(args.lambda_, args.epsilon, profile, 1.0, True, args.n_theta, args.n_profile))
    # Shape-swept smooth profiles
    for profile in ["lamb_oseen", "nlse_tanh"]:
        for shape in np.linspace(args.shape_min, args.shape_max, args.shape_count):
            rows.append(evaluate_finite_core_balance(args.lambda_, args.epsilon, profile, float(shape), True, args.n_theta, args.n_profile))

    write_csv(EXPORT_DIR / "density_profile_comparison.csv", rows)
    best = min(rows, key=lambda r: abs(r.chi_E - TARGET_CHI_E))
    summary = {
        "run": "density_profile_comparison",
        "status": "RESEARCH-TRACK / PROFILE COMPARISON / NOT CANONIZED",
        "warning": "A profile parameter that is tuned to hit 2*pi is calibrated. Look for robust profile families or variationally derived shape values.",
        "lambda_": args.lambda_,
        "epsilon": args.epsilon,
        "target_chi_E": TARGET_CHI_E,
        "best_profile_to_2pi": rows_to_dicts([best])[0],
        "elapsed_s": time.time() - t0,
    }
    write_json(EXPORT_DIR / "density_profile_comparison_summary.json", summary)

    plt.figure(figsize=(10, 6))
    for profile in sorted(set(r.profile for r in rows)):
        subset = [r for r in rows if r.profile == profile]
        xs = [r.shape for r in subset]
        ys = [r.chi_E for r in subset]
        plt.plot(xs, ys, marker="o", linewidth=1, label=profile)
    plt.axhline(TARGET_CHI_E, linestyle="--", label=r"target $2\pi$")
    plt.xlabel("profile shape parameter")
    plt.ylabel(r"$\chi_E$")
    plt.title(r"Finite-core density profile comparison at fixed $\lambda,\epsilon$")
    plt.grid(True, alpha=0.35)
    plt.legend()
    plt.tight_layout()
    plt.savefig(EXPORT_DIR / "density_profile_comparison.png", dpi=180)
    plt.close()

    text_path = EXPORT_DIR / "density_profile_comparison_run_results_summary.txt"
    with text_path.open("w", encoding="utf-8") as f:
        f.write("SST density-profile comparison diagnostic\n")
        f.write("=========================================\n")
        f.write(f"lambda                          = {args.lambda_:.16e}\n")
        f.write(f"epsilon                         = {args.epsilon:.16e}\n")
        f.write(f"target 2*pi                     = {TARGET_CHI_E:.16e}\n\n")
        f.write("Best row to target:\n")
        f.write(f"profile                         = {best.profile}\n")
        f.write(f"shape                           = {best.shape:.16e}\n")
        f.write(f"chi_E                           = {best.chi_E:.16e}\n")
        f.write(f"residual                        = {best.target_residual:.16e}\n\n")
        f.write("Interpretation:\n")
        f.write("Rankine is the fixed constant-density reference. Lamb-Oseen and tanh profiles are smooth-core diagnostics.\n")
    print(f"[*] Wrote {text_path}")
    print(f"best profile={best.profile}, shape={best.shape:.6g}, chi_E={best.chi_E:.12g}")


if __name__ == "__main__":
    main()
