# A049 v0.2.0 hypotheses

## H0 — fluid-like relaxation / no universal transverse pole
The positive instantaneous Born curvature found in v0.1.0 does not persist as a conservative low-frequency shear mode under nonlinear Euler evolution. Long-wave transverse probes decorrelate, scatter, grow/decay, or acquire direction/helicity-dependent phase drift.

## H1 — emergent conservative transverse elasticity
The isotropic Euler-vortex microstructure supports a coherent transverse branch satisfying, over the preregistered probes,

\[
\omega(k)=c_T k+o(k),\qquad c_T>0,
\]

with weak damping, direction-independent speed and degenerate \(h=\pm1\) helicities.

## Master-Factor Wave Closure
The preregistered blind closure target is

\[
\frac{c_T}{v_*}=\frac12.
\]

It is evaluated only if the dynamic wave branch itself qualifies. No noisy phase-fit speed may be promoted to a physical \(c_T\).
