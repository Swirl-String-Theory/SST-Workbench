#!/usr/bin/env python3
"""
sst_ffs_05_helicity_batch.py

Batch framed-helicity / self-linking test for selected ideal.txt IDs.

Computes the SST-native diagnostic:

    H / Gamma^2 = SL = Wr + Tw

Numerically:
  - Wr is estimated by midpoint-rule Gauss writhe integral.
  - A closed parallel-transport ribbon frame is built.
  - Lk0 is the Gauss linking number of the centreline and its offset ribbon.
  - Tw0 = Lk0 - Wr.
  - For torus T(2,q) controls, an optional target SL=2q+1 is tested.

Important limitations:
  - This script analyses single-component AB blocks.
  - Multi-component links are inventoried but skipped for now.
  - For links, helicity needs the multi-component formula with mutual linking:
        H/Gamma^2 = sum_i SL_i + 2 sum_{i<j} Lk_ij
    when all circulations are equal. That is a separate extension.

Dependencies: numpy only.
"""

from __future__ import annotations

import argparse
import csv
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np

TAU = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi


@dataclass
class IdealEntry:
    ideal_id: str
    label: str
    family: str
    amphichiral: bool
    conway: str
    L: str
    D: str
    component_count: int
    is_multicomponent: bool
    coeffs: Optional[np.ndarray]
    indices: Optional[np.ndarray]
    notes: str = ""


def parse_attrs(attr_text: str) -> dict[str, str]:
    return dict(re.findall(r'([A-Za-z_][A-Za-z0-9_]*)="([^"]*)"', attr_text))


def parse_vec3(s: str):
    vals = [float(x.strip()) for x in s.split(",")]
    if len(vals) != 3:
        raise ValueError(f"bad vec3: {s!r}")
    return vals


def read_config(path: Path):
    rows = []
    with path.open("r", newline="", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f):
            rows.append(row)
    return rows


def parse_ideal_blocks(ideal_path: Path):
    text = ideal_path.read_text(encoding="utf-8", errors="replace")
    block_re = re.compile(r'<AB\s+([^>]*)>(.*?)</AB>', re.S)
    coeff_re = re.compile(
        r'<Coeff\s+[^>]*I="\s*([0-9]+)"\s+A="([^"]+)"\s+B="([^"]+)"\s*/?>',
        re.S,
    )
    blocks = {}
    for m in block_re.finditer(text):
        attrs = parse_attrs(m.group(1))
        ideal_id = attrs.get("Id")
        if not ideal_id:
            continue
        body = m.group(2)
        is_multi = "<Component" in body
        component_count = len(re.findall(r'<Component\b', body))
        coeff_rows = []
        indices = []
        if not is_multi:
            for cm in coeff_re.finditer(body):
                i = int(cm.group(1))
                a = parse_vec3(cm.group(2))
                b = parse_vec3(cm.group(3))
                coeff_rows.append([a[0], b[0], a[1], b[1], a[2], b[2]])
                indices.append(float(i))
        coeffs = np.asarray(coeff_rows, dtype=float) if coeff_rows else None
        idx = np.asarray(indices, dtype=float) if indices else None
        blocks[ideal_id] = {
            "attrs": attrs,
            "body": body,
            "is_multicomponent": is_multi,
            "component_count": component_count,
            "coeffs": coeffs,
            "indices": idx,
        }
    return blocks


def target_sl_from_label(label: str, ideal_id: str) -> Optional[int]:
    # Torus T(2,q): 3_1,5_1,7_1,9_1,11_1 -> SL_target = 2q+1.
    torus = {
        "3_1": 3,
        "5_1": 5,
        "7_1": 7,
        "9_1": 9,
        "11_1": 11,
        "3:1:1": 3,
        "5:1:1": 5,
        "7:1:1": 7,
        "9:1:1": 9,
        "K11a367": 11,
    }
    q = torus.get(label) or torus.get(ideal_id)
    return None if q is None else 2 * q + 1


def eval_fourier(coeffs: np.ndarray, idx: np.ndarray, n: int) -> np.ndarray:
    t = np.linspace(0.0, TAU, n, endpoint=False)
    X = np.zeros((n, 3), dtype=float)
    for row, j in zip(coeffs, idx):
        c = np.cos(j * t)
        s = np.sin(j * t)
        X[:, 0] += row[0] * c + row[1] * s
        X[:, 1] += row[2] * c + row[3] * s
        X[:, 2] += row[4] * c + row[5] * s
    return X


def normalize_curve(curve: np.ndarray) -> np.ndarray:
    c = np.asarray(curve, dtype=float).copy()
    c -= np.mean(c, axis=0, keepdims=True)
    rms = math.sqrt(float(np.mean(np.sum(c*c, axis=1))))
    if rms > 0.0:
        c /= rms
    return c


def polygon_segments(curve: np.ndarray):
    p0 = curve
    p1 = np.roll(curve, -1, axis=0)
    d = p1 - p0
    mid = 0.5 * (p0 + p1)
    return mid, d


def gauss_linking_midpoint(curve_a: np.ndarray, curve_b: np.ndarray, chunk: int = 256, same_curve: bool = False) -> float:
    ma, da = polygon_segments(curve_a)
    mb, db = polygon_segments(curve_b)
    n = ma.shape[0]
    total = 0.0
    eps2 = 1e-30
    for i0 in range(0, n, chunk):
        i1 = min(i0 + chunk, n)
        M = ma[i0:i1, None, :] - mb[None, :, :]
        C = np.cross(da[i0:i1, None, :], db[None, :, :])
        r2 = np.einsum("ijk,ijk->ij", M, M)
        denom = np.power(np.maximum(r2, eps2), 1.5)
        num = np.einsum("ijk,ijk->ij", M, C)
        term = num / denom
        if same_curve and curve_a is curve_b:
            rows = np.arange(i0, i1)
            term[np.arange(i1 - i0), rows] = 0.0
        total += float(np.sum(term))
    return total / FOUR_PI


def rotate_about_axis(v: np.ndarray, axis: np.ndarray, angle: float) -> np.ndarray:
    axis = np.asarray(axis, dtype=float)
    an = float(np.linalg.norm(axis))
    if an < 1e-15 or abs(angle) < 1e-15:
        return v.copy()
    k = axis / an
    return v * math.cos(angle) + np.cross(k, v) * math.sin(angle) + k * float(np.dot(k, v)) * (1.0 - math.cos(angle))


def point_tangents(curve: np.ndarray) -> np.ndarray:
    t = np.roll(curve, -1, axis=0) - np.roll(curve, 1, axis=0)
    norm = np.linalg.norm(t, axis=1)
    norm[norm < 1e-15] = 1.0
    return t / norm[:, None]


def signed_angle_in_plane(a: np.ndarray, b: np.ndarray, normal: np.ndarray) -> float:
    a = a / max(np.linalg.norm(a), 1e-15)
    b = b / max(np.linalg.norm(b), 1e-15)
    n = normal / max(np.linalg.norm(normal), 1e-15)
    return math.atan2(float(np.dot(n, np.cross(a, b))), float(np.dot(a, b)))


def closed_parallel_frame(curve: np.ndarray):
    T = point_tangents(curve)
    n = len(curve)
    U = np.zeros_like(curve)
    axes = np.eye(3)
    dots = np.abs(axes @ T[0])
    u0 = axes[int(np.argmin(dots))]
    u0 = u0 - np.dot(u0, T[0]) * T[0]
    U[0] = u0 / max(np.linalg.norm(u0), 1e-15)

    for i in range(1, n):
        prev = T[i - 1]
        cur = T[i]
        axis = np.cross(prev, cur)
        angle = math.atan2(float(np.linalg.norm(axis)), float(np.dot(prev, cur)))
        ui = rotate_about_axis(U[i - 1], axis, angle)
        ui = ui - np.dot(ui, cur) * cur
        U[i] = ui / max(np.linalg.norm(ui), 1e-15)

    axis = np.cross(T[-1], T[0])
    angle = math.atan2(float(np.linalg.norm(axis)), float(np.dot(T[-1], T[0])))
    u_end = rotate_about_axis(U[-1], axis, angle)
    u_end = u_end - np.dot(u_end, T[0]) * T[0]
    u_end = u_end / max(np.linalg.norm(u_end), 1e-15)
    hol = signed_angle_in_plane(u_end, U[0], T[0])

    for i in range(n):
        frac = i / float(n)
        U[i] = rotate_about_axis(U[i], T[i], frac * hol)
        U[i] = U[i] - np.dot(U[i], T[i]) * T[i]
        U[i] = U[i] / max(np.linalg.norm(U[i]), 1e-15)
    return T, U


def add_integer_twist(U: np.ndarray, T: np.ndarray, k: int) -> np.ndarray:
    n = len(U)
    out = np.zeros_like(U)
    for i in range(n):
        phi = TAU * k * (i / float(n))
        out[i] = rotate_about_axis(U[i], T[i], phi)
        out[i] = out[i] - np.dot(out[i], T[i]) * T[i]
        out[i] = out[i] / max(np.linalg.norm(out[i]), 1e-15)
    return out


def curve_diagnostics(curve: np.ndarray):
    p1 = np.roll(curve, -1, axis=0)
    seg = np.linalg.norm(p1 - curve, axis=1)
    bbox = np.max(curve, axis=0) - np.min(curve, axis=0)
    return {
        "seg_min": float(np.min(seg)),
        "seg_mean": float(np.mean(seg)),
        "seg_max": float(np.max(seg)),
        "bbox_diag": float(np.linalg.norm(bbox)),
    }


def analyze_curve(X: np.ndarray, entry: IdealEntry, samples: int, eps_frac: float, chunk: int, no_target_link: bool):
    c = normalize_curve(X)
    diag = curve_diagnostics(c)
    eps = eps_frac * diag["bbox_diag"]
    Wr = gauss_linking_midpoint(c, c, chunk=chunk, same_curve=True)
    T, U0 = closed_parallel_frame(c)
    C0 = c + eps * U0
    Lk0 = gauss_linking_midpoint(c, C0, chunk=chunk, same_curve=False)
    Lk0_round = int(round(Lk0))
    Tw0 = Lk0 - Wr
    Tw0_round_est = Lk0_round - Wr

    target_sl = target_sl_from_label(entry.label, entry.ideal_id)
    extra_k = ""
    Lk_target = ""
    Lk_target_round = ""
    Lk_target_error = ""
    Tw_target = ""
    status = "NO_TARGET"
    if target_sl is not None:
        extra_k_int = int(target_sl - Lk0_round)
        extra_k = extra_k_int
        Tw_target = float(target_sl - Wr)
        if no_target_link:
            status = "TARGET_NOT_MEASURED"
        else:
            Ut = add_integer_twist(U0, T, extra_k_int)
            Ct = c + eps * Ut
            lk = gauss_linking_midpoint(c, Ct, chunk=chunk, same_curve=False)
            Lk_target = float(lk)
            Lk_target_round = int(round(lk))
            Lk_target_error = float(lk - target_sl)
            status = "PASS" if abs(lk - target_sl) < 0.25 else "CHECK"

    chirality_note = "AMPHICHIRAL_CONTROL" if entry.amphichiral else ""
    return {
        "ideal_id": entry.ideal_id,
        "label": entry.label,
        "family": entry.family,
        "amphichiral": "yes" if entry.amphichiral else "no",
        "conway": entry.conway,
        "L": entry.L,
        "D": entry.D,
        "component_count": entry.component_count,
        "samples": samples,
        "Wr": Wr,
        "abs_Wr": abs(Wr),
        "Lk0": Lk0,
        "Lk0_round": Lk0_round,
        "Tw0_Lk0_minus_Wr": Tw0,
        "Tw0_round_est": Tw0_round_est,
        "target_SL": target_sl if target_sl is not None else "",
        "extra_integer_twists_to_target": extra_k,
        "Tw_target_targetSL_minus_Wr": Tw_target,
        "Lk_target": Lk_target,
        "Lk_target_round": Lk_target_round,
        "Lk_target_error": Lk_target_error,
        "ribbon_eps": eps,
        "seg_min": diag["seg_min"],
        "seg_mean": diag["seg_mean"],
        "seg_max": diag["seg_max"],
        "bbox_diag": diag["bbox_diag"],
        "status": status,
        "notes": ";".join([entry.notes, chirality_note]).strip(";"),
    }


def write_csv(path: Path, rows: list[dict]):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def write_summary(path: Path, result_rows: list[dict], inventory_rows: list[dict]):
    lines = []
    lines.append("# SST framed-helicity batch summary")
    lines.append("")
    lines.append("Diagnostic:")
    lines.append("")
    lines.append(r"\[")
    lines.append(r"\frac{H}{\Gamma^2}=SL=Wr+Tw.")
    lines.append(r"\]")
    lines.append("")
    lines.append(f"Inventory rows: {len(inventory_rows)}")
    lines.append(f"Analysed single-component rows: {len(result_rows)}")
    skipped = [r for r in inventory_rows if r.get("status") != "single_component_ready"]
    if skipped:
        lines.append(f"Skipped/missing rows: {len(skipped)}")
    lines.append("")
    if result_rows:
        ranked = sorted(result_rows, key=lambda r: float(r["abs_Wr"]), reverse=True)
        lines.append("## Top by |Wr|")
        lines.append("")
        lines.append("| knot | id | family | amphichiral | Wr | Lk0 | Tw0 | target SL | status |")
        lines.append("|---|---|---|---|---:|---:|---:|---:|---|")
        for r in ranked[:20]:
            lines.append(
                f"| {r['label']} | `{r['ideal_id']}` | {r['family']} | {r['amphichiral']} | "
                f"{float(r['Wr']):.6g} | {float(r['Lk0']):.6g} | {float(r['Tw0_Lk0_minus_Wr']):.6g} | "
                f"{r['target_SL']} | {r['status']} |"
            )
        lines.append("")
        amph = [r for r in result_rows if r["amphichiral"] == "yes"]
        if amph:
            lines.append("## Amphichiral controls")
            lines.append("")
            lines.append("| knot | id | Wr | |Wr| | Lk0 | Tw0 |")
            lines.append("|---|---|---:|---:|---:|---:|")
            for r in sorted(amph, key=lambda x: x["label"]):
                lines.append(
                    f"| {r['label']} | `{r['ideal_id']}` | {float(r['Wr']):.6g} | "
                    f"{float(r['abs_Wr']):.6g} | {float(r['Lk0']):.6g} | {float(r['Tw0_Lk0_minus_Wr']):.6g} |"
                )
            lines.append("")
    if skipped:
        lines.append("## Skipped / missing")
        lines.append("")
        lines.append("| id | label | status | reason |")
        lines.append("|---|---|---|---|")
        for r in skipped:
            lines.append(f"| `{r.get('ideal_id')}` | {r.get('label')} | {r.get('status')} | {r.get('reason')} |")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--ideal-file", type=Path, default=Path("data/ideal.txt"))
    p.add_argument("--config", type=Path, default=Path("data/helicity_knot_config.csv"))
    p.add_argument("--samples", type=int, default=768)
    p.add_argument("--chunk", type=int, default=256)
    p.add_argument("--ribbon-eps-frac", type=float, default=0.012)
    p.add_argument("--outdir", type=Path, default=Path("results_helicity"))
    p.add_argument("--no-target-link", action="store_true")
    args = p.parse_args()

    if args.samples < 64:
        raise ValueError("--samples must be at least 64")

    cfg = read_config(args.config)
    blocks = parse_ideal_blocks(args.ideal_file)
    args.outdir.mkdir(parents=True, exist_ok=True)

    inventory = []
    entries: list[IdealEntry] = []
    for row in cfg:
        ideal_id = row["ideal_id"].strip()
        label = row.get("label", ideal_id).strip() or ideal_id
        family = row.get("family", "").strip()
        amph = row.get("amphichiral", "").strip().lower() in {"yes", "true", "1"}
        notes = row.get("notes", "")
        block = blocks.get(ideal_id)
        if block is None:
            inventory.append({
                "ideal_id": ideal_id,
                "label": label,
                "family": family,
                "amphichiral": "yes" if amph else "no",
                "status": "missing",
                "reason": "ID not found in ideal.txt",
                "component_count": "",
                "conway": "",
                "L": "",
                "D": "",
            })
            continue

        attrs = block["attrs"]
        is_multi = bool(block["is_multicomponent"])
        comp_count = int(block["component_count"])
        if is_multi:
            inventory.append({
                "ideal_id": ideal_id,
                "label": label,
                "family": family,
                "amphichiral": "yes" if amph else "no",
                "status": "skipped_multicomponent",
                "reason": "Link/multi-component AB block requires mutual-linking helicity extension",
                "component_count": comp_count,
                "conway": attrs.get("Conway", ""),
                "L": attrs.get("L", ""),
                "D": attrs.get("D", ""),
            })
            continue

        if block["coeffs"] is None or block["indices"] is None:
            inventory.append({
                "ideal_id": ideal_id,
                "label": label,
                "family": family,
                "amphichiral": "yes" if amph else "no",
                "status": "skipped_no_coeffs",
                "reason": "No direct coefficient rows",
                "component_count": comp_count,
                "conway": attrs.get("Conway", ""),
                "L": attrs.get("L", ""),
                "D": attrs.get("D", ""),
            })
            continue

        inventory.append({
            "ideal_id": ideal_id,
            "label": label,
            "family": family,
            "amphichiral": "yes" if amph else "no",
            "status": "single_component_ready",
            "reason": "",
            "component_count": comp_count,
            "conway": attrs.get("Conway", ""),
            "L": attrs.get("L", ""),
            "D": attrs.get("D", ""),
        })
        entries.append(IdealEntry(
            ideal_id=ideal_id,
            label=label,
            family=family,
            amphichiral=amph,
            conway=attrs.get("Conway", ""),
            L=attrs.get("L", ""),
            D=attrs.get("D", ""),
            component_count=comp_count,
            is_multicomponent=False,
            coeffs=block["coeffs"],
            indices=block["indices"],
            notes=notes,
        ))

    result_rows = []
    for i, entry in enumerate(entries, 1):
        X = eval_fourier(entry.coeffs, entry.indices, args.samples)
        r = analyze_curve(X, entry, args.samples, args.ribbon_eps_frac, args.chunk, args.no_target_link)
        result_rows.append(r)
        print(
            f"[{i:03d}/{len(entries):03d}] {entry.label:12s} {entry.ideal_id:10s} "
            f"Wr={r['Wr']:+.6f} Lk0={r['Lk0']:+.4f} Tw0={r['Tw0_Lk0_minus_Wr']:+.6f} "
            f"target={r['target_SL']} {r['status']}"
        )

    write_csv(args.outdir / "helicity_inventory.csv", inventory)
    write_csv(args.outdir / "helicity_results.csv", result_rows)
    write_summary(args.outdir / "helicity_summary.md", result_rows, inventory)

    print(f"wrote: {args.outdir / 'helicity_inventory.csv'}")
    print(f"wrote: {args.outdir / 'helicity_results.csv'}")
    print(f"wrote: {args.outdir / 'helicity_summary.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
