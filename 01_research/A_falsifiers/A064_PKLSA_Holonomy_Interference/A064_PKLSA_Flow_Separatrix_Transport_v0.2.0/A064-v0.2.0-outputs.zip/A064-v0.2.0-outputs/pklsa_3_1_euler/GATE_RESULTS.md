# A064 gate results
- Mode: `EULER_SIMULATION_MODEL`
- Evidence: `geometry_initialized_periodic_3d_euler_model`
- Discovery SHA-256: `268691de8d5d495942065dfb01c16c1dde11d6a569da4bd85fccc6aa4323c502`
- Divergence (p95 dx/U): `0.004034`
- Candidate identified: `True`
- Feature status: `PERMEABLE_NONMATERIAL_FEATURE`
- True separatrix manifold gate: `UNRESOLVED_NOT_CONSTRUCTED`
- Overall: `CANDIDATE_FALSIFIED_AS_MATERIAL_AT_TESTED_SCALE`
