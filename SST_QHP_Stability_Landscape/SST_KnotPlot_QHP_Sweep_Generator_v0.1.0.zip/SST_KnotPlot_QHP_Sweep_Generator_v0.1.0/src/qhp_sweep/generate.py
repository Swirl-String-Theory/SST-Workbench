from __future__ import annotations
import argparse,csv,json,hashlib,re
from pathlib import Path
from .geometry import load_xyz,save_xyz,arclength_resample_closed,apply_qhp,metrics

EXTS={'.txt','.xyz','.dat','.coords'}

def sha256(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def family_from_name(p):
    s=p.stem.lower()
    m=re.search(r'(?<!\d)(\d+)[._-](\d+)(?!\d)',s)
    return f'{m.group(1)}.{m.group(2)}' if m else p.parent.name

def discover(root):
    root=Path(root)
    out=[]
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in EXTS:
            try:
                x=load_xyz(p)
                out.append((p,x))
            except Exception: pass
    return out

def token(v):
    if abs(v)<5e-15:return '0'
    sign='m' if v<0 else ''
    return sign+(f'{abs(v):.6g}'.replace('.','p').replace('+',''))

def axis_points(vals):
    vals=sorted(set(float(v) for v in vals))
    pts={(0.0,0.0,0.0)}
    for v in vals:
        pts.add((v,0,0));pts.add((0,v,0));pts.add((0,0,v))
    return sorted(pts)

def full_grid(vals):
    vals=sorted(set(float(v) for v in vals))
    return [(q,h,p) for q in vals for h in vals for p in vals]

def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('dataset')
    ap.add_argument('--out',default=None)
    ap.add_argument('--config',default='config/basic.json')
    ap.add_argument('--families',default='')
    ns=ap.parse_args(argv)
    cfg=json.loads(Path(ns.config).read_text())
    src=Path(ns.dataset).resolve(); out=Path(ns.out).resolve() if ns.out else src.parent/'qhp'
    fam_filter={s.strip() for s in ns.families.split(',') if s.strip()}
    seeds=discover(src)
    if fam_filter: seeds=[z for z in seeds if family_from_name(z[0]) in fam_filter]
    if not seeds: raise SystemExit(f'No parseable XYZ seed files found under {src}')
    vals=cfg['amplitudes']; points=full_grid(vals) if cfg.get('full_grid') else axis_points(vals)
    n=int(cfg['resample_n'])
    out.mkdir(parents=True,exist_ok=True)
    rows=[]; seedrows=[]
    for sp,x0 in seeds:
        fam=family_from_name(sp)
        x0=arclength_resample_closed(x0,n)
        m0=metrics(x0); base_sep=m0['min_nonlocal_vertex_distance']
        famdir=out/fam; famdir.mkdir(parents=True,exist_ok=True)
        seedrows.append({'family':fam,'seed':str(sp),'seed_sha256':sha256(sp),**m0})
        for q,h,p in points:
            x,B=apply_qhp(x0,q,h,p); mm=metrics(x)
            sep_ratio=mm['min_nonlocal_vertex_distance']/max(base_sep,1e-30)
            geom_ok=sep_ratio>=float(cfg['min_separation_ratio']) and mm['ds_cv']<=float(cfg['max_ds_cv'])
            name=f'{fam.replace(".","p")}_q{token(q)}_h{token(h)}_p{token(p)}.txt'
            fp=famdir/name
            save_xyz(fp,x)
            rows.append({
                'file':fp.relative_to(out).as_posix(),'family':fam,
                'q':q,'h':h,'p':p,'replicate':0,'seed_file':str(sp),
                'seed_sha256':sha256(sp),'geometry_ok':str(bool(geom_ok)).lower(),
                'separation_ratio':sep_ratio,**mm,
            })
    fields=list(rows[0].keys())
    with open(out/'qhp_metadata.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    with open(out/'seed_manifest.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(seedrows[0].keys()));w.writeheader();w.writerows(seedrows)
    summary={'format':'SST-QHP-SWEEP-1','source':str(src),'output':str(out),'n_seeds':len(seeds),'n_points_per_seed':len(points),'n_geometries':len(rows),'config':cfg,'n_geometry_ok':sum(r['geometry_ok']=='true' for r in rows)}
    (out/'QHP_SWEEP_SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
