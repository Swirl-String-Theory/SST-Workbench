# Validation — v0.3.2

PASS:
- v0.3.0/v0.3.1 model and bead-allocation selftests.
- Stage 1 contains 0.1, 0.2.1, 0.3.1.
- All four stage plans dry-run.
- Stage 3 twist ladder frozen.
- Live runner uses Popen heartbeat, progress.log, timings.csv, checkpoint-based ETA.
- Generated KPC checkpoint echo passes static KPC audit.
- Real Windows KnotPlot timing cannot be executed in the Linux artifact environment.
