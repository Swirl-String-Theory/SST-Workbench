# CHANGELOG v0.2.0

- New standalone workbench; not a patch to the failed v0.1.4-v0.1.6 runtime path experiments.
- Restricts scope to charge/hooke/power/timeincr.
- 12-run, 100-iteration command certification gate.
- 12-run maximum extended matrix, but only for certified families.
- Uses old v0.1.1 KnotPlot invocation semantics (`-nog`, shortcut CWD, stdin KPC).
- No `alex` dependency.
- Parsed-geometry SHA-256, Kabsch RMS and shape metrics.
- Command rejection is recorded as a scientific result instead of crashing the whole campaign.
