//
// Created by mr on 3/22/2025.
//

#ifndef SSTCORE_KNOT_DYNAMICS_H
#define SSTCORE_KNOT_DYNAMICS_H

#include "SST_Constants.h"
#include "vec3_utils.h"
#include "canonical_constants.h"
#ifndef M_PI
#define M_PI SST::Constants::pi
#endif
// include/knot_dynamics.hpp
#pragma once

#include <vector>
#include <array>
#include <string>
#include <stdexcept>
#include <tuple>
#include <map>
#include <regex>
#include <optional>

namespace sst {

	using Vec3 = std::array<double, 3>;

	// Forward declaration
	struct FourierBlock;
  class KnotParticleModel;

	// Forward declaration for embedded knot files (generated during build)
	std::map<std::string, std::string> get_embedded_knot_files();

	// Embedded ideal database files (generated during build)
	std::map<std::string, std::string> get_embedded_ideal_files();

	// Convenience loader (supports basename fallback like "ideal.txt")
	std::string load_embedded_ideal_text(const std::string& name = "ideal.txt");

	// Resource path resolution: explicit path → env → build tree → installed share → legacy
	// Returns full path to knot.${knot_id}.fseries, or empty if not found.
	std::string find_knot_file_path(const std::string& knot_id, const std::string& explicit_base = "");
	// Returns full path to ideal database file (e.g. "ideal.txt"), or empty if not found.
	std::string find_ideal_file_path(const std::string& filename, const std::string& explicit_base = "");

	// Search embedded + disk ideal*.txt (never knotplot) for <AB Id="ab_id"> block XML.
	// Returns empty string if not found.
	std::string find_ideal_ab_block_by_id(const std::string& ab_id);

	// General Gilbert lookup: <AB>, <HT>, or <TL> by Id. tag empty => try AB, HT, TL in order.
	std::string find_ideal_block_by_id(const std::string& block_id, const std::string& tag = "");

  struct KnotInvariants {
    std::string name;
    int crossing_number = 0;      // k
    int braid_index = 0;          // b
    int seifert_genus = 0;        // g
    int chirality = 0;            // -1, 0, +1
    bool hyperbolic = false;

    double hyperbolic_volume = 0.0;  // Vol_H(T)
    double ropelength_like = 0.0;    // L_tot(T) proxy
    std::optional<double> hyperbolic_volume_opt; // preferred optional representation
    std::optional<double> ropelength;            // preferred optional representation
    double writhe = 0.0;
    double min_self_distance = 0.0;
    double bending_energy = 0.0;

    // Resolved-tube / ropelength geometry (radius convention unless stated otherwise).
    // Canon guard: thickness_rad is reach/normal-injectivity radius, not necessarily r_c.
    double thickness_rad = 0.0;
    double ropelength_rad = 0.0;
    double ropelength_diam = 0.0;
    double minrad_min = 0.0;
    double dcsd_min = 0.0;
    int strut_count = 0;
    int kink_count = 0;
    double contact_residual = 0.0;
    double contact_entropy = 0.0;
    bool ropelength_lower_bound_ok = true;
  };

  enum class SectorGate : int {
    Shielded = 0,
    Exposed = 1,
    Unknown = -1
  };

  struct KnotPrediction {
    SectorGate gate = SectorGate::Unknown;
    double gate_factor = 1.0;  // (lambda_c / (pi r_c))^G
    double xi = 1.0;           // topology factor Xi(T)
    double mass_ratio = 1.0;   // M(T)/M_e
    double mass_kg = 0.0;      // M(T)
    std::string note;
  };

  struct CanonicalConstants {
    double r_c = static_cast<double>(SST::Constants::RC_CORE);
    // Full electron Compton wavelength h/(m_e c). Canon gate lambda_c/(pi r_c)=4/alpha uses full, not reduced, Compton wavelength.
    double lambda_c = static_cast<double>(2.0L * SST::Constants::PI * SST::Constants::H_BAR /
                                (SST::Constants::M_ELECTRON * SST::Constants::C_VACUUM));
    double m_e = static_cast<double>(SST::Constants::M_ELECTRON);
    double rho_f = static_cast<double>(SST::Constants::RHO_FLUID);
    double v_swirl = static_cast<double>(SST::Constants::V_SWIRL);
    double c = static_cast<double>(SST::Constants::C_VACUUM);
    double rho_m = static_cast<double>(SST::Constants::mass_equivalent_density());
    // Horn-envelope density closure for resolved-tube baseline masses.
    // Distinct from rho_m = rho_E/c^2, the medium-scale density in the master equation.
    double rho_horn = SSTCanonicalConstants::horn_envelope_density(m_e, c, v_swirl, r_c);
  };

  struct KnotDerived {
    SectorGate gate = SectorGate::Unknown;
    double gate_factor = 1.0;
    double xi = 1.0;
    double mass_ratio = 1.0;
    double mass_kg = 0.0;
    bool valid = false;
    std::string note;
  };

  class XiModel {
  public:
    virtual ~XiModel() = default;
    [[nodiscard]] virtual double compute_xi(const KnotInvariants& K) const = 0;
    [[nodiscard]] virtual SectorGate assign_gate(const KnotInvariants& K) const = 0;
  };

  class SimpleInvariantXiModel final : public XiModel {
  public:
    struct Params {
      double a_k = 0.0;
      double a_b = 0.0;
      double a_g = 0.0;
      double a_vol = 0.0;
      double a_L = 0.0;
      double a_chi = 0.0;
    };

    explicit SimpleInvariantXiModel(const Params& p);

    [[nodiscard]] double compute_xi(const KnotInvariants& K) const override;
    [[nodiscard]] SectorGate assign_gate(const KnotInvariants& K) const override;

  private:
    Params p_;
  };

  class SSTCanonicalXiModel final : public XiModel {
  public:
    struct Params {
      double alpha_C = 0.0;
      double beta_L = 0.0;
      double gamma_H = 0.0;
      double delta_V = 0.0;      // optional legacy hyperbolic-volume term; set 0 for strict Canon kernel
      int golden_layer = 0;
      bool use_crossing_number_as_C = true;
      bool use_writhe_as_H = true;
    };

    explicit SSTCanonicalXiModel(const Params& p);

    [[nodiscard]] double compute_xi(const KnotInvariants& K) const override;
    [[nodiscard]] SectorGate assign_gate(const KnotInvariants& K) const override;

  private:
    Params p_;
  };

  class MassFunctional {
  public:
    explicit MassFunctional(const CanonicalConstants& c = CanonicalConstants{});

    [[nodiscard]] double baseline_mass_from_ropelength(double L_tot) const; // medium-scale rho_m form; retained for compatibility
    [[nodiscard]] double baseline_mass_from_horn_ropelength(double L_tot) const;
    [[nodiscard]] double bare_master_mass_scale() const;
    [[nodiscard]] double gate_factor(SectorGate G) const;
    [[nodiscard]] KnotDerived evaluate(const KnotInvariants& K, const XiModel& model) const;
    [[nodiscard]] KnotDerived evaluate_electron_normalized(const KnotInvariants& K, const XiModel& model) const;

  private:
    CanonicalConstants c_;
  };

  struct KnotState {
    KnotInvariants inv;
    std::optional<double> contact_score;
    std::optional<double> hopf_like_score;
    std::optional<double> energy_score;
    std::optional<KnotDerived> derived;
  };

  struct KnotReportRow {
    std::string name;
    int k = 0;
    int b = 0;
    int g = 0;
    double vol_h = 0.0;
    double L_tot = 0.0;
    int gate = -1;
    double xi = 1.0;
    double mass_ratio = 1.0;
    double mass_kg = 0.0;
  };

  KnotReportRow make_knot_report_row(const KnotInvariants& K, const KnotDerived& D);

  // Stateless helpers for deterministic per-knot and dataset evaluation.
  KnotDerived evaluate_single_knot(const KnotInvariants& K,
                                   const XiModel& model,
                                   const CanonicalConstants& c = CanonicalConstants{});

  KnotState evaluate_knot_state(const KnotState& state,
                                const XiModel& model,
                                const CanonicalConstants& c = CanonicalConstants{});

  std::vector<KnotReportRow> evaluate_knot_dataset(const std::vector<KnotState>& dataset,
                                                   const XiModel& model,
                                                   const CanonicalConstants& c = CanonicalConstants{});

  class KnotParticleModel {
  public:
    struct Params {
      double a_k = 0.0;
      double a_b = 0.0;
      double a_g = 0.0;
      double a_vol = 0.0;
      double a_L = 0.0;
      double a_wr = 0.0;
      double a_sep = 0.0;
    };

    explicit KnotParticleModel(const Params& p);

    SectorGate assign_gate(const KnotInvariants& K) const;
    double compute_xi(const KnotInvariants& K) const;
    KnotPrediction predict(const KnotInvariants& K) const;

  private:
    Params p_;
  };

        class KnotDynamics {
        public:
                // Compute writhe from filament centerline
                // Ref: Călugăreanu-White formula (approximated)
                static double compute_writhe(const std::vector<Vec3>& centerline);

                // Compute linking number between two vortex filaments
                static int compute_linking_number(const std::vector<Vec3>& curve1, const std::vector<Vec3>& curve2);

                // Compute twist given tangent and normal
                // Twist = ∫ (T × dN/ds) ⋅ B ds
                static double compute_twist(const std::vector<Vec3>& T, const std::vector<Vec3>& B);

                // Compute centerline helicity invariant H_cl
                // H_cl = Lk + Wr, combines link and writhe
                static double compute_centerline_helicity(const std::vector<Vec3>& curve,
                                                                           const std::vector<Vec3>& tangent);

                // Check for reconnection events
                // Returns indices of close approach
                static std::vector<std::pair<int, int>> detect_reconnection_candidates(
                        const std::vector<Vec3>& curve, double threshold);

                // Fourier series evaluation (from heavy_knot)
                struct FourierResult {
                        std::vector<Vec3> positions;
                        std::vector<Vec3> tangents;
                };
                static FourierResult evaluate_fourier_series(
                        const std::vector<std::array<double, 6>>& coeffs,
                        const std::vector<double>& t_vals);

                // Writhe computation using Gauss integral with tangents (from heavy_knot)
                static double writhe_gauss_curve(
                        const std::vector<Vec3>& r,
                        const std::vector<Vec3>& r_t);

                // Estimate crossing number from projections (from heavy_knot)
                static int estimate_crossing_number(
                        const std::vector<Vec3>& r,
                        int directions = 24,
                        int seed = 12345);

                // Planar diagram from curve (from knot_pd)
                using Crossing = std::array<int, 4>;
                using PD = std::vector<Crossing>;
                static PD pd_from_curve(
                        const std::vector<Vec3>& P3,
                        int tries = 40,
                        unsigned int seed = 12345,
                        double min_angle_deg = 1.0,
                        double depth_tol = 1e-6);

                // Biot-Savart and helicity calculations (wrappers for BiotSavart)
                // Compute Biot-Savart velocity field from a closed curve at grid points
                static std::vector<Vec3> compute_biot_savart_velocity_grid(
                        const std::vector<Vec3>& curve,
                        const std::vector<Vec3>& grid_points);

                // Compute vorticity from velocity field on a regular grid
                static std::vector<Vec3> compute_vorticity_grid(
                        const std::vector<Vec3>& velocity,
                        const std::array<int, 3>& shape,
                        double spacing);

                // Extract cubic interior field subset
                static std::vector<Vec3> extract_interior_field(
                        const std::vector<Vec3>& field,
                        const std::array<int, 3>& shape,
                        int margin);

                // Compute helicity invariants (H_charge, H_mass, a_mu)
                static std::tuple<double, double, double> compute_helicity_invariants(
                        const std::vector<Vec3>& v_sub,
                        const std::vector<Vec3>& w_sub,
                        const std::vector<double>& r_sq);

                // High-level method: compute helicity from Fourier block
                // Returns (H_charge, H_mass, a_mu)
                static std::tuple<double, double, double> compute_helicity_from_fourier_block(
                        const FourierBlock& block,
                        int grid_size = 32,
                        double spacing = 0.1,
                        int interior_margin = 8,
                        int nsamples = 1000);
        };

        // Fourier block definition (mode-indexed coefficients, dense vector format)
        struct FourierBlock {
                std::string header;  // optional metadata/comment line
                std::vector<double> a_x, b_x;
                std::vector<double> a_y, b_y;
                std::vector<double> a_z, b_z;
        };

  // Build a mixed metadata+geometry invariant payload from Fourier coefficients.
  KnotInvariants build_invariants_from_fourier_block(
    const FourierBlock& block,
    const std::string& knot_name = "",
    int crossing_number = 0,
    int braid_index = 0,
    int seifert_genus = 0,
    int chirality = 0,
    bool hyperbolic = false,
    double hyperbolic_volume = 0.0,
    int nsamples = 2048,
    int exclude_window = 4);

  // Convenience path-based builder using the largest block in a .fseries file.
  KnotInvariants build_invariants_from_fseries(
    const std::string& path,
    const std::string& knot_name = "",
    int crossing_number = 0,
    int braid_index = 0,
    int seifert_genus = 0,
    int chirality = 0,
    bool hyperbolic = false,
    double hyperbolic_volume = 0.0,
    int nsamples = 2048,
    int exclude_window = 4);

  // End-to-end helpers for Python/dashboard style workflows.
  KnotPrediction predict_particle_from_fourier_block(
    const FourierBlock& block,
    const KnotParticleModel::Params& params,
    const std::string& knot_name = "",
    int crossing_number = 0,
    int braid_index = 0,
    int seifert_genus = 0,
    int chirality = 0,
    bool hyperbolic = false,
    double hyperbolic_volume = 0.0,
    int nsamples = 2048,
    int exclude_window = 4);

  KnotPrediction predict_particle_from_fseries(
    const std::string& path,
    const KnotParticleModel::Params& params,
    const std::string& knot_name = "",
    int crossing_number = 0,
    int braid_index = 0,
    int seifert_genus = 0,
    int chirality = 0,
    bool hyperbolic = false,
    double hyperbolic_volume = 0.0,
    int nsamples = 2048,
    int exclude_window = 4);

        // Optional sparse Fourier representation (for ideal.txt / AB parsing / conversions)
        struct FourierBlockSparse {
                std::string name;
                std::map<int, std::array<double, 3>> A;  // cosine coeffs by harmonic index j>=1
                std::map<int, std::array<double, 3>> B;  // sine coeffs by harmonic index j>=1
        };

        class FourierKnot {
        public:
                struct Block {
                        std::vector<double> a_x, b_x, a_y, b_y, a_z, b_z;
                };

                struct LoadedKnot {
                        std::string name;
                        std::vector<Vec3> points;
                        std::vector<double> curvature;
                };

                struct GeometricDescriptors {
                        double L = 0.0;
                        double bending_energy = 0.0;
                        double min_self_distance = 0.0;
                        double writhe = 0.0;
                        std::vector<double> mode_energy;
                };

                // Rich ideal.txt AB parser support (multi-component capable)
                struct IdealABComponent {
                        int component_index = 0;   // <Component I="...">
                        Vec3 A0{0.0, 0.0, 0.0};    // Coeff I="0" A="..."
                        Vec3 B0{0.0, 0.0, 0.0};    // Coeff I="0" B="..."
                        FourierBlock fourier;      // I >= 1 harmonics in vector form
                };

                struct IdealABBlock {
                        std::string id;            // AB Id="x:x:x"
                        std::string conway;        // Conway="..."
                        double L = 0.0;            // L="..."
                        double D = 0.0;            // D="..."
                        int n = 1;                 // n="..." (number of components)
                        std::string source_tag;    // AB | HT | TL
                        std::vector<IdealABComponent> components;

                        // Backward-compat convenience: first component's Fourier block
                        FourierBlock fourier;
                };

                // Parse AB, HT, and TL blocks from Gilbert ideal*.txt content
                static std::vector<IdealABBlock> parse_ideal_gilbert_from_string(const std::string& content);

                // Parse all AB blocks from ideal*.txt file path / content
                static std::vector<IdealABBlock> parse_ideal_txt_multi(const std::string& path);
                static std::vector<IdealABBlock> parse_ideal_txt_from_string(const std::string& content);

                // Single-AB on-demand parse (avoids parsing entire file when only one is needed)
                static IdealABBlock parse_ideal_ab_by_id_from_string(const std::string& content, const std::string& ab_id);
                static IdealABBlock parse_ideal_ab_by_id_from_embedded(const std::string& ab_id,
                                                                       const std::string& embedded_name = "ideal.txt");

                // Find index helper for already-parsed vectors
                static int index_of_ideal_id(const std::vector<IdealABBlock>& blocks, const std::string& id);

                // Metadata formatter for display/logging
                static std::string format_ideal_ab_header(const IdealABBlock& ab);

                // Evaluate one ideal component including I=0 term offsets
                static std::vector<Vec3> evaluate_ideal_component(const IdealABComponent& comp,
                                                                  const std::vector<double>& s);

                // Evaluate all components of an ideal AB block
                static std::vector<std::vector<Vec3>> evaluate_ideal_ab_components(const IdealABBlock& ab,
                                                                                   const std::vector<double>& s);

                // For compatibility with pybind/cpp, reuse FourierBlock as dense runtime block
                std::vector<FourierBlock> blocks;
                FourierBlock activeBlock;
                std::vector<Vec3> points;

                void loadBlocks(const std::string& filename);
                void selectMaxHarmonics();
                void reconstruct(size_t N = 1000);
                // Parse a .fseries file into blocks. Each block is separated by either a '%' header
                // or by a blank line. Lines contain 6 doubles: a_x b_x a_y b_y a_z b_z
                static std::vector<FourierBlock> parse_fseries_multi(const std::string& path);
                
                // Parse .fseries content from a string (for embedded files)
                static std::vector<FourierBlock> parse_fseries_from_string(const std::string& content);

                // Choose the block with the largest number of harmonics
                static int index_of_largest_block(const std::vector<FourierBlock>& blocks);

                // Evaluate r(s) for a block on samples s (radians in [0,2π])
                static std::vector<Vec3> evaluate(const FourierBlock& block, const std::vector<double>& s);

                // Center points at their centroid and return centered points
                static std::vector<Vec3> center_points(const std::vector<Vec3>& pts);

                // Discrete curvature from points using central differences (periodic curve)
                static std::vector<double> curvature(const std::vector<Vec3>& pts, double eps = 1e-8);

                // Convenience: load file, pick largest block, evaluate on ns samples in [0,2π],
                // center the result and return (points, curvature)
                static std::pair<std::vector<Vec3>, std::vector<double>>
                load_knot(const std::string& path, int nsamples);

                // Load all knots from a list of file paths, return vector of LoadedKnot
                // Each knot uses the largest block and is evaluated with nsamples points
                static std::vector<LoadedKnot>
                load_all_knots(const std::vector<std::string>& paths, int nsamples = 1000);

                static std::tuple<Vec3, Vec3, Vec3, Vec3> evaluate_with_derivatives(const FourierBlock& block, double s);
                static std::vector<double> curvature_exact(const FourierBlock& block,
                                                           const std::vector<double>& s,
                                                           double eps = 1e-12);
                static double length_exact(const FourierBlock& block, int nsamples = 4096);
                static double bending_energy_exact(const FourierBlock& block, int nsamples = 4096, double eps = 1e-12);
                static std::vector<double> mode_energies(const FourierBlock& block);
                static double min_self_distance_sampled(const std::vector<Vec3>& pts, int exclude_window = 4);
                static double min_self_distance_exactish(const FourierBlock& block, int nsamples = 2048, int exclude_window = 4);

                static GeometricDescriptors describe_fourier_block(const FourierBlock& block,
                                                                   int nsamples = 2048,
                                                                   int exclude_window = 4);

                static Vec3 evalPoint(const FourierBlock& blk, double s);
        };

        // Vortex knot system (from vortex_knot_system)
        class VortexKnotSystem {
        public:
                VortexKnotSystem(double gamma = 1.0);

                void initialize_trefoil_knot(size_t resolution = 400);
                void initialize_figure8_knot(size_t resolution = 400);
                
                // Initialize any knot from .fseries file by identifier (e.g., "3_1", "4_1", "5_1")
                // Searches in standard locations for knot_fseries directory
                void initialize_knot_from_name(const std::string& knot_id, size_t resolution = 1000);

                void evolve(double dt, size_t steps);

                [[nodiscard]] const std::vector<Vec3>& get_positions() const;
                [[nodiscard]] const std::vector<Vec3>& get_tangents() const;

        private:
                std::vector<Vec3> positions;
                std::vector<Vec3> tangents;
                double circulation;

                void compute_tangents();
                static std::string find_knot_file(const std::string& knot_id);
        };

        inline double compute_writhe(const std::vector<Vec3>& centerline) {
                return KnotDynamics::compute_writhe(centerline);
        }

        inline int compute_linking_number(const std::vector<Vec3>& curve1, const std::vector<Vec3>& curve2) {
                return KnotDynamics::compute_linking_number(curve1, curve2);
        }

        inline double compute_twist(const std::vector<Vec3>& T, const std::vector<Vec3>& B) {
                return KnotDynamics::compute_twist(T, B);
        }

        inline double compute_centerline_helicity(const std::vector<Vec3>& curve,
                                                                           const std::vector<Vec3>& tangent) {
                return KnotDynamics::compute_centerline_helicity(curve, tangent);
        }

        inline std::vector<std::pair<int, int>> detect_reconnection_candidates(
                        const std::vector<Vec3>& curve, double threshold) {
                return KnotDynamics::detect_reconnection_candidates(curve, threshold);
        }

} // namespace sst


#endif //SSTCORE_KNOT_DYNAMICS_H