#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from sst_counterpulley.benchmark import benchmark_blind_summary
from sst_counterpulley.core import write_json

def main()->int:
    ap=argparse.ArgumentParser(description="Open alpha only after a blind H0-H12 summary has been archived.")
    ap.add_argument("blind_summary"); ap.add_argument("--out",default="audit_out_blind/posthoc_alpha_benchmark.json")
    a=ap.parse_args(); src=json.loads(Path(a.blind_summary).read_text(encoding="utf-8")); r=benchmark_blind_summary(src)
    write_json(a.out,r); print(json.dumps(r,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
