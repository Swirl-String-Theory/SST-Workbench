
MODE: VERIFIER

TASK:
- Check LaTeX
- Check logic
- Fix inconsistencies
