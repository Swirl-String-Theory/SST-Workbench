from __future__ import annotations
from pathlib import Path
import argparse,os,shutil,zipfile,json
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/"balance_design.json").read_text(encoding="utf-8"))

def candidates():
    env=os.environ.get("TREFOIL_V021_SOURCE","").strip()
    if env: yield Path(env)
    yield ROOT.parent/"Trefoil_Balance_Point_Campaign_v0.2.1"
    yield ROOT.parent/"Trefoil_Balance_Point_Campaign_v0.2.1_outputs.zip"
    yield ROOT.parent/"Trefoil_Balance_Point_Campaign_v0.2.1_outputs(1).zip"

def needed_names():
    # Source v0.2.1 ends at 60000. Never require future v0.2.2 checkpoints.
    track={x for x in D["continuation"]["zero_track"] if x<=D["continuation"]["resume_from"]}|{0,15000,20000,25000}
    names=set()
    for s in D["settings"]:
        rid=f"K31__{s['id']}"
        for it in track:
            names.add(f"out/{rid}_i{it:05d}.txt")
        names.add(f"out/{rid}_i60000.k")
    return names

def import_folder(src):
    base=src/"out" if (src/"out").is_dir() else src
    copied=0
    for s in D["settings"]:
        rid=f"K31__{s['id']}"
        # all text checkpoints are cheap and useful provenance
        for p in base.glob(f"{rid}_i*.txt"):
            shutil.copy2(p,ROOT/"out"/p.name);copied+=1
        kp=base/f"{rid}_i60000.k"
        if not kp.is_file(): raise FileNotFoundError(kp)
        shutil.copy2(kp,ROOT/"out"/kp.name);copied+=1
    # optional prior analysis provenance
    for rel in ["analysis/REPORT.json","analysis/RESUME_CONTINUITY.json"]:
        p=src/rel
        if p.is_file():
            q=ROOT/"reference"/("imported_v021_"+p.name)
            shutil.copy2(p,q)
    return copied

def import_zip(src):
    copied=0
    need=needed_names()
    with zipfile.ZipFile(src) as z:
        names=set(z.namelist())
        missing=[n for n in need if n not in names]
        if missing:
            raise RuntimeError(f"Source zip lacks {len(missing)} required files; first={missing[:3]}")
        for n in sorted(names):
            if n.startswith("out/K31__") and (n.endswith(".txt") or n.endswith("_i60000.k")):
                dst=ROOT/n;dst.parent.mkdir(parents=True,exist_ok=True)
                dst.write_bytes(z.read(n));copied+=1
        for n in ["analysis/REPORT.json","analysis/RESUME_CONTINUITY.json"]:
            if n in names:
                (ROOT/"reference"/("imported_v021_"+Path(n).name)).write_bytes(z.read(n))
    return copied

def validate():
    missing=[]
    for s in D["settings"]:
        rid=f"K31__{s['id']}"
        for fn in [f"{rid}_i00000.txt",f"{rid}_i30000.txt",f"{rid}_i40000.txt",
                   f"{rid}_i50000.txt",f"{rid}_i60000.txt",f"{rid}_i60000.k"]:
            p=ROOT/"out"/fn
            if not p.is_file() or p.stat().st_size==0: missing.append(str(p))
    if missing: raise RuntimeError(f"Import incomplete: {len(missing)} missing; first={missing[:5]}")
    print("SOURCE IMPORT VALIDATION PASS: required 0..60k metric history + 20 i60000 states")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--source",default=None)
    a=ap.parse_args()
    src=Path(a.source) if a.source else next((p for p in candidates() if p.exists()),None)
    if src is None:
        raise SystemExit("ERROR: no v0.2.1 source found. Set TREFOIL_V021_SOURCE to the v0.2.1 folder or repaired outputs.zip")
    print("SOURCE:",src)
    n=import_folder(src) if src.is_dir() else import_zip(src)
    print("IMPORTED FILES:",n)
    validate()
    return 0
if __name__=="__main__":
    raise SystemExit(main())
