"""SSTcore knot taxonomy spine: hyperbolic volume + chirality.

This module is deliberately a Research-Track metadata layer. It does not
replace the Rayleigh/rocking audit or the energy functional. Its purpose is
family gating: torus/leptonic, hyperbolic/chiral, and amphichiral/inert-style
candidate coordinates.

SnapPy is optional. Without SnapPy, the module still returns vetted seed
records for 3_1 and 4_1 and can read/write JSONL taxonomy databases.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

TAXONOMY_SCHEMA_VERSION = "0.1.0"
VOL_FIGURE_EIGHT = 2.029883212819307
DEFAULT_TOLERANCE_VOLUME = 1.0e-10
MIRROR_CONVENTION = (
    "sigma_chi=+1 denotes the chosen original/table orientation mapped to matter; "
    "mirror flips sigma_chi for chiral knots; amphichiral knots use sigma_chi=0."
)

KNOT_TYPE_ENUM = {"torus", "hyperbolic", "satellite", "composite", "unknown"}
CHIRALITY_ENUM = {"chiral_left", "chiral_right", "amphichiral", "unknown"}
SOURCE_ENUM = {"knot_table", "knotplot_export", "snappy", "user_defined"}
SIGMA_ENUM = {-1, 0, 1}

# Small built-in seed table. Expand via data/taxonomy_db*.jsonl, not by
# hardcoding large tables in this module.
KNOWN_RECORDS: dict[str, dict[str, Any]] = {
    "3_1": {
        "id": "3_1",
        "components": 1,
        "pd_code": None,
        "dt_code": None,
        "is_prime": True,
        "knot_type": "torus",
        "vol_hyperbolic": None,
        "vol_ref": VOL_FIGURE_EIGHT,
        "hvol_norm": None,
        "hvol_signed": None,
        "chirality": "chiral_right",
        "sigma_chi": 1,
        "features": {"C_raw": 3, "L_rope": 32.7436, "H_link": None, "E_eff": None},
        "source": "knot_table",
        "compute": {
            "snappy_version": None,
            "tolerance_volume": DEFAULT_TOLERANCE_VOLUME,
            "triangulation_method": None,
            "mirror_convention": MIRROR_CONVENTION,
            "taxonomy_schema_version": TAXONOMY_SCHEMA_VERSION,
            "classification_note": "Seed fallback record; torus knots have null hyperbolic volume.",
        },
    },
    "4_1": {
        "id": "4_1",
        "components": 1,
        "pd_code": None,
        "dt_code": None,
        "is_prime": True,
        "knot_type": "hyperbolic",
        "vol_hyperbolic": VOL_FIGURE_EIGHT,
        "vol_ref": VOL_FIGURE_EIGHT,
        "hvol_norm": 1.0,
        "hvol_signed": 0.0,
        "chirality": "amphichiral",
        "sigma_chi": 0,
        "features": {"C_raw": 4, "L_rope": 42.0887, "H_link": None, "E_eff": None},
        "source": "knot_table",
        "compute": {
            "snappy_version": None,
            "tolerance_volume": DEFAULT_TOLERANCE_VOLUME,
            "triangulation_method": "reference_table_seed",
            "mirror_convention": MIRROR_CONVENTION,
            "taxonomy_schema_version": TAXONOMY_SCHEMA_VERSION,
            "classification_note": "Figure-eight knot is hyperbolic and amphichiral; volume is nonzero but signed volume cancels.",
        },
    },
}

ALIASES = {
    "trefoil": "3_1",
    "3:1:1": "3_1",
    "figure8": "4_1",
    "figure-eight": "4_1",
    "figure_eight": "4_1",
    "4:1:1": "4_1",
}


def canonical_id(knot_id: str) -> str:
    key = str(knot_id).strip()
    return ALIASES.get(key.lower(), key)


def _clean_float(value: Any) -> float | None:
    if value is None:
        return None
    out = float(value)
    if not math.isfinite(out):
        return None
    return out


def compute_hvol_fields(record: dict[str, Any], *, vol_ref: float | None = VOL_FIGURE_EIGHT) -> dict[str, Any]:
    """Return a copy with hvol_norm and hvol_signed filled consistently."""
    out = copy.deepcopy(record)
    vol = _clean_float(out.get("vol_hyperbolic"))
    ref = _clean_float(out.get("vol_ref")) or _clean_float(vol_ref)
    sigma = int(out.get("sigma_chi", 0))
    if vol is None:
        out["vol_ref"] = ref
        out["hvol_norm"] = None
        out["hvol_signed"] = None
        return out
    if ref is None or ref <= 0:
        raise ValueError("vol_ref must be positive when vol_hyperbolic is present")
    h = float(vol / ref)
    out["vol_ref"] = float(ref)
    out["hvol_norm"] = h
    out["hvol_signed"] = float(sigma * h)
    return out


def apply_mirror(record: dict[str, Any]) -> dict[str, Any]:
    """Diagrammatic mirror convention: flip sigma for chiral records only."""
    out = copy.deepcopy(record)
    sigma = int(out.get("sigma_chi", 0))
    chirality = out.get("chirality")
    if chirality == "amphichiral" or sigma == 0:
        out["chirality"] = "amphichiral"
        out["sigma_chi"] = 0
    else:
        out["sigma_chi"] = -sigma
        if chirality == "chiral_left":
            out["chirality"] = "chiral_right"
        elif chirality == "chiral_right":
            out["chirality"] = "chiral_left"
    out = compute_hvol_fields(out, vol_ref=out.get("vol_ref"))
    note = out.setdefault("compute", {}).get("classification_note") or ""
    out["compute"]["classification_note"] = (note + " Mirror operation applied by SST taxonomy convention.").strip()
    return out


def taxonomy_sector(record: dict[str, Any]) -> dict[str, Any]:
    """Family-gating interpretation. This is taxonomy, not mass prediction."""
    knot_type = record.get("knot_type")
    sigma = int(record.get("sigma_chi", 0))
    chirality = record.get("chirality")
    if chirality == "amphichiral" or sigma == 0:
        sector = "inert_neutrino_candidate"
        rationale = "amphichiral or signed-cancelled taxonomy coordinate"
    elif knot_type == "torus":
        sector = "lepton_track"
        rationale = "torus/non-hyperbolic family with nonzero chirality sign"
    elif knot_type == "hyperbolic" and sigma != 0:
        sector = "quark_track"
        rationale = "hyperbolic family with nonzero chirality sign"
    else:
        sector = "unknown_track"
        rationale = "insufficient topology/chirality information"
    return {
        "sector": sector,
        "matter_sign": sigma,
        "hvol_signed": record.get("hvol_signed"),
        "rationale": rationale,
        "status": "RESEARCH_TRACK: taxonomy-only gating; mass/stability remains in E_eff and dynamic audits.",
    }


def validate_record_light(record: dict[str, Any]) -> list[str]:
    """Dependency-free structural checks matching the bundled JSON schema."""
    errors: list[str] = []
    required = ["id", "components", "knot_type", "chirality", "sigma_chi", "source", "compute"]
    for key in required:
        if key not in record:
            errors.append(f"missing required field: {key}")
    if not isinstance(record.get("id"), str) or not record.get("id"):
        errors.append("id must be a nonempty string")
    if not isinstance(record.get("components"), int) or record.get("components", 0) < 1:
        errors.append("components must be integer >= 1")
    if record.get("knot_type") not in KNOT_TYPE_ENUM:
        errors.append(f"knot_type must be one of {sorted(KNOT_TYPE_ENUM)}")
    if record.get("chirality") not in CHIRALITY_ENUM:
        errors.append(f"chirality must be one of {sorted(CHIRALITY_ENUM)}")
    if record.get("sigma_chi") not in SIGMA_ENUM:
        errors.append("sigma_chi must be one of -1, 0, +1")
    if record.get("source") not in SOURCE_ENUM:
        errors.append(f"source must be one of {sorted(SOURCE_ENUM)}")
    compute = record.get("compute")
    if not isinstance(compute, dict):
        errors.append("compute must be an object")
    elif not isinstance(compute.get("mirror_convention"), str) or not compute.get("mirror_convention"):
        errors.append("compute.mirror_convention must be a nonempty string")
    features = record.get("features", {})
    if features is not None and not isinstance(features, dict):
        errors.append("features must be an object if supplied")
    if record.get("chirality") == "amphichiral" and record.get("sigma_chi") != 0:
        errors.append("amphichiral records must use sigma_chi=0")
    if record.get("sigma_chi") == 0 and record.get("hvol_signed") not in (0, 0.0, None):
        errors.append("sigma_chi=0 records must have hvol_signed=0 or null")
    if record.get("knot_type") != "hyperbolic" and record.get("vol_hyperbolic") not in (None,):
        errors.append("non-hyperbolic records should use vol_hyperbolic=null")
    return errors


def _snappy_version(snappy: Any) -> str | None:
    for attr in ("version", "__version__"):
        value = getattr(snappy, attr, None)
        if callable(value):
            try:
                return str(value())
            except Exception:
                continue
        if value:
            return str(value)
    return None


def _verify_hyperbolic(M: Any) -> bool:
    try:
        result = M.verify_hyperbolicity()
    except Exception:
        return False
    if isinstance(result, tuple):
        return bool(result[0])
    return bool(result)


def _snappy_record(knot_id: str, *, mirror: bool, vol_ref: float, tolerance_volume: float) -> dict[str, Any] | None:
    try:
        import snappy  # type: ignore
    except Exception:
        return None
    kid = canonical_id(knot_id)
    try:
        M = snappy.Manifold(kid)
        if mirror:
            try:
                M = M.reverse_orientation()
            except Exception:
                # Volume should still match; chirality sign is handled separately.
                pass
        verified = _verify_hyperbolic(M)
        volume = float(M.volume()) if verified else None
    except Exception:
        return None
    base = copy.deepcopy(KNOWN_RECORDS.get(kid, {
        "id": kid,
        "components": 1,
        "pd_code": None,
        "dt_code": None,
        "is_prime": None,
        "knot_type": "hyperbolic" if verified else "unknown",
        "vol_hyperbolic": volume,
        "vol_ref": vol_ref,
        "hvol_norm": None,
        "hvol_signed": None,
        "chirality": "unknown",
        "sigma_chi": 1 if verified else 0,
        "features": {"C_raw": None, "L_rope": None, "H_link": None, "E_eff": None},
        "source": "snappy",
        "compute": {},
    }))
    base["knot_type"] = "hyperbolic" if verified else base.get("knot_type", "unknown")
    base["vol_hyperbolic"] = volume
    base["vol_ref"] = vol_ref
    base["source"] = "snappy"
    base.setdefault("compute", {})
    base["compute"].update({
        "snappy_version": _snappy_version(snappy),
        "tolerance_volume": tolerance_volume,
        "triangulation_method": "snappy.verify_hyperbolicity",
        "mirror_convention": MIRROR_CONVENTION,
        "taxonomy_schema_version": TAXONOMY_SCHEMA_VERSION,
        "classification_note": "SnapPy-derived volume; chirality still follows table metadata when available.",
    })
    base = compute_hvol_fields(base, vol_ref=vol_ref)
    return apply_mirror(base) if mirror else base


def compute_record(
    knot_id: str | None = None,
    *,
    pd_code: str | None = None,
    dt_code: str | None = None,
    mirror: bool = False,
    vol_ref: float = VOL_FIGURE_EIGHT,
    tolerance_volume: float = DEFAULT_TOLERANCE_VOLUME,
    prefer_snappy: bool = True,
) -> dict[str, Any]:
    """Compute or retrieve a taxonomy record.

    For now, PD/DT inputs are stored as user-defined placeholders unless SnapPy
    support is expanded in a local environment. This avoids inventing topology
    classifications from geometry-only data.
    """
    kid = canonical_id(knot_id or "user_defined")
    if prefer_snappy and knot_id:
        rec = _snappy_record(kid, mirror=mirror, vol_ref=vol_ref, tolerance_volume=tolerance_volume)
        if rec is not None:
            return rec
    if kid in KNOWN_RECORDS:
        rec = copy.deepcopy(KNOWN_RECORDS[kid])
        rec["vol_ref"] = vol_ref
        rec = compute_hvol_fields(rec, vol_ref=vol_ref)
        return apply_mirror(rec) if mirror else rec
    rec = {
        "id": kid,
        "components": 1,
        "pd_code": pd_code,
        "dt_code": dt_code,
        "is_prime": None,
        "knot_type": "unknown",
        "vol_hyperbolic": None,
        "vol_ref": vol_ref,
        "hvol_norm": None,
        "hvol_signed": None,
        "chirality": "unknown",
        "sigma_chi": 0,
        "features": {"C_raw": None, "L_rope": None, "H_link": None, "E_eff": None},
        "source": "user_defined",
        "compute": {
            "snappy_version": None,
            "tolerance_volume": tolerance_volume,
            "triangulation_method": None,
            "mirror_convention": MIRROR_CONVENTION,
            "taxonomy_schema_version": TAXONOMY_SCHEMA_VERSION,
            "classification_note": "Unknown/user-defined record; no hyperbolic invariant assigned.",
        },
    }
    return rec


def load_jsonl(path: str | Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with Path(path).open("r", encoding="utf-8") as fh:
        for line_no, line in enumerate(fh, start=1):
            text = line.strip()
            if not text or text.startswith("#"):
                continue
            try:
                records.append(json.loads(text))
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid JSONL at {path}:{line_no}: {exc}") from exc
    return records


def write_jsonl(path: str | Path, records: Iterable[dict[str, Any]]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as fh:
        for rec in records:
            fh.write(json.dumps(rec, separators=(",", ":"), sort_keys=False) + "\n")


def lookup_record(path: str | Path, knot_id: str) -> dict[str, Any] | None:
    kid = canonical_id(knot_id)
    for rec in load_jsonl(path):
        if canonical_id(str(rec.get("id", ""))) == kid:
            return rec
    return None


def run_taxonomy_checks() -> dict[str, Any]:
    rec3 = compute_record("3_1", prefer_snappy=False)
    rec4 = compute_record("4_1", prefer_snappy=False)
    mir3 = apply_mirror(rec3)
    mir4 = apply_mirror(rec4)
    checks = {
        "schema_version": TAXONOMY_SCHEMA_VERSION,
        "record_3_1_valid": not validate_record_light(rec3),
        "record_4_1_valid": not validate_record_light(rec4),
        "torus_volume_null": rec3["knot_type"] == "torus" and rec3["vol_hyperbolic"] is None,
        "figure8_hvol_norm_one": abs(float(rec4["hvol_norm"]) - 1.0) < 1e-12,
        "figure8_amphichiral_signed_zero": rec4["sigma_chi"] == 0 and rec4["hvol_signed"] == 0.0,
        "mirror_flips_chiral_sigma": rec3["sigma_chi"] == 1 and mir3["sigma_chi"] == -1,
        "mirror_preserves_amphichiral_sigma": rec4["sigma_chi"] == 0 and mir4["sigma_chi"] == 0,
    }
    checks["ok"] = all(bool(v) for k, v in checks.items() if k not in {"schema_version"})
    return checks


def _main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Compute SSTcore knot taxonomy records.")
    p.add_argument("--id", default="4_1", help="Canonical knot/link id such as 3_1 or 4_1.")
    p.add_argument("--pd-code", default=None, help="Optional PD code string. Stored as metadata unless local SnapPy support is extended.")
    p.add_argument("--dt-code", default=None, help="Optional DT code string. Stored as metadata unless local SnapPy support is extended.")
    p.add_argument("--mirror", action="store_true", help="Apply SST diagrammatic mirror convention to the record.")
    p.add_argument("--no-snappy", action="store_true", help="Do not attempt SnapPy; use seed/user-defined fallback only.")
    p.add_argument("--vol-ref", type=float, default=VOL_FIGURE_EIGHT, help="Hyperbolic reference volume, default Vol(4_1).")
    p.add_argument("--out", default="", help="Optional JSON output file.")
    p.add_argument("--jsonl", default="", help="Optional JSONL output file; appends one compact record line.")
    p.add_argument("--validate", action="store_true", help="Run dependency-free structural validation.")
    p.add_argument("--classify", action="store_true", help="Add taxonomy sector classification to printed JSON.")
    p.add_argument("--checks", action="store_true", help="Run built-in taxonomy sanity checks instead of computing one record.")
    args = p.parse_args(argv)
    if args.checks:
        result = run_taxonomy_checks()
        print(json.dumps(result, indent=2))
        return 0 if result["ok"] else 1
    rec = compute_record(
        args.id,
        pd_code=args.pd_code,
        dt_code=args.dt_code,
        mirror=args.mirror,
        vol_ref=args.vol_ref,
        prefer_snappy=not args.no_snappy,
    )
    errors = validate_record_light(rec) if args.validate else []
    result: dict[str, Any] = rec
    if args.classify or args.validate:
        result = {"record": rec}
        if args.classify:
            result["classification"] = taxonomy_sector(rec)
        if args.validate:
            result["validation_errors"] = errors
            result["valid"] = not errors
    text = json.dumps(result, indent=2)
    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")
    if args.jsonl:
        with Path(args.jsonl).open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, separators=(",", ":")) + "\n")
    print(text)
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(_main())
