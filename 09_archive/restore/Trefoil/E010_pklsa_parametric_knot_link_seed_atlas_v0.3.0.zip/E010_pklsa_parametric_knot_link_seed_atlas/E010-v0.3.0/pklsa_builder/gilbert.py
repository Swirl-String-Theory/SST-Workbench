from __future__ import annotations
from pathlib import Path
import gzip, re, xml.etree.ElementTree as ET, numpy as np

_ID_RE=re.compile(r'^(\d+):(\d+):(\d+)$')

def canonical_id_from_gilbert(record_id):
    m=_ID_RE.match(str(record_id))
    if not m: return None
    crossings,index,components=map(int,m.groups())
    if components==1: return f'{crossings}_{index}'
    return f'GILBERT_LINK_{crossings}_{index}_{components}'

def iter_gilbert_records(path):
    """Stream Brian Gilbert AB/HT Fourier records from Ideal*.txt.gz.

    For each record, coefficients follow r(t)=sum_i A_i cos(i t)+B_i sin(i t).
    The upstream L and D attributes are preserved as reference metadata.
    """
    p=Path(path)
    opener=gzip.open if p.suffix.lower()=='.gz' else open
    with opener(p,'rt',encoding='utf-8',errors='strict') as f:
        # ET.iterparse requires a binary-ish file-like or filename; gzip text works in practice,
        # but use an incremental XMLPullParser to avoid materializing the catalogue.
        parser=ET.XMLPullParser(events=('start','end'))
        current=None
        for chunk in iter(lambda:f.read(65536),''):
            parser.feed(chunk)
            for ev,elem in parser.read_events():
                if ev=='start' and elem.tag in ('AB','HT'):
                    current={'tag':elem.tag,'attrs':dict(elem.attrib),'coeff':[]}
                elif ev=='end' and elem.tag=='Coeff' and current is not None:
                    I=int(elem.attrib['I'])
                    A=np.fromstring(elem.attrib['A'],sep=',',dtype=float)
                    B=np.fromstring(elem.attrib['B'],sep=',',dtype=float)
                    if A.shape!=(3,) or B.shape!=(3,): raise ValueError('Gilbert Coeff must contain 3-vectors A and B')
                    current['coeff'].append((I,A,B))
                    elem.clear()
                elif ev=='end' and elem.tag in ('AB','HT') and current is not None:
                    current['canonical_id']=canonical_id_from_gilbert(current['attrs'].get('Id'))
                    yield current
                    current=None; elem.clear()

def find_gilbert_record(path, canonical_id):
    for r in iter_gilbert_records(path):
        if r['canonical_id']==canonical_id: return r
    raise KeyError(f'{canonical_id} not found in {path}')

def sample_gilbert_record(record,n=4096):
    t=np.linspace(0,2*np.pi,int(n),endpoint=False)
    out=np.zeros((int(n),3),float)
    for I,A,B in record['coeff']:
        out += np.cos(I*t)[:,None]*A[None,:] + np.sin(I*t)[:,None]*B[None,:]
    return out
