#!/usr/bin/env python3
"""Independent dimensionaless Gate-1 crosschecks for a finite-core T(2,3) field.

This is a numerical verification attempt, NOT an interval proof of reach, Euler
relative equilibrium, or nonlinear stability. No SST constants are imported.

Requires numpy and scipy. The vorticity is evaluated in Euclidean 3D from the
analytic torus frame; FFT convolution uses the unregularized free-space
Biot-Savart kernel, sampled at grid cell centers (the diagonal is set to zero).
Both grid interpolation and singular-kernel quadrature have discretization
error, so the reported helicity must be convergence-tested.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.spatial import cKDTree
from scipy.integrate import quad
from scipy import fft as sfft
from numpy.polynomial.legendre import leggauss

R0=1.0
A_TORUS=0.35
GAMMA=1.0
A_CORE=0.20
ETA_C=0.95
BUMP_B=2.0


def xder(phi):
    p=np.asarray(phi)
    co,si=np.cos(2*p),np.sin(2*p)
    c,s=np.cos(3*p),np.sin(3*p)
    r=R0*(1+A_TORUS*c)
    dr=-3*R0*A_TORUS*s
    d2r=-9*R0*A_TORUS*c
    X=np.stack([r*co,r*si,R0*A_TORUS*s],axis=-1)
    Xp=np.stack([dr*co-2*r*si,dr*si+2*r*co,3*R0*A_TORUS*c],axis=-1)
    Xpp=np.stack([(d2r-4*r)*co-4*dr*si,(d2r-4*r)*si+4*dr*co,-9*R0*A_TORUS*s],axis=-1)
    return X,Xp,Xpp


def geom(phi):
    X,Xp,Xpp=xder(phi)
    speed=np.linalg.norm(Xp,axis=-1)
    t=Xp/speed[...,None]
    c,s=np.cos(3*phi),np.sin(3*phi)
    co,si=np.cos(2*phi),np.sin(2*phi)
    e1=np.stack([c*co,c*si,s],axis=-1)  # global torus-surface normal
    e2=np.cross(t,e1)
    de1=np.stack([-3*s*co-2*c*si,-3*s*si+2*c*co,3*c],axis=-1)
    frame_connection=np.sum(de1*e2,axis=-1)/speed
    # dt/ds = [Xpp - (Xpp.t)t]/speed^2
    ks=(Xpp-np.sum(Xpp*t,axis=-1)[...,None]*t)/speed[...,None]**2
    kappa1=np.sum(ks*e1,axis=-1)
    kappa2=np.sum(ks*e2,axis=-1)
    kappa=np.linalg.norm(ks,axis=-1)
    return X,t,e1,e2,frame_connection,kappa1,kappa2,kappa,speed


def bump(u):
    u=np.asarray(u)
    ans=np.zeros_like(u, dtype=float)
    mask=(u>=0)&(u<1)
    ans[mask]=np.exp(-BUMP_B/(1-u[mask]**2))
    return ans

BUMP_I=quad(lambda v:float(bump(np.array([v]))[0]),0,1,epsabs=1e-13,epsrel=1e-13)[0]

def fprime(eta):
    return bump(np.asarray(eta)/ETA_C)/(ETA_C*BUMP_I)


def curve_length():
    return quad(lambda p:float(np.linalg.norm(xder(p)[1])),0,2*np.pi,epsabs=1e-12,epsrel=1e-12)[0]


def curvature_max():
    ps=np.linspace(0,2*np.pi,6001,endpoint=False)
    ka=geom(ps)[7]
    ind=np.argmax(ka)
    step=2*np.pi/6001
    opt=minimize_scalar(lambda p:-float(geom(np.array([p]))[7][0]),bounds=(ps[ind]-2*step,ps[ind]+2*step),method='bounded',options={'xatol':1e-14})
    return float(-opt.fun),float(opt.x%(2*np.pi))


def doublecritical_antipodal():
    ps=np.linspace(0,2*np.pi,41,endpoint=False)
    A,V,_=xder(ps);B,W,_=xder(ps+np.pi)
    D=A-B
    return {
        'max_distance_deviation_from_2alpha':float(np.max(np.abs(np.linalg.norm(D,axis=1)-2*A_TORUS))),
        'max_orthogonality_residual':float(max(np.max(np.abs(np.sum(D*V,axis=1))),np.max(np.abs(np.sum(D*W,axis=1))))),
        'upper_bound_reach':float(A_TORUS*R0),
        'global_completeness_certified':False,
    }


def gauss_invariants(ns=512, delta=0.075):
    p=2*np.pi*np.arange(ns)/ns
    X,t,e1,e2,omega,_,_,_,speed=geom(p)
    dp=2*np.pi/ns
    Y=X+delta*e1
    k=np.fft.fftfreq(ns,d=1/ns)
    Yp=np.fft.ifft(1j*k[:,None]*np.fft.fft(Y,axis=0),axis=0).real
    Xp=t*speed[:,None]
    wr=lk=0.0
    for i in range(ns):
        dx=X[i]-X
        d=np.linalg.norm(dx,axis=1)
        d[i]=np.inf
        wr+=np.sum(np.einsum('ij,ij->i',np.cross(Xp[i],Xp),dx)/d**3)
        dy=X[i]-Y
        dn=np.linalg.norm(dy,axis=1)
        lk+=np.sum(np.einsum('ij,ij->i',np.cross(Xp[i],Yp),dy)/dn**3)
    wr*=dp**2/(4*np.pi);lk*=dp**2/(4*np.pi)
    tw=np.sum(omega*speed)*dp/(2*np.pi)
    return {'n':ns,'writhe':float(wr),'frame_twist':float(tw),'writhe_plus_twist':float(wr+tw),'gauss_linking':float(lk),'closure_error':float((wr+tw)-lk)}


def cross_section_flux(phi, L0, q, ngauss=96, ntheta=72):
    # Numeric flux integral over a geometry cross-section, using Cartesian vector field.
    xg,wg=leggauss(ngauss)
    eta=(xg+1)/2;wg=wg/2
    theta=2*np.pi*np.arange(ntheta)/ntheta
    rr=A_CORE*np.sqrt(eta[:,None]);ang=theta[None,:]
    y1=rr*np.cos(ang);y2=rr*np.sin(ang)
    _,t,e1,e2,frame,k1,k2,_,_=geom(np.array([phi]))
    t,e1,e2=t[0],e1[0],e2[0]
    h=1-k1[0]*y1-k2[0]*y2
    A=GAMMA/(np.pi*A_CORE**2)*fprime(eta)[:,None]
    omega=A[...,None]*t+(A*(frame[0]+2*np.pi*q/L0)/h)[...,None]*(-y2[...,None]*e1+y1[...,None]*e2)
    dot=np.einsum('ijk,k->ij',omega,t)
    # dA=r dr dtheta = a^2/2 d eta d theta
    return float(np.sum(dot * wg[:,None])*(A_CORE**2/2)*(2*np.pi/ntheta))


def pointwise_divergence_check(L0,q):
    """Independent real-space centered derivatives at smooth interior points.

    A local Taylor truncation test, not a 3D discretization certificate.
    """
    samplep=2*np.pi*np.arange(8192)/8192
    kd=cKDTree(xder(samplep)[0])
    eye=np.eye(3)
    def field(x):
        _,ind=kd.query(x)
        phi=samplep[ind]
        for _ in range(8):
            xx,v,a=xder(phi)
            dx=x-xx
            res=np.dot(dx,v)
            den=-np.dot(v,v)+np.dot(dx,a)
            phi-=res/den
        xx,t,e1,e2,frame,k1,k2,_,_=geom(np.array([phi]))
        dx=x-xx[0]
        y1=float(np.dot(dx,e1[0]));y2=float(np.dot(dx,e2[0]))
        eta=(y1*y1+y2*y2)/A_CORE**2
        if eta>=ETA_C:return np.zeros(3)
        h=1-k1[0]*y1-k2[0]*y2
        amp=GAMMA/(np.pi*A_CORE**2)*float(fprime(np.array([eta]))[0])
        return amp*t[0]+(amp*(frame[0]+2*np.pi*q/L0)/h)*(-y2*e1[0]+y1*e2[0])
    ps=[.2,1.1,2.3,4.1,5.7]
    rows=[]
    for phi in ps:
        xx,t,e1,e2,*_=geom(np.array([phi]))
        x=xx[0]+.07*e1[0]+.11*e2[0]
        for step in (1e-3,1e-4,1e-5):
            div=sum((field(x+step*eye[k])[k]-field(x-step*eye[k])[k])/(2*step) for k in range(3))
            rows.append({'phi':phi,'step':step,'divergence':float(div),'dimensionless':float(div*L0**3/GAMMA)})
    return rows


def make_cartesian_grid(n,L0,q,box=4.0,samples=4096):
    dx=box/n
    coords=(np.arange(n)+0.5)*dx-box/2
    # nearest sample along centerline; refinement minimizes distance to smooth curve
    sample_p=2*np.pi*np.arange(samples)/samples
    Xs=xder(sample_p)[0]
    tree=cKDTree(Xs)
    out=np.zeros((3,n,n,n),dtype=np.float64)
    ygrid,zgrid=np.meshgrid(coords,coords,indexing='ij')
    for i,x in enumerate(coords):
        points=np.column_stack((np.full(n*n,x),ygrid.ravel(),zgrid.ravel()))
        distances,idx=tree.query(points,workers=1)
        subset=np.nonzero(distances<A_CORE+box/samples*.1)[0]
        if len(subset)==0:continue
        pp=sample_p[idx[subset]].copy()
        pts=points[subset]
        for j in range(8):
            xx,v,a=xder(pp)
            diff=pts-xx
            f=np.einsum('ij,ij->i',diff,v)
            fp=-np.einsum('ij,ij->i',v,v)+np.einsum('ij,ij->i',diff,a)
            pp=pp-np.clip(f/fp,-.04,.04)
        xx,t,e1,e2,frame,k1,k2,_,_=geom(pp)
        dd=pts-xx
        y1=np.einsum('ij,ij->i',dd,e1)
        y2=np.einsum('ij,ij->i',dd,e2)
        eta=(y1**2+y2**2)/A_CORE**2
        mask=eta<ETA_C
        if not np.any(mask):continue
        ii=subset[mask]
        y1=y1[mask];y2=y2[mask];eta=eta[mask]
        h=1-k1[mask]*y1-k2[mask]*y2
        amp=GAMMA/(np.pi*A_CORE**2)*fprime(eta)
        w=amp[:,None]*t[mask]+(amp*(frame[mask]+2*np.pi*q/L0)/h)[:,None]*(-y2[:,None]*e1[mask]+y1[:,None]*e2[mask])
        out[:,i,ii//n,ii%n]=w.T
    return out,dx


def spectral_divergence(w,dx,L0):
    n=w.shape[1]
    kv=2*np.pi*sfft.fftfreq(n,dx)
    wk=sfft.fftn(w,axes=(1,2,3),workers=2)
    div_hat=1j*(kv[:,None,None]*wk[0]+kv[None,:,None]*wk[1]+kv[None,None,:]*wk[2])
    div=sfft.ifftn(div_hat,workers=2).real
    fac=L0**3/abs(GAMMA)
    return {'max_Dstar':float(np.max(np.abs(div))*fac),'rms_Dstar':float(np.sqrt(np.mean(div**2))*fac),
            'discrete_flux_vorticity_integral':float(np.linalg.norm(np.sum(w,axis=(1,2,3))*dx**3))}


def helicity_discrete_free_space(w,dx):
    """Free-space sampled Biot-Savart convolution (2N zero padding).

    Trapezoidal/midpoint kernel evaluation is not exact singular-cell integration.
    No explicit smoothing is applied: K(0)=0 is the odd-kernel principal-value
    diagonal convention, whose truncation error must be measured by refinement.
    """
    n=w.shape[1]; nn=2*n;shape=(nn,nn,nn)
    inds=np.arange(nn,dtype=np.float64)
    rr=np.where(inds<n,inds,inds-nn)*dx
    rx=rr[:,None,None];ry=rr[None,:,None];rz=rr[None,None,:]
    rr2=rx**2+ry**2+rz**2
    inv=np.zeros(shape,dtype=np.float64)
    np.power(rr2,-1.5,out=inv,where=rr2>0)
    inv*=1/(4*np.pi)
    ks=[sfft.rfftn(comp*inv,workers=2) for comp in (rx,ry,rz)]
    del inv,rr2
    omegas=[]
    for comp in w:
        a=np.zeros(shape,dtype=np.float64)
        a[:n,:n,:n]=comp
        omegas.append(sfft.rfftn(a,workers=2))
        del a
    h=0.0
    for comp,(a,b,c,d) in enumerate(((1,2,2,1),(2,0,0,2),(0,1,1,0))):
        uhat=omegas[a]*ks[b]-omegas[c]*ks[d]
        u=sfft.irfftn(uhat,s=shape,workers=2)[:n,:n,:n]
        h+=float(np.sum(u*w[comp]))
        del uhat,u
    return h*(dx**6) # u=dx^3 integral; helicity=dx^3 sum


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--grids',type=int,nargs='+',default=[64,96])
    ap.add_argument('--q',type=float,default=0.0)
    ap.add_argument('--box',type=float,default=4.0)
    ap.add_argument('--output',type=str,default='Gate1_Trefoil_Independent_v0.1.0-outputs/results.json')
    args=ap.parse_args()
    t0=time.time()
    L0=curve_length()
    km,at=curvature_max()
    geom_checks={'L0':L0,'kappa_max':km,'phi_curvature_max':at,'local_curvature_radius_min':1/km,
        'antipodal_family':doublecritical_antipodal(),'core_radius':A_CORE,
        'core_radius_vs_proven_reach_upper_bound':A_CORE/A_TORUS,
        'actual_reach_certified':False}
    ginv=[gauss_invariants(ns) for ns in (256,512,1024)]
    flux=[cross_section_flux(float(p),L0,args.q) for p in np.linspace(0,2*np.pi,9,endpoint=False)]
    results={'status':'NUMERIC_PREQUALIFICATION_NOT_CERTIFIED','constants':'dimensionless only, no SST constants',
        'parameters':{'R0':R0,'torus_minor_to_major':A_TORUS,'Gamma0':GAMMA,'core_radius':A_CORE,'eta_c':ETA_C,'bump_b':BUMP_B,'q':args.q,'box':args.box},
        'geometry':geom_checks,'gauss_invariants':ginv,'cross_section_circulations':flux,
        'cross_section_max_relative_error':float(np.max(np.abs(np.array(flux)/GAMMA-1))),
        'pointwise_divergence':pointwise_divergence_check(L0,args.q),
        'grids':[],'interpretation':{'helicity_reference':-6+args.q,
             'helicity_reference_note':'Uses torus-surface framing; numerically Gauss Lk=-6. q added in this framing.',
             'no_claimed_reach_certificate':True,'no_equilibrium_or_stability_result':True}}
    for n in args.grids:
        print('Running 3D field',n,'^3 ...',flush=True)
        w,dx=make_cartesian_grid(n,L0,args.q,box=args.box)
        diagnostics=spectral_divergence(w,dx,L0)
        print('  D*=',diagnostics['max_Dstar'],'RMS=',diagnostics['rms_Dstar'],flush=True)
        h=helicity_discrete_free_space(w,dx)
        diagnostics.update({'n':n,'dx':dx,'helicity_free_space_midpoint':float(h),
                            'helicity_reference':float(-6+args.q),
                            'helicity_absolute_error':float(h-(-6+args.q))})
        results['grids'].append(diagnostics)
        print('  helicity=',h,' ref=',-6+args.q,flush=True)
    results['duration_seconds']=time.time()-t0
    results['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    Path(args.output).parent.mkdir(parents=True,exist_ok=True)
    Path(args.output).write_text(json.dumps(results,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print('Wrote',args.output, 'elapsed:',results['duration_seconds'])

if __name__=='__main__':main()
