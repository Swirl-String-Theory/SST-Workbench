// src/module_sst.cpp
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <algorithm>

namespace py = pybind11;

// Forward declaration only!
void bind_ab_initio(py::module_& m);
void bind_canonical_constants(py::module_& m);
void bind_sst_master_equation(py::module_& m);
void bind_chronos_kelvin_transport(py::module_& m);
void bind_sst_tension_scales(py::module_& m);
void bind_delay_mode_selector(py::module_& m);
void bind_atomic_bridge_model(py::module_& m);
void bind_spectroscopic_gap(py::module_& m);
void bind_clock_field_eft(py::module_& m);
void bind_biot_savart(py::module_& m);
void bind_fluid_dynamics(py::module_ &m);
void bind_field_kernels(py::module_ &m);
void bind_field_ops(py::module_& m);
void bind_knot(py::module_& m);
void bind_frenet_helicity(py::module_& m);
void bind_magnus_integrator(py::module_& m);
void bind_multisector_fitter(py::module_& m);
void bind_timefield(py::module_& m);
void bind_hyperbolic_volume(py::module_& m);
void bind_radiation_flow(py::module_& m);
void bind_swirl_field(py::module_& m);
void bind_thermo_dynamics(py::module_& m);
void bind_time_evolution(py::module_& m);
void bind_vortex_ring(py::module_& m);
void bind_vorticity_dynamics(py::module_& m);
void bind_sst_gravity(py::module_& m);
void bind_sst_integrator(py::module_& m);
void bind_extensions(py::module_& m);
void bind_trefoil_operator(py::module_& m);
void bind_resolved_tube_geometry(py::module_& m);


// Pip/setuptools wheels use SSTcore._native; CMake builds keep the sstcore module name.
#ifdef SSTCORE_PYBIND11_NATIVE_SUBMODULE
PYBIND11_MODULE(_native, m) {
#else
PYBIND11_MODULE(sstcore, m) {
#endif
  m.doc() = "SSTcore Bindings";
  bind_ab_initio(m);
  bind_canonical_constants(m);
  bind_sst_master_equation(m);
  bind_chronos_kelvin_transport(m);
  bind_sst_tension_scales(m);
  bind_delay_mode_selector(m);
  bind_atomic_bridge_model(m);
  bind_spectroscopic_gap(m);
  bind_clock_field_eft(m);
  bind_biot_savart(m);
  bind_fluid_dynamics(m);
  bind_field_kernels(m);
  bind_field_ops(m);
  bind_knot(m);
  bind_frenet_helicity(m);
  bind_magnus_integrator(m);
  bind_multisector_fitter(m);
  bind_timefield(m);
  bind_hyperbolic_volume(m);
  bind_radiation_flow(m);
  bind_swirl_field(m);
  bind_thermo_dynamics(m);
  bind_time_evolution(m);
  bind_vortex_ring(m);
  bind_vorticity_dynamics(m);
  bind_sst_gravity(m);
  bind_sst_integrator(m);
  bind_extensions(m);
  bind_trefoil_operator(m);
  bind_resolved_tube_geometry(m);
 // module-wide listing utility
    m.def(
        "list_bindings",
        [m](const py::object &pattern /* = None */,
          const bool include_private /* = false */) {
            const auto names = m.attr("__dir__")().cast<py::list>();
            py::list funcs, classes, attrs;

            const bool use_pat = !pattern.is_none();
            std::string pat = use_pat ? std::string(py::str(pattern)) : std::string();
            std::ranges::transform(pat, pat.begin(), ::tolower);

            for (const py::handle h : names) {
                std::string name = py::str(h);
                if (!include_private && !name.empty() && name[0] == '_') continue;
                if (name == "list_bindings") continue;

                std::string namelow = name;
                if (use_pat) {
                    std::ranges::transform(namelow, namelow.begin(), ::tolower);
                    if (namelow.find(pat) == std::string::npos) continue;
                }

                if (const py::object obj = m.attr(name.c_str());
                    py::isinstance<py::function>(obj)) {
                    funcs.append(py::str(name));
                } else if (py::isinstance<py::type>(obj)) {
                    classes.append(py::str(name));
                } else {
                    attrs.append(py::str(name));
                }
            }

            // also populate __all__ for convenience (public functions + classes)
            py::list all;
            for (auto&& f : funcs) all.append(f);
            for (auto&& c : classes) all.append(c);
            m.attr("__all__") = all;

            py::dict counts;
            counts["functions"]  = py::len(funcs);
            counts["classes"]    = py::len(classes);
            counts["attributes"] = py::len(attrs);

            py::dict out;
            out["functions"]  = funcs;
            out["classes"]    = classes;
            out["attributes"] = attrs;
            out["counts"]     = counts;
            return out;
        },
        py::arg("pattern") = py::none(),
        py::arg("include_private") = false,
        R"pbdoc(
        Return a dictionary of exported names in this module.

        Args:
          pattern (str|None): optional case-insensitive substring filter.
          include_private (bool): include names beginning with '_' if True.

        Returns:
          dict with keys: 'functions', 'classes', 'attributes', and 'counts'.
        Also sets module __all__ = functions + classes (public names).
        )pbdoc");
}
