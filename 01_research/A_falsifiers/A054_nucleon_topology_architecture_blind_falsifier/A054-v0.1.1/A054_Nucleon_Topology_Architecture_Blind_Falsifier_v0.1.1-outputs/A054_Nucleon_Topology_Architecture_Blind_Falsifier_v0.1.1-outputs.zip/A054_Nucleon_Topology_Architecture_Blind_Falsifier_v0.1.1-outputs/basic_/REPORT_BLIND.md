# A054 v0.1.1 — BLIND report

No semantic identity table was available to this stage.

Scientific-ready full factorial tournament: **False**
Backend: **numpy_reference**

| anonymous | numerical status | polarity gate | rel-eq | cross-stab | sep curvature | shape drift |
|---|---|---|---:|---:|---:|---:|
| `CAND_211234f1dc51a31e` | NUMERICALLY_QUALIFIED | True | 0.527125 | 0.370023 | -3.78653e-29 | 0.015470222131185814 |
| `CAND_8b3d2827d2f3a6cc` | NUMERICALLY_QUALIFIED | False | 0.526321 | 0.00915196 | -7.10543e-15 | 0.0020872670816337044 |
| `CAND_9273176d04caec0e` | NUMERICALLY_QUALIFIED | True | 0.49763 | 0.433481 | -1.98522e-08 | 0.013960358539274423 |

`INCONCLUSIVE_NUMERICAL` is not a physical FAIL. `NUMERICALLY_QUALIFIED` is not a particle assignment.
Reveal must not recompute blind observables.
