# Route B BEMv11 length provenance

BEMv11 audits the length bottleneck isolated by BEMv10.

It computes the arclength directly from Brian Gilbert Fourier coefficients:

\[
x(t)=\sum_I A_I\cos(It)+B_I\sin(It),
\]

\[
L=\int_0^{2\pi}\|x'(t)\|\,dt.
\]

No observed alpha is used.

## Outputs

```text
length_convergence.csv
length_extrapolation_fit.csv
alpha_leading_length_audit.csv
length_provenance_report.md
run_config_v11.json
```

## Fast run

```bash
python routeB_RT_bem_v11_length_provenance.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v11_length \
  --ideal-xml-knot-ids 0:1:1,3:1:1,4:1:1 \
  --samples-list 1000,2000,4000,8000,16000,32000
```

## Larger run

```bash
python routeB_RT_bem_v11_length_provenance.py \
  --ideal ideal.txt \
  --outdir outputs_routeB_BEM_v11_length_hi \
  --ideal-xml-knot-ids 0:1:1,3:1:1,4:1:1,5:1:1,5:1:2 \
  --samples-list 4000,8000,16000,32000,64000,128000
```

## Meaning

BEMv11 checks whether the leading Route-B length scale

\[
\alpha^{-1}_{\rm lead}=\frac{8\pi}{3}L
\]

is provenance-stable.

This is not a final derivation. It is the length-scale certification gate.
