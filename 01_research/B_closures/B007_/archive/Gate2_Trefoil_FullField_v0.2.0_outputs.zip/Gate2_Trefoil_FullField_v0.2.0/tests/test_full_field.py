"""Software/regression tests, NOT physical certification."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
import pytest
from full_field import ShearOrbit, AnalyticSeed, SearchGrid, fd_gauss_newton, shear_profile
from verify_independent import curl2, stationary_residual
from gate2 import curl4

def params(modes=3):
    return np.linspace(-.2,.3,3*modes)

def test_inverse_identity():
    rng=np.random.default_rng(5);pts=rng.normal(size=(40,3))
    orbit=ShearOrbit(modes=3);p=params()
    dest=orbit.forward(pts,p)
    src,_=orbit.inverse_and_gradient(dest,p)
    assert np.max(np.abs(src-pts))<1e-12

def test_volume_preservation():
    pts=np.random.default_rng(3).normal(size=(22,3))
    assert np.max(np.abs(np.linalg.det(ShearOrbit(modes=3).jacobian(pts,params()))-1))<1e-12

def test_numerical_jacobian():
    pts=np.random.default_rng(4).normal(size=(6,3));orbit=ShearOrbit(modes=4)
    pp=params(4);eps=1e-6;J=orbit.jacobian(pts,pp)
    j_fd=np.zeros_like(J)
    for axis in range(3):
        shift=np.zeros(3);shift[axis]=eps
        j_fd[:,:,axis]=(orbit.forward(pts+shift,pp)-orbit.forward(pts-shift,pp))/(2*eps)
    assert np.max(np.abs(J-j_fd))<1e-8

def test_piola_consistency():
    orbit=ShearOrbit(modes=4);p=params(4)
    src=np.random.default_rng(1).uniform(-1.6,1.6,size=(32,3))
    dest=orbit.forward(src,p)
    _,grad=orbit.inverse_and_gradient(dest,p)
    v=np.random.default_rng(2).normal(size=(32,3))
    assert np.max(np.abs(orbit.pushforward(v,grad)-np.einsum('nij,nj->ni',orbit.jacobian(src,p),v)))<1e-11

def test_seed_uses_fixed_q():
    w0=AnalyticSeed(0).field(np.array([[.95,.2,.1],[1.2,.0,.0]]))
    w1=AnalyticSeed(1).field(np.array([[.95,.2,.1],[1.2,.0,.0]]))
    assert np.all(np.isfinite(w0)) and np.all(np.isfinite(w1))
    assert AnalyticSeed(0).q==0 and AnalyticSeed(1).q==1

def test_identity_shear_exact():
    orbit=ShearOrbit(modes=3)
    pts=np.random.default_rng(11).uniform(-1.5,1.5,(64,3))
    pre,g=orbit.inverse_and_gradient(pts,np.zeros(9))
    vec=AnalyticSeed().field(pts)
    assert np.max(np.abs(pre-pts))<1e-14
    assert np.max(np.abs(orbit.pushforward(vec,g)-vec))<1e-14

def test_shear_derivatives():
    x=np.array([.12,.5,-.7]);y=np.array([-.2,.3,.9]);p=np.array([.2,-.4,.1,.3,.05]);h=1e-6
    _,a,b=shear_profile(x,y,p)
    fpx=shear_profile(x+h,y,p)[0];fmx=shear_profile(x-h,y,p)[0]
    fpy=shear_profile(x,y+h,p)[0];fmy=shear_profile(x,y-h,p)[0]
    assert np.max(np.abs(a-(fpx-fmx)/(2*h)))<1e-9
    assert np.max(np.abs(b-(fpy-fmy)/(2*h)))<1e-9

def test_material_flux_piola_identity():
    """Flux density transforms as (Jw).(cof(J)n) = w.n for det(J)=1."""
    seed=AnalyticSeed(0)
    phi=.71;X,t,e1,e2,*_=__import__('g1_seed').geom(np.array([phi]))
    rng=np.random.default_rng(15);rr=.16*np.sqrt(rng.random(32));theta=2*np.pi*rng.random(32)
    pts=X[0]+rr[:,None]*(np.cos(theta)[:,None]*e1[0]+np.sin(theta)[:,None]*e2[0])
    orbit=ShearOrbit(modes=3);p=params()
    J=orbit.jacobian(pts,p);w=seed.field(pts)
    pushed=np.einsum('nij,nj->ni',J,w)
    cofac_area=np.einsum('nji,j->ni',np.linalg.inv(J),t[0])
    assert np.max(np.abs(np.sum(pushed*cofac_area,axis=1)-np.sum(w*t[0],axis=1)))<1e-10

def test_known_stationary_field():
    n=16;dx=2*np.pi/n;x=(np.arange(n)+.5)*dx
    xx=x[:,None,None]; yy=x[None,:,None];zz=x[None,None,:]
    z=np.zeros((n,n,n));one=np.broadcast_to(np.sin(yy)*np.sin(zz),z.shape)
    u=np.stack([one,z,z]);omega=curl4(u,dx)
    r=stationary_residual(omega,u,dx,2*np.pi,0,0)
    assert np.max(np.abs(r))<1e-12

def test_nonstationary_control():
    n=16;dx=2*np.pi/n;x=(np.arange(n)+.5)*dx
    xx=x[:,None,None]; yy=x[None,:,None];zz=x[None,None,:]
    u=np.stack([np.broadcast_to(np.sin(xx)*np.cos(yy)*np.cos(zz),(n,)*3),
        np.broadcast_to(-np.cos(xx)*np.sin(yy)*np.cos(zz),(n,)*3),np.zeros((n,)*3)])
    w=curl4(u,dx)
    r=stationary_residual(w,u,dx,2*np.pi,0,0)
    assert np.sqrt(np.mean(r*r))>0.05

def test_nonzero_trefoil_residual():
    g=SearchGrid(n=16,modes=1)
    score,_=g.score(np.zeros(3))
    assert score['relative_residual']>.1
    assert np.isfinite(score['Rstar'])

def test_optimizer_no_false_pass():
    g=SearchGrid(n=16,modes=1)
    r=fd_gauss_newton(g,iterations=1)
    assert r['search_status']=='CANDIDATE_ONLY_NOT_A_CERTIFIED_EULER_ROOT'
    assert r['trace'][-1]['residual_rms']<=r['trace'][0]['residual_rms']+1e-15

def test_scalar_potential_linear():
    from verify_independent import ScalarPotentialVelocity
    n=12;g=ScalarPotentialVelocity(n,.3)
    rng=np.random.default_rng(30);v=rng.normal(size=(3,n,n,n))
    assert np.max(np.abs(g.velocity(2*v)-2*g.velocity(v)))<1e-12

def test_curl2_and_4_annihilate_constant():
    arr=np.broadcast_to(np.array([1.,2.,3.])[:,None,None,None],(3,8,8,8))
    assert np.max(np.abs(curl2(arr,.5)))==0
    assert np.max(np.abs(curl4(arr,.5)))<1e-14
