from __future__ import annotations
import numpy as np
from . import native

def periodic_sample(points: np.ndarray, u: np.ndarray) -> np.ndarray:
    n=len(points); x=(np.mod(u,1.0)*n)
    i=np.floor(x).astype(int)%n; t=(x-np.floor(x))[:,None]
    return points[i]*(1-t)+points[(i+1)%n]*t

def relabel_variants(points: np.ndarray, n: int, trials: int, seed: int):
    base=native.resample(points,n)
    yield "cyclic", np.roll(base, n//7, axis=0)
    yield "reverse", base[::-1].copy()
    rng=np.random.default_rng(seed)
    u=np.linspace(0.0,1.0,2*n,endpoint=False)
    for j in range(max(0,trials-2)):
        m=int(rng.integers(1,6)); a=float(rng.uniform(0.15,0.65)); ph=float(rng.uniform(0,2*np.pi))
        # q'(u)=1+a cos(...) > 0: monotone label warp.
        q=u + a*np.sin(2*np.pi*m*u+ph)/(2*np.pi*m)
        warped=periodic_sample(base,q)
        yield f"warp{j+1}_m{m}", native.resample(warped,n)

def spectral_tail_fraction(signal: np.ndarray, frac_start=0.75):
    x=np.asarray(signal,float)-np.mean(signal)
    p=np.abs(np.fft.rfft(x))**2
    if len(p)<=2 or p.sum()==0: return 0.0
    p[0]=0.0; start=max(1,int(frac_start*len(p)))
    return float(p[start:].sum()/max(p.sum(),1e-300))

def fourier_smooth(points: np.ndarray, n: int, k_cut: int) -> np.ndarray:
    """Uniform-arclength sample followed by a fixed periodic Fourier cutoff."""
    q=native.resample(points,int(n))
    k_cut=min(int(k_cut), int(n)//2-1)
    out=np.empty_like(q)
    for j in range(3):
        f=np.fft.rfft(q[:,j])
        if k_cut+1 < len(f): f[k_cut+1:]=0
        out[:,j]=np.fft.irfft(f,n=int(n))
    return out
