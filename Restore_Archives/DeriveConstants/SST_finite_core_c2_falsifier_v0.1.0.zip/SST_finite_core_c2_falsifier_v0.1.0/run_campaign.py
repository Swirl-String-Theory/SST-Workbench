#!/usr/bin/env python3
"""Run a preregistered resolution and model-branch robustness campaign."""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import yaml

from finite_core_falsifier.model import derive_coefficients


def spread(values: list[float]) -> float:
    mean = sum(values) / len(values)
    return (max(values) - min(values)) / abs(mean) if mean else float("inf")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/reference.yaml")
    ap.add_argument("--output", default="outputs/campaign_summary.json")
    args = ap.parse_args()
    root = Path(__file__).resolve().parent
    cfg_path = (root / args.config).resolve() if not Path(args.config).is_absolute() else Path(args.config)
    out_path = (root / args.output).resolve() if not Path(args.output).is_absolute() else Path(args.output)
    base = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    campaign = base.get("campaign", {})
    grids = [int(x) for x in campaign.get("grid_sizes", [96, 128, 160])]
    beta_values = [float(x) for x in campaign.get("beta_values", [0.75, 1.0, 1.25])]
    contact_scales = [float(x) for x in campaign.get("contact_scales", [1.0])]

    rows = []
    for n in grids:
        for beta in beta_values:
            for cs in contact_scales:
                cfg = copy.deepcopy(base)
                cfg["profile"]["n_grid"] = n
                cfg["profile"]["beta"] = beta
                cfg["contact"]["scale"] = cs
                res = derive_coefficients(cfg, cfg_path.parent)
                rows.append({
                    "n_grid": n,
                    "beta": beta,
                    "contact_scale": cs,
                    "w_perp": res["closure"]["w_perp"],
                    "sigma": res["closure"]["sigma"],
                    "c2": res["closure"]["c2"],
                    "profile_success": res["profile"]["success"],
                    "quality": res["derivation_quality"],
                })

    central_beta = min(beta_values, key=lambda x: abs(x - float(base["profile"].get("beta", 1.0))))
    central_contact = min(contact_scales, key=lambda x: abs(x - float(base["contact"].get("scale", 1.0))))
    grid_rows = [r for r in rows if r["beta"] == central_beta and r["contact_scale"] == central_contact]
    grid_sigma = [float(r["sigma"]) for r in grid_rows]
    all_sigma = [float(r["sigma"]) for r in rows]
    grid_tol = float(campaign.get("grid_relative_spread_max", 0.01))
    branch_tol = float(campaign.get("branch_relative_spread_max", 0.05))
    summary = {
        "rows": rows,
        "metrics": {
            "grid_sigma_relative_spread": spread(grid_sigma),
            "all_branch_sigma_relative_spread": spread(all_sigma),
        },
        "gates": {
            "grid_convergence": spread(grid_sigma) <= grid_tol,
            "branch_robustness": spread(all_sigma) <= branch_tol,
            "no_target_tuning": not bool(campaign.get("optimise_against_target", False)),
            "all_profile_solves": all(bool(r["profile_success"]) for r in rows),
        },
        "thresholds": {"grid_relative_spread_max": grid_tol, "branch_relative_spread_max": branch_tol},
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"output": str(out_path), "metrics": summary["metrics"], "gates": summary["gates"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
