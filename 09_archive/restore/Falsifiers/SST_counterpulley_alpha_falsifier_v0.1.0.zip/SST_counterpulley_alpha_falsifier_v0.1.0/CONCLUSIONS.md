# Conclusions — v0.1.0 reference fallback run

Status labels below refer only to the registered **simple counter-pulley energy mapping** in this package.

## [DERIVED NEGATIVE] Energy-ratio mapping misses the alpha correction by orders of magnitude

For the full Python reference run (`N=192`, `a/D=0.5`, `epsilon/D=0.05`):

\[
G_E = 0.8107078697247521,
\qquad
\delta_E = G_E-1 = -0.18929213027524794.
\]

The geometric alpha baseline requires only

\[
\delta_{\alpha,\mathrm{req}}
=
\frac{137.035999177}{(8\pi/3)(16.3714672385)}-1
=
-8.5513108744\times 10^{-4}.
\]

Thus the blind correction magnitude is about

\[
\frac{|\delta_E|}{|\delta_{\alpha,\mathrm{req}}|}
\approx 2.21\times 10^2
\]

times too large. The corresponding multiplicative candidate predicts

\[
\alpha_{\rm pred}^{-1}\approx 111.1912461,
\]

not \(137.035999177\).

## [SUPPORTED STRUCTURAL] First-order suppression survives

H8 passes in the reference run:

\[
\frac{|G'_{\rm odd}(0)|}{|G''_{\rm even}(0)|}
\approx 0.0804 < 0.10.
\]

This supports the narrower symmetry idea that a balanced counter-circulation construction can suppress an odd/linear perturbation. It does **not** rescue the energy mapping's magnitude.

## [DERIVED NEGATIVE] Nuisance sensitivity is too large

H7 fails because the correction varies strongly with both regularization scale and Bishop material-frame phase. A fundamental dimensionless coupling should not require selecting one favorable \(\epsilon/D\) or one arbitrary frame phase after seeing alpha.

## [DERIVED NEGATIVE] No in-core grid rescue

The predeclared scan

\[
a/D\in\{0.05,0.10,0.20,0.30,0.40,0.50\},
\qquad
\epsilon/D\in\{0.025,0.05,0.10,0.20\}
\]

contains zero points within 10% of the required alpha correction. H10 therefore fails without optimizer-based fitting.

## Scoped verdict

`FALSIFIED_OR_UNSUPPORTED_SIMPLE_COUNTERPULLEY_ENERGY_MAPPING`

This does **not** falsify every counter-vortex interpretation. The most logical next independent observable is a **relative phase/holonomy or helicity-transfer eigenvalue**, pre-registered before alpha comparison, rather than another rescaling of the interaction energy.
