# SST Canon v0.8.20 — Cantarella source-isolated patch series

## Doel

Deze serie verwerkt de drie aangeleverde bronnen als afzonderlijke, sequentiële subpatches. Iedere patch heeft een eigen wetenschappelijke scope en kan na toepassing afzonderlijk worden gecompileerd en beoordeeld.

De patchserie wijzigt:

- `SST_CANON-v0.8.20.tex`
- `SST_CANON-v0.8.20-research-track.tex`

Er wordt bewust **geen versienummer gewijzigd**. Dit voorkomt dat broninhoud, editiebeheer en een toekomstige integratie-/releasebeslissing in dezelfde patch worden vermengd.

## Vereiste basisbestanden

| Bestand | SHA-256 |
|---|---|
| `SST_CANON-v0.8.20.tex` | `748c53ffa89d181ac2a0d2dd38f27e575f05e2aac9465b0ee0673e6b8f40e698` |
| `SST_CANON-v0.8.20-research-track.tex` | `3d011afcf7fd1c837d0f1eeed24d16b7fcee17818d0ad71fb01bdb6ece9b96e3` |

Gebruik de patchserie niet stilzwijgend op een gelijknamig maar inhoudelijk ander bestand.

## Patchvolgorde

### 0001 — `helicity-forms.pdf`

Bestand: `patches/0001-helicity-forms-mapping-class.diff`

Voegt toe:

- canonieke mapping-class/framing guard voor heliciteit;
- Biot–Savart/Hodge-primitieve als onderdeel van de definitie;
- algemene fluxkwadratische sprongwet;
- solide-torusreductie `Delta H = j Phi^2`;
- SST-mapping `Delta H = j Gamma^2`;
- expliciete scheiding tussen ideale Chronos-evolutie en Kairos/mapping-class-overgang;
- research-track state metadata en numerieke `Gamma_0^2`-benchmark;
- bronvermelding in beide bibliografiecontexten.

### 0002 — `isoperimetricproblem.pdf`

Bestand: `patches/0002-isoperimetric-domain-spectrum.diff`

Voegt toe:

- projectie `BS_K = P_K BS`;
- equivalentie tussen maximale heliciteit-per-`L^2`, grootste Biot–Savart-eigenwaarde en kleinste positieve curl-eigenwaarde;
- expliciete guard: `V = omega` maakt de `L^2`-noemer enstrophy, niet kinetische energie;
- exacte eerste variatie en eigenwaarde-shape derivative;
- noodzakelijke boundarycondities voor een glad globaal optimum;
- niet-claim rond de singuliere extreme-apple/pinched-torus conjectuur;
- regularized, embedding-restricted SST research target;
- operationele domein-/spectrumsdiagnostiek;
- bronvermelding in beide bibliografiecontexten.

### 0003 — `ridgerunner.pdf`

Bestand: `patches/0003-ridgerunner-certification.diff`

Voegt toe:

- canonieke certificatieguard voor geïmporteerde ideal-knotdata;
- equilateral-mesh gate voor `CThi`/`Thi_p`;
- `MinRad`-stijfheidsschaal `2/ell^2`;
- onderscheid tussen polygonale en smooth ropelength upper bound;
- uitgebreide SSTcore-diagnostische tuple;
- KKT-residual, NNLS-conditioning en multistartprotocol;
- contactmaatconvergentie en precisieplafond;
- expliciete non-claim: first-order criticality is geen globale of dynamische stabiliteit;
- structurele reparatie van de samengevoegde dubbele `\subsubsection`-regel.

De bronvermelding `AshtonCantarellaPiatekRawdon2011` bestond al en wordt hergebruikt.

## Toepassen met Git

Voer dit uit vanuit de map waarin de twee doelbestanden staan:

```bash
git apply --check patches/0001-helicity-forms-mapping-class.diff
git apply patches/0001-helicity-forms-mapping-class.diff

git apply --check patches/0002-isoperimetric-domain-spectrum.diff
git apply patches/0002-isoperimetric-domain-spectrum.diff

git apply --check patches/0003-ridgerunner-certification.diff
git apply patches/0003-ridgerunner-certification.diff
```

Of gebruik `apply-patch-series.ps1` / `apply-patch-series.sh`.

## Validatie

De volgende controles zijn uitgevoerd op de exacte basisbestanden hierboven:

1. iedere patch slaagt afzonderlijk voor `git apply --check`;
2. iedere patch is sequentieel toegepast;
3. na iedere afzonderlijke patch compileert de volledige canon met:

```bash
pdflatex -draftmode -interaction=nonstopmode -halt-on-error SST_CANON-v0.8.20.tex
```

4. de volledig geïntegreerde versie compileert met `latexmk -pdf`;
5. er zijn geen nieuwe fatale LaTeX-fouten vastgesteld.

## Eindhashes na alle drie patches

| Bestand | SHA-256 |
|---|---|
| `SST_CANON-v0.8.20.tex` | `6efd3c9f0be84cdb907f1b232051189513b4910beb58cce55b03f62dee40d52f` |
| `SST_CANON-v0.8.20-research-track.tex` | `b5f0c9a6d61252d93d413455c19530a0efa9ce41bca069c2a3eea95270701c22` |

## Integriteitsregel

Pas de patches in de aangegeven volgorde toe. Bewerk een eerdere subpatch niet om een latere conclusie in te voegen; maak daarvoor een nieuwe, afzonderlijke patch. Hierdoor blijft de herkomst van iedere canonieke wijziging auditbaar.

## Pakketindeling

- `BASE/`: exacte, hash-gecontroleerde uitgangsbestanden;
- `patches/`: drie bron-geïsoleerde subpatches;
- `SST_CANON-...-cantarella-patched.tex`: volledig geïntegreerde referentie-uitvoer;
- `SOURCE_PROVENANCE.md`: cryptografische koppeling tussen ieder bronbestand en zijn subpatch;
- `SHA256SUMS.txt`: integriteitscontrole van basis, patches en eindbestanden.
