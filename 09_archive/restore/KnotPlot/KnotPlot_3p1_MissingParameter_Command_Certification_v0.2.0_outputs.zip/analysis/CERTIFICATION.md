# Missing-Parameter Command Certification

| parameter | status | unique i100 | max aligned RMS |
|---|---:|---:|---:|
| charge | **RUN_FAILED** | 0 | nan |
| hooke | **RUN_FAILED** | 0 | nan |
| power | **RUN_FAILED** | 0 | nan |
| timeincr | **RUN_FAILED** | 0 | nan |

Certified for extended stage: **NONE**

