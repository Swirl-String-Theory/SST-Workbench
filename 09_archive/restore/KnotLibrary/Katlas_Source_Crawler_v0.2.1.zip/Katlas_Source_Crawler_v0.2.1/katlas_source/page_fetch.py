from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request

from .downloader import USER_AGENT
from .aliases import sync_alias_page_snapshots


@dataclass
class PageFetchResult:
    katlas_id: str
    relpath: str
    url: str
    status: str
    bytes: int = 0
    sha256: str | None = None
    attempts: int = 0
    error: str | None = None


def raw_page_url(katlas_id: str) -> str:
    query = urllib.parse.urlencode({"title": katlas_id, "action": "raw"})
    return f"https://katlas.org/index.php?{query}"


def fetch_raw_page(
    katlas_id: str,
    dest: Path,
    delay_seconds: float = 0.8,
    retries: int = 3,
    backoff_seconds: float = 2.0,
) -> tuple[str, int, str]:
    """Fetch one MediaWiki raw source page and atomically persist it."""
    url = raw_page_url(katlas_id)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    last_error: Exception | None = None

    for attempt in range(1, max(1, retries) + 1):
        try:
            with urllib.request.urlopen(req, timeout=60) as response:
                data = response.read()
            text = data.decode("utf-8", errors="replace")
            encoded = text.encode("utf-8")
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_suffix(dest.suffix + ".tmp")
            tmp.write_bytes(encoded)
            tmp.replace(dest)
            sha256 = hashlib.sha256(encoded).hexdigest()
            time.sleep(max(0.0, delay_seconds))
            return url, attempt, sha256
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
            last_error = exc
            if attempt < max(1, retries):
                time.sleep(max(0.0, backoff_seconds) * (2 ** (attempt - 1)))

    assert last_error is not None
    raise last_error


def select_profile_targets(
    db_path: Path,
    max_auto_crossings: int,
    extra_ids: list[str],
) -> list[tuple[str, str]]:
    """Return unique (id, relpath) targets, low-crossing objects first."""
    con = sqlite3.connect(db_path)
    try:
        rows = con.execute(
            """
            SELECT id, relpath
            FROM objects
            WHERE crossings <= ?
            ORDER BY crossings, kind, id
            """,
            (max_auto_crossings,),
        ).fetchall()

        seen = {row[0] for row in rows}
        for katlas_id in extra_ids:
            if katlas_id in seen:
                continue
            row = con.execute(
                "SELECT id, relpath FROM objects WHERE id=?", (katlas_id,)
            ).fetchone()
            if row is not None:
                rows.append(row)
                seen.add(katlas_id)
        return rows
    finally:
        con.close()


def fetch_profile(
    *,
    db_path: Path,
    out_root: Path,
    profile_name: str,
    profile: dict,
    force: bool = False,
    delay_seconds: float | None = None,
) -> dict:
    max_auto = int(profile.get("max_auto_crossings", 7))
    extra_ids = list(profile.get("extra_ids", []))
    delay = float(profile.get("delay_seconds", 0.8) if delay_seconds is None else delay_seconds)
    retries = int(profile.get("retries", 3))
    backoff = float(profile.get("backoff_seconds", 2.0))

    targets = select_profile_targets(db_path, max_auto, extra_ids)
    present_ids = {katlas_id for katlas_id, _ in targets}
    missing_extra_ids = [x for x in extra_ids if x not in present_ids]
    results: list[PageFetchResult] = []

    for index, (katlas_id, relpath) in enumerate(targets, start=1):
        dest = out_root / relpath / "page.wikitext"
        url = raw_page_url(katlas_id)
        print(f"[fetch {index:04d}/{len(targets):04d}] {katlas_id}")

        if dest.exists() and not force:
            data = dest.read_bytes()
            results.append(PageFetchResult(
                katlas_id=katlas_id,
                relpath=str(dest.relative_to(out_root)),
                url=url,
                status="SKIPPED_EXISTS",
                bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest(),
                attempts=0,
            ))
            sync_alias_page_snapshots(db_path, out_root, katlas_id)
            continue

        try:
            fetched_url, attempts, sha256 = fetch_raw_page(
                katlas_id,
                dest,
                delay_seconds=delay,
                retries=retries,
                backoff_seconds=backoff,
            )
            results.append(PageFetchResult(
                katlas_id=katlas_id,
                relpath=str(dest.relative_to(out_root)),
                url=fetched_url,
                status="FETCHED",
                bytes=dest.stat().st_size,
                sha256=sha256,
                attempts=attempts,
            ))
            sync_alias_page_snapshots(db_path, out_root, katlas_id)
        except Exception as exc:  # keep batch resumable; report every failure
            results.append(PageFetchResult(
                katlas_id=katlas_id,
                relpath=str(dest.relative_to(out_root)),
                url=url,
                status="FAILED",
                attempts=retries,
                error=f"{type(exc).__name__}: {exc}",
            ))

    report = {
        "schema": "SST-KATLAS-PAGE-FETCH-REPORT-1.0",
        "profile": profile_name,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "max_auto_crossings": max_auto,
        "extra_ids_requested": extra_ids,
        "extra_ids_missing_from_catalog": missing_extra_ids,
        "target_count": len(targets),
        "fetched": sum(r.status == "FETCHED" for r in results),
        "skipped_existing": sum(r.status == "SKIPPED_EXISTS" for r in results),
        "failed": sum(r.status == "FAILED" for r in results),
        "results": [asdict(r) for r in results],
    }
    report_path = out_root / "_catalog" / f"PAGE_FETCH_{profile_name}_REPORT.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report
