# Observed Drive snapshot — 17 October 2026

67 A-family directories, 66 distinct A identifiers, 70 children including 3 files.
A059 has two distinct folders; no other duplicate is visible in this folder listing.
Missing numerical IDs must NOT be interpreted as deleted or never-created; this is a folder-level snapshot only.
This listing is not the live catalog_index.json and does not verify underlying source or science.

The CSV deliberately labels every folder NOT_REQUALIFIED regardless of historical PASS or FAIL.
Review leads refer to selected previously inspected files and do not assert current scientific status.
