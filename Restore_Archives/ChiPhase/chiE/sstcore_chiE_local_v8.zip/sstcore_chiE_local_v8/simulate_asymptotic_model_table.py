#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_core_model_ladder import (
    ASYMPTOTIC_MODEL_TABLE,
    TARGET_CHI_E,
    evaluate_asymptotic_model,
    rows_to_dicts,
    write_csv,
    write_json,
)

SCRIPT_DIR = Path(__file__).resolve().parent
EXPORT_DIR = SCRIPT_DIR / "exports"
EXPORT_DIR.mkdir(exist_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare Page-51 thin-ring model constants alpha/beta.")
    parser.add_argument("--lambda-min", type=float, default=1.0)
    parser.add_argument("--lambda-max", type=float, default=8.0)
    parser.add_argument("--lambda-count", type=int, default=33)
    args = parser.parse_args()

    t0 = time.time()
    rows = []
    for lam in np.linspace(args.lambda_min, args.lambda_max, args.lambda_count):
        for spec in ASYMPTOTIC_MODEL_TABLE:
            rows.append(evaluate_asymptotic_model(spec, float(lam)))
    horn_rows = [evaluate_asymptotic_model(spec, 1.0) for spec in ASYMPTOTIC_MODEL_TABLE]
    best = min(rows, key=lambda r: abs(r.chi_E - TARGET_CHI_E))

    write_csv(EXPORT_DIR / "asymptotic_model_table_scan.csv", rows)
    write_csv(EXPORT_DIR / "asymptotic_model_table_horn_rows.csv", horn_rows)
    summary = {
        "run": "asymptotic_model_table",
        "status": "RESEARCH-TRACK / THIN-RING ASYMPTOTIC BENCHMARK / NOT CANONIZED",
        "warning": "The alpha/beta formulas are thin-ring asymptotics. Values at lambda=1 are horn extrapolations only.",
        "lambda_min": args.lambda_min,
        "lambda_max": args.lambda_max,
        "lambda_count": args.lambda_count,
        "target_chi_E": TARGET_CHI_E,
        "horn_rows": rows_to_dicts(horn_rows),
        "best_row_to_2pi": rows_to_dicts([best])[0],
        "elapsed_s": time.time() - t0,
    }
    write_json(EXPORT_DIR / "asymptotic_model_table_summary.json", summary)

    plt.figure(figsize=(10, 6))
    for spec in ASYMPTOTIC_MODEL_TABLE:
        subset = [r for r in rows if r.name == spec.name]
        plt.plot([r.lambda_ for r in subset], [r.chi_E for r in subset], marker="o", linewidth=1, label=spec.name)
    plt.axhline(TARGET_CHI_E, linestyle="--", label=r"target $2\pi$")
    plt.xlabel(r"$\lambda=R/a_0$")
    plt.ylabel(r"thin-ring $\chi_E$")
    plt.title("Thin-ring alpha/beta model table benchmark")
    plt.grid(True, alpha=0.35)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(EXPORT_DIR / "asymptotic_model_table_scan.png", dpi=180)
    plt.close()

    text_path = EXPORT_DIR / "asymptotic_model_table_run_results_summary.txt"
    with text_path.open("w", encoding="utf-8") as f:
        f.write("SST asymptotic alpha/beta model-table diagnostic\n")
        f.write("================================================\n")
        f.write(f"target 2*pi = {TARGET_CHI_E:.16e}\n\n")
        f.write("Horn extrapolation rows, lambda=1:\n")
        for r in horn_rows:
            f.write(f"{r.name:32s} alpha={r.alpha_E:.6g} beta={r.beta_V:.6g} chi_E={r.chi_E:.16e} residual={r.target_residual:.6e}\n")
        f.write("\nInterpretation:\n")
        f.write("These are classic thin-ring asymptotic constants. They organize the next tests but do not decide the horn limit.\n")
    print(f"[*] Wrote {text_path}")
    print(f"best model={best.name}, lambda={best.lambda_:.6g}, chi_E={best.chi_E:.12g}")


if __name__ == "__main__":
    main()
