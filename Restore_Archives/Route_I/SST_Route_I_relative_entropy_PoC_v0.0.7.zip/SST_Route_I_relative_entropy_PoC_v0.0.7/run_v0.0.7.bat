@echo off
python sst_route1_nonlinear_adjacency_phase_v0.0.7.py --output-dir output_v0.0.7
if errorlevel 1 exit /b 1
