# A075-v0.2.10 Ruban T(2,3) mathematical diagnostic

**Status: DEVELOPMENT_ONLY — PHYSICAL_STABILITY_UNRESOLVED.**

Source: A007 exact 77/500 trefoil and original A075-v0.2.9 equation-(9) reference (SHA256 checked).

Hypothesis: a relative equilibrium and a converged, gauge-correct spectrum can explain a quasi-stable interval near B0=0.154.

Method: fixed-R0 analytic torus, midpoint Biot-Savart, Fourier curvature, least-squares axial motion removal, small harmonic shape corrections.

| B0 | n | epsilon before | epsilon after | exploratory max Ritz Re |
|---:|---:|---:|---:|---:|
| 0.1520 | 128 | 0.056809964 | 0.052818420 | 21.042851242662483 |
| 0.1540 | 128 | 0.057091519 | 0.053301774 | 20.537386947347862 |
| 0.1560 | 128 | 0.057374468 | 0.053780934 | 20.049688252268112 |

**Conclusions:** Optimizer convergence is not equilibrium proof. Ritz values do not certify a physical growth rate; they omit full gauge and spectrum. Dynamics, time convergence, topology, and Euler finite-core remain NOT_RUN.

Reference: V. P. Ruban (2018), *Long-lived quantum vortex knots*, JETP Letters 107, 307–311, doi:10.1134/S0021364018050120.
