# Revealed summary

Freeze SHA-256: `560146f7bd1e8a2f06f9c0d0d480acffc982abbf8b13cf9cd519118cf04941de`

Freeze verified: **YES**
Private mapping commitment verified: **YES**

| Case | Split | Overall | Components | Parser | Source |
|---|---|---|---:|---|---|
| C57717B8A8715 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_0.1_final.txt` |
| C62A8C9398201 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_10.123_final.txt` |
| C09BBFEFE7D4C | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_10.1_final.txt` |
| C2FE5704AA6D4 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_3.1_final.txt` |
| CAD1A08A00BEF | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_4.1_final.txt` |
| CEA3F8ABAA184 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_5.1_final.txt` |
| CE08C014A484B | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_5.2_final.txt` |
| C9AAC9596F1FE | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_6.1_final.txt` |
| C2F07B518A7F5 | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_6.2_final.txt` |
| CEDBB1D4F22F9 | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_6.3_final.txt` |
| C6A632828FC78 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.1_final.txt` |
| C861C5E71DC9F | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.2_final.txt` |
| C5AA8FCD2A2E1 | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.3_final.txt` |
| C7A94F8B1AC42 | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_7.4_final.txt` |
| CE1469DFC89B3 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_8.17_final.txt` |
| CF30060BE5D6A | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_8.18_final.txt` |
| CB36CE8C6F686 | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_8.1_final.txt` |
| C4F15B42B9744 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_9.1_final.txt` |
| C30652BD72216 | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_9.2_final.txt` |
| C9659D9875009 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\knot_9.35_final.txt` |
| C76E5BE28CE3A | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_0.2.1_final.txt` |
| C09427B6B9073 | train | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_0.3.1_final.txt` |
| C45B673B9D6A3 | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_2.2.1_final.txt` |
| C8681D2AA6AA7 | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_4.2.1_final.txt` |
| C55C59CEF07C1 | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_5.2.1_final.txt` |
| C7DF2DCE9F812 | holdout | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.2.1_final.txt` |
| CDC3AEEA1F406 | train | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.3.1_final.txt` |
| C76E7ECC17022 | train | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.3.2_final.txt` |
| C94FB49A1897B | train | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_6.3.3_final.txt` |
| C3F1C7904D17F | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_7.2.5_final.txt` |
| CF9A2954269F4 | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_7.2.6_final.txt` |
| C585DEC498897 | holdout | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_7.2.8_final.txt` |
| C1D632D469A98 | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_8.2.1_final.txt` |
| C4B8AF2C7CFA9 | holdout | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_9.2.20_final.txt` |
| C492C152C99BC | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\link_9.2.40_final.txt` |
| C5CEAB505C9AC | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.11_final.txt` |
| CAF30CDE96863 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.3_final.txt` |
| C9856C9DBE03D | holdout | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.4_final.txt` |
| CE33C44063FAB | holdout | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.5_final.txt` |
| C1A70FF9667C3 | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.6_final.txt` |
| C5E6F4C838DF7 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.7_final.txt` |
| C8471D2D20540 | train | INDETERMINATE | 2 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.8_final.txt` |
| CA29C3302D138 | train | INDETERMINATE | 1 | single | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_2.9_final.txt` |
| C8D2F64BEC178 | train | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_3.3_final.txt` |
| C10A32427D5F4 | train | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_3.6_final.txt` |
| C09B47EE330B2 | holdout | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_3.9_final.txt` |
| C4637A0DD02DC | holdout | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_6.15_final.txt` |
| C100C20FBD702 | train | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_6.21_final.txt` |
| C55FF29E23A3E | holdout | INDETERMINATE | 3 | explicit_separators | `C:\workspace\projects\SST-Workbench\KnotPlot\knots\final\torus_6.9_final.txt` |
