#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_core_model_ladder import (
    TARGET_CHI_E,
    evaluate_surface_tension,
    rows_to_dicts,
    write_csv,
    write_json,
)

SCRIPT_DIR = Path(__file__).resolve().parent
EXPORT_DIR = SCRIPT_DIR / "exports"
EXPORT_DIR.mkdir(exist_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Surface-tension/interface term sweep: chi_sigma=2*pi^2*lambda*Sigma.")
    parser.add_argument("--lambda", dest="lambda_", type=float, default=1.0)
    parser.add_argument("--epsilon", type=float, default=1.0)
    parser.add_argument("--base-mode", default="hollow", choices=["hollow", "kinetic_only", "cavity_only"])
    parser.add_argument("--sigma-min", type=float, default=-1.0)
    parser.add_argument("--sigma-max", type=float, default=1.0)
    parser.add_argument("--sigma-count", type=int, default=81)
    parser.add_argument("--n", type=int, default=8192)
    args = parser.parse_args()

    t0 = time.time()
    rows = [
        evaluate_surface_tension(args.lambda_, args.epsilon, float(Sigma), args.base_mode, args.n)
        for Sigma in np.linspace(args.sigma_min, args.sigma_max, args.sigma_count)
    ]
    base = evaluate_surface_tension(args.lambda_, args.epsilon, 0.0, args.base_mode, args.n)
    best = min(rows, key=lambda r: abs(r.chi_E - TARGET_CHI_E))

    write_csv(EXPORT_DIR / "surface_tension_sweep.csv", rows)
    summary = {
        "run": "surface_tension_sweep",
        "status": "RESEARCH-TRACK / SURFACE-TENSION PARAMETER SWEEP / NOT CANONIZED",
        "warning": "Positive surface tension only raises chi_E. Negative required Sigma means an ordinary positive interface term cannot rescue the target.",
        "lambda_": args.lambda_,
        "epsilon": args.epsilon,
        "base_mode": args.base_mode,
        "target_chi_E": TARGET_CHI_E,
        "base_row_sigma_0": rows_to_dicts([base])[0],
        "best_row_to_2pi": rows_to_dicts([best])[0],
        "elapsed_s": time.time() - t0,
    }
    write_json(EXPORT_DIR / "surface_tension_sweep_summary.json", summary)

    sig = np.array([r.Sigma for r in rows])
    chi = np.array([r.chi_E for r in rows])
    plt.figure(figsize=(10, 6))
    plt.plot(sig, chi, marker="o", linewidth=1, label=fr"base={args.base_mode}")
    plt.axhline(TARGET_CHI_E, linestyle="--", label=r"target $2\pi$")
    plt.axvline(base.Sigma_required_for_2pi, linestyle=":", label=r"required $\Sigma$")
    plt.xlabel(r"$\Sigma=\sigma/(P_{\rm vac}a_0)$")
    plt.ylabel(r"$\chi_E$")
    plt.title("Surface-tension/interface sweep")
    plt.grid(True, alpha=0.35)
    plt.legend()
    plt.tight_layout()
    plt.savefig(EXPORT_DIR / "surface_tension_sweep.png", dpi=180)
    plt.close()

    text_path = EXPORT_DIR / "surface_tension_sweep_run_results_summary.txt"
    with text_path.open("w", encoding="utf-8") as f:
        f.write("SST surface-tension/interface sweep diagnostic\n")
        f.write("==============================================\n")
        f.write(f"base_mode                       = {args.base_mode}\n")
        f.write(f"lambda                          = {args.lambda_:.16e}\n")
        f.write(f"epsilon                         = {args.epsilon:.16e}\n")
        f.write(f"target 2*pi                     = {TARGET_CHI_E:.16e}\n\n")
        f.write("Sigma=0 base row:\n")
        f.write(f"chi_base                        = {base.chi_base:.16e}\n")
        f.write(f"Sigma_required_for_2pi          = {base.Sigma_required_for_2pi:.16e}\n")
        f.write(f"positive_sigma_can_hit_target   = {base.positive_sigma_can_hit_target}\n\n")
        f.write("Interpretation:\n")
        f.write("If Sigma_required is negative, positive surface tension worsens rather than fixes the target mismatch.\n")
    print(f"[*] Wrote {text_path}")
    print(f"base chi={base.chi_base:.12g}, Sigma_required={base.Sigma_required_for_2pi:.12g}")


if __name__ == "__main__":
    main()
