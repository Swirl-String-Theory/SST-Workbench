import numpy as np
#from numba import jit 
from scipy.integrate import * 
from variable import *
import matplotlib.pyplot as plt
import cupy as cp

global Wx1,Wx2,Wy1,Wy2

# calculate the gradient w.r.t x 
## need dx variable
def Dx(array):
    return np.gradient(array, axis=1)*(1/dx)

def Dx_gpu(array):
    return cp.gradient(array, axis=1)*(1/dx)

## calculate the gradient w.r.t y 
def Dy(array):
    return np.gradient(array, axis=0)*(1/dy)

def Dy_gpu(array):
    return cp.gradient(array, axis=0)*(1/dy)

## calculate the Laplacian
def Laplacian(array):
    return Dx(Dx(array))+Dy(Dy(array))

def Laplacian_gpu(array):
    return Dx_gpu(Dx_gpu(array))+Dy_gpu(Dy_gpu(array))

## implement interation along the designated axis
## x,y is needed additionaly as variables

#@jit(nopython=True)
def simp2d(array):
    return np.trapz(np.trapz(array, x), y)

# intergration of array along the linspace x by 1st Euler method 
def integration(array):
    h = x[1]-x[0]
    integral = np.zeros(len(array))
    for i in range(len(integral)-1):
        integral[i+1] = integral[i] + 0.5*(array[i]+array[i+1])*h
    return integral

# @jit(nopython=True)
def atan2(Y, X):
    atan22 = np.zeros(Y.shape, dtype=float)
    temp = X*Y
    atan22[np.where(temp>0)] = np.arctan(Y[np.where(temp>0)]/X[np.where(temp>0)]) - np.pi
    atan22[np.where(temp<=0)] = np.arctan(Y[np.where(temp<=0)]/X[np.where(temp<=0)]) + np.pi
    atan22[np.where(X>=0)] = np.arctan(Y[np.where(X>=0)]/X[np.where(X>=0)])
    return atan22

def atan2_GPU(Y, X):
    atan2 = cp.zeros(Y.shape, dtype="float32")
    temp = X*Y
    atan2[cp.where(temp>0)] = cp.arctan(Y[cp.where(temp>0)]/X[cp.where(temp>0)]) - np.pi
    atan2[cp.where(temp<=0)] = cp.arctan(Y[cp.where(temp<=0)]/X[cp.where(temp<=0)]) + np.pi
    atan2[cp.where(X>=0)] = cp.arctan(Y[cp.where(X>=0)]/X[cp.where(X>=0)])
    return atan2


## V_prime is V/mu - 1 normalized differnece between the obstacle height and chemical potential
## From the Thomas-Fermi approx, atom number n= |psi|^2 = (mu-V)/g, and using the relation mu=ng 
## in uniform Bose gas, we get the (1-V_hat)=|psi_hat|^2 in dimensionless form.abs
## Thomas _Fermi function is given the potential, xposition, yposition
## V_prime is needed as variable additionally.

def Thomas_Fermi(V_prime):
    psi0 = np.zeros((Ny, Nx), dtype=float)
    psi0[np.where(V_prime < 0)] = np.sqrt(-V_prime[np.where( V_prime < 0)])
    return psi0

## 
def Energy(psi):
    energy = simp2d(np.conjugate(psi)*(-0.5*Laplacian(psi)+(V_static+0.5*abs(psi)**2)*psi))
    return energy

## the force exerted on the whole Bose fluid is calculated as expectation value of the 
## F = -n_0*F_mu*|psi_hat|^2*grad_hat(V_hat) where F_mu=mu/xi
def Force(psi,V):
    return simp2d(Dx(V)*np.abs(psi)**2)

def Forcey(psi,V):
    return simp2d(Dy(V)*np.abs(psi)**2)


def velocity_field(phase): 
    v_x = Dx(phase)
    v_y = Dy(phase)
    phase_factor = 0.5
    phase_factor_2 = 1
    v_x[np.where(np.logical_and(v_x>=phase_factor*np.pi/dx,phase_factor_2*np.pi/dx>v_x))] -= np.pi/dx
    v_x[np.where(v_x>=phase_factor_2*np.pi/dx)]-=2*np.pi/dx

    v_x[np.where(np.logical_and(v_x<=-phase_factor*np.pi/dx,v_x>-phase_factor_2*np.pi/dx))] += np.pi/dx
    v_x[np.where(v_x<=-phase_factor_2*np.pi/dx)] += 2*np.pi/dx

    v_y[np.where(np.logical_and(v_y>=phase_factor*np.pi/dy,v_y<phase_factor_2*np.pi/dy))] -= np.pi/dy
    v_y[np.where(v_y>=phase_factor_2*np.pi/dy)] -= 2*np.pi/dy

    v_y[np.where(np.logical_and(v_y<=-phase_factor*np.pi/dy,v_y>-phase_factor_2*np.pi/dy))] += np.pi/dy
    v_y[np.where(v_y<=-phase_factor_2*np.pi/dy)] += 2*np.pi/dy
    return [v_x, v_y]


def velocity_field_gpu(phase, dx_value=None, dy_value=None):
    """Compute the phase-gradient velocity field on GPU with branch-cut fixes."""
    dx_use = dx if dx_value is None else dx_value
    dy_use = dy if dy_value is None else dy_value

    v_x = cp.gradient(phase, dx_use, axis=1)
    v_y = cp.gradient(phase, dy_use, axis=0)

    phase_factor = 0.5
    phase_factor_2 = 1.0
    pi = cp.pi

    mask = cp.logical_and(v_x >= phase_factor * pi / dx_use, v_x < phase_factor_2 * pi / dx_use)
    v_x = cp.where(mask, v_x - pi / dx_use, v_x)
    v_x = cp.where(v_x >= phase_factor_2 * pi / dx_use, v_x - 2 * pi / dx_use, v_x)

    mask = cp.logical_and(v_x <= -phase_factor * pi / dx_use, v_x > -phase_factor_2 * pi / dx_use)
    v_x = cp.where(mask, v_x + pi / dx_use, v_x)
    v_x = cp.where(v_x <= -phase_factor_2 * pi / dx_use, v_x + 2 * pi / dx_use, v_x)

    mask = cp.logical_and(v_y >= phase_factor * pi / dy_use, v_y < phase_factor_2 * pi / dy_use)
    v_y = cp.where(mask, v_y - pi / dy_use, v_y)
    v_y = cp.where(v_y >= phase_factor_2 * pi / dy_use, v_y - 2 * pi / dy_use, v_y)

    mask = cp.logical_and(v_y <= -phase_factor * pi / dy_use, v_y > -phase_factor_2 * pi / dy_use)
    v_y = cp.where(mask, v_y + pi / dy_use, v_y)
    v_y = cp.where(v_y <= -phase_factor_2 * pi / dy_use, v_y + 2 * pi / dy_use, v_y)

    return v_x, v_y




def decay(xx, yy):
    Gamma = np.zeros((Ny, Nx))
    gamma_x = gamma0*(2+np.tanh((xx-Wx1)/15)-np.tanh((xx-Wx2)/15))/2
    gamma_y = gamma0*(2+np.tanh((yy-Wy1)/15)-np.tanh((yy-Wy2)/15))/2
    
    Gamma[np.where(gamma_x>gamma_y)] += gamma_x[np.where(gamma_x>gamma_y)]
    Gamma[np.where(gamma_x<=gamma_y)] += gamma_y[np.where(gamma_x<=gamma_y)]
    return Gamma

Gamma = decay(xx, yy)


def Plot(array, tt, v,title, path_figures, shading='flat'):
    plt.figure(figsize=(7.3, 3.4))
    extent = [min(x), max(x), min(y), max(y)]
    plt.imshow(array, extent=extent)
    plt.colorbar()
    if tt<0:
        plt.title(f'{title} ( t={tt:.3f}, ground)')
    else:
        plt.title(f'{title} ( t={tt:.3f}')
    plt.tight_layout()
    if tt>=0:
        plt.savefig(f'{path_figures}/t={tt:.3f} v={v:.3f} {title}.png')
    plt.close()




if __name__ == "__main__":
    print(dx,dy)
