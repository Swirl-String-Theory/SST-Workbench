import importlib.util
import sys
import os
import inspect
# ✅ Get the script filename dynamically
import sys
import os
import inspect


# Set path if needed
sys.path.insert(0, os.path.abspath("."))
# ✅ Get the script filename dynamically
import os
script_name = os.path.splitext(os.path.basename(__file__))[0]

# Prefer pip / editable SSTcore; else legacy local .pyd (CMake still names it sstcore.*.pyd).
try:
    import SSTcore as sstcore
except ImportError:
    module_path = os.path.abspath("sstcore.cp312-win_amd64.pyd")
    module_name = "sstcore"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    sstcore = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sstcore)



# Generate Markdown documentation
lines = ["# SST Python Bindings (Auto-Generated API)\n"]

for name in dir(sstcore):
    if name.startswith("__"):
        continue
    obj = getattr(sstcore, name)
    if inspect.isclass(obj):
        lines.append(f"## Class: `{name}`\n")
        doc = inspect.getdoc(obj)
        if doc:
            lines.append(f"{doc}\n")
        for method_name in dir(obj):
            if method_name.startswith("_"):
                continue
            method = getattr(obj, method_name)
            if inspect.isfunction(method) or inspect.ismethod(method):
                lines.append(f"### Method: `{method_name}`\n")
                method_doc = inspect.getdoc(method)
                if method_doc:
                    lines.append(f"{method_doc}\n")
    elif inspect.isfunction(obj):
        lines.append(f"## Function: `{name}`\n")
        doc = inspect.getdoc(obj)
        if doc:
            lines.append(f"{doc}\n")

markdown_doc = "\n".join(lines)

# Save to file and return path
output_path = "../sstcore_api.md"
with open(output_path, "w", encoding="utf-8") as f:
    f.write(markdown_doc)

print(output_path)