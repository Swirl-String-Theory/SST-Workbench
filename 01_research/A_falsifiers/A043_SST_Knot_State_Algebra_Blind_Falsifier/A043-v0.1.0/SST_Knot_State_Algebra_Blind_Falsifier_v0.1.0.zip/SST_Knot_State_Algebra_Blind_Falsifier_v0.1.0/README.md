# SST Knot State Algebra Blind Falsifier v0.1.0 (A043 candidate)

First application of the reusable **SST Blind Multi-Library Falsifier Template**.

It asks two separate questions:

1. whether knot-complement/topological data produce an independently significant low-denominator dimensionless structure across a preregistered knot-family ladder; and
2. whether physical finite-core SST data produce a genuinely non-Abelian rotation algebra plus a `2π/4π` double-cover signature.

It does **not** assume that a knot label equals an LQG spin label, that an ordinary 3-D material frame is a spinor, or that any historical VAM particle assignment is correct.

## Data routes

- PKLSA: exhaustive broad geometry population (expected 2352 carriers in the full atlas).
- A002 SST Knot Library: preferred canonical ingestion/qualification layer.
- Fremlin, Gilbert, Katlas, KnotPlot/Ridgerunner: independent source-provenance replication lanes.
- SnapPy or an explicit CSV/JSON invariant table: independent dimensionless knot-complement invariant lane.
- Physical finite-core solver: external hashed NPZ/provider contract for G6.

For a formally sealed blind run, first point the guard at the separately packaged private denylist:

```cmd
set SST_PRIVATE_DENYLIST=C:\private\A043\denylist.txt
```

`run_all.cmd` and `run_all_extended.cmd` refuse to create the formal BLIND archive without this committed private guard.

Set the Workbench root if it differs from the canonical default:

```cmd
set SST_WORKBENCH_ROOT=C:\workspace\projects\SST-Workbench
```


## PKLSA adapter contract

G1 reads the atlas index `CANDIDATES_FULL.csv` and family map `SOURCE_MAP.json`, then expands every family bundle by `variant_index`. The scientific population is required to be exactly **49 families × 48 variants = 2352 carriers**. BASIC still validates the full atlas but screens a family-stratified subset (default 96); EXTENDED screens all 2352. A partially decodable family is `UNRESOLVED`, never silently collapsed to one carrier.

For cross-source certification, an optional blind-safe manifest can be supplied:

```cmd
run_02_basic.cmd --cross-source-manifest C:\path\to\cross_source_manifest.csv
```

Required manifest columns are `source_family,topology,source_path`. This is the preferred bridge when Gilbert/Katlas catalog records cannot be inferred safely from filenames alone.

## Scientific BASIC

```cmd
run_all.cmd
```

BASIC screens up to 96 PKLSA carriers to verify the full chain economically. It is a real blind campaign but not an exhaustive-atlas claim.

## EXTENDED / full PKLSA

```cmd
run_all_extended.cmd
```

This permits the full 2352-carrier G4 population.

## Intel Arc / oneAPI path

If `dpnp` is installed in an Intel oneAPI/SYCL-capable environment:

```cmd
run_gpu_intel.cmd
```

The GPU is used only after CPU↔GPU parity. Finalists are always CPU-certified.

## Invariant data

If SnapPy is installed it is used for the preregistered twist-family hyperbolic-volume records. Alternatively:

```cmd
run_basic_with_invariants.cmd C:\path	olind_safe_invariants.csv
```

CSV columns: `topology,invariant,value,provider`.

## Physical G6 contract

A finite-core provider exports an NPZ containing:

```text
generators      complex/real [3,n,n]
angles          float [k]          (optional but required for double-cover PASS)
state_overlap   complex [k]
```

Then run:

```cmd
run_core_algebra.cmd C:\path\to\physical_core_response.npz
```

## Reveal

The private reveal archive is separate. After the blind outputs have been sealed:

```cmd
run_reveal.cmd C:\private\private_reveal.json
```

The file must match `REVEAL_COMMITMENT.sha256`. The BLIND archive never contains private reveal material. For a full pre-run contamination scan, set `SST_PRIVATE_DENYLIST` to the separate private `denylist.txt`; only its SHA-256 commitment is public.

## Output convention

```text
./SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs/
../SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs_BLIND.zip
../SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs_REVEALED.zip
```
