# SST Katlas Source Crawler v0.2.1

Offline Knot Atlas source builder for knots and links through 12 crossings, with an SST/Fremlin-friendly alias layer.

## Primary source strategy

Bulk catalog data is imported from the official Knot Atlas RDF archives:

- `Rolfsen.rdf.gz` — Rolfsen knot table through 10 crossings;
- `Knots11.rdf.gz` — 11-crossing Hoste-Thistlethwaite knots;
- `Knots12.rdf.gz` — 12-crossing knots;
- `Links.rdf.gz` — Thistlethwaite links.

The RDF data remains canonical. Raw MediaWiki page source is fetched only for the curated profile or on demand.

## Canonical output layout

Canonical Katlas identifiers are never renamed or discarded.

```text
Katlas_Source/
  _source/
    Rolfsen.rdf.gz
    Knots11.rdf.gz
    Knots12.rdf.gz
    Links.rdf.gz
    SOURCE_MANIFEST.json

  _catalog/
    catalog.sqlite3
    catalog.jsonl
    catalog.csv
    aliases.json
    BUILD_REPORT.json
    VALIDATION_REPORT.json

  knots/
    03/3_1/
      katlas.json
      source.rdf.nt
      page.wikitext          # when fetched

    09/9_2/...

    10/
      rolfsen/0001-0050/10_1/...
      10_1/                  # friendly duplicate for a Fremlin favorite
        ALIAS.json
        katlas.json
        source.rdf.nt
        page.wikitext        # synchronized after fetch
      10_2/...
      10_124/...

    11/
      alternating/0351-0400/K11a367/...   # canonical Katlas storage
      alternating/0201-0250/K11a247/...   # canonical Katlas storage

      11_1/                  # friendly Fremlin duplicate -> K11a367
        ALIAS.json
        katlas.json
        source.rdf.nt
        page.wikitext
      11_2/                  # friendly Fremlin duplicate -> K11a247
        ALIAS.json
        katlas.json
        source.rdf.nt
        page.wikitext

    12/
      alternating/...
      nonalternating/...

  links/
    02/L2a1/...
    09/L9a1/...
    10/alternating/...
    10/nonalternating/...
    11/...
    12/...                   # only when present in official Links.rdf.gz
```

Crossings 0-9 remain shallow. Canonical 10-12 crossing objects stay sharded in groups of 50, but selected Fremlin favorites get additional direct convenience duplicates.

> Note: the crossing-first catalog path for the trefoil is `knots/03/3_1`. The friendly higher-crossing duplicates follow the same crossing-first convention: `knots/10/10_1`, `knots/11/11_1`, etc.

## Friendly alias rule

The friendly directory is a real copy, not a symlink or junction. This is intentional for Windows portability and offline transfer.

`ALIAS.json` records the resolution. For example:

```json
{
  "alias": "11_1",
  "target_id": "K11a367",
  "alias_relpath": "knots/11/11_1",
  "canonical_relpath": "knots/11/alternating/0351-0400/K11a367",
  "storage_mode": "duplicate"
}
```

The duplicated `katlas.json` keeps the canonical Katlas identity. The alias metadata never pretends that `11_1` is Katlas' native ID.

### Explicit Fremlin/11-crossing mapping

The user-provided `knots_ideal_favorites.txt` contains the favorite labels `11:1:1` and `11:1:2`. For convenient SST/Fremlin naming they resolve as:

```text
11_1  -> K11a367
11_2  -> K11a247
```

These mappings are deliberately documented because `K11a367` and `K11a247` are much harder to remember than `11_1` and `11_2`.

## Curated favorites imported from `knots_ideal_favorites.txt`

The package contains only an identity manifest in `curated/fremlin_favorites.json`; it does not redistribute the Fourier coefficients from the supplied source file.

Recognized favorite knots:

```text
3_1
4_1
5_1  5_2
6_1  6_2  6_3
7_1  7_2  7_4
8_1  8_3  8_9  8_12  8_17  8_19
9_1  9_2
10_1 10_2 10_124
11_1 11_2
```

Recognized favorite Katlas link IDs:

```text
L2a1 L4a1 L5a1 L6a1 L6a4 L6n1 L8a1
```

The default `sst_curated` page profile fetches every knot/link through 7 crossings automatically and adds the higher favorites:

```text
8_1 8_3 8_9 8_12 8_17 8_19
9_1 9_2
10_1 10_2 10_124
K11a367 K11a247
L8a1
```

Thus `11_1` and `11_2` are fetched from their actual Katlas pages and then copied into their friendly duplicate directories.

## One-click runs

Build the complete RDF catalog:

```bat
run_all.cmd
```

Build the catalog and also fetch all curated page snapshots:

```bat
run_all_curated.cmd
```

Fetch/update only the curated page layer:

```bat
run_fetch_curated.cmd
```

Force refetch:

```bat
run_fetch_curated.cmd --force
```

Existing page snapshots are skipped by default, so the operation is restart-safe.

## Individual lookup/fetch

Canonical IDs still work:

```bat
run_lookup.cmd K11a367
run_fetch_page.cmd K11a367
```

Friendly aliases also work:

```bat
run_lookup.cmd 11_1
run_lookup.cmd 11_2
run_fetch_page.cmd 11_1
run_fetch_page.cmd 11_2
```

For an alias, the CLI resolves the canonical Katlas target before fetching and then synchronizes `page.wikitext` back into the direct alias directory.

## Per-object files

Canonical object directories contain:

```text
katlas.json
source.rdf.nt
page.wikitext       # optional/fetched
```

Friendly duplicate directories additionally contain:

```text
ALIAS.json
```

`katlas.json` retains exact Katlas identity, presentations, invariant data, source archive and canonical page URL.

## Validation

`run_validate.cmd` checks both canonical objects and friendly aliases. Alias validation includes:

- target exists in the canonical SQLite catalog;
- alias directory exists;
- duplicated `katlas.json` exists;
- `ALIAS.json` is valid and resolves to the configured target;
- canonical target directory remains present.

## Tests

```bat
run_tests.cmd
```

This covers naming/sharding, RDF parsing, curated selection, direct 10-crossing duplicates, 11-crossing Fremlin-to-Katlas aliases, and page snapshot synchronization.

## Reproducibility

`_source/SOURCE_MANIFEST.json` records source URL, size, SHA-256, retrieval time, ETag and Last-Modified when provided by the server.

`_catalog/PAGE_FETCH_sst_curated_REPORT.json` records page target IDs, URL, fetch/skip/failure status, byte size, SHA-256 and attempt count.

The crawler never fabricates missing Katlas objects. Friendly aliases resolve only to an existing canonical Katlas object.
