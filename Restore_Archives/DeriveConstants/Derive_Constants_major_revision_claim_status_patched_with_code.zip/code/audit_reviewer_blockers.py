#!/usr/bin/env python3
"""
audit_reviewer_blockers.py

Numerical audit for reviewer-blocking points in the Derive_Constants package.

It computes:
  * the bare trefoil scale (8*pi/3)L_K,
  * the NLS shell factor [1 - 11/(48 L_K^2)],
  * the difference between E_p^NLS and the batch stationary point E_star,
  * whether the stationary point is pressure-selected,
  * whether far-field and phase certificates are internal consistency checks.

This script is deliberately conservative. It does not promote any result to
"first-principles derived"; it reports the strongest defensible label from the
available CSV outputs.
"""
from __future__ import annotations

import argparse, math, json, re
from pathlib import Path
import pandas as pd
import numpy as np

ALPHA_CODATA_2022 = 7.2973525643e-3

def read_csv(path: Path) -> pd.DataFrame | None:
    return pd.read_csv(path) if path.exists() else None

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default=".", help="Package root containing code/ and data/.")
    p.add_argument("--ropelength", type=float, default=16.371637)
    p.add_argument("--paper1-tex", default="Manuscripts/1_SST_constants_derivation_v8_paper1_derived_gate_model_answers.tex")
    p.add_argument("--outdir", default="outputs_reviewer_blocker_audit")
    args = p.parse_args()

    root = Path(args.root)
    outdir = root / args.outdir
    outdir.mkdir(parents=True, exist_ok=True)

    L = args.ropelength
    Ep0 = (16.0 * math.pi / 3.0) * L
    shell_factor = 1.0 - 11.0 / (48.0 * L * L)
    EpNLS = Ep0 * shell_factor
    eta = 1.0 / (4.0 * L)
    Xi = 1.0 + 3.0 * eta + eta * eta
    Eeff_from_Ep = EpNLS * (1.0 - math.pi * Xi / (4.0 * EpNLS * EpNLS))
    alpha_inv_from_Ep = Eeff_from_Ep / 2.0

    batch = read_csv(root / "code" / "batch_aggregate_stats.csv")
    controls = read_csv(root / "code" / "batch_controls.csv")

    E_star_mean = float(batch["E_star_mean"].iloc[0]) if batch is not None and "E_star_mean" in batch else np.nan
    E_star_std = float(batch["E_star_std"].iloc[0]) if batch is not None and "E_star_std" in batch else np.nan

    bem_only_status = "missing"
    if controls is not None and "pressure_mode" in controls and "status" in controls:
        bem = controls[controls["pressure_mode"].astype(str) == "none"]
        if len(bem):
            bem_only_status = "no_E0_derived" if not any(bem["status"].astype(str) == "E0_derived") else "unexpected_E0_derived"

    paper1_E0 = np.nan
    tex_path = root / args.paper1_tex
    if tex_path.exists():
        m = re.search(r"\\Et=([0-9.]+)", tex_path.read_text(encoding="utf-8", errors="replace"))
        if m:
            paper1_E0 = float(m.group(1))

    phase_cert = read_csv(root / "code" / "outputs_Kcell_phase_certificate" / "phase_stiffness_certificate.csv")
    far_cert = read_csv(root / "code" / "outputs_farfield_two_cell" / "alpha_farfield_certificate.csv")

    rows = [
        {"item": "bare_inverse_scale_(8pi/3)L", "value": (8.0 * math.pi / 3.0) * L, "status": "geometric_bare_scale"},
        {"item": "shell_factor_1_minus_11_over_48L2", "value": shell_factor, "status": "depends_on_11_over_48_gate"},
        {"item": "alpha_inverse_from_EpNLS_chain", "value": alpha_inv_from_Ep, "status": "closure_prediction"},
        {"item": "CODATA_alpha_inverse_comparison_only", "value": 1.0 / ALPHA_CODATA_2022, "status": "post_hoc_comparison_only"},
        {"item": "E_p_NLS", "value": EpNLS, "status": "analytic_pressure_scale"},
        {"item": "E_star_mean_batch", "value": E_star_mean, "status": "stationary_point"},
        {"item": "E_star_minus_EpNLS", "value": E_star_mean - EpNLS if np.isfinite(E_star_mean) else np.nan, "status": "BEM_compliance_shift"},
        {"item": "E_star_std", "value": E_star_std, "status": "batch_spread"},
        {"item": "BEM_only_control", "value": bem_only_status, "status": "must_be_no_E0_derived"},
        {"item": "Paper1_retrospective_E0", "value": paper1_E0, "status": "ledger_target_not_noncircular_route"},
    ]

    flags = []
    if bem_only_status == "no_E0_derived":
        flags.append("BEM-only control confirms the BEM term does not independently select E0.")
    if np.isfinite(E_star_mean):
        flags.append("E_star is close to E_p^NLS; classify the result as pressure-selected with BEM compliance shift.")
    flags.append("Far-field and phase certificates are internal identities unless Lambda_phi is measured independently.")
    flags.append("Strongest label: closure-derived / derived within the minimal finite-cell shell model, not first-principles QED alpha.")

    pd.DataFrame(rows).to_csv(outdir / "reviewer_blocker_numeric_audit.csv", index=False)
    (outdir / "reviewer_blocker_summary.md").write_text(
        "# Reviewer blocker audit\n\n" + "\n".join(f"- {x}" for x in flags) + "\n",
        encoding="utf-8"
    )

    print(pd.DataFrame(rows).to_string(index=False))
    print("\n" + "\n".join(flags))
    print(f"\nWrote {outdir/'reviewer_blocker_numeric_audit.csv'}")
    print(f"Wrote {outdir/'reviewer_blocker_summary.md'}")

if __name__ == "__main__":
    main()
