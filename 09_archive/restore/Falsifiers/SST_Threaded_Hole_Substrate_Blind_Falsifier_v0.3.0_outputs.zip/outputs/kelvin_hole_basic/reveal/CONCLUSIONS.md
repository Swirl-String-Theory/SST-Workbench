# SST Threaded-Hole Substrate v0.3.0 — post-seal reveal

Seal verification: **PASS**.

## Self-confinement
- Carrier-clustered verdict: **INDETERMINATE** — active carriers 0, null carriers 0.

## Pressure / gravity
- Central pressure: **INDETERMINATE_PRESSURE_DEFICIT**.
- Even quadratic pressure law: **INDETERMINATE_PRESSURE_LAW**.
- Source monopole: **INDETERMINATE_OR_WRONG_MONOPOLE**.
- Free exponent: **INDETERMINATE_FREE_EXPONENT**, median ν=nan.
- Exponent convergence: **NEEDS_OR_FAILS_FAR_FIELD_CONVERGENCE**; monopole convergence: **NEEDS_OR_FAILS_MONOPOLE_CONVERGENCE**.
- Combined: **GRAVITY_CLOSURE_NOT_SUPPORTED**.

## Thread focusing
- **INDETERMINATE_THREAD_FOCUSING** from active versus passive zero-circulation tracer threads.

## Confirmatory stability
- **CONFIRMATORY_NOT_ESTABLISHED** across 0 preregistered pairs.

## Stability discovery
- 0 carrier minima reported as discovery only.

## Triple gear
- Geometric marker-invariant phase proxy available for 0 conditions; active score lower in 0. No gear ratio was supplied.

Zero-circulation ghost threads are excluded from contact and CFL gates. v0.3.0 additionally tests whether the central hole is a persistent Lagrangian transport structure rather than a visual centerline gap.

## Kelvin--M'Farlane central-hole dynamics
- **VISUAL_HOLE_ONLY_WITHIN_TESTED_MODEL_AND_HORIZON**.
- Detailed post-seal results: `HOLE_REVEAL_SUMMARY.json`, `hole_revealed_pairs.csv`, `HOLE_CONCLUSIONS.md`.
