LIST {
	{ < n300c_rr_050k_e.0.vect }
	{ < n300c_rr_050k_e.0.struts.vect }
	{ < n300c_rr_050k_e.0.dlen.vect }
	{ < n300c_rr_050k_e.0.dVdt.vect }
}
