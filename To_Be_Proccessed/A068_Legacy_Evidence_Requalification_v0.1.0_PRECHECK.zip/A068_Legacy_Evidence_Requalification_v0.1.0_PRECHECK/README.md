# A068 v0.1.0 — Legacy Evidence Requalification / PKLSA audit (candidate)

**Status: DEVELOPMENT / NOT CERTIFIED.** Proposed ID A068 must be checked against the authoritative Workbench registry before registration. This is a read-only **preflight** auditor and a prospective falsifier protocol, **not** a frozen framework v1.0.7 instance, not a complete review of 66 science families, and not evidence for SST physics.

## Purpose

Recover exact versioned provenance for *all* available legacy A-falsifiers, classify the strength of their **claims**, and select minimal justified upgrades. Preserve historical negative results and blind commitments. Do not infer physical validity from test-passing, successful framework import, a PDF, or source-geometry availability.

## Inspect current local Workbench

```
run_audit.cmd C:\workspace\projects\SST-Workbench
```

Linux: `./run_audit.sh /path/to/SST-Workbench`

Outputs go to `outputs/local_audit/` only: `AUDIT_INDEX.csv`, `REQUALIFICATION_LEDGER.json`, `IDENTITY_CONFLICTS.json`, `AUDIT_REPORT.md`. Inputs are never changed. All physical certifications in the output remain `false` by design.

Run selftests: `python -m unittest discover -s tests -v` (or `python -m unittest discover -s tests -v`, in the package root). No nonstandard Python dependencies are required.

## Evidence classes and gates

* G0: ID/registry canonical identity and migration map (manual official check required).
* G1: frozen original bytes, release hashes, retained old gate outcomes.
* G2: claim-scope classification: analytic / topological / finite-core / Euler / physical.
* G3: E010/E011/E013 geometry admission, provider independence, `reach`/writhe/ropelength estimator qualification if relevant.
* G4: finite-core profile, `a_core/reach`, circulation, solver/scaling contract if relevant.
* G5: separate static-relative-equilibrium and dynamical stability gates, source-native Euler/filament and temporal-spatial convergence.
* G6: independence and blinded holdout integrity, data lineage and target exclusion.
* G7: original physical/simulation claim re-evaluation without score tuning.
* G8: publication-worthy claim class and reproducible evidence handoff.

All gates are `NOT_EXECUTED` in v0.1.0; the scanner detects files, not physics. Gate applicability is per claim. `FAIL` requires a concrete recorded violation, and no claim must be failed merely because PKLSA is irrelevant to it.

## Upgrade policy

1. **Framework-only**: create a *new sidecar instance* pinned to v1.0.7; replay fixed old computations and compare hashes/numerics; old result unchanged. No scientific authority upgrade.
2. **Provider-requalification**: source-native E010/E011/E013 plus static geometry/reach/independence gates; requires fresh frozen design and may change claim eligibility.
3. **Physical re-falsification**: finite-core dynamic re-run or new measurements and fresh confirmation holdout, with new version and gate commitments.
4. **Archived negative**: preserve known failures as failures; allow new mechanisms only in a distinct new hypothesis branch.

## Scientific safety

No automatic PASS for physical claims. No invented missing legacy inputs. DD32/FP32 controls are not an FP64 certificate; matched analytic controls are not independent vortex experiments. Synthetic simulations are not independent real-world observations. Distinct discretizations of a single KnotPlot seed are not distinct upstream providers. SST-28 stays excluded from active physics.

## File layout

`docs/SCIENTIFIC_PROTOCOL.md` gives the prospective claim-level falsifier; `config/drive_folders_snapshot.json` is the **observed** 2026-10-17 folder-level snapshot (67 directories, 66 distinct IDs), not complete registry authority. The `review_profiles.json` entries are human review leads, not automatically adjudicated physical truths.
