python .\sst_trefoil_biot_build.py --force
python .\simulate_trefoil_biot_closure.py @args
