# Result summary v0.1.0

## Release verdict

\[
\boxed{
\texttt{ACTION-CONVENTION-CLOSED / TOTAL-KNOT-UNIVERSALITY-REJECTED /}
\atop
\texttt{LOCAL-CELL-SELECTOR-CONDITIONAL / DYNAMIC-EIGENMODE-OPEN}
}
\]

## Action convention

\[
I=\frac{1}{2\pi}\oint p\,dq,
\qquad
\mathscr A_{\rm cycle}=2\pi I.
\]

For the Rankine rotor,

\[
I_{\rm rot}=L_{\rm core}=2E/\Omega.
\]

Thus the earlier alternatives `E/Omega` and `integral p dq` differ by both a
factor two and a factor \(2\pi\) in this sector.

## Total action ladder

At \(a_{\rm core}=r_c\) and on the horn-envelope density branch:

\[
\frac{I_K}{\hbar}
\simeq
\begin{cases}
1.57073,&0_1\text{ resolved torus},\\
4.09167,&3_1,\\
4.09167,&\overline{3_1},\\
5.25844,&4_1.
\end{cases}
\]

Total knot action is therefore not species universal. The parity-even action
correctly gives identical values for the two trefoil chiralities.

The action density is uniform:

\[
\frac{I_K/\hbar}{L_K/r_c}\simeq0.25.
\]

This redirects the matching target from the total knot action to a local
adjacency-cell action.

## Local-cell selector

Solving

\[
\hbar\beta_Q=j_\phi a_\star(\beta_Q)
\]

with the v0.0.7 nonlinear neck closure gives, for
\(a_{\rm core}=r_c\),

\[
\boxed{
\beta_Q=4.591716065108,
\quad
\frac{a_\star}{r_c}=18.36686600745.
}
\]

Consequences:

\[
c_T=2.0090516\times10^7\ \mathrm{m\,s^{-1}}
=0.06701475\,c,
\]

\[
\eta_{\rm cap}^{(2)}
=2.0700543\times10^{27}\ \mathrm{m^{-2}}.
\]

The point is above the inherited finite-volume Coulomb pre-gate, but it does
not close monometricity or the gravitational area density.

## Sensitivity

The fixed point crosses the finite-volume Coulomb pre-gate only near

\[
a_{\rm core}/r_c\simeq0.90.
\]

Therefore the local core-radius theorem remains decisive.

## Dynamical gate

Under the regularized Biot--Savart diagnostic:

- the round ring has residual \(3.3\times10^{-8}\) and is a rigidly translating
  relative-equilibrium candidate;
- the ideal trefoil residual is \(0.226\);
- the figure-eight residual is \(0.332\).

The static knot atlas therefore does not yet provide a certified recurrence or
Floquet frequency for \(3_1\) or \(4_1\).
