# Theory note

The source paper demonstrates phase- and helicity-sensitive control in a two-colour Floquet topological system. This package transfers only the falsification architecture: bichromatic periodic driving, relative phase, co-/counter-rotation, dynamical symmetry, a symmetry-forbidden null channel, and explicit finite-envelope symmetry breaking.

The reference dynamics are

\[
\partial_t \mathbf X
= \beta\,\frac{\mathbf X_s\times\mathbf X_{ss}}{|\mathbf X_s|^3}
+ \epsilon A(t)(\mathbf X-\bar{\mathbf X}),
\]

with a trace-free planar strain

\[
S(\theta)=R_z(\theta)\,\mathrm{diag}(1,-1,0)\,R_z(-\theta),
\]

and

\[
A_{\pm}(t)=a_1 S(\omega t)+a_2 S(\pm 2\omega t+\phi).
\]

The minus sign is the counter-rotating arm. All quantities are dimensionless in v0.1.0. The LIA term is used only as a rotationally equivariant vortex-filament reference model. A later certification release should replace or cross-check it with finite-core Biot--Savart / PKLSA-qualified dynamics.

A strict distinction is maintained between physical fluid vorticity and Berry curvature; no identification is made between them.
