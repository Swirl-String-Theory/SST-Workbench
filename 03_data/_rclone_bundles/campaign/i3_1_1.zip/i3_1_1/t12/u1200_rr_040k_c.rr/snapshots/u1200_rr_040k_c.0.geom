LIST {
	{ < u1200_rr_040k_c.0.vect }
	{ < u1200_rr_040k_c.0.dlen.vect }
	{ < u1200_rr_040k_c.0.dVdt.vect }
}
