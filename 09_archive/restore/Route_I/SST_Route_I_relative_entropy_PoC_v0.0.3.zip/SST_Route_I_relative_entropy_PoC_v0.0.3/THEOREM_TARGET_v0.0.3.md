# Theorem Target v0.0.3 — Local Affine-Scale and Modular/KMS Closure

## Status

\[
\boxed{
\text{CLOSED-CONDITIONAL / EFFECTIVE-SECTOR THEOREM}
}
\]

This closes the specific v0.0.2 gate consisting of:

1. fixing the affine length \(L_\star\) from the SST clock construction;
2. deriving the local Rindler horizon and its modular dilation;
3. deriving the KMS/Unruh response of the canonically normalized torsion field.

The closure applies to the homogeneous quadratic transverse-torsion sector. It
is not yet a theorem for the complete nonlinear knotted-vortex substrate.

## Assumptions

Let a local SST patch satisfy:

1. \(\rho_{\!f}>0\) and \(K_T>0\) are approximately constant;
2. \(\nabla\!\cdot\!\mathbf A=0\), and the two transverse polarizations
   decouple to quadratic order;
3. each polarization is quantized in the quasifree effective-Minkowski vacuum;
4. the coarse-grained Swirl-Clock \(\mathcal S(x)=d\tau/dT\) is the lapse of
   the same infrared torsion cone;
5. \(g_\chi:=|\partial_n\ln\mathcal S|_p\neq0\) is approximately constant
   over the local patch.

Assumptions 2--4 are bridge assumptions relative to the full SST substrate,
but once imposed the following result is exact.

## 1. Canonical torsion field

For one transverse polarization,

\[
\mathcal L_T
=
\frac12\rho_{\!f}(\partial_t A)^2
-
\frac12K_T(\nabla A)^2,
\qquad
c_T^2=\frac{K_T}{\rho_{\!f}}.
\]

With \(x^0=c_Tt\) and

\[
Z_T=\sqrt{\rho_{\!f}K_T}=\rho_{\!f}c_T,
\]

the quantum-normalized field is

\[
\varphi_T
=
\sqrt{\frac{Z_T}{\hbar}}A,
\]

and obeys the free massless equation in the effective metric

\[
\eta^{ab}_{(T)}\partial_a\partial_b\varphi_T=0,
\qquad
\eta^{(T)}_{ab}=\operatorname{diag}(-1,1,1,1).
\]

## 2. Swirl-Clock gradient fixes the affine scale

Introduce local Rindler coordinates in the effective torsion cone:

\[
x^0=\xi\sinh\eta,
\qquad
x^1=\xi\cosh\eta,
\qquad
\xi>0.
\]

Then

\[
ds_T^2
=
-\xi^2d\eta^2+d\xi^2+d\mathbf x_\perp^2.
\]

Choose the Rindler laboratory time

\[
T_R=\frac{L_\star}{c_T}\eta.
\]

The metric becomes

\[
ds_T^2
=
-c_T^2\left(\frac{\xi}{L_\star}\right)^2dT_R^2
+d\xi^2+d\mathbf x_\perp^2.
\]

Therefore the local clock lapse is

\[
\mathcal S(\xi)=\frac{\xi}{L_\star}.
\]

At the reference clock orbit \(\xi=L_\star\),

\[
\left.\partial_\xi\ln\mathcal S\right|_{L_\star}
=
\frac{1}{L_\star}.
\]

Hence

\[
\boxed{
L_\star
=
\frac{1}{g_\chi}
=
\frac{1}{|\partial_n\ln\mathcal S|_p}
}
\]

and the proper acceleration of that clock orbit is

\[
\boxed{
a_\chi
=
c_T^2g_\chi
=
\frac{c_T^2}{L_\star}.
}
\]

Thus \(L_\star\) is local and state-dependent; it is not a new universal SST
constant and no longer appears as a freely chosen numerical normalization.

## 3. Modular flow fixes the horizon dilation sign

Define null coordinates

\[
U=x^0-x^1=-\xi e^{-\eta}<0,
\qquad
V=x^0+x^1=\xi e^{\eta}>0.
\]

A boost \(\eta\mapsto\eta+s\) gives

\[
U\mapsto e^{-s}U,
\qquad
V\mapsto e^sV.
\]

For the right-wedge vacuum algebra, the Bisognano--Wichmann modular parameter
\(t\) generates a boost of rapidity \(s=2\pi t\). Therefore

\[
\boxed{
U\mapsto e^{-2\pi t}U.
}
\]

This resolves the sign ambiguity observed numerically in v0.0.1--v0.0.2:
the matching orientation \(\exp(-2\pi t)\) follows from the adopted
\(U=x^0-x^1<0\) convention.

## 4. KMS and Unruh response

The wedge vacuum is KMS at inverse dimensionless boost temperature

\[
\beta_\eta=2\pi.
\]

Along the reference orbit,

\[
d\tau=\frac{L_\star}{c_T}d\eta,
\]

so the physical inverse-temperature time is

\[
\boxed{
\beta_\tau
=
\frac{2\pi L_\star}{c_T}
=
\frac{2\pi c_T}{a_\chi}.
}
\]

Consequently,

\[
\boxed{
T_{\mathrm{KMS}}
=
\frac{\hbar}{k_B\beta_\tau}
=
\frac{\hbar c_T}{2\pi k_BL_\star}
=
\frac{\hbar a_\chi}{2\pi c_Tk_B}.
}
\]

For the quantum-normalized massless polarization, the accelerated-orbit
Wightman function is

\[
W(z)
=
-\frac{1}{16\pi^2L_\star^2}
\operatorname{csch}^2\!\left(\frac{c_Tz}{2L_\star}\right).
\]

It satisfies the bosonic KMS identity

\[
\boxed{
W(z)=W(-z+i\beta_\tau)
}
\]

inside the analytic strip. An Unruh--DeWitt detector therefore satisfies

\[
\frac{\dot{\mathcal F}(+\Omega)}
{\dot{\mathcal F}(-\Omega)}
=
e^{-\beta_\tau\Omega}.
\]

## 5. Closed normalization map

The dimensionless coherent field used in the relative-entropy calculation is
therefore

\[
\boxed{
\widehat\phi
=
L_\star\varphi_T
=
\frac{1}{|\partial_n\ln\mathcal S|_p}
\sqrt{\frac{Z_T}{\hbar}}A.
}
\]

Equivalently,

\[
\boxed{
\mathcal N_T
=
\frac{1}{|\partial_n\ln\mathcal S|_p}
\sqrt{\frac{Z_T}{\hbar}}.
}
\]

Within the stated effective-sector assumptions, \(\widehat\phi\) is now the
same canonically normalized coherent horizon variable that enters the Weyl
algebra, modular flow, relative entropy, and horizon energy flux.

## 6. Numerical certification

The v0.0.3 script certifies independently:

- the Rindler metric reconstruction;
- constant proper acceleration \(a_\chi=c_T^2/L_\star\);
- \(L_\star^{-1}=|\partial_n\ln\mathcal S|\);
- the affine modular dilation \(U\to e^{-2\pi t}U\);
- the complex-time KMS identity;
- detector detailed balance;
- the Unruh-temperature identity;
- all v0.0.1 and v0.0.2 entropy, Raychaudhuri, action, Hamiltonian, and
  symplectic tests.

## 7. Remaining boundaries

The closed theorem does **not** establish:

1. a substrate-level derivation of \(K_T\) or \(c_T=c\);
2. full nonlinear polarization decoupling and vacuum selection;
3. universal clock/ruler dressing of every resolved knot state;
4. the SST entropy-area coefficient \(\eta_A^{\mathrm{SST}}\);
5. Newton's constant or the Einstein equations without imported gravitational
   input.

Those are distinct theorem targets and must not be folded into the present
closure.

## References

```latex
\begin{thebibliography}{9}

\bibitem{BisognanoWichmann1975}
J.~J.~Bisognano and E.~H.~Wichmann,
\newblock On the duality condition for a Hermitian scalar field,
\newblock \emph{Journal of Mathematical Physics} \textbf{16}, 985--1007 (1975).
\newblock doi:10.1063/1.522605.

\bibitem{Unruh1976}
W.~G.~Unruh,
\newblock Notes on black-hole evaporation,
\newblock \emph{Physical Review D} \textbf{14}, 870--892 (1976).
\newblock doi:10.1103/PhysRevD.14.870.

\bibitem{KayWald1991}
B.~S.~Kay and R.~M.~Wald,
\newblock Theorems on the uniqueness and thermal properties of stationary,
non-singular, quasifree states on spacetimes with a bifurcate Killing horizon,
\newblock \emph{Physics Reports} \textbf{207}, 49--136 (1991).
\newblock doi:10.1016/0370-1573(91)90015-E.

\bibitem{DorauMuch2026}
P.~Dorau and A.~Much,
\newblock From quantum relative entropy to the semiclassical Einstein equations,
\newblock \emph{Physical Review Letters} \textbf{136}, 091602 (2026).
\newblock doi:10.1103/lmq8-nsty.
\newblock arXiv:2510.24491.

\end{thebibliography}
```
