# Common Foundation v0.0.6

## Purpose

v0.0.5 treated correlations, topological degeneracy, and sub-core mode density
as parallel candidate mechanisms. v0.0.6 prevents double counting by placing all
three on one compact cellular link sector.

## Shared ledger

| Object | Branch C | Branch B | Branch A |
|---|---:|---:|---:|
| Coexact positive-frequency modes | counted as channels | not recounted | covariance carrier |
| Gradient/gauge modes | removed | not physical labels | removed |
| Harmonic Wilson modes | not local channels | global protected labels | excluded from local pulse inverse |
| Compact closed-cell defects | not radiation modes | defect alphabet only if protected | modify covariance only when explicitly sampled |
| Hidden collective mode | must be added here | or here | may not appear only as a response multiplier |

The common equations are

\[
\eta_{\mathrm{cap}}=n_{\mathrm{ch}}h_{\mathrm{rate}},
\qquad
\eta_{\mathrm{rel}}=n_{\mathrm{ch}}d_{\mathrm{rate}},
\qquad
0\leq d_{\mathrm{rate}}\leq h_{\mathrm{rate}}.
\]

## Blind result

The audited boundary trace has two independent tangential channels per
relation cell:

\[
\nu_{\mathrm{ch}}=2.
\]

Therefore

\[
n_{\mathrm{ch}}=\frac{2}{a_\star^2},
\qquad
\eta_{\mathrm{cap}}^{(2)}=\frac{2\ln2}{a_\star^2}.
\]

No physical value is assigned to \(a_\star\). This is the key anti-fitting
guardrail of v0.0.6.

## Interpretation

- The **dimensionless channel coefficient** is now derived within the frozen
  model.
- Ordinary global topology is nonextensive.
- Dilute local compact defects do not provide a large protected alphabet.
- Vacuum correlations alter the response by an order-one factor, not by an
  unbooked hierarchy.
- The large coefficient problem has therefore been reduced to the nonlinear
  derivation of a physical adjacency/correlation scale and any genuinely new
  protected local labels.
