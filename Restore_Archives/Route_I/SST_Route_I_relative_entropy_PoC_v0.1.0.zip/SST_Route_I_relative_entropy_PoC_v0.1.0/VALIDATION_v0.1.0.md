# Validation record v0.1.0

## Verdict

\[
\boxed{
\texttt{ACTION-CONVENTION-CLOSED / TOTAL-KNOT-UNIVERSALITY-REJECTED /}
\atop
\texttt{LOCAL-CELL-SELECTOR-CONDITIONAL / DYNAMIC-EIGENMODE-OPEN}
}
\]

## Automated gates

The default run reports 13/13 passing gates:

1. Rankine rotor action equals twice \(E/\Omega\);
2. full phase-space cycle equals \(2\pi I\);
3. trefoil and mirror actions agree;
4. trefoil and mirror Biot--Savart energies agree;
5. total action is not species universal;
6. action per unit ropelength is uniform in the frozen core model;
7. the circular ring passes the relative-equilibrium translation gate;
8. the static trefoil fails the 5% dynamical gate;
9. the static figure-eight fails the 5% dynamical gate;
10. the baseline local-cell equation has one positive root;
11. the baseline root lies above the inherited Coulomb pre-gate;
12. the baseline root does not reproduce observed \(c\);
13. core-radius sensitivity changes the phase verdict.

## Python validation

```text
python -m py_compile sst_route1_resolved_knot_action_v0.1.0.py
PASS
```

## Numerical resolution

The default action table uses 192 arclength-resampled segments. The package also
runs 96 and 384 segment diagnostics. The source/Fourier length discrepancy in
the final table is below \(4.6\times10^{-4}\) for every geometry. The parity
comparisons are exact to the reported numerical tolerance.

## Determinism

A second clean run with the same source geometry reproduced the JSON and CSV
outputs byte-for-byte. No random sampler is used in v0.1.0.

## PDF validation

The theorem source was compiled twice with `pdflatex -halt-on-error`. The output
was rendered to PNG at 200 dpi and visually inspected for clipping, overlap,
broken glyphs, and missing equations.

## CANON patch validation

The Research-Track patch was generated against the current loose
`SST_CANON-v0.8.28-research-track.tex`. The inserted block is labeled
`[RESEARCH TRACK / CONDITIONAL ACTION RESULT]`; it does not promote the
Rankine profile, horn-envelope density, local-cell root, or Biot--Savart
surrogate to CANON.

## Remaining validation limits

- `rho_horn` remains an envelope calibration, not a measured local density;
- `a_core=r_c` is a continuity branch, not a theorem;
- the regularized filament model is not a finite-core Euler certification;
- the static knot atlas is not a periodic-orbit database;
- the finite-volume Coulomb threshold is a pre-gate, not a thermodynamic-limit
  phase proof.

## Clean ZIP extraction

The final archive was extracted into a separate directory. The entrypoint was
compiled and executed from that clean extraction. All 13 gates passed, the
manifest verified before execution, and the regenerated JSON, CSV, and plot
outputs matched the packaged release outputs byte-for-byte.

## Recorded release checks

- default theorem gates: `13/13 PASS`;
- deterministic JSON/CSV rerun: `PASS`;
- theorem PDF: `3 A4 pages`, render inspection `PASS`;
- Research-Track patch application: `PASS`;
- patched combined CANON: `227 pages`, fatal-error scan `PASS`.
