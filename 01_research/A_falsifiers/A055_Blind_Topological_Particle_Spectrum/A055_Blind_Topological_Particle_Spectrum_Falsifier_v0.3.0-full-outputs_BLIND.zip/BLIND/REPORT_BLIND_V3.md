# A055 v0.3.0 — integrated BLIND report

## S-branch: isolated knot controls
A055 v0.2.1-style single-knot/counter-channel controls are retained, now with per-(provider,N,m)
mode failure bookkeeping. A missing oscillatory pair in one cell no longer deletes successful
measurements from other mode/resolution cells.

## C-branch: three-component compounds
Status: **ATTACHED**

A054 v0.2.x remains the authoritative multi-component dynamics engine. A055 does not rebuild
Triple-Gear or Borromean compounds with a second, divergent implementation.

The blind compound bridge extracts only anonymous dynamical observables:
counter-propagating eigenvalue-pair availability, Kelvin-restricted pair availability,
growth, ringdown, RPO and conditional Floquet status.

No architecture code, 5_2/6_1 slot label, proton/neutron label, mass or charge is available
to the BLIND bridge analysis.

## Interpretation lock
Raw eigenvalue magnitudes from the single-knot and compound branches are not pooled into one
winner score because the projected bases differ. Cross-branch comparison is limited to
pre-registered categorical gates (oscillatory-pair availability, RPO, true-Floquet).
