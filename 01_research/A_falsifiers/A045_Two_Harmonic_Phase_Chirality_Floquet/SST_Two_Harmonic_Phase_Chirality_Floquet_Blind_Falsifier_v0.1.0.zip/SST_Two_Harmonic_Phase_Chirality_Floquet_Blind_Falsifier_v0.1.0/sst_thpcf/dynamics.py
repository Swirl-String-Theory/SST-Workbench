from __future__ import annotations
import numpy as np
from .geometry import length, resample_closed_curve, centered
from .drive import drive_matrix


def lia_rhs(X: np.ndarray, t: float, cfg: dict, t_origin: float = 0.0) -> np.ndarray:
    """Dimensionless local-induction reference dynamics plus trace-free bichromatic strain.

    This is a pre-certification reference model, not a finite-core SST closure.
    """
    X = np.asarray(X, float)
    n = len(X)
    ds = length(X)/n
    xp = np.roll(X, -1, axis=0)
    xm = np.roll(X, 1, axis=0)
    Xs = (xp-xm)/(2.0*ds)
    Xss = (xp - 2.0*X + xm)/(ds*ds)
    den = np.linalg.norm(Xs, axis=1)**3 + 1e-12
    lia = cfg["beta_lia"] * np.cross(Xs, Xss) / den[:, None]
    A = drive_matrix(t+t_origin, cfg["omega"], cfg["a1"], cfg["a2"], cfg["phase"],
                     cfg["chirality"], cfg["total_time"], cfg.get("envelope", "flat"))
    Xc = centered(X)
    forced = cfg["drive_strength"] * (Xc @ A.T)
    return lia + forced


def rk4_step(X: np.ndarray, t: float, dt: float, cfg: dict, t_origin: float = 0.0) -> np.ndarray:
    k1 = lia_rhs(X, t, cfg, t_origin)
    k2 = lia_rhs(X+0.5*dt*k1, t+0.5*dt, cfg, t_origin)
    k3 = lia_rhs(X+0.5*dt*k2, t+0.5*dt, cfg, t_origin)
    k4 = lia_rhs(X+dt*k3, t+dt, cfg, t_origin)
    return X + (dt/6.0)*(k1+2*k2+2*k3+k4)


def evolve_python(X0: np.ndarray, cfg: dict, duration: float | None = None,
                  t_origin: float = 0.0) -> np.ndarray:
    X = np.array(X0, dtype=float, copy=True)
    if duration is None:
        duration = cfg["total_time"]
    steps = max(1, int(np.ceil(duration/cfg["dt"])))
    dt = duration/steps
    t = 0.0
    reparam_every = int(cfg.get("reparam_every", 0))
    for step in range(steps):
        X = rk4_step(X, t, dt, cfg, t_origin)
        if reparam_every and (step+1) % reparam_every == 0:
            X = resample_closed_curve(X, len(X))
        t += dt
    return X


def evolve(X0: np.ndarray, cfg: dict, backend: str = "python", duration: float | None = None,
           t_origin: float = 0.0) -> np.ndarray:
    if backend == "python":
        return evolve_python(X0, cfg, duration=duration, t_origin=t_origin)
    if backend == "native":
        try:
            from . import _native
        except Exception as e:
            raise RuntimeError("native backend not built") from e
        if duration is None:
            duration = cfg["total_time"]
        return _native.evolve(np.asarray(X0, float), float(duration), float(t_origin), cfg)
    raise ValueError(f"unknown backend {backend}")
