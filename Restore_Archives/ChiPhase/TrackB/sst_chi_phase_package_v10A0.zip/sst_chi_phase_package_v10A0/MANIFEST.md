# MANIFEST — SST chi-phase package v10A.0

```text
sst_chi_phase_package_v10A0/
  README.md
  CANON_STATUS.md
  DERIVATION_TRACK_A_BIOT_SAVART.md
  simulate_chi_phase_v10A0.py
  sst_chi_phase_v10A0_py.py
  sst_chi_phase_v10A0.cpp
  sst_chi_phase_v10A0_build.py
  exports/
    chi_v10A0_alpha_scan.csv
    chi_v10A0_alpha_intercepts.csv
    chi_v10A0_beta_from_q.csv
    chi_v10A0_run_results_summary.txt
    chi_v10A0_alpha_eff_vs_eps.png
    chi_v10A0_alpha_intercepts.png
  legacy_note/
    notebook_2015_paginas_49_51.tex   # if available
```
