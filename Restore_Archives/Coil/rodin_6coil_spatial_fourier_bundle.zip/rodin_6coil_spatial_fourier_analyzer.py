#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rodin_6coil_spatial_fourier_analyzer.py

Spatial Fourier analyzer for the Rodin 6-lane / 3-phase + mirrored coil guide
created by rodin_6coil_guide_generator.py.

What it computes
----------------
1) Wire/geometry azimuthal spectrum S_m^wire from the lane centerlines.
2) Biot-Savart near-field azimuthal spectrum S_m^B(r,z) on probe circles.
3) Mode-lock frequencies f0 for top harmonics using SST v_swirl.

This is deliberately a diagnostic/metrology script, not a force-law script.
It tells you which azimuthal modes m the Rodin geometry and its magnetic field
actually provide to a test region.

Units
-----
Geometry is in millimetres, inherited from the STL generator. Biot-Savart is
computed in arbitrary normalized units because the spectra are normalized mode
amplitudes. Frequencies are in Hz.

Default outputs
---------------
- rodin_6coil_wire_spectrum.csv
- rodin_6coil_field_spectrum.csv
- rodin_6coil_mode_lock_frequencies.csv
- rodin_6coil_spatial_fourier_spectrum.png
- rodin_6coil_field_profiles.png
- rodin_6coil_spatial_fourier_summary.txt

Author: generated for SST/Rodin coil diagnostics.
"""

from __future__ import annotations

import argparse
import csv
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# =============================================================================
# Parameters copied from rodin_6coil_guide_generator.py
# =============================================================================
R_MAJOR_MM = 34.0
R_TUBE_MM = 9.0
P = 5
Q = 12
N_PATH = 1800
PHASE_ANGLES = [0.0, 2 * np.pi / 3, 4 * np.pi / 3]
MIRROR = True

# SST canonical swirl speed used only for the optional mode-lock table.
V_SWIRL = 1.09384563e6  # m/s

# Default analysis parameters.
M_MAX = 60
N_PHI = 720
FIELD_DECIMATE = 4
PROBE_R_LIST_MM = [10.0, 20.0, 30.0, 34.0]
PROBE_Z_LIST_MM = [12.0, 20.0, 30.0]
SELECTED_PROBE_R_MM = 20.0
SELECTED_PROBE_Z_MM = 20.0
TOP_N = 15


@dataclass(frozen=True)
class Lane:
    name: str
    phase_index: int
    phase_angle: float
    mirror: bool
    points_mm: np.ndarray


# =============================================================================
# Geometry generation: same lane equation as the STL guide generator
# =============================================================================
def torus_lane(
    R_major: float,
    r_surface: float,
    p: int,
    q: int,
    t: np.ndarray,
    phase_angle: float = 0.0,
    mirror: bool = False,
    offset: float = 0.0,
) -> np.ndarray:
    """
    (p,q) torus-knot curve on a torus surface:
      x = (R + r cos(q t)) cos(p t)
      y = (R + r cos(q t)) sin(p t)
      z = r sin(q t)

    phase_angle rotates the curve around Z.
    mirror=True flips z -> -z.
    """
    theta = p * t + phase_angle
    phi = q * t
    r_eff = r_surface + offset

    x = (R_major + r_eff * np.cos(phi)) * np.cos(theta)
    y = (R_major + r_eff * np.cos(phi)) * np.sin(theta)
    z = r_eff * np.sin(phi)

    if mirror:
        z = -z

    return np.column_stack([x, y, z])


def generate_lanes(n_path: int = N_PATH) -> List[Lane]:
    t = np.linspace(0.0, 2 * np.pi, n_path, endpoint=True)
    lanes: List[Lane] = []
    for k, angle in enumerate(PHASE_ANGLES):
        top = torus_lane(R_MAJOR_MM, R_TUBE_MM, P, Q, t, phase_angle=angle, mirror=False)
        lanes.append(Lane(f"phase{k+1}_top", k, angle, False, top))
        if MIRROR:
            bottom = torus_lane(R_MAJOR_MM, R_TUBE_MM, P, Q, t, phase_angle=angle, mirror=True)
            lanes.append(Lane(f"phase{k+1}_bottom", k, angle, True, bottom))
    return lanes


def segment_midpoints_and_dl(points_mm: np.ndarray, decimate: int = 1) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return segment midpoints, dl vectors, and lengths from a path."""
    pts = np.asarray(points_mm, dtype=float)
    if decimate > 1:
        pts = pts[::decimate]
        # Ensure closure segment still reaches final original endpoint if decimation skipped it.
        if np.linalg.norm(pts[0] - pts[-1]) > 1e-9:
            pts = np.vstack([pts, pts[0]])
    a = pts[:-1]
    b = pts[1:]
    dl = b - a
    mid = 0.5 * (a + b)
    length = np.linalg.norm(dl, axis=1)
    mask = length > 1e-12
    return mid[mask], dl[mask], length[mask]


# =============================================================================
# Drive/phasing cases
# =============================================================================
def phase_phasor(phase_index: int, convention: str = "abc") -> complex:
    """Complex current phasor for 3-phase drive."""
    if convention == "abc":
        return np.exp(1j * 2 * np.pi * phase_index / 3)
    if convention == "acb":
        return np.exp(-1j * 2 * np.pi * phase_index / 3)
    if convention == "dc":
        return 1.0 + 0.0j
    raise ValueError(f"Unknown phase convention: {convention}")


def lane_current_phasor(lane: Lane, case: str) -> complex:
    """
    Return a complex lane current weight for a named drive case.

    Cases:
    - geometry_abs: each segment contributes by length only; spectra use abs weights elsewhere.
    - dc_same: all six lanes same current sign.
    - dc_opposed: bottom/mirrored lanes have opposite current sign.
    - abc_same: 3-phase phasor, top/bottom same sign.
    - abc_opposed: 3-phase phasor, bottom/mirrored lanes opposite sign.
    - acb_same: reversed 3-phase phasor, top/bottom same sign.
    - acb_opposed: reversed 3-phase phasor, bottom/mirrored lanes opposite sign.
    """
    if case == "geometry_abs":
        return 1.0 + 0.0j
    if case == "dc_same":
        return 1.0 + 0.0j
    if case == "dc_opposed":
        return -1.0 + 0.0j if lane.mirror else 1.0 + 0.0j

    if case.startswith("abc_"):
        ph = phase_phasor(lane.phase_index, "abc")
    elif case.startswith("acb_"):
        ph = phase_phasor(lane.phase_index, "acb")
    else:
        raise ValueError(f"Unknown case: {case}")

    if case.endswith("_opposed") and lane.mirror:
        ph *= -1
    return ph


DRIVE_CASES = [
    "geometry_abs",
    "dc_same",
    "dc_opposed",
    "abc_same",
    "abc_opposed",
    "acb_same",
    "acb_opposed",
]


# =============================================================================
# Fourier spectra
# =============================================================================
def normalized_complex_spectrum(theta: np.ndarray, weights: np.ndarray, m_max: int) -> Dict[int, float]:
    theta = np.asarray(theta, dtype=float)
    weights = np.asarray(weights, dtype=complex)
    denom = float(np.sum(np.abs(weights)))
    if denom <= 0:
        return {m: 0.0 for m in range(m_max + 1)}
    out: Dict[int, float] = {}
    for m in range(m_max + 1):
        amp = np.sum(weights * np.exp(-1j * m * theta))
        out[m] = float(np.abs(amp) / denom)
    return out


def wire_spectrum(lanes: List[Lane], case: str, m_max: int = M_MAX) -> Dict[int, float]:
    theta_all = []
    weights_all = []
    for lane in lanes:
        mid, _dl, length = segment_midpoints_and_dl(lane.points_mm)
        theta = np.arctan2(mid[:, 1], mid[:, 0])
        if case == "geometry_abs":
            # Treat geometry as unsigned spatial support.
            w = length.astype(complex)
        else:
            w = length.astype(complex) * lane_current_phasor(lane, case)
        theta_all.append(theta)
        weights_all.append(w)
    theta_concat = np.concatenate(theta_all)
    weights_concat = np.concatenate(weights_all)
    return normalized_complex_spectrum(theta_concat, weights_concat, m_max)


def probe_circle_points(r_mm: float, z_mm: float, n_phi: int) -> Tuple[np.ndarray, np.ndarray]:
    phi = np.linspace(0.0, 2 * np.pi, n_phi, endpoint=False)
    pts = np.column_stack([r_mm * np.cos(phi), r_mm * np.sin(phi), np.full_like(phi, z_mm)])
    return phi, pts


def biot_savart_field_on_points(
    lanes: List[Lane],
    case: str,
    probe_pts_mm: np.ndarray,
    decimate: int = FIELD_DECIMATE,
    softening_mm: float = 0.5,
) -> np.ndarray:
    """
    Compute normalized Biot-Savart B field at probe points.

    Uses arbitrary units: B ~ sum I dl x r / (|r|^2+eps^2)^(3/2).
    mm units are left as-is because spectra are normalized; absolute B is not used.
    """
    B = np.zeros((len(probe_pts_mm), 3), dtype=complex)
    eps2 = softening_mm * softening_mm

    for lane in lanes:
        mid, dl, _length = segment_midpoints_and_dl(lane.points_mm, decimate=decimate)
        ph = lane_current_phasor(lane, case)
        # Vectorized over segments in chunks to avoid huge memory use.
        for start in range(0, len(mid), 256):
            end = min(start + 256, len(mid))
            r_vec = probe_pts_mm[:, None, :] - mid[None, start:end, :]
            r2 = np.sum(r_vec * r_vec, axis=2) + eps2
            denom = r2 ** 1.5
            cross = np.cross(dl[None, start:end, :], r_vec)
            B += ph * np.sum(cross / denom[:, :, None], axis=1)
    return B


def field_spectrum(
    lanes: List[Lane],
    case: str,
    r_mm: float,
    z_mm: float,
    component: str,
    m_max: int,
    n_phi: int,
    decimate: int,
) -> Tuple[np.ndarray, np.ndarray, Dict[int, float]]:
    phi, pts = probe_circle_points(r_mm, z_mm, n_phi)
    B = biot_savart_field_on_points(lanes, case, pts, decimate=decimate)

    if component == "Bz":
        sig = B[:, 2]
    elif component == "Br":
        radial = np.column_stack([np.cos(phi), np.sin(phi), np.zeros_like(phi)])
        sig = np.sum(B * radial, axis=1)
    elif component == "Bphi":
        az = np.column_stack([-np.sin(phi), np.cos(phi), np.zeros_like(phi)])
        sig = np.sum(B * az, axis=1)
    elif component == "Bmag":
        sig = np.sqrt(np.real(B[:, 0] * np.conj(B[:, 0]) + B[:, 1] * np.conj(B[:, 1]) + B[:, 2] * np.conj(B[:, 2])))
    else:
        raise ValueError(component)

    # Remove DC for field shape modes; keep normalized non-DC mode strengths.
    sig_centered = sig - np.mean(sig)
    weights = sig_centered.astype(complex)
    spec = normalized_complex_spectrum(phi, weights, m_max)
    return phi, sig, spec


def top_modes(spec: Dict[int, float], n: int = TOP_N, skip_dc: bool = True) -> List[Tuple[int, float]]:
    items = [(m, a) for m, a in spec.items() if not (skip_dc and m == 0)]
    items.sort(key=lambda x: x[1], reverse=True)
    return items[:n]


def mode_lock_frequency_hz(m: int, r_eff_mm: float, n: int = 1, v_swirl: float = V_SWIRL) -> float:
    r_eff_m = r_eff_mm * 1e-3
    if r_eff_m <= 0 or n == 0:
        return float("nan")
    return abs(m) * v_swirl / (n * 2 * np.pi * r_eff_m)


# =============================================================================
# Output helpers
# =============================================================================
def write_wire_csv(path: Path, rows: List[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["case", "m", "S_m_wire"])
        writer.writeheader()
        writer.writerows(rows)


def write_field_csv(path: Path, rows: List[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["case", "component", "r_probe_mm", "z_probe_mm", "m", "S_m_field"])
        writer.writeheader()
        writer.writerows(rows)


def write_mode_lock_csv(path: Path, rows: List[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["case", "source", "component", "r_probe_mm", "z_probe_mm", "m", "amplitude", "n", "R_eff_mm", "f_lock_Hz", "f_lock_MHz"])
        writer.writeheader()
        writer.writerows(rows)


def plot_spectra(wire_specs: Dict[str, Dict[int, float]], selected_field_specs: Dict[Tuple[str, str], Dict[int, float]], out_png: Path) -> None:
    m_vals = np.arange(M_MAX + 1)
    fig, axes = plt.subplots(2, 1, figsize=(12, 9), sharex=True)

    for case in ["geometry_abs", "dc_same", "dc_opposed", "abc_same", "abc_opposed"]:
        if case in wire_specs:
            axes[0].plot(m_vals, [wire_specs[case][m] for m in m_vals], marker="o", markersize=3, linewidth=1, label=case)
    axes[0].set_ylabel(r"$S_m^{wire}$")
    axes[0].set_title("Rodin 6-lane wire / geometry azimuthal Fourier spectrum")
    axes[0].grid(True, alpha=0.35)
    axes[0].legend(fontsize=8, ncol=3)

    for (case, component), spec in selected_field_specs.items():
        axes[1].plot(m_vals, [spec[m] for m in m_vals], marker="o", markersize=3, linewidth=1, label=f"{case} {component}")
    axes[1].set_xlabel("azimuthal harmonic m")
    axes[1].set_ylabel(r"$S_m^{B}$")
    axes[1].set_title(f"Biot-Savart field spectrum at r={SELECTED_PROBE_R_MM:g} mm, z={SELECTED_PROBE_Z_MM:g} mm")
    axes[1].grid(True, alpha=0.35)
    axes[1].legend(fontsize=8, ncol=2)

    plt.tight_layout()
    fig.savefig(out_png, dpi=180)
    plt.close(fig)


def plot_field_profiles(lanes: List[Lane], out_png: Path, n_phi: int, decimate: int) -> None:
    cases = ["abc_same", "abc_opposed"]
    components = ["Bz", "Br", "Bphi"]
    phi, pts = probe_circle_points(SELECTED_PROBE_R_MM, SELECTED_PROBE_Z_MM, n_phi)
    fig, axes = plt.subplots(len(cases), 1, figsize=(12, 7), sharex=True)
    if len(cases) == 1:
        axes = [axes]
    for ax, case in zip(axes, cases):
        B = biot_savart_field_on_points(lanes, case, pts, decimate=decimate)
        radial = np.column_stack([np.cos(phi), np.sin(phi), np.zeros_like(phi)])
        az = np.column_stack([-np.sin(phi), np.cos(phi), np.zeros_like(phi)])
        vals = {
            "Bz": np.real(B[:, 2]),
            "Br": np.real(np.sum(B * radial, axis=1)),
            "Bphi": np.real(np.sum(B * az, axis=1)),
        }
        for comp in components:
            y = vals[comp]
            scale = np.max(np.abs(y)) if np.max(np.abs(y)) > 0 else 1.0
            ax.plot(phi, y / scale, linewidth=1, label=f"{comp} normalized")
        ax.set_title(f"Field profiles around probe circle: {case}")
        ax.grid(True, alpha=0.35)
        ax.legend(fontsize=8)
    axes[-1].set_xlabel(r"probe angle $\phi$ [rad]")
    plt.tight_layout()
    fig.savefig(out_png, dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze Rodin 6-coil spatial Fourier modes.")
    parser.add_argument("--out-dir", default=".", help="Output directory")
    parser.add_argument("--m-max", type=int, default=M_MAX)
    parser.add_argument("--n-phi", type=int, default=N_PHI)
    parser.add_argument("--field-decimate", type=int, default=FIELD_DECIMATE)
    parser.add_argument("--top-n", type=int, default=TOP_N)
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    lanes = generate_lanes()

    # Wire spectra for all drive cases.
    wire_rows: List[dict] = []
    wire_specs: Dict[str, Dict[int, float]] = {}
    for case in DRIVE_CASES:
        spec = wire_spectrum(lanes, case, m_max=args.m_max)
        wire_specs[case] = spec
        for m, amp in spec.items():
            wire_rows.append({"case": case, "m": m, "S_m_wire": f"{amp:.12g}"})
    write_wire_csv(out_dir / "rodin_6coil_wire_spectrum.csv", wire_rows)

    # Field spectra across a probe grid. Compute B only once per case/probe,
    # then decompose into components. This is much faster than recomputing B per component.
    field_rows: List[dict] = []
    selected_field_specs: Dict[Tuple[str, str], Dict[int, float]] = {}
    field_components = ["Bz", "Br", "Bphi", "Bmag"]
    field_cases = ["dc_same", "dc_opposed", "abc_same", "abc_opposed", "acb_same", "acb_opposed"]
    for case in field_cases:
        for r_mm in PROBE_R_LIST_MM:
            for z_mm in PROBE_Z_LIST_MM:
                phi, pts = probe_circle_points(r_mm, z_mm, args.n_phi)
                B = biot_savart_field_on_points(lanes, case, pts, decimate=args.field_decimate)
                radial = np.column_stack([np.cos(phi), np.sin(phi), np.zeros_like(phi)])
                az = np.column_stack([-np.sin(phi), np.cos(phi), np.zeros_like(phi)])
                comp_values = {
                    "Bz": B[:, 2],
                    "Br": np.sum(B * radial, axis=1),
                    "Bphi": np.sum(B * az, axis=1),
                    "Bmag": np.sqrt(np.real(B[:, 0] * np.conj(B[:, 0]) + B[:, 1] * np.conj(B[:, 1]) + B[:, 2] * np.conj(B[:, 2]))),
                }
                for comp, sig in comp_values.items():
                    sig_centered = sig - np.mean(sig)
                    spec = normalized_complex_spectrum(phi, sig_centered.astype(complex), args.m_max)
                    if abs(r_mm - SELECTED_PROBE_R_MM) < 1e-9 and abs(z_mm - SELECTED_PROBE_Z_MM) < 1e-9 and comp in ["Bz", "Br", "Bphi"] and case in ["abc_same", "abc_opposed"]:
                        selected_field_specs[(case, comp)] = spec
                    for m, amp in spec.items():
                        field_rows.append({
                            "case": case,
                            "component": comp,
                            "r_probe_mm": f"{r_mm:g}",
                            "z_probe_mm": f"{z_mm:g}",
                            "m": m,
                            "S_m_field": f"{amp:.12g}",
                        })
    write_field_csv(out_dir / "rodin_6coil_field_spectrum.csv", field_rows)

    # Mode-lock table from top harmonics in wire and selected field spectra.
    mode_rows: List[dict] = []
    for case, spec in wire_specs.items():
        for m, amp in top_modes(spec, n=args.top_n):
            for n in [1, 2, 3, 4, 5, 6]:
                f = mode_lock_frequency_hz(m, R_MAJOR_MM, n=n)
                mode_rows.append({
                    "case": case,
                    "source": "wire",
                    "component": "wire",
                    "r_probe_mm": "",
                    "z_probe_mm": "",
                    "m": m,
                    "amplitude": f"{amp:.12g}",
                    "n": n,
                    "R_eff_mm": f"{R_MAJOR_MM:g}",
                    "f_lock_Hz": f"{f:.12g}",
                    "f_lock_MHz": f"{f/1e6:.12g}",
                })
    for (case, comp), spec in selected_field_specs.items():
        for m, amp in top_modes(spec, n=args.top_n):
            for n in [1, 2, 3, 4, 5, 6]:
                f = mode_lock_frequency_hz(m, SELECTED_PROBE_R_MM, n=n)
                mode_rows.append({
                    "case": case,
                    "source": "field",
                    "component": comp,
                    "r_probe_mm": f"{SELECTED_PROBE_R_MM:g}",
                    "z_probe_mm": f"{SELECTED_PROBE_Z_MM:g}",
                    "m": m,
                    "amplitude": f"{amp:.12g}",
                    "n": n,
                    "R_eff_mm": f"{SELECTED_PROBE_R_MM:g}",
                    "f_lock_Hz": f"{f:.12g}",
                    "f_lock_MHz": f"{f/1e6:.12g}",
                })
    write_mode_lock_csv(out_dir / "rodin_6coil_mode_lock_frequencies.csv", mode_rows)

    plot_spectra(wire_specs, selected_field_specs, out_dir / "rodin_6coil_spatial_fourier_spectrum.png")
    plot_field_profiles(lanes, out_dir / "rodin_6coil_field_profiles.png", args.n_phi, args.field_decimate)

    # Text summary.
    summary_lines: List[str] = []
    summary_lines.append("Rodin 6-lane spatial Fourier analysis")
    summary_lines.append("======================================")
    summary_lines.append(f"Geometry: R_MAJOR={R_MAJOR_MM} mm, R_TUBE={R_TUBE_MM} mm, P={P}, Q={Q}, lanes={len(lanes)}")
    summary_lines.append(f"Selected field probe: r={SELECTED_PROBE_R_MM} mm, z={SELECTED_PROBE_Z_MM} mm")
    summary_lines.append("")
    summary_lines.append("Top wire modes:")
    for case in DRIVE_CASES:
        tops = ", ".join([f"m={m}: {amp:.4f}" for m, amp in top_modes(wire_specs[case], n=10)])
        summary_lines.append(f"  {case}: {tops}")
    summary_lines.append("")
    summary_lines.append("Top selected field modes:")
    for key, spec in selected_field_specs.items():
        tops = ", ".join([f"m={m}: {amp:.4f}" for m, amp in top_modes(spec, n=10)])
        summary_lines.append(f"  {key[0]} {key[1]}: {tops}")
    summary_lines.append("")
    summary_lines.append("Mode-lock frequency formula:")
    summary_lines.append("  f_lock = |m| v_swirl / (n 2π R_eff)")
    summary_lines.append(f"  v_swirl = {V_SWIRL:.8e} m/s")
    summary_lines.append("")
    summary_lines.append("Notes:")
    summary_lines.append("  - geometry_abs is unsigned wire-support only.")
    summary_lines.append("  - abc/acb are the two rotating 3-phase directions.")
    summary_lines.append("  - same/opposed control whether mirrored bottom lanes carry same or opposite current sign.")
    summary_lines.append("  - Field spectra are normalized shape spectra; they are not absolute magnetic-field predictions.")

    (out_dir / "rodin_6coil_spatial_fourier_summary.txt").write_text("\n".join(summary_lines), encoding="utf-8")

    print("Wrote outputs to", out_dir)
    for filename in [
        "rodin_6coil_wire_spectrum.csv",
        "rodin_6coil_field_spectrum.csv",
        "rodin_6coil_mode_lock_frequencies.csv",
        "rodin_6coil_spatial_fourier_spectrum.png",
        "rodin_6coil_field_profiles.png",
        "rodin_6coil_spatial_fourier_summary.txt",
    ]:
        print("-", out_dir / filename)


if __name__ == "__main__":
    main()
