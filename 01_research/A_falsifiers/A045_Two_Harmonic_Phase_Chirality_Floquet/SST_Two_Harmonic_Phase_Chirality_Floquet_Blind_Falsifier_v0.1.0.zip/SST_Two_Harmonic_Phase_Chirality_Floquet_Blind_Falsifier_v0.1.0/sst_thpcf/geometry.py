from __future__ import annotations
import numpy as np


def torus_trefoil(n: int = 96, R: float = 2.0, r: float = 1.0) -> np.ndarray:
    """Dimensionless T(2,3) trefoil centerline, arclength-resampled."""
    if n % 3 != 0:
        raise ValueError("n must be divisible by 3 for C3 symmetry tests")
    u = np.linspace(0.0, 2.0*np.pi, n, endpoint=False)
    x = (R + r*np.cos(3*u))*np.cos(2*u)
    y = (R + r*np.cos(3*u))*np.sin(2*u)
    z = r*np.sin(3*u)
    X = np.column_stack([x, y, z])
    return resample_closed_curve(X, n)


def resample_closed_curve(X: np.ndarray, n: int | None = None) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if n is None:
        n = len(X)
    d = np.roll(X, -1, axis=0) - X
    seg = np.linalg.norm(d, axis=1)
    if np.any(seg <= 0):
        raise ValueError("curve has zero-length segment")
    s = np.concatenate([[0.0], np.cumsum(seg)])
    total = s[-1]
    Xc = np.vstack([X, X[0]])
    target = np.linspace(0.0, total, n, endpoint=False)
    out = np.empty((n, 3), dtype=float)
    for k in range(3):
        out[:, k] = np.interp(target, s, Xc[:, k])
    return out


def rz(theta: float) -> np.ndarray:
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def centered(X: np.ndarray) -> np.ndarray:
    return np.asarray(X) - np.mean(X, axis=0, keepdims=True)


def c3_geometry_residual(X: np.ndarray) -> float:
    """Relative residual of T(2,3) geometric C3 symmetry.

    For the standard trefoil orientation, shifting one third of the closed curve
    corresponds to an Rz(-2pi/3) rotation.
    """
    Xc = centered(X)
    n = len(Xc)
    if n % 3:
        raise ValueError("n must be divisible by 3")
    lhs = np.roll(Xc, -n//3, axis=0)
    rhs = Xc @ rz(-2.0*np.pi/3.0).T
    den = np.linalg.norm(Xc)
    return float(np.linalg.norm(lhs-rhs)/(den + 1e-30))


def length(X: np.ndarray) -> float:
    return float(np.sum(np.linalg.norm(np.roll(X, -1, axis=0)-X, axis=1)))


def curvature_stats(X: np.ndarray) -> tuple[float, float]:
    X = np.asarray(X, float)
    xp = np.roll(X, -1, axis=0)
    xm = np.roll(X, 1, axis=0)
    ds = length(X)/len(X)
    Xs = (xp-xm)/(2.0*ds)
    Xss = (xp - 2.0*X + xm)/(ds*ds)
    num = np.linalg.norm(np.cross(Xs, Xss), axis=1)
    den = np.linalg.norm(Xs, axis=1)**3 + 1e-30
    k = num/den
    return float(np.mean(k)), float(np.sqrt(np.mean(k*k)))


def min_nonlocal_distance(X: np.ndarray, exclude: int = 3) -> float:
    X = np.asarray(X, float)
    n = len(X)
    best = np.inf
    for i in range(n):
        for j in range(i+1, n):
            sep = min((j-i) % n, (i-j) % n)
            if sep <= exclude:
                continue
            d = np.linalg.norm(X[i]-X[j])
            if d < best:
                best = d
    return float(best)
