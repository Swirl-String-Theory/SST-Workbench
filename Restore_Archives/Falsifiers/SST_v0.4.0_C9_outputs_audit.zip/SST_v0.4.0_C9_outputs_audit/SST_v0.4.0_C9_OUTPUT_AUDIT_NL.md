# Hoge-resolutie audit — SST v0.4.0 iso-Γ/A outputs

## Kernverdict

De upload bevat de positieve solid-body-controle, smoke-test, volledige 128-run researchmatrix en twee discretisatietests.


\[
\boxed{
\begin{array}{c}
\texttt{POSITIVE-CONTROL-PASS}\\
\texttt{INITIAL-PHASE-RESPONSE-CERTIFIED}\\
\texttt{GLOBAL-GAMMA/A-TREFOIL-RESPONSE-FAIL}\\
\texttt{RANKINE-EXTERIOR-SCALING-SUPPORTED}\\
\texttt{STRICT-DYNAMIC-PERIOD-INCONCLUSIVE}\\
\texttt{SHAPE-CLOCK-INCONCLUSIVE}\\
\texttt{LONG-TIME-CONSERVATION-FAIL}
\end{array}}
\]
## 1. Positieve controle


Voor \(R_{\rm bundle}/R_{\rm hole}=4\), zodat de trefoil volledig in de
solid-body-regio ligt:

\[
\mathcal Q_\Gamma=0.995478,\qquad 1.003049.
\]

De strikte fits bevatten \(3.13\)–\(3.32\) gemeten cycli en geven:

\[
\mathcal Q_\Gamma^{\rm strict}=0.976076,\qquad1.041624.
\]

De extractor vindt de correcte relatie terug wanneer de geometrische voorwaarde

\[
\Omega=\frac{\Gamma/A}{2}
\]

daadwerkelijk geldt.
## 2. Volledige researchmatrix

Alle 128 initiële fasefits zijn gecertificeerd, met $R^2_{\min}=0.999554$ en ${\rm SNR}_{\min}=101.95$.

De gemeten falsifier ligt in $[0.013404, 0.086837]$. Geen enkele run ligt binnen de preregistreerde tolerantie rond één.

De uitkomst is robuust tegen resolutie, kernel, circulatiemagnitude en trefoil/mirror-trefoil na de juiste parityvergelijking.

## 3. De sterkste gevonden schaalwet

De data volgen

\[
\mathcal Q_\Gamma = (0.08400590\pm0.00024642)\left(\frac{R_{\rm bundle}}{R_{\rm hole}}\right)^2+(0.00002743\pm0.00015413),
\]

met $R^2=0.998916949$.


Voor een Rankine-vortex buiten de kern geldt:

\[
\Omega(r)=\frac{\Gamma}{2\pi r^2}.
\]

Daarom:

\[
\frac{2\Omega(r)}{\Gamma/A}
=
\frac{R_{\rm bundle}^2}{r^2}.
\]

De gevonden kwadratische schaalwet is dus precies het verwachte buitenveldgedrag.
De fit correspondeert met een effectief door het multipoolmoment bemonsterde radius $r_{\rm eff}/R_{\rm hole}\simeq3.450$.

De trefoil reageert daarmee op de lokale buitenstroming die zij werkelijk bemonstert, niet rechtstreeks op de gemiddelde vorticiteit binnen het centrale gat.

## 4. Wat is werkelijk gefalsificeerd?


Gefalsificeerd binnen het bevroren Rankine-model:

\[
\boxed{
\text{De oriëntatiefase-rate van een trefoil buiten de bundelkern}
\atop
\text{wordt uitsluitend bepaald door de gemiddelde kernvorticiteit }\Gamma/A.
}
\]

Niet gefalsificeerd:

\[
\boxed{
\text{Binnen een uniforme vorticiteitsregio geldt }
\Omega=\frac{\Gamma/A}{2}.
}
\]

Ook niet getest zijn een dynamisch geselecteerd klokoppervlak, volledige
terugreactie, emergente proper time en een stabiele recurrente
trefoil–bundelmodus.
## 5. Epistemische correctie rond T_dyn


De primaire output `t_dyn` is een uit een korte beginhelling geëxtrapoleerde
periode:

\[
T_{\rm dyn}^{\rm extrap}
=
\frac{2\pi}{|\Delta\Omega_{\rm initial}|}.
\]

De fitwindow is vast op \(0.025\), dus de primaire numerator is niet uit
\(\Gamma/A\) terugberekend. In de researchmatrix bestrijkt deze window echter
slechts \(0.000248\) tot \(0.023507\) fasecyclus.

Daarom is dit een gecertificeerde lokale fasehelling, maar geen rechtstreeks
waargenomen volledige periode.
De strikte driecyclische gate slaagt in 0/128 runs; het maximum is 1.5526 gemeten cycli. Ook zijn 0/128 shape clocks gecertificeerd.

Een volgende versie moet `t_dyn_certified` hernoemen naar `initial_phase_rate_certified` en `t_dyn_extrapolated`; alleen de strikte multi-cycle-uitkomst verdient de naam `T_dyn`.

## 6. Numerieke discretisatie

| Representatie | Gemiddeld |ΔQ| | Maximum |ΔQ| |
|---|---:|---:|
| numerical_N19 | 6.455e-06 | 2.684e-05 |
| numerical_N37 | 4.593e-06 | 1.914e-05 |
| numerical_N61 | 3.890e-06 | 1.624e-05 |

De discrete buizen reproduceren de continuümbundel; de negatieve uitkomst is geen artefact van de continue Rankine-formule.

## 7. Conservatie en lange-tijdinterpretatie

De researchruns hebben einddrifts $\Delta E/E\in[-0.989,0.123]$ en $\Delta L/L\in[-0.443,1.123]$.

Deze drifts zijn te groot voor een recurrente klok- of Floquetclaim. De fase-extractor is bruikbaar als lokale kinematische responsmeter, maar de huidige integrator/remeshing-combinatie certificeert geen schone lange-tijd Hamiltoniaanse evolutie.

## 8. Aanbevolen v0.4.1-gates

1. Hernoem de primaire output naar `initial_phase_rate`.
2. Reserveer `T_dyn` voor minimaal drie werkelijk gemeten cycli.
3. Voeg een initial-window-conservatiegate toe.
4. Bewaar initial-window-timeseries voor alle researchruns.
5. Voeg de lokale Rankine-voorspeller binnen en buiten de kern toe.
6. Vergelijk de multipoolfase met een geometrisch gewogen lokale angular-velocity-functionaal.
7. Verlaag dt of gebruik een geometrisch/conservatief filamentintegratieschema.

## Eindconclusie


\[
\boxed{
\text{De trefoilfase meet het lokale Rankine-buitenveld, niet automatisch}
\atop
\text{de gemiddelde vorticiteit van de bundelkern.}
\]

De keten

\[
\Gamma/A\rightarrow\bar\zeta\rightarrow\Omega
\]

blijft correct voor het gebied waarop \(\bar\zeta\) en de klok werkelijk
betrekking hebben. Wat faalt, is de identificatie van die kernrate met de
fase-rate van een ruimtelijk buiten de kern gelegen trefoil zonder aanvullende
koppelingswet.
