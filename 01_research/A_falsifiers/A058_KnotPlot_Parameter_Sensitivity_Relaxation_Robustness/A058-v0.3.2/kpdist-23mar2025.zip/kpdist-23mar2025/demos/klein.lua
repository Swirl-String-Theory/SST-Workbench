--[[

rob scharein
Tuesday, 23-Jan-24 00:12:08 UTC

--]]


if demo ~= luaSource then
  demo = luaSource
  executeKP ([[
    reset all
    txt on
    txt clobber on
  ]])

  --Demo ()
  --Title ("klein")

end   -- end of init block

--ButtonHelp ()



executeKP ('klein.kps', [[
  <ARG1
]])




--[[

BEGIN HELP
some helpful text should go here...



some helpful text should go here...



some helpful text should go here...
END HELP

--]]
