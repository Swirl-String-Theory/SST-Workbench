from pathlib import Path
import sst_counterpulley.physics as physics

def test_physics_has_no_alpha_target_literal():
    text=Path(physics.__file__).read_text(encoding="utf-8")
    assert "137.035" not in text
    assert "ALPHA_INV" not in text
