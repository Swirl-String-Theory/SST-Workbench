"""Canonical SST constants used only where explicitly dimensionally meaningful."""
V_SWIRL = 1.09384563e6          # m s^-1
R_C = 1.40897017e-15           # m
RHO_CORE = 3.8934358266918687e18 # kg m^-3
RHO_F = 7.0e-7                 # kg m^-3
F_SWIRL_MAX = 29.053507        # N
F_GR_MAX = 3.02563e43          # N
OMEGA_CORE = V_SWIRL / R_C     # s^-1
F_CORE = OMEGA_CORE / (2.0 * 3.141592653589793)
