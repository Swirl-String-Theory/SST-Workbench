$ErrorActionPreference = "Stop"
python derive_blind.py --config config/reference.yaml
python run_campaign.py --config config/reference.yaml
python score_target.py --input outputs/blind_result.json --campaign outputs/campaign_summary.json
if ($LASTEXITCODE -ne 0) { Write-Host "Falsifier returned a non-survival verdict (expected for demo inputs)." }
