# Discussion, limits, appendices, and falsification map

## Slide 1/15 - Why limits are a section

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Limits prevent overclaiming.
- They distinguish established, conjectural, and speculative content.
- They define near-term priorities.

**Single slide message:** Limits prevent overclaiming.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 2/15 - Established at Canon level

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Axioms and definitions are explicit.
- Notation and density hierarchy are formalized.
- Operational spacetime and provenance rules are integrated.

**Single slide message:** Axioms and definitions are explicit.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 3/15 - What remains conjectural

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Full Standard Model mapping.
- Exact derivation of charge and action quantum.
- Full Einstein dynamics.
- Exact physical ideal-knot identity.

**Single slide message:** Full Standard Model mapping.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 4/15 - Compatibility limits

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST must obey spectroscopy, Lorentz tests, tensor-speed constraints, and topology.
- Analogy does not replace derivation.
- Violations require domain limits or falsifiers.

**Single slide message:** SST must obey spectroscopy, Lorentz tests, tensor-speed constraints, and topology.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 5/15 - Minimal falsifiers

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Hidden circularity in constants.
- Operational Lorentz violation.
- Unauthorized topology change.
- No knot convergence.
- Excluded spectral shifts.

**Single slide message:** Hidden circularity in constants.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 6/15 - Methodological limit

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Classical intuition guides but does not prove.
- Dimensional consistency is necessary but insufficient.
- Calibrated reproduction is not prediction.

**Single slide message:** Classical intuition guides but does not prove.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 7/15 - Near-term priorities

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Constant provenance audit.
- Independent link-response derivation.
- Bound-mode impedance from certified geometry.
- Monometricity tests.
- Knot contact-map convergence.

**Single slide message:** Constant provenance audit.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 8/15 - Historical provenance appendix

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Preserves notebook and proto-Canon references.
- Separates original wording from modern interpretation.
- Allows correction without erasure.

**Single slide message:** Preserves notebook and proto-Canon references.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 9/15 - Topological reference toolkit

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Defines chirality, framing, linking, ropelength and related tools.
- Prevents misuse of topology terms.
- Supports the geometry module.

**Single slide message:** Defines chirality, framing, linking, ropelength and related tools.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 10/15 - Full derivations appendix

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Long derivations stay auditable without blocking main narrative.
- Readers can check details.
- Main text stays readable.

**Single slide message:** Long derivations stay auditable without blocking main narrative.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 11/15 - Delay mathematics appendix

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Fixed points and stability support delay claims.
- Must be cited for dynamical claims.
- Prevents slogan-level quantization.

**Single slide message:** Fixed points and stability support delay claims.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 12/15 - Conversation-derived insights

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Chats are not Canon automatically.
- They can be distilled into labelled appendices.
- Useful intuition is preserved with status.

**Single slide message:** Chats are not Canon automatically.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 13/15 - Dark/galactic appendix

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Galaxy-scale claims remain research branches.
- They need independent tests.
- They must not contaminate core microphysics.

**Single slide message:** Galaxy-scale claims remain research branches.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 14/15 - Final limit statement

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- v0.8.23 is a disciplined research Canon.
- It is not final proof of SST.
- It is strongest where it says what is not yet claimed.

**Single slide message:** v0.8.23 is a disciplined research Canon.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.

## Slide 15/15 - Limits closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Genesis gives origin.
- Axioms define commitments.
- Bridges propose physics.
- Limits decide current trust level.

**Single slide message:** Genesis gives origin.

**Source anchors:** Discussion and Limits; Appendices; Historical Provenance Register.

**Visual specification:** Trust contract diagram: origin, axioms, bridges, limits, falsifiers.

**Do not generate:** Do not omit limits or turn every open point into “future confirmation”.
