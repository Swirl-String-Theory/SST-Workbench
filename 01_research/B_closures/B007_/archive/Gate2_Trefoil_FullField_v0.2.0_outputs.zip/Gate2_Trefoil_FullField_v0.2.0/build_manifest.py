from pathlib import Path
import datetime,hashlib,json,platform,sys
import numpy, scipy, pytest
P=Path(__file__).resolve().parent
out=P/'Gate2_Trefoil_FullField_v0.2.0-outputs'
prior=[Path('/mnt/data/Gate1_Trefoil_Independent_v0.2.0_outputs.zip'),Path('/mnt/data/Gate2_Trefoil_Relative_Equilibrium_v0.1.0_outputs.zip')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old_s=P/'src/g1_seed.py';old_g=P/'src/gate2.py'
manifest={'project':'Gate2_Trefoil_FullField','version':'v0.2.0','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'G2_UNRESOLVED_NO_EULER_RELATIVE_EQUILIBRIUM',
 'isovortical_seed':'Analytic q-fixed compact trefoil, fixed dimensionless units R0=1 Gamma0=1',
 'backend':{'python':sys.version,'numpy':numpy.__version__,'scipy':scipy.__version__,'pytest':pytest.__version__,'platform':platform.platform()},
 'original_packages':[{'name':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in prior if p.exists()],
 'vendored_sources':[{'name':p.name,'sha256':sha(p)} for p in [old_s,old_g]],
 'source_notes':'g1_seed.py and gate2.py are unchanged vendored from Gate2 v0.1.0; all new software in full_field.py, continuation.py, verify_independent.py, assess.py.',
 'not_closed':['independent continuum zero residual','discrete vorticity divergence convergence','spectral and nonlinear stability','background filament response']}
(out/'PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
files={}
for p in sorted(P.rglob('*')):
 if not p.is_file() or any(part in ['.pytest_cache','__pycache__','.git'] for part in p.relative_to(P).parts) or p.name in ['FILE_CHECKSUMS.json']:
  continue
 files[str(p.relative_to(P)).replace('\\','/')]={'sha256':sha(p),'size_bytes':p.stat().st_size}
(out/'FILE_CHECKSUMS.json').write_text(json.dumps({'project':'Gate2_Trefoil_FullField_v0.2.0','excludes':['FILE_CHECKSUMS.json','__pycache__','.pytest_cache'],'file_count':len(files),'files':files},indent=2)+'\n')
print(len(files),'file hashes written')
