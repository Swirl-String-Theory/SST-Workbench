#!/usr/bin/env python3
"""
s5_spherical_designs.py  —  AUDIT §5  (conversation turn 17)

CLAIM UNDER TEST
    Leading (dim-4) photon-metric isotropy from a Weyl-node set requires the
    2nd-moment (spherical 2-design) condition  sum_a n_a^i n_a^j = (N/3) delta^ij.
    The 8-node cube satisfies it -> isotropic leading cone.
    But the cube is a 3-design, NOT a 4-design: a cubic (k^4) dim-6 anisotropy
    survives. Only the icosahedron (5-design) kills the 4th-moment anisotropy.

STATUS: [DERIVED]  (cube isotropizes dim-4; dim-6 needs icosahedron)
"""
import numpy as np, itertools
phi=(1+5**0.5)/2
def normset(v):
    v=np.array(v,float); return v/np.linalg.norm(v,axis=1,keepdims=True)

tetra=normset([(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)])
octa =normset([(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)])
cube =normset([(sx,sy,sz) for sx in(1,-1) for sy in(1,-1) for sz in(1,-1)])
ico  =normset([(0,s1,s2*phi) for s1 in(1,-1) for s2 in(1,-1)]
            +[(s1,s2*phi,0) for s1 in(1,-1) for s2 in(1,-1)]
            +[(s1*phi,0,s2) for s1 in(1,-1) for s2 in(1,-1)])

print("Isotropic-sphere reference:  <nx^4>=0.2000  3<nx^2 ny^2>=0.2000  cubic-anisotropy(4th)=0\n")
for name, n in [("tetra(4)",tetra),("octa(6)",octa),("cube(8)",cube),("ico(12)",ico)]:
    M2 = np.einsum('ai,aj->ij', n, n)/len(n)
    iso2 = np.allclose(M2, np.eye(3)/3, atol=1e-9)
    nx4 = np.mean(n[:,0]**4); nx2ny2 = np.mean(n[:,0]**2*n[:,1]**2)
    cub = nx4 - 3*nx2ny2
    tag = "ISOTROPIC@k^4" if abs(cub)<1e-9 else "ANISOTROPIC@k^4"
    print(f"{name:10s} 2nd-moment isotropic: {str(iso2):5s}  "
          f"<nx^4>={nx4:.4f}  3<nx^2ny^2>={3*nx2ny2:.4f}  cubic-aniso(4th)={cub:+.4f}  {tag}")

# self-checks: all four are 2-designs; only icosahedron is isotropic at 4th moment
for n in (tetra,octa,cube,ico):
    assert np.allclose(np.einsum('ai,aj->ij',n,n)/len(n), np.eye(3)/3, atol=1e-9)
cub_cube = np.mean(cube[:,0]**4) - 3*np.mean(cube[:,0]**2*cube[:,1]**2)
cub_ico  = np.mean(ico[:,0]**4)  - 3*np.mean(ico[:,0]**2*ico[:,1]**2)
assert abs(cub_cube) > 0.1 and abs(cub_ico) < 1e-9
print("\n>>> cube isotropizes the LEADING cone (dim-4) but leaves dim-6 cubic anisotropy;")
print(">>> only the icosahedron (5-design) is isotropic at k^4.")
print("\nALL §5 CHECKS PASSED.")
