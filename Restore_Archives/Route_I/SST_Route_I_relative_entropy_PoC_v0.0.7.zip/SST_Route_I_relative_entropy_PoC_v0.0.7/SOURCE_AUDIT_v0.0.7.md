# Source and Claim Audit v0.0.7

## SST source basis

The active source is `SST_CANON-v0.8.28-research-track.tex`, especially
`Research Track: Minimal Relational Link--Field Action`. That source supports:

- compact relative link phases \(U_e=e^{i\vartheta_e}\);
- the rotor/plaquette action with \(I_\ell\) and \(K_\ell\);
- the speed identity \(c_T=a_\ell\sqrt{K_\ell/I_\ell}\);
- the requirement to derive \(a_\ell,I_\ell,K_\ell\) independently;
- a mandatory four-dimensional Coulomb/deconfinement phase gate;
- strict separation of the effective background density from ordinary mixture
  or rest-mass interpretations.

The source does not provide the core-neck geometry introduced in v0.0.7. That
geometry is new Research-Track content and is labelled accordingly.

## Orthodox external basis

1. Wilson's compact plaquette action supplies the Euclidean phase model.
2. Kogut and Susskind supply the canonical rotor Hamiltonian structure.
3. Guth proves existence of a nonconfining phase for four-dimensional compact
   \(U(1)\) lattice gauge theory in Villain form.
4. DeGrand and Toussaint supply the integer monopole-current diagnostic used in
   the simulation.
5. Vettorazzo and de Forcrand support flux/helicity-modulus phase diagnostics
   and a first-order interpretation for the Wilson transition on large toroidal
   lattices.
6. Torres et al. (2024) report a more nuanced tricritical phase structure and
   possible continuous behavior in parts of the anisotropic phase diagram.

The package therefore does not claim that the transition order is settled by
its small lattice. It only certifies a finite-volume strong/weak phase window.

## Claim labels

- Core-neck inertia formula: `[DERIVED WITHIN DECLARED MICROGEOMETRY]`.
- Rankine plaquette stiffness: `[DERIVED WITHIN DECLARED MICROGEOMETRY]`.
- Hamiltonian-to-Wilson map: `[ORTHODOX/DERIVED]`.
- Finite-volume phase separation: `[NUMERICALLY VERIFIED]`.
- Thermodynamic-limit Coulomb phase for the SST relational graph:
  `[OPEN]`.
- Core density as the physical link carrier: `[HYPOTHESIS]`.
- Effective background density as the link inertia in this geometry:
  `[REJECTED BY JOINT CAUSAL/PHASE GATE]`.
- \(\beta_Q=68.517993\ldots\) as a prediction: `[REJECTED]`; it is an
  observationally unblinded compatibility value.

## References

```latex
\begin{thebibliography}{9}

\bibitem{Wilson1974}
K.~G.~Wilson,
\newblock Confinement of quarks,
\newblock \emph{Physical Review D} \textbf{10}, 2445--2459 (1974).
\newblock doi:10.1103/PhysRevD.10.2445.

\bibitem{KogutSusskind1975}
J.~Kogut and L.~Susskind,
\newblock Hamiltonian formulation of Wilson's lattice gauge theories,
\newblock \emph{Physical Review D} \textbf{11}, 395--408 (1975).
\newblock doi:10.1103/PhysRevD.11.395.

\bibitem{Guth1980}
A.~H.~Guth,
\newblock Existence proof of a nonconfining phase in four-dimensional
U(1) lattice gauge theory,
\newblock \emph{Physical Review D} \textbf{21}, 2291--2307 (1980).
\newblock doi:10.1103/PhysRevD.21.2291.

\bibitem{DeGrandToussaint1980}
T.~A.~DeGrand and D.~Toussaint,
\newblock Topological excitations and Monte Carlo simulation of Abelian gauge theory,
\newblock \emph{Physical Review D} \textbf{22}, 2478--2489 (1980).
\newblock doi:10.1103/PhysRevD.22.2478.

\bibitem{VettorazzoDeForcrand2004}
M.~Vettorazzo and P.~de~Forcrand,
\newblock Electromagnetic fluxes, monopoles, and the order of the 4d compact
U(1) phase transition,
\newblock \emph{Nuclear Physics B} \textbf{686}, 85--118 (2004).
\newblock doi:10.1016/j.nuclphysb.2004.02.029.
\newblock arXiv:hep-lat/0311006.

\bibitem{TorresEtAl2024}
R.~C.~Torres, N.~Cardoso, P.~Bicudo, P.~Ribeiro, and P.~McClarty,
\newblock Tricriticality in 4D U(1) lattice gauge theory,
\newblock \emph{Physical Review D} \textbf{110}, 034518 (2024).
\newblock doi:10.1103/PhysRevD.110.034518.

\end{thebibliography}
```
