@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set "PYTHON=.venv\Scripts\python.exe") else (set "PYTHON=python")
"%PYTHON%" scripts\run_spectral.py --config configs\spectral_audit.json --output outputs_spectral %*
exit /b %errorlevel%
