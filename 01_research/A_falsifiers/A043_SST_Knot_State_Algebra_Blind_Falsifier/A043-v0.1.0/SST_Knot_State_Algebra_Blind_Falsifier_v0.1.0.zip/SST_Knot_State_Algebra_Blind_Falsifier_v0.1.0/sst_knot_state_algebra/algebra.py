from __future__ import annotations
from pathlib import Path
import numpy as np

def _comm(a,b):return a@b-b@a

def closure_metrics(gens):
    G=np.asarray(gens)
    if G.shape[0]!=3 or G.ndim!=3 or G.shape[1]!=G.shape[2]: raise ValueError("generators must be (3,n,n)")
    pairs=[(0,1,2),(1,2,0),(2,0,1)]; C=[]; T=[]
    for i,j,k in pairs: C.append(_comm(G[i],G[j]).reshape(-1)); T.append(G[k].reshape(-1))
    c=np.concatenate(C); t=np.concatenate(T); den=np.vdot(t,t)
    s=(np.vdot(t,c)/den) if abs(den)>0 else 0
    resid=np.linalg.norm(c-s*t)/max(np.linalg.norm(c),1e-30)
    noncomm=np.linalg.norm(c)/max(np.linalg.norm(G),1e-30)
    return {"closure_relative_residual":float(np.real(resid)),"common_scale_real":float(np.real(s)),"common_scale_imag":float(np.imag(s)),"noncommutativity":float(np.real(noncomm))}

def load_core_response(path):
    z=np.load(path,allow_pickle=False); out={"generators":z["generators"]}
    if "angles" in z.files and "state_overlap" in z.files: out["angles"]=z["angles"].astype(float); out["state_overlap"]=z["state_overlap"]
    return out

def double_cover_metrics(angles,overlap):
    a=np.asarray(angles,float); o=np.asarray(overlap)
    def nearest(theta):
        i=int(np.argmin(abs(a-theta))); return float(a[i]),complex(o[i])
    a2,o2=nearest(2*np.pi); a4,o4=nearest(4*np.pi)
    return {"angle_2pi":a2,"overlap_2pi_abs":abs(o2),"overlap_2pi_real":o2.real,
            "angle_4pi":a4,"overlap_4pi_abs":abs(o4),"overlap_4pi_real":o4.real}
