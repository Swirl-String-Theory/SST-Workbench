@echo off
setlocal EnableExtensions
set "MODE=%~1"
set "WB=%~2"
if /I "%MODE%"=="" set "MODE=BASIC"
if /I not "%MODE%"=="BASIC" if /I not "%MODE%"=="FULL" if /I not "%MODE%"=="CERTIFY" if /I not "%MODE%"=="REVEAL" (set "WB=%~1" & set "MODE=BASIC")
if "%WB%"=="" if not "%SST_WORKBENCH_ROOT%"=="" set "WB=%SST_WORKBENCH_ROOT%"
if "%WB%"=="" set "WB=C:\workspace\projects\SST-Workbench"
set "PY=%WB%\.venvs\A054-v0.4.0-r3\Scripts\python.exe"

call "%~dp0run_00_setup.cmd" "%WB%"
if errorlevel 1 exit /b 20

set "SST_FALSIFIER_FRAMEWORK_ROOT=%WB%\06_templates\SST_Falsifier_Framework\SST_Falsifier_Framework_v1.0.4"
"%PY%" "%~dp0run_instance.py" FREEZE
if errorlevel 1 exit /b 21

"%PY%" "%~dp0run_instance.py" %MODE%
if errorlevel 1 exit /b 22
exit /b 0
