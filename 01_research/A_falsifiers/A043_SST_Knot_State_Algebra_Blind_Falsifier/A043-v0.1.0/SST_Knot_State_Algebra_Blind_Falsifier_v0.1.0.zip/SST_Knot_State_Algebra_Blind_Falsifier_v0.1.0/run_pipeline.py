import argparse
from sst_knot_state_algebra.pipeline import run
p=argparse.ArgumentParser()
p.add_argument("--config",default="configs/basic.json")
p.add_argument("--out")
p.add_argument("--profile",choices=["basic","extended"],default="basic")
p.add_argument("--backend",default=None)
p.add_argument("--invariants",default=None)
p.add_argument("--core-response",default=None)
p.add_argument("--cross-source-manifest",default=None,help="Blind-safe CSV/JSON/JSONL with source_family,topology,source_path")
a=p.parse_args()
out=a.out or f"SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs/{a.profile}"
run(a.config,out,a.profile,a.backend,a.invariants,a.core_response,a.cross_source_manifest)
