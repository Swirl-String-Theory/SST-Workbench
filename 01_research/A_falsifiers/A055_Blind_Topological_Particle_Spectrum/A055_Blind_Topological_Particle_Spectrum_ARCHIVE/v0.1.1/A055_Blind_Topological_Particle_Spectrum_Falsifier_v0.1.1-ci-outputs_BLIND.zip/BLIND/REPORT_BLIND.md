# A055 v0.1.1 — BLIND report

- Cases: **82** = 35 knots + 47 links.
- Backend: **python**.
- Resolution ladder: **[20, 28, 36]** points/component.
- Primary resolution: **36**; convergence gate uses **28 -> 36**.
- Embedding replicates per resolution: **2**.
- Feature convergence tolerance: **1** relative.
- Embedding-CV tolerance: **2**.
- SM particle labels visible to blind stage: **no**.
- Historical particle mapping visible to blind stage: **no**.

## v0.1.1 corrections

`contact_ratio = min_distance / mean_segment` is retained only as a diagnostic because it explicitly changes when the discretization resolution changes.  The primary contact observable is now `min_distance` after the common mean-component-length normalization.

Feature domains are preregistered.  `linking_strength` is link-only and can no longer place knots at a numerical floor.  Mixed knot/link distance uses only bending, Neumann and minimum-distance observables with common semantics.  Knot-only and link-only distance spaces add their domain-specific observables.

Every primary feature receives its own resolution-convergence and embedding-stability gate.  Qualified pair tables contain only cases that pass all features required by that pair space.

## Scientific scope

These remain PD-derived screening observables, not PKLSA-relaxed vortex equilibria or particle masses.  The reveal stage may test preregistered mass-pattern resemblance only after the BLIND tree is sealed.
