# SST Knot State Algebra Blind Falsifier v0.1.0 — preregistration

Protocol: `SST-KSA-BLIND-v0.1.0`.

## Primary questions

**Lane F (fractional/topological):** does a preregistered knot-family adjacency graph exhibit a low-denominator dimensionless structure that survives source/invariant provenance controls, permutation nulls and multiplicity correction, without exposing historical target fractions to the discovery executable?

**Lane A (algebra/spinorial):** does a physical finite-core response supply three non-commuting generators whose commutators close with one common scale, and does the same physical state exhibit a double-cover return (`4π` return without an ordinary `2π` return)?

The lanes are independent. A PASS in one cannot compensate for FAIL/UNRESOLVED in the other.

## Primary nulls

\[
H_{0,F}: \text{rational proximity is no stronger than the preregistered permutation null after multiplicity correction.}
\]

\[
H_{0,A}: \text{the physical core response is commuting, fails Lie-algebra closure, or returns ordinarily after }2\pi.
\]

## Lane order

`G0 provenance -> G1 PKLSA geometry -> G2 invariant provenance -> G3 blind rational discovery -> G4 broad carrier screen -> G5 CPU certification -> G5X cross-source replication -> G6 physical algebra/double-cover -> REVEAL`.

G3 and G6 are scientifically independent; G4/G5 select/qualify physical carriers and may not retrofit G3 targets.

## Independence

The primary PKLSA geometry/dynamics independence unit is the **upstream family/carrier**; topology is retained as a physical label but 48 family variants are dependent shape probes. The primary provenance replication unit is **source family**. Forty-eight PKLSA variants, multiple Fremlin variants, several meshes, time steps, or GPU reruns do not become independent samples.

## CPU/GPU authority

GPU is screening-only. Before any GPU ranking, one deterministic candidate must satisfy CPU↔GPU relative \(L_2\) parity `<=1e-10` in BASIC/EXTENDED unless a new protocol version preregisters another threshold. Every finalist is rerun on the CPU reference path at `N=128,256,512`; cross-source geometry is independently CPU-certified where an admissible parser/provider exists. A GPU-only result cannot produce PASS.

## Rational search

The blind code searches all reduced rationals with denominator `q <= 12` (EXTENDED keeps the same denominator domain) through a generic nearest-rational statistic. No historical rational target is stored in the blind source. For every preregistered adjacent family pair and every admitted invariant/transform, the null is formed by random value permutations. Benjamini-Hochberg FDR is applied across the complete generated test family.

## Physical algebra gate

The physical-provider contract supplies `generators[3,n,n]`. The test fits one common coefficient \(s\) to

\[
[G_1,G_2]\approx sG_3,\quad [G_2,G_3]\approx sG_1,\quad [G_3,G_1]\approx sG_2.
\]

A built-in analytic \(SO(3)\) control is permitted only as a software check; it cannot count as physical evidence. A half-integer/spinorial bridge additionally requires a physical state-overlap record that returns at \(4\pi\) while remaining sign-distinct at \(2\pi\).

## Allowed conclusions

- `FRACTIONAL_LANE_SUPPORTED`: G2+G3 PASS; no particle interpretation follows.
- `ALGEBRA_LANE_SUPPORTED`: G6 PASS; no particle mapping follows.
- `COMBINED_BRIDGE_ELIGIBLE_FOR_REVEAL`: G3 and G6 PASS, with required provenance/certification gates satisfied.
- `FALSIFIED`: a well-powered preregistered scientific gate FAILs.
- `UNRESOLVED`: required providers/data/numerical certification are missing or inconclusive.

Private historical mappings/target fractions are committed by SHA-256 and are inaccessible to the blind runtime until explicit reveal.
