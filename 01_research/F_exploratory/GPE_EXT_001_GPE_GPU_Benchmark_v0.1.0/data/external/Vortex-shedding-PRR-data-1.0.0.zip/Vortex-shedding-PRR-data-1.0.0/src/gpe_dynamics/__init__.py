"""Simulation and analysis modules for the vortex-shedding calculations."""

