
# SST Taxonomy Starter

Standalone, non-destructive toolkit to build an **orthodox knot taxonomy** from your existing project zips.

It does **not** modify `SSTcore`, `SST_Dashboard`, or `resources`.
It only reads the zip files and writes new CSV/JSON files.

## What it produces

- `taxonomy_identity.csv`
- `taxonomy_embeddings.csv`
- `taxonomy_complement_geometry.csv`
- `taxonomy_field_descriptors.csv`
- `taxonomy_validation.csv`

## Current philosophy

This starter separates five data layers:

1. `knot_identity` — standard knot/link metadata
2. `geometric_realization` — concrete `.fseries` or resource embeddings
3. `complement_geometry` — hyperbolic volume and related complement data
4. `induced_field_descriptors` — embedding-dependent descriptors such as `a_mu`, `Hc`, `Hm`
5. `numerical_validation` — sweep / closure / robustness metadata

## Current extraction level

This starter already extracts:

- embeddings from `resources.zip` and `SST_Dashboard.zip`
- field descriptors from `SST_helicity_by_base.csv`
- partial complement data from `fseries_batch_results.csv`
- schema files for all five output tables

It intentionally avoids importing your compiled modules or changing any existing code.

## Usage

```bash
python taxonomy_builder.py \
  --resources /path/to/resources.zip \
  --dashboard /path/to/SST_Dashboard.zip \
  --out ./taxonomy_output
```

Optional:

```bash
python taxonomy_builder.py \
  --resources /path/to/resources.zip \
  --dashboard /path/to/SST_Dashboard.zip \
  --sstcore /path/to/SSTcore.zip \
  --out ./taxonomy_output
```

## Notes

- `taxonomy_identity.csv` is seeded conservatively for a core candidate set.
- Hyperbolic volume values are currently taken from available CSV/export metadata when present.
- The C++ `hyperbolic_volume.cpp` backend in the inspected source looks like a stub, so this starter does not pretend to compute full complement geometry from C++ yet.
