#!/usr/bin/env python3
"""
SST chi-phase package v10A.0
Track A: incompressible Euler / Biot-Savart ring-alpha extraction.

This module is intentionally self-contained and conservative:
- It computes the vorticity-energy integral for toroidal vortex tubes.
- It extracts alpha_eff = log(8R/a) - 2E/(rho Gamma^2 R).
- It extrapolates alpha_eff(eps) to eps -> 0.
- It does NOT include NLSE/GP gradient or density-depletion energy.

Authoring status: Research Track / CANON-compatible audit prototype.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Callable, Dict, Iterable, List, Tuple

import numpy as np

PHI = (1.0 + math.sqrt(5.0)) / 2.0
A0_STAR = (math.sqrt(385.0) - 13.0) / 4.0
A0_GRAD_MIN = 7.0 / 4.0


@dataclass(frozen=True)
class Profile:
    name: str
    family: str
    a0: float | None = None
    sigma: float | None = None
    expected_alpha: float | None = None
    note: str = ""


def smooth_f(x: np.ndarray, a0: float) -> np.ndarray:
    return x * (a0 + (3.0 - 2.0 * a0) * x * x + (a0 - 2.0) * x**4)


def smooth_df(x: np.ndarray, a0: float) -> np.ndarray:
    return a0 + 3.0 * (3.0 - 2.0 * a0) * x * x + 5.0 * (a0 - 2.0) * x**4


def lamb_oseen_f(x: np.ndarray, sigma: float) -> np.ndarray:
    # Boundary-normalized Lamb-Oseen phase-velocity profile.
    # f(x) = [1-exp(-(x/sigma)^2)]/[1-exp(-(1/sigma)^2)] * 1/x
    # It is regular near x=0 because numerator ~ x^2.
    denom = 1.0 - math.exp(-1.0 / (sigma * sigma))
    return (1.0 - np.exp(-(x / sigma) ** 2)) / (denom * x)


def lamb_oseen_df(x: np.ndarray, sigma: float) -> np.ndarray:
    denom = 1.0 - math.exp(-1.0 / (sigma * sigma))
    e = np.exp(-(x / sigma) ** 2)
    # derivative of g/x where g=1-e.
    g = 1.0 - e
    gp = 2.0 * x * e / (sigma * sigma)
    return (gp * x - g) / (denom * x * x)


DEFAULT_PROFILES: Dict[str, Profile] = {
    "rankine_solid": Profile(
        name="rankine_solid",
        family="solid",
        expected_alpha=7.0 / 4.0,
        note="Benchmark: solid-body v_theta=f=x, uniform tube vorticity; expected alpha near 7/4.",
    ),
    "smooth_a0star": Profile(
        name="smooth_a0star",
        family="smooth",
        a0=A0_STAR,
        note="v6 chi-closure root a0=(sqrt(385)-13)/4.",
    ),
    "smooth_phi": Profile(
        name="smooth_phi",
        family="smooth",
        a0=PHI,
        note="Smooth-matched family at golden ratio phi.",
    ),
    "smooth_a0_2": Profile(
        name="smooth_a0_2",
        family="smooth",
        a0=2.0,
        note="Simple matched polynomial f=2x-x^3.",
    ),
    "smooth_grad_min": Profile(
        name="smooth_grad_min",
        family="smooth",
        a0=A0_GRAD_MIN,
        note="v6 gradient-energy minimum a0=7/4.",
    ),
    "lamb_oseen_sigma_075": Profile(
        name="lamb_oseen_sigma_075",
        family="lamb_oseen",
        sigma=0.75,
        note="Boundary-normalized Lamb-Oseen phase-velocity profile, sigma=0.75.",
    ),
}


def profile_f_df(profile: Profile, x: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    if profile.family == "solid":
        return x, np.ones_like(x)
    if profile.family == "smooth":
        assert profile.a0 is not None
        return smooth_f(x, profile.a0), smooth_df(x, profile.a0)
    if profile.family == "lamb_oseen":
        assert profile.sigma is not None
        return lamb_oseen_f(x, profile.sigma), lamb_oseen_df(x, profile.sigma)
    raise ValueError(f"Unknown profile family: {profile.family}")


def chi_speed_ratio_smooth(a0: float) -> float:
    """Analytic c_chi/v_ref for the smooth-matched polynomial family."""
    c2 = (2.0 * a0 * a0 + 13.0 * a0 + 78.0) / 105.0
    return math.sqrt(c2)


@dataclass
class RingEnergyResult:
    profile: str
    eps: float
    R: float
    a: float
    nr: int
    ntheta: int
    ndelta: int
    energy: float
    gamma: float
    alpha_eff: float


def ring_energy_biot_savart(
    profile: Profile,
    *,
    eps: float,
    R: float = 1.0,
    rho: float = 1.0,
    gamma: float = 1.0,
    nr: int = 8,
    ntheta: int = 24,
    ndelta: int | None = None,
    nd_scale: float = 90.0,
    nd_min: int = 900,
) -> RingEnergyResult:
    """Compute vortex-ring energy by axisymmetry-reduced Biot-Savart quadrature.

    The quadrature is midpoint in cross-section radius x, angle theta, and
    toroidal separation delta. Delta resolution must increase as eps decreases
    because the near-singular region narrows with a/R.
    """

    if eps <= 0.0:
        raise ValueError("eps must be positive")
    if R <= 0.0:
        raise ValueError("R must be positive")
    if nr < 2 or ntheta < 4:
        raise ValueError("nr and ntheta are too small")

    a = eps * R
    if ndelta is None:
        ndelta = max(int(nd_min), int(math.ceil(nd_scale / eps)))

    # Cross-section midpoint nodes.
    x = (np.arange(nr, dtype=float) + 0.5) / nr
    theta = (np.arange(ntheta, dtype=float) + 0.5) * (2.0 * math.pi / ntheta)
    X, TH = np.meshgrid(x, theta, indexing="ij")
    xv = X.ravel()
    thv = TH.ravel()
    r = a * xv

    f, df = profile_f_df(profile, xv)
    f1, _ = profile_f_df(profile, np.array([1.0]))
    f1_scalar = float(f1[0])
    if abs(f1_scalar) < 1e-15:
        raise ValueError(f"profile {profile.name} has f(1)=0; cannot boundary-normalize circulation")

    # Gamma = 2*pi*a*v_ref*f(1)
    v_ref = gamma / (2.0 * math.pi * a * f1_scalar)

    # omega_phi = (v_ref/a) * (f'(x) + f(x)/x)
    omega = (v_ref / a) * (df + f / xv)

    dr = a / nr
    dtheta = 2.0 * math.pi / ntheta

    # Reduced torus geometry at phi=0.
    radial_major = R + r * np.cos(thv)
    z = r * np.sin(thv)
    jac = radial_major * r
    weight = jac * dr * dtheta
    omega_weight = omega * weight

    # x/y/z at phi=0
    x0 = radial_major
    y0 = np.zeros_like(x0)
    z0 = z

    ddelta = 2.0 * math.pi / ndelta
    total = 0.0

    # Chunkless vectorized N^2 loop over cross-section nodes for each delta.
    for k in range(ndelta):
        delta = (k + 0.5) * ddelta
        cd = math.cos(delta)
        sd = math.sin(delta)

        xp = radial_major * cd
        yp = radial_major * sd
        zp = z0

        dx = x0[:, None] - xp[None, :]
        dy = y0[:, None] - yp[None, :]
        dz = z0[:, None] - zp[None, :]
        dist = np.sqrt(dx * dx + dy * dy + dz * dz)

        total += ddelta * cd * np.sum((omega_weight[:, None] * omega_weight[None, :]) / dist)

    energy = rho * 0.25 * total
    alpha_eff = math.log(8.0 * R / a) - 2.0 * energy / (rho * gamma * gamma * R)

    return RingEnergyResult(
        profile=profile.name,
        eps=eps,
        R=R,
        a=a,
        nr=nr,
        ntheta=ntheta,
        ndelta=ndelta,
        energy=energy,
        gamma=gamma,
        alpha_eff=alpha_eff,
    )


@dataclass
class AlphaFitResult:
    profile: str
    alpha0: float
    A: float
    B: float
    residual_rms: float
    n_points: int
    expected_alpha: float | None = None
    expected_error: float | None = None


def fit_alpha_intercept(results: Iterable[RingEnergyResult], profile: Profile) -> AlphaFitResult:
    rows = [r for r in results if r.profile == profile.name]
    if len(rows) < 3:
        raise ValueError("Need at least 3 epsilon points for alpha intercept fit")

    eps = np.array([r.eps for r in rows], dtype=float)
    y = np.array([r.alpha_eff for r in rows], dtype=float)

    X = np.column_stack([np.ones_like(eps), eps * eps * np.log(1.0 / eps), eps * eps])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ coef
    residual_rms = float(np.sqrt(np.mean((y - pred) ** 2)))

    expected_error = None
    if profile.expected_alpha is not None:
        expected_error = float(coef[0] - profile.expected_alpha)

    return AlphaFitResult(
        profile=profile.name,
        alpha0=float(coef[0]),
        A=float(coef[1]),
        B=float(coef[2]),
        residual_rms=residual_rms,
        n_points=len(rows),
        expected_alpha=profile.expected_alpha,
        expected_error=expected_error,
    )


def beta_from_alpha_q(alpha: float, q: float) -> float:
    return alpha - 1.0 + q


def run_track_a(
    profiles: List[Profile],
    eps_values: List[float],
    *,
    nr: int = 8,
    ntheta: int = 24,
    nd_scale: float = 90.0,
    nd_min: int = 900,
    R: float = 1.0,
    rho: float = 1.0,
    gamma: float = 1.0,
) -> Tuple[List[RingEnergyResult], List[AlphaFitResult]]:
    energy_results: List[RingEnergyResult] = []
    fits: List[AlphaFitResult] = []

    for profile in profiles:
        for eps in eps_values:
            energy_results.append(
                ring_energy_biot_savart(
                    profile,
                    eps=eps,
                    R=R,
                    rho=rho,
                    gamma=gamma,
                    nr=nr,
                    ntheta=ntheta,
                    nd_scale=nd_scale,
                    nd_min=nd_min,
                )
            )
        fits.append(fit_alpha_intercept(energy_results, profile))

    return energy_results, fits
