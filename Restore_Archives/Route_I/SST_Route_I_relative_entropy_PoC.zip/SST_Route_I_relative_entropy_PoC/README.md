# SST Route I — Relative-Entropy / Area-Variation Proof-of-Concept

## Doel

Dit pakket start het actuele SST-onderzoeksprogramma voor **Route I:
thermodynamic gravity** met een reproduceerbare numerieke audit van

\[
\text{coherente horizonpuls}
\longrightarrow
T_{UU}
\longrightarrow
S_{\mathrm{rel}}
\longrightarrow
\delta A.
\]

De implementatie gebruikt de leidende-orde relaties uit Dorau en Much,
*From Quantum Relative Entropy to the Semiclassical Einstein Equations*,
Phys. Rev. Lett. **136**, 091602 (2026), DOI `10.1103/lmq8-nsty`.

## Wat het script berekent

Voor een gladde, compact gedragen puls \(\phi(U)\), volledig gelegen in
\(U<0\), wordt

\[
T_{UU}(U)=\left(\partial_U\phi\right)^2
\]

berekend. Vervolgens worden vier routes vergeleken.

### Route A — gewogen energieflux / relatieve entropie

\[
S_{\mathrm{rel}}
=
-2\pi A_\perp
\int_{-\infty}^{0}
U\,T_{UU}(U)\,dU.
\]

Omdat \(U<0\) en \(T_{UU}\geq 0\), geldt numeriek en analytisch:

\[
S_{\mathrm{rel}}\geq 0.
\]

### Route B — modulaire symplectische afgeleide

Het script berekent numeriek

\[
\frac12
\left.
\frac{d}{dt}
\sigma(\phi^t,\phi)
\right|_{t=0},
\qquad
\sigma(f,g)
=
A_\perp\int(fg'-gf')\,dU.
\]

Beide dilatatie-oriëntaties

\[
\phi^t(U)=\phi(e^{\pm 2\pi t}U)
\]

worden expliciet getest. Met de in het script gekozen oriëntatie van
\(U\) en \(\sigma\) reproduceert \(e^{-2\pi t}\) de positieve
energiefluxformule. Dit is een **conventie-audit**, geen fysische
afwijking: de combinatie van horizonoriëntatie, pullback/pushforward en
symplectisch teken moet in een SST-afleiding vooraf worden vastgelegd.

### Route C — entropische oppervlaktevariatie

Onder de conditionele koppeling

\[
R_{UU}=\alpha T_{UU}
\]

wordt

\[
\delta A_{\mathrm{ent}}
=
\frac{\alpha}{2\pi}S_{\mathrm{rel}}
\]

berekend.

### Route D — Raychaudhuri-focusing

De lineaire Raychaudhuri-route gebruikt

\[
\frac{d\theta}{dU}
=
-R_{UU},
\qquad
\theta(0)=0,
\]

en

\[
\delta A_{\mathrm{Ray}}
=
A_\perp
\int_{-\infty}^{0}\theta(U)\,dU.
\]

Deze route moet identiek worden aan

\[
\delta A_{\mathrm{Ricci}}
=
-A_\perp
\int_{-\infty}^{0}U R_{UU}(U)\,dU.
\]

Daarnaast wordt de niet-lineaire vergelijking

\[
\frac{d\theta}{dU}
=
-\frac12\theta^2-R_{UU}
\]

opgelost, zodat zichtbaar wordt wanneer de leidende-orde benadering
begint af te wijken.

## SST-koppeling

De actuele SST Research Track bevat voor de transversale torsielaag

\[
\mathcal L_{\mathrm{torsion}}
=
\frac12\rho_{\!f}
\left\lVert\partial_t\mathbf A\right\rVert^2
-
\frac12K_T
\left\lVert\nabla\times\mathbf A\right\rVert^2,
\qquad
c_T^2=\frac{K_T}{\rho_{\!f}}.
\]

Met

\[
\rho_{\!f}=7.0\times10^{-7}\ \mathrm{kg\,m^{-3}},
\qquad
c_T=c,
\]

rapporteert het script:

\[
K_T=\rho_{\!f}c^2
=
6.2912862511577\times10^{10}\ \mathrm{Pa},
\]

\[
Z_T=\rho_{\!f}c
=
2.098547206\times10^{2}\ 
\mathrm{kg\,m^{-2}\,s^{-1}}.
\]

Deze waarden zijn **gekalibreerde doelen** zolang \(c_T=c\) niet uit de
substraatmicrofysica is afgeleid.

## Standaarduitkomst

Met de meegeleverde standaardparameters:

\[
S_{\mathrm{rel}}
=
7.225707152549\times10^{-3},
\]

\[
\delta A_{\mathrm{ent}}
=
\delta A_{\mathrm{Ricci}}
=
\delta A_{\mathrm{Ray}}
=
2.890282861020\times10^{-2}
\]

binnen numerieke precisie.

De nulstaat geeft exact nul binnen machineprecisie. Verdubbeling van de
pulsamplitude geeft

\[
\frac{S_{\mathrm{rel}}[2\phi]}
{S_{\mathrm{rel}}[\phi]}
=4,
\]

zoals vereist door \(T_{UU}\propto(\partial_U\phi)^2\).

## Uitvoeren

```bash
python sst_relative_entropy_route1_poc.py
```

Een andere uitvoermap:

```bash
python sst_relative_entropy_route1_poc.py \
  --output-dir my_output
```

Een zwakkere puls voor een nog strengere lineaire limiet:

```bash
python sst_relative_entropy_route1_poc.py \
  --amplitude 0.003
```

## Bestanden in `output/`

- `audit_report.json` — machineleesbare resultaten en epistemische grenzen;
- `convergence.csv` — waarden per rasterresolutie;
- `pulse_and_flux.png` — \(\phi(U)\) en \(T_{UU}\);
- `raychaudhuri_response.png` — lineaire en niet-lineaire focusing;
- `convergence.png` — numerieke fouten versus rasterresolutie.

## Wat hiermee wel is aangetoond

1. De gekozen pulse geeft \(T_{UU}\geq0\) en \(S_{\mathrm{rel}}\geq0\).
2. De energieflux-, entropie-, Ricci- en lineaire
   Raychaudhuri-routes zijn intern consistent.
3. De nul- en amplitudeschalingslimieten worden correct gereproduceerd.
4. De berekening is reproduceerbaar en geautomatiseerd.
5. Een relevante teken-/oriëntatieconventie is expliciet zichtbaar
   gemaakt.

## Wat hiermee niet is aangetoond

1. Dat het SST-torsieveld een Araki–Uhlmann-relative entropy bezit.
2. Dat SST lokale Rindler/Killing-horizonten en een KMS-toestand oplevert.
3. Dat \(\delta A=(\alpha/2\pi)S_{\mathrm{rel}}\) microscopisch uit SST volgt.
4. Dat de Bekenstein–Hawking-coëfficiënt of \(G\) uit SST is afgeleid.
5. Dat Einstein-dynamica empirisch uit SST volgt.

De volgende echte theorem target is daarom een onafhankelijke
normalisatiemapping

\[
\phi
=
\mathcal N_T\,A_{\mathrm{torsion}}
\]

plus een afleiding van de SST-oppervlaktedichtheid

\[
\eta_A^{\mathrm{SST}}
=
s_\ell n_\perp
\]

zonder \(G\) of \(L_p\) als invoer.

## Referenties

```latex
\begin{thebibliography}{9}

\bibitem{DorauMuch2026}
P.~Dorau and A.~Much,
\newblock From quantum relative entropy to the semiclassical Einstein equations,
\newblock \emph{Physical Review Letters} \textbf{136}, 091602 (2026).
\newblock doi:10.1103/lmq8-nsty.
\newblock arXiv:2510.24491.

\bibitem{Jacobson1995}
T.~Jacobson,
\newblock Thermodynamics of spacetime: The Einstein equation of state,
\newblock \emph{Physical Review Letters} \textbf{75}, 1260--1263 (1995).
\newblock doi:10.1103/PhysRevLett.75.1260.

\bibitem{Araki1976}
H.~Araki,
\newblock Relative entropy of states of von Neumann algebras,
\newblock \emph{Publications of the Research Institute for Mathematical Sciences}
\textbf{11}, 809--833 (1976).
\newblock doi:10.2977/prims/1195191148.

\end{thebibliography}
```
