# A046 v0.2.0 reveal report

Blind seal: **VERIFIED**
Release mode: **FULL_PYTHON_NATIVE_QUALIFIED**
Python blind status: **PIPELINE_QUALIFIED**
Native blind status: **PIPELINE_QUALIFIED**
Backend parity: **PASS**

HWC basis: **REJECTED_AS_LOCAL_COMPLETE_BASIS**
UWS basis: **LOCAL_FIRST_ORDER_KINEMATICS_RECONSTRUCTED_NOT_VALIDATED_AS_GRAVITY**

## Canonical-scale reveal

- beta = 3.648676278574e-03
- Swirl-Clock = 9.999933435586e-01
- n_gamma - 1 (exact) = 6.656485755485e-06
- delta p_swirl = -4.187743917945e+05 Pa
- Gamma_0 = 9.683619203489e-09 m^2 s^-1
- v/r_c characteristic = 7.763440655383e+20 s^-1
- r_c/v characteristic = 1.288088676644e-21 s

## Rotating-frame reveal benchmark

- Earth f at north pole = 1.458423000000e-04 s^-1
- Earth f at south pole = -1.458423000000e-04 s^-1
- illustrative_hurricane_core: Ro = 3.42836 for U=50.0 m/s, L=100000.0 m
- illustrative_hurricane_outer: Ro = 0.685672 for U=50.0 m/s, L=500000.0 m
- illustrative_tornado_core: Ro = 342.836 for U=50.0 m/s, L=1000.0 m

Rossby examples use explicitly declared illustrative U and L values. They are scale diagnostics, not fitted atmospheric predictions.

Reveal values were evaluated only after the complete blind evidence tree was sealed. No canonical SST value or Earth rotation value was used to choose blind gates or tolerances.
