from __future__ import annotations
import argparse, csv, json, math, shutil, zipfile
from pathlib import Path
import numpy as np
from .geometry import torus_trefoil, rz, c3_geometry_residual
from .drive import c3_dynamic_symmetry_residual
from .dynamics import evolve
from .metrics import equivariance_residual, shape_metrics
from .provenance import anon_id, environment_manifest, source_leakage_audit, sha256_bytes

PACKAGE = "SST_Two_Harmonic_Phase_Chirality_Floquet_Blind_Falsifier"
VERSION = "v0.1.0"


def load_config(path: str | Path) -> dict:
    return json.loads(Path(path).read_text())


def condition_records(cfg: dict) -> list[dict]:
    out = []
    for chirality in ["COR", "CNR"]:
        for phase in cfg["phases"]:
            out.append({"chirality": chirality, "phase": float(phase), "envelope": cfg["envelope"]})
    return out


def run(cfg_path: str | Path, backend: str = "python", root: str | Path = ".", reveal: bool = False) -> Path:
    root = Path(root).resolve()
    cfg = load_config(cfg_path)
    outdir = root / f"{PACKAGE}_{VERSION}-outputs"
    if outdir.exists():
        shutil.rmtree(outdir)
    (outdir/"certification").mkdir(parents=True)
    (outdir/"logs").mkdir()
    (outdir/"data").mkdir()
    (outdir/"figures").mkdir()

    X0 = torus_trefoil(int(cfg["n_points"]))
    omega = float(cfg["omega"])
    T = 2*math.pi/omega
    n_cycles = int(cfg["n_cycles"])
    total_time = n_cycles*T
    salt = str(cfg["blind_salt"])

    base = dict(cfg)
    base["total_time"] = total_time
    base["dt"] = T/float(cfg["steps_per_cycle"])

    # Gate G0: geometry symmetry and analytic drive symmetry.
    geom_res = c3_geometry_residual(X0)
    drive_sym = {}
    for chir in ["COR", "CNR"]:
        drive_sym[chir] = c3_dynamic_symmetry_residual(omega, cfg["a1"], cfg["a2"], 0.371, chir)

    rows = []
    reveal_map = []
    for rec in condition_records(cfg):
        anon = anon_id(rec, salt)
        local = dict(base)
        local.update(rec)
        local["chirality"] = rec["chirality"]
        local["phase"] = rec["phase"]
        X1 = evolve(X0, local, backend=backend)
        m = shape_metrics(X0, X1)

        # Dynamic equivariance pair: A(t+T/3)=R A(t)R^-1 should hold only for CNR/flat.
        # Compare flow from R X0 at shifted start with R times flow from X0.
        duration = float(cfg["equivariance_duration_cycles"])*T
        Xa = evolve(X0, local, backend=backend, duration=duration, t_origin=0.0)
        R = rz(2*math.pi/3)
        X0r = X0 @ R.T
        Xb = evolve(X0r, local, backend=backend, duration=duration, t_origin=T/3.0)
        equiv = equivariance_residual(Xa, Xb, 2*math.pi/3)

        row = {
            "anonymous_id": anon,
            "phase_index": cfg["phases"].index(rec["phase"]),
            "equivariance_residual": equiv,
            **m,
        }
        rows.append(row)
        reveal_map.append({"anonymous_id": anon, **rec})

    # Aggregate blind gates using only anonymous metrics; reveal labels only after seal.
    eq = np.array([r["equivariance_residual"] for r in rows])
    # The preregistered pass condition is existence of one symmetry class with a tightly clustered low-residual branch
    # and a separated control branch; arm identity is revealed later.
    order = np.argsort(eq)
    half = len(eq)//2
    low = eq[order[:half]]
    high = eq[order[half:]]
    separation = float(np.median(high)/(np.median(low)+1e-30))
    low_max = float(np.max(low))

    gates = {
        "G0_trefoil_C3_geometry": {"value": geom_res, "threshold": cfg["gate_geometry_residual_max"], "pass": geom_res <= cfg["gate_geometry_residual_max"]},
        "G1_one_drive_class_has_exact_C3_dynamic_symmetry": {"blind_value_min": float(min(drive_sym.values())), "threshold": cfg["gate_drive_symmetry_residual_max"], "pass": min(drive_sym.values()) <= cfg["gate_drive_symmetry_residual_max"]},
        "G2_blind_equivariance_low_branch": {"value": low_max, "threshold": cfg["gate_equivariance_residual_max"], "pass": low_max <= cfg["gate_equivariance_residual_max"]},
        "G3_blind_control_separation": {"value": separation, "threshold_min": cfg["gate_control_separation_min"], "pass": separation >= cfg["gate_control_separation_min"]},
        "G4_numerical_length_drift": {"value": float(max(abs(r["length_rel_drift"]) for r in rows)), "threshold": cfg["gate_length_rel_drift_max"], "pass": max(abs(r["length_rel_drift"]) for r in rows) <= cfg["gate_length_rel_drift_max"]},
    }

    status = "PRELIMINARY_SURVIVED" if all(g["pass"] for g in gates.values()) else "PRELIMINARY_FAIL"
    formal_floquet = "SKIP_FORMAL_FLOQUET: no certified periodic orbit / finite-core closure in v0.1.0"

    with (outdir/"data"/"blind_metrics.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    manifest = {
        "package": PACKAGE, "version": VERSION, "backend": backend,
        "blind": True, "dimensionless": True,
        "sst_constants_used": False,
        "model_scope": "dimensionless LIA reference + trace-free bichromatic strain; not finite-core SST closure",
        "environment": environment_manifest(),
        "config": {k:v for k,v in cfg.items() if k != "blind_salt"},
    }
    (outdir/"manifest.json").write_text(json.dumps(manifest, indent=2))
    (outdir/"summary.json").write_text(json.dumps({"status": status, "gates": gates, "formal_floquet": formal_floquet}, indent=2))

    report = [
        f"# {PACKAGE} {VERSION} — Python reference run",
        "",
        f"Status: **{status}**",
        f"Backend: `{backend}`",
        "",
        "## Scope",
        "Dimensionless local-induction reference dynamics with a trace-free two-harmonic strain drive. This release tests the preregistered dynamical-symmetry architecture; it does **not** certify a finite-core SST mechanism.",
        "",
        "## Gates",
    ]
    for name, g in gates.items():
        report.append(f"- {name}: {'PASS' if g['pass'] else 'FAIL'} — {g}")
    report += ["", "## Formal Floquet gate", formal_floquet, ""]
    (outdir/"REPORT.md").write_text("\n".join(report))

    # Seal blind files before reveal.
    seal_entries = []
    for p in sorted(outdir.rglob("*")):
        if p.is_file():
            seal_entries.append({"file": str(p.relative_to(outdir)), "sha256": sha256_bytes(p.read_bytes())})
    seal = {"files": seal_entries}
    seal_bytes = json.dumps(seal, indent=2).encode()
    (outdir/"BLIND_SEAL.json").write_bytes(seal_bytes)

    private = root/"private_reveal"
    private.mkdir(exist_ok=True)
    (private/"reveal_map.json").write_text(json.dumps(reveal_map, indent=2))

    # Reveal summary is separate and only generated on request.
    if reveal:
        by_id = {m["anonymous_id"]: m for m in reveal_map}
        revealed = [{**r, **{k:v for k,v in by_id[r["anonymous_id"]].items() if k!="anonymous_id"}} for r in rows]
        (outdir/"REVEALED_metrics.json").write_text(json.dumps(revealed, indent=2))
        arm_stats = {}
        for chir in ["COR","CNR"]:
            vals = [r["equivariance_residual"] for r in revealed if r["chirality"]==chir]
            arm_stats[chir] = {"median_equivariance_residual": float(np.median(vals)), "max": float(np.max(vals)), "min": float(np.min(vals))}
        (outdir/"REVEALED_summary.json").write_text(json.dumps({"arm_stats": arm_stats, "analytic_drive_symmetry_residual": drive_sym}, indent=2))

    # Leakage audit on source tree is informational because scientific terms may appear in docs; denylist is SST-constant leakage only.
    audit = source_leakage_audit(root)
    (outdir/"certification"/"leakage_audit.json").write_text(json.dumps(audit, indent=2))
    return outdir


def make_zip(outdir: Path, reveal: bool) -> Path:
    suffix = "REVEALED" if reveal else "BLIND"
    zpath = outdir.parent / f"{PACKAGE}_{VERSION}-outputs_{suffix}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(outdir.rglob("*")):
            if not p.is_file():
                continue
            if not reveal and p.name.startswith("REVEALED"):
                continue
            z.write(p, p.relative_to(outdir.parent))
        if reveal:
            rm = outdir.parent/"private_reveal"/"reveal_map.json"
            if rm.exists():
                z.write(rm, rm.relative_to(outdir.parent))
    (zpath.with_suffix(zpath.suffix+".sha256")).write_text(sha256_bytes(zpath.read_bytes())+"  "+zpath.name+"\n")
    return zpath


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--backend", choices=["python","native"], default="python")
    ap.add_argument("--root", default=".")
    ap.add_argument("--reveal", action="store_true")
    ap.add_argument("--package", action="store_true")
    a = ap.parse_args()
    out = run(a.config, a.backend, a.root, reveal=a.reveal)
    print(out)
    if a.package:
        print(make_zip(out, reveal=False))
        if a.reveal:
            print(make_zip(out, reveal=True))

if __name__ == "__main__":
    main()
