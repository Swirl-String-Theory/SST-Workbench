from pathlib import Path
from experiment.readiness import readiness
import json
if __name__=='__main__':
    r=readiness(Path(__file__).resolve().parents[1]);print(json.dumps(r,indent=2));raise SystemExit(0 if r['ready'] else 2)
