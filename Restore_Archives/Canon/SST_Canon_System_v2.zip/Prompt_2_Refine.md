
MODE: STRUCTURE OPTIMIZATION

TASK:
- Improve logic flow
- Remove redundancy
- Ensure consistency
