@echo off
setlocal enabledelayedexpansion
if "%PYTHON%"=="" set PYTHON=python

REM Framed-helicity batch for user-selected SST knots/controls.
REM Outputs:
REM   results_helicity\helicity_inventory.csv
REM   results_helicity\helicity_results.csv
REM   results_helicity\helicity_summary.md

%PYTHON% scripts\sst_ffs_05_helicity_batch.py --ideal-file data\ideal.txt --config data\helicity_knot_config.csv --samples 768 --chunk 256 --outdir results_helicity
if errorlevel 1 exit /b 1

echo Done. Check results_helicity.
