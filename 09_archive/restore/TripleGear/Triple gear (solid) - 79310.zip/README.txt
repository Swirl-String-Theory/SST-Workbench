Triple gear (solid) by henryseg on Thingiverse: https://www.thingiverse.com/thing:79310

Summary:
This is a version of Triple gear which is not hollow - each gear is solid. This should hopefully make it easier to print on a home printer.