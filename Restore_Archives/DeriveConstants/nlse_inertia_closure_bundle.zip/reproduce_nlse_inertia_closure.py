#!/usr/bin/env python3
"""
Reproduce the NLSE/Gross--Pitaevskii route to the SST/VAM inertia closure.

Key equations:
    i hbar psi_t = [-hbar^2/(2m*) Laplacian + g(|psi|^2-n0)] psi
    v = (hbar/m*) grad S
    Gamma_q = h/m*
    c_s^2 = g n0/m*
    xi = hbar/(sqrt(2) m* c_s)
    Delta E_boost = 1/2 M_NLS u^2

Closure target:
    Delta E/E0 = u^2/c_ref^2.

NLSE conditional closure:
    E0 = 1/2 M_NLS c_s^2  =>  Delta E/E0 = u^2/c_s^2.

This script checks compatibility of the canonical SST circulation
Gamma0 = 2*pi*r_c*v_swirl and core radius xi=r_c with c_s=c_light.
"""
from __future__ import annotations

import argparse
import csv
import math
from dataclasses import dataclass, asdict
from pathlib import Path

# SI constants
HBAR = 1.054571817e-34       # J s
H = 6.62607015e-34           # J s
C_LIGHT = 2.99792458e8       # m/s
M_E = 9.1093837015e-31       # kg
E_ELECTRON = M_E * C_LIGHT**2

# SST/VAM canonical constants
R_C = 1.40897017e-15         # m
V_SWIRL = 1.09384563e6       # m/s
GAMMA0 = 2.0 * math.pi * R_C * V_SWIRL


@dataclass(frozen=True)
class Scenario:
    scenario: str
    constraint_1: str
    constraint_2: str
    m_star_kg: float
    m_star_over_me: float
    gamma_quantum_m2_s: float
    gamma_over_gamma0: float
    xi_m: float
    xi_over_rc: float
    c_s_m_s: float
    c_s_over_vswirl: float
    c_s_over_clight: float
    notes: str


def gamma_quantum(m_star: float) -> float:
    return H / m_star


def sound_from_m_xi(m_star: float, xi: float) -> float:
    return HBAR / (math.sqrt(2.0) * m_star * xi)


def mass_from_gamma(gamma: float) -> float:
    return H / gamma


def mass_from_xi_cs(xi: float, c_s: float) -> float:
    return HBAR / (math.sqrt(2.0) * xi * c_s)


def xi_from_m_cs(m_star: float, c_s: float) -> float:
    return HBAR / (math.sqrt(2.0) * m_star * c_s)


def build_scenarios() -> list[Scenario]:
    out: list[Scenario] = []

    # A: Preserve canonical circulation and identify healing length with r_c.
    m_a = mass_from_gamma(GAMMA0)
    cs_a = sound_from_m_xi(m_a, R_C)
    xi_a = R_C
    out.append(Scenario(
        scenario="A_quantized_circulation_plus_core_radius",
        constraint_1="Gamma_q = Gamma0 = 2*pi*r_c*v_swirl",
        constraint_2="xi = r_c",
        m_star_kg=m_a,
        m_star_over_me=m_a / M_E,
        gamma_quantum_m2_s=gamma_quantum(m_a),
        gamma_over_gamma0=gamma_quantum(m_a) / GAMMA0,
        xi_m=xi_a,
        xi_over_rc=xi_a / R_C,
        c_s_m_s=cs_a,
        c_s_over_vswirl=cs_a / V_SWIRL,
        c_s_over_clight=cs_a / C_LIGHT,
        notes="Predicts c_s = v_swirl/sqrt(2); not c_light.",
    ))

    # B: Preserve healing length and set causal speed to c_light.
    m_b = mass_from_xi_cs(R_C, C_LIGHT)
    cs_b = C_LIGHT
    xi_b = R_C
    out.append(Scenario(
        scenario="B_core_radius_plus_light_speed",
        constraint_1="xi = r_c",
        constraint_2="c_s = c_light",
        m_star_kg=m_b,
        m_star_over_me=m_b / M_E,
        gamma_quantum_m2_s=gamma_quantum(m_b),
        gamma_over_gamma0=gamma_quantum(m_b) / GAMMA0,
        xi_m=xi_b,
        xi_over_rc=xi_b / R_C,
        c_s_m_s=cs_b,
        c_s_over_vswirl=cs_b / V_SWIRL,
        c_s_over_clight=cs_b / C_LIGHT,
        notes="Requires Gamma_q/Gamma0 = sqrt(2)*c_light/v_swirl.",
    ))

    # C: Preserve canonical circulation and set causal speed to c_light.
    m_c = mass_from_gamma(GAMMA0)
    cs_c = C_LIGHT
    xi_c = xi_from_m_cs(m_c, cs_c)
    out.append(Scenario(
        scenario="C_quantized_circulation_plus_light_speed",
        constraint_1="Gamma_q = Gamma0",
        constraint_2="c_s = c_light",
        m_star_kg=m_c,
        m_star_over_me=m_c / M_E,
        gamma_quantum_m2_s=gamma_quantum(m_c),
        gamma_over_gamma0=gamma_quantum(m_c) / GAMMA0,
        xi_m=xi_c,
        xi_over_rc=xi_c / R_C,
        c_s_m_s=cs_c,
        c_s_over_vswirl=cs_c / V_SWIRL,
        c_s_over_clight=cs_c / C_LIGHT,
        notes="Requires xi/r_c = v_swirl/(sqrt(2)*c_light).",
    ))

    # D: Preserve healing length and set acoustic speed to v_swirl.
    m_d = mass_from_xi_cs(R_C, V_SWIRL)
    cs_d = V_SWIRL
    xi_d = R_C
    out.append(Scenario(
        scenario="D_core_radius_plus_swirl_speed",
        constraint_1="xi = r_c",
        constraint_2="c_s = v_swirl",
        m_star_kg=m_d,
        m_star_over_me=m_d / M_E,
        gamma_quantum_m2_s=gamma_quantum(m_d),
        gamma_over_gamma0=gamma_quantum(m_d) / GAMMA0,
        xi_m=xi_d,
        xi_over_rc=xi_d / R_C,
        c_s_m_s=cs_d,
        c_s_over_vswirl=cs_d / V_SWIRL,
        c_s_over_clight=cs_d / C_LIGHT,
        notes="Requires Gamma_q = sqrt(2)*Gamma0.",
    ))

    return out


def n_required(E0: float, m_star: float, c_ref: float) -> float:
    """N required by E0 = 1/2 (m_star N) c_ref^2."""
    return 2.0 * E0 / (m_star * c_ref**2)


def write_csv(path: Path, rows: list[Scenario]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def main() -> int:
    parser = argparse.ArgumentParser(description="NLSE/GPE inertia-closure diagnostics for SST/VAM.")
    parser.add_argument("--csv", type=Path, default=Path("nlse_inertia_closure_scenarios.csv"))
    parser.add_argument("--E0", type=float, default=E_ELECTRON,
                        help="Defect rest energy in joule; default electron rest energy m_e c^2.")
    args = parser.parse_args()

    scenarios = build_scenarios()
    write_csv(args.csv, scenarios)

    print("NLSE/Gross--Pitaevskii SST inertia-closure diagnostics")
    print("=======================================================")
    print(f"r_c        = {R_C:.12e} m")
    print(f"v_swirl    = {V_SWIRL:.12e} m/s")
    print(f"c_light    = {C_LIGHT:.12e} m/s")
    print(f"Gamma0     = 2*pi*r_c*v_swirl = {GAMMA0:.12e} m^2/s")
    print(f"E0 input   = {args.E0:.12e} J")
    print()

    for s in scenarios:
        print(s.scenario)
        print("-" * len(s.scenario))
        print(f"{s.constraint_1}; {s.constraint_2}")
        print(f"m_star              = {s.m_star_kg:.12e} kg = {s.m_star_over_me:.9g} m_e")
        print(f"Gamma_q/Gamma0      = {s.gamma_over_gamma0:.12g}")
        print(f"xi/r_c              = {s.xi_over_rc:.12g}")
        print(f"c_s/v_swirl         = {s.c_s_over_vswirl:.12g}")
        print(f"c_s/c_light         = {s.c_s_over_clight:.12g}")
        print(f"N_req(c_s)          = {n_required(args.E0, s.m_star_kg, s.c_s_m_s):.12g}")
        print(f"N_req(c_light)      = {n_required(args.E0, s.m_star_kg, C_LIGHT):.12g}")
        print(f"N_req(v_swirl)      = {n_required(args.E0, s.m_star_kg, V_SWIRL):.12g}")
        print(f"note                = {s.notes}")
        print()

    print("Interpretation")
    print("--------------")
    print("NLSE/GPE gives an exact Galilean boost energy shift DeltaE = 1/2 M_NLS u^2.")
    print("If E0 = 1/2 M_NLS c_s^2, then DeltaE/E0 = u^2/c_s^2.")
    print("With Gamma_q=Gamma0 and xi=r_c, the model predicts c_s = v_swirl/sqrt(2), not c_light.")
    print("Therefore NLSE closes the acoustic version conditionally, but the light-speed version still needs an extra renormalization/causal layer.")
    print(f"CSV written to: {args.csv.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
