from __future__ import annotations

import argparse
import json
from pathlib import Path
import sqlite3
import sys

from .builder import build_catalog
from .downloader import download, write_manifest
from .page_fetch import fetch_raw_page
from .validate import validate


def load_config(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def cmd_download(args, config, root):
    out_root = (root / config["output_root"]).resolve()
    source_dir = out_root / "_source"
    results = []
    for ds in config["datasets"]:
        print(f"[download] {ds['name']}: {ds['url']}")
        results.append(download(ds["url"], source_dir / ds["filename"], ds["name"]))
    write_manifest(results, source_dir / "SOURCE_MANIFEST.json")
    print(json.dumps([r.__dict__ for r in results], indent=2))


def cmd_build(args, config, root):
    print(json.dumps(build_catalog(config, root), indent=2))


def cmd_validate(args, config, root):
    report = validate(config, root)
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["status"] == "PASS" else 2)


def cmd_lookup(args, config, root):
    out_root = (root / config["output_root"]).resolve()
    db = out_root / "_catalog" / "catalog.sqlite3"
    con = sqlite3.connect(db)
    row = con.execute("SELECT * FROM objects WHERE id=?", (args.id,)).fetchone()
    if row is None:
        print(f"Not found: {args.id}", file=sys.stderr); raise SystemExit(1)
    cols = [x[0] for x in con.execute("SELECT * FROM objects LIMIT 0").description]
    data = dict(zip(cols, row))
    data["invariants"] = [
        {"predicate": p, "value": v}
        for p, v in con.execute("SELECT predicate,value FROM invariants WHERE object_id=? ORDER BY predicate", (args.id,))
    ]
    con.close()
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_fetch_page(args, config, root):
    out_root = (root / config["output_root"]).resolve()
    db = out_root / "_catalog" / "catalog.sqlite3"
    con = sqlite3.connect(db)
    row = con.execute("SELECT relpath FROM objects WHERE id=?", (args.id,)).fetchone(); con.close()
    if row is None:
        print(f"Not found in local catalog: {args.id}", file=sys.stderr); raise SystemExit(1)
    dest = out_root / row[0] / "page.wikitext"
    url = fetch_raw_page(args.id, dest, args.delay)
    print(f"Saved {args.id}: {dest}\nSource: {url}")


def main(argv=None):
    p = argparse.ArgumentParser(description="Katlas RDF importer and offline catalog builder")
    p.add_argument("--config", default="config.json")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("download")
    sub.add_parser("build")
    sub.add_parser("validate")
    lookup = sub.add_parser("lookup"); lookup.add_argument("id")
    fetch = sub.add_parser("fetch-page"); fetch.add_argument("id"); fetch.add_argument("--delay", type=float, default=0.8)
    args = p.parse_args(argv)
    config_path = Path(args.config).resolve()
    root = config_path.parent
    config = load_config(config_path)
    {"download":cmd_download,"build":cmd_build,"validate":cmd_validate,"lookup":cmd_lookup,"fetch-page":cmd_fetch_page}[args.cmd](args, config, root)

if __name__ == "__main__":
    main()
