# SST Fractional Filament-Sea / Attachment-Barrier Research Package

This package contains a reproducible Python workflow for testing a research-track SST idea inspired by fractional Fermi seas:

\[
\vartheta_\ell(q)=\frac{1}{\ell}\Theta(\ell q_0-|q|),
\]

where \(q\) is interpreted as a torsion/Kelvin/R-phase wavenumber along a vortex filament or knot.

The package is not a claim that the cold-atom experiment directly proves SST. It is a numerical bridge:

\[
\text{fractional mode-space occupancy}
\rightarrow
\text{filament torsion spectrum}
\rightarrow
\text{attachment / Pauli-barrier diagnostic}.
\]

## Current SST taxonomy used here

Use the corrected light-quark assignment:

\[
u \longleftrightarrow 5_2,
\qquad
d \longleftrightarrow 6_1.
\]

The older \(6_2/7_4\) mapping is deprecated and should not be used for the light-quark sector.

Recommended ideal-knot IDs in `ideal.txt`:

\[
3_1 \rightarrow \texttt{3:1:1},
\qquad
5_2 \rightarrow \texttt{5:2:1},
\qquad
6_1 \rightarrow \texttt{6:1:1}.
\]

Baryon bookkeeping under the corrected taxonomy:

\[
p \sim uud \sim 5_2+5_2+6_1,
\]

\[
n \sim udd \sim 5_2+6_1+6_1.
\]

## Package layout

```text
sst_ffs_research_package/
  README.md
  requirements.txt
  run_all_windows.bat
  run_all_unix.sh
  run_extended_windows.bat
  run_extended_unix.sh
  scripts/
    sst_ffs_00_reproduce_g1.py
    sst_ffs_01_rosetta_spectrum.py
    sst_ffs_02_filament_projection.py
    sst_ffs_02_filament_projection_ideal.py
    sst_ffs_03_attachment_threshold_scan.py
  data/
    ideal.txt
  example_outputs/
    sst_ffs_00_results/
    sst_ffs_02_ideal_3_1_1_results/
    sst_ffs_03_ideal_3_1_1_results/
```

## Installation

Python 3.10+ is recommended.

```bash
python -m venv .venv
```

Windows:

```bat
.venv\Scripts\activate
pip install -r requirements.txt
```

Linux/macOS:

```bash
source .venv/bin/activate
pip install -r requirements.txt
```

`SSTcore` is optional. The scripts try:

```python
import SSTcore as sst
```

If SSTcore is unavailable, they use the canonical fallback values:

\[
\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}=1.09384563\times10^6\,{\rm m\,s^{-1}},
\]

\[
r_c=1.40897017\times10^{-15}\,{\rm m},
\]

\[
\rho_{\!f}=7.0\times10^{-7}\,{\rm kg\,m^{-3}},
\]

\[
\Gamma_0=9.68361918\times10^{-9}\,{\rm m^2\,s^{-1}}.
\]

## Fast full run

Windows:

```bat
run_all_windows.bat
```

Linux/macOS:

```bash
./run_all_unix.sh
```

This runs:

1. synthetic \(G^{(1)}\) demo fit,
2. analytic Rosetta spectrum,
3. ideal-knot filament projection for `3:1:1`, `5:2:1`, and `6:1:1`,
4. attachment-threshold scans for the same knots.

Outputs are written to:

```text
results/
```

## Extended local analysis

For a more serious stability/convergence scan:

Windows:

```bat
run_extended_windows.bat
```

Linux/macOS:

```bash
./run_extended_unix.sh
```

This tests:

\[
N\in\{2048,4096,8192\},
\qquad
\text{smooth width}\in\{5,9,15\}.
\]

The goal is to verify whether:

\[
\ell_{\rm eff,95},
\qquad
\mathcal{B}_{\rm actual},
\qquad
F_\ell=\frac{\sum_{|q|\le \ell q_0}P(q)}{\sum_q P(q)}
\]

are stable under discretization and smoothing.

Outputs are written to:

```text
results_ext/
```

## Script 00: reproduce or fit \(G^{(1)}(x)\)

File:

```text
scripts/sst_ffs_00_reproduce_g1.py
```

Purpose:

Fit a one-body/phase correlator with:

\[
G^{(1)}(x)
=
A\,\frac{\sin(q_{\rm edge}x)}{q_{\rm edge}x}
e^{-x/\xi}
+B.
\]

Run demo:

```bash
python scripts/sst_ffs_00_reproduce_g1.py --demo --ell-demo 2 --outdir results/00_demo
```

Run on real CSV data:

```bash
python scripts/sst_ffs_00_reproduce_g1.py --input g1_data.csv --x-unit um --outdir results/00_real
```

Expected CSV columns are flexible, but safest is:

```csv
x,g1
0.0,1.0
...
```

The fitted edge gives:

\[
\ell_{\rm fit}=\frac{q_{\rm edge}}{q_0},
\qquad
x_1=\frac{\pi}{q_{\rm edge}},
\qquad
f_{\rm edge}=\frac{\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}q_{\rm edge}}{2\pi}.
\]

## Script 01: analytic Rosetta spectrum

File:

```text
scripts/sst_ffs_01_rosetta_spectrum.py
```

Purpose:

Compute the ideal fractional sector:

\[
\vartheta_\ell(q)=\frac{1}{\ell}\Theta(\ell q_0-|q|)
\]

with:

\[
\mathcal{N}_{\rm line}=\frac{q_0}{\pi},
\]

\[
M_2^{(\ell)}=\frac{\ell^2 q_0^3}{3\pi},
\]

\[
G^{(1)}_\ell(s)=\frac{\sin(\ell q_0s)}{\ell q_0s},
\]

\[
f_\ell=\frac{\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}\ell q_0}{2\pi}.
\]

Run:

```bash
python scripts/sst_ffs_01_rosetta_spectrum.py --n-line-um-inv 0.5 --ells 1 2 4 8 13 21 28 34 --outdir results/01_rosetta
```

## Script 02: filament projection

Base file:

```text
scripts/sst_ffs_02_filament_projection.py
```

Ideal-knot version:

```text
scripts/sst_ffs_02_filament_projection_ideal.py
```

The ideal-knot version can directly parse Brian Gilbert `ideal.txt` Fourier blocks:

\[
\mathbf{X}(t)=
\sum_i \mathbf{A}_i\cos(it)+\mathbf{B}_i\sin(it).
\]

Run trefoil:

```bash
python scripts/sst_ffs_02_filament_projection_ideal.py \
  --curve ideal \
  --ideal-file data/ideal.txt \
  --ideal-id 3:1:1 \
  --natural-scale \
  --n 4096 \
  --smooth-width 9 \
  --ells 1 2 4 8 13 21 28 34 55 \
  --outdir results/02_ideal_3_1_1
```

Run corrected quark candidates:

```bash
python scripts/sst_ffs_02_filament_projection_ideal.py \
  --curve ideal \
  --ideal-file data/ideal.txt \
  --ideal-id 5:2:1 \
  --natural-scale \
  --n 4096 \
  --smooth-width 9 \
  --ells 1 2 4 8 13 21 28 34 55 \
  --outdir results/02_ideal_5_2_1
```

```bash
python scripts/sst_ffs_02_filament_projection_ideal.py \
  --curve ideal \
  --ideal-file data/ideal.txt \
  --ideal-id 6:1:1 \
  --natural-scale \
  --n 4096 \
  --smooth-width 9 \
  --ells 1 2 4 8 13 21 28 34 55 \
  --outdir results/02_ideal_6_1_1
```

The script computes:

\[
\tau(s)=
\frac{
\left(\mathbf{X}'(s)\times\mathbf{X}''(s)\right)\cdot\mathbf{X}'''(s)
}{
\left\lVert \mathbf{X}'(s)\times\mathbf{X}''(s)\right\rVert^2
},
\]

\[
\varphi(s)=\int_0^s\tau(s')\,ds',
\]

\[
u(s)=e^{i\varphi(s)},
\]

\[
P(q)=|\mathcal{F}\{u(s)-\langle u\rangle\}|^2.
\]

Important diagnostics:

\[
q_{95}:
\quad
\frac{\sum_{|q|\le q_{95}}P(q)}{\sum_q P(q)}
=0.95,
\]

\[
\ell_{\rm eff,95}=\frac{q_{95}}{q_0}.
\]

## Script 03: attachment-threshold scan

File:

```text
scripts/sst_ffs_03_attachment_threshold_scan.py
```

Purpose:

Convert the fractional-sector model or actual spectrum into an attachment-barrier diagnostic.

The clean dimensionless top-hat barrier is:

\[
\mathcal{B}_\ell
=
\frac{\langle q^2\rangle_\ell}{q_{\rm crit}^2}
=
\frac{\ell^2 q_0^2}{3q_{\rm crit}^2}
=
\frac{\ell^2(q_0a_{\rm crit})^2}{3}.
\]

Default:

\[
a_{\rm crit}=r_c,
\qquad
q_{\rm crit}=r_c^{-1}.
\]

Run after script 02:

```bash
python scripts/sst_ffs_03_attachment_threshold_scan.py \
  --summary-csv results/02_ideal_3_1_1/sst_ffs_02_summary.csv \
  --spectrum-csv results/02_ideal_3_1_1/sst_ffs_02_spectrum.csv \
  --ells 1 2 4 8 13 21 28 34 55 89 \
  --outdir results/03_threshold_3_1_1
```

Change the locking length:

```bash
python scripts/sst_ffs_03_attachment_threshold_scan.py \
  --summary-csv results/02_ideal_3_1_1/sst_ffs_02_summary.csv \
  --spectrum-csv results/02_ideal_3_1_1/sst_ffs_02_spectrum.csv \
  --a-crit-m 2.0e-15 \
  --ells 1 2 4 8 13 21 28 34 55 89 \
  --outdir results/03_threshold_3_1_1_acrit_2fm
```

## How to interpret results

The current research-track interpretation is:

\[
\text{fermion-like sector}
=
\text{chiral knot or confined chiral twist subknot}
+
\text{half-exchange/framing}
+
\text{supercritical torsion/R-phase attachment barrier}.
\]

A low-order top-hat fractional sector is not sufficient by itself. The actual spectrum matters.

Key quantities:

\[
F_\ell
=
\frac{\sum_{|q|\le \ell q_0}P(q)}{\sum_qP(q)}.
\]

If \(F_\ell\) jumps sharply near a small integer sector, the knot resembles a simple fractional sea. If \(F_\ell\) only approaches 0.95 at high \(\ell\), the knot has a high-bandwidth torsion/R-phase spectrum.

\[
\mathcal{B}_{\rm actual}
=
\frac{\langle q^2\rangle_{\rm power}}{r_c^{-2}}.
\]

If:

\[
\mathcal{B}_{\rm actual}<1,
\]

the spectrum is subcritical under the \(r_c\)-locking criterion.

If:

\[
\mathcal{B}_{\rm actual}\gtrsim1,
\]

the spectrum is supercritical and supports an attachment-suppressed / Pauli-barrier-like interpretation.

## Known result included in example outputs

For the ideal trefoil `3:1:1`, using natural SST scaling, the earlier run found:

\[
L_{\rm phys}\approx1.44942342\times10^{-13}\,{\rm m},
\]

\[
q_0\approx4.33495501\times10^{13}\,{\rm m^{-1}},
\]

\[
\ell_{\rm eff,95}\approx21.
\]

With the top-hat threshold and \(a_{\rm crit}=r_c\):

\[
\ell_{\rm crit}\approx28.36.
\]

But the actual spectral moment from the reconstructed torsion/R-phase spectrum can be supercritical:

\[
\mathcal{B}_{\rm actual}\approx3.36.
\]

Therefore the trefoil is not simply an \(\ell=2\) or \(\ell=4\) fractional sea. Its actual high-\(q\) torsion content is the relevant candidate mechanism for an SST Pauli/attachment barrier.

## Recommended next local analyses

1. Run `5:2:1` and `6:1:1` with the extended scan.
2. Compare:
   \[
   \ell_{\rm eff,95}(3_1),\quad
   \ell_{\rm eff,95}(5_2),\quad
   \ell_{\rm eff,95}(6_1).
   \]
3. Compare:
   \[
   \mathcal{B}_{\rm actual}(3_1),\quad
   \mathcal{B}_{\rm actual}(5_2),\quad
   \mathcal{B}_{\rm actual}(6_1).
   \]
4. Test whether \(5_2\) and \(6_1\) have systematically different barrier signatures.
5. Only after convergence is stable, write a research-track canon block.

## Minimal citation block

```latex
\begin{thebibliography}{99}

\bibitem{Zeng2026FractionalFermiSeas}
Y.~Zeng, A.~Bastianello, S.~Dhar, Z.~Wang, X.~Yu, M.~Horvath,
G.~E.~Astrakharchik, Y.~Guo, H.-C.~N\"agerl, and M.~Landini,
``Realization of fractional Fermi seas,''
arXiv:2602.17657 (2026).
doi: \texttt{10.48550/arXiv.2602.17657}.

\bibitem{Haldane1991FractionalStatistics}
F.~D.~M.~Haldane,
``Fractional statistics in arbitrary dimensions: A generalization of the Pauli principle,''
Physical Review Letters \textbf{67}, 937--940 (1991).
doi: \texttt{10.1103/PhysRevLett.67.937}.

\bibitem{WilczekZee1983}
F.~Wilczek and A.~Zee,
``Linking Numbers, Spin, and Statistics of Solitons,''
Physical Review Letters \textbf{51}, 2250--2252 (1983).
doi: \texttt{10.1103/PhysRevLett.51.2250}.

\bibitem{FinkelsteinRubinstein1968}
D.~Finkelstein and J.~Rubinstein,
``Connection between spin, statistics, and kinks,''
Journal of Mathematical Physics \textbf{9}, 1762--1779 (1968).
doi: \texttt{10.1063/1.1664500}.

\end{thebibliography}
```
