# VALIDATION — SST Explicit Closed Vortex-Thread Blind Falsifier v0.2.0

## Generation-environment status

### Static / Python validation

- `python -m compileall`: **PASS**.
- pure-Python kernel self-test: **PASS**.
- explicit closed-loop residual on the self-test bundle: \(7.21\times10^{-17}\).
- multi-step common-boost intrinsic shape residual: \(3.30\times10^{-16}R_g\).
- initial self-test thread clearance: \(2.14R_g\).
- finite-segment Python reference path: **PASS**.

### Synthetic blind campaign

A synthetic trefoil and a two-component link were run through the complete QUICK blind workflow, including commitment verification, opaque cases, RK4 trajectories, closed-thread checks, remote-return checks and unblinding.

Result: **2/2 v0.2.0 PASS**.

Representative synthetic trefoil values:

- G1 common-boost covariance: \(3.82\times10^{-16}R_g\);
- G2 translation covariance: \(3.32\times10^{-15}R_g\);
- G3 rotation covariance: \(3.29\times10^{-16}R_g\);
- G4 closed-filament residual: \(6.64\times10^{-17}\);
- G6 mid-vs-far return effect / main response: \(2.38\times10^{-5}\);
- explicit radial-thread response: \(1.33\times10^{-4}R_g\).

### Reconstructed real-v0.1 geometry smoke

Three centerlines were reconstructed from the blinded N=128 cases in the supplied real v0.1.0 output archive and rerun through the v0.2.0 QUICK Python-reference chain.  All three completed with **structural PASS + thread-model PASS**.  This checks compatibility with the geometry shape/scale actually present in the user campaign; it is not a substitute for rerunning v0.2.0 on the original `KnotPlot\knots\final` files.

### Synthetic fixed-core extended ladder

A synthetic trefoil was run at

\[
N=128,256,512
\]

with the same \(a_k/R_g=0.10\), same final time and same orientation ensemble.

Orientation-averaged explicit-thread response:

\[
6.7473\times10^{-5},\quad
6.7397\times10^{-5},\quad
6.7371\times10^{-5}.
\]

The \(256\rightarrow512\) relative change was

\[
3.82\times10^{-4}=0.0382\%,
\]

therefore **CERTIFIED_PASS** under the 0.5% criterion.

### Holdout-runner smoke test

The prior-holdout driver was exercised end-to-end on synthetic files with a reduced \(N\)/time ladder.  Both selected filenames completed and the spatial/temporal comparison logic returned **PASS**.  This validates runner plumbing only; it is not a certification result for the user's real `link_0.3.1` or `torus_6.21` datasets.

## Real v0.1.0 result ingestion

`RESULTS_v0.1.0_BASELINE.json` was generated from the user-supplied `outputs_extended_20260820_195749.zip` and freezes the numerical basis for this release's design choices and prior holdout selection.

## Native C++ status in the generation container

The container used to assemble v0.2.0 does not have the `pybind11` package/headers installed, so a C++ extension could not be compiled here.  A native PASS is therefore **not claimed**.

On Windows, both `run_all.cmd` and `run_all_extended.cmd` require:

1. strict C++17/pybind11 build;
2. native-vs-Python self-kernel parity;
3. native-vs-Python finite-segment parity;
4. multi-step common-boost self-test;

before a real dataset campaign begins.

## Remaining epistemic limitation

The closed source-organized loops are an explicit physically admissible vortex-filament **candidate model**.  v0.2.0 does not yet derive from SST Canon:

- the number of Earth/Sun threads;
- their circulation distribution;
- source distance dependence;
- their physical core size;
- or a mapping from source mass to vortex-thread flux.

Those remain falsifiable inputs for a future calibrated release.
