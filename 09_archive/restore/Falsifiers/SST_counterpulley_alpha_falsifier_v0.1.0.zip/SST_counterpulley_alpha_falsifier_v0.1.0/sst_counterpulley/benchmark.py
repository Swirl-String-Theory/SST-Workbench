"""Post-hoc alpha benchmark.

This module is intentionally separate from physics.py so blind campaign outputs can be
frozen before importing the measured alpha value.
"""
from __future__ import annotations
import math
from typing import Any
from .constants import TREFOIL_ROPELENGTH_HIRES

ALPHA_INV_BENCHMARK = 137.035999177


def alpha0_inverse(ropelength: float = TREFOIL_ROPELENGTH_HIRES) -> float:
    return (8.0 * math.pi / 3.0) * float(ropelength)


def benchmark_blind(blind: dict[str, Any], *, ropelength: float = TREFOIL_ROPELENGTH_HIRES,
                    alpha_inv: float = ALPHA_INV_BENCHMARK) -> dict[str, Any]:
    a0 = alpha0_inverse(ropelength)
    target_delta_abs = alpha_inv - a0
    target_delta_rel = alpha_inv / a0 - 1.0
    G = float(blind["G_energy"])
    pred = a0 * G
    pred_delta_abs = pred - a0
    pred_delta_rel = G - 1.0
    return {
        "benchmark_phase": "POST_HOC_ONLY",
        "alpha_inverse_benchmark": float(alpha_inv),
        "ropelength_alpha_baseline": float(ropelength),
        "alpha0_inverse": float(a0),
        "target_delta_abs": float(target_delta_abs),
        "target_delta_rel": float(target_delta_rel),
        "G_energy_blind": G,
        "alpha_inverse_pred": float(pred),
        "pred_delta_abs": float(pred_delta_abs),
        "pred_delta_rel": float(pred_delta_rel),
        "abs_error_inverse": float(abs(pred - alpha_inv)),
        "relative_error_to_target_correction": float(abs(pred_delta_rel-target_delta_rel)/max(abs(target_delta_rel),1e-30)),
    }
