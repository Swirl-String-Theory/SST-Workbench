# PROMPT 4 — DOCUMENT ASSEMBLY

MODE: INTEGRATION

TASK:
Merge all sections into one LaTeX document.

ENSURE:
- Consistent notation
- No duplicates
