from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib
import json
import math

import numpy as np
import scipy.linalg as la
from scipy.optimize import minimize


@dataclass
class ProfileResult:
    r: np.ndarray
    f: np.ndarray
    energy: float
    success: bool
    message: str
    iterations: int
    grad_norm: float


@dataclass
class OperatorResult:
    h_parallel: np.ndarray
    h_transverse: np.ndarray
    mass: np.ndarray
    dilation: np.ndarray


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json_hash(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _assemble_profile(full_inner: np.ndarray, inner_value: float, outer_value: float) -> np.ndarray:
    return np.concatenate(([inner_value], full_inner, [outer_value]))


def solve_radial_profile(cfg: dict[str, Any]) -> ProfileResult:
    """Minimise one declared dimensionless radial finite-core functional.

    Functional:
      F = 2*pi int r [kappa/2 (f')^2
                      + winding^2 f^2/(2(r^2+a^2))
                      + beta/4 (f^2-bulk^2)^2
                      + pin/2 g(r) (f-f_pref(r))^2] dr.

    The optional pinning term is explicit and is reported as a model input. It is
    useful for testing filled-core profile families but cannot be hidden or fitted.
    """
    n = int(cfg["n_grid"])
    if n < 24:
        raise ValueError("n_grid must be >= 24")
    r_max = float(cfg["r_max"])
    r_eps = float(cfg.get("r_eps", 1.0e-4))
    if not (0 < r_eps < r_max):
        raise ValueError("Require 0 < r_eps < r_max")
    r = np.linspace(r_eps, r_max, n)
    dr = float(r[1] - r[0])

    kappa = float(cfg.get("kappa", 1.0))
    beta = float(cfg.get("beta", 1.0))
    winding = float(cfg.get("winding", 1.0))
    regulator = float(cfg.get("core_regulator", 0.0))
    bulk = float(cfg.get("bulk_value", 1.0))
    inner = float(cfg.get("inner_value", 0.0))
    outer = float(cfg.get("outer_value", bulk))
    pin = float(cfg.get("pin_strength", 0.0))
    pin_radius = float(cfg.get("pin_radius", 1.0))
    preferred_inner = float(cfg.get("preferred_inner", inner))

    if min(kappa, beta) <= 0:
        raise ValueError("kappa and beta must be positive")
    if regulator < 0 or pin < 0:
        raise ValueError("core_regulator and pin_strength must be nonnegative")

    # Smooth preregistered initial guess; it is not a target fit.
    if abs(inner) < 1.0e-14:
        guess = bulk * np.tanh(r / max(1.0, pin_radius))
    else:
        guess = inner + (bulk - inner) * (1.0 - np.exp(-(r / max(pin_radius, 1.0e-6)) ** 2))
    guess[0] = inner
    guess[-1] = outer
    x0 = guess[1:-1].copy()

    r_mid = 0.5 * (r[:-1] + r[1:])
    pin_shape = np.exp(-(r / max(pin_radius, 1.0e-12)) ** 2)
    preferred = preferred_inner + (bulk - preferred_inner) * (1.0 - np.exp(-(r / max(pin_radius, 1.0e-12)) ** 2))

    def value_and_grad(x: np.ndarray) -> tuple[float, np.ndarray]:
        f = _assemble_profile(x, inner, outer)
        df = np.diff(f)
        e_grad = math.pi * kappa * np.sum(r_mid * df * df / dr)
        centrifugal = 0.5 * winding * winding * f * f / (r * r + regulator * regulator)
        quartic = 0.25 * beta * (f * f - bulk * bulk) ** 2
        pinning = 0.5 * pin * pin_shape * (f - preferred) ** 2
        e_pot = 2.0 * math.pi * np.sum(r * dr * (centrifugal + quartic + pinning))
        energy = float(e_grad + e_pot)

        grad = np.zeros_like(f)
        c = 2.0 * math.pi * kappa * r_mid / dr
        # Derivative of sum pi*kappa*r_mid*(delta f)^2/dr.
        grad[:-1] -= c * df
        grad[1:] += c * df
        dpot = (
            winding * winding * f / (r * r + regulator * regulator)
            + beta * (f * f - bulk * bulk) * f
            + pin * pin_shape * (f - preferred)
        )
        grad += 2.0 * math.pi * r * dr * dpot
        return energy, grad[1:-1]

    res = minimize(
        fun=lambda x: value_and_grad(x)[0],
        x0=x0,
        jac=lambda x: value_and_grad(x)[1],
        method="L-BFGS-B",
        bounds=[(float(cfg.get("lower_bound", 0.0)), float(cfg.get("upper_bound", max(1.5, 1.2 * bulk))))] * len(x0),
        options={
            "maxiter": int(cfg.get("maxiter", 4000)),
            "ftol": float(cfg.get("ftol", 1.0e-13)),
            "gtol": float(cfg.get("gtol", 1.0e-9)),
            "maxls": 50,
        },
    )
    f = _assemble_profile(np.asarray(res.x), inner, outer)
    _, g = value_and_grad(np.asarray(res.x))
    return ProfileResult(
        r=r,
        f=f,
        energy=float(res.fun),
        success=bool(res.success),
        message=str(res.message),
        iterations=int(res.nit),
        grad_norm=float(np.linalg.norm(g) / math.sqrt(max(1, len(g)))),
    )


def build_core_operators(profile: ProfileResult, cfg: dict[str, Any]) -> OperatorResult:
    """Build amplitude and transverse second-variation operators.

    These are the Hessians of the same declared complex-field radial functional.
    Boundary values are fixed, so only interior degrees of freedom are retained.
    """
    r = profile.r
    f = profile.f
    dr = float(r[1] - r[0])
    ri = r[1:-1]
    fi = f[1:-1]
    m = len(ri)

    kappa = float(cfg.get("kappa", 1.0))
    beta = float(cfg.get("beta", 1.0))
    winding = float(cfg.get("winding", 1.0))
    regulator = float(cfg.get("core_regulator", 0.0))
    bulk = float(cfg.get("bulk_value", 1.0))
    pin = float(cfg.get("pin_strength", 0.0))
    pin_radius = float(cfg.get("pin_radius", 1.0))

    h_grad = np.zeros((m, m), dtype=float)
    r_mid = 0.5 * (r[:-1] + r[1:])
    # Hessian of each gradient edge term. Boundary rows are eliminated.
    for edge in range(len(r) - 1):
        coeff = 2.0 * math.pi * kappa * r_mid[edge] / dr
        left = edge - 1   # full index edge maps to interior edge-1
        right = edge      # full index edge+1 maps to interior edge
        if 0 <= left < m:
            h_grad[left, left] += coeff
        if 0 <= right < m:
            h_grad[right, right] += coeff
        if 0 <= left < m and 0 <= right < m:
            h_grad[left, right] -= coeff
            h_grad[right, left] -= coeff

    pin_shape = np.exp(-(ri / max(pin_radius, 1.0e-12)) ** 2)
    common = winding * winding / (ri * ri + regulator * regulator)
    v_parallel = common + beta * (3.0 * fi * fi - bulk * bulk) + pin * pin_shape
    # Phase/transverse channel of a U(1)-symmetric quartic term. The optional
    # scalar pin is intentionally omitted here because a density pin does not
    # supply phase stiffness; this asymmetry is declared in the report.
    v_transverse = common + beta * (fi * fi - bulk * bulk)

    weight = 2.0 * math.pi * ri * dr
    h_parallel = h_grad + np.diag(weight * v_parallel)
    h_transverse = h_grad + np.diag(weight * v_transverse)
    mass = np.diag(weight)

    fp = np.gradient(f, r)
    dilation = (-r * fp)[1:-1]
    if np.linalg.norm(dilation) < 1.0e-12:
        dilation = np.ones(m)
    return OperatorResult(h_parallel, h_transverse, mass, dilation)


def periodic_laplacian(n: int) -> np.ndarray:
    k = np.zeros((n, n), dtype=float)
    for i in range(n):
        j = (i + 1) % n
        k[i, i] += 1.0
        k[j, j] += 1.0
        k[i, j] -= 1.0
        k[j, i] -= 1.0
    return k


def load_square_matrix(path: Path) -> np.ndarray:
    arr = np.loadtxt(path, delimiter=",")
    if arr.ndim != 2 or arr.shape[0] != arr.shape[1]:
        raise ValueError(f"Matrix must be square: {path}")
    if not np.allclose(arr, arr.T, atol=1.0e-10, rtol=1.0e-10):
        raise ValueError(f"Matrix must be symmetric: {path}")
    return np.asarray(arr, dtype=float)


def build_contact_hessian(contact_cfg: dict[str, Any], n_cell: int, base_dir: Path) -> tuple[np.ndarray, dict[str, Any]]:
    kind = str(contact_cfg.get("kind", "none"))
    scale = float(contact_cfg.get("scale", 1.0))
    meta: dict[str, Any] = {"kind": kind, "scale": scale, "source_class": contact_cfg.get("source_class", "unspecified")}
    if kind == "none":
        return np.zeros((n_cell, n_cell)), meta
    if kind == "matrix_csv":
        path = (base_dir / str(contact_cfg["path"])).resolve()
        mat = load_square_matrix(path)
        if mat.shape != (n_cell, n_cell):
            raise ValueError("Contact matrix dimension differs from cell n_dof")
        meta.update({"path": str(path), "sha256": sha256_file(path)})
        return scale * mat, meta
    if kind != "edge_list":
        raise ValueError(f"Unknown contact kind: {kind}")
    path = (base_dir / str(contact_cfg["path"])).resolve()
    rows = np.genfromtxt(path, delimiter=",", names=True, dtype=None, encoding="utf-8")
    mat = np.zeros((n_cell, n_cell), dtype=float)
    count = 0
    total_lambda = 0.0
    rows_iter = np.atleast_1d(rows)
    for row in rows_iter:
        i, j, lam = int(row["i"]), int(row["j"]), float(row["lambda"])
        if not (0 <= i < n_cell and 0 <= j < n_cell and i != j and lam >= 0):
            raise ValueError(f"Invalid contact row {(i, j, lam)}")
        mat[i, i] += lam
        mat[j, j] += lam
        mat[i, j] -= lam
        mat[j, i] -= lam
        count += 1
        total_lambda += lam
    meta.update({"path": str(path), "sha256": sha256_file(path), "n_contacts": count, "lambda_sum": total_lambda})
    return scale * mat, meta


def build_cell_hessians(cell_cfg: dict[str, Any], base_dir: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    kind = str(cell_cfg.get("kind", "periodic_laplacian"))
    n = int(cell_cfg["n_dof"])
    if kind == "matrix_csv":
        p_path = (base_dir / str(cell_cfg["parallel_path"])).resolve()
        t_path = (base_dir / str(cell_cfg["transverse_path"])).resolve()
        hp = load_square_matrix(p_path)
        ht = load_square_matrix(t_path)
        if hp.shape != (n, n) or ht.shape != (n, n):
            raise ValueError("Cell matrix dimensions differ from n_dof")
        meta = {
            "kind": kind,
            "parallel_path": str(p_path),
            "transverse_path": str(t_path),
            "parallel_sha256": sha256_file(p_path),
            "transverse_sha256": sha256_file(t_path),
            "source_class": cell_cfg.get("source_class", "unspecified"),
        }
        return hp, ht, meta
    if kind != "periodic_laplacian":
        raise ValueError(f"Unknown cell Hessian kind: {kind}")
    lap = periodic_laplacian(n)
    stiffness = float(cell_cfg.get("stiffness", 1.0))
    hp = stiffness * lap + float(cell_cfg.get("parallel_shift", 1.0)) * np.eye(n)
    ht = stiffness * lap + float(cell_cfg.get("transverse_shift", 1.0)) * np.eye(n)
    meta = {
        "kind": kind,
        "n_dof": n,
        "stiffness": stiffness,
        "parallel_shift": float(cell_cfg.get("parallel_shift", 1.0)),
        "transverse_shift": float(cell_cfg.get("transverse_shift", 1.0)),
        "source_class": cell_cfg.get("source_class", "generated_demo"),
    }
    return hp, ht, meta


def positive_generalized_eigenvalues(h: np.ndarray, m: np.ndarray, threshold: float = 1.0e-9) -> np.ndarray:
    vals = la.eigvalsh(h, m, check_finite=True)
    vals = np.asarray(vals[np.isfinite(vals)], dtype=float)
    return np.sort(vals[vals > threshold])


def positive_eigenvalues(h: np.ndarray, threshold: float = 1.0e-9) -> np.ndarray:
    vals = la.eigvalsh(h, check_finite=True)
    vals = np.asarray(vals[np.isfinite(vals)], dtype=float)
    return np.sort(vals[vals > threshold])


def normalise_vector(v: np.ndarray, mass: np.ndarray | None = None) -> np.ndarray:
    if mass is None:
        norm = float(np.linalg.norm(v))
    else:
        norm = float(math.sqrt(max(0.0, v @ mass @ v)))
    if norm <= 1.0e-14:
        raise ValueError("Cannot normalise near-zero vector")
    return v / norm


def lowest_positive_mode(h: np.ndarray, threshold: float = 1.0e-9) -> tuple[float, np.ndarray]:
    vals, vecs = la.eigh(h, check_finite=True)
    for idx, val in enumerate(vals):
        if val > threshold:
            return float(val), normalise_vector(vecs[:, idx])
    raise ValueError("No positive cell mode")


def pairwise_low_spectrum(radial: np.ndarray, cell: np.ndarray, k: int) -> np.ndarray:
    sums = (radial[:, None] + cell[None, :]).ravel()
    sums = np.sort(sums[np.isfinite(sums)])
    return sums[: min(k, len(sums))]


def compute_weight(
    ops: OperatorResult,
    h_cell_parallel: np.ndarray,
    h_cell_transverse: np.ndarray,
    h_contact: np.ndarray,
    estimator: str,
    low_modes: int,
) -> tuple[float, dict[str, Any]]:
    radial_p = positive_generalized_eigenvalues(ops.h_parallel, ops.mass)
    radial_t = positive_generalized_eigenvalues(ops.h_transverse, ops.mass)
    if len(radial_p) == 0 or len(radial_t) == 0:
        raise ValueError("Core Hessian has no positive mode in one channel")
    cell_p = positive_eigenvalues(h_cell_parallel)
    cell_t = positive_eigenvalues(h_cell_transverse + h_contact)
    if len(cell_p) == 0 or len(cell_t) == 0:
        raise ValueError("Cell/contact Hessian has no positive mode in one channel")

    details: dict[str, Any] = {
        "radial_parallel_min": float(radial_p[0]),
        "radial_transverse_min": float(radial_t[0]),
        "cell_parallel_min": float(cell_p[0]),
        "cell_transverse_contact_min": float(cell_t[0]),
    }

    if estimator == "lowest_positive":
        lp = float(radial_p[0] + cell_p[0])
        lt = float(radial_t[0] + cell_t[0])
        details.update({"lambda_parallel": lp, "lambda_transverse": lt})
        return lt / lp, details

    if estimator == "low_spectrum_trace":
        spec_p = pairwise_low_spectrum(radial_p[:low_modes], cell_p[:low_modes], low_modes)
        spec_t = pairwise_low_spectrum(radial_t[:low_modes], cell_t[:low_modes], low_modes)
        lp = float(np.mean(spec_p))
        lt = float(np.mean(spec_t))
        details.update({"mean_parallel": lp, "mean_transverse": lt, "n_modes": int(min(len(spec_p), len(spec_t)))})
        return lt / lp, details

    if estimator != "dilation_rayleigh":
        raise ValueError(f"Unknown estimator: {estimator}")

    u = normalise_vector(ops.dilation, ops.mass)
    _, y_p = lowest_positive_mode(h_cell_parallel)
    _, y_t = lowest_positive_mode(h_cell_transverse + h_contact)
    qrp = float(u @ ops.h_parallel @ u)
    qrt = float(u @ ops.h_transverse @ u)
    qcp = float(y_p @ h_cell_parallel @ y_p)
    qct = float(y_t @ (h_cell_transverse + h_contact) @ y_t)
    lp = qrp + qcp
    lt = qrt + qct
    details.update({
        "rayleigh_radial_parallel": qrp,
        "rayleigh_radial_transverse": qrt,
        "rayleigh_cell_parallel": qcp,
        "rayleigh_cell_transverse_contact": qct,
        "lambda_parallel": lp,
        "lambda_transverse": lt,
    })
    return lt / lp, details


def derive_coefficients(cfg: dict[str, Any], base_dir: Path) -> dict[str, Any]:
    profile = solve_radial_profile(cfg["profile"])
    ops = build_core_operators(profile, cfg["profile"])
    hp, ht, cell_meta = build_cell_hessians(cfg["cell"], base_dir)
    hc, contact_meta = build_contact_hessian(cfg.get("contact", {"kind": "none"}), hp.shape[0], base_dir)

    estimator = str(cfg["closure"].get("estimator", "dilation_rayleigh"))
    low_modes = int(cfg["closure"].get("low_modes", 8))
    w_perp, estimator_details = compute_weight(ops, hp, ht, hc, estimator, low_modes)

    sigma_volume = float(cfg["closure"].get("sigma_volume", 3.0))
    angular_average = float(cfg["closure"].get("angular_projector_average", 2.0 / 3.0))
    chi_r = float(cfg["closure"].get("chi_R", 2.0))
    sigma = sigma_volume + angular_average * w_perp
    c2 = sigma / (4.0 * chi_r * chi_r)

    derivation_quality = "scientific_input"
    source_classes = {str(cell_meta.get("source_class")), str(contact_meta.get("source_class"))}
    if any("demo" in s or "synthetic" in s or "unspecified" in s for s in source_classes):
        derivation_quality = "demo_or_incomplete_input"

    return {
        "schema_version": "1.0",
        "profile": {
            "success": profile.success,
            "message": profile.message,
            "iterations": profile.iterations,
            "energy": profile.energy,
            "gradient_rms": profile.grad_norm,
            "n_grid": int(len(profile.r)),
            "r_max": float(profile.r[-1]),
            "f_min": float(np.min(profile.f)),
            "f_max": float(np.max(profile.f)),
            "f_core": float(profile.f[0]),
            "f_bulk": float(profile.f[-1]),
        },
        "operator": estimator_details,
        "cell": cell_meta,
        "contact": contact_meta,
        "closure": {
            "estimator": estimator,
            "low_modes": low_modes,
            "w_perp": float(w_perp),
            "sigma_volume": sigma_volume,
            "angular_projector_average": angular_average,
            "sigma": float(sigma),
            "chi_R": chi_r,
            "c2": float(c2),
        },
        "derivation_quality": derivation_quality,
    }
