# A055 v0.1.2 — Full production run analysis

## Execution

- preset: `full`
- backend: native C++17/OpenMP
- atlas: 82 objects = 35 knots + 47 links
- resolution ladder: 40, 80, 160 points/component
- embedding replicates: 16/resolution
- null trials: 10,000 per valid search
- BLIND seal verified before reveal

The Windows `run_all.cmd` stages were executed equivalently in the Linux validation environment.  The `.cmd` file itself is Windows-specific; native build, selftest, blind campaign, seal, reveal and packaging were all executed.

## Topological calibration

At N=160, native C++ with the v0.1.2 planarity-preserving PD construction returned:

- Hopf `L2a1`: `Lk = -1.0003857683` (absolute error from 1: 3.86e-4)
- Solomon `L4a1`: `Lk = -2.0045153838` (absolute error from 2: 4.52e-3)
- Borromean `L6a4`: pairwise `Lk = [0.00196166, -0.00300396, 0.00131199]`

All calibration errors are below the registered 0.02 tolerance.

Across the full link atlas, the median Gauss integer residual is 0.00602. Thirty of 47 links pass the complete linking-strength convergence/CV/integer-residual qualification.

## Blind qualification counts

- `min_distance`: 55/82 qualified (10 knots, 45 links)
- `abs_writhe`: 51/82 qualified (14 knots, 37 links)
- `linking_strength`: 30/47 links qualified
- `abs_neumann_energy`: 3/82 qualified
- `bend_energy`: 0/82 qualified

Thus v0.1.2 validates the topological-link and fixed-arclength-contact layers substantially better than v0.1.1, but the bending and regularized Neumann proxies remain resolution-unqualified.

## Historical 5_2 / 6_1 check

The corrected raw knot-space rank is 104/595 (fraction 0.17479), compared with 400/595 in v0.1.1 and 551/595 in v0.1.0.  This large shift demonstrates that the earlier random-lane/contact discretization materially affected the historical-pair diagnostic.

No scientific qualified rank is assigned because the registered knot-space requires all features and both objects do not jointly pass them.

For `5_2`:
- bending delta = 0.30419 (fail)
- Neumann delta = 0.54502 (fail)
- fixed-arclength minimum-distance delta = 0.03886 (pass)
- writhe delta = 0.03122 (pass)

For `6_1`:
- bending delta = 0.35509 (fail)
- Neumann delta = 0.54511 (fail)
- fixed-arclength minimum-distance delta = 0.14381 (pass under full 0.15 gate)
- writhe delta = 0.32960 (fail)

Conclusion: the historical pair is `UNRESOLVED`, not falsified.

## SM reveal

The visually strongest absolute fit remains in the W/Z/H target: `min_distance` on `6_2, L8a11, L8a12` gives log-RMS 5.14e-4 and passes the effect-size gate, but its within-search p=0.1374 and common-all familywise p=0.1412. It is therefore not statistically unusual.

The charged-lepton all-valid-domains familywise p=0.00550 is superficially smaller, but the winning fit has log-RMS 2.01245 and fails the registered effect-size gate by a very large margin. It is not a meaningful particle-spectrum match.

The corrected empirical-p-space global look-elsewhere p-value is 0.02130. This is driven by the charged-lepton *shape* rarity, not by a good mass fit; because the effect-size gate fails, it is not evidence for an SM mapping.

No SM group simultaneously provides a compelling globally corrected significance and a physically acceptable absolute log-RMS fit.

## Scientific disposition

- blindness/integrity: PASS
- native parity/selftest: PASS
- Hopf/Solomon/Borromean topology calibration: PASS
- fixed-arclength contact definition: PASS
- linking-strength numerical qualification: PARTIAL PASS (30/47 links)
- bending convergence: FAIL
- Neumann convergence: FAIL
- 5_2/6_1 physical selection: UNRESOLVED
- generic SM spectrum: NOT ESTABLISHED
- Higgs identification: NOT TESTED

The natural next step is A055 v0.2.0 with PKLSA/finite-core/Hessian/Kelvin/Floquet observables. The v0.1.2 topological/link calibration should be retained as an upstream invariant gate, while the failing artificial bending/Neumann PD proxies should not be promoted as physical observables.
