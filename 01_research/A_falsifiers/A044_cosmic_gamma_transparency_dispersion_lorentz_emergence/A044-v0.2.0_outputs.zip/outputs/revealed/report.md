# Reveal verdict

**OPEN_NO_INDEPENDENT_CANDIDATE** — supply at least two frozen non-null candidate velocity samples.
