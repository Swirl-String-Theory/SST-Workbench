# A054 v0.1.0 — REVEALED report

Blind seal verified: `a71a5d8e5b2871d581f4fcbf114168e69134967624afd26218e849f371440d6d`.

## Historical VAM/SST quark check

Historical mapping: `u -> 5_2`, `d -> 6_1` (twist-knot pair).

- Blind feature-space rank among knot pairs: **551/595**
- Rank fraction: **0.926050**
- Frozen feature distance: **3.28929521**

This is an independent adjacency diagnostic because `5_2/6_1` was not available to the blind stage.

## Exploratory SM mass-pattern reveal

- **charged_leptons**: best all-atlas proxy `abs_neumann_energy` -> ['3_1', 'L7a2', 'L8a21']; log-RMS=1.75241; null fraction=0.167.
- **up_quarks**: best all-atlas proxy `linking_strength` -> ['7_6', 'L7a5', 'L8a17']; log-RMS=1.79288; null fraction=0.833.
- **down_quarks**: best all-atlas proxy `abs_neumann_energy` -> ['3_1', '5_1', 'L8a21']; log-RMS=1.20215; null fraction=0.333.
- **massive_EW_Higgs**: best all-atlas proxy `contact_ratio` -> ['L4a1', 'L7a7', 'L8a13']; log-RMS=0.00050739; null fraction=0.667.

The triplet search fits one free overall scale and compares only the *shape* of three masses in log-space. The reported null fraction uses random intermediate target positions at the same total mass span and repeats the full atlas search.

## Mandatory interpretation limits

1. v0.1.0 does **not** identify a knot/link with an SM particle.
2. PD-derived embeddings are presentation ensembles, not PKLSA ideal/relaxed vortex equilibria.
3. Higgs spin-0/scalar dynamics, gauge charge, color, chirality, weak isospin, lifetime and couplings are **not tested**.
4. Quark masses are scheme/scale dependent; their reveal is diagnostic only.
5. A convincing next stage requires replacing the screening geometry with PKLSA/finite-core dynamics while keeping this blind/reveal protocol fixed.
