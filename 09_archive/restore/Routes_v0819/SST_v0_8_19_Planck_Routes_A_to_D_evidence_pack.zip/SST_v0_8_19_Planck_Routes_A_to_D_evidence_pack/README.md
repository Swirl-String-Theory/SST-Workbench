# SST v0.8.19 Planck-Time Route Candidates A--D Evidence Pack

**Epistemic status:** `[RESEARCH-TRACK]`, not canon proof.  
**Purpose:** share one self-contained package with Gemini/Claude for external audit of the Route-I heat guard and the four Planck-time candidate routes A--D.

This pack starts from the current `SST_CANON-v0.8.19.tex` / `SST_CANON-v0.8.19-research-track.tex` files and collects:

1. the Route-I heat-sector guard patch already prepared for v0.8.19;
2. a parallel audit script for the four possible Planck-time routes;
3. individual trial-and-error scripts/logs for Routes A, B, C, and D;
4. canon-ready LaTeX research-track blocks;
5. review prompts for Gemini/Claude.

## Bottom line

The four routes do **not** yet constitute independent derivations of Planck time.  They are candidate closures that reproduce the orthodox Planck time to about **0.286%** from SST-style non-`G`, non-`L_p`, non-`t_p` combinations.

Reference:

```text
t_p = 5.391246446662e-44 s
L_p = 1.616255023929e-35 m
G_N = 6.674300000000e-11 m^3 kg^-1 s^-2
F_gr^max = 3.025638910846e+43 N
```

## Candidate formulas

### Route A — line-density entropy / horizon piercing

```tex
\sigma_{m pierce}\Lambda_L
=
rac{1}{r_c^2}
rac{ho_{	ext{core}}}{ho_{\!f}}
rac{16}{\pi^2}
\left(rac{c}{\mathbf{v}_{\!oldsymbol{\circlearrowleft}}}ight)^6 .
```

Result:

```text
sigma_Lambda = 1.925039396852e+69 m^-2
ratio to 1/(2 L_p^2) = 1.005748499538
t_p(candidate) = 5.375817147521e-44 s
t_p/t_p_ref = 0.997138083133
```

### Route B — induced mode count

```tex
N_B
=
rac{32}{\pi^2}
rac{ho_{	ext{core}}}{ho_{\!f}}
\left(rac{c}{\mathbf{v}_{\!oldsymbol{\circlearrowleft}}}ight)^6 .
```

Result:

```text
N_B = 7.643164639827e+39
ratio to (r_c/L_p)^2 = 1.005748499538
t_p(candidate) = 5.375817147521e-44 s
t_p/t_p_ref = 0.997138083133
```

Relation to Route A:

```tex
N_B = 2r_c^2(\sigma_{m pierce}\Lambda_L)_A .
```

### Route C — pressure-susceptibility / Newton closure

```tex
G_C
=
rac{\pi^2}{32}
rac{ho_{\!f}}{ho_{	ext{core}}}
\left(rac{\mathbf{v}_{\!oldsymbol{\circlearrowleft}}}{c}ight)^5
rac{\mathbf{v}_{\!oldsymbol{\circlearrowleft}}^2 r_c}{M_e} .
```

Result:

```text
G_C = 6.636152035233e-11 m^3 kg^-1 s^-2
G_C/G_N = 0.994284349704
t_p(candidate) = 5.375817128248e-44 s
t_p/t_p_ref = 0.997138079558
```

### Route D — maximum-tension closure

```tex
F_D
=
rac{16}{\pi^2}
F_{m swirl}^{\max}
rac{ho_{	ext{core}}}{ho_{\!f}}
\left(rac{c}{\mathbf{v}_{\!oldsymbol{\circlearrowleft}}}ight)^7 .
```

Result:

```text
F_D = 3.043031505280e+43 N
F_D/F_gr^max = 1.005748403873
t_p(candidate) = 5.375817403190e-44 s
t_p/t_p_ref = 0.997138130556
```

Relation to Route C:

```tex
F_D = rac{c^4}{4G_C} .
```

## Interpretation

The evidence suggests two dual pairs:

```text
A/B = horizon microstate counting pair
C/D = bulk pressure / maximum tension pair
```

All four share the same small residual factor near:

```text
primary ratio high-side ≈ 1.005748499538
G_C/G_N low-side ≈ 0.994284349704
t_p ratio ≈ 0.997138083133
```

This suggests one missing angular/heat-kernel correction, not four unrelated coincidences.

## What reviewers should check

1. Dimensional consistency of every candidate formula.
2. Whether any formula secretly imports `G`, `L_p`, or `t_p`.
3. Whether the powers 5, 6, and 7 can be derived from a real SST phase-space / torsion / horizon-channel argument.
4. Whether the angular kernels `16/pi^2`, `32/pi^2`, `pi^2/32` can follow from stereology, Green functions, heat-kernel coefficients, or horizon mode counting.
5. Whether Route A/B and C/D can be unified by one microstructure theorem.

## How to run

```bash
cd scripts
python sst_planck_routes_A_to_D_candidate_summary.py
```

Individual scripts are under `evidence/route_*`.

## Canon discipline

These formulas should **not** be inserted into the main canon as derived facts.  They belong in the research-track document with status labels:

```text
[RESEARCH-TRACK]
[TRIAL]
[NOT DERIVED]
[OPEN: kernel theorem]
```
