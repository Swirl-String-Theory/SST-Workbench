from __future__ import annotations
import argparse, json
from pathlib import Path

def main() -> int:
    ap=argparse.ArgumentParser(description='Print compact gate diagnostics from a completed SST trefoil campaign.')
    ap.add_argument('out_dir')
    a=ap.parse_args()
    p=Path(a.out_dir)/'final_verdict.json'
    if not p.exists():
        raise SystemExit(f'Missing {p}')
    d=json.loads(p.read_text(encoding='utf-8'))
    print(f"Overall: {d.get('overall')}")
    for src,sc in d.get('unblinded_scores',{}).items():
        print(f"\n{src}: {sc.get('status')}")
        for g,v in sc.get('gates',{}).items(): print(f"  {g}: {'PASS' if v else 'FAIL'}")
        m=sc.get('metrics',{})
        keys=['shape_velocity_ratio','normalized_growth','jacobian_convergence','cross_jacobian_fraction','cross_growth_improvement','nearest_pair_cross_rate','control_growth_delta']
        print('  metrics:')
        for k in keys:
            if k in m: print(f"    {k}: {m[k]}")
    print('\nCircle nulls:')
    for bid,z in d.get('circle_nulls',{}).items():
        print(f"  {bid}: pass={z.get('pass_null')} radial_mean={z.get('radial_velocity_mean')}")
    return 0

if __name__=='__main__':
    raise SystemExit(main())
