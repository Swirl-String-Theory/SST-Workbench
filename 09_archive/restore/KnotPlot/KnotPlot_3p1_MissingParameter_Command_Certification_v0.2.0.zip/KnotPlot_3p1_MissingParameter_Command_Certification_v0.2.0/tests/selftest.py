from pathlib import Path
import sys,tempfile,json
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import analyze_results as ar

# Kabsch should remove rigid translation/rotation.
t=np.linspace(0,2*np.pi,32,endpoint=False)
a=np.c_[np.cos(t),np.sin(t),0*t]
q=np.array([[0,-1,0],[1,0,0],[0,0,1]],float)
b=a@q.T+np.array([3,4,5])
assert ar.kabsch_rms(a,b) < 1e-12
assert ar.arr_hash(a)==ar.arr_hash(a.copy())
for stage in ('cert','extended'):
    assert len(list((ROOT/'kpc'/stage).glob('*.kpc')))==12
for p in ('charge','hooke','power','timeincr'):
    for f in (ROOT/'kpc/cert').glob(f'{p}_*.kpc'):
        txt=f.read_text()
        assert 'load 3.1' in txt
        assert 'refine nbeads 300' in txt
        active=[]
        for q in ('charge','hooke','power','timeincr'):
            if any(line.strip().startswith(q+' ') for line in txt.splitlines()):
                active.append(q)
        assert active==[p], (f,active)
print('SELFTEST PASS: 24 KPC scripts + one-command isolation + analyzer invariants')
