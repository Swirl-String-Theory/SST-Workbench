# A048 v0.1.0 reveal report

**Status:** `SYNTHETIC_DISCRIMINATOR_QUALIFIED`

**Physics status:** `NOT_YET_TESTED_ON_INDEPENDENT_DYNAMICAL_PKLSA_OBSERVATIONS`

- Python classification accuracy: 1.000000
- Median |p-p_true|: 0.0017061
- Ambiguous cases: 0

## Gates
- classification_accuracy: PASS
- median_exponent_error: PASS
- circle_curvature: PASS
- circle_torsion: PASS
- winding_gauge: PASS
- native_classification_accuracy: PASS
- native_backend_parity: PASS

## Post-seal SST scale mapping
- Gamma_c = 9.683619203489e-09 m^2 s^-1
- beta_c = 7.705979316274e-10 m^2 s^-1
- t_c = 1.288088676644e-21 s
- omega_c = 7.763440655383e+20 s^-1

> These scales are reveal-only and do not enter the blind classifier.
