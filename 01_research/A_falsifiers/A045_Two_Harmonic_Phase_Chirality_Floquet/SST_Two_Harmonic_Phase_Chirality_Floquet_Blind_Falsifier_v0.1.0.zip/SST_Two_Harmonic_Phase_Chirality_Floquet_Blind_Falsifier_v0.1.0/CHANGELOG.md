# Changelog

## v0.1.0
- Initial Python + C++17/pybind11 template.
- Dimensionless T(2,3) trefoil seed.
- Two-harmonic co-/counter-rotating trace-free strain drive.
- Blind anonymous condition IDs and separate reveal map.
- Dynamic C3 symmetry and transformed-flow equivariance gates.
- Explicit `SKIP_FORMAL_FLOQUET` until periodic-orbit certification exists.
