"""Orchestrate MultiDynamics matrix .kpc runs via KnotPlot (run_build-style).

Batch packaging mirrors ridgerunner/run_catalog_batch.cmd → .py.
KnotPlot launch mirrors KnotPlot/run_build.cmd:

  "%KP_EXE%" -nog < "%SCRIPT%" > "%LOG%" 2>&1
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

MATRIX_DIR = Path(__file__).resolve().parent
KNOTPLOT_ROOT = MATRIX_DIR.parent
DEFAULT_SHORTCUT = KNOTPLOT_ROOT / "KnotPlot.lnk"

CORE_FAMILY = [
    "10_force_ablation_matrix.kpc",
    "20_charge_sweep_ME.kpc",
    "30_bend_sweep_MB.kpc",
    "40_power_sweep_ME.kpc",
    "50_close_sweep_MEB.kpc",
    "90_charge_anneal_MEB.kpc",
]

ALL_FAMILY = [
    "00_baseline_MEB_tight.kpc",
    "10_force_ablation_matrix.kpc",
    "20_charge_sweep_ME.kpc",
    "30_bend_sweep_MB.kpc",
    "40_power_sweep_ME.kpc",
    "50_close_sweep_MEB.kpc",
    "60_hooke_sweep_ME.kpc",
    "70_maxdr_sweep_MEB.kpc",
    "80_timeincr_sweep_MEB.kpc",
    "90_charge_anneal_MEB.kpc",
]

NOTHING_LOADED_MARKERS = (
    "nothing loaded",
    "*** nothing loaded",
    "nothing to save",
    "nothing to output",
)


def resolve_shortcut(lnk: Path) -> tuple[Path, Path]:
    """Return (KnotPlot.exe, working_directory) from a .lnk file."""
    if not lnk.is_file():
        raise FileNotFoundError(f"KnotPlot shortcut not found: {lnk}")
    # Prefer PowerShell COM (same as run_build.cmd); fall back to defaults.
    ps = (
        "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('"
        + str(lnk).replace("'", "''")
        + "'); "
        "Write-Output $s.TargetPath; Write-Output $s.WorkingDirectory"
    )
    proc = subprocess.run(
        ["powershell", "-NoProfile", "-Command", ps],
        check=False,
        capture_output=True,
        text=True,
    )
    lines = [ln.strip() for ln in (proc.stdout or "").splitlines() if ln.strip()]
    if len(lines) < 1 or not lines[0]:
        raise RuntimeError(f"Could not resolve TargetPath from {lnk}")
    exe = Path(lines[0])
    workdir = Path(lines[1]) if len(lines) > 1 and lines[1] else KNOTPLOT_ROOT
    if not exe.is_file():
        raise FileNotFoundError(f"KnotPlot.exe from shortcut not found: {exe}")
    return exe, workdir


def log_indicates_nothing_loaded(log_text: str) -> bool:
    """True if the run never successfully loaded/saved a knot.

    KnotPlot may print ``nothing loaded`` during rc/startup before the script
    body runs (workdir ``knotplotrc.kps``). Treat those as noise when a later
    ``knot loaded`` / ``knot saved`` appears.
    """
    lower = log_text.lower()
    if "knot loaded" in lower or "knot saved" in lower:
        return False
    return any(marker in lower for marker in NOTHING_LOADED_MARKERS)


def resolve_script(matrix_dir: Path, name: str) -> Path:
    """Resolve a script path relative to the matrix directory."""
    path = Path(name)
    if not path.is_absolute():
        path = matrix_dir / path
    return path.resolve()


def knotplot_argv(exe: Path) -> list[str]:
    """Argv for KnotPlot batch mode (matches run_build.cmd -nog)."""
    return [str(exe), "-nog"]


def run_one_script(
    *,
    exe: Path,
    workdir: Path,
    script: Path,
    log_path: Path,
    dry_run: bool = False,
) -> int:
    """Run one .kpc with stdin redirect; return process exit code."""
    if not script.is_file():
        raise FileNotFoundError(f"Script not found: {script}")
    argv = knotplot_argv(exe)
    print(f"KnotPlot: {exe}")
    print(f"CWD:      {workdir}")
    print(f"Script:   {script}")
    print(f"Log:      {log_path}")
    print("Mode:     non-graphics (-nog)")
    if dry_run:
        print(f"DRY-RUN:  {' '.join(argv)} < {script} > {log_path}")
        return 0

    log_path.parent.mkdir(parents=True, exist_ok=True)
    with script.open("rb") as stdin_f, log_path.open(
        "wb"
    ) as log_f:
        proc = subprocess.run(
            argv,
            cwd=str(workdir),
            stdin=stdin_f,
            stdout=log_f,
            stderr=subprocess.STDOUT,
            check=False,
        )
    rc = int(proc.returncode)
    log_text = log_path.read_text(encoding="utf-8", errors="replace")
    if log_indicates_nothing_loaded(log_text):
        print(f"ERROR: log indicates nothing loaded: {log_path}", file=sys.stderr)
        return rc if rc != 0 else 1
    return rc


def family_scripts(matrix_dir: Path, names: list[str]) -> list[Path]:
    return [resolve_script(matrix_dir, name) for name in names]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--all", action="store_true", help="Run full matrix family list")
    mode.add_argument("--core", action="store_true", help="Run core matrix family list")
    mode.add_argument(
        "--one",
        metavar="SCRIPT",
        help="Run a single .kpc (relative to matrix dir or absolute)",
    )
    parser.add_argument(
        "--matrix-dir",
        type=Path,
        default=MATRIX_DIR,
        help="MultiDynamics matrix directory",
    )
    parser.add_argument(
        "--shortcut",
        type=Path,
        default=DEFAULT_SHORTCUT,
        help="Path to KnotPlot.lnk",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print KnotPlot argv only; do not launch",
    )
    args = parser.parse_args(argv)

    matrix_dir = args.matrix_dir.resolve()
    if not matrix_dir.is_dir():
        print(f"ERROR: matrix directory not found: {matrix_dir}", file=sys.stderr)
        return 1

    if args.all:
        scripts = family_scripts(matrix_dir, ALL_FAMILY)
        title = "FULL Multi-Dynamics Relaxation Matrix"
    elif args.core:
        scripts = family_scripts(matrix_dir, CORE_FAMILY)
        title = "CORE Multi-Dynamics Relaxation Matrix"
    else:
        scripts = [resolve_script(matrix_dir, args.one)]
        title = f"ONE script: {scripts[0].name}"

    try:
        exe, workdir = resolve_shortcut(args.shortcut.resolve())
    except (OSError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print("=" * 60)
    print(f"KnotPlot 3.1 {title}")
    print("=" * 60)
    print(f"Shortcut : {args.shortcut}")
    print(f"Target   : {exe}")
    print(f"Start in : {workdir}")
    print(f"Output   : {matrix_dir}")
    print(f"Scripts  : {len(scripts)}")
    print("=" * 60)

    out_dir = matrix_dir / "out"
    logs_dir = matrix_dir / "logs"
    if not args.dry_run:
        out_dir.mkdir(parents=True, exist_ok=True)
        logs_dir.mkdir(parents=True, exist_ok=True)

    for index, script in enumerate(scripts, start=1):
        log_path = logs_dir / f"{script.stem}_console.log"
        print(f"\n-------- [{index}/{len(scripts)}] {script.name} --------")
        try:
            rc = run_one_script(
                exe=exe,
                workdir=workdir,
                script=script,
                log_path=log_path,
                dry_run=args.dry_run,
            )
        except FileNotFoundError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        if rc != 0:
            print(f"ERROR: KnotPlot failed (exit {rc}), see {log_path}", file=sys.stderr)
            return rc
        print(f"OK: {script.name}")

    print("\nAll requested scripts finished successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
