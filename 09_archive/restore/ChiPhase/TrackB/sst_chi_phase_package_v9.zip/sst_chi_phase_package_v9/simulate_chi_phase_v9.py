#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SST chi-phase v9: alpha/beta ring-constant intercept audit.

This package is a Research Track audit.  It derives/tests the alpha/beta
relationship and the log-subtracted alpha-intercept machinery.  It does not
claim a full NLSE/GP derivation of alpha=1.61.
"""
from __future__ import annotations

import argparse
import csv
import math
import os
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)

try:
    from sst_chi_phase_v9_build import import_module
except Exception:
    import_module = None


def load_backend(force_python: bool = False):
    if not force_python and import_module is not None:
        try:
            return import_module(auto_build=True, script_dir=SCRIPT_DIR), "cpp"
        except Exception as exc:
            print(f"[!] C++ backend unavailable; using Python fallback. Reason: {exc}")
    import sst_chi_phase_v9_py as mod
    return mod, "python"


def write_csv(path, rows, fieldnames):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--python", action="store_true", help="force pure-Python backend")
    parser.add_argument("--no-plots", action="store_true", help="skip matplotlib plots")
    args = parser.parse_args(argv)

    mod, backend = load_backend(force_python=args.python)
    t0 = time.time()

    export_dir = os.path.join(SCRIPT_DIR, "exports")
    os.makedirs(export_dir, exist_ok=True)

    print("=" * 86)
    print("SST chi-phase v9 alpha/beta ring-constant intercept audit")
    print("=" * 86)
    print(f"[*] backend = {backend}")
    print("[*] Status: Research Track.  Not a full NLSE/GP derivation of alpha=1.61.")

    # Targets and q relation
    if hasattr(mod, "target_analysis_rows"):
        target_rows = mod.target_analysis_rows()
    else:
        # C++ backend supplies scalar funcs only; use Python table for convenience.
        import sst_chi_phase_v9_py as pymod
        target_rows = pymod.target_analysis_rows()
        mod = pymod
        backend = "python-table+cpp-scalar"

    target_csv = os.path.join(export_dir, "chi_v9_alpha_beta_targets.csv")
    write_csv(target_csv, target_rows, [
        "name", "alpha", "beta", "q_eff", "q_label", "beta_pred", "beta_residual",
        "alpha_minus_a0_star", "alpha_minus_phi", "c_over_v_if_a0_eq_alpha", "c_minus_1_if_a0_eq_alpha",
    ])
    print(f"[*] CSV saved: {target_csv}")

    # Synthetic intercept machinery check
    eps_values = [0.25, 0.20, 0.15, 0.10, 0.075, 0.05, 0.035]
    synthetic_alpha = 1.61
    syn_rows = mod.synthetic_intercept_rows(synthetic_alpha, eps_values)
    fit_alpha0, fit_A, fit_B = mod.fit_alpha_intercept(
        [r["eps"] for r in syn_rows], [r["alpha_eff"] for r in syn_rows]
    )
    syn_csv = os.path.join(export_dir, "chi_v9_synthetic_alpha_intercept.csv")
    write_csv(syn_csv, syn_rows, ["eps", "R_over_a", "E", "alpha_eff"])
    print(f"[*] CSV saved: {syn_csv}")

    # Smooth-root constants
    a0_star = mod.A0_STAR
    phi = mod.PHI
    c_phi = mod.smooth_matched_c_over_v(phi)
    c_nls_as_a0 = mod.smooth_matched_c_over_v(1.61)
    c_star = mod.smooth_matched_c_over_v(a0_star)

    # Summary
    summary_path = os.path.join(export_dir, "chi_v9_run_results_summary.txt")
    lines = []
    lines.append("SST chi-phase v9 alpha/beta ring-constant intercept audit")
    lines.append("===========================================================")
    lines.append(f"backend                                      = {backend}")
    lines.append("")
    lines.append("Key ring formulas:")
    lines.append("E = 1/2 rho Gamma^2 R [ln(8R/a)-alpha]")
    lines.append("alpha_eff = ln(8R/a) - 2E/(rho Gamma^2 R)")
    lines.append("beta = alpha - 1 + q, q=d ln a/d ln R")
    lines.append("")
    lines.append(f"smooth closure a0_star                       = {a0_star:.16e}")
    lines.append(f"golden ratio phi                             = {phi:.16e}")
    lines.append(f"a0_star - phi                                = {a0_star - phi:.16e}")
    lines.append(f"c(a0_star)/v                                 = {c_star:.16e}")
    lines.append(f"c(phi)/v                                     = {c_phi:.16e}")
    lines.append(f"c(alpha_NLS=1.61 as a0)/v                    = {c_nls_as_a0:.16e}")
    lines.append("")
    for row in target_rows:
        lines.append(
            f"{row['name']:<42} alpha={row['alpha']:.8f} beta={row['beta']:.8f} "
            f"q_eff={row['q_eff']:.8f} c(a0=alpha)/v={row['c_over_v_if_a0_eq_alpha']:.10f}"
        )
    lines.append("")
    lines.append("Synthetic intercept roundtrip, target alpha=1.61:")
    lines.append(f"fit alpha0                                   = {fit_alpha0:.16e}")
    lines.append(f"fit alpha0 - target                          = {fit_alpha0 - synthetic_alpha:.16e}")
    lines.append(f"fit A                                        = {fit_A:.16e}")
    lines.append(f"fit B                                        = {fit_B:.16e}")
    lines.append("")
    lines.append("Interpretation:")
    lines.append("v9 verifies the alpha/beta relation and the log-subtracted intercept")
    lines.append("machinery.  The synthetic intercept check confirms the fitting pipeline,")
    lines.append("but does not derive alpha=1.61 from NLSE/GP dynamics.  A true canon-level")
    lines.append("alpha derivation still requires an independent vortex-ring energy solver")
    lines.append("or NLSE/GP matched-core calculation.")
    lines.append("")
    lines.append(f"targets_csv                                  = {target_csv}")
    lines.append(f"synthetic_intercept_csv                      = {syn_csv}")
    lines.append(f"elapsed                                      = {time.time() - t0:.2f} s")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"[*] Summary saved: {summary_path}")

    if not args.no_plots:
        try:
            import matplotlib.pyplot as plt
            names = [r["name"].replace(", ", "\n") for r in target_rows]
            alphas = [r["alpha"] for r in target_rows]
            betas = [r["beta"] for r in target_rows]
            qeff = [r["q_eff"] for r in target_rows]
            cvals = [r["c_over_v_if_a0_eq_alpha"] for r in target_rows]

            plt.figure(figsize=(10, 6))
            plt.scatter(alphas, betas, s=80)
            xs = [0.9, 2.1]
            plt.plot(xs, [x-1.0 for x in xs], "k--", label=r"$q=0: \beta=\alpha-1$")
            plt.plot(xs, [x-1.5 for x in xs], "k:", label=r"$q=-1/2: \beta=\alpha-3/2$")
            for r in target_rows:
                plt.annotate(r["name"].split(",")[0], (r["alpha"], r["beta"]), fontsize=8)
            plt.xlabel(r"$\alpha$")
            plt.ylabel(r"$\beta$")
            plt.title(r"v9 legacy ring-constant targets and $\beta=\alpha-1+q$")
            plt.grid(True)
            plt.legend()
            plt.tight_layout()
            p = os.path.join(export_dir, "chi_v9_alpha_beta_targets.png")
            plt.savefig(p, dpi=150)
            print(f"[*] Plot saved: {p}")

            plt.figure(figsize=(10, 6))
            plt.plot([r["R_over_a"] for r in syn_rows], [r["alpha_eff"] for r in syn_rows], "o-")
            plt.axhline(synthetic_alpha, color="k", linestyle="--", label="target alpha=1.61")
            plt.xscale("log")
            plt.xlabel(r"$R/a$")
            plt.ylabel(r"$\alpha_{\rm eff}$")
            plt.title("v9 synthetic alpha-intercept extraction pipeline")
            plt.grid(True)
            plt.legend()
            plt.tight_layout()
            p = os.path.join(export_dir, "chi_v9_synthetic_alpha_intercept.png")
            plt.savefig(p, dpi=150)
            print(f"[*] Plot saved: {p}")

            plt.figure(figsize=(10, 6))
            plt.bar(range(len(cvals)), cvals)
            plt.axhline(1.0, color="k", linestyle="--")
            plt.xticks(range(len(cvals)), names, rotation=35, ha="right")
            plt.ylabel(r"$c_\chi/v$ if $a_0=\alpha$")
            plt.title("v9 comparison: legacy alpha values used as smooth-profile a0")
            plt.tight_layout()
            p = os.path.join(export_dir, "chi_v9_alpha_as_a0_comparison.png")
            plt.savefig(p, dpi=150)
            print(f"[*] Plot saved: {p}")
        except Exception as exc:
            print(f"[!] Plot generation skipped: {exc}")

    print("=" * 86)
    print("Summary")
    print("=" * 86)
    print(f"a0_star        = {a0_star:.16e}")
    print(f"phi            = {phi:.16e}")
    print(f"c(phi)/v       = {c_phi:.16e}")
    print(f"fit alpha0     = {fit_alpha0:.16e}")
    print(f"summary        = {summary_path}")
    print("[*] PASS: v9 alpha/beta intercept audit completed.  Not a final NLSE alpha derivation.")


if __name__ == "__main__":
    main()
