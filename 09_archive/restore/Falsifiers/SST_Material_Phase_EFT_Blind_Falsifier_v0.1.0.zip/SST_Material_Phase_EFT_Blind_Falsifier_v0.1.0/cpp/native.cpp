#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <vector>
#include <array>
#include <cmath>
#include <stdexcept>
#include <algorithm>

namespace py = pybind11;
using P = std::array<double,3>;

static inline P add(const P&a,const P&b){return {a[0]+b[0],a[1]+b[1],a[2]+b[2]};}
static inline P sub(const P&a,const P&b){return {a[0]-b[0],a[1]-b[1],a[2]-b[2]};}
static inline P mul(const P&a,double s){return {a[0]*s,a[1]*s,a[2]*s};}
static inline double dot(const P&a,const P&b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
static inline P cross(const P&a,const P&b){return {a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};}
static inline double norm(const P&a){return std::sqrt(dot(a,a));}

static std::vector<P> read_points(const py::array_t<double, py::array::c_style | py::array::forcecast>& arr){
    auto b = arr.request();
    if(b.ndim != 2 || b.shape[1] != 3) throw std::runtime_error("points must have shape (N,3)");
    if(b.shape[0] < 4) throw std::runtime_error("need at least 4 points");
    const double* p = static_cast<const double*>(b.ptr);
    std::vector<P> out((size_t)b.shape[0]);
    for(py::ssize_t i=0;i<b.shape[0];++i) out[(size_t)i] = {p[3*i],p[3*i+1],p[3*i+2]};
    // Drop repeated closing point if present.
    if(out.size()>4 && norm(sub(out.front(), out.back())) < 1e-14 * std::max(1.0, norm(out.front()))) out.pop_back();
    return out;
}

static double poly_length(const std::vector<P>& pts){
    double L=0.0; const size_t n=pts.size();
    for(size_t i=0;i<n;++i) L += norm(sub(pts[(i+1)%n], pts[i]));
    return L;
}

py::array_t<double> resample_closed_curve(const py::array_t<double, py::array::c_style | py::array::forcecast>& arr, int nout){
    auto pts = read_points(arr);
    if(nout < 8) throw std::runtime_error("nout must be >= 8");
    const size_t n=pts.size();
    std::vector<double> cum(n+1,0.0);
    for(size_t i=0;i<n;++i) cum[i+1] = cum[i] + norm(sub(pts[(i+1)%n], pts[i]));
    const double L=cum[n];
    if(!(L>0.0)) throw std::runtime_error("zero-length curve");
    py::array_t<double> out({py::ssize_t(nout), py::ssize_t(3)});
    auto o=out.mutable_unchecked<2>();
    size_t seg=0;
    for(int j=0;j<nout;++j){
        double s=L*double(j)/double(nout);
        while(seg+1<n && cum[seg+1] < s) ++seg;
        double den=cum[seg+1]-cum[seg];
        double t=den>0.0 ? (s-cum[seg])/den : 0.0;
        P q=add(pts[seg], mul(sub(pts[(seg+1)%n],pts[seg]),t));
        o(j,0)=q[0]; o(j,1)=q[1]; o(j,2)=q[2];
    }
    return out;
}

py::dict curve_metrics(const py::array_t<double, py::array::c_style | py::array::forcecast>& arr){
    auto pts=read_points(arr); const size_t n=pts.size();
    double L=poly_length(pts); double ds=L/double(n);
    if(!(ds>0.0)) throw std::runtime_error("zero ds");
    std::vector<double> k(n,0.0);
    for(size_t i=0;i<n;++i){
        const P& pm=pts[(i+n-1)%n]; const P& p=pts[i]; const P& pp=pts[(i+1)%n];
        P d2=mul(add(sub(pp,mul(p,2.0)),pm),1.0/(ds*ds));
        k[i]=norm(d2);
    }
    double intk=0.0,intk2=0.0,intdk2=0.0,kmax=0.0;
    for(size_t i=0;i<n;++i){
        intk += k[i]*ds; intk2 += k[i]*k[i]*ds; kmax=std::max(kmax,k[i]);
        double dk=(k[(i+1)%n]-k[i])/ds;
        intdk2 += dk*dk*ds;
    }
    py::dict d;
    d["n"]=(py::ssize_t)n; d["length"]=L; d["ds"]=ds;
    d["total_curvature"]=intk; d["int_kappa2"]=intk2; d["int_dkappa2"]=intdk2;
    d["D0"]=L*intk2; d["D2"]=L*L*L*intdk2; d["kappa_max"]=kmax;
    return d;
}

py::array_t<double> curvature_uniform(const py::array_t<double, py::array::c_style | py::array::forcecast>& arr){
    auto pts=read_points(arr); const size_t n=pts.size();
    double L=poly_length(pts), ds=L/double(n);
    py::array_t<double> out({py::ssize_t(n)}); auto o=out.mutable_unchecked<1>();
    for(size_t i=0;i<n;++i){
        const P& pm=pts[(i+n-1)%n]; const P& p=pts[i]; const P& pp=pts[(i+1)%n];
        P d2=mul(add(sub(pp,mul(p,2.0)),pm),1.0/(ds*ds));
        o((py::ssize_t)i)=norm(d2);
    }
    return out;
}

double approx_writhe(const py::array_t<double, py::array::c_style | py::array::forcecast>& arr){
    auto pts=read_points(arr); const size_t n=pts.size();
    std::vector<P> e(n),m(n);
    double L=0.0;
    for(size_t i=0;i<n;++i){e[i]=sub(pts[(i+1)%n],pts[i]);m[i]=mul(add(pts[i],pts[(i+1)%n]),0.5);L+=norm(e[i]);}
    double eps=1e-14*std::max(1.0,L); double sum=0.0;
    for(size_t i=0;i<n;++i){
        for(size_t j=i+1;j<n;++j){
            size_t d=(j>i?j-i:i-j); if(d<=1 || d>=n-1) continue;
            P r=sub(m[i],m[j]); double r2=dot(r,r); double rr=std::sqrt(r2);
            if(rr<eps) continue;
            sum += dot(r,cross(e[i],e[j]))/(r2*rr);
        }
    }
    constexpr double PI=3.141592653589793238462643383279502884;
    return sum/(2.0*PI);
}

PYBIND11_MODULE(_native,m){
    m.doc()="Native geometry kernels for SST Material/Phase EFT blind falsifier";
    m.def("resample_closed_curve", &resample_closed_curve, py::arg("points"), py::arg("n"));
    m.def("curve_metrics", &curve_metrics, py::arg("points"));
    m.def("curvature_uniform", &curvature_uniform, py::arg("points"));
    m.def("approx_writhe", &approx_writhe, py::arg("points"));
}
