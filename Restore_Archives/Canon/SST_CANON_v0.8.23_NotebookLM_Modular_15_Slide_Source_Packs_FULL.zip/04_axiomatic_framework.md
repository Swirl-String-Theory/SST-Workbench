# Axiomatic Framework - the eight commitments

## Slide 1/15 - Axioms as load-bearing commitments

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Prelude motivates; axioms authorize calculations.
- They are stronger than origin notes and narrower than research hypotheses.
- Later claims must trace to them or to labelled bridges.

**Single slide message:** Prelude motivates; axioms authorize calculations.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 2/15 - Axiom 1: continuum substrate

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- SST assumes a continuum substrate in 3D foliation.
- The working fluid limit is incompressible and inviscid.
- External forcing/viscosity are not silently introduced.

**Single slide message:** SST assumes a continuum substrate in 3D foliation.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 3/15 - Axiom 2: stable vortex filaments

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Stable finite-core vortex filaments exist.
- Persistence is constrained by Helmholtz/Kelvin logic.
- Stability still requires certification.

**Single slide message:** Stable finite-core vortex filaments exist.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 4/15 - Axiom 3: circulation quantization

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Circulation has discrete allowed sectors.
- This gives a classical topological route to discreteness.
- It does not derive every quantum observable alone.

**Single slide message:** Circulation has discrete allowed sectors.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 5/15 - Axiom 4: Compton anchoring

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Compton-scale anchoring connects carrier scales to observed matter.
- It carries dependency/circularity risk.
- It organizes electron-scale closures.

**Single slide message:** Compton-scale anchoring connects carrier scales to observed matter.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 6/15 - Axiom 5: delay as constitutive principle

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Self-interaction is delayed through circulation paths.
- Delay can select locked modes.
- It is central to mode selection and spectra.

**Single slide message:** Self-interaction is delayed through circulation paths.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 7/15 - Axiom 6: energy localization

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Energy localizes in stable finite-core configurations.
- Mass emerges from trapped energy under closure rules.
- Leakage/reconnection/decay are falsifiers.

**Single slide message:** Energy localizes in stable finite-core configurations.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 8/15 - Axiom 7: operational spacetime

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Vortex matter builds clocks and rulers.
- Two-way torsion/light speed is measured locally.
- Observable Lorentz structure must emerge.

**Single slide message:** Vortex matter builds clocks and rulers.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 9/15 - Axiom 8: density saturation and horn envelope

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Core and envelope densities are separated.
- Saturation prevents undefined core behavior.
- Envelope closure links local and coarse-grained fields.

**Single slide message:** Core and envelope densities are separated.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 10/15 - Logical ordering

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Axiom 1: medium.
- Axioms 2-3: topological carriers.
- Axioms 4-6: scale, delay, energy.
- Axioms 7-8: observations and envelope closure.

**Single slide message:** Axiom 1: medium.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 11/15 - Minimality principle

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Avoid ad-hoc interaction potentials.
- Prefer hydrodynamic/topological stability mechanisms.
- New additions require labels and promotion gates.

**Single slide message:** Avoid ad-hoc interaction potentials.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 12/15 - Philosophical interpretation

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Axioms encode the physical-substrate programme.
- They preserve classical logic with possible emergent discreteness.
- They demand compatibility with operational relativity.

**Single slide message:** Axioms encode the physical-substrate programme.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 13/15 - Consistency condition

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Conflicting axioms require revision.
- Bridge assumptions cannot override primitive constraints.
- Axioms face empirical falsifiers through derived claims.

**Single slide message:** Conflicting axioms require revision.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 14/15 - Canonical axiom statement

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- The eight axioms define active Canon basis.
- They do not include every research idea.
- They determine permitted assumptions.

**Single slide message:** The eight axioms define active Canon basis.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.

## Slide 15/15 - Axioms closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Axioms are the legal moves of SST.
- Foundations supply symbols; axioms supply commitments.
- Research tests whether commitments generate physics.

**Single slide message:** Axioms are the legal moves of SST.

**Source anchors:** Axiomatic Framework.

**Visual specification:** Eight-pillar diagram with dependency arrows.

**Do not generate:** Do not add an unofficial ninth axiom or promote research hypotheses as axioms.
