from pathlib import Path
import numpy as np
from sst_counterpulley.core import DEFAULT_DATA, prepare_centerline
from sst_counterpulley.ideal_ab import parse_ideal_ab
from sst_counterpulley.geometry import make_counter_channels, resample_closed

def test_parse_trefoil():
    m=parse_ideal_ab(DEFAULT_DATA,"3:1:1")
    assert m.knot_id=="3:1:1"
    assert abs(m.L-16.371637)<1e-12
    assert abs(m.D-1.0)<1e-12
    assert len(m.harmonics)>100

def test_resampled_channels_are_well_distributed():
    c,m=prepare_centerline(n=96)
    p,q,_,_=make_counter_channels(c,.5*m["D_metadata"])
    for a in (resample_closed(p,96),resample_closed(q,96)):
        ds=np.linalg.norm(np.roll(a,-1,axis=0)-a,axis=1)
        assert np.std(ds)/np.mean(ds)<0.01
