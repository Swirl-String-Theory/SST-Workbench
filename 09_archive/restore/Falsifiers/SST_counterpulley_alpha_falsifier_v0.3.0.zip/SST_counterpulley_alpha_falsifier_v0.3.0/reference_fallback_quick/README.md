Python-fallback quick validation. This is a portability reference only; scientific conclusions use reference_native_full.
