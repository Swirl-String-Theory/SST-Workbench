#!/usr/bin/env python3
"""
make_ideal_3_1_ab.py

Convert a KnotPlot point export and/or a Fremlin/Fresnel .fseries file into
Ideal.txt-style Fourier AB records for the trefoil Id="3:1:1".

What this script does:
  - reads a closed 3-column point list from KnotPlot;
  - reads a 6-column Fourier-series file with rows
        Ax Bx Ay By Az Bz
    for harmonics n=1,2,... by default;
  - reparameterizes each curve approximately by arclength;
  - fits real Fourier coefficients A[n], B[n];
  - standardizes approximately like Brian Gilbert's Ideal.txt convention;
  - estimates the diameter D from curvature and double-critical-like self-distance;
  - rescales all coefficients so D=1;
  - writes Ideal.txt-style <AB Id="3:1:1" ...> blocks.

Important limitation:
  The script does NOT perform SONO/Ridgerunner tightening.  Therefore it cannot
  magically make a non-tight KnotPlot/Fremlin curve have Gilbert's ideal
  ropelength L=16.372861.  It writes a geometrically honest D=1 block and reports
  the resulting L/D deviation from the target.

Dependencies:
  pip install numpy

Example:
  python make_ideal_3_1_ab.py \
      --knotplot knot_3.1.txt \
      --fseries knot.3_1.fseries \
      --outdir ideal_3_1_out
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import math
import os
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Optional

import numpy as np

TARGET_ID = "3:1:1"
TARGET_CONWAY = "3"
TARGET_GILBERT_L = 16.372861


@dataclass
class CurveDiagnostics:
    source: str
    source_path: str
    raw_points: int
    fit_modes: int
    eval_points: int
    length_before_scale: float
    diameter_before_scale: float
    ropelength_L_over_D: float
    curvature_diameter: float
    self_distance_diameter: float
    active_diameter_kind: str
    dcsd_pair_i: Optional[int]
    dcsd_pair_j: Optional[int]
    target_L: float
    rel_error_vs_target: float
    warning: str


def _split_floats(line: str) -> list[float]:
    vals = []
    for tok in re.split(r"[,;\s]+", line.strip()):
        if not tok:
            continue
        try:
            vals.append(float(tok))
        except ValueError:
            pass
    return vals


def read_xyz_points(path: Path) -> np.ndarray:
    rows: list[list[float]] = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("%"):
                continue
            vals = _split_floats(s)
            if len(vals) >= 3:
                rows.append(vals[:3])
    if len(rows) < 4:
        raise ValueError(f"{path}: expected at least 4 xyz rows, got {len(rows)}")
    pts = np.asarray(rows, dtype=float)
    if pts.ndim != 2 or pts.shape[1] != 3:
        raise ValueError(f"{path}: parsed array shape {pts.shape}, expected (N,3)")
    return pts


def read_fseries(path: Path, layout: str = "ax_bx_ay_by_az_bz") -> tuple[np.ndarray, np.ndarray]:
    """Read Fremlin/Fresnel-style rows.

    Default row layout:
        Ax Bx Ay By Az Bz
    corresponding to
        x += Ax cos(nt) + Bx sin(nt), etc.

    Alternative layout:
        Ax Ay Az Bx By Bz
    """
    rows: list[list[float]] = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("%"):
                continue
            vals = _split_floats(s)
            if len(vals) >= 6:
                rows.append(vals[:6])
    if not rows:
        raise ValueError(f"{path}: no 6-column Fourier rows found")

    M = len(rows)
    A = np.zeros((M + 1, 3), dtype=float)
    B = np.zeros((M + 1, 3), dtype=float)

    for n, row in enumerate(rows, start=1):
        if layout == "ax_bx_ay_by_az_bz":
            ax, bx, ay, by, az, bz = row
        elif layout == "ax_ay_az_bx_by_bz":
            ax, ay, az, bx, by, bz = row
        else:
            raise ValueError(f"Unknown fseries layout: {layout}")
        A[n] = (ax, ay, az)
        B[n] = (bx, by, bz)
    return A, B


def remove_duplicate_endpoint(points: np.ndarray, tol: float = 1e-12) -> np.ndarray:
    pts = np.asarray(points, dtype=float)
    if len(pts) > 2 and np.linalg.norm(pts[0] - pts[-1]) <= tol:
        return pts[:-1].copy()
    return pts.copy()


def closed_polygon_length(points: np.ndarray) -> float:
    pts = remove_duplicate_endpoint(points)
    return float(np.linalg.norm(np.roll(pts, -1, axis=0) - pts, axis=1).sum())


def resample_closed_by_arclength(points: np.ndarray, n: int) -> np.ndarray:
    pts = remove_duplicate_endpoint(points)
    if len(pts) < 4:
        raise ValueError("Need at least 4 points for a closed curve")
    seg_vec = np.roll(pts, -1, axis=0) - pts
    seg_len = np.linalg.norm(seg_vec, axis=1)
    if np.any(seg_len <= 0):
        keep = seg_len > 0
        pts = pts[keep]
        seg_vec = np.roll(pts, -1, axis=0) - pts
        seg_len = np.linalg.norm(seg_vec, axis=1)
    cum = np.concatenate([[0.0], np.cumsum(seg_len)])
    total = float(cum[-1])
    if not math.isfinite(total) or total <= 0:
        raise ValueError("Degenerate closed curve length")

    s_targets = np.linspace(0.0, total, n, endpoint=False)
    out = np.empty((n, 3), dtype=float)
    j = 0
    for i, s in enumerate(s_targets):
        while j + 1 < len(cum) and cum[j + 1] <= s:
            j += 1
        j = min(j, len(seg_len) - 1)
        u = 0.0 if seg_len[j] == 0 else (s - cum[j]) / seg_len[j]
        out[i] = (1.0 - u) * pts[j] + u * pts[(j + 1) % len(pts)]
    return out


def fit_fourier_from_samples(points: np.ndarray, modes: int) -> tuple[np.ndarray, np.ndarray]:
    pts = np.asarray(points, dtype=float)
    N = len(pts)
    if modes >= N // 2:
        modes = max(1, N // 2 - 1)
    t = 2.0 * math.pi * np.arange(N, dtype=float) / N
    A = np.zeros((modes + 1, 3), dtype=float)
    B = np.zeros((modes + 1, 3), dtype=float)
    A[0] = 2.0 * pts.mean(axis=0)
    for k in range(1, modes + 1):
        c = np.cos(k * t)[:, None]
        s = np.sin(k * t)[:, None]
        A[k] = 2.0 * np.mean(pts * c, axis=0)
        B[k] = 2.0 * np.mean(pts * s, axis=0)
    return A, B


def eval_fourier(A: np.ndarray, B: np.ndarray, t: np.ndarray, derivative: int = 0) -> np.ndarray:
    t = np.asarray(t, dtype=float)
    M = len(A) - 1
    out = np.zeros((len(t), 3), dtype=float)
    if derivative == 0:
        out += A[0][None, :] / 2.0
        for k in range(1, M + 1):
            out += A[k][None, :] * np.cos(k * t)[:, None]
            out += B[k][None, :] * np.sin(k * t)[:, None]
    elif derivative == 1:
        for k in range(1, M + 1):
            out += -k * A[k][None, :] * np.sin(k * t)[:, None]
            out +=  k * B[k][None, :] * np.cos(k * t)[:, None]
    elif derivative == 2:
        for k in range(1, M + 1):
            out += -(k * k) * A[k][None, :] * np.cos(k * t)[:, None]
            out += -(k * k) * B[k][None, :] * np.sin(k * t)[:, None]
    else:
        raise ValueError("derivative must be 0, 1, or 2")
    return out


def sample_fourier(A: np.ndarray, B: np.ndarray, n: int) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    return eval_fourier(A, B, t, derivative=0)


def arclength_reparameterize_fourier(A: np.ndarray, B: np.ndarray, n_samples: int, modes: int) -> tuple[np.ndarray, np.ndarray]:
    pts = sample_fourier(A, B, n_samples)
    pts_s = resample_closed_by_arclength(pts, n_samples)
    return fit_fourier_from_samples(pts_s, modes)


def phase_shift(A: np.ndarray, B: np.ndarray, phi: float) -> tuple[np.ndarray, np.ndarray]:
    """Return coefficients for x(t + phi)."""
    A2 = A.copy()
    B2 = B.copy()
    for k in range(1, len(A)):
        c = math.cos(k * phi)
        s = math.sin(k * phi)
        Ak = A[k].copy()
        Bk = B[k].copy()
        A2[k] = Ak * c + Bk * s
        B2[k] = -Ak * s + Bk * c
    return A2, B2


def rotate_coefficients(A: np.ndarray, B: np.ndarray, R: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Rotate coordinates by rows-as-new-basis matrix R: x_new = R @ x_old."""
    return A @ R.T, B @ R.T


def _first_harmonic_phase(A1: np.ndarray, B1: np.ndarray) -> float:
    # Diagonalize the first harmonic ellipse.  We want A1'·B1' ≈ 0.
    a2 = float(np.dot(A1, A1))
    b2 = float(np.dot(B1, B1))
    ab = float(np.dot(A1, B1))
    # dot after shift phi:
    # ab*cos(2phi) + 0.5*(b2-a2)*sin(2phi) = 0
    phi0 = 0.5 * math.atan2(-2.0 * ab, b2 - a2)
    candidates = [phi0, phi0 + 0.5 * math.pi]
    best = candidates[0]
    best_score = -1e300
    for phi in candidates:
        Ap = A1 * math.cos(phi) + B1 * math.sin(phi)
        Bp = -A1 * math.sin(phi) + B1 * math.cos(phi)
        # Prefer larger A1 norm than B1 norm, and low dot product.
        score = np.linalg.norm(Ap) - np.linalg.norm(Bp) - 100.0 * abs(float(np.dot(Ap, Bp)))
        if score > best_score:
            best_score = score
            best = phi
    return best


def standardize_like_ideal_txt(A: np.ndarray, B: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Approximate Brian Gilbert standardization from the Knot Atlas page.

    The exact historical code is not reproduced here, but this implements the
    same intent: arclength parameter, first harmonic aligned to x/y, signs fixed
    using A[2], then D=1 is applied separately.
    """
    A = A.copy()
    B = B.copy()
    A[0] = 0.0
    B[0] = 0.0

    if len(A) < 3:
        return A, B

    # Rebase parameter so A1 and B1 are orthogonal and |A1| >= |B1|.
    phi = _first_harmonic_phase(A[1], B[1])
    A, B = phase_shift(A, B, phi)

    # Rotate 3D coordinates so A1 -> +x and B1 -> +y.
    e1 = A[1].copy()
    n1 = np.linalg.norm(e1)
    if n1 < 1e-14:
        return A, B
    e1 /= n1

    b_perp = B[1] - np.dot(B[1], e1) * e1
    n2 = np.linalg.norm(b_perp)
    if n2 < 1e-14:
        # Pick any perpendicular direction.
        tmp = np.array([1.0, 0.0, 0.0])
        if abs(np.dot(tmp, e1)) > 0.9:
            tmp = np.array([0.0, 1.0, 0.0])
        b_perp = tmp - np.dot(tmp, e1) * e1
        n2 = np.linalg.norm(b_perp)
    e2 = b_perp / n2
    e3 = np.cross(e1, e2)
    e3 /= np.linalg.norm(e3)
    R = np.vstack([e1, e2, e3])
    A, B = rotate_coefficients(A, B, R)

    # Ensure A1.x and B1.y are positive.
    if A[1, 0] < 0:
        A[:, 0] *= -1.0
        B[:, 0] *= -1.0
    if B[1, 1] < 0:
        A[:, 1] *= -1.0
        B[:, 1] *= -1.0

    # If the first harmonic axes came out swapped, rotate by 90 degrees in xy.
    if abs(B[1, 0]) > abs(B[1, 1]) and abs(A[1, 1]) > abs(A[1, 0]):
        Q = np.array([[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
        A, B = rotate_coefficients(A, B, Q)

    # Gilbert sign conventions using A[2].
    if len(A) > 2:
        # Equivalent to t -> t+pi plus xy rotation by pi; keeps A1/B1 positive and flips A2.xy.
        if A[2, 0] < 0:
            A[:, 0:2] *= -1.0
            B[:, 0:2] *= -1.0
            A, B = phase_shift(A, B, math.pi)

        # Reverse string if A2.y < 0, using the transformation stated on Knot Atlas.
        if A[2, 1] < 0:
            A[:, 1] *= -1.0  # Ay
            A[:, 2] *= -1.0  # Az
            B[:, 0] *= -1.0  # Bx

        # Reflect in xy plane if A2.z < 0.
        if A[2, 2] < 0:
            A[:, 2] *= -1.0
            B[:, 2] *= -1.0

    # Remove tiny numerical noise.
    A[np.abs(A) < 5e-13] = 0.0
    B[np.abs(B) < 5e-13] = 0.0
    return A, B


def length_from_fourier(A: np.ndarray, B: np.ndarray, n: int) -> float:
    t = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    v = eval_fourier(A, B, t, derivative=1)
    return float(2.0 * math.pi * np.mean(np.linalg.norm(v, axis=1)))


def curvature_diameter_from_fourier(A: np.ndarray, B: np.ndarray, n: int) -> float:
    t = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    v = eval_fourier(A, B, t, derivative=1)
    a = eval_fourier(A, B, t, derivative=2)
    speed = np.linalg.norm(v, axis=1)
    cross = np.linalg.norm(np.cross(v, a), axis=1)
    R = np.full(n, np.inf, dtype=float)
    mask = cross > 1e-14
    R[mask] = speed[mask] ** 3 / cross[mask]
    return float(2.0 * np.min(R))


def self_distance_dcsd_proxy(
    A: np.ndarray,
    B: np.ndarray,
    n: int,
    sep_frac: float,
    angle_tol: float,
    chunk: int = 256,
) -> tuple[float, Optional[tuple[int, int]]]:
    """Approximate double-critical self-distance for a smooth sampled curve.

    This is a validator/normalizer, not a substitute for Ridgerunner.  It filters
    point pairs whose chord is nearly orthogonal to both endpoint tangents.
    """
    t = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    x = eval_fourier(A, B, t, derivative=0)
    v = eval_fourier(A, B, t, derivative=1)
    speed = np.linalg.norm(v, axis=1)
    T = v / np.maximum(speed[:, None], 1e-300)

    skip = max(8, int(sep_frac * n))
    d_min = np.inf
    pair: Optional[tuple[int, int]] = None

    for i0 in range(0, n, chunk):
        xi = x[i0:i0 + chunk]
        Ti = T[i0:i0 + chunk]
        m = len(xi)
        dvec = x[None, :, :] - xi[:, None, :]
        dist = np.linalg.norm(dvec, axis=2)

        ii = np.arange(i0, i0 + m)[:, None]
        jj = np.arange(n)[None, :]
        sep = np.abs(ii - jj)
        sep = np.minimum(sep, n - sep)
        mask = sep >= skip

        cos_i = np.abs(np.einsum("ijk,ik->ij", dvec, Ti)) / np.maximum(dist, 1e-300)
        cos_j = np.abs(np.einsum("ijk,jk->ij", dvec, T)) / np.maximum(dist, 1e-300)
        mask &= (cos_i <= angle_tol) & (cos_j <= angle_tol)

        if np.any(mask):
            vals = np.where(mask, dist, np.inf)
            local_flat = int(np.argmin(vals))
            local_val = float(vals.flat[local_flat])
            if local_val < d_min:
                loc = np.unravel_index(local_flat, vals.shape)
                d_min = local_val
                pair = (int(i0 + loc[0]), int(loc[1]))

    return d_min, pair


def estimate_diameter(A: np.ndarray, B: np.ndarray, n: int, sep_frac: float, angle_tol: float) -> tuple[float, float, float, str, Optional[tuple[int, int]]]:
    D_curv = curvature_diameter_from_fourier(A, B, n)
    D_self, pair = self_distance_dcsd_proxy(A, B, n, sep_frac=sep_frac, angle_tol=angle_tol)
    if not math.isfinite(D_self):
        # Fallback: if no double-critical-like pair is detected, curvature controls.
        D_self = np.inf
    if D_curv <= D_self:
        return D_curv, D_curv, D_self, "curvature", pair
    return D_self, D_curv, D_self, "self-distance", pair


def normalize_D1(A: np.ndarray, B: np.ndarray, D: float) -> tuple[np.ndarray, np.ndarray]:
    if not math.isfinite(D) or D <= 0:
        raise ValueError(f"Invalid diameter estimate: {D}")
    return A / D, B / D


def fmt_vec(v: np.ndarray) -> str:
    return ",".join(f"{float(x): .9f}" for x in v)


def write_ab_block(
    path: Path,
    A: np.ndarray,
    B: np.ndarray,
    L: float,
    source: str,
    diagnostics: CurveDiagnostics,
    title: str = "Generated trefoil AB candidate",
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    today = _dt.date.today().isoformat()
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(f'<DATA Title="{title}" Author="make_ideal_3_1_ab.py" Date="{today}">\n')
        f.write(f'<!-- Source: {source} -->\n')
        f.write(f'<!-- Honest D=1 normalization; not SONO/Ridgerunner-tightened. -->\n')
        f.write(f'<!-- Computed L/D={diagnostics.ropelength_L_over_D:.9f}; target Gilbert L={diagnostics.target_L:.9f}; relative error={diagnostics.rel_error_vs_target:.6e}. -->\n')
        f.write(f'<AB Id="{TARGET_ID}" Conway="{TARGET_CONWAY}" L="{L:.6f}" D=" 1.000000">\n')
        for i in range(1, len(A)):
            if np.max(np.abs(A[i])) < 5e-12 and np.max(np.abs(B[i])) < 5e-12:
                continue
            f.write(f'  <Coeff I="{i:2d}" A="{fmt_vec(A[i])}" B="{fmt_vec(B[i])}" />\n')
        f.write('</AB>\n')
        f.write('</DATA>\n')


def build_from_points(
    path: Path,
    fit_modes: int,
    resample_n: int,
    eval_n: int,
    sep_frac: float,
    angle_tol: float,
    standardize: bool,
) -> tuple[np.ndarray, np.ndarray, CurveDiagnostics]:
    raw = read_xyz_points(path)
    samples = resample_closed_by_arclength(raw, resample_n)
    A, B = fit_fourier_from_samples(samples, fit_modes)
    if standardize:
        A, B = standardize_like_ideal_txt(A, B)

    L0 = length_from_fourier(A, B, eval_n)
    D0, Dc, Ds, kind, pair = estimate_diameter(A, B, eval_n, sep_frac, angle_tol)
    R0 = L0 / D0
    A1, B1 = normalize_D1(A, B, D0)
    L1 = length_from_fourier(A1, B1, eval_n)
    rel = (R0 - TARGET_GILBERT_L) / TARGET_GILBERT_L
    warn = ""
    if abs(rel) > 1e-3:
        warn = "not ideal-compatible within 0.1%; use as AB seed or run ropelength minimizer"
    diag = CurveDiagnostics(
        source="knotplot_points",
        source_path=str(path),
        raw_points=int(len(raw)),
        fit_modes=int(fit_modes),
        eval_points=int(eval_n),
        length_before_scale=float(L0),
        diameter_before_scale=float(D0),
        ropelength_L_over_D=float(R0),
        curvature_diameter=float(Dc),
        self_distance_diameter=float(Ds) if math.isfinite(Ds) else float("inf"),
        active_diameter_kind=kind,
        dcsd_pair_i=None if pair is None else int(pair[0]),
        dcsd_pair_j=None if pair is None else int(pair[1]),
        target_L=float(TARGET_GILBERT_L),
        rel_error_vs_target=float(rel),
        warning=warn,
    )
    return A1, B1, diag


def build_from_fseries(
    path: Path,
    layout: str,
    fit_modes: int,
    resample_n: int,
    eval_n: int,
    sep_frac: float,
    angle_tol: float,
    standardize: bool,
) -> tuple[np.ndarray, np.ndarray, CurveDiagnostics]:
    A0, B0 = read_fseries(path, layout=layout)
    # Force arclength parameterization before writing Ideal.txt-style AB.
    A, B = arclength_reparameterize_fourier(A0, B0, resample_n, fit_modes)
    if standardize:
        A, B = standardize_like_ideal_txt(A, B)

    L0 = length_from_fourier(A, B, eval_n)
    D0, Dc, Ds, kind, pair = estimate_diameter(A, B, eval_n, sep_frac, angle_tol)
    R0 = L0 / D0
    A1, B1 = normalize_D1(A, B, D0)
    L1 = length_from_fourier(A1, B1, eval_n)
    rel = (R0 - TARGET_GILBERT_L) / TARGET_GILBERT_L
    warn = ""
    if abs(rel) > 1e-3:
        warn = "not ideal-compatible within 0.1%; use as AB seed or run ropelength minimizer"
    diag = CurveDiagnostics(
        source="fseries",
        source_path=str(path),
        raw_points=int(len(A0) - 1),
        fit_modes=int(fit_modes),
        eval_points=int(eval_n),
        length_before_scale=float(L0),
        diameter_before_scale=float(D0),
        ropelength_L_over_D=float(R0),
        curvature_diameter=float(Dc),
        self_distance_diameter=float(Ds) if math.isfinite(Ds) else float("inf"),
        active_diameter_kind=kind,
        dcsd_pair_i=None if pair is None else int(pair[0]),
        dcsd_pair_j=None if pair is None else int(pair[1]),
        target_L=float(TARGET_GILBERT_L),
        rel_error_vs_target=float(rel),
        warning=warn,
    )
    return A1, B1, diag


def write_summary_csv(path: Path, diagnostics: Iterable[CurveDiagnostics]) -> None:
    rows = [asdict(d) for d in diagnostics]
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main() -> int:
    ap = argparse.ArgumentParser(description="Convert KnotPlot/Fremlin trefoil data to Ideal.txt-style AB Id=3:1:1 records.")
    ap.add_argument("--knotplot", type=Path, default=None, help="3-column closed point list exported by KnotPlot")
    ap.add_argument("--fseries", type=Path, default=None, help="6-column Fremlin/Fresnel Fourier-series file")
    ap.add_argument("--outdir", type=Path, default=Path("ideal_3_1_out"))
    ap.add_argument("--point-modes", type=int, default=16, help="Fourier modes for coarse KnotPlot point export; default 16 smooths 47-point exports")
    ap.add_argument("--fseries-modes", type=int, default=256, help="Fourier modes after arclength reparametrizing fseries")
    ap.add_argument("--resample-n", type=int, default=4096, help="arclength samples before Fourier fit")
    ap.add_argument("--eval-n", type=int, default=4096, help="samples for length/diameter diagnostics")
    ap.add_argument("--fseries-layout", choices=["ax_bx_ay_by_az_bz", "ax_ay_az_bx_by_bz"], default="ax_bx_ay_by_az_bz")
    ap.add_argument("--sep-frac", type=float, default=0.02, help="minimum circular index separation for self-distance candidates")
    ap.add_argument("--angle-tol", type=float, default=0.075, help="DCSD tangent-orthogonality tolerance; smaller is stricter")
    ap.add_argument("--no-standardize", action="store_true", help="skip approximate Gilbert orientation/sign standardization")
    args = ap.parse_args()

    if args.knotplot is None and args.fseries is None:
        ap.error("provide --knotplot and/or --fseries")

    args.outdir.mkdir(parents=True, exist_ok=True)
    records: list[tuple[str, np.ndarray, np.ndarray, CurveDiagnostics]] = []
    standardize = not args.no_standardize

    if args.knotplot is not None:
        A, B, d = build_from_points(
            args.knotplot,
            fit_modes=args.point_modes,
            resample_n=args.resample_n,
            eval_n=args.eval_n,
            sep_frac=args.sep_frac,
            angle_tol=args.angle_tol,
            standardize=standardize,
        )
        records.append(("knotplot", A, B, d))
        write_ab_block(args.outdir / "ideal_3_1_from_knotplot.txt", A, B, d.ropelength_L_over_D, "knotplot", d)

    if args.fseries is not None:
        A, B, d = build_from_fseries(
            args.fseries,
            layout=args.fseries_layout,
            fit_modes=args.fseries_modes,
            resample_n=args.resample_n,
            eval_n=args.eval_n,
            sep_frac=args.sep_frac,
            angle_tol=args.angle_tol,
            standardize=standardize,
        )
        records.append(("fseries", A, B, d))
        write_ab_block(args.outdir / "ideal_3_1_from_fseries.txt", A, B, d.ropelength_L_over_D, "fseries", d)

    diagnostics = [r[3] for r in records]
    write_summary_csv(args.outdir / "summary.csv", diagnostics)
    with open(args.outdir / "summary.json", "w", encoding="utf-8") as f:
        json.dump([asdict(d) for d in diagnostics], f, indent=2, allow_nan=True)

    # Best candidate = closest honest L/D to Gilbert target.
    if records:
        best = min(records, key=lambda r: abs(r[3].rel_error_vs_target))
        name, A, B, d = best
        write_ab_block(args.outdir / "ideal_3_1_best.txt", A, B, d.ropelength_L_over_D, f"best={name}", d)

    print("Wrote:")
    for p in ["ideal_3_1_from_knotplot.txt", "ideal_3_1_from_fseries.txt", "ideal_3_1_best.txt", "summary.csv", "summary.json"]:
        q = args.outdir / p
        if q.exists():
            print(f"  {q}")
    print()
    for d in diagnostics:
        print(f"{d.source:16s} L/D={d.ropelength_L_over_D:.9f}  Dkind={d.active_diameter_kind:13s}  rel.err={d.rel_error_vs_target:+.6%}")
        if d.warning:
            print(f"  warning: {d.warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
