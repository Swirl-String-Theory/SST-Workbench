from __future__ import annotations
import hashlib, random
import numpy as np
from sst_falsifier_core.stats import nearest_rational, permutation_pvalue, benjamini_hochberg

# Full preregistered twist-family adjacency. No historical pair receives special weight.
TWIST_CHAIN=("3_1","4_1","5_2","6_1","7_2","8_1","9_2","10_1")

def pair_statistics(records,qmax=12,permutations=2000,seed=43001):
    by={}
    for r in records: by.setdefault((r["provider"],r["invariant"]),{})[r["topology"]]=float(r["value"])
    results=[]; rng=random.Random(seed)
    for (provider,inv),vals in sorted(by.items()):
        available=[k for k in TWIST_CHAIN if k in vals]
        for a,b in zip(TWIST_CHAIN[:-1],TWIST_CHAIN[1:]):
            if a not in vals or b not in vals: continue
            for transform,x in [("absolute_difference",abs(vals[b]-vals[a])),("absolute_ratio",abs(vals[b]/vals[a]) if vals[a] else float('nan'))]:
                if not np.isfinite(x): continue
                rat=nearest_rational(x,qmax); score=rat["scaled_error"]
                pool=[vals[k] for k in available]; null=[]
                if len(pool)>=3:
                    for _ in range(permutations):
                        u,v=rng.sample(pool,2); y=abs(v-u) if transform=="absolute_difference" else (abs(v/u) if u else float('nan'))
                        if np.isfinite(y): null.append(nearest_rational(y,qmax)["scaled_error"])
                p=permutation_pvalue(score,null,True)
                key=hashlib.sha256(f"{provider}|{inv}|{a}|{b}|{transform}".encode()).hexdigest()[:16].upper()
                results.append({"opaque_test_id":key,"provider":provider,"invariant":inv,"chain_index":TWIST_CHAIN.index(a),"transform":transform,
                                "x":x,"best_p":rat["p"],"best_q":rat["q"],"best_value":rat["value"],"scaled_error":score,"permutation_p":p})
    qs=benjamini_hochberg([r["permutation_p"] for r in results])
    for r,q in zip(results,qs):r["bh_q"]=float(q)
    return results
