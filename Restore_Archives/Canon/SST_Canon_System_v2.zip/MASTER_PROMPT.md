
# MASTER PROMPT — SST CANON v0.8.0 (PRO)

MODE: ORCHESTRATOR + AGENT SYSTEM

OBJECTIVE:
Construct: Swirl-String-Theory_Canon-v0.8.0.tex

PIPELINE:
1. Planner.md
2. Prompt_1_Skeleton.md
3. Prompt_2_Refine.md
4. Prompt_3_Expand.md (iterate per section)
5. Prompt_4_Assemble.md
6. Prompt_5_Verify.md

GLOBAL RULES:
- Use LaTeX with \label and \ref everywhere
- Use \cite{} for non-original ideas
- Label: [ORTHODOX], [DERIVED], [SPECULATIVE]

OUTPUT:
- Do NOT summarize
- Expand fully
- Continue until complete
