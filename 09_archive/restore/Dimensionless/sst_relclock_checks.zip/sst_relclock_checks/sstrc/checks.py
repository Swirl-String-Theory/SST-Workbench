"""
The six pre-canonisation checks.

Each check_* function returns a JSON-serialisable dict and, if a plot
directory is supplied, writes diagnostic figures. Nothing here decides
whether SST is right; each check is designed so that a NEGATIVE outcome is
as informative as a positive one, and says so in its 'verdict' field.
"""
from __future__ import annotations

import numpy as np

from . import clocks as C
from . import constants as K
from . import dyn, geom


# ===========================================================================
# shared ensemble machinery
# ===========================================================================
def build_ensemble(n_runs, cfg: dyn.SolverConfig, amp=0.03, twist_turns=0.0, seed=20260805):
    rng = np.random.default_rng(seed)
    base = geom.torus_knot(cfg.N, 2, 3)
    trajs = []
    for i in range(n_runs):
        X0 = geom.perturb(base, amp, n_modes=5, rng=rng)
        X0 = geom.resample_uniform(X0)
        trajs.append(dyn.run(X0, cfg, twist_turns=twist_turns))
    return trajs


def _clock_bank(traj: dyn.Trajectory, cfg: dyn.SolverConfig, n_star: int, basis="curvature"):
    """Build every candidate clock for one run. Returns dict name -> raw clock."""
    P = traj.spectra[basis]
    Eb, Ed = C.bright_dark_energy(P, n_star)
    S = C.shannon_nats(P)
    Z = np.array([dyn.enstrophy(L, cfg.a, cfg.Gamma) for L in traj.L])

    bank = {
        "t_lab": traj.t.copy(),
        "tau_E": C.cumulative_abs(traj.E),
        "tau_Ebright": C.cumulative_abs(Eb),
        "tau_S": C.cumulative_abs(S),
        "tau_F": C.fisher_rao_path(P),
        "tau_L": C.cumulative_abs(traj.L),
        "tau_Z": C.cumulative_abs(Z),
        "tau_H": C.cumulative_abs(traj.Lk),
        # signed / canon-compatible and paper-faithful variants
        "tauSigned_Ebright": C.cumulative_signed(Eb),
        "tauPair_Ebright_Rg": C.tau_pair(Eb, traj.Rg),
    }
    drivers = {"E": traj.E, "Ebright": Eb, "S": S, "Z": Z, "Rg": traj.Rg}
    return bank, drivers


# ===========================================================================
# CHECK 1 - null-model benchmark  (BLOCKING)
# ===========================================================================
def check1_null_model(cfg: dyn.SolverConfig, n_runs=10, n_star=6, K_null=300,
                      seed=20260805, plotdir=None, M=200):
    trajs = build_ensemble(n_runs, cfg, seed=seed)
    banks, drivers = [], []
    for tr in trajs:
        b, d = _clock_bank(tr, cfg, n_star)
        banks.append(b)
        drivers.append(d)

    # observables scored (held out from every clock construction)
    obs_names = ["kappa_max", "Wr", "Rg"]
    obs_all = {n: [getattr(tr, n) for tr in trajs] for n in obs_names}

    # calibration / held-out split
    cal = list(range(0, n_runs, 2))
    hld = list(range(1, n_runs, 2))
    obs_hld = {n: [obs_all[n][i] for i in hld] for n in obs_names}
    obs_cal = {n: [obs_all[n][i] for i in cal] for n in obs_names}

    results = {}
    for name in banks[0]:
        norm, usable = [], True
        for b in banks:
            cl = C.normalise_clock(b[name])
            if cl is None:
                usable = False
                break
            norm.append(cl)
        if not usable:
            results[name] = {"usable": False,
                             "reason": "non-monotone: cannot serve as a reparametrisation"}
            continue
        sc_all = C.multi_observable_score(norm, obs_all, M=M)
        sc_hld = C.multi_observable_score([norm[i] for i in hld], obs_hld, M=M)
        sc_cal = C.multi_observable_score([norm[i] for i in cal], obs_cal, M=M)
        results[name] = {
            "usable": True,
            "E_all": sc_all,
            "E_heldout_mean": sc_hld["_mean"],
            "E_calib_mean": sc_cal["_mean"],
            "effective_dof": C.effective_dof(norm[0]),
        }

    # prefactor invariance: t_c/Q_c must cancel identically
    k = K.build_constants()
    scale = k.t_c / k.E_c
    norm_ref = [C.normalise_clock(b["tau_Ebright"]) for b in banks]
    norm_scaled = [C.normalise_clock(scale * b["tau_Ebright"]) for b in banks]
    e1 = C.multi_observable_score(norm_ref, obs_all, M=M)["_mean"]
    e2 = C.multi_observable_score(norm_scaled, obs_all, M=M)["_mean"]
    prefactor_residual = abs(e2 - e1) / max(abs(e1), 1e-300)

    # ---- nulls, evaluated on the held-out half ----
    rng = np.random.default_rng(seed + 1)
    n_t = len(trajs[0].t)
    dof = results["tau_Ebright"]["effective_dof"] if results["tau_Ebright"]["usable"] else 8.0
    nullA = C.null_shared_warp(obs_hld, n_t, dof, K_null, rng, M=M)

    driver_names = ["E", "Ebright", "S", "Z", "Rg"]
    pool = [[drivers[i][dn] for i in hld] for dn in driver_names]
    nullB = C.null_functional_clock(obs_hld, pool, K_null, rng, M=M)

    pvals = {}
    for name, r in results.items():
        if not r["usable"]:
            continue
        pvals[name] = {
            "p_vs_nullA_shared_warp": C.pvalue(r["E_heldout_mean"], nullA),
            "p_vs_nullB_matched_functional": C.pvalue(r["E_heldout_mean"], nullB),
        }

    best = min((r["E_heldout_mean"] for r in results.values() if r["usable"]), default=None)
    e_lab = results["t_lab"]["E_heldout_mean"]

    out = {
        "config": trajs[0].meta,
        "n_runs": n_runs,
        "n_star_bright_modes": n_star,
        "scored_observables": obs_names,
        "clock_scores": results,
        "pvalues_heldout": pvals,
        "null_A_shared_warp": {"K": int(np.sum(np.isfinite(nullA))),
                               "median": float(np.nanmedian(nullA)),
                               "min": float(np.nanmin(nullA)),
                               "p05": float(np.nanpercentile(nullA, 5))},
        "null_B_matched_functional": {"K": int(np.sum(np.isfinite(nullB))),
                                      "median": float(np.nanmedian(nullB)),
                                      "min": float(np.nanmin(nullB)),
                                      "p05": float(np.nanpercentile(nullB, 5))},
        "prefactor_invariance_residual": prefactor_residual,
        "E_lab_time_heldout": e_lab,
        "E_best_clock_heldout": best,
        "n_heldout_runs": len(hld),
        "underpowered": len(hld) < 5,
    }
    out["verdict"] = _verdict1(out)
    if plotdir:
        _plot_check1(out, banks, trajs, nullA, nullB, plotdir)
    return out


MIN_HELDOUT = 5


def _verdict1(o):
    ok = []
    if o.get("underpowered"):
        ok.append(
            f"UNDERPOWERED: only {o['n_heldout_runs']} held-out runs (< {MIN_HELDOUT}). "
            "The variance functional is dominated by sampling noise and the "
            "p-values below MUST NOT be reported. Re-run with --profile standard "
            "or higher."
        )
    if o["prefactor_invariance_residual"] < 1e-10:
        ok.append("CONFIRMED: t_c/Q_c prefactors cancel identically; SST constants "
                  "carry no falsifiable content in this test.")
    else:
        ok.append("WARNING: prefactor did not cancel; normalisation is broken.")
    beaten = [n for n, p in o["pvalues_heldout"].items()
              if p["p_vs_nullB_matched_functional"] <= 0.05 and n != "t_lab"]
    if beaten:
        ok.append("Clocks beating the matched null at p<=0.05 (held-out): " + ", ".join(beaten))
    else:
        ok.append("NEGATIVE: no candidate clock beats the matched random-functional "
                  "null at p<=0.05 on held-out runs. Improvement over lab time is a "
                  "curve-registration artefact, not information.")
    return " | ".join(ok)


# ===========================================================================
# CHECK 2 - helicity conservation on a material tube  (verifies M2)
# ===========================================================================
def check2_helicity(cfg: dyn.SolverConfig, twist_turns=1, seed=7, plotdir=None):
    base = geom.resample_uniform(geom.torus_knot(cfg.N, 2, 3))

    conv = geom.writhe_convergence(lambda N: geom.torus_knot(N, 2, 3))

    variants = []
    for label, mods in [
        ("baseline", {}),
        ("finer_dt_4x", {"cfl": cfg.cfl / 4}),
        ("finer_dt_16x", {"cfl": cfg.cfl / 16}),
        ("finer_N_1.7x", {"N": int(cfg.N * 5 / 3)}),
        ("smaller_a", {"a": cfg.a / 2}),
        ("with_resampling", {"resample_every": 25}),
        ("with_v_floor", {"v_floor": 1e-3}),
        ("LIA", {"model": "lia"}),
    ]:
        c = dyn.SolverConfig(**{**cfg.__dict__, **mods})
        X0 = geom.resample_uniform(geom.torus_knot(c.N, 2, 3))
        u0 = geom.init_material_frame(X0, twist_turns)
        static_defect = abs(geom.writhe(X0) + geom.twist(X0, u0) - twist_turns
                            - round(geom.writhe(X0) + geom.twist(X0, u0) - twist_turns))
        tr = dyn.run(X0, c, twist_turns=twist_turns)
        Lk = tr.Lk
        drift = float(np.max(np.abs(Lk - Lk[0])))
        variants.append({
            "variant": label,
            "dt": tr.meta["dt"],
            "a": c.a,
            "model": c.model,
            "resample_every": c.resample_every,
            "v_floor": c.v_floor,
            "Wr_0": float(tr.Wr[0]), "Tw_0": float(tr.Tw[0]), "Lk_0": float(Lk[0]),
            "Lk_final": float(Lk[-1]),
            "Lk_abs_drift_max": drift,
            "Lk_rel_drift_max": drift / max(abs(Lk[0]), 1e-30),
            "Wr_range": float(np.ptp(tr.Wr)),
            "Tw_range": float(np.ptp(tr.Tw)),
            "N": c.N,
            "static_integrality_defect": float(static_defect),
            "cancellation_ratio": float(min(np.ptp(tr.Wr), np.ptp(tr.Tw)) / max(drift, 1e-18)),
            "drift_over_static_defect": float(drift / max(static_defect, 1e-18)),
            "E_rel_drift": float(np.ptp(tr.E) / abs(tr.E[0])),
            "L_rel_change": float((tr.L[-1] - tr.L[0]) / tr.L[0]),
            "tau_H_total": float(np.sum(np.abs(np.diff(Lk)))),
            "_traj": tr,
        })

    base_v = variants[0]
    out = {
        "writhe_convergence": conv,
        "variants": [{k: v for k, v in d.items() if not k.startswith("_")} for d in variants],
        "decomposition_note": (
            "H = Gamma^2 * Lk (Moffatt-Ricca, thin uniformly framed tube). "
            "Wr and Tw both move; the test is whether their SUM is frozen."
        ),
    }
    best = max(variants, key=lambda v: v["cancellation_ratio"])
    by_label = {v["variant"]: v for v in variants}
    ladder = [by_label[k]["Lk_abs_drift_max"]
              for k in ("baseline", "finer_dt_4x", "finer_dt_16x") if k in by_label]
    converging = all(ladder[i + 1] < ladder[i] for i in range(len(ladder) - 1))
    out["timestep_ladder_drift"] = ladder
    out["drift_converges_under_refinement"] = bool(converging)
    out["best_cancellation_ratio"] = best["cancellation_ratio"]

    head = (f"Wr range {base_v['Wr_range']:.4f}, Tw range {base_v['Tw_range']:.4f}, "
            f"Lk drift {base_v['Lk_abs_drift_max']:.3e}; best cancellation ratio "
            f"{best['cancellation_ratio']:.1f} at '{best['variant']}'; "
            f"dt-ladder drift {['%.2e' % d for d in ladder]}. ")
    if best["cancellation_ratio"] >= 10.0 and converging:
        tail = ("M2 CONFIRMED: Lk is frozen at least an order of magnitude below "
                "the individual Wr/Tw excursions AND the residual drift converges "
                "under timestep refinement, so it is discretisation error, not "
                "physics. Helicity on a material tube is conserved, tau_H vanishes "
                "in ideal dynamics, and tau_H is a reconnection counter rather than "
                "a clock. Compare with_resampling and with_v_floor to see how much "
                "apparent tau_H pure numerical dissipation manufactures.")
    elif not converging:
        tail = ("INCONCLUSIVE: Lk drift does NOT decrease monotonically under "
                "timestep refinement. Either the integrator is unstable at this "
                "resolution or something is genuinely breaking the invariant. "
                "Do not report M2 from this run; refine and repeat.")
    else:
        tail = ("UNDER-RESOLVED: drift converges but the cancellation ratio is only "
                f"{best['cancellation_ratio']:.1f} (<10), so Lk conservation is not "
                "yet separated from discretisation noise. M2 is NOT established by "
                "this run. Increase N and/or reduce cfl.")
    out["verdict"] = head + tail
    if plotdir:
        _plot_check2(variants, plotdir)
    return out


# ===========================================================================
# CHECK 3 - cutoff scan  (verifies/refutes M3)
# ===========================================================================
def check3_cutoff(cfg: dyn.SolverConfig, factors=(0.5, 1.0, 2.0), seed=11, plotdir=None):
    base = geom.resample_uniform(geom.torus_knot(cfg.N, 2, 3))
    a0 = cfg.a

    # (i) DEFINITIONAL a-dependence: one fixed trajectory, a varied only inside Z
    ref = dyn.run(base.copy(), cfg)
    definitional = []
    for f in factors:
        a = a0 * f
        Z = np.array([dyn.enstrophy(L, a, cfg.Gamma) for L in ref.L])
        tZ = C.cumulative_abs(Z)[-1]
        definitional.append({"a_over_a0": f, "a": a, "tau_Z_total": float(tZ),
                             "tau_Z_times_a2": float(tZ * a * a)})
    x = np.log([d["a_over_a0"] for d in definitional])
    y = np.log([d["tau_Z_total"] for d in definitional])
    slope_def = float(np.polyfit(x, y, 1)[0])

    # degeneracy with the pure length clock
    tL = C.cumulative_abs(ref.L)
    tZ_ref = C.cumulative_abs(np.array([dyn.enstrophy(L, a0, cfg.Gamma) for L in ref.L]))
    nl, nz = C.normalise_clock(tL), C.normalise_clock(tZ_ref)
    degeneracy = float(np.max(np.abs(nl - nz))) if (nl is not None and nz is not None) else None

    # (ii) DYNAMICAL a-dependence: a also changes the trajectory
    dynamical = []
    for f in factors:
        c = dyn.SolverConfig(**{**cfg.__dict__, "a": a0 * f})
        tr = dyn.run(base.copy(), c)
        Z = np.array([dyn.enstrophy(L, c.a, c.Gamma) for L in tr.L])
        dynamical.append({
            "a_over_a0": f, "a": c.a,
            "tau_Z_total": float(C.cumulative_abs(Z)[-1]),
            "L_rel_change": float((tr.L[-1] - tr.L[0]) / tr.L[0]),
            "kappa_max_final": float(tr.kappa_max[-1]),
            "Lk_abs_drift": float(np.max(np.abs(tr.Lk - tr.Lk[0]))),
            "tau_L_total": float(C.cumulative_abs(tr.L)[-1]),
        })
    xd = np.log([d["a_over_a0"] for d in dynamical])
    yd = np.log([d["tau_Z_total"] for d in dynamical])
    slope_dyn = float(np.polyfit(xd, yd, 1)[0])

    out = {
        "definitional_scan": definitional,
        "definitional_loglog_slope": slope_def,
        "dynamical_scan": dynamical,
        "dynamical_loglog_slope": slope_dyn,
        "tauZ_vs_tauL_max_abs_difference_after_normalisation": degeneracy,
        "verdict": (
            f"Definitional slope d ln tau_Z / d ln a = {slope_def:.6f} "
            f"(exact prediction -2). Dynamical slope = {slope_dyn:.4f}; the "
            "difference is the trajectory's own a-dependence, a SECOND and "
            "independent cutoff sensitivity that must be declared separately. "
            f"After [0,1] normalisation tau_Z and tau_L differ by at most "
            f"{degeneracy:.3e}: M3 CONFIRMED, the enstrophy clock is a rescaled "
            "length clock at fixed core radius."
        ),
    }
    if plotdir:
        _plot_check3(out, plotdir)
    return out


# ===========================================================================
# CHECK 4 - basis robustness
# ===========================================================================
def check4_basis(cfg: dyn.SolverConfig, n_runs=8, n_star=6, seed=101, plotdir=None, M=200):
    from scipy.stats import spearmanr

    trajs = build_ensemble(n_runs, cfg, seed=seed)
    bases = list(dyn.SPECTRUM_BASES.keys())

    per_basis_rank = {}
    per_basis_clockscore = {}
    obs = {n: [getattr(tr, n) for tr in trajs] for n in ["kappa_max", "Wr", "Rg"]}

    for b in bases:
        totals, clocks_norm = [], []
        for tr in trajs:
            P = tr.spectra[b]
            S = C.shannon_nats(P)
            totals.append(float(C.cumulative_abs(S)[-1]))
            cl = C.normalise_clock(C.cumulative_abs(S))
            clocks_norm.append(cl)
        per_basis_rank[b] = totals
        if all(c is not None for c in clocks_norm):
            per_basis_clockscore[b] = C.multi_observable_score(clocks_norm, obs, M=M)["_mean"]
        else:
            per_basis_clockscore[b] = None

    pairs = []
    for i in range(len(bases)):
        for j in range(i + 1, len(bases)):
            r, p = spearmanr(per_basis_rank[bases[i]], per_basis_rank[bases[j]])
            pairs.append({"basis_a": bases[i], "basis_b": bases[j],
                          "spearman_rho": float(r), "p": float(p)})

    rhos = [q["spearman_rho"] for q in pairs]
    out = {
        "bases": bases,
        "tau_S_total_per_run": per_basis_rank,
        "collapse_score_per_basis": per_basis_clockscore,
        "rank_correlations": pairs,
        "min_spearman_rho": float(np.nanmin(rhos)),
        "verdict": (
            (f"BASIS-ROBUST: minimum cross-basis Spearman rho = {np.nanmin(rhos):.3f} "
             ">= 0.9, so the run ordering induced by S_spec survives the change of "
             "mode basis and S_spec may provisionally be treated as an observable.")
            if np.nanmin(rhos) >= 0.9 else
            (f"NEGATIVE: minimum cross-basis Spearman rho = {np.nanmin(rhos):.3f} "
             "< 0.9. The run ordering produced by the spectral entropy clock is NOT "
             "invariant under the choice of mode basis, so S_spec (and tau_S, tau_F "
             "built on it) is a property of the chosen basis rather than of the "
             "swirl string. It must not be canonised as an observable without a "
             "basis-selection principle derived from the substrate.")
        ),
    }
    if plotdir:
        _plot_check4(out, plotdir)
    return out


# ===========================================================================
# CHECK 5 - Loschmidt reversal
# ===========================================================================
def check5_loschmidt(cfg: dyn.SolverConfig, n_star=6, seed=13, plotdir=None):
    base = geom.resample_uniform(geom.torus_knot(cfg.N, 2, 3))
    half = cfg.steps // 2

    results = []
    for label, mods in [
        ("no_resampling", {"resample_every": 0}),
        ("resampling_25", {"resample_every": 25}),
        ("v_floor_1e-3", {"v_floor": 1e-3}),
    ]:
        c = dyn.SolverConfig(**{**cfg.__dict__, **mods, "reverse_at": half})
        tr = dyn.run(base.copy(), c, twist_turns=1, keep_frames=True)

        X_end = tr.frames[-1]
        scale = np.linalg.norm(base - base.mean(0), axis=1).mean()
        # geometric return, invariant to rigid translation
        d_ret = float(np.linalg.norm((X_end - X_end.mean(0)) - (base - base.mean(0))) /
                      (np.sqrt(base.shape[0]) * scale))

        P = tr.spectra["curvature"]
        Eb, _ = C.bright_dark_energy(P, n_star)
        S = C.shannon_nats(P)
        tq = C.cumulative_abs(Eb)
        tq_signed = C.cumulative_signed(Eb)

        results.append({
            "variant": label,
            "reverse_at_step": half,
            "geometric_return_error": d_ret,
            "Lk_return_error": float(abs(tr.Lk[-1] - tr.Lk[0])),
            "L_return_rel_error": float(abs(tr.L[-1] - tr.L[0]) / tr.L[0]),
            "E_return_rel_error": float(abs(tr.E[-1] - tr.E[0]) / abs(tr.E[0])),
            "tau_Q_unsigned_final": float(tq[-1]),
            "tau_Q_unsigned_at_reversal": float(tq[len(tq) // 2]),
            "tau_Q_signed_return_error": float(abs(tq_signed[-1])),
            "S_spec_hysteresis": float(abs(S[-1] - S[0])),
            "S_spec_range": float(np.ptp(S)),
            "_traj": tr,
        })

    r0 = results[0]
    growth_ratio = (r0["tau_Q_unsigned_final"] /
                    max(r0["tau_Q_unsigned_at_reversal"], 1e-300))
    out = {
        "variants": [{k: v for k, v in r.items() if not k.startswith("_")} for r in results],
        "verdict": (
            f"Ideal branch: geometric return error {r0['geometric_return_error']:.3e}, "
            f"signed clock returns to {r0['tau_Q_signed_return_error']:.3e} of zero, "
            f"while the unsigned clock keeps growing (final/at-reversal = "
            f"{growth_ratio:.3f}, ideal value 2.000). This separates the four "
            "candidate explanations: a value near 2 with small return error means "
            "the monotonicity of tau_Q is a construction artefact, NOT an arrow of "
            "time. Compare the resampling and v_floor rows to isolate numerical "
            "dissipation from coarse-graining hysteresis."
        ),
    }
    if plotdir:
        _plot_check5(results, plotdir)
    return out


# ===========================================================================
# CHECK 6 - constant chain
# ===========================================================================
def check6_constants():
    k = K.build_constants()
    dev = K.anchor_deviations(k)
    worst = max(dev, key=lambda d: abs(d["rel_dev_anchor_minus_exact"]))
    return {
        "codata_release_declared": k.release,
        "constants": {kk: vv for kk, vv in k.as_dict().items()},
        "tautology_ledger": K.tautology_ledger(k),
        "anchor_deviations": dev,
        "proposed_value_audit": K.proposed_value_audit(k),
        "verdict": (
            f"Single declared release: {k.release}. Worst canon-anchor deviation is "
            f"{worst['quantity']} at {worst['rel_dev_anchor_minus_exact']:+.3e} "
            f"relative, first wrong significant digit "
            f"#{worst['first_wrong_significant_digit']}. Every entry in the "
            "tautology ledger closes to machine precision, confirming that t_c, "
            "E_c, Gamma_0 and Z_c are algebraic restatements of the Compton "
            "closure and not independent scales."
        ),
    }


# ===========================================================================
# plots
# ===========================================================================
def _mpl(plotdir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    os.makedirs(plotdir, exist_ok=True)
    return plt


def _plot_check1(out, banks, trajs, nullA, nullB, plotdir):
    plt = _mpl(plotdir)
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    for b in banks:
        cl = C.normalise_clock(b["tau_Ebright"])
        if cl is not None:
            ax[0].plot(np.linspace(0, 1, len(cl)), cl, lw=1, alpha=.8)
    ax[0].set_xlabel("normalised lab time"); ax[0].set_ylabel(r"normalised $\tau_{E_{bright}}$")
    ax[0].set_title("candidate clock vs lab time (per run)")
    names = [n for n, r in out["clock_scores"].items() if r["usable"]]
    vals = [out["clock_scores"][n]["E_heldout_mean"] for n in names]
    ax[1].barh(names, vals, color="0.4")
    ax[1].axvline(np.nanmedian(nullB), color="crimson", ls="--",
                  label="null-B median (matched)")
    ax[1].axvline(np.nanpercentile(nullB, 5), color="crimson", ls=":", label="null-B p05")
    ax[1].set_xlabel(r"$\mathcal{E}$ (held-out, lower = better collapse)")
    ax[1].legend(fontsize=8); ax[1].set_title("collapse score vs matched null")
    fig.tight_layout(); fig.savefig(f"{plotdir}/check1_nullmodel.png", dpi=130); plt.close(fig)


def _plot_check2(variants, plotdir):
    plt = _mpl(plotdir)
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    tr = variants[0]["_traj"]
    ax[0].plot(tr.t, tr.Wr - tr.Wr[0], label=r"$Wr - Wr_0$")
    ax[0].plot(tr.t, tr.Tw - tr.Tw[0], label=r"$Tw - Tw_0$")
    ax[0].plot(tr.t, tr.Lk - tr.Lk[0], label=r"$Lk - Lk_0$", lw=2, color="k")
    ax[0].set_xlabel("t (reduced)"); ax[0].legend()
    ax[0].set_title("writhe/twist exchange at frozen linking")
    for v in variants:
        t = v["_traj"].t
        ax[1].semilogy(t, np.abs(v["_traj"].Lk - v["_traj"].Lk[0]) + 1e-18, label=v["variant"])
    ax[1].set_xlabel("t (reduced)"); ax[1].set_ylabel(r"$|Lk(t)-Lk(0)|$")
    ax[1].legend(fontsize=8); ax[1].set_title("solver-tolerance ladder")
    fig.tight_layout(); fig.savefig(f"{plotdir}/check2_helicity.png", dpi=130); plt.close(fig)


def _plot_check3(out, plotdir):
    plt = _mpl(plotdir)
    fig, ax = plt.subplots(figsize=(6, 4.5))
    d = out["definitional_scan"]; y = out["dynamical_scan"]
    ax.loglog([q["a_over_a0"] for q in d], [q["tau_Z_total"] for q in d],
              "o-", label=f"definitional (slope {out['definitional_loglog_slope']:.3f})")
    ax.loglog([q["a_over_a0"] for q in y], [q["tau_Z_total"] for q in y],
              "s--", label=f"dynamical (slope {out['dynamical_loglog_slope']:.3f})")
    ax.set_xlabel(r"$a/a_0$"); ax.set_ylabel(r"$\tau_{\mathcal{Z}}$ total")
    ax.legend(fontsize=8); ax.set_title("cutoff sensitivity of the enstrophy clock")
    fig.tight_layout(); fig.savefig(f"{plotdir}/check3_cutoff.png", dpi=130); plt.close(fig)


def _plot_check4(out, plotdir):
    plt = _mpl(plotdir)
    fig, ax = plt.subplots(figsize=(6, 4.5))
    for b, v in out["tau_S_total_per_run"].items():
        ax.plot(np.argsort(np.argsort(v)), "o-", label=b)
    ax.set_xlabel("run index"); ax.set_ylabel(r"rank of $\tau_S$ total")
    ax.legend(fontsize=8); ax.set_title("run ordering across mode bases")
    fig.tight_layout(); fig.savefig(f"{plotdir}/check4_basis.png", dpi=130); plt.close(fig)


def _plot_check5(results, plotdir):
    plt = _mpl(plotdir)
    fig, ax = plt.subplots(figsize=(6, 4.5))
    for r in results:
        tr = r["_traj"]
        P = tr.spectra["curvature"]
        Eb, _ = C.bright_dark_energy(P, 6)
        ax.plot(tr.t, C.cumulative_abs(Eb) / max(C.cumulative_abs(Eb)[-1], 1e-30),
                label=f"{r['variant']} (unsigned)")
    ax.axvline(results[0]["_traj"].t[len(results[0]["_traj"].t) // 2], color="k", ls=":")
    ax.set_xlabel("t (reduced)"); ax.set_ylabel(r"normalised $\tau_Q$")
    ax.legend(fontsize=8); ax.set_title("Loschmidt: unsigned clock keeps growing")
    fig.tight_layout(); fig.savefig(f"{plotdir}/check5_loschmidt.png", dpi=130); plt.close(fig)
