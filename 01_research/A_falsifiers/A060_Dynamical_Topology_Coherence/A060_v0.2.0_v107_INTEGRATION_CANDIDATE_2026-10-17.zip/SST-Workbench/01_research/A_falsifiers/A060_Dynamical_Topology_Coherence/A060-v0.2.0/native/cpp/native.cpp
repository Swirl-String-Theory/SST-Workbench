#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <cmath>
#include <stdexcept>
namespace py=pybind11;
py::dict tensor(py::array_t<double, py::array::c_style | py::array::forcecast> input){
 auto b=input.request();if(b.ndim!=2||b.shape[0]!=3||b.shape[1]!=3)throw std::invalid_argument("3x3 tensor required");
 auto A=input.unchecked<2>();double S[3][3],S2[3][3]={},w[3]={A(2,1)-A(1,2),A(0,2)-A(2,0),A(1,0)-A(0,1)};
 double trA2=0.,trS3=0.,Vs=0.;
 for(int i=0;i<3;++i)for(int j=0;j<3;++j){if(!std::isfinite(A(i,j)))throw std::invalid_argument("finite tensor required");S[i][j]=.5*(A(i,j)+A(j,i));trA2+=A(i,j)*A(j,i);}
 for(int i=0;i<3;++i)for(int j=0;j<3;++j)for(int k=0;k<3;++k)S2[i][j]+=S[i][k]*S[k][j];
 for(int i=0;i<3;++i)for(int j=0;j<3;++j){trS3+=S2[i][j]*S[j][i];Vs+=w[i]*S[i][j]*w[j];}
 py::dict d;d["Q"]=-.5*trA2;d["poisson_source"]=-trA2;d["Rs"]=-trS3/3.;d["Vs"]=Vs;d["fluxfactor"]=-trS3+Vs/4.;return d;
}
PYBIND11_MODULE(_sst_native,m){m.def("tensor",&tensor);m.def("backend_info",[]{py::dict d;d["backend"]="serial";d["precision"]="float64";d["scope"]="tensor_controls_only";return d;});}
