@echo off
call run_python.cmd -m experiment.precheck
exit /b %errorlevel%
