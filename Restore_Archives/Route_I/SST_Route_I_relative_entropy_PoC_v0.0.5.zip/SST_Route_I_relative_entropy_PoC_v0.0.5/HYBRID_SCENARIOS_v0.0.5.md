# Hybrid Scenarios v0.0.5

These scenarios solve the inverse coefficient equation only. They are not
microscopic derivations.

## Capacity-valid B+C scenario using the strongest independent Branch-C candidate

The most aggressive scale constructed without \(G\) or \(L_p\) in the current
harness is

\[
\ell_{2/3}=r_c\left(\frac{\rho_{\!f}}{\rho_{\rm core}}\right)^{2/3}
=4.488264865523e-32\ \mathrm m.
\]

Its one-polarization binary Weyl density still misses the audit target by

\[
R_{\rm residual}=3.541292882396e+06.
\]

Branch B would then need

\[
\ln q_{\rm top}=(\ln2)R_{\rm residual}
=2.454637176970e+06\ \text{nats per sub-core mode}.
\]

Even with the deliberately generous growth model \(q_{\rm top}=10^{6C_r}\),
this corresponds to

\[
C_r=1.776725635054e+05,
\qquad
L_{\rm centreline}\gtrsim2.603244468670e-11\ \mathrm m.
\]

This is much less extreme than the pure core-piercing topology route, but the
\(2/3\) density exponent has not been derived from SST dynamics and the resulting
centreline complexity still does not fit inside a core-scale local channel.

## Equal-log three-way inverse allocation

Assigning one third of \(\ln R\) to each mechanism gives

\[
E_A=E_B=E_C=R^{1/3}
=2.582415258511e+13.
\]

This implies

\[
r_A=15.441166,
\qquad
\ln q_B=1.789993855472e+13,
\qquad
\ell_C=2.772609832096e-22\ \mathrm m.
\]

The correlation share does not pass the fixed-alphabet capacity gate. It becomes
admissible only if the associated collective modes are independently counted in
Branch B or C, in which case it is no longer a separate capacity multiplier.
