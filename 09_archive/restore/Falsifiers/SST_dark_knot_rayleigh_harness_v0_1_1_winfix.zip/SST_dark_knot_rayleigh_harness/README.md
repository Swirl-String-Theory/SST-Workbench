# SST Dark-Knot Rayleigh / Rocking Harness

Research-Track audit package generated from `SST_cpp_pybind_audit_template`.

This folder keeps the template pattern:

- `cpp/` — optional pybind11 kernels for quadrupole and regularized Biot-Savart velocity.
- `sst_dark_knot_harness/` — Python package with C++ loader, fallback, core diagnostics.
- `run_example.py` — single diagnostic run.
- `run_sweep.py` — sweep over `epsilon_BS` and `Omega`.
- `run_all_checks.py` — smoke + sweep battery.
- `examples/` — copy-paste commands.

## Status

This is **Research Track**, not canonical physics. It implements the diagnostic split

\[
\Phi_{\rm R}(r;K)=4\Omega^2+2\Omega A_K+B_K,
\]

with

\[
\Delta_\Omega(K)=\langle\Phi_{\rm R}(+\Omega;K)-\Phi_{\rm R}(-\Omega;K)\rangle
=4\Omega\langle A_K\rangle,
\]

and

\[
\widehat\Sigma_\Omega(K)=
\frac{\langle\Phi_{\rm R}(+\Omega;K)+\Phi_{\rm R}(-\Omega;K)-8\Omega^2\rangle}{8\Omega^2}
=\frac{\langle B_K\rangle}{4\Omega^2}.
\]

Canon-safe interpretation:

\[
4_1 \text{ is tested as first-order chirality-blind, not dynamically inert.}
\]

## Baseline parameters

The default nondimensional ropelength setup uses

\[
\tau=1,\qquad \epsilon_{\rm BS}=1,\qquad h=0.5,\qquad \Delta r=0.25.
\]

Generated default centerlines are scaled to the reference ropelength targets:

- `3_1`: `32.7436`
- `4_1`: `42.0887`

These are used only for the default synthetic input geometry. For final results, supply Ridgerunner-relaxed CSV centerlines.

## Quick start

```bash
cd SST_dark_knot_rayleigh_harness

# Optional C++ build; Python fallback remains usable.
python -m sst_dark_knot_harness.build_ext_if_needed --force

# Diagnostic run for 4_1. Rocking/breathing unavailable unless response vertices are supplied.
python run_example.py --knot 4_1 --n 256 --omega 1.0 --epsilon-bs 1.0 --summary-only

# Smoke-only synthetic response for checking the rocking/breathing output fields.
python run_example.py --knot 4_1 --n 256 --proxy-response-gain 0.02 --summary-only

# Sensitivity sweep.
python run_sweep.py --knots 3_1,4_1 --omegas 0.5,1.0 --epsilons 0.5,1.0,2.0 --out-json sweep.json --out-csv sweep.csv

# Full check battery.
python run_all_checks.py --out-dir audit_out
```

## CSV input format

Base and response vertices use CSV with either a header

```csv
x,y,z
0.0,1.0,0.0
...
```

or three headerless numeric columns.

Use actual solver outputs like this:

```bash
python run_example.py \
  --knot 4_1 \
  --input-csv V0_4_1.csv \
  --vertices-plus Vplus_4_1.csv \
  --vertices-minus Vminus_4_1.csv \
  --omega 1.0 \
  --epsilon-bs 1.0 \
  --out audit_4_1.json
```

## Important limitation

`active_constraint_summary()` currently logs a vertex-vertex strut proxy and MinRad/kink proxy. It does **not** replace the full Ridgerunner `dcsd + MinRad± + NNLS` projection. The package is designed to ingest real Ridgerunner output first; full `Pi_I(V)` evolution should be wired in after the regularization audit is stable.

## Files to edit next

| File | Purpose |
|---|---|
| `sst_dark_knot_harness/core.py` | Main diagnostics and sweep logic. |
| `cpp/native.cpp` | Optional C++ acceleration kernels. |
| `run_example.py` | CLI for one audit. |
| `run_sweep.py` | CLI for regularization sensitivity scans. |
| `PROJECTED_GRADIENT_NOTES.md` | Roadmap for full `Pi_I(V)` integration. |
