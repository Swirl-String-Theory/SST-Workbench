# Patch disposition -- reviewed evidence pack through v0.8.30

## Current direct upgrade

| Patch | Disposition | Reason |
|---|---|---|
| `canon_upgrade_v0_8_28_to_v0_8_30/0001-main-canon-v0.8.28-to-v0.8.30.diff` | **ACCEPTED** | Adds v0.8.29 provenance/dependency guards, v0.8.30 density ontology, and reviewed benchmark wording/layout. |
| `canon_upgrade_v0_8_28_to_v0_8_30/0002-research-track-v0.8.28-to-v0.8.30.diff` | **ACCEPTED** | Adds v0.8.29 SSDL audit, v0.8.30 VAM-7 provenance audit, and reviewed printed `omega_c` values. |
| `canon_upgrade_v0_8_28_to_v0_8_30/SST_CANON-v0.8.28_to_v0.8.30-combined.diff` | **ACCEPTED** | Direct reviewed snapshot upgrade; dry-run and byte-identical roundtrip verified. |

## Predecessor review decisions retained

| Patch | Disposition | Current handling |
|---|---|---|
| `canon_accepted/0001-precision-omega-c-and-rt-clock-table.patch` | **ACCEPTED** | Rebased into the v0.8.30 Research Track snapshot. |
| `canon_accepted/0002-benchmark-exact-closure-guard-layout-safe.patch` | **ACCEPTED** | Rebased into the v0.8.30 main snapshot. |
| `canon_held/HELD-precision-fmax-printed-value.patch` | **HELD** | Not applied; locked canonical value remains unchanged. |
| SSTcore action--phase API | **CODE ACTION REQUIRED** | No speculative repository patch emitted from this evidence-only bundle. |

Historical patch files remain in their original locations for provenance.
