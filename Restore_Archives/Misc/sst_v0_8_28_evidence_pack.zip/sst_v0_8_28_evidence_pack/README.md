# SST Canon v0.8.28 evidence pack

This package upgrades the earlier v0.8.17 evidence bundle to accompany the supplied SST Canon v0.8.28 main and research-track sources.

## Quick run

```bash
cd scripts
python3 sst_v0_8_28_verification_suite.py
```

Machine-readable output:

```bash
python3 sst_v0_8_28_verification_suite.py --json ../results/suite_results_v0_8_28.json
```

The suite contains four layers:

1. inherited numerical regression checks from the v0.8.17 evidence ledger;
2. v0.8.28 frozen canonical-anchor checks;
3. the action--phase mass--shell algebra, fixed-momentum derivative, low-momentum expansion, worldline-phase, and shape-Hessian checks;
4. direct marker/label synchronization against the bundled v0.8.28 LaTeX snapshots.

## Scope guard

Passing the action--phase tests proves only that

\[
H(P,I)=\sqrt{P^2c^2+E_0^2(I)}
\]

implies

\[
\dot\theta=\left.\frac{\partial H}{\partial I}\right|_P
=\frac{\Omega_0}{\gamma}.
\]

It does **not** derive the mass shell, the conserved action \(I\), or universal monometricity from the SST substrate. Those remain explicit theorem targets in v0.8.28.

## Directory layout

- `canon_snapshot/`: supplied v0.8.28 main and research-track sources.
- `scripts/`: upgraded verification suite plus inherited standalone reproducers.
- `results/`: fresh v0.8.28 run outputs.
- `legacy_repo_patches/`: historical SSTcore/Workbench patches retained for provenance; not claimed as rebased.
- `patches/`: suite-upgrade diff and patch-status notes.
- `provenance/`: original v0.8.17 audit/results.
