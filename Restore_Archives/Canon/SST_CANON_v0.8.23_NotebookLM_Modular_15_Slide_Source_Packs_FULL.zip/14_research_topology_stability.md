# Research Track I - topology, stability, and finite-core numerical programme

## Slide 1/15 - Research track authority

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Research track contains candidates and protocols.
- It does not override MAIN Canon.
- Promotion gates are required.

**Single slide message:** Research track contains candidates and protocols.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 2/15 - Migrated sectors overview

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Thermodynamic radiation, QED interfaces, chirality, particle maps, and benchmarks live here when not closed.
- Migration protects main claims while preserving material.

**Single slide message:** Thermodynamic radiation, QED interfaces, chirality, particle maps, and benchmarks live here when not closed.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 3/15 - Non-Abelian topological charge

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Richer topological protection is explored.
- Group action and physical mapping must be defined.
- Not locked Canon.

**Single slide message:** Richer topological protection is explored.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 4/15 - Reconnection decay falsifier

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Unauthorized reconnection falsifies stability.
- Non-ideal events require explicit gates.
- Simulations must distinguish physics from numerical cutting.

**Single slide message:** Unauthorized reconnection falsifies stability.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 5/15 - Fractional torus-phase winding

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Fractional winding may encode phase branches.
- Must respect closure and framing.
- Clock-phase link remains research.

**Single slide message:** Fractional winding may encode phase branches.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 6/15 - Topological fluid mechanics

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Helicity, linking, writhe, and twist are orthodox tools.
- SST uses them as constraints.
- They do not automatically prove mass formulas.

**Single slide message:** Helicity, linking, writhe, and twist are orthodox tools.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 7/15 - Resolved-tube criticality

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Finite-core states need tube-thickness and contact-stress geometry.
- Ideal-knot data guide candidates.
- Physical energy functional remains open.

**Single slide message:** Finite-core states need tube-thickness and contact-stress geometry.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 8/15 - Spherical curl spectrum

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Curl spectra test field reconstruction.
- Spherical domains provide controlled benchmarks.
- Helicity capacity may bound configurations.

**Single slide message:** Curl spectra test field reconstruction.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 9/15 - Writhe and twist guards

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Framed tubes require twist/writhe guardrails.
- Flat-torus benchmarks test limiting cases.
- Over-twisting must be controlled.

**Single slide message:** Framed tubes require twist/writhe guardrails.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 10/15 - Gehring-link benchmarks

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Simple links calibrate ropelength methods.
- Contact measures expose active constraints.
- Benchmark links should precede complex knots.

**Single slide message:** Simple links calibrate ropelength methods.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 11/15 - Biot-Savart realizability

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Centerline geometry must induce admissible velocity fields.
- Far-field and boundary compatibility matter.
- Curve files are not full fields.

**Single slide message:** Centerline geometry must induce admissible velocity fields.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 12/15 - Hodge-complete reconstruction

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Local curl alone is insufficient.
- Hodge completion supplies circulation sectors.
- Supports robust SSTcore diagnostics.

**Single slide message:** Local curl alone is insufficient.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 13/15 - Minimal numerical programme

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Start from certified geometry.
- Run topology, thickness, field, energy, response checks.
- Record resolution/convergence metadata.

**Single slide message:** Start from certified geometry.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 14/15 - Finite-core falsifiers

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Unauthorized reconnection.
- No contact-map convergence.
- Unstable finite core.
- Inconsistent field reconstruction.
- Contradictory topology metadata.

**Single slide message:** Unauthorized reconnection.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.

## Slide 15/15 - Research I closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Topology research turns closed-interference intuition into certified carriers.
- It supplies bound-state geometry for impedance and particle work.

**Single slide message:** Topology research turns closed-interference intuition into certified carriers.

**Source anchors:** Research appendices: topology, stability, fluid mechanics; minimal numerical programme.

**Visual specification:** Certification pipeline with finite-core tube, struts/kinks, and field reconstruction gates.

**Do not generate:** Do not treat research protocols as final physical claims.
