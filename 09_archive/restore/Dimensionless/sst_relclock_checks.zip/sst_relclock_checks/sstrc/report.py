"""Markdown report generator (audit output format)."""
from __future__ import annotations

import csv
import os


def _tbl(rows, cols, fmt=None):
    if not rows:
        return "_(no rows)_\n"
    fmt = fmt or {}
    out = ["| " + " | ".join(cols) + " |",
           "|" + "|".join(["---"] * len(cols)) + "|"]
    for r in rows:
        cells = []
        for c in cols:
            v = r.get(c, "")
            if isinstance(v, float):
                cells.append(fmt.get(c, "{:.6g}").format(v))
            else:
                cells.append(str(v))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out) + "\n"


def write_report(res: dict, outdir: str) -> str:
    m = res.get("meta", {})
    L = []
    A = L.append

    A("# SST relational-clock pre-canonisation report\n")
    A(f"Generated {m.get('generated')} | profile `{m.get('profile')}` | "
      f"python {m.get('python')} | numpy {m.get('numpy')}\n")
    A("**Scope.** This suite tests whether the relational/entropic-time construction of "
      "Barontini (PRR **8**, L022047, 2026) survives translation into SST as a "
      "canonisable object. It does not test SST.\n")
    A("**Declared parameters.** " + ", ".join(
        f"`{k}={v}`" for k, v in m.get("solver_config", {}).items()) + "\n")

    A("\n## Executive verdict\n")
    for n in [1, 2, 3, 4, 5, 6]:
        c = res.get(f"check{n}")
        if not c:
            continue
        if "error" in c:
            A(f"- **check {n}** — FAILED: `{c['error']}`")
        else:
            A(f"- **check {n}** — {c.get('verdict', '(none)')}\n")

    # ---- check 6
    c = res.get("check6")
    if c and "error" not in c:
        A("\n## Check 6 — constant chain / CODATA hygiene\n")
        A(f"Declared release: **{c['codata_release_declared']}**\n")
        A("### Tautology ledger\n")
        A(_tbl(c["tautology_ledger"],
               ["quantity", "claimed_as", "identically_equals", "value",
                "rel_residual", "label"], {"rel_residual": "{:+.3e}"}))
        A("### Canon anchor vs exact chain\n")
        A(_tbl(c["anchor_deviations"],
               ["quantity", "formula", "exact", "canon_anchor",
                "rel_dev_anchor_minus_exact", "first_wrong_significant_digit", "status"],
               {"exact": "{:.10e}", "canon_anchor": "{:.10e}",
                "rel_dev_anchor_minus_exact": "{:+.3e}"}))
        A("### Externally proposed values, re-derived\n")
        A(_tbl(c["proposed_value_audit"],
               ["quantity", "proposed", "recomputed_from_canon_anchors",
                "recomputed_from_exact_chain", "rel_err_proposed_vs_exact",
                "justified_sig_digits"],
               {"proposed": "{:.9g}", "recomputed_from_canon_anchors": "{:.9g}",
                "recomputed_from_exact_chain": "{:.9g}",
                "rel_err_proposed_vs_exact": "{:+.3e}"}))

    # ---- check 2
    c = res.get("check2")
    if c and "error" not in c:
        A("\n## Check 2 — helicity on a material tube (audit point M2)\n")
        A(c["decomposition_note"] + "\n")
        A("### Writhe convergence (Gauss double integral)\n")
        A(_tbl(c["writhe_convergence"], ["N", "writhe", "delta_vs_prev"]))
        A(f"Timestep ladder drift: {c.get('timestep_ladder_drift')} | "
          f"converging: **{c.get('drift_converges_under_refinement')}** | "
          f"best cancellation ratio: **{c.get('best_cancellation_ratio', float('nan')):.1f}**\n")
        A("### Solver-tolerance ladder\n")
        A(_tbl(c["variants"],
               ["variant", "N", "dt", "a", "model", "resample_every", "v_floor",
                "Wr_range", "Tw_range", "Lk_abs_drift_max", "cancellation_ratio",
                "static_integrality_defect", "drift_over_static_defect",
                "E_rel_drift", "L_rel_change", "tau_H_total"],
               {"dt": "{:.3e}", "Lk_abs_drift_max": "{:.3e}",
                "cancellation_ratio": "{:.1f}", "static_integrality_defect": "{:.3e}",
                "drift_over_static_defect": "{:.3f}", "E_rel_drift": "{:.3e}",
                "tau_H_total": "{:.3e}"}))

    # ---- check 3
    c = res.get("check3")
    if c and "error" not in c:
        A("\n## Check 3 — cutoff scan of the enstrophy clock (audit point M3)\n")
        A("### (i) Definitional: fixed trajectory, `a` varied only inside Z\n")
        A(_tbl(c["definitional_scan"],
               ["a_over_a0", "a", "tau_Z_total", "tau_Z_times_a2"],
               {"tau_Z_total": "{:.6e}", "tau_Z_times_a2": "{:.10e}"}))
        A(f"log-log slope = **{c['definitional_loglog_slope']:.6f}** "
          "(exact prediction −2)\n")
        A("### (ii) Dynamical: `a` also changes the trajectory\n")
        A(_tbl(c["dynamical_scan"],
               ["a_over_a0", "a", "tau_Z_total", "tau_L_total", "L_rel_change",
                "kappa_max_final", "Lk_abs_drift"],
               {"tau_Z_total": "{:.6e}", "tau_L_total": "{:.6e}",
                "Lk_abs_drift": "{:.3e}"}))
        A(f"log-log slope = **{c['dynamical_loglog_slope']:.4f}**\n")

    # ---- check 4
    c = res.get("check4")
    if c and "error" not in c:
        A("\n## Check 4 — mode-basis robustness\n")
        A(_tbl(c["rank_correlations"], ["basis_a", "basis_b", "spearman_rho", "p"],
               {"spearman_rho": "{:+.4f}", "p": "{:.3g}"}))
        A("Collapse score per basis: " + ", ".join(
            f"`{k}` = {v:.5g}" if v is not None else f"`{k}` = n/a"
            for k, v in c["collapse_score_per_basis"].items()) + "\n")

    # ---- check 5
    c = res.get("check5")
    if c and "error" not in c:
        A("\n## Check 5 — Loschmidt reversal\n")
        A(_tbl(c["variants"],
               ["variant", "geometric_return_error", "Lk_return_error",
                "L_return_rel_error", "E_return_rel_error",
                "tau_Q_unsigned_at_reversal", "tau_Q_unsigned_final",
                "tau_Q_signed_return_error", "S_spec_hysteresis", "S_spec_range"],
               {k: "{:.3e}" for k in
                ["geometric_return_error", "Lk_return_error", "L_return_rel_error",
                 "E_return_rel_error", "tau_Q_signed_return_error",
                 "S_spec_hysteresis"]}))

    # ---- check 1
    c = res.get("check1")
    if c and "error" not in c:
        A("\n## Check 1 — null-model benchmark (BLOCKING)\n")
        if c.get("underpowered"):
            A(f"> **UNDERPOWERED RUN** — only {c.get('n_heldout_runs')} held-out runs. "
              "p-values below are not reportable.\n")
        A(f"Scored observables (held out from every clock): "
          f"{', '.join(c['scored_observables'])}\n")
        A(f"Prefactor-invariance residual: **{c['prefactor_invariance_residual']:.3e}** "
          "(must be ~0: proves `t_c/Q_c` carries no falsifiable content)\n")
        rows = []
        for name, r in c["clock_scores"].items():
            if not r.get("usable"):
                rows.append({"clock": name, "status": "UNUSABLE — " + r.get("reason", "")})
                continue
            p = c["pvalues_heldout"].get(name, {})
            rows.append({
                "clock": name, "status": "ok",
                "E_heldout": r["E_heldout_mean"],
                "E_calib": r["E_calib_mean"],
                "eff_dof": r["effective_dof"],
                "p_nullA": p.get("p_vs_nullA_shared_warp"),
                "p_nullB_matched": p.get("p_vs_nullB_matched_functional"),
            })
        A(_tbl(rows, ["clock", "status", "E_heldout", "E_calib", "eff_dof",
                      "p_nullA", "p_nullB_matched"],
               {"E_heldout": "{:.5g}", "E_calib": "{:.5g}", "eff_dof": "{:.3g}",
                "p_nullA": "{:.4g}", "p_nullB_matched": "{:.4g}"}))
        A(f"Null-A (shared random monotone warp): median "
          f"{c['null_A_shared_warp']['median']:.5g}, p05 "
          f"{c['null_A_shared_warp']['p05']:.5g}\n")
        A(f"Null-B (matched random functional over the same driver pool): median "
          f"{c['null_B_matched_functional']['median']:.5g}, p05 "
          f"{c['null_B_matched_functional']['p05']:.5g}\n")
        A("\n> **Reading rule.** `p_nullB_matched` is the only number that "
          "licenses a claim. A clock that beats lab time but not null-B has "
          "demonstrated curve registration, not physics.\n")

        with open(os.path.join(outdir, "check1_clock_scores.csv"), "w",
                  newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["clock", "status", "E_heldout", "E_calib",
                                              "eff_dof", "p_nullA", "p_nullB_matched"])
            w.writeheader()
            for r in rows:
                w.writerow(r)

    A("\n## Epistemic labelling of anything exported from this run\n")
    A("- Clock *constructions* (tau_Q, tau_S, tau_F, tau_G): `[SPECULATIVE]` / "
      "`[RESEARCH-TRACK]`.\n"
      "- Helicity freeze on a material tube: `[ORTHODOX]` (Moffatt 1969; "
      "Calugareanu-White-Fuller), and as an SST statement `[DERIVED NEGATIVE]`.\n"
      "- Enstrophy-clock cutoff scaling: `[DERIVED]` from the Rankine-core "
      "definition, with `[CRITICAL NOTE]` on the undeclared-`a` reproducibility gap.\n"
      "- t_c, E_c, Gamma_0, Z_c: `[CALIBRATED ALGEBRAIC IDENTITY]`, never `[DERIVED]`.\n")

    path = os.path.join(outdir, "REPORT.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    return path
