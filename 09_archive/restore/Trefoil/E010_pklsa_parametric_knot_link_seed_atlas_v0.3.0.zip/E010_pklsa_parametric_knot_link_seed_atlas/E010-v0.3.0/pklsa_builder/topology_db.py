from __future__ import annotations
from pathlib import Path
import json, re, zipfile, tempfile, hashlib, gzip
from .hashing import sha256_file

def norm_header(s):
    s=str(s or '').strip().lower()
    s=re.sub(r'[^a-z0-9]+','_',s).strip('_')
    return s

def _labelish(v):
    s=str(v or '').strip()
    return bool(re.match(r'^(?:K)?\d{1,2}(?:[an])?[_ ]?\d+$',s,re.I) or re.match(r'^L\d+[an]\d+$',s,re.I) or re.match(r'^\d+[_ .]\d+$',s))

def canonicalize_knot_label(v):
    s=str(v or '').strip().replace(' ','')
    m=re.match(r'^K(\d+)([an])(\d+)$',s,re.I)
    if m: return f"{int(m.group(1))}{m.group(2).lower()}_{int(m.group(3))}"
    m=re.match(r'^(\d+)([an])[_]?(\d+)$',s,re.I)
    if m: return f"{int(m.group(1))}{m.group(2).lower()}_{int(m.group(3))}"
    m=re.match(r'^(\d+)[._](\d+)$',s)
    if m: return f"{int(m.group(1))}_{int(m.group(2))}"
    return s or None

def _choose_header(sheet,max_rows=20):
    best=None
    for r in range(min(sheet.nrows,max_rows)):
        vals=[str(sheet.cell_value(r,c)).strip() for c in range(sheet.ncols)]
        nz=[x for x in vals if x]
        if not nz: continue
        score=len(set(nz))+3*sum(any(k in norm_header(x) for k in ('knot','link','name','pd','gauss','braid','dt','dowker')) for x in nz)
        if best is None or score>best[0]: best=(score,r,vals)
    if best is None: raise ValueError('no header row')
    return best[1],best[2]

def _open_xls(path):
    try:
        import xlrd
    except Exception as e:
        raise RuntimeError('xlrd>=2.0.1 is required for KnotInfo/LinkInfo legacy .xls integration') from e
    p=Path(path)
    if p.suffix.lower()=='.zip':
        z=zipfile.ZipFile(p); names=[n for n in z.namelist() if n.lower().endswith('.xls') and not n.startswith('__MACOSX/')]
        if len(names)!=1: raise ValueError('expected one .xls in archive')
        data=z.read(names[0]); return xlrd.open_workbook(file_contents=data), names[0]
    return xlrd.open_workbook(str(p),on_demand=True),p.name

def ingest_legacy_database(path, kind='knot'):
    book,member=_open_xls(path)
    source={'path':str(path),'member':member,'sha256':sha256_file(path),'sheet_count':book.nsheets}
    records=[]; aliases={}; profiles=[]
    for sname in book.sheet_names():
        sh=book.sheet_by_name(sname)
        if sh.nrows==0 or sh.ncols==0: continue
        hr,raw_headers=_choose_header(sh); headers=[]; seen={}
        for i,h in enumerate(raw_headers):
            k=norm_header(h) or f'col_{i+1}'
            seen[k]=seen.get(k,0)+1
            if seen[k]>1:k=f'{k}_{seen[k]}'
            headers.append(k)
        profiles.append({'sheet':sname,'nrows':sh.nrows,'ncols':sh.ncols,'header_row_1based':hr+1,'headers':headers})
        for r in range(hr+1,sh.nrows):
            vals=[sh.cell_value(r,c) for c in range(sh.ncols)]
            row={headers[c]:vals[c] for c in range(len(headers)) if vals[c] not in ('',None)}
            if not row: continue
            # Find a primary label only from cells that look like established knot/link labels.
            candidates=[]
            for k,v in row.items():
                if _labelish(v):
                    bonus=3 if any(x in k for x in ('knot','link','name','rolfsen','thistle','ht')) else 0
                    candidates.append((bonus,k,str(v).strip()))
            if not candidates: continue
            candidates.sort(reverse=True); primary_raw=candidates[0][2]
            primary=canonicalize_knot_label(primary_raw) if kind=='knot' else primary_raw
            rec={'kind':kind,'canonical_label':primary,'raw_primary_label':primary_raw,'sheet':sname,'row_1based':r+1,'notations':{},'notation_labels':{},'raw_fields':row}
            for k,v in row.items():
                kl=k.lower()
                if 'pd' in kl and ('notation' in kl or kl=='pd'): rec['notations']['PD']=v
                if any(x in kl for x in ('rolfsen','thistle','knot_atlas','ht_name','knot_name','link_name')) and _labelish(v): rec['notation_labels'][k]=str(v).strip()
                if 'gauss' in kl: rec['notations']['Gauss']=v
                if 'braid' in kl: rec['notations']['Braid']=v
                if 'dowker' in kl or re.search(r'(^|_)dt($|_)',kl): rec['notations']['DT']=v
            als=set([primary_raw,primary])
            for _,_,v in candidates: als.add(v); als.add(canonicalize_knot_label(v) if kind=='knot' else v)
            als={str(x) for x in als if x}
            rec['aliases']=sorted(als)
            records.append(rec)
            for a in als:
                aliases.setdefault(a,set()).add(primary)
    aliases_out={a:sorted(v) for a,v in aliases.items()}
    return {'source':source,'profiles':profiles,'records':records,'aliases':aliases_out}

def write_database_bundle(result,outdir,prefix):
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
    with gzip.open(out/f'{prefix}_records.jsonl.gz','wt',encoding='utf-8') as f:
        for r in result['records']: f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')
    (out/f'{prefix}_aliases.json').write_text(json.dumps(result['aliases'],indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
    (out/f'{prefix}_schema_profile.json').write_text(json.dumps({'source':result['source'],'profiles':result['profiles'],'record_count':len(result['records'])},indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')


def lookup_database_records(bundle_dir, prefix, label):
    """Stream-ingest lookup without loading the full KnotInfo/LinkInfo DB into RAM.

    `label` may be a canonical label or any alias that was observed on the same upstream row.
    No Rolfsen/HT conversion is guessed: aliases are only accepted when the database row itself
    contains the relation.
    """
    out=Path(bundle_dir)
    alias_path=out/f'{prefix}_aliases.json'
    rec_path=out/f'{prefix}_records.jsonl.gz'
    if not alias_path.exists() or not rec_path.exists(): return []
    aliases=json.loads(alias_path.read_text(encoding='utf-8'))
    targets=set(aliases.get(label,[])) | set(aliases.get(str(label).replace('.','_'),[]))
    targets.add(label)
    hits=[]
    with gzip.open(rec_path,'rt',encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            r=json.loads(line)
            if r.get('canonical_label') in targets or label in r.get('aliases',[]): hits.append(r)
    return hits
