# Canon trace

## Orthodox

- incompressible Euler kinematics;
- Cauchy vorticity deformation law;
- Fourier reconstruction of kinetic energy from transverse vorticity;
- isotropic tensor averages;
- affine/Born elastic response terminology.

## Derived in A049 v0.1.0

- blind numerical recovery of the isotropic quadratic coefficient;
- corresponding affine/Born modulus;
- candidate transverse speed **conditional on persistence**;
- Master-Factor Wave Closure Gate under a declared speed mapping.

## Speculative / not promoted

- identification of the affine Born response with a permanent vacuum shear modulus;
- identification of the candidate transverse mode with electromagnetic radiation;
- any post-hoc adjustment of \(u_{\rm rms}/\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}\) to force the Master-Factor gate.
