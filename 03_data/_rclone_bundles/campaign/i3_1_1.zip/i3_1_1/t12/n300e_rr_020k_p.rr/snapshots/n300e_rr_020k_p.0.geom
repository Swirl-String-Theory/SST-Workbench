LIST {
	{ < n300e_rr_020k_p.0.vect }
	{ < n300e_rr_020k_p.0.struts.vect }
	{ < n300e_rr_020k_p.0.dlen.vect }
	{ < n300e_rr_020k_p.0.dVdt.vect }
}
