No precomputed positive physics result is bundled. Run the smoke campaign locally.
