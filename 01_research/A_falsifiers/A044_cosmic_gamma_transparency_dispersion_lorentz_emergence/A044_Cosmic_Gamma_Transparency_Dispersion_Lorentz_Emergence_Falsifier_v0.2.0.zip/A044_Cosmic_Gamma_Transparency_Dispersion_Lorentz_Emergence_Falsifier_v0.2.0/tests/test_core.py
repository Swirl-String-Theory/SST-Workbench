import math, json
from pathlib import Path
from sst_cgtdlef.core import *


def test_poisson_threshold():
    lam=-math.log(0.95)
    assert abs(poisson_at_least_one(lam)-0.05) < 1e-12


def test_li_pair_threshold_300tev():
    x=pair_threshold_eV(300.0)
    assert 8.6e-4 < x < 8.8e-4


def test_n2_timing_scale_gives_hourish_delay():
    dt=tof_delay_s(300.0,10.0,1.59e12,2,0.151,67.4,0.315,0.685)
    assert 3500.0 < dt < 4600.0


def test_n2_threshold_uplift():
    x0=pair_threshold_eV(300.0)
    x=pair_threshold_eV(300.0,2.03e13,2)
    assert x/x0 > 10.0


def test_effective_power_fit():
    Es=[1e4,1e5,3e5]
    n=2; E0=1.59e12
    ds=[0.5*(n+1)*(E/E0)**n for E in Es]
    f=linear_fit_log_power(Es,ds)
    assert abs(f['n_eff']-2.0)<1e-10
    assert f['r2']>0.999999


def test_stable_delta_exact():
    d=group_delay_fraction_exact(300e3,1.59e12,2)
    lead=1.5*(300e3/1.59e12)**2
    assert d>0
    assert abs(d/lead-1.0)<1e-12
