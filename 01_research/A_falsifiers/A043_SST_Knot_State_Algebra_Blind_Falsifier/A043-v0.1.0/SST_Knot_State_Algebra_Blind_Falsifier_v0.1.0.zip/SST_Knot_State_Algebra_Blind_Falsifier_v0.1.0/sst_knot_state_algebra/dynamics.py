from __future__ import annotations
import numpy as np
from sst_falsifier_core.geometry import normalize_components,segments,uniform_resample_closed,min_nonlocal_distance
from sst_falsifier_core.backends import velocity,parity

def _cross_matrix(r):
    x,y,z=r; return np.array([[0,-z,y],[z,0,-x],[-y,x,0]],float)

def relative_equilibrium_score(comps,backend="cpu",core=.03,gamma=1.0):
    comps=normalize_components(comps); targets,mids,dls,tans,offs=segments(comps); v,used=velocity(targets,mids,dls,gamma,core,backend)
    A=[]; b=[]
    for r,t,vi in zip(targets,tans,v):
        P=np.eye(3)-np.outer(t,t); A.append(np.hstack([P,-P@_cross_matrix(r)])); b.append(P@vi)
    A=np.vstack(A); b=np.concatenate(b); x,*_=np.linalg.lstsq(A,b,rcond=None); pred=A@x
    denom=max(float(np.linalg.norm(b)),1e-30); residual=float(np.linalg.norm(b-pred)/denom)
    clearance=min(min_nonlocal_distance(c) for c in comps if len(c)>=8)
    return {"re_residual":residual,"backend":used,"translation":x[:3].tolist(),"omega":x[3:].tolist(),"clearance":float(clearance),"n_points":int(len(targets))}

def resolution_certificate(comps,levels=(128,256,512),core=.03):
    rows=[]
    for n in levels:
        rc=[uniform_resample_closed(c,n) for c in comps]
        rows.append({"N_per_component":n,**relative_equilibrium_score(rc,"cpu",core)})
    vals=[r["re_residual"] for r in rows]
    conv=abs(vals[-1]-vals[-2])/max(abs(vals[-1]),1e-30) if len(vals)>1 else float('inf')
    return {"levels":rows,"last_relative_change":float(conv)}

def gpu_parity(comps,gpu_backend="auto",core=.03):
    comps=normalize_components(comps); targets,mids,dls,tans,offs=segments(comps); return parity(targets,mids,dls,1.0,core,gpu_backend)
