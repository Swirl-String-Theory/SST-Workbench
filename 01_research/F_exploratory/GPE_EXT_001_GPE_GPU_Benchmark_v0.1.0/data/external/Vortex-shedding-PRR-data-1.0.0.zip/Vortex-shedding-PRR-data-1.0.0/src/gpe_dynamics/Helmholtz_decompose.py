"""Helmholtz decomposition helpers used in the flow-field analysis."""

import numpy as np
from numpy.fft import fft2, fftfreq, ifft2

try:
    import cupy as cp
except Exception:  # pragma: no cover - GPU simulations require CuPy.
    cp = None


def H_decompos(Fx, Fy, Nx, Ny, dx, dy):
    """Return irrotational and solenoidal components of a 2D vector field."""
    F_kx = fft2(Fx)
    F_ky = fft2(Fy)

    kx = fftfreq(Nx, d=dx) * 2 * np.pi
    ky = fftfreq(Ny, d=dy) * 2 * np.pi
    kx, ky = np.meshgrid(kx, ky)

    k_norm = np.sqrt(kx**2 + ky**2)
    k_norm[k_norm == 0] = 1
    k_hat_x = kx / k_norm
    k_hat_y = ky / k_norm

    dot = F_kx * k_hat_x + F_ky * k_hat_y
    F_irrotational_x = ifft2(dot * k_hat_x).real
    F_irrotational_y = ifft2(dot * k_hat_y).real

    F_solenoidal_x = Fx - F_irrotational_x
    F_solenoidal_y = Fy - F_irrotational_y

    return [F_irrotational_x, F_irrotational_y], [F_solenoidal_x, F_solenoidal_y]


def H_decompos_cpu(Fx, Fy, Nx, Ny, dx, dy):
    """Backward-compatible alias for the CPU decomposition."""
    return H_decompos(Fx, Fy, Nx, Ny, dx, dy)


def H_decompos_gpu(Fx, Fy, Nx, Ny, dx, dy):
    """CuPy implementation of the same k-space projection."""
    if cp is None:
        raise ImportError("CuPy is required for H_decompos_gpu.")

    F_kx = cp.fft.fft2(Fx)
    F_ky = cp.fft.fft2(Fy)

    kx = cp.fft.fftfreq(Nx, d=dx) * 2 * cp.pi
    ky = cp.fft.fftfreq(Ny, d=dy) * 2 * cp.pi
    kx, ky = cp.meshgrid(kx, ky)

    k_norm = cp.sqrt(kx**2 + ky**2)
    k_norm = cp.where(k_norm == 0, 1, k_norm)
    k_hat_x = kx / k_norm
    k_hat_y = ky / k_norm

    dot = F_kx * k_hat_x + F_ky * k_hat_y
    Fx_irrot = cp.fft.ifft2(dot * k_hat_x).real
    Fy_irrot = cp.fft.ifft2(dot * k_hat_y).real

    Fx_solen = Fx - Fx_irrot
    Fy_solen = Fy - Fy_irrot
    return (Fx_irrot, Fy_irrot), (Fx_solen, Fy_solen)


if __name__ == "__main__":
    print("Import this module and call H_decompos or H_decompos_gpu on simulation fields.")
