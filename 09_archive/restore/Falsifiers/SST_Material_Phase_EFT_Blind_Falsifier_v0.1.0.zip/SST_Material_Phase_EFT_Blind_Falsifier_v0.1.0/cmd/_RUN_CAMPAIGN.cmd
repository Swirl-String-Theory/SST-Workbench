@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
set "CFG=%~1"
set "DATA=%~2"
set "OUT=%~3"
if "%DATA%"=="" set "DATA=..\..\KnotPlot\knots\final"
if "%OUT%"=="" set "OUT=outputs\campaign"
call "cmd\01_BUILD_CPP.cmd"
if errorlevel 1 exit /b 1
if not exist "%DATA%" (
  echo [SST-EFT] ERROR dataset not found: %DATA%
  exit /b 2
)
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"
echo [SST-EFT] PREANALYSIS LOCK
.venv\Scripts\python.exe run_prepare.py --config "%CFG%" --dataset "%DATA%" --out "%OUT%"
if errorlevel 1 exit /b 1
echo [SST-EFT] BLIND ANALYSIS
.venv\Scripts\python.exe run_blind.py --config "%CFG%" --out "%OUT%"
if errorlevel 1 exit /b 1
echo [SST-EFT] REVEAL AFTER LOCK
.venv\Scripts\python.exe run_reveal.py --out "%OUT%"
if errorlevel 1 exit /b 1
echo [SST-EFT] DONE: %OUT%
