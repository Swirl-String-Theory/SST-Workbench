# Historical reference conclusions on bundled `3_1` inputs

These are **reference recomputations**, not hard-coded expected answers. Use the history runners to reproduce them from the immutable archived code.

## v0.1.0 BASIC

Overall: `FAIL`.

Both sources returned the same gate pattern:

```text
G0 PASS
G1 PASS
G2 FAIL
G3 FAIL
G4 PASS
G5 FAIL
G6 PASS
```

Key values:

| Source | normalized growth | cross growth improvement | nearest cross-lobe pair rate | cross Jacobian fraction |
|---|---:|---:|---:|---:|
| Fremlin fseries | 0.8880253693 | -0.4319405312 | +0.1169939025 | 0.9811847000 |
| KnotPlot final | 0.7978293089 | -0.5350206526 | +0.02564257594 | 0.8162246190 |

Interpretation: the nearest cross-lobe pair is locally separating in both representations, but the reduced six-mode dynamics is unstable and removing cross-lobe coupling reduces the worst growth rate rather than increasing it.

## v0.1.1 BASIC

Overall: `FAIL`, numerically identical to the v0.1.0 scientific result on these inputs. v0.1.1 primarily corrected Windows packaging/build behavior.

## v0.2.0 BASIC reference validation

Overall: `FAIL`; the original critical pattern remains:

```text
G0 PASS
G1 PASS
G2 FAIL
G3 FAIL
G4 PASS
G5 FAIL
G6 PASS
```

New diagnostics on the full BASIC settings show:

- `G7` FAIL for both: curvature-matched scrambles do not show a seed stability advantage.
- `G8` FAIL for both at the preregistered coherence threshold: the closest pair separates, but the sign is not sufficiently coherent across all selected close contacts/lobe-centroid pairs.
- `G9` FAIL for both: the cross-lobe contribution to the most unstable eigenmode has **positive** real part, i.e. it is destabilizing for that mode in this reduced model.
- `G10` FAIL for both: the dominant eigenvector has substantial `m=0` participation but the `m=0/E` block leakage is too large for a clean single-sector description.
- `G11` PASS for both: short full-versus-without-cross nonlinear counterfactual evolution orders growth in the same direction as the linear modal attribution.

Selected v0.2.0 BASIC values:

| Source | close-contact separating fraction | lobe-pair separating fraction | dominant cross contribution / spectral scale | C3 block leakage |
|---|---:|---:|---:|---:|
| Fremlin fseries | 0.5833333333 | 0.3333333333 | +0.1703235605 | 0.8596646652 |
| KnotPlot final | 0.5833333333 | 0.6666666667 | +0.3811221354 | 0.7788399834 |

This sharpens the v0.1 conclusion: **local cross-lobe separation exists, but it is not equivalent to global self-confinement.** In the resolved dominant reduced eigenmode, cross-lobe coupling is instead a positive growth contribution for both source geometries.
