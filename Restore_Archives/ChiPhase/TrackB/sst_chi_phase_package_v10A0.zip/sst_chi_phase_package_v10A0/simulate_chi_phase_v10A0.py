#!/usr/bin/env python3
"""
Command-line runner for SST chi-phase package v10A.0.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
import time

from sst_chi_phase_v10A0_py import (
    A0_STAR,
    PHI,
    DEFAULT_PROFILES,
    beta_from_alpha_q,
    chi_speed_ratio_smooth,
    run_track_a,
)


def parse_eps(s: str):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_profiles(s: str):
    names = [x.strip() for x in s.split(",") if x.strip()]
    profiles = []
    for name in names:
        if name not in DEFAULT_PROFILES:
            raise SystemExit(f"Unknown profile {name!r}. Available: {', '.join(DEFAULT_PROFILES)}")
        profiles.append(DEFAULT_PROFILES[name])
    return profiles


def write_energy_csv(path: Path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["profile", "eps", "R", "a", "nr", "ntheta", "ndelta", "energy", "gamma", "alpha_eff"])
        for r in rows:
            w.writerow([
                r.profile, f"{r.eps:.17g}", f"{r.R:.17g}", f"{r.a:.17g}",
                r.nr, r.ntheta, r.ndelta,
                f"{r.energy:.17g}", f"{r.gamma:.17g}", f"{r.alpha_eff:.17g}",
            ])


def write_fit_csv(path: Path, fits):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "profile", "alpha0_fit", "A_eps2log", "B_eps2", "residual_rms",
            "n_points", "expected_alpha", "expected_error",
        ])
        for fit in fits:
            w.writerow([
                fit.profile,
                f"{fit.alpha0:.17g}",
                f"{fit.A:.17g}",
                f"{fit.B:.17g}",
                f"{fit.residual_rms:.17g}",
                fit.n_points,
                "" if fit.expected_alpha is None else f"{fit.expected_alpha:.17g}",
                "" if fit.expected_error is None else f"{fit.expected_error:.17g}",
            ])


def write_beta_csv(path: Path, fits):
    q_values = [0.0, -0.5]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["profile", "alpha0_fit", "q", "beta"])
        for fit in fits:
            for q in q_values:
                w.writerow([fit.profile, f"{fit.alpha0:.17g}", f"{q:.17g}", f"{beta_from_alpha_q(fit.alpha0, q):.17g}"])


def make_plots(outdir: Path, energy_rows, fits):
    try:
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(f"[warn] matplotlib unavailable, skipping plots: {exc}")
        return

    # alpha_eff vs eps
    fig = plt.figure(figsize=(9, 6))
    profiles = sorted(set(r.profile for r in energy_rows))
    for p in profiles:
        rows = sorted([r for r in energy_rows if r.profile == p], key=lambda r: r.eps)
        plt.plot([r.eps for r in rows], [r.alpha_eff for r in rows], marker="o", label=p)
    plt.gca().invert_xaxis()
    plt.xlabel(r"$\epsilon=a/R$")
    plt.ylabel(r"$\alpha_{\rm eff}$")
    plt.title("v10A.0 Track A: Biot-Savart alpha_eff vs slenderness")
    plt.legend(fontsize=8)
    plt.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(outdir / "chi_v10A0_alpha_eff_vs_eps.png", dpi=180)
    plt.close(fig)

    # Intercepts
    fig = plt.figure(figsize=(9, 5))
    names = [f.profile for f in fits]
    vals = [f.alpha0 for f in fits]
    xs = range(len(names))
    plt.bar(xs, vals)
    plt.axhline(1.75, linestyle="--", label=r"$7/4$")
    plt.axhline(1.61, linestyle=":", label=r"NLS note $\alpha=1.61$")
    plt.xticks(list(xs), names, rotation=30, ha="right")
    plt.ylabel(r"$\alpha_0$ fit")
    plt.title("v10A.0 fitted alpha intercepts")
    plt.legend()
    fig.tight_layout()
    fig.savefig(outdir / "chi_v10A0_alpha_intercepts.png", dpi=180)
    plt.close(fig)


def write_summary(path: Path, args, profiles, energy_rows, fits, elapsed):
    lines = []
    lines.append("SST chi-phase package v10A.0 summary")
    lines.append("=" * 52)
    lines.append("")
    lines.append("Track: A — incompressible Euler / Biot-Savart ring-energy solver")
    lines.append("Status: Research Track / CANON-compatible audit prototype")
    lines.append("")
    lines.append("Core extraction:")
    lines.append("  alpha_eff = log(8R/a) - 2E/(rho Gamma^2 R)")
    lines.append("  alpha_eff(eps) = alpha0 + A eps^2 log(1/eps) + B eps^2")
    lines.append("  beta = alpha - 1 + q")
    lines.append("")
    lines.append(f"Runtime seconds: {elapsed:.3f}")
    lines.append(f"nr={args.nr}, ntheta={args.ntheta}, nd_scale={args.nd_scale}, nd_min={args.nd_min}")
    lines.append(f"eps values: {args.eps}")
    lines.append(f"profiles: {', '.join(p.name for p in profiles)}")
    lines.append("")
    lines.append("v6 reference constants:")
    lines.append(f"  a0_star = {A0_STAR:.17g}")
    lines.append(f"  phi     = {PHI:.17g}")
    lines.append(f"  c(phi)/v_ref      = {chi_speed_ratio_smooth(PHI):.17g}")
    lines.append(f"  c(a0_star)/v_ref  = {chi_speed_ratio_smooth(A0_STAR):.17g}")
    lines.append("")
    lines.append("Fitted alpha intercepts:")
    for fit in fits:
        exp = "" if fit.expected_alpha is None else f", expected={fit.expected_alpha:.12g}, err={fit.expected_error:+.6g}"
        lines.append(
            f"  {fit.profile:22s} alpha0={fit.alpha0:.12g}, rms={fit.residual_rms:.3e}{exp}"
        )
    lines.append("")
    lines.append("Beta values from q-lines:")
    for fit in fits:
        lines.append(
            f"  {fit.profile:22s} q=0 beta={beta_from_alpha_q(fit.alpha0,0.0):.12g}; "
            f"q=-1/2 beta={beta_from_alpha_q(fit.alpha0,-0.5):.12g}"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("  - rankine_solid is the benchmark and should approach alpha≈7/4 with higher resolution.")
    lines.append("  - smooth_a0star tests whether the v6 chi-closure root also behaves like a ring-energy selector.")
    lines.append("  - v10A.0 does not include NLSE/GP core-field energy, so alpha_NLS=1.61 is not expected to be proven here.")
    lines.append("  - If smooth_a0star does not land near 1.61, that is evidence that chi-closure and NLS ring-energy selection are distinct constraints.")
    lines.append("")
    lines.append("CANON-safe status:")
    lines.append("  Method: canon-compatible Research Track.")
    lines.append("  Numerical alpha0 values: provisional; grid/extrapolation dependent.")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--eps", default="0.10,0.075,0.055,0.04,0.03")
    parser.add_argument("--profiles", default="rankine_solid,smooth_a0star,smooth_phi,smooth_a0_2,smooth_grad_min")
    parser.add_argument("--nr", type=int, default=8)
    parser.add_argument("--ntheta", type=int, default=24)
    parser.add_argument("--nd-scale", type=float, default=90.0)
    parser.add_argument("--nd-min", type=int, default=900)
    parser.add_argument("--outdir", default="exports")
    parser.add_argument("--no-plots", action="store_true")
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    eps_values = parse_eps(args.eps)
    profiles = parse_profiles(args.profiles)

    t0 = time.time()
    energy_rows, fits = run_track_a(
        profiles,
        eps_values,
        nr=args.nr,
        ntheta=args.ntheta,
        nd_scale=args.nd_scale,
        nd_min=args.nd_min,
    )
    elapsed = time.time() - t0

    write_energy_csv(outdir / "chi_v10A0_alpha_scan.csv", energy_rows)
    write_fit_csv(outdir / "chi_v10A0_alpha_intercepts.csv", fits)
    write_beta_csv(outdir / "chi_v10A0_beta_from_q.csv", fits)
    if not args.no_plots:
        make_plots(outdir, energy_rows, fits)
    write_summary(outdir / "chi_v10A0_run_results_summary.txt", args, profiles, energy_rows, fits, elapsed)

    print((outdir / "chi_v10A0_run_results_summary.txt").read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
