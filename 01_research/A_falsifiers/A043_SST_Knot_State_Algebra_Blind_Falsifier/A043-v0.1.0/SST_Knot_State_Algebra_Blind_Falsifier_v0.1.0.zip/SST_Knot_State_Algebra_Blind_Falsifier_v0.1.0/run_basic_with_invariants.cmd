@echo off
setlocal
if "%~1"=="" (echo Usage: %~nx0 ^<blind_safe_invariants.csv/json^> & exit /b 2)
call .venv\Scripts\activate.bat
python run_pipeline.py --config configs\basic.json --profile basic --invariants "%~1" --out SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs\basic
