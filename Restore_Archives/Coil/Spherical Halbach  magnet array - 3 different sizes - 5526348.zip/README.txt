Spherical Halbach  magnet array - 3 different sizes by OmegaZZ on Thingiverse: https://www.thingiverse.com/thing:5526348

Summary:
This is a spherical (halbach) magnet array that fits 5mm cube magnets.You can arrange the magnets in a halbach array pattern to get the strongest field.You can also arrange the magnets equally so all poles of the magnets face the same directions or in an alternating north-south pattern.Be creative and find an arrangment pattern that fits your needs the most.The holes for the magnets are 5,1mm large, if you want a thighter fit, just scale the print down a bit.