#!/usr/bin/env bash
set -euo pipefail
PYTHON="${PYTHON:-python3}"

"$PYTHON" scripts/sst_ffs_05_helicity_batch.py \
  --ideal-file data/ideal.txt \
  --config data/helicity_knot_config.csv \
  --samples 768 \
  --chunk 256 \
  --outdir results_helicity

echo "Done. Check results_helicity."
