# A064 gate results
- Mode: `EULER_SIMULATION_MODEL`
- Evidence: `geometry_initialized_periodic_3d_euler_model`
- Discovery SHA-256: `7734d49df907a5b0020adfc585871f8d2102d45186a039f69f05a79bee6d1fb2`
- Divergence (p95 dx/U): `0.0060159`
- Candidate identified: `True`
- Feature status: `PERMEABLE_NONMATERIAL_FEATURE`
- True separatrix manifold gate: `UNRESOLVED_NOT_CONSTRUCTED`
- Overall: `CANDIDATE_FALSIFIED_AS_MATERIAL_AT_TESTED_SCALE`
