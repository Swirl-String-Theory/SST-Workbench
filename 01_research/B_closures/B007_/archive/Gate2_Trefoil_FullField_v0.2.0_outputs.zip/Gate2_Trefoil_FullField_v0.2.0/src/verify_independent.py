#!/usr/bin/env python3
"""Frozen full-field trefoil candidate: independent spatial/box/operator holdouts.
No optimizer, no parameter fitting in the pass/fail evaluation: U and Omega
are frozen from the search grid. A separate refit is reported diagnostically.
Two free-space reconstructions: direct vector Biot-Savart and convolution
with Newton potential followed by 4th-order curl, both approximate.
"""
import argparse, hashlib, json, sys, time
from pathlib import Path
import numpy as np
from scipy import fft as sfft
sys.path.insert(0,str(Path(__file__).resolve().parent))
from full_field import SearchGrid, FreeSpaceKernel
from gate2 import curl4, div4

def curl2(a,dx):
    diff=lambda v,j:(np.roll(v,-1,axis=j)-np.roll(v,1,axis=j))/(2*dx)
    return np.stack((diff(a[2],1)-diff(a[1],2),diff(a[0],2)-diff(a[2],0),diff(a[1],0)-diff(a[0],1)))

class ScalarPotentialVelocity:
    def __init__(self,n,dx,workers=1):
        self.n=n;self.nn=2*n;self.dx=dx;self.workers=workers
        r=np.arange(self.nn,dtype=float)
        r=np.where(r<n,r,r-self.nn)*dx
        r2=r[:,None,None]**2+r[None,:,None]**2+r[None,None,:]**2
        G=np.zeros((self.nn,)*3)
        np.sqrt(r2,out=r2)
        np.divide(dx**3/(4*np.pi),r2,out=G,where=r2>0)
        # One independently specified quadrature: diagonal = 0.
        # O(dx^2) error is NOT silently interpreted as a valid continuum Green function.
        self.Ghat=sfft.rfftn(G,workers=workers)
    def velocity(self,w):
        n=self.n;A=[];shape=(2*n,)*3
        for comp in w:
            pad=np.zeros(shape);pad[:n,:n,:n]=comp
            A.append(sfft.irfftn(sfft.rfftn(pad,workers=self.workers)*self.Ghat,s=shape,workers=self.workers))
        vv=curl4(np.stack(A),self.dx)
        return vv[:,:n,:n,:n].copy()

def stationary_residual(w,u,dx,box,U,Omega,curl=curl4):
    n=w.shape[1];x=(np.arange(n)+.5)*dx-box/2
    v=np.zeros_like(w);v[0]=-Omega*x[None,:,None];v[1]=Omega*x[:,None,None];v[2]=U
    return curl(np.cross(u-v,w,axisa=0,axisb=0,axisc=0),dx)

def stats(r,w,dx,l0,box,reference_box=4.4):
    rms=float(np.sqrt(np.mean(np.sum(r*r,axis=0))))
    normalized_rms=rms*(box/reference_box)**1.5
    return {'residual_rms':rms,'residual_rms_fixed_reference_volume':normalized_rms,
            'Rstar':normalized_rms*l0**4,'Rstar_box_rms':rms*l0**4,
            'rms_Dstar':float(np.sqrt(np.mean(div4(w,dx)**2))*l0**3),
            'max_Dstar':float(np.max(np.abs(div4(w,dx)))*l0**3)}

def evaluate(n,box,q,modes,coeff,U,Omega,workers=1):
    start=time.time()
    grid=SearchGrid(n,box,q,modes,workers)
    w=grid.candidate(coeff)
    va=grid.velocity.velocity(w)
    vb=ScalarPotentialVelocity(n,grid.dx,workers).velocity(w)
    ra4=stationary_residual(w,va,grid.dx,box,U,Omega)
    ra2=stationary_residual(w,va,grid.dx,box,U,Omega,curl2)
    rb4=stationary_residual(w,vb,grid.dx,box,U,Omega)
    refit=grid.score_short(coeff)
    support=np.any(np.abs(w)>1e-9,axis=0)
    inds=np.where(support)
    min_margin=min(min(int(np.min(idx)),n-1-int(np.max(idx))) for idx in inds) if len(inds[0]) else -1
    num=float(np.sqrt(np.mean(np.sum((va-vb)**2,axis=0))))
    den=float(np.sqrt(np.mean(np.sum(va**2,axis=0))))
    return {'n':n,'box':box,'dx':grid.dx,'q':q,'core_sampled_boundary_cell_margin':min_margin,
            'direct_BS_curl4':stats(ra4,w,grid.dx,grid.seed.L0,box),
            'direct_BS_curl2':stats(ra2,w,grid.dx,grid.seed.L0,box),
            'scalar_green_curl4':stats(rb4,w,grid.dx,grid.seed.L0,box),
            'reconstruction_relative_velocity_disagreement':num/max(den,1e-30),
            'diagnostic_refit_U':refit['U'],'diagnostic_refit_Omega':refit['Omega'],
            'diagnostic_refit_Rstar':refit['Rstar'],
            'frame_frozen':{'U':U,'Omega':Omega},
            'runtime_seconds':time.time()-start}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--search',required=True)
    ap.add_argument('--grids',type=int,nargs='+',default=[24,32,40,48])
    ap.add_argument('--box',type=float,default=4.4)
    ap.add_argument('--box-control',action='store_true')
    ap.add_argument('--workers',type=int,default=1)
    ap.add_argument('--output',default='')
    args=ap.parse_args()
    source=json.loads(Path(args.search).read_text())
    coeff=np.asarray(source['coefficients'],dtype=float)
    cfg=source['config'];q=cfg['q'];modes=cfg['modes'];final=source['trace'][-1]
    U=final['U'];Omega=final['Omega']
    run=[]
    for n in args.grids:
        print('Frozen holdout',n,'box',args.box,flush=True)
        run.append(evaluate(n,args.box,q,modes,coeff,U,Omega,args.workers))
        print('  Rstar',run[-1]['direct_BS_curl4']['Rstar'],'reconstruction_diff',run[-1]['reconstruction_relative_velocity_disagreement'],flush=True)
    if args.box_control:
        # preserve dx between 32@4.4 and 40@5.5, or scale from first input
        base=32 if 32 in args.grids else args.grids[0]
        extra=max(8,round(1.25*base))
        run.append(evaluate(extra,args.box*extra/base,q,modes,coeff,U,Omega,args.workers))
    # Observe if raw stationary residual appears to move towards a nonzero limit.
    tail=[a['direct_BS_curl4']['Rstar'] for a in run[:len(args.grids)]]
    report={'status':'INDEPENDENT_HOLDOUT_NOT_A_CERTIFIED_ROOT',
        'candidate_search_sha256':hashlib.sha256(Path(args.search).read_bytes()).hexdigest(),
        'candidate_coefficients_frozen':coeff.tolist(),
        'U_Omega_frozen':[U,Omega],
        'source_search_grid':[cfg['n'],cfg['box']],
        'Rstar_integral_normalization':'sqrt(integral |R|^2 / (4.4)^3) * L0^4 / Gamma0^2, common physical reference volume even if box grows',
        'independent_holdouts':run,
        'qualification':{'equilibrium_found':False,
                         'reason':'A finite set of nonzero-resolution residuals does not establish vanishing continuum residual; require model-free convergence to zero and solver agreement.',
                         'residual_Rstar_first_last':tail[0:1]+tail[-1:],
                         'spatial_convergence_demonstrated':False,
                         'box_independence_demonstrated':False,
                         'stability_unassessed':True},
        'limitations':['Primary midpoint singular-cell convention and independent scalar-Green diagonal=0 are approximate free-space quadratures.',
                       '4th-order/2nd-order curls are independent derivative stencils but use the same sampled analytic seed.',
                       'A vanishing discrete divergence after projection is never used as a pass criterion.',
                       'Global smooth volume-preserving shear diffeomorphisms preserve the topology of the continuous transported field; discrete sampling is separately approximate.',
                       'No conclusive proof of nonexistence follows from failure of this finite modal search.']}
    path=Path(args.output) if args.output else Path(args.search).parent/'holdout.json'
    path.write_text(json.dumps(report,indent=2)+'\n')
    print('saved',path,flush=True)
if __name__=='__main__':main()
