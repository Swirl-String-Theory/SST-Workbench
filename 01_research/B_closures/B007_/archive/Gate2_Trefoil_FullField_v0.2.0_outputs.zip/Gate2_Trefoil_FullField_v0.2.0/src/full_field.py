"""Finite-dimensional, exact-isovortical FULL VORTICITY FIELD continuation.

Each step is a composition of global smooth shears: x_i <- x_i + f(x_j,x_k).
The inverse is explicit and determinant of its Jacobian is exactly one.
Vorticity is transformed by the exact contravariant Piola push-forward:
  omega_new(Phi(X)) = D Phi(X) omega_seed(X).
Thus the continuum map preserves line topology, volume, helicity and flux,
without filtering the field or projecting the candidate onto div-free subspace.

WARNING: A finite modal shears family is NOT the entire infinite-dimensional
isovortical orbit, and interpolated Cartesian samplings do NOT exactly preserve
discrete invariants. No equilibria are certified unless independent holdouts pass.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, sys, time
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from scipy.optimize import minimize
from scipy import fft as sfft

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import g1_seed as seed
from gate2 import curl4, div4

MODES=('dipole_u','dipole_v','quadrupole_uv','quadrupole_difference','monopole')
COORD_ORDER=((1,2),(0,2),(0,1))

def shear_profile(u,v,coeff,scale=0.20,sigma=1.1):
    """Return displacement f and df/du,df/dv for smooth exact shears.
    u,v in physical coordinates; coeff length <=5; mode order is frozen.
    """
    a=u/sigma;b=v/sigma
    e=np.exp(-.5*(a*a+b*b))
    polys=(a,b,a*b,.5*(a*a-b*b),np.ones_like(a))
    pa=(np.ones_like(a),np.zeros_like(a),b,a,np.zeros_like(a))
    pb=(np.zeros_like(a),np.ones_like(a),a,-b,np.zeros_like(a))
    p=sum((float(c)*polys[i] for i,c in enumerate(coeff)),np.zeros_like(a))
    dpda=sum((float(c)*pa[i] for i,c in enumerate(coeff)),np.zeros_like(a))
    dpdb=sum((float(c)*pb[i] for i,c in enumerate(coeff)),np.zeros_like(a))
    f=scale*e*p
    fu=scale*e*(dpda-a*p)/sigma
    fv=scale*e*(dpdb-b*p)/sigma
    return f,fu,fv

class ShearOrbit:
    def __init__(self, modes=2, scale=0.20, sigma=1.1):
        assert 1<=modes<=len(MODES)
        self.modes=int(modes);self.scale=scale;self.sigma=sigma
        self.nparameters=3*self.modes

    def coeffs(self,coeff,axis):
        return np.asarray(coeff,dtype=float).reshape(3,self.modes)[axis]

    def forward(self,xyz,coeff):
        x=np.array(xyz,dtype=np.float64,copy=True).reshape(-1,3)
        for axis,(j,k) in enumerate(COORD_ORDER):
            d,_,_=shear_profile(x[:,j],x[:,k],self.coeffs(coeff,axis),self.scale,self.sigma)
            x[:,axis]+=d
        return x.reshape(np.asarray(xyz).shape)

    def inverse_and_gradient(self,xyz,coeff):
        """Exact inverse and the three saved rows of D shear (reverse order)."""
        x=np.array(xyz,dtype=np.float64,copy=True).reshape(-1,3)
        gradients=[None]*3
        for axis in (2,1,0):
            j,k=COORD_ORDER[axis]
            d,du,dv=shear_profile(x[:,j],x[:,k],self.coeffs(coeff,axis),self.scale,self.sigma)
            gradients[axis]=(du,dv)
            x[:,axis]-=d
        return x,gradients

    def pushforward(self,omega,gradients):
        """Apply D Phi to vector field; no interpolation or Hodge projection."""
        w=np.array(omega,dtype=float,copy=True).reshape(-1,3)
        for axis,(j,k) in enumerate(COORD_ORDER):
            du,dv=gradients[axis]
            w[:,axis] += du*w[:,j]+dv*w[:,k]
        return w

    def jacobian(self,xyz,coeff):
        """Full D Phi at input points, useful for determinant unit tests."""
        xx=np.array(xyz,dtype=float,copy=True).reshape(-1,3)
        jac=np.broadcast_to(np.eye(3),(len(xx),3,3)).copy()
        for axis,(j,k) in enumerate(COORD_ORDER):
            _,fu,fv=shear_profile(xx[:,j],xx[:,k],self.coeffs(coeff,axis),self.scale,self.sigma)
            jac[:,axis,:]+=fu[:,None]*jac[:,j,:]+fv[:,None]*jac[:,k,:]
            d,_,_=shear_profile(xx[:,j],xx[:,k],self.coeffs(coeff,axis),self.scale,self.sigma)
            xx[:,axis]+=d
        return jac

class AnalyticSeed:
    def __init__(self,q=0,nsamples=2048):
        self.q=float(q)
        self.L0=seed.curve_length()
        self.samples=2*np.pi*np.arange(nsamples)/nsamples
        self.tree=cKDTree(seed.xder(self.samples)[0]);self.nsamples=nsamples

    def field(self,xyz):
        pts=np.asarray(xyz,dtype=float).reshape(-1,3)
        out=np.zeros_like(pts)
        _,ids=self.tree.query(pts,workers=1)
        pp=self.samples[ids].copy()
        # Initial closest branch seed follows the analytic curved tube;
        # radius test only after exact normal projection to avoid false negatives.
        for _ in range(7):
            X,dX,d2X=seed.xder(pp)
            diff=pts-X
            f=np.einsum('ij,ij->i',diff,dX)
            fp=-np.einsum('ij,ij->i',dX,dX)+np.einsum('ij,ij->i',diff,d2X)
            pp-=np.clip(f/fp,-0.07,0.07)
        X,t,e1,e2,frame,k1,k2,_,_=seed.geom(pp)
        diff=pts-X
        a=np.einsum('ij,ij->i',diff,e1);b=np.einsum('ij,ij->i',diff,e2)
        eta=(a*a+b*b)/(seed.A_CORE**2)
        inside=np.nonzero(eta<seed.ETA_C)[0]
        if not len(inside):return out.reshape(np.asarray(xyz).shape)
        h=1-k1[inside]*a[inside]-k2[inside]*b[inside]
        if np.min(h)<=0:raise ValueError('Tube coordinate folding detected')
        v=seed.GAMMA/(np.pi*seed.A_CORE**2)*seed.fprime(eta[inside])
        out[inside]=v[:,None]*t[inside]+\
            (v*(frame[inside]+2*np.pi*self.q/self.L0)/h)[:,None]*\
            (-b[inside,None]*e1[inside]+a[inside,None]*e2[inside])
        return out.reshape(np.asarray(xyz).shape)

class FreeSpaceKernel:
    """Independent midpoint free-space Biot-Savart (zero diagonal), linear convolution."""
    def __init__(self,n,dx,workers=1):
        self.n=n;self.nn=2*n;self.dx=dx;self.workers=workers
        i=np.arange(self.nn,dtype=float)
        r=np.where(i<n,i,i-self.nn)*dx
        rx=r[:,None,None];ry=r[None,:,None];rz=r[None,None,:]
        r2=rx**2+ry**2+rz**2
        inv=np.zeros((self.nn,)*3)
        np.power(r2,-1.5,out=inv,where=r2>0)
        inv*=dx**3/(4*np.pi)
        self.k=[sfft.rfftn(rv*inv,workers=workers) for rv in (rx,ry,rz)]
    def velocity(self,w):
        n=self.n;shape=(self.nn,)*3
        W=[]
        for component in w:
            temp=np.zeros(shape)
            temp[:n,:n,:n]=component
            W.append(sfft.rfftn(temp,workers=self.workers))
        v=[]
        for axis in range(3):
            j=(axis+1)%3;k=(axis+2)%3
            vhat=W[j]*self.k[k]-W[k]*self.k[j]
            v.append(sfft.irfftn(vhat,s=shape,workers=self.workers)[:n,:n,:n].copy())
        return np.stack(v)

class SearchGrid:
    def __init__(self,n=24,box=4.4,q=0,modes=2,workers=1):
        self.n=int(n);self.box=float(box);self.dx=box/n
        self.seed=AnalyticSeed(q=q);self.orbit=ShearOrbit(modes=modes)
        vals=(np.arange(n)+.5)*self.dx-box/2
        grid=np.meshgrid(vals,vals,vals,indexing='ij')
        self.xyz=np.stack([g.ravel() for g in grid],axis=1)
        self.ez=np.zeros((3,n,n,n));self.ez[2]=1
        self.vr=np.zeros_like(self.ez)
        self.vr[0]=-grid[1];self.vr[1]=grid[0]
        self.velocity=FreeSpaceKernel(n,self.dx,workers)
        self.N=self.xyz.shape[0]

    def candidate(self,coeff):
        pre,grads=self.orbit.inverse_and_gradient(self.xyz,coeff)
        wref=self.seed.field(pre)
        w=self.orbit.pushforward(wref,grads).T.reshape(3,self.n,self.n,self.n)
        return w

    def score(self,coeff,return_field=False):
        coeff=np.asarray(coeff,dtype=float)
        w=self.candidate(coeff)
        u=self.velocity.velocity(w)
        f=curl4(np.cross(u,w,axisa=0,axisb=0,axisc=0),self.dx)
        a=curl4(np.cross(self.ez,w,axisa=0,axisb=0,axisc=0),self.dx)
        b=curl4(np.cross(self.vr,w,axisa=0,axisb=0,axisc=0),self.dx)
        aa=np.dot(a.ravel(),a.ravel());ab=np.dot(a.ravel(),b.ravel());bb=np.dot(b.ravel(),b.ravel())
        af=np.dot(a.ravel(),f.ravel());bf=np.dot(b.ravel(),f.ravel())
        matrix=np.array([[aa,ab],[ab,bb]])
        U,Omega=np.linalg.lstsq(matrix,np.array([af,bf]),rcond=1e-12)[0]
        residual=f-U*a-Omega*b
        rnorm=float(np.sqrt(np.mean(np.sum(residual**2,axis=0))))
        fnorm=float(np.sqrt(np.mean(np.sum(f**2,axis=0))))
        fit={'n':self.n,'box':self.box,'dx':self.dx,'q':self.seed.q,'modes':self.orbit.modes,
             'U':float(U),'Omega':float(Omega),
             'Rstar':float(rnorm*self.seed.L0**4/seed.GAMMA**2),
             'relative_residual':float(rnorm/max(fnorm,1e-20)),
             'residual_rms':rnorm,'uncorrected_rms':fnorm,
             'discrete_divergence_Dstar':float(np.sqrt(np.mean(div4(w,self.dx)**2))*self.seed.L0**3/seed.GAMMA),
             'total_vorticity_integral':float(np.linalg.norm(np.sum(w,axis=(1,2,3))*self.dx**3))}
        if return_field:return fit,residual,w,u
        return fit,residual

    def score_short(self,coeff):return self.score(coeff)[0]


def fd_gauss_newton(grid,iterations=2,reg=1e-2,bound=0.8,fd_step=0.012,initial_coeff=None):
    """Matrix-free with respect to the large Euler residual; small modal J columns.

    Finite-difference directional Jacobian in each vol-preserving shear mode;
    regularized normal equations and monotone trust-region/backtracking.
    Search is constrained to the fixed helicity/isovortical orbit; no q fitting.
    """
    coeff=np.zeros(grid.orbit.nparameters) if initial_coeff is None else np.asarray(initial_coeff,dtype=float).copy()
    if coeff.size!=grid.orbit.nparameters:raise ValueError("Initial modal vector has wrong length")
    if np.any(np.abs(coeff)>bound):raise ValueError("Initial modal coefficients exceed search bound")
    trace=[]
    prior,r=grid.score(coeff)
    trace.append({'iteration':0,'accepted':True,**prior,'coefficient_norm':0.,'coefficients':coeff.tolist()})
    n_eval=1
    for iteration in range(1,iterations+1):
        jf=[]
        for i in range(coeff.size):
            probe=coeff.copy();probe[i]+=fd_step
            _,rp=grid.score(probe);n_eval+=1
            jf.append(((rp-r)/fd_step).ravel())
        J=np.stack(jf,axis=1)
        rv=r.ravel()
        H=J.T@J
        grad=J.T@rv
        # Tikhonov in units of the actual directional Jacobian curvature
        mu=max(reg*np.trace(H)/max(len(coeff),1),1e-22)
        direction=-np.linalg.solve(H+mu*np.eye(len(coeff)),grad)
        # Safe bounded coefficient displacement independent of iteration count.
        limit=np.max(np.abs(direction))
        if limit>0.35:direction*=0.35/limit
        accepted=False
        for alpha in (1.0,.5,.25,.125):
            proposal=np.clip(coeff+alpha*direction,-bound,bound)
            trial,rr=grid.score(proposal);n_eval+=1
            if trial['residual_rms']<prior['residual_rms']*(1-1e-8):
                coeff=proposal;prior=trial;r=rr;accepted=True;break
        trace.append({'iteration':iteration,'accepted':accepted,**prior,
                      'coefficient_norm':float(np.linalg.norm(coeff)), 'coefficients':coeff.tolist(),
                      'step_direction_norm':float(np.linalg.norm(direction)),
                      'line_search_alpha':float(alpha) if accepted else None,
                      'rank_J':int(np.linalg.matrix_rank(H)),
                      'modal_condition':float(np.linalg.cond(H+mu*np.eye(len(coeff))))})
        if not accepted:break
    boundary=bool(np.any(np.abs(coeff)>=bound-1e-6))
    return {'coefficients':coeff.tolist(),'trace':trace,'n_evaluations':n_eval,
            'coefficient_bound':float(bound),'boundary_drift':boundary,
            'search_status':'BOUNDARY_DRIFT_NOT_A_CERTIFIED_ROOT' if boundary else 'CANDIDATE_ONLY_NOT_A_CERTIFIED_EULER_ROOT'}


def numerical_map_checks(orbit,coeff,seedmodel,npoints=128):
    rng=np.random.default_rng(731021)
    points=rng.uniform(-1.2,1.2,(npoints,3))
    final=orbit.forward(points,coeff)
    pre,grad=orbit.inverse_and_gradient(final,coeff)
    J=orbit.jacobian(points,coeff)
    dets=np.linalg.det(J)
    w1=orbit.pushforward(seedmodel.field(points),grad)
    w2=np.einsum('nij,nj->ni',J,seedmodel.field(points))
    return {'inverse_error_max':float(np.max(np.abs(pre-points))),
        'det_jacobian_max_error_from_one':float(np.max(np.abs(dets-1))),
        'piola_forward_consistency_max_error':float(np.max(np.abs(w1-w2))),
        'analytic_volume_preservation':True,
        'analytic_topology_preservation':True,
        'analytic_flux_preservation':True,
        'note':'Numerical Eulerian gridding has independent approximation errors; map checks are not Euler stationarity tests.'}


def main():
    ap=argparse.ArgumentParser(description='Exact-isovortical modal full vorticity continuation; Gate2 research')
    ap.add_argument('--n',type=int,default=24)
    ap.add_argument('--modes',type=int,default=2)
    ap.add_argument('--iterations',type=int,default=2)
    ap.add_argument('--box',type=float,default=4.4)
    ap.add_argument('--q',type=float,default=0.)
    ap.add_argument('--out',default=str(HERE.parent/'Gate2_Trefoil_FullField_v0.2.0-outputs'))
    ap.add_argument('--workers',type=int,default=1)
    ap.add_argument('--start-from',default='',help='Previous search.json; prolong modes without changing q')
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    start=time.time()
    grid=SearchGrid(args.n,args.box,args.q,args.modes,args.workers)
    initial=None
    if args.start_from:
        prior=json.loads(Path(args.start_from).read_text())
        pcfg=prior["config"]
        if pcfg["q"]!=args.q:raise ValueError("Isovortical q leaf cannot change in a continuation")
        pm=int(pcfg["modes"])
        if pm>args.modes:raise ValueError("Continuation may only increase or retain basis resolution")
        initial=np.zeros((3,args.modes))
        initial[:,:pm]=np.asarray(prior["coefficients"]).reshape(3,pm)
        initial=initial.ravel()
    result=fd_gauss_newton(grid,iterations=args.iterations,initial_coeff=initial)
    checks=numerical_map_checks(grid.orbit,np.array(result['coefficients']),grid.seed)
    result.update({'config':vars(args),'map_checks':checks,'elapsed_seconds':time.time()-start,
        'restart_parent_sha256':hashlib.sha256(Path(args.start_from).read_bytes()).hexdigest() if args.start_from else None,
        'base_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE/'g1_seed.py',HERE/'gate2.py',HERE/'full_field.py']}})
    (out/'search.json').write_text(json.dumps(result,indent=2)+'\n')
    print('baseline',result['trace'][0]['relative_residual'], 'final', result['trace'][-1]['relative_residual'],
          'step_status',result['trace'][-1]['accepted'],'elapsed',result['elapsed_seconds'],flush=True)

if __name__=='__main__':main()
