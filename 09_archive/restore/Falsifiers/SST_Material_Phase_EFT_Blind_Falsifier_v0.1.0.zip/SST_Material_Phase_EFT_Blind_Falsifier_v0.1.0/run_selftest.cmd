@echo off
setlocal
cd /d "%~dp0"
call "cmd\02_SELFTEST.cmd"
