#!/usr/bin/env python3
"""Reproduce the finalized Fig. 2.

All inputs are final plotted coordinates from data/panel_a ... data/panel_j.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib import ticker
import numpy as np
import pandas as pd
from PIL import Image

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PACKAGE_ROOT / "data"
RESULTS_DIR = PACKAGE_ROOT / "results"

FIG_W = 7.165
FIG_H = 6.6

COLORS = {
    "b_line": "#2196F3",
    "QU": "#9E9E9E",
    "c_line": "#FF5722",
    "decay_data": "darkorange",
}
PANEL_A_COLORS = {
    "A": "#9C27B0",
    "B": "#2196F3",
    "C": "#FF5722",
    "D": "#795548",
    "E": "#607D8B",
    "QU": "#9E9E9E",
}
PANEL_A_LABELS = {"A": "a", "B": "b", "C": "c", "D": "d", "E": "e", "QU": "QU"}
PANEL_A_LABEL_SCALE = {"A": 1.15, "B": 1.0, "C": 1.05, "D": 1.08, "E": 2.5, "QU": 1.03}
PANEL_IJ_CONFIG = {
    "i": {
        "xlim": (-0.5, 10.5),
        "ylim": (0.0, 2.5e-3),
        "xticks": [0, 5, 10],
        "yticks": [0, 1e-3, 2e-3],
    },
    "j": {
        "xlim": (-0.25, 5.25),
        "ylim": (0.0, 5e-3),
        "xticks": [0, 2.5, 5],
        "yticks": [0, 2e-3, 4e-3],
    },
}
PHOTO_CONFIG = {
    "g": {
        "filename": "crystal.png",
        "crop": (0.20, 0.20, 0.10, 0.10),
        "long_edge_px": 430.0,
        "long_edge_mm": 9.6,
        "scale_bar_mm": 5.0,
    },
    "h": {
        "filename": "crystal.png",
        "crop": (0.21, 0.21, 0.12, 0.12),
        "long_edge_px": 200.0,
        "long_edge_mm": 4.94,
        "scale_bar_mm": 5.0,
    },
}


def configure_style() -> None:
    plt.rcParams.update(
        {
            # Use DejaVu Sans consistently for ordinary and mathematical text.
            "font.family": "DejaVu Sans",
            "mathtext.fontset": "dejavusans",
            # Embed editable TrueType fonts in PDF/EPS instead of Type 3 glyphs.
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            # Preserve text nodes if an SVG export is added later.
            "svg.fonttype": "none",
            "text.usetex": False,
            "font.size": 7,
            "axes.labelsize": 7,
            "axes.titlesize": 7,
            "legend.fontsize": 7,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "figure.dpi": 150,
            "savefig.dpi": 600,
            "savefig.bbox": "tight",
            "axes.linewidth": 0.5,
            "xtick.major.width": 0.5,
            "ytick.major.width": 0.5,
            "xtick.direction": "in",
            "ytick.direction": "in",
            "lines.markersize": 2.5,
            "lines.solid_capstyle": "projecting",
            "lines.solid_joinstyle": "round",
            "path.simplify": False,
        }
    )


def draw_panel_a(figure, grid) -> None:
    axis = figure.add_subplot(grid[0, :3])
    for line in ("A", "B", "C", "D", "E", "QU"):
        points = pd.read_csv(DATA_DIR / "panel_a" / f"{line}_points.csv")
        color = PANEL_A_COLORS[line]
        axis.errorbar(
            points["vuv_frequency_thz"],
            points["normalized_signal"],
            yerr=points["error_bar"],
            fmt="o",
            ms=3,
            capsize=1.5,
            color=color,
            ecolor=color,
            elinewidth=0.4,
            zorder=4,
            mew=0,
        )
        fit_path = DATA_DIR / "panel_a" / f"{line}_fit.csv"
        if fit_path.exists():
            fit = pd.read_csv(fit_path)
            axis.plot(fit["vuv_frequency_thz"], fit["normalized_fit"], color=color, linewidth=0.8, zorder=3)
            peak_index = int(np.argmax(fit["normalized_fit"].to_numpy(float)))
            label_x = float(fit["vuv_frequency_thz"].iloc[peak_index])
            label_y = float(fit["normalized_fit"].iloc[peak_index]) * PANEL_A_LABEL_SCALE[line]
        else:
            peak_index = int(np.argmax(points["normalized_signal"].to_numpy(float)))
            label_x = float(points["vuv_frequency_thz"].iloc[peak_index])
            label_y = float(
                points["normalized_signal"].iloc[peak_index]
                + points["error_bar"].iloc[peak_index]
            ) * 1.12
        axis.text(
            label_x,
            label_y,
            PANEL_A_LABELS[line],
            fontsize=7,
            color=color,
            ha="center",
            va="bottom",
            fontweight="bold",
        )

    axis.set_xlim(2020.40726, 2020.40774)
    axis.set_ylim(0, 1.25)
    axis.set_yticks([0, 0.5, 1.0])
    axis.set_ylabel("arb. units", fontsize=7, labelpad=2)
    axis.yaxis.set_label_coords(-0.08, 0.5)
    axis.xaxis.set_ticks_position("top")
    axis.xaxis.set_label_position("top")
    axis.set_xlabel("VUV frequency (THz)", fontsize=7, labelpad=3)
    axis.xaxis.set_major_locator(ticker.MaxNLocator(5))
    axis.xaxis.set_major_formatter(ticker.FormatStrFormatter("%.6f"))
    axis.xaxis.set_minor_locator(ticker.AutoMinorLocator(5))
    axis.tick_params(axis="x", which="major", pad=2, length=3)
    axis.tick_params(axis="x", which="minor", pad=2, length=1.5)
    axis.text(-0.1, 1.2, "a", transform=axis.transAxes, fontsize=10, fontweight="bold", va="bottom")


def draw_spectral_panels(figure, grid):
    column_limits = [(-150, 150), (-2500, 2500), (-150, 150)]
    column_names = ("b_line", "QU", "c_line")
    column_labels = ("b", "QU", "c")
    rows = ((1, "b", "panel_b", True), (2, "c", "panel_c", False), (3, "d", "panel_d", False), (4, "e", "panel_e", False))
    axes = {}

    for row_index, letter, panel_folder, fluorescence in rows:
        for column_index, dataset_name in enumerate(column_names):
            axis = figure.add_subplot(grid[row_index, column_index])
            axes[(row_index, column_index)] = axis
            data = pd.read_csv(DATA_DIR / panel_folder / f"{dataset_name}.csv")
            color = COLORS[dataset_name]
            axis.errorbar(
                data["frequency_offset_khz"],
                data["normalized_signal"],
                yerr=data["error_bar"],
                fmt="o",
                ms=2,
                capsize=0,
                color=color,
                ecolor=color,
                elinewidth=0.5,
                zorder=3,
                mfc="none",
                mec=color,
                mew=0.5,
            )
            axis.axhline(y=0, color="gray", linewidth=0.3, linestyle="--", zorder=1)
            axis.set_xlim(*column_limits[column_index])
            axis.set_ylim(0.0, 1.1) if fluorescence else axis.set_ylim(-1.3, 1.3)
            if row_index == 4:
                axis.set_xlabel("Freq. offset (kHz)", fontsize=7, labelpad=1)
            if column_index == 0:
                axis.set_ylabel("arb. units", fontsize=7, labelpad=2)
                axis.yaxis.set_label_coords(-0.25, 0.5)
            else:
                axis.tick_params(labelleft=False)
            if row_index != 4:
                axis.tick_params(labelbottom=False)
            axis.ticklabel_format(style="plain", axis="y", useOffset=False)
            axis.yaxis.set_major_locator(ticker.MaxNLocator(4, prune="both"))

        axes[(row_index, 0)].text(
            -0.32,
            1.05,
            letter,
            transform=axes[(row_index, 0)].transAxes,
            fontsize=10,
            fontweight="bold",
            va="bottom",
        )

    for column_index in range(3):
        axes[(1, column_index)].set_yticks([0, 0.5, 1.0])
    for row_index in (2, 3, 4):
        for column_index in range(3):
            axes[(row_index, column_index)].set_yticks([-1, 0, 1])

    for column_index, (dataset_name, label) in enumerate(zip(column_names, column_labels)):
        bounds = axes[(1, column_index)].get_position()
        figure.text(
            bounds.x0 + bounds.width / 2,
            bounds.y1 + 0.015,
            label,
            ha="center",
            va="bottom",
            fontsize=7,
            fontweight="bold",
            color=COLORS[dataset_name],
        )
    return axes


def add_photo_frame(axis) -> None:
    for spine in axis.spines.values():
        spine.set_visible(True)
        spine.set_color("black")
        spine.set_linewidth(0.8)


def load_and_crop_photo(path: Path, crop: tuple[float, float, float, float]) -> np.ndarray:
    """Load and crop a scale-free crystal photo using the archived settings."""
    crop_top, crop_bottom, crop_left, crop_right = crop
    with Image.open(path) as source:
        image = source.copy()
    if image.mode == "RGBA":
        alpha = np.asarray(image.getchannel("A"))
        nonzero = np.where(alpha > 10)
        if nonzero[0].size and nonzero[1].size:
            top, bottom = int(nonzero[0].min()), int(nonzero[0].max())
            left, right = int(nonzero[1].min()), int(nonzero[1].max())
            image = image.crop((left, top, right, bottom))

    width, height = image.size
    if min(width, height) < 500:
        scale = 500.0 / min(width, height)
        image = image.resize(
            (int(width * scale), int(height * scale)),
            Image.Resampling.LANCZOS,
        )

    width, height = image.size
    box = (
        int(width * crop_left),
        int(height * crop_top),
        int(width * (1.0 - crop_right)),
        int(height * (1.0 - crop_bottom)),
    )
    return np.asarray(image.crop(box))


def add_scale_bar(
    axis,
    image_width_px: int,
    long_edge_px: float,
    long_edge_mm: float,
    scale_bar_mm: float,
) -> None:
    """Draw an editable vector scale bar and TrueType text label."""
    x0, y0, tick_height = 0.05, 0.15, 0.05
    width = (scale_bar_mm * long_edge_px / long_edge_mm) / image_width_px
    x = [x0, x0, x0 + width, x0 + width]
    y = [y0 + tick_height, y0, y0, y0 + tick_height]
    axis.plot(
        x,
        y,
        color="black",
        linewidth=1.2,
        transform=axis.transAxes,
        solid_capstyle="butt",
        solid_joinstyle="miter",
        zorder=3,
    )
    axis.text(
        x0 + width / 2,
        y0 + tick_height + 0.15,
        f"{scale_bar_mm:g} mm",
        transform=axis.transAxes,
        ha="center",
        va="top",
        color="black",
        fontsize=8,
        zorder=4,
    )


def draw_photo_panels(figure, grid) -> None:
    photo_grid = grid[1:3, 4].subgridspec(2, 1, hspace=0.15)
    for row, panel in enumerate(("g", "h")):
        axis = figure.add_subplot(photo_grid[row, 0])
        config = PHOTO_CONFIG[panel]
        image = load_and_crop_photo(
            DATA_DIR / f"panel_{panel}" / config["filename"],
            config["crop"],
        )
        axis.imshow(image, interpolation="lanczos")
        axis.set_xticks([])
        axis.set_yticks([])
        add_photo_frame(axis)
        axis.text(-0.18, 1.05, panel, transform=axis.transAxes, fontsize=10, fontweight="bold", va="bottom")
        add_scale_bar(
            axis,
            image_width_px=image.shape[1],
            long_edge_px=config["long_edge_px"],
            long_edge_mm=config["long_edge_mm"],
            scale_bar_mm=config["scale_bar_mm"],
        )


def draw_panel_f(figure, grid) -> None:
    data = pd.read_csv(DATA_DIR / "panel_f" / "decay.csv")
    parameters = pd.read_csv(DATA_DIR / "panel_f" / "fit_parameters.csv").set_index("parameter")["value"]
    tau = float(parameters["tau_s"])
    tau_error = float(parameters["tau_standard_error_s"])
    label = rf"$\tau_e$ = {tau:.0f}({tau_error:.0f}) s"

    axis = figure.add_subplot(grid[0, 4])
    axis.errorbar(
        data["time_s"],
        data["count_rate_cps"],
        yerr=data["error_bar_cps"],
        fmt="o",
        ms=1.2,
        capsize=0.8,
        color=COLORS["QU"],
        alpha=0.5,
        ecolor=COLORS["QU"],
        elinewidth=0.3,
        zorder=2,
        mew=0,
    )
    axis.plot(data["time_s"], data["fit_count_rate_cps"], color="black", linewidth=1.0, alpha=0.8, zorder=3, label=label)
    axis.legend(fontsize=7, loc="upper right", framealpha=0.8, borderpad=0.3, labelspacing=0.2, handlelength=1)
    axis.set_xlabel("Time (s)", fontsize=7, labelpad=1)
    axis.set_ylabel("Count rate (cps)", fontsize=7, labelpad=2)
    axis.yaxis.set_label_position("left")
    axis.yaxis.set_label_coords(-0.2, 0.5)
    axis.set_ylim(0, 800)
    axis.set_yticks([0, 400, 800])
    axis.tick_params(width=0.5)
    axis.text(-0.18, 1.06, "f", transform=axis.transAxes, fontsize=10, fontweight="bold", va="bottom")


def draw_population_panel(axis, panel: str) -> None:
    """Draw panel i or j directly from its final plotted CSV columns."""
    data = pd.read_csv(DATA_DIR / f"panel_{panel}" / f"panel_{panel}.csv")
    axis.plot(data["depth_mm"], data["b_line"], color=COLORS["b_line"], linewidth=0.8)
    axis.plot(data["depth_mm"], data["c_line"], color=COLORS["c_line"], linewidth=0.8)
    axis.plot(data["depth_mm"], data["QU"], color=COLORS["QU"], linewidth=0.8)

    config = PANEL_IJ_CONFIG[panel]
    axis.set_xlabel(r"Depth $z$ (mm)", fontsize=7, labelpad=1)
    axis.set_ylabel(r"$p_s(z)$", fontsize=7, labelpad=2)
    axis.yaxis.set_label_position("left")
    axis.yaxis.set_label_coords(-0.15, 0.5)
    axis.set_xlim(*config["xlim"])
    axis.set_ylim(*config["ylim"])
    axis.xaxis.set_major_locator(ticker.FixedLocator(config["xticks"]))
    axis.yaxis.set_major_locator(ticker.FixedLocator(config["yticks"]))
    axis.ticklabel_format(axis="y", style="sci", scilimits=(0, 0), useMathText=True)
    axis.tick_params(labelsize=7, direction="in", width=0.5, pad=2)
    axis.yaxis.get_offset_text().set_fontsize(7)
    axis.text(-0.16, 1.05, panel, transform=axis.transAxes, fontsize=10, fontweight="bold", va="bottom")


def main() -> None:
    configure_style()
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    figure = plt.figure(figsize=(FIG_W, FIG_H))
    outer = figure.add_gridspec(1, 1, left=0.07, right=0.98, top=0.97, bottom=0.04)
    grid = outer[0, 0].subgridspec(
        5,
        5,
        height_ratios=[0.6, 0.6, 1, 1, 1],
        width_ratios=[1, 1, 1, 0.15, 1],
        hspace=0.35,
        wspace=0.10,
    )

    draw_panel_a(figure, grid)
    draw_spectral_panels(figure, grid)
    draw_panel_f(figure, grid)
    draw_photo_panels(figure, grid)
    draw_population_panel(figure.add_subplot(grid[3, 4]), "i")
    draw_population_panel(figure.add_subplot(grid[4, 4]), "j")

    for extension in ("png", "pdf"):
        figure.savefig(
            RESULTS_DIR / f"Fig2.{extension}",
            dpi=600,
            bbox_inches="tight",
        )
    plt.close(figure)
    print("[OK] Saved Fig2.png and Fig2.pdf")


if __name__ == "__main__":
    main()
