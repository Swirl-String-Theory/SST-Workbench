from __future__ import annotations
from pathlib import Path
import csv, json, re, sys
import numpy as np
from sst_falsifier_core.geometry import as_components
from sst_falsifier_core.source_registry import resolve_sources
from sst_falsifier_core.util import sha256_file

TOPO_RE = re.compile(r"(?<!\d)(\d{1,2})[_\.]([0-9]{1,3})(?!\d)")


def canonical_topology(s):
    m = TOPO_RE.search(str(s))
    return f"{int(m.group(1))}_{int(m.group(2))}" if m else None


def _find_one(root: Path, name: str):
    direct = root / name
    if direct.exists():
        return direct
    hits = sorted(root.rglob(name)) if root.exists() else []
    return hits[0] if hits else None


def _source_map(root: Path):
    p = _find_one(root, "SOURCE_MAP.json")
    if not p:
        return {}, None
    raw = json.loads(p.read_text(encoding="utf-8"))
    rows = raw if isinstance(raw, list) else raw.get("families", raw.get("sources", []))
    out = {}
    if isinstance(rows, list):
        for r in rows:
            if isinstance(r, dict) and r.get("family"):
                out[str(r["family"])] = r
    return out, p


def _candidate_rows(root: Path):
    p = _find_one(root, "CANDIDATES_FULL.csv")
    if not p:
        raise FileNotFoundError("PKLSA CANDIDATES_FULL.csv not found")
    with p.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    needed = {"candidate_id", "family", "canonical_id", "family_index", "variant_index", "component_count", "points_per_component"}
    if not rows or not needed.issubset(rows[0]):
        raise ValueError(f"PKLSA candidate index missing required columns: {sorted(needed)}")
    return rows, p


def _split_flat(points, component_count, points_per_component=None, offsets=None):
    a = np.asarray(points, dtype=float)
    if a.ndim != 2 or a.shape[1] != 3:
        raise ValueError("flattened geometry must be Nx3")
    if offsets is not None:
        o = np.asarray(offsets, dtype=int).ravel()
        if len(o) == component_count + 1 and o[0] == 0 and o[-1] == len(a):
            return [a[int(lo):int(hi)].copy() for lo, hi in zip(o[:-1], o[1:])]
    c = int(component_count)
    if c <= 1:
        return [a.copy()]
    n = int(points_per_component or 0)
    if n > 0 and len(a) == c * n:
        return [a[i*n:(i+1)*n].copy() for i in range(c)]
    if len(a) % c == 0:
        n = len(a) // c
        return [a[i*n:(i+1)*n].copy() for i in range(c)]
    raise ValueError(f"cannot split {len(a)} points into {c} components")


def _variant_components(path, variant_index, component_count, points_per_component, expected_variants=48):
    """Extract one PKLSA variant without assuming one fixed NPZ key layout.

    Accepted representations include:
      - [V,N,3] single-component coordinates;
      - [V,C,N,3] multi-component coordinates;
      - [V,C*N,3] flattened multi-component coordinates;
      - one array per component, each [V,N,3];
      - x/y/z arrays with leading variant axis.

    A family bundle that cannot expose the requested variant is rejected rather than
    silently treated as one candidate.
    """
    z = np.load(path, allow_pickle=False)
    vi = int(variant_index); cc = int(component_count); npp = int(points_per_component)

    offsets = None
    for key in ("component_offsets", "offsets"):
        if key in z.files:
            o = np.asarray(z[key])
            if o.ndim == 2 and o.shape[0] > vi:
                offsets = o[vi]
            elif o.ndim == 1:
                offsets = o
            break

    # Prefer semantically named coordinate arrays.
    named = []
    for key in ("coordinates", "coords", "points", "xyz", "geometry", "geometries", "x"):
        if key in z.files:
            named.append((key, np.asarray(z[key])))
    seen = {k for k, _ in named}
    named += [(k, np.asarray(z[k])) for k in z.files if k not in seen]

    # x/y/z scalar-coordinate representation.
    if all(k in z.files for k in ("x", "y", "z")):
        X, Y, Z = (np.asarray(z[k]) for k in ("x", "y", "z"))
        if X.shape == Y.shape == Z.shape and X.ndim >= 2 and X.shape[0] >= expected_variants:
            a = np.stack((X[vi], Y[vi], Z[vi]), axis=-1)
            if a.ndim == 2:
                return _split_flat(a, cc, npp, offsets)
            if a.ndim == 3 and a.shape[0] == cc:
                return [np.asarray(a[i], float).copy() for i in range(cc)]

    # One component array per key, e.g. component_0[V,N,3].
    component_arrays = []
    for k in z.files:
        kl = k.lower()
        a = np.asarray(z[k])
        if ("component" in kl or re.fullmatch(r"c\d+", kl)) and a.ndim == 3 and a.shape[0] >= expected_variants and a.shape[-1] == 3:
            component_arrays.append((k, a))
    if len(component_arrays) >= cc > 1:
        component_arrays.sort(key=lambda kv: kv[0])
        return [np.asarray(a[vi], float).copy() for _, a in component_arrays[:cc]]

    for key, a in named:
        if not (np.issubdtype(a.dtype, np.number) and a.shape and a.shape[-1] == 3):
            continue
        # V,C,N,3
        if a.ndim == 4 and a.shape[0] >= expected_variants:
            q = np.asarray(a[vi], float)
            if q.ndim == 3 and q.shape[0] == cc:
                return [q[i].copy() for i in range(cc)]
        # V,N,3 or V,C*N,3
        if a.ndim == 3 and a.shape[0] >= expected_variants:
            return _split_flat(np.asarray(a[vi], float), cc, npp, offsets)
        # C,V,N,3 (less common)
        if a.ndim == 4 and a.shape[0] == cc and a.shape[1] >= expected_variants:
            return [np.asarray(a[i, vi], float).copy() for i in range(cc)]

    raise ValueError(f"PKLSA family bundle {path} does not expose variant {vi} in a supported 48-variant layout; keys={z.files}")


def _resolve_bundle(root: Path, family: str, family_index: int, source_entry, source_map_path):
    if source_entry and source_entry.get("bundle"):
        rel = Path(str(source_entry["bundle"]))
        candidates = [root / rel]
        if source_map_path:
            candidates += [source_map_path.parent / rel, source_map_path.parent.parent / rel]
        for p in candidates:
            if p.exists():
                return p
    famdir = _find_one(root, "families")
    if famdir and famdir.is_dir():
        prefix = f"{int(family_index):02d}_"
        hits = sorted(famdir.glob(prefix + "*.npz"))
        if len(hits) == 1:
            return hits[0]
    raise FileNotFoundError(f"PKLSA bundle not found for family={family!r} index={family_index}")


def discover_pklsa(root):
    root = Path(root)
    rows_idx, index_path = _candidate_rows(root)
    smap, smap_path = _source_map(root)
    expected_per_family = 48
    by_family = {}
    for r in rows_idx:
        by_family.setdefault(r["family"], []).append(r)

    rows = []
    family_errors = []
    for family, members in sorted(by_family.items(), key=lambda kv: int(kv[1][0]["family_index"])):
        members.sort(key=lambda r: int(r["variant_index"]))
        if len(members) != expected_per_family or [int(r["variant_index"]) for r in members] != list(range(expected_per_family)):
            family_errors.append({"family": family, "reason": "candidate_index_not_0_to_47", "count": len(members)})
            continue
        first = members[0]
        try:
            bundle = _resolve_bundle(root, family, int(first["family_index"]), smap.get(family), smap_path)
            bundle_sha = sha256_file(bundle)
            for r in members:
                comps = _variant_components(
                    bundle,
                    int(r["variant_index"]),
                    int(r["component_count"]),
                    int(r["points_per_component"]),
                    expected_variants=expected_per_family,
                )
                if len(comps) != int(r["component_count"]):
                    raise ValueError("component_count mismatch")
                if any(len(c) != int(r["points_per_component"]) for c in comps):
                    raise ValueError("points_per_component mismatch")
                if not all(np.isfinite(c).all() for c in comps):
                    raise ValueError("non-finite coordinate")
                rows.append({
                    "source_family": "pklsa",
                    "source_path": str(bundle),
                    "source_sha256": bundle_sha,
                    "topology": str(r["canonical_id"]),
                    "family": family,
                    "family_index": int(r["family_index"]),
                    "variant_index": int(r["variant_index"]),
                    "candidate_source_id": str(r["candidate_id"]),
                    "variant": f"v{int(r['variant_index']):02d}",
                    "component_count": int(r["component_count"]),
                    "points_per_component": int(r["points_per_component"]),
                    "construction_method": r.get("construction_method"),
                    "components": comps,
                })
        except Exception as e:
            family_errors.append({"family": family, "reason": repr(e)})

    return rows, {
        "candidate_index": str(index_path),
        "source_map": str(smap_path) if smap_path else None,
        "indexed_candidates": len(rows_idx),
        "indexed_families": len(by_family),
        "loaded_candidates": len(rows),
        "loaded_families": len({r["family"] for r in rows}),
        "family_errors": family_errors,
    }


def discover_xyz_like(root, source_family, max_files=10000):
    root = Path(root); rows = []
    if not root.exists():
        return rows
    exts = {".xyz", ".csv", ".txt", ".vect", ".fseries"}; count = 0
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in exts:
            continue
        topo = canonical_topology(p.as_posix())
        if topo is None:
            continue
        comps = None
        try:
            if p.suffix.lower() in {".xyz", ".txt", ".csv"}:
                a = np.loadtxt(p, delimiter="," if p.suffix.lower() == ".csv" else None)
                if a.ndim == 2 and a.shape[1] >= 3:
                    comps = [a[:, :3].astype(float)]
        except Exception:
            pass
        rows.append({
            "source_family": source_family,
            "source_path": str(p),
            "source_sha256": sha256_file(p),
            "topology": topo,
            "family": None,
            "variant": p.name,
            "components": comps,
        })
        count += 1
        if count >= max_files:
            break
    return rows


def load_cross_source_manifest(path):
    """Load an explicit blind-safe cross-source inventory.

    Required fields per row: source_family, topology, source_path.
    Optional: source_sha256, variant. Geometry is still parsed independently.
    """
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    if p.suffix.lower() == ".csv":
        with p.open("r", encoding="utf-8-sig", newline="") as f:
            raw = list(csv.DictReader(f))
    elif p.suffix.lower() == ".jsonl":
        raw = [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]
    else:
        obj = json.loads(p.read_text(encoding="utf-8"))
        raw = obj if isinstance(obj, list) else obj.get("records", obj.get("rows", []))
    out = []
    for r in raw:
        if not all(r.get(k) for k in ("source_family", "topology", "source_path")):
            continue
        q = Path(r["source_path"])
        out.append({
            "source_family": str(r["source_family"]),
            "source_path": str(q),
            "source_sha256": str(r.get("source_sha256") or (sha256_file(q) if q.exists() and q.is_file() else "")),
            "topology": str(r["topology"]),
            "family": r.get("family"),
            "variant": str(r.get("variant", q.name)),
            "components": None,
        })
    return out


def activate_a002(path):
    p = Path(path)
    if not p.exists():
        return False
    # Accept either package root or parent version root.
    candidates = [p, p / "src"]
    for c in candidates:
        if c.exists() and str(c) not in sys.path:
            sys.path.insert(0, str(c))
    try:
        import sst_knotlib  # noqa: F401
        return True
    except Exception:
        return False


def a002_load(path):
    import sst_knotlib
    if hasattr(sst_knotlib, "load_geometry"):
        obj = sst_knotlib.load_geometry(str(path))
        if hasattr(obj, "components"):
            return [np.asarray(x, float) for x in obj.components]
        if hasattr(obj, "points"):
            return [np.asarray(obj.points, float)]
        return as_components(obj)
    raise RuntimeError("A002 sst_knotlib.load_geometry unavailable")


def source_inventory(overrides=None):
    return resolve_sources(overrides)
