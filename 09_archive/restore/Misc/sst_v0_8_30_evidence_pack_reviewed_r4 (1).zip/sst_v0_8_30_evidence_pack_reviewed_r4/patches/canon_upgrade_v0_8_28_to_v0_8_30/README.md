# Direct reviewed Canon patch: v0.8.28 -> v0.8.30

This patch is rebased against the exact `canon_snapshot/` sources from the
reviewed v0.8.28 evidence pack, including its published DOI value.

The generated v0.8.30 output contains:

- v0.8.29 density provenance and SSDL/epoch audit;
- v0.8.30 density ontology and historical VAM-7 provenance correction;
- the two accepted v0.8.28 evidence-review hotfixes;
- a layout-only breakable benchmark archive path.

Apply from this directory:

```bash
./apply_canon_upgrade.sh ../../provenance/canon_snapshot_v0_8_28
```

The script creates a local `patched/` directory and leaves the baseline sources
unchanged.
