# SST ideal-trefoil Biot-Savart closure package v1

This is a flat, `sst_chi_phase_package_v6`-style experiment package for the ideal-trefoil Biot-Savart / energetic closure scan.

It is intentionally **not** a full installable `src/` package. It is a single-folder experiment with:

- `simulate_trefoil_biot_closure.py` — main runner and plots.
- `sst_trefoil_biot_py.py` — pure-Python backend: `ideal.txt` parser, Fourier trefoil sampler, SST energy scan.
- `sst_trefoil_biot.cpp` — optional pybind11 C++ backend for Biot-Savart kernels.
- `sst_trefoil_biot_build.py` — Windows-safe local build helper.
- `ideal.txt` — embedded local ideal-knot table; default knot `Id="3:1:1"`.
- `exports/` — generated CSVs, plots, XYZ, and summary.
- `vendor/pybind11/include` — bundled pybind11 headers for self-contained local compilation.

## Model

The runner samples the ideal trefoil from `ideal.txt` using the Fourier representation

\[
\mathbf{r}(t)=\sum_i \mathbf{A}_i\cos(i t)+\mathbf{B}_i\sin(i t),
\qquad t\in[0,2\pi).
\]

The C++/Python backends evaluate a regularized filament Biot-Savart / Neumann energy

\[
E_{\rm BS}^{\rm dimless}(a)
=\frac{1}{8\pi}\sum_{i\ne j}
\frac{(\hat{\mathbf{t}}_i\cdot\hat{\mathbf{t}}_j)\,\Delta s_i\Delta s_j}
{\sqrt{|\mathbf{m}_i-\mathbf{m}_j|^2+a^2}}.
\]

Physical scaling uses the SST constants

\[
\Gamma_0=2\pi r_c\mathbf{v}_{\!\boldsymbol{\circlearrowleft}},
\qquad
L_0=\frac{\Gamma_0}{\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}}=2\pi r_c.
\]

The scanned closure energy is

\[
E_{\rm total}(a)
=\rho_{\!f}\Gamma_0^2 L_0 E_{\rm BS}^{\rm dimless}(a/L_0)
+\frac{\pi}{2}\rho_{\!f}\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}^2 a^2 L_{\rm phys}
+\lambda_p\rho_{\!f}\Gamma_0^2L_{\rm phys}\left(\frac{a}{r_c}-1\right)^2.
\]

The report also writes

\[
\chi_{\rm eff}=\frac{a_\star\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}}{\Gamma_0},
\qquad
\chi_{\rm req}=\frac{1}{2\pi}.
\]

## Run

From the package folder:

```powershell
python -m pip install -r requirements.txt
python simulate_trefoil_biot_closure.py
```

Default uses `--pressure-penalty-lambda 10`, giving an interior closure near `a/r_c = 1`. Use `--pressure-penalty-lambda 0` for the bare Biot-Savart + core-radius scan.

Force pure Python:

```powershell
python simulate_trefoil_biot_closure.py --python
```

Force C++ rebuild:

```powershell
python sst_trefoil_biot_build.py --force
```

One-shot Windows helper:

```powershell
.\run_all.ps1 --n 384 --samples 60
```

One-shot Linux/macOS helper:

```bash
./run_all.sh --n 384 --samples 60
```

## Outputs

The runner writes:

- `exports/trefoil_biot_summary.json`
- `exports/trefoil_biot_run_results_summary.txt`
- `exports/trefoil_biot_energy_scan.csv`
- `exports/trefoil_biot_energy_scan.png`
- `exports/trefoil_geometry.png`
- `exports/3_1_1_points.xyz`

## Status

This is **Research Track** numerical infrastructure. It reproduces a local ideal-trefoil geometry from `ideal.txt`, computes a pybind11-accelerated Biot-Savart closure scan, and exports diagnostics. It is not a derivation that SST/Euler/NLSE dynamically selects the reported radius.
