# README hoofdstuk — `fs_unified_attachment_audit.py`

Dit hoofdstuk beschrijft hoe je `fs_unified_attachment_audit.py` gebruikt met de drie bronfamilies in jouw setup: `ideal.txt`, de Fremlin `Knots_FourierSeries/`, en jouw eigen KnotPlot-relax/export map `knotplot/`.

```text
./
├─ fs_unified_attachment_audit.py
├─ ideal.txt
├─ Knots_FourierSeries/
│  ├─ 3_1/
│  ├─ 5_1/
│  ├─ 5_2/
│  ├─ 7_1/
│  ├─ ...
│  └─ STL/
└─ knotplot/
   ├─ knot_3.1/
   ├─ knot_5.2/
   ├─ knot_6.3.3/
   ├─ knot_TL2.4/
   ├─ knot_TL3.3_Gear/
   └─ ...
```

Plaats het script dus **naast `ideal.txt`**, in dezelfde rootmap als `Knots_FourierSeries/` en `knotplot/`.

Het script schrijft standaard alle exports naar een map met dezelfde naam als `--out-prefix`. Bijvoorbeeld:

```bat
python fs_unified_attachment_audit.py --out-prefix unified_attachment_audit_full
```

maakt:

```text
./unified_attachment_audit_full/
```

met daarin alle CSV’s, summary en runlog.

---


# Correctie bronmodel — provenance van de drie inputbronnen

De audit gebruikt drie verschillende bronfamilies. Deze moeten niet alleen technisch als `txt`/`fseries`/`ideal` worden gezien, maar vooral naar **herkomst** en **betrouwbaarheidsrol**.

```text
SOURCE A — ideal.txt
  Herkomst: ideal-knot coordinate database / ideal polygon data.
  Rol: referentie- en vergelijkingbron voor canonical/ideal embeddings.
  Loader: --ideal-txt ./ideal.txt
  Gebruik: single-knot torus/twist diagnostics.

SOURCE B — Knots_FourierSeries/
  Herkomst: David Fremlin Fourier-series knot collection.
  Rol: externe FourierSeries bron voor standaard knopen.
  Loader: --fseries-root ./Knots_FourierSeries
  Gebruik: single-knot torus/twist/general diagnostics.

SOURCE C — knotplot/
  Herkomst: jouw eigen KnotPlot-relax/export set.
  Rol: zelf-geselecteerde, gerelaxte knopen en links; daarna geëxporteerd en/of via lokale scripts omgezet naar .fseries.
  Loader 1: --fseries-root ./knotplot
  Loader 2: --link-root ./knotplot
  Gebruik:
    - .fseries: diagnostic single-curve/framed-tube runs;
    - component-gescheiden .txt: multicomponent link-invarianten.
```

Belangrijk: `knotplot/` is dus **niet alleen een linkfolder**. Het is jouw eigen experimentele/gerelaxte bronset. Het script kan dezelfde map daarom op twee manieren tegelijk gebruiken:

```text
--fseries-root ./knotplot
  leest jouw uit KnotPlot geëxporteerde/geconverteerde .fseries als single-curve diagnostics.

--link-root ./knotplot
  leest component-gescheiden .txt-bestanden als echte multicomponent links.
```

Voor multicomponent links blijft de waarschuwing gelden: gebruik de component-gescheiden `.txt` voor linking matrices. Een `.fseries` van een link kan door conversie/stitching als één curve verschijnen en is dan alleen diagnostisch, niet canoniek voor link-invarianten.

---

## Aanbevolen run voor jouw echte setup

Vanuit de root waar `ideal.txt`, `Knots_FourierSeries/` en `knotplot/` staan:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --fseries-root ./Knots_FourierSeries ^
  --fseries-root ./knotplot ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --include-controls ^
  --core-models canon ^
  --out-prefix unified_attachment_audit
```

Dit doet vier dingen tegelijk:

```text
1. ideal.txt
   -> ideal torus/twist/single-knot coordinate diagnostics.

2. Knots_FourierSeries/
   -> Fremlin .fseries single-knot diagnostics.

3. knotplot/ as fseries-root
   -> jouw eigen gerelaxte/geëxporteerde .fseries single-curve diagnostics.

4. knotplot/ as link-root
   -> jouw eigen component-gescheiden .txt links voor Lk_ij matrices en link-helicity bookkeeping.
```

Exports komen in:

```text
./unified_attachment_audit/
```

---

## Snelle veilige Canon-kernrun

Deze run houdt de modelkant smal (`C0–C2`) en neemt alleen bekende torus/twist-control patronen mee uit de `.fseries` roots:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --fseries-root ./Knots_FourierSeries ^
  --fseries-root ./knotplot ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --include-controls ^
  --core-models canon ^
  --out-prefix unified_canon_core
```

Gebruik deze voor rapportage/Canon-kandidaten.

---

## Full diagnostic inventory-run

Deze run neemt veel meer mee, inclusief alle `.fseries` en alle `ideal.txt` entries. Gebruik deze om te ontdekken wat er in de bronsets zit, niet om alles direct te canoniseren:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --include-all-ideal ^
  --fseries-root ./Knots_FourierSeries ^
  --fseries-root ./knotplot ^
  --include-all-fseries ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --include-controls ^
  --core-models full ^
  --out-prefix unified_full_inventory
```

Let op bij `--include-all-fseries`: geconverteerde `.fseries` van multicomponent links kunnen als stitched single curves verschijnen. Die rijen moeten als `DIAGNOSTIC_*` worden gelezen, niet als link-helicity bewijs.

---

## Provenance-label interpretatie

Aanbevolen interpretatie van resultaten:

```text
ideal.txt rows
  Referentie/ideal embedding diagnostics.
  Sterk als geometrische controle, maar framing blijft expliciet labelen.

Knots_FourierSeries rows
  Externe standaardbron.
  Goed voor reproduceerbare torus/twist comparisons.

knotplot .fseries rows
  Jouw eigen relaxed/exported source.
  Zeer nuttig als experimental geometry/relaxation diagnostic.
  Niet automatisch canoniek als torus-surface framing niet target-free bevestigd is.

knotplot .txt multicomponent rows
  Beste bron voor link matrices van jouw eigen links.
  Gebruik voor Hopf/Solomon/Borromean/TL/Gear style link bookkeeping.
```

---

## Praktische broncontrole

Alleen Fremlin FourierSeries:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --include-controls ^
  --core-models canon ^
  --out-prefix audit_fremlin_fseries
```

Alleen jouw KnotPlot `.fseries` diagnostics:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./knotplot ^
  --include-controls ^
  --include-all-fseries ^
  --core-models full ^
  --out-prefix audit_knotplot_fseries
```

Alleen jouw KnotPlot multicomponent links:

```bat
python fs_unified_attachment_audit.py ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --core-models canon ^
  --out-prefix audit_knotplot_links
```

Alleen `ideal.txt`:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --include-controls ^
  --core-models canon ^
  --out-prefix audit_ideal
```

## 1. Wat het script test

Het script is één unified audit harness voor de compensated swirl-clock / entanglement attachment:

```text
chi_total = chi_local + chi_attachment
Canon-safe: chi_total = chi, charge_leak = 0, FR odd parity active
```

Het onderscheidt streng tussen:

```text
integer_selection_chi = YES
```

en:

```text
exact_holonomy_chi = YES
```

Dat is belangrijk: een model kan nog steeds integer `n_core = 1` selecteren terwijl de holonomie niet exact canoniek is.

De hoofdformules per klasse zijn:

```text
Torus knots:
  SL_phys(T(p,q)) = pq + chi

Twist/general single knots:
  SL_phys(K) = SL_geom_proxy(K) + chi
  Geen pq-regel.

Multicomponent links:
  H/Gamma^2 = sum_i(SL_i + chi_i) + 2 sum_{i<j} Lk_ij + higher

Gear/STL analogs:
  test of een mechanische phase-lock één collectieve fase oplevert.
```

---

## 2. Dependencies

Minimaal:

```bat
pip install numpy
```

Voor STL gear-analyse:

```bat
pip install trimesh
```

`trimesh` is alleen nodig als je `--gear-stl` gebruikt.

---

## 3. Oude compacte run / minimale variant

Deze minimale variant gebruikt `knotplot/` alleen als link-root. Voor jouw echte setup is de aanbevolen provenance-run hierboven beter, omdat die `knotplot/` ook als `.fseries` bron scant. Vanuit de rootmap waar `ideal.txt` staat:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --ideal-txt ./ideal.txt ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --include-controls ^
  --core-models canon ^
  --out-prefix unified_attachment_audit
```

Dit gebruikt:

```text
./Knots_FourierSeries/**/*.fseries
./ideal.txt
./knotplot/knot_*/<coordinate>.txt
```

en schrijft naar:

```text
./unified_attachment_audit/
```

Let op: `knotplot/` bevat zowel echte links als single knots. Single-component `.txt` folders worden nu als:

```text
[link][SKIP single-component]
```

geskipt. Dat is normaal; single knots worden via `Knots_FourierSeries` en/of `ideal.txt` behandeld.

---

## 4. Snelle test-run

Gebruik caps om eerst te controleren of alles werkt:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --ideal-txt ./ideal.txt ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --include-controls ^
  --max-fseries 10 ^
  --max-ideal 5 ^
  --core-models canon ^
  --out-prefix smoke_unified_attachment
```

Deze run schrijft naar:

```text
./smoke_unified_attachment/
```

---

## 5. Full diagnostic run

Gebruik `--core-models full` als je ook de failure/diagnostic modes wilt zien:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --ideal-txt ./ideal.txt ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --include-controls ^
  --include-all-fseries ^
  --include-all-ideal ^
  --core-models full ^
  --out-prefix unified_attachment_audit_full
```

`full` gebruikt C0–C8:

```text
C0 baseline exact attachment
C1 compensated neutral matter
C2 compensated neutral antimatter
C3 uncompensated local only
C4 partial compensation
C5 charge leak
C6 decohered residual
C7 q-dependent compensated
C8 passive transit
```

Voor Canon-kernruns is `--core-models canon` meestal beter; voor falsificatie/diagnostiek is `full` nuttig.

---

## 6. Alleen torus/twist single knots uit `Knots_FourierSeries`

Default neemt het script alleen de bekende torus/twist-control patronen mee. Dat is handig voor snelle runs:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --include-controls ^
  --out-prefix fseries_core_audit
```

Alles uit `Knots_FourierSeries` meenemen:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --include-all-fseries ^
  --include-controls ^
  --out-prefix fseries_all_audit
```

Met cap:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --include-all-fseries ^
  --max-fseries 50 ^
  --include-controls ^
  --out-prefix fseries_50_audit
```

---

## 7. Alleen `ideal.txt`

Default-IDs:

```text
3:1:1,5:1:1,7:1:1,9:1:1,K11a367,5:1:2,K11a247
```

Run:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --include-controls ^
  --out-prefix ideal_default_audit
```

Specifieke ideal IDs:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --ideal-ids 3:1:1,5:1:1,7:1:1,9:1:1,K11a367,K11a247 ^
  --include-controls ^
  --out-prefix ideal_selected_audit
```

Alles uit `ideal.txt`:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --include-all-ideal ^
  --include-controls ^
  --out-prefix ideal_all_audit
```

Met cap:

```bat
python fs_unified_attachment_audit.py ^
  --ideal-txt ./ideal.txt ^
  --include-all-ideal ^
  --max-ideal 100 ^
  --include-controls ^
  --out-prefix ideal_100_audit
```

---

## 8. Alleen multicomponent links uit `knotplot`

Alle `knot_*` folders scannen:

```bat
python fs_unified_attachment_audit.py ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --out-prefix knotplot_links_audit
```

Alleen TL-links scannen:

```bat
python fs_unified_attachment_audit.py ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_TL*" ^
  --link-recursive ^
  --out-prefix knotplot_TL_links_audit
```

Eén specifieke folder:

```bat
python fs_unified_attachment_audit.py ^
  --link-file ./knotplot/knot_TL3.3_Gear ^
  --out-prefix tl33_gear_only
```

Eén specifieke tekstfile:

```bat
python fs_unified_attachment_audit.py ^
  --link-file ./knotplot/knot_6.3.3/knot_6.3.3.txt ^
  --out-prefix knot_6_3_3_only
```

Belangrijk: voor links gebruikt het script de component-gescheiden `.txt`, niet de `.fseries`, omdat `.fseries` multicomponent links soms tot één curve kan stitchen.

---

## 9. Zip-link input

Als je een link als zip hebt:

```bat
python fs_unified_attachment_audit.py ^
  --link-file knot_TL3.3_Gear.zip ^
  --out-prefix tl33_zip_audit
```

Als de zip meerdere `.txt` bestanden bevat en je expliciet één member wilt kiezen:

```bat
python fs_unified_attachment_audit.py ^
  --link-file knot_TL3.3_Gear.zip ^
  --link-member knot_TL3.3_Gear.txt ^
  --out-prefix tl33_zip_member_audit
```

---

## 10. Gear/STL module

Als je de 3D-print STL’s naast het script zet:

```text
./triple_gear_solid_with_mark.stl
./30cm_axle.stl
```

run:

```bat
python fs_unified_attachment_audit.py ^
  --gear-stl ./triple_gear_solid_with_mark.stl ^
  --axle-stl ./30cm_axle.stl ^
  --helix-ratio 1.0 ^
  --out-prefix gear_locked_audit
```

Met een linkmatrix erbij, bijvoorbeeld TL3.3 Gear:

```bat
python fs_unified_attachment_audit.py ^
  --link-file ./knotplot/knot_TL3.3_Gear ^
  --gear-stl ./triple_gear_solid_with_mark.stl ^
  --axle-stl ./30cm_axle.stl ^
  --helix-ratio 1.0 ^
  --out-prefix gear_plus_tl33_audit
```

Als je al een matrix CSV hebt:

```bat
python fs_unified_attachment_audit.py ^
  --gear-stl ./triple_gear_solid_with_mark.stl ^
  --axle-stl ./30cm_axle.stl ^
  --gear-linking-matrix-csv ./tl33_gear_link_audit_linking_matrix.csv ^
  --helix-ratio 1.0 ^
  --out-prefix gear_locked_with_matrix
```

---

## 11. Accuracy/speed knobs

Voor single-knot diagnostics:

```text
--single-samples N       standaard sampling voor .fseries/ideal curves
--single-chunk N         chunk size voor Gauss integrals
--single-pq-tol X        tolerantie voor torus-source-fit check
--ribbon-eps-frac X      offset-fractie voor diagnostic framed-linking
```

Voor links:

```text
--link-sub N             segment subdivision voor Gauss linking
```

Voor modelscan:

```text
--eps-list 0,0.01,0.1,1.0
--sigma 1.0
--n-range -5:5
--exact-tol 1e-9
--charge-tol 1e-12
--energy-tol 1e-12
```

Voor q-dependent diagnostics:

```text
--q-ref 3
--q-slope 0.01
```

Voor failure-mode diagnostics:

```text
--passive-center 2.501
--partial-fraction 0.5
--charge-leak-fraction 0.01
--decoherence-residual 0.02
```

---

## 12. Complete argument reference

### Output

```text
--out-prefix NAME        exports naar ./NAME/ tenzij --out-dir gezet is
--out-dir PATH           override exportfolder
```

### Existing v2 result input

```text
--input-results FILE     core_holonomy_v2_results.csv of compatible CSV
--include-controls       neem twist/control rows mee uit input-results
--canonical-only         houd alleen PASS_DERIVED_PQ torus rows uit input-results
--include-noncanonical   neem noncanonical fitted torus diagnostics mee
```

### Fallback analytic torus

```text
--q-list 3,5,7,9,11
--p 2
--extra-torus 3:2,3:4
```

### Fourier series

```text
--fseries-root PATH      repeatable; bv ./Knots_FourierSeries
--include-all-fseries    niet alleen bekende torus/twist patterns
--max-fseries N          0 = geen cap
```

### ideal.txt

```text
--ideal-txt PATH         repeatable; bv ./ideal.txt
--ideal-ids LIST         comma list of IDs, of ALL
--include-all-ideal      alle single-component AB blocks
--max-ideal N            0 = geen cap
```

### Single-curve numerics

```text
--single-samples N
--single-chunk N
--single-pq-tol X
--ribbon-eps-frac X
```

### Multicomponent links

```text
--link-file PATH         .txt/.zip/folder; repeatable
--link-root PATH         scan root; repeatable
--link-folder-glob GLOB  default knot_*
--link-file-glob GLOB    default *.txt
--link-recursive
--link-member NAME       zip member override
--link-sub N
```

### Gear/STL

```text
--gear-stl FILE
--axle-stl FILE
--gear-linking-matrix-csv FILE
--helix-ratio X
```

### Attachment models

```text
--core-models canon      C0-C2 only
--core-models full       C0-C8 diagnostics
--eps-list LIST
--sigma X
--n-range A:B
--q-ref X
--q-slope X
--passive-center X
--partial-fraction X
--charge-leak-fraction X
--decoherence-residual X
--exact-tol X
--charge-tol X
--energy-tol X
```

### SST constants

```text
--v-swirl 1.09384563e6
--r-c 1.40897017e-15
```

---

## 13. Outputbestanden

Voor `--out-prefix unified_attachment_audit` krijg je:

```text
unified_attachment_audit/
├─ unified_attachment_audit_summary.md
├─ unified_attachment_audit_runlog.txt
├─ unified_attachment_audit_objects.csv
├─ unified_attachment_audit_models.csv
├─ unified_attachment_audit_single_attachment_results.csv
├─ unified_attachment_audit_link_components.csv
├─ unified_attachment_audit_linking_matrices.csv
├─ unified_attachment_audit_link_attachment_results.csv
├─ unified_attachment_audit_gear_mesh_summary.csv
├─ unified_attachment_audit_gear_components.csv
├─ unified_attachment_audit_gear_distance_matrix.csv
├─ unified_attachment_audit_gear_lock_scenarios.csv
└─ unified_attachment_audit_gear_helicity_bookkeeping.csv
```

De belangrijkste CSV’s zijn:

```text
*_objects.csv
  single torus/twist/general object inventory

*_single_attachment_results.csv
  per single object: chi_local, chi_attachment, chi_total, selected_n_core, exact_holonomy_chi

*_linking_matrices.csv
  pairwise Gauss Lk_ij per parsed link

*_link_attachment_results.csv
  per multicomponent link: self attachment + pairwise helicity bookkeeping

*_gear_lock_scenarios.csv
  sign-cycle / collective-phase diagnostics voor gear-STL analogs
```

---

## 14. Interpretatie van labels

Sterk / Canon-candidate:

```text
BASELINE_EXACT_ATTACHMENT
CANON_CANDIDATE_EXACT_COMPENSATED
LINK_CANON_CANDIDATE_EXACT_COMPENSATED
FULLY_LOCKED_ATTACHMENT_ANALOG
```

Diagnostisch / niet-canoniek:

```text
DIAGNOSTIC_TWIST_PROXY
DIAGNOSTIC_NONCANONICAL_TORUS_FIT
SELECTION_STABLE_BUT_HOLONOMY_NOT_EXACT
PARTIAL_SELECTION_STABLE_NOT_EXACT
DECOHERED_SELECTION_STABLE_NOT_EXACT
```

Afwijzen of sterk begrenzen:

```text
PASSIVE_TRANSIT_REJECTED
CHARGE_LEAK_REJECT_OR_CONSTRAIN
FRUSTRATED_OR_OVERCONSTRAINED_NO_COLLECTIVE_ROTATION
```

---

## 15. Belangrijke waarschuwingen

1. Dit script is een audit-harness, geen bewijs-machine.

2. Voor torusknopen is `pq + chi` alleen canoniek als de torus-surface framing echt target-free is bevestigd.

3. Voor twistknopen geldt geen `pq`-regel. Ze testen alleen:

```text
SL_phys(K) = SL_geom_proxy(K) + chi
```

4. Voor links moet je de `.txt` met componentblokken gebruiken, niet een stitched `.fseries`.

5. `integer_selection_chi = YES` is zwakker dan `exact_holonomy_chi = YES`.

6. `charge_safe = NO` betekent: niet canoniseren zonder extra constraint.

7. De load-bearing fysieke claim blijft:

```text
Exact neutral compensation exists and does not leak into electric charge/spectra.
```

---

## 16. Geteste run op jouw zipstructuur

Na unpack van `knots.zip` heb ik deze run getest vanuit de root waar `ideal.txt` staat:

```bat
python fs_unified_attachment_audit.py ^
  --fseries-root ./Knots_FourierSeries ^
  --ideal-txt ./ideal.txt ^
  --link-root ./knotplot ^
  --link-folder-glob "knot_*" ^
  --link-recursive ^
  --include-controls ^
  --core-models canon ^
  --out-prefix unified_readme_smoke
```

Deze test vond:

```text
single objects: 46
  single_torus: 13
  single_twist: 33

multicomponent links parsed: 23
link attachment result rows: 276
```

De linkscan vond onder andere:

```text
knot_TL2.4
knot_TL2.6
knot_TL2.8
knot_TL3.3_Gear
knot_TL3.6
knot_TL3.9
knot_TL6.15
knot_TL6.9
knot_6.3.3
```

Single-component folders in `knotplot/` worden bewust overgeslagen als link-input.
