# SST framed-helicity batch summary

Diagnostic:

\[
\frac{H}{\Gamma^2}=SL=Wr+Tw.
\]

Inventory rows: 32
Analysed single-component rows: 18
Skipped/missing rows: 14

## Top by |Wr|

| knot | id | family | amphichiral | Wr | Lk0 | Tw0 | target SL | status |
|---|---|---|---|---:|---:|---:|---:|---|
| 11_1 | `K11a367` | torus | no | -14.9433 | -15.0023 | -0.0590819 | 23 | CHECK |
| 9_1 | `9:1:1` | torus | no | 12.0683 | 12.0001 | -0.0682018 | 19 | PASS |
| 7_1 | `7:1:1` | torus | no | 9.17926 | 8.99951 | -0.179755 | 15 | PASS |
| 11_2 | `K11a247` | twist | no | 7.95937 | 8.02097 | 0.0616009 |  | NO_TARGET |
| 7_3 | `7:1:3` | seven_crossing_extra | no | -7.42928 | -7.00141 | 0.427874 |  | NO_TARGET |
| 9_2 | `9:1:2` | twist | no | -6.82275 | -7.01334 | -0.19059 |  | NO_TARGET |
| 5_1 | `5:1:1` | torus | no | -6.29223 | -5.99897 | 0.293262 | 11 | PASS |
| 7_4 | `7:1:4` | seven_crossing_extra_deprecated_quark | no | -5.79312 | -6.00785 | -0.214737 |  | NO_TARGET |
| 7_2 | `7:1:2` | twist | no | -5.69984 | -6.00839 | -0.308548 |  | NO_TARGET |
| 5_2 | `5:1:2` | twist_u_candidate | no | 4.54918 | 5.00383 | 0.454645 |  | NO_TARGET |
| 3_1 | `3:1:1` | torus_twist | no | -3.41728 | -2.99955 | 0.417732 | 7 | PASS |
| 10_1 | `10:1:1` | twist | no | -3.37813 | -3.00828 | 0.369852 |  | NO_TARGET |
| 6_2 | `6:1:2` | six_crossing_extra_deprecated_quark | no | -2.78478 | -3.00029 | -0.215507 |  | NO_TARGET |
| 8_1 | `8:1:1` | twist | no | -2.24448 | -2.00505 | 0.239433 |  | NO_TARGET |
| 6_1 | `6:1:1` | twist_d_candidate | no | -1.11809 | -1.00201 | 0.116075 |  | NO_TARGET |
| 6_3 | `6:1:3` | six_crossing_extra | no | 0.00414033 | -0.000402895 | -0.00454322 |  | NO_TARGET |
| 4_1 | `4:1:1` | amphichiral_control | yes | -0.000315096 | 4.59017e-06 | 0.000319686 |  | NO_TARGET |
| unknot | `0:1:1` | amphichiral_control | yes | 0 | 0 | 0 |  | NO_TARGET |

## Amphichiral controls

| knot | id | Wr | |Wr| | Lk0 | Tw0 |
|---|---|---:|---:|---:|---:|
| 4_1 | `4:1:1` | -0.000315096 | 0.000315096 | 4.59017e-06 | 0.000319686 |
| unknot | `0:1:1` | 0 | 0 | 0 | 0 |

## Skipped / missing

| id | label | status | reason |
|---|---|---|---|
| `6:3:1` | 6_3? | missing | ID not found in ideal.txt |
| `8:3:1` | 8_3? | missing | ID not found in ideal.txt |
| `8:9:1` | 8_9? | missing | ID not found in ideal.txt |
| `8:12:1` | 8_12? | missing | ID not found in ideal.txt |
| `8:17:1` | 8_17? | missing | ID not found in ideal.txt |
| `8:18:1` | 8_18? | missing | ID not found in ideal.txt |
| `5:1:3` | 5_x | missing | ID not found in ideal.txt |
| `0:1:2` | unlink_2? | skipped_multicomponent | Link/multi-component AB block requires mutual-linking helicity extension |
| `2:2:1` | Hopf_link? | skipped_multicomponent | Link/multi-component AB block requires mutual-linking helicity extension |
| `l2a1` | link_l2a1 | missing | ID not found in ideal.txt |
| `l4a1` | link_l4a1 | missing | ID not found in ideal.txt |
| `l5a1` | link_l5a1 | missing | ID not found in ideal.txt |
| `l6a1` | link_l6a1 | missing | ID not found in ideal.txt |
| `l8a1` | link_l8a1 | missing | ID not found in ideal.txt |
