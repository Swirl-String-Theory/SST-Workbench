# Windows v1.0.10 RC1 hardware and behavior evidence

These are **unaltered user-supplied outputs** from the first v1.0.10 candidate.
The pasted command log records 81/81 regressions, Windows full backend parity PASS, DD32-only PASS, non-short-circuit FULL diagnostic PASS, and output retention PASS.

Metadata defect discovered: project installer and parity reports use `1.0.9`, while v1.0.10 was executed from its versioned path and instance runtime. This defect is fixed in separate v1.0.10 RC2, **not** retrospectively corrected here.

Source candidate ZIP SHA-256: 25f42d3ecd2ee77eb24f09cefd699ef1513e515baae89f2ac65db68c7d49a647

| file | SHA-256 |
|---|---|
| `Pasted markdown(20261018-231142).md` | `1255cce1880e33697f1115f9dbfeda7eac7accba79fca26762ef00155cb5e226` |
| `BACKEND_SELFTEST(5).json` | `5be3fed4d9f1aec1917d3e05f0bd05be46aed8721e5e92ef746f698e4a47718e` |
| `DD32_PARITY_SMOKE(1).json` | `a94d5ebc3b538c786a255855c16f8f57fa8c6df2e13ae9fa99652bbdd2ccfdfc` |
| `SYCL_WORKER_BUILD.json` | `983ef3b15818935cd40d74e5801820fe83454002f79098560caba580507a2533` |

## Scope
C++ FP64 kernel parity and SYCL FP32/DD32 screening kernel parity succeeded in the ALL run. The DD32-only run intentionally skipped C++. Full Euler/PKLSA time evolution and physical SST claims remain unqualified.

Do not use this evidence as proof that the corrected RC2 package was executed on Windows.
