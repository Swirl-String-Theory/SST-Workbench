#!/usr/bin/env python3
"""Single-command entry point for the finite-core coefficient falsifier."""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys


def run(cmd: list[str], cwd: Path, allow_nonzero: bool = False) -> int:
    print("+", " ".join(cmd), flush=True)
    proc = subprocess.run(cmd, cwd=cwd)
    if proc.returncode and not allow_nonzero:
        raise SystemExit(proc.returncode)
    return proc.returncode


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/reference.yaml")
    ap.add_argument("--relative-tolerance", type=float, default=5.0e-3)
    args = ap.parse_args()
    root = Path(__file__).resolve().parent
    py = sys.executable
    run([py, "derive_blind.py", "--config", args.config], root)
    run([py, "run_campaign.py", "--config", args.config], root)
    code = run([
        py, "score_target.py",
        "--input", "outputs/blind_result.json",
        "--campaign", "outputs/campaign_summary.json",
        "--relative-tolerance", str(args.relative_tolerance),
    ], root, allow_nonzero=True)
    print("\nScored report: outputs/scored_result.json")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
