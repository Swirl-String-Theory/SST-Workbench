#!/usr/bin/env python3
from pathlib import Path

src = Path('SST_CANON-v0.8.19-research-track.tex')
block = Path('canon_blocks/SST_CANON-v0.8.19-research-track-planck-routes-A-D-clean-block.tex')
out = Path('SST_CANON-v0.8.19-research-track-planck-routes-A-D.patched.tex')
marker = '% ----------------------------------------------------------\n% Bibliography entries for the Relativity Emergence Ladder'
text = src.read_text(encoding='utf-8')
insert = block.read_text(encoding='utf-8')
if marker in text:
    patched = text.replace(marker, insert + '\n\n' + marker)
else:
    patched = text + '\n\n' + insert
out.write_text(patched, encoding='utf-8')
print(f'wrote {out}')
