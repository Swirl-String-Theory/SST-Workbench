@echo off
setlocal
if not defined SST_PRIVATE_DENYLIST (
  echo ERROR - Full blind sealing requires SST_PRIVATE_DENYLIST pointing to the separate private denylist.txt.
  echo Example: set SST_PRIVATE_DENYLIST=C:\private\A043\denylist.txt
  exit /b 2
)
call run_00_setup.cmd || exit /b 1
call run_01_selftest.cmd || exit /b 1
call run_02_basic.cmd %* || exit /b 1
call .venv\Scripts\activate.bat
python tools\check_blind_a043.py --denylist "%SST_PRIVATE_DENYLIST%" || exit /b 1
python tools\pack_outputs.py SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs ..\SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs_BLIND.zip || exit /b 1
echo PASS - full blind BASIC chain sealed. Reveal is explicit and separate.
