# Model assumptions — v0.3.0

1. Incompressible, inviscid filament dynamics are represented by the package's regularised midpoint Biot–Savart kernel.
2. The physical centerline is the `3:1:1` entry from the bundled `ideal_3_1_1.txt`.
3. The two physical channels are offset by `offset/D=0.5` in the canonical run and carry equal/opposite circulation.
4. `eps/D=0.05` is the canonical regularisation; it is a nuisance parameter and is explicitly swept rather than fitted.
5. The temporal Jacobian is evaluated by central differences of the complete pair RHS. The finite-difference step is a numerical parameter and is convergence-tested.
6. The `m=1` four-state Kelvin subspace is a Galerkin truncation, not the complete Euler spectrum.
7. The frozen monodromy has a true Floquet interpretation only if H3 establishes a relative equilibrium. The present canonical geometry fails H3.
8. Alpha is absent from H0-H12. No mode, resolution, core width, channel phase or orientation may be selected after looking at alpha.
9. The post-hoc map uses unit coefficient: `alpha_inv_pred = alpha0_inv + h_F`. No fitted multiplier is permitted.
10. Identification `D=2 r_c` is used only for optional SI clock reporting and never enters the blind dimensionless calculation.
