"""SST dark-knot Rayleigh / rocking / breathing audit harness."""

from .core import (
    run,
    run_audit,
    run_sweep,
    run_all_checks,
    write_csv,
    write_json,
    load_vertices_csv,
    save_vertices_csv,
)

from .taxonomy import (
    TAXONOMY_SCHEMA_VERSION,
    compute_record,
    compute_hvol_fields,
    taxonomy_sector,
    apply_mirror,
    validate_record_light,
    load_jsonl,
    write_jsonl,
    lookup_record,
    run_taxonomy_checks,
)

__all__ = [
    "run",
    "run_audit",
    "run_sweep",
    "run_all_checks",
    "write_json",
    "write_csv",
    "load_vertices_csv",
    "save_vertices_csv",
    "TAXONOMY_SCHEMA_VERSION",
    "compute_record",
    "compute_hvol_fields",
    "taxonomy_sector",
    "apply_mirror",
    "validate_record_light",
    "load_jsonl",
    "write_jsonl",
    "lookup_record",
    "run_taxonomy_checks",
]

__version__ = "0.3.0-research-track"
