"""Plot Figure 3 from the prepared data and fitted lines."""

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


base_dir = Path(__file__).resolve().parents[1]
data_dir = base_dir / "data"
results_dir = base_dir / "results"

data_sets = [
    {
        "name": "s1_pmt",
        "file": "fig3_s1_pmt.csv",
        "label": "S1 + PMT",
        "marker": "^",
        "color": "#2166AC",
    },
    {
        "name": "s1_phototube",
        "file": "fig3_s1_phototube.csv",
        "label": "S1 + phototube",
        "marker": "s",
        "color": "#B2182B",
    },
    {
        "name": "ts1_phototube",
        "file": "fig3_ts1_phototube.csv",
        "label": "TS1 + phototube",
        "marker": "o",
        "color": "#1B7837",
    },
    {
        "name": "ts1_phototube_optimized",
        "file": "fig3_ts1_phototube_optimized.csv",
        "label": "TS1 + phototube (optimized)",
        "marker": "D",
        "color": "#E69F00",
    },
]


def read_plot_data(filename):
    tau = []
    allan = []
    lower = []
    upper = []

    with open(data_dir / filename, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["plot_point"].strip().lower() == "true":
                value = float(row["allan_deviation"])
                tau.append(float(row["tau_s"]))
                allan.append(value)
                lower.append(value - float(row["errorbar_lower"]))
                upper.append(float(row["errorbar_upper"]) - value)

    errors = np.array([lower, upper])
    return np.array(tau), np.array(allan), errors


def read_fit_lines():
    lines = {}

    with open(results_dir / "fit_lines.csv", "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["dataset_id"]
            if name not in lines:
                lines[name] = {"tau": [], "allan": []}
            lines[name]["tau"].append(float(row["tau_s"]))
            lines[name]["allan"].append(float(row["fitted_allan_deviation"]))

    return lines


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "mathtext.fontset": "dejavusans",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "font.size": 9,
            "axes.labelsize": 9,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 8,
            "figure.dpi": 300,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.05,
        }
    )

    fit_lines = read_fit_lines()
    fig, ax = plt.subplots(figsize=(3.5, 3.0))

    for item in data_sets:
        tau, allan, errors = read_plot_data(item["file"])

        ax.errorbar(
            tau,
            allan,
            yerr=errors,
            fmt=item["marker"],
            ms=4,
            color=item["color"],
            markerfacecolor="none",
            elinewidth=0.7,
            capsize=0,
            label=item["label"],
            zorder=5,
        )

        line = fit_lines[item["name"]]
        ax.plot(
            line["tau"],
            line["allan"],
            color=item["color"],
            alpha=0.35,
            lw=0.8,
            ls="--",
        )

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel(r"Averaging time $\tau$ (s)")
    ax.set_ylabel("Fractional frequency instability")
    ax.set_xlim(1, 10000)
    ax.set_ylim(1e-15, 3e-12)
    ax.set_xticks([1, 10, 100, 1000])
    ax.set_yticks([1e-14, 1e-13, 1e-12])
    ax.get_xaxis().set_major_formatter(plt.ScalarFormatter())
    ax.tick_params(which="minor", length=2, width=0.5, color="gray")
    ax.grid(True, which="major", ls=":", alpha=0.35)
    ax.legend(loc="lower left", frameon=False)

    fig.tight_layout(pad=0.8)
    results_dir.mkdir(exist_ok=True)
    fig.savefig(results_dir / "Fig3.pdf")
    fig.savefig(results_dir / "Fig3.png")
    plt.close(fig)


if __name__ == "__main__":
    main()
