
MODE: FULL EXPANSION

TASK:
Expand ONE section into full LaTeX.

RULES:
- Full derivations
- No logical gaps
- Use align + labels
- Add citations where needed
