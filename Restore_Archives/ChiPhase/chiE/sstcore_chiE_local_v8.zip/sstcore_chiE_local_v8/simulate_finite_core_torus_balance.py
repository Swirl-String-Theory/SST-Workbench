#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sst_core_model_ladder import (
    TARGET_CHI_E,
    evaluate_finite_core_balance,
    rows_to_dicts,
    write_csv,
    write_json,
)

SCRIPT_DIR = Path(__file__).resolve().parent
EXPORT_DIR = SCRIPT_DIR / "exports"
EXPORT_DIR.mkdir(exist_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Finite-core toroidal balance diagnostic: regularized exterior + resolved interior profile.")
    parser.add_argument("--lambda-min", type=float, default=1.0)
    parser.add_argument("--lambda-max", type=float, default=8.0)
    parser.add_argument("--lambda-count", type=int, default=33)
    parser.add_argument("--epsilon", type=float, default=1.0)
    parser.add_argument("--profile", default="rankine", choices=["rankine", "polynomial", "lamb_oseen", "nlse_tanh"])
    parser.add_argument("--shape", type=float, default=1.0)
    parser.add_argument("--unnormalized-boundary", action="store_true")
    parser.add_argument("--n-theta", type=int, default=8192)
    parser.add_argument("--n-profile", type=int, default=4096)
    args = parser.parse_args()

    t0 = time.time()
    lambdas = np.linspace(args.lambda_min, args.lambda_max, args.lambda_count)
    rows = [
        evaluate_finite_core_balance(
            lambda_=float(lam), epsilon=args.epsilon, profile=args.profile, shape=args.shape,
            normalize_boundary=not args.unnormalized_boundary,
            n_theta=args.n_theta, n_profile=args.n_profile,
        )
        for lam in lambdas
    ]
    horn = evaluate_finite_core_balance(
        lambda_=1.0, epsilon=args.epsilon, profile=args.profile, shape=args.shape,
        normalize_boundary=not args.unnormalized_boundary,
        n_theta=args.n_theta, n_profile=args.n_profile,
    )
    best = min(rows, key=lambda r: abs(r.chi_E - TARGET_CHI_E))

    write_csv(EXPORT_DIR / "finite_core_torus_balance_scan.csv", rows)
    summary = {
        "run": "finite_core_torus_balance",
        "status": "RESEARCH-TRACK / FINITE-CORE DIAGNOSTIC / NOT CANONIZED",
        "warning": "Exterior energy still uses a regularized circular-filament kernel. This is not a full exterior Dirichlet solve.",
        "params": vars(args),
        "target_chi_E": TARGET_CHI_E,
        "horn_row": rows_to_dicts([horn])[0],
        "best_lambda_to_2pi": rows_to_dicts([best])[0],
        "elapsed_s": time.time() - t0,
    }
    write_json(EXPORT_DIR / "finite_core_torus_balance_summary.json", summary)

    lam = np.array([r.lambda_ for r in rows])
    chi_ext = np.array([r.chi_external_regularized for r in rows])
    chi_int = np.array([r.chi_internal for r in rows])
    chi_total = np.array([r.chi_E for r in rows])

    plt.figure(figsize=(10, 6))
    plt.plot(lam, chi_total, marker="o", linewidth=1, label=r"$\chi_E$ finite-core diagnostic")
    plt.plot(lam, chi_ext, linewidth=1, label=r"$\chi_{\rm ext}^{\rm reg}$")
    plt.plot(lam, chi_int, linewidth=1, label=r"$\chi_{\rm int}$")
    plt.axhline(TARGET_CHI_E, linestyle="--", label=r"target $2\pi$")
    plt.xlabel(r"$\lambda=R/a_0$")
    plt.ylabel("dimensionless energy factor")
    plt.title(f"Finite-core toroidal balance: {args.profile}")
    plt.grid(True, alpha=0.35)
    plt.legend()
    plt.tight_layout()
    plt.savefig(EXPORT_DIR / "finite_core_torus_balance_scan.png", dpi=180)
    plt.close()

    text_path = EXPORT_DIR / "finite_core_torus_balance_run_results_summary.txt"
    with text_path.open("w", encoding="utf-8") as f:
        f.write("SST finite-core toroidal balance diagnostic\n")
        f.write("===========================================\n")
        f.write(f"profile                         = {args.profile}\n")
        f.write(f"shape                           = {args.shape:.16e}\n")
        f.write(f"epsilon                         = {args.epsilon:.16e}\n")
        f.write(f"target 2*pi                     = {TARGET_CHI_E:.16e}\n\n")
        f.write("Horn row lambda=1:\n")
        f.write(f"chi_external_regularized        = {horn.chi_external_regularized:.16e}\n")
        f.write(f"chi_internal                    = {horn.chi_internal:.16e}\n")
        f.write(f"chi_E                           = {horn.chi_E:.16e}\n")
        f.write(f"residual                        = {horn.target_residual:.16e}\n\n")
        f.write("Interpretation:\n")
        f.write("This removes positive hollow-cavity work and replaces it with a resolved internal kinetic profile.\n")
        f.write("The exterior remains a regularized circular-filament diagnostic; a full Dirichlet solve remains open.\n")
    print(f"[*] Wrote {text_path}")
    print(f"horn chi_E={horn.chi_E:.12g}, residual={horn.target_residual:.6g}")


if __name__ == "__main__":
    main()
