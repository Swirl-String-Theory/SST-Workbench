"""Recreate the time-averaged D-field figure and D_eff comparison from raw outputs and merged data."""

from __future__ import annotations

from pathlib import Path
import re

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.gridspec import GridSpec
from scipy.optimize import curve_fit
from scipy.signal import find_peaks

from _common import DEFAULT_CASE_ROOT, FIGURE_DIR, find_psi_dir, load_merged, parse_snapshot_time, setup_matplotlib

from functions import velocity_field
from Helmholtz_decompose import H_decompos
import variable as var


PARAM_SETS = [
    (0.9, 20, 0.55)
]
RIGHT_PANEL_V0 = 0.9
TIME_MIN = 2000.0
TIME_MAX = 10000.0
XREL_LIM = (-50.0, 50.0)
Y_LIM = (-50.0, 50.0)
SAVE_NAME = "time_averaged_vorticity_field.png"
CASE_DIR_RE = re.compile(
    r"^V0=(?P<V0>[+-]?\d+(?:\.\d+)?) sigma=(?P<sigma>\d+) v=(?P<speed>[+-]?\d+(?:\.\d+)?) dt = .* GPU.*$"
)


setup_matplotlib()
merged = load_merged()
custom_cmap = LinearSegmentedColormap.from_list(
    "BlueRed_balanced",
    [(0.00, "#2b83d3"), (0.25, "#b3d7ea"), (0.50, "#f7f7f7"), (0.75, "#f4b6c2"), (1.00, "#c51b3a")],
)

x_rel_full = var.x - var.obstacle_position
x_idx = np.where((x_rel_full >= XREL_LIM[0]) & (x_rel_full <= XREL_LIM[1]))[0]
y_idx = np.where((var.y >= Y_LIM[0]) & (var.y <= Y_LIM[1]))[0]
CROP_SLICE = np.s_[y_idx[0] : y_idx[-1] + 1, x_idx[0] : x_idx[-1] + 1]
x_rel = x_rel_full[x_idx]
y_vals = var.y[y_idx]


def D_field(psi):
    dpsi1_dx = np.gradient(psi.real, var.dx, axis=1)
    dpsi2_dx = np.gradient(psi.imag, var.dx, axis=1)
    dpsi1_dy = np.gradient(psi.real, var.dy, axis=0)
    dpsi2_dy = np.gradient(psi.imag, var.dy, axis=0)
    return dpsi1_dx * dpsi2_dy - dpsi1_dy * dpsi2_dx


def compute_vorticity(vx, vy):
    return np.gradient(vy, var.dx, axis=1) - np.gradient(vx, var.dy, axis=0)


def list_case_files(V0, sigma, speed):
    psi_dir = find_psi_dir(V0, sigma, speed)
    return [path for path in sorted(psi_dir.glob("psi_time:*.npy"), key=parse_snapshot_time) if TIME_MIN <= parse_snapshot_time(path) <= TIME_MAX]


def load_case_stack(V0, sigma, speed):
    files = list_case_files(V0, sigma, speed)
    if not files:
        raise RuntimeError(f"No psi snapshots found in [{TIME_MIN}, {TIME_MAX}] for V0={V0}, sigma={sigma}, speed={speed}.")
    return np.asarray([np.load(path)[CROP_SLICE] for path in files])


def compute_case_means(V0, sigma, speed):
    data_arr = load_case_stack(V0, sigma, speed)
    density_mean = np.mean(np.abs(data_arr) ** 2, axis=0)
    irr_x_mean = np.zeros_like(density_mean)
    irr_y_mean = np.zeros_like(density_mean)
    omega_accum = []
    d_accum = []

    for psi in data_arr:
        phase = np.arctan2(psi.imag, psi.real)
        vx, vy = velocity_field(phase)
        (vx_irr, vy_irr), _ = H_decompos(vx, vy, vx.shape[1], vx.shape[0], var.dx, var.dy)
        irr_x_mean += vx_irr - speed
        irr_y_mean += vy_irr
        omega_accum.append(compute_vorticity(vx, vy))
        d_accum.append(D_field(psi))

    count = len(data_arr)
    irr_x_mean /= count
    irr_y_mean /= count
    irr = np.sqrt(irr_x_mean**2 + irr_y_mean**2)
    omega_mean = np.mean(np.asarray(omega_accum), axis=0)
    d_mean = np.mean(np.asarray(d_accum), axis=0)
    return density_mean, irr, omega_mean, d_mean


def compute_tf_profile(V0, sigma):
    Xg, Yg = np.meshgrid(x_rel, y_vals)
    r2 = Xg**2 + Yg**2
    return np.maximum(1.0 - V0 * np.exp(-2.0 * r2 / (sigma**2)), 0.0)


def contour_with_optional_guide(ax, field, with_guide):
    cs = ax.contour(x_rel, y_vals, field, levels=[0.0], colors="black")
    if not with_guide or not cs.collections or not cs.collections[0].get_paths():
        return
    vertices = cs.collections[0].get_paths()[0].vertices
    x_vert = vertices[:, 0]
    y_vert = vertices[:, 1]
    y_min = np.min(y_vert)
    y_max = np.max(y_vert)
    x_at_ymin = x_vert[np.argmin(np.abs(y_vert - y_min))]
    x_at_ymax = x_vert[np.argmin(np.abs(y_vert - y_max))]
    x_arrow = x_rel.max() - 15.0
    ax.hlines(y_min, x_at_ymin, x_arrow, colors="black", linestyles="--", linewidth=0.6)
    ax.hlines(y_max, x_arrow, x_at_ymax, colors="black", linestyles="--", linewidth=0.6)
    ax.annotate("", xy=(x_arrow, y_max), xytext=(x_arrow, y_min), arrowprops=dict(arrowstyle="<->", color="black", lw=0.6))
    ax.text(x_arrow + 3.0, 0.5 * (y_min + y_max), r"$\rm D_{{eff}}$", color="black", fontsize=8, va="center")


def draw_panel(ax, V0, sigma, speed, with_guide=False):
    density_mean, irr, omega_mean, d_mean = compute_case_means(V0, sigma, speed)
    mach_field = irr - np.sqrt(compute_tf_profile(V0, sigma))
    contour_with_optional_guide(ax, mach_field, with_guide)
    im = ax.imshow(
        d_mean,
        cmap=custom_cmap,
        origin="lower",
        extent=[x_rel.min(), x_rel.max(), y_vals.min(), y_vals.max()],
        vmin=-0.055,
        vmax=0.055,
        aspect="equal",
    )
    ax.set_xticks([-25, 0, 25])
    ax.set_yticks([-50, -25, 0, 25, 50])
    ax.set_xlabel(r"$x/\xi$")
    ax.set_ylabel(r"$y/\xi$")
    ax.add_patch(plt.Circle((0.0, 0.0), sigma, edgecolor="grey", facecolor="none", linewidth=0.8, linestyle="dotted"))
    return im, omega_mean


def measure_nucleation_width(omega_mean):
    strength = np.sum(omega_mean, axis=1)
    pos_peaks, _ = find_peaks(strength, prominence=max(np.max(strength) * 0.3, 1e-12))
    neg_peaks, _ = find_peaks(-strength, prominence=max(np.max(np.abs(strength)) * 0.3, 1e-12))
    if len(pos_peaks) == 0 or len(neg_peaks) == 0:
        return None
    y_pos = y_vals[pos_peaks[np.argmax(strength[pos_peaks])]]
    y_neg = y_vals[neg_peaks[np.argmax((-strength)[neg_peaks])]]
    return abs(float(y_pos - y_neg))


def lookup_deff(V0, sigma, speed):
    subset = merged[(np.isclose(merged[:, 0], V0)) & (np.isclose(merged[:, 1], sigma)) & (np.isclose(merged[:, 2], speed))]
    if subset.size == 0:
        return None
    return float(subset[0, 6])


def list_available_right_panel_cases():
    cases = []
    for case_dir in sorted(DEFAULT_CASE_ROOT.iterdir()):
        if not case_dir.is_dir():
            continue
        match = CASE_DIR_RE.match(case_dir.name)
        if match is None:
            continue
        V0 = float(match.group("V0"))
        sigma = int(match.group("sigma"))
        speed = float(match.group("speed"))
        if RIGHT_PANEL_V0 is not None and not np.isclose(V0, RIGHT_PANEL_V0):
            continue
        cases.append((V0, sigma, speed))
    return cases


def lin_fit(x, a):
    return a * x


fig = plt.figure(figsize=(7, 2.6))
fig.subplots_adjust(left=0.1, right=0.98, bottom=0.15, top=0.95)
subfigs = fig.subfigures(1, 2, wspace=0.1, width_ratios=[2, 1.15])
left_gs = GridSpec(2, 3, figure=subfigs[0], left=0.06, right=0.87, bottom=0.15, top=0.92, wspace=0.0, hspace=0.1)

axes = []
alphabet = ["a", "b", "c", "d", "e", "f"]
for idx, (V0, sigma, speed) in enumerate(PARAM_SETS):
    row, col = divmod(idx, 3)
    ax = subfigs[0].add_subplot(left_gs[row, col])
    im, _ = draw_panel(ax, V0, sigma, speed, with_guide=(idx == len(PARAM_SETS) - 1))
    ax.text(0.13, 0.88, f"({alphabet[idx]})", color="k", ha="center", va="center", transform=ax.transAxes, fontsize=8)
    if col != 0:
        ax.tick_params(labelleft=False)
        ax.set_ylabel("")
    if row == 0:
        ax.set_title(f"$v_0/c_\\mathrm{{s0}}$={speed:.2f}")
        ax.set_xticklabels([])
        ax.set_xlabel("")
    axes.append(ax)

cbar = subfigs[0].colorbar(im, ax=axes, orientation="vertical", fraction=0.03, pad=0.04, shrink=0.8)
cbar.ax.set_title(r"$\overline{\omega_\mathrm{{s}}}/\omega_\mathrm{{s0}}$", x=1.5)
cbar.set_ticks([-0.05, -0.025, 0.0, 0.025, 0.05])
cbar.set_ticklabels(["-5", "-2.5", "0", "2.5", r"$5\times 10^{-2}$"])

ax_right = subfigs[1].subplots(1, 1)
plot_rows = []
for V0, sigma, speed in list_available_right_panel_cases():
    deff = lookup_deff(V0, sigma, speed)
    if deff is None:
        continue
    try:
        _, _, omega_mean, _ = compute_case_means(V0, sigma, speed)
    except Exception:
        continue
    nuc_width = measure_nucleation_width(omega_mean)
    if nuc_width is None:
        continue
    plot_rows.append([sigma, speed, deff, nuc_width])

if not plot_rows:
    raise RuntimeError("No D_eff vs nucleation-width points could be assembled from merged data and available outputs.")

results = np.asarray(plot_rows, dtype=float)
unique_sigmas = sorted(np.unique(results[:, 0]).astype(int))
colors_list = ["C0", "C1", "C2", "C3", "C4", "C5", "C6"]
markers = ["o", "s", "^", "D", "v", "P", "X"]

for sigma, color, marker in zip(unique_sigmas, colors_list, markers):
    mask = results[:, 0] == sigma
    if not np.any(mask):
        continue
    y_sup = results[mask, 2] / 2.0
    nuc_w = results[mask, 3] / 2.0
    ax_right.plot(nuc_w, y_sup, marker=marker, linestyle="None", mec=color, mew=0.7, markersize=3, mfc=colors.to_rgba(color, alpha=0.3), label=rf"{sigma}")

max_range = float(max(np.max(results[:, 2] / 2.0), np.max(results[:, 3] / 2.0)))
popt, pcov = curve_fit(lin_fit, results[:, 3] / 2.0, results[:, 2] / 2.0)
x_fit = np.linspace(0, max_range, 400)
y_fit = popt[0] * x_fit
ax_right.plot(x_fit, y_fit, ls="--", lw=0.8, alpha=0.9, color="k", zorder=1)

ax_right.set_xlabel(r"$w_\mathrm{n}/2$ ($\xi$)")
ax_right.set_ylabel(r"$D_\mathrm{eff}/2$ ($\xi$)")
ax_right.legend(frameon=False, title=r"$\sigma/\xi$")

out = FIGURE_DIR / SAVE_NAME
fig.savefig(out, dpi=600)
plt.close(fig)
print(f"saved {out}")
