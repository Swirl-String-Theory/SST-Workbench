"""Native G0-G9 adapter. No physical provider is fabricated."""
from pathlib import Path
import json
from sst_falsifier.protocol import assert_frozen
from .readiness import require_ready,implementation_integrity
from .precheck import source_audit,run_analytic

def run_scientific_pipeline(root,cfg,ledger,mode):
    root=Path(root)
    require_ready(root)
    assert_frozen(root,root/'preregistration/FROZEN_PROTOCOL.json')
    integrity,errors=implementation_integrity(root)
    ledger.record('G0','PASS' if integrity else 'FAIL',metrics={'implementation_errors':errors},reason='Native frozen bundle verified; implementation lock checked.')
    if not ledger.dependencies_pass('G1'): ledger.skip_due_prerequisite('G1')
    else:
        src=source_audit(root)
        # Authoritative provider and registry acceptance remains explicitly unimplemented.
        ledger.record('G1','UNRESOLVED',metrics=src,reason='Paper hashes alone do not qualify registry identity or independent scientific providers.')
    for gid in ['G2','G3','G4','G5','G6','G7','G8']:
        if not ledger.defs[gid].enabled: ledger.record(gid,'NOT_APPLICABLE',reason='Framework configuration disabled this lane; no PASS claim.')
        elif not ledger.dependencies_pass(gid): ledger.skip_due_prerequisite(gid,reason='Prerequisite unresolved; scientific state UNRESOLVED.')
        elif gid=='G2':
            analytic=run_analytic(root)
            ledger.record(gid,'UNRESOLVED',metrics=analytic,reason='Engineering controls executed; production parameters not yet preregistered.')
        else: ledger.record(gid,'UNRESOLVED',reason='Required registered provider/implementation has not executed.')
    return {'schema':'SST-BACKEND-MANIFEST-2','python_reference':{'actual_backend':'python-numpy-fp64','authority':'REFERENCE','precision':'float64'},'cpp':{'authority':'UNRESOLVED','scope':'tensor engineering precheck only; full G5 unimplemented'},'scientific_certification':False}
