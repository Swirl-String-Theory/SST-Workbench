@echo off
setlocal
cd /d "%~dp0.."
call "cmd\01_BUILD_CPP.cmd"
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe run_selftest.py
