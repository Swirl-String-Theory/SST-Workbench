# MODEL_NOTES — v0.2.0 explicit source-organized closed threads

## 1. No global velocity observable is assumed

The intended architecture distinguishes a local objective texture from a universal absolute velocity.  A common boost

\[
\mathbf X\mapsto\mathbf X+\mathbf U_0 t,
\qquad
\mathbf B\mapsto\mathbf B+\mathbf U_0 t
\]

must leave all intrinsic knot/link observables invariant.

## 2. A source cannot be a vorticity monopole in ordinary incompressible flow

For

\[
\boldsymbol\omega=\nabla\times\mathbf v,
\]

one has identically

\[
\nabla\cdot\boldsymbol\omega=0.
\]

Therefore a source cannot simply create open vortex lines that terminate in space.  v0.2.0 models a source as **organizing closed loops**: locally they can look radial, while the compensating return vorticity is remote.

This is a model constraint, not yet an SST canon derivation of how Earth or Sun generates the loops.

## 3. Local source geometry

For local active-center points \(\mathbf q_a\), the active vorticity direction is

\[
\mathbf n_a=\frac{\mathbf q_a-\mathbf X_s}{|\mathbf q_a-\mathbf X_s|}.
\]

At finite source distance the bundle has direction texture.  In the limit

\[
|\mathbf X_s-\mathbf x_c|/R_g\rightarrow\infty,
\]

all \(\mathbf n_a\) approach one common direction, giving the G7 radial-to-parallel limit.

## 4. Remote closure

Every thread is a four-segment closed loop:

1. local active segment;
2. outward connector;
3. remote anti-parallel return;
4. closing connector.

The loop is cyclic in the solver, hence

\[
\sum_j\Delta\boldsymbol\ell_j=0
\]

up to floating-point roundoff.

## 5. Stress-test amplitudes

The supplied `thread_total_gamma_ratio`, source distances and “Sun” strength are intentionally not fitted to experimental gravity data and are not asserted as canon constants.  Their purpose is to give a resolvable, reproducible finite-core vortex interaction on dimensionless relaxed-knot data.

A physically calibrated successor requires a canon-derived map of the form

\[
\{M_a,R_a,\text{SST source state}\}
\longmapsto
\{\Gamma_{a,k},C_{a,k},a_{a,k}\}
\]

for the generated background filaments.

## 6. What can falsify this implementation

- a common boost changes intrinsic evolution beyond numerical tolerance;
- closed-loop/topological validity fails;
- the answer depends materially on where the compensating return flux is placed after the return is already remote;
- moving the organizing source farther away does not approach the parallel-bundle limit;
- fixed-core spatial refinement fails to converge;
- the prior holdouts fail spatial or temporal certification.
