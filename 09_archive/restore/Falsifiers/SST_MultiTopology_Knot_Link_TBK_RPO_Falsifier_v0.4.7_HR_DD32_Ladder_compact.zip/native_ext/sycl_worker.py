from __future__ import annotations
import atexit, hashlib, json, os, platform, shutil, struct, subprocess, sys, threading, time
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build'
CPP=ROOT/'cpp'/'sycl_worker.cpp'
_WORKER_BUILD_FLAGS='-fsycl|-fsycl-device-code-split=per_kernel|-O3|-fp-model=precise|-std=c++17|protocol-v2-dd32'

def _icpx():
    for x in (os.environ.get('ICPX'),os.environ.get('CXX'),'icpx'):
        if not x: continue
        p=Path(x)
        if p.exists(): return str(p.resolve())
        w=shutil.which(x)
        if w: return str(Path(w).resolve())
    for p in (Path(r'C:\Program Files (x86)\Intel\oneAPI\compiler\latest\bin\icpx.exe'),Path(r'C:\Program Files\Intel\oneAPI\compiler\latest\bin\icpx.exe')):
        if p.exists(): return str(p.resolve())
    return None

def _compiler_fingerprint():
    cxx=_icpx()
    if not cxx: return 'icpx-unresolved'
    try:
        p=Path(cxx); st=p.stat()
        return f'{p}|{st.st_size}|{st.st_mtime_ns}'
    except Exception:
        return str(cxx)

def _worker_tag():
    h=hashlib.sha256()
    h.update(CPP.read_bytes())
    h.update(_WORKER_BUILD_FLAGS.encode('utf-8'))
    h.update(_compiler_fingerprint().encode('utf-8','replace'))
    return h.hexdigest()[:12]

_WORKER_TAG=_worker_tag()
EXE=BUILD/((f'sst_sycl_worker_{_WORKER_TAG}.exe') if platform.system().lower()=='windows' else f'sst_sycl_worker_{_WORKER_TAG}')
MAGIC_REQ=0x31545353
MAGIC_RES=0x52545353
CMD_F32=2
CMD_F64=3
CMD_DD32=4
CMD_QUIT=9
_LOCK=threading.RLock()
_PROC=None
_INFO=None

def build_worker(force=False,verbose=True):
    """Build the content-addressed standalone SYCL worker.

    On Windows an executable cannot be overwritten while any process still has
    the image mapped.  Therefore we never link directly to the canonical worker
    path.  We compile to a unique temporary executable and then publish it.
    Because EXE is content-addressed by source+flags, an already-existing EXE is
    already the correct binary and is safe to reuse even when --force was asked.
    """
    BUILD.mkdir(exist_ok=True)
    if EXE.exists() and not force:
        if verbose: print(f'[SST-SYCL-WORKER] reuse: {EXE}',file=sys.stderr)
        return True
    cxx=_icpx()
    if not cxx:
        if verbose: print('[SST-SYCL-WORKER] icpx not found; call oneAPI setvars.bat first',file=sys.stderr)
        return False
    suffix='.exe' if platform.system().lower()=='windows' else ''
    tmp=BUILD/f'.sst_sycl_worker_{_WORKER_TAG}.build_{os.getpid()}_{time.time_ns()}{suffix}'
    cmd=[cxx,'-fsycl','-fsycl-device-code-split=per_kernel','-O3','-fp-model=precise','-std=c++17',str(CPP),'-o',str(tmp)]
    if verbose: print('[SST-SYCL-WORKER] compile:',' '.join(cmd),file=sys.stderr)
    cp=subprocess.run(cmd,cwd=str(ROOT),text=True,capture_output=True)
    if cp.returncode!=0:
        if verbose: print((cp.stdout+'\n'+cp.stderr)[-12000:],file=sys.stderr)
        try: tmp.unlink(missing_ok=True)
        except Exception: pass
        return False
    if not tmp.exists(): return False
    try:
        # If the same content-addressed target already exists, replacing it is
        # unnecessary and may fail on Windows if an older worker process still
        # has it mapped.  Reuse it and discard the freshly verified build.
        if EXE.exists():
            if verbose: print(f'[SST-SYCL-WORKER] target already exists; reusing locked-safe binary: {EXE}',file=sys.stderr)
            tmp.unlink(missing_ok=True)
            return True
        os.replace(tmp,EXE)
    except Exception as e:
        if EXE.exists():
            if verbose: print(f'[SST-SYCL-WORKER] publish target busy; reusing existing content-addressed binary: {EXE} ({type(e).__name__}: {e})',file=sys.stderr)
            try: tmp.unlink(missing_ok=True)
            except Exception: pass
            return True
        if verbose: print(f'[SST-SYCL-WORKER] failed to publish worker: {type(e).__name__}: {e}',file=sys.stderr)
        try: tmp.unlink(missing_ok=True)
        except Exception: pass
        return False
    return EXE.exists()

def probe_worker(force_build=False,verbose=False):
    if not build_worker(force=force_build,verbose=verbose): return {'available':False,'error':'build_failed'}
    env=os.environ.copy();env.setdefault('SYCL_CACHE_PERSISTENT','0')
    try:
        cp=subprocess.run([str(EXE),'--probe'],cwd=str(ROOT),env=env,text=True,capture_output=True,timeout=30)
        if cp.returncode!=0: return {'available':False,'returncode':cp.returncode,'stderr':cp.stderr.strip()}
        d=json.loads(cp.stdout.strip().splitlines()[-1]);d.update(available=True,transport='external_process',executable=str(EXE))
        return d
    except Exception as e: return {'available':False,'error':f'{type(e).__name__}: {e}'}

def _read_exact(stream,n):
    b=bytearray()
    while len(b)<n:
        z=stream.read(n-len(b))
        if not z: raise RuntimeError('SYCL worker terminated while reading response')
        b.extend(z)
    return bytes(b)

def _start():
    global _PROC,_INFO
    with _LOCK:
        if _PROC is not None and _PROC.poll() is None: return _PROC
        info=probe_worker(verbose=False)
        if not info.get('available'): raise RuntimeError(f'SYCL worker unavailable: {info}')
        env=os.environ.copy();env.setdefault('SYCL_CACHE_PERSISTENT','0')
        _PROC=subprocess.Popen([str(EXE)],cwd=str(ROOT),env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        # Worker writes readiness to stderr so stdout remains purely binary.
        line=_PROC.stderr.readline().decode('utf-8','replace').strip()
        if not line.startswith('SST_WORKER_READY '):
            rc=_PROC.poll(); raise RuntimeError(f'SYCL worker did not become ready (rc={rc}): {line}')
        try: _INFO=json.loads(line[len('SST_WORKER_READY '):])
        except Exception: _INFO=info
        _INFO.update(available=True,transport='persistent_external_process',executable=str(EXE))
        return _PROC

def worker_info(start=False):
    global _INFO
    if start:
        try: _start()
        except Exception as e: return {'available':False,'error':f'{type(e).__name__}: {e}'}
    if _INFO is not None: return dict(_INFO)
    return probe_worker(verbose=False)

def shutdown_worker():
    global _PROC
    with _LOCK:
        p=_PROC;_PROC=None
        if p is None: return
        try:
            if p.poll() is None and p.stdin:
                p.stdin.write(struct.pack('<II',MAGIC_REQ,CMD_QUIT));p.stdin.flush()
                p.wait(timeout=2)
        except Exception:
            try:p.kill()
            except Exception:pass
atexit.register(shutdown_worker)

def biot_savart(points,queries,gamma=1.0,core=0.04,require_fp64=False,numeric_mode=None):
    """Biot-Savart through the persistent SYCL worker.

    numeric_mode:
      - ``fp32``: one binary32 per scalar (screening)
      - ``dd32``: two binary32 values per scalar in the device kernel (experimental
        double-single / FP32x2 arithmetic; not IEEE binary64)
      - ``fp64``: native device binary64, only when the device advertises fp64
      - ``auto``/None: preserve legacy behavior (native fp64 when available,
        otherwise fp32 only when explicitly allowed).
    """
    p64=np.ascontiguousarray(points,dtype=np.float64);q64=np.ascontiguousarray(queries,dtype=np.float64)
    if p64.ndim!=2 or p64.shape[1]!=3 or q64.ndim!=2 or q64.shape[1]!=3: raise ValueError('points/queries must be Nx3')
    proc=_start();info=worker_info()
    mode=(numeric_mode or os.environ.get('SST_SYCL_NUMERIC_MODE') or 'auto').strip().lower()
    if mode in ('double-double','double_single','double-single','fp32x2','ds32'): mode='dd32'
    if mode not in ('auto','fp32','dd32','fp64'): raise ValueError(f'unknown SYCL numeric mode: {mode}')
    native64=bool(info.get('fp64',False))
    if require_fp64: mode='fp64'
    if mode=='auto':
        mode='fp64' if native64 else 'fp32'
    if mode=='fp64' and not native64:
        raise RuntimeError(f"SYCL device {info.get('device_name')} has no native FP64")
    if mode=='fp32' and not native64 and os.environ.get('SST_SYCL_ALLOW_FP32','0')!='1':
        raise RuntimeError('SYCL device has no native FP64. Set SST_SYCL_ALLOW_FP32=1 only for explicitly labeled screening runs.')
    if mode=='dd32' and not bool(info.get('dd32',True)):
        raise RuntimeError('SYCL worker does not advertise DD32 support')

    if mode=='fp64':
        pp=np.ascontiguousarray(p64,dtype=np.float64);qq=np.ascontiguousarray(q64,dtype=np.float64);cmd=CMD_F64;response_dtype=np.float64;label='sycl-worker-fp64'
    elif mode=='dd32':
        # DD32 input transport remains FP64 so the worker can split each host
        # scalar into hi+lo binary32 without losing the low component first.
        pp=p64;qq=q64;cmd=CMD_DD32;response_dtype=np.float64;label='sycl-worker-dd32'
    else:
        pp=np.ascontiguousarray(p64,dtype=np.float32);qq=np.ascontiguousarray(q64,dtype=np.float32);cmd=CMD_F32;response_dtype=np.float32;label='sycl-worker-fp32'

    hdr=struct.pack('<IIQQdd',MAGIC_REQ,cmd,pp.shape[0],qq.shape[0],float(gamma),float(core))
    with _LOCK:
        if proc.stdin is None or proc.stdout is None: raise RuntimeError('worker pipes unavailable')
        proc.stdin.write(hdr);proc.stdin.write(pp.tobytes(order='C'));proc.stdin.write(qq.tobytes(order='C'));proc.stdin.flush()
        rh=_read_exact(proc.stdout,16);magic,status,nbytes=struct.unpack('<IIQ',rh)
        if magic!=MAGIC_RES: raise RuntimeError('bad worker response magic')
        payload=_read_exact(proc.stdout,nbytes)
        if status!=0: raise RuntimeError(payload.decode('utf-8','replace'))
    arr=np.frombuffer(payload,dtype=response_dtype).reshape((-1,3)).astype(np.float64,copy=False)
    return arr,label
