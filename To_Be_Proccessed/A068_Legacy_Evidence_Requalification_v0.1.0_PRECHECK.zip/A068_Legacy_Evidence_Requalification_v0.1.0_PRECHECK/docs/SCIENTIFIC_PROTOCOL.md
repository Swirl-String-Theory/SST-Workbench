# A068 — Prospective scientific falsifier and migration contract (v0.1.0)

## Exact question

Which previously reported scientific claims remain supported under modern SST-Workbench *claim-dependent* provenance, geometry, finite-core, dynamics, numerics and blinded replication requirements? Can the same historical code, in an **additive** framework v1.0.7 instance, reproduce its historical limited results without inadvertently upgrading evidentiary authority?

## H0 / H1

H0: A given **claim**, not necessarily its entire historical family, lacks the specified current evidence qualification, or fails at least one relevant originally frozen criterion. Framework migration alone cannot reject H0.

H1 (engineering): historical deterministic outputs and existing negative statuses reproduce under the unchanged frozen v1.0.7 instance within committed tolerances. H1 supports reproducibility only.

H1 (scientific, separate): a prospectively committed source-native knot/field claim passes all *applicable* independent provider, geometry, finite-core, dynamical, blind and physical comparison gates; successful analytic controls are insufficient.

## Invariants

- Original family/version contents and result archives immutable; original commitments and FAIL states retain authoritative history.
- Registry numbering and old aliases must be reconciled; A045 = two-harmonic phase-chirality Floquet; A046 = relative-vorticity triadic geometry. A059 appears in two direct directories and needs distinct identity assessment.
- Framework v1.0.7 `CANONICAL_FROZEN` 56 selftests is a separate baseline; historical original framework versions stay pinned. A060 v0.3.0 remains independent.
- No source independence inferred from knot discretization, copying, resampling, smoothing, or two files from the same ancestral provider.
- Core geometry is distinct from finite core; static centerline is distinct from time-evolved vorticity. Stationarity is not inferred from snapshot finiteness; Floquet multipliers require qualified recurrent dynamics.
- `reach` is estimator-dependent: distinguish certified geometry from approximated lower bounds; propagate interval uncertainty to `a_core/reach` and collisions.
- Do not make every old non-knot falsifier fail for lacking knot data. Map gates from the specific scientific claim and its actual inputs.

## Mandatory machine-readable records per claim (prospective phase)

`family_id`, `family_folder`, `version`, `claim_id`, `claim_text`, `claim_kind`, `dependency_gate_ids`, `original_verdict`, `original_output_sha256`, `framework_original`, `framework_migrated`, `upstream_source_hashes`, `independence_groups`, `geometry_resolution_ladder`, `core_profile`, `circulation`, `dynamics_provider`, `numerical_backends`, `discovery_commitment`, `confirmation_commitment`, `requalification_verdict`, `limitations`, `reviewer`.

Missing records produce `UNRESOLVED`, never automatic `FAIL` or `PASS`. A failed original physical gate may remain `FAIL` while independent diagnostic branches run.

## Gate sequence (prospective)

| Gate | Pass test | Failure meaning |
|:--|:--|:--|
| G0 identity | 1:1 authoritative family UUID, versions and aliases | naming/provenance ambiguity; block downstream |
| G1 archive | original file/result hashes, original verdicts pinned | lost or changed historical evidence |
| G2 applicability | claim-to-gate dependency specified before review | unauthorized physical promotion |
| G3 PKLSA | independently pinned E010/E011/E013 raw geometry; topology, isotopy proxy, robust reach, chirality, convergence | non-admissible geometrical carrier |
| G4 finite-core | declared physical scale, core profile, circulation; `a_core/reach` resolved incl. uncertainty | insufficient core contract |
| G5 dynamics | exact solver/randvoorwaarden, equilibrium or RPO proof as needed, independent temporal/spatial convergence | unqualified dynamical claim |
| G6 blind / provider | ≥2 real upstream groups where replication claimed; sealed prospective confirmation | no independently supported replication |
| G7 target | no fitted target leakage; archived negative controls preserved; independent experimental data where physical claim made | failed specific physical hypothesis |
| G8 release | cross-validated claim-level ledger and PDF, no upgraded physical verdict without G3–G7 | only diagnostic release |

G3–G5 are NOT_APPLICABLE for genuinely unrelated analytic controls. None is automatically made PASS by the inventory stage. G6 is NOT_APPLICABLE when independent source replication is not claimed, but no general physical claim may be promoted from a single surrogate.

## Priority migration tranche

1. A008 frozen-geometry modes, A021 trefoil self-confinement, A023/A031 RPO and Floquet, A038 seed qualification: inspect their *original* specific claims and versioned provider data; do **not** change old experiments.
2. A010 alpha-blind RPO; retain recorded H10/H11 FAIL; separate alpha benchmark from target-free orbital work.
3. A016 current E011-dependent transport and A057 mass H10/G22 failure; audit claim-dependence of providers and state-selection.
4. A001 older Route-A analytic failure as important counterexample: outside PKLSA, keep original negative result and rerun only framework/provenance controls.
5. A062 v0.1.0 pressure/mass negative vs v0.6.0 explicitly postulated Green-law screen: retain separateness.
6. A045/A046 and A059 aliases: identity reconciliation independent of science reruns.

## Future framework instance

Generate *new* official A068-v0.2.0 from the exact validated framework v1.0.7 source, after catalog ID resolution. Do not copy v1.0.8 candidate in place. Before FREEZE require full claimed geometry/provider population and lineage. Then SELFTEST → FREEZE → BASIC → FULL → CERTIFY → explicit independent REVEAL. Failing physical gates do not suppress independent diagnostic gates.

## Scope of current release

The included scanner and static report are PRECHECK only, NOT an executed scientific falsifier. No full source tree or physical solver was available locally here, so the 66 families have not been evaluated at claim level. This boundary is deliberate.
