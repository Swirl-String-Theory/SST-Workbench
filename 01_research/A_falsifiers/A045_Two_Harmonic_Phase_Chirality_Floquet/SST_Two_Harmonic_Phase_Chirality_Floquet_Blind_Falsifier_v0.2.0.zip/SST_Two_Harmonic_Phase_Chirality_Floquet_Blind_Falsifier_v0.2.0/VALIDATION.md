# Validation status — v0.2.0

Required before promotion:

- [x] Python unit tests.
- [x] Python smoke campaign on one frozen A038 seed.
- [x] Frozen input SHA-256 gate.
- [x] Blind source leakage audit.
- [ ] Native C++17/pybind11 + OpenMP build on MSVC.
- [ ] Python/native parity campaign.
- [ ] Basic four-seed campaign.
- [ ] Extended finite-core ladder campaign.
- [ ] PKLSA exported centerline added as an independent geometry arm.
- [ ] Certified RPO supplied upstream before any Floquet multipliers are evaluated.
