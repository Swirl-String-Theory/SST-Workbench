# 0.1.1

- Fix one-click wrapper: no longer hard-requires pre-existing `qhp_metadata.csv` when strict filename inference is possible.
- Add `metadata-bootstrap`: auto-promotes only complete explicit q/h/p filename tokens; never invents coordinates from file order.
- If inference is incomplete, automatically writes `qhp_metadata_template.csv` and exits before physics with code 2.
- Fix signed filename parsing: tokens such as `h-0p2` retain the negative sign; filename-safe `m` sign is supported.
- Preserve MSVC-safe `py::ssize_t` native kernel and all v0.1.0 physics/gates.

# Changelog

## 0.1.0 — 2026-08-27
- Initial blind QHP Stability Landscape release.
- QHP-manifold tangent projection of normal finite-core Biot--Savart velocity.
- One-dimensional zero-crossing/restoring-slope gates.
- Three-dimensional local Jacobian/eigenvalue stability gate where a complete local QHP stencil exists.
- Independent short-time RK4 drift confirmation.
- N=64/96/128 resolution ladder.
- Metadata-template generator for existing KnotPlot sweep exports.
- C++17/pybind11/OpenMP backend.
- Explicit Windows/MSVC guard: `py::ssize_t`, no global `ssize_t`.
