"""H0-H12 blind falsification gates for the coupled Kelvin/Floquet route.

This module contains no alpha benchmark value and never imports benchmark.py.
"""
from __future__ import annotations
import math
from pathlib import Path
from typing import Any
import numpy as np

from .core import DEFAULT_DATA, prepare_centerline, write_csv, write_json
from .dynamics import (compute_dynamic_blind, pair_rhs, projected_kelvin_analysis_fixed,
                       turn_wrap)
from .backend import load_backend
from .geometry import (bishop_frame, make_counter_channels, rigid_rotation_matrix,
                       rigid_transform)
from .holonomy import director_holonomy
from .topology import topology_observables

ROOT = Path(__file__).resolve().parents[1]


def _gate(name: str, passed: bool, value: Any, criterion: str, note: str = "") -> dict[str, Any]:
    return {"gate": name, "pass": bool(passed), "value": value, "criterion": criterion, "note": note}


def _complex_distance_turns(a: float, b: float) -> float:
    return abs(turn_wrap(float(a)-float(b)))


def _max_circular_spread(values: list[float]) -> float:
    if len(values)<2: return 0.0
    return max(_complex_distance_turns(a,b) for i,a in enumerate(values) for b in values[i+1:])


def _v02_clockfree_control(center: np.ndarray, D: float, *, force_python: bool=False) -> dict[str, float]:
    p,m,t,n=make_counter_channels(center,.5*D)
    backend,_=load_backend(force_python=force_python,skip_build=True)
    eps=.05*D
    up=np.asarray(backend.induced_velocity(p,m,-1.0,eps),dtype=float)
    um=np.asarray(backend.induced_velocity(m,p,1.0,eps),dtype=float)
    hd=director_holonomy(up-um,t)
    topo=topology_observables(center,p,m,force_python=force_python)
    return {"director_principal_turns":float(hd["turns_principal"]),
            "gauss_linking":float(topo["gauss_linking"]),
            "writhe":float(topo["writhe"]),
            "twist":float(topo["ribbon_twist_from_Lk_minus_Wr"])}


def run_blind_gates(*, out_dir: str|Path="audit_out_blind", data_path: str|Path=DEFAULT_DATA,
                    force_python: bool=False, force_build: bool=False,
                    build_verbose: bool=False, quick: bool=False) -> dict[str, Any]:
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    gates=[]

    # H0: strict source separation. Benchmark literals/functions may exist only in benchmark.py/run_benchmark.py.
    blind_files=[ROOT/"sst_counterpulley"/"dynamics.py", ROOT/"sst_counterpulley"/"blind_gates.py",
                 ROOT/"sst_counterpulley"/"physics.py", ROOT/"sst_counterpulley"/"holonomy.py"]
    bad=[]
    for f in blind_files:
        txt=f.read_text(encoding="utf-8")
        forbidden_numeric = "137" + ".035"
        forbidden_symbol = "ALPHA_INV_" + "BENCHMARK"
        if forbidden_numeric in txt or forbidden_symbol in txt:
            bad.append(str(f.relative_to(ROOT)))
    gates.append(_gate("H0_alpha_blinding",not bad,{"forbidden_hits":bad},
                       "no alpha benchmark literal/symbol in blind solver/gate modules"))

    # H1: native/Python parity on the actual two-filament temporal ODE and projected phase.
    c1,m1=prepare_centerline(data_path=data_path,n=24); D1=float(m1["D_metadata"])
    p1,q1,_,_=make_counter_channels(c1,.5*D1)
    cpp,cpp_name=load_backend(force_python=False,skip_build=not force_build,force_build=force_build,build_verbose=build_verbose)
    py,_=load_backend(force_python=True,skip_build=True)
    rhs_cpp=pair_rhs(p1,q1,1.0,-1.0,.05*D1,backend=cpp)
    rhs_py=pair_rhs(p1,q1,1.0,-1.0,.05*D1,backend=py)
    rhs_rel=float(np.linalg.norm(rhs_cpp-rhs_py)/max(np.linalg.norm(rhs_py),1e-30))
    dcpp=compute_dynamic_blind(c1,D=D1,force_python=False,skip_build=True)
    dpy=compute_dynamic_blind(c1,D=D1,force_python=True,skip_build=True)
    phase_parity=_complex_distance_turns(dcpp.floquet_phase_signed_turns,dpy.floquet_phase_signed_turns)
    h1=(cpp_name=="cpp" and rhs_rel<1e-11 and phase_parity<1e-8) if not force_python else (rhs_rel<1e-11 and phase_parity<1e-8)
    gates.append(_gate("H1_native_python_parity",h1,{"backend":cpp_name,"rhs_rel_l2":rhs_rel,"phase_turn_error":phase_parity},
                       "native/Python RHS rel error <1e-11 and projected phase error <1e-8 turns"))

    canonical_n=256 if quick else 2048
    center,meta=prepare_centerline(data_path=data_path,n=canonical_n); D=float(meta["D_metadata"])
    base=compute_dynamic_blind(center,D=D,force_python=force_python,skip_build=not force_build,
                               force_build=force_build,build_verbose=build_verbose)
    blind_payload={"protocol":"BLIND_TEMPORAL_BIOT_SAVART_KELVIN_FLOQUET_NO_ALPHA_INPUT",
                   "geometry":meta,"canonical":base.to_dict()}
    write_json(out/"blind_canonical.json",blind_payload)

    # H2: data/subspace correctness and algebraic multiplier consistency.
    h2=(meta["knot_id"]=="3:1:1" and abs(float(meta["L_metadata"])-16.371637)<1e-10 and
        abs(float(meta["D_metadata"])-1.0)<1e-12 and base.gram_error_fro<1e-12 and
        base.phase_internal_consistency_turns<1e-12)
    gates.append(_gate("H2_geometry_subspace_consistency",h2,
                       {"knot_id":meta["knot_id"],"L_metadata":meta["L_metadata"],"D_metadata":meta["D_metadata"],
                        "gram_error_fro":base.gram_error_fro,"phase_internal_error_turns":base.phase_internal_consistency_turns},
                       "3:1:1 metadata exact; Kelvin basis orthonormal; eigenphase/multiplier definitions agree"))

    # H3: hard Floquet eligibility: frozen geometry must be a relative equilibrium to justify exp(A T).
    rel_thresh=.25 if quick else .15
    h3=base.relative_equilibrium_residual<rel_thresh
    gates.append(_gate("H3_relative_equilibrium_eligibility",h3,base.relative_equilibrium_residual,
                       f"best rigid-motion residual / total velocity RMS < {rel_thresh}",
                       "FAIL means the frozen Jacobian is only an instantaneous local spectrum, not a true global Floquet monodromy."))

    # H4: strict Euclidean invariance using the same physical channels transformed rigidly.
    n4=192 if quick else 384
    c4,_=prepare_centerline(data_path=data_path,n=n4); p4,m4,_,_=make_counter_channels(c4,.5*D); _,nvec,bvec=bishop_frame(c4)
    a4=projected_kelvin_analysis_fixed(c4,p4,m4,nvec,bvec,D=D,force_python=force_python,skip_build=True)
    R=rigid_rotation_matrix(); ct=rigid_transform(c4); pt=rigid_transform(p4); mt=rigid_transform(m4)
    z4=projected_kelvin_analysis_fixed(ct,pt,mt,nvec@R.T,bvec@R.T,D=D,force_python=force_python,skip_build=True)
    rigid_phase=_complex_distance_turns(a4["floquet_phase_signed_turns"],z4["floquet_phase_signed_turns"])
    rigid_wp=abs(a4["omega_positive_hat"]-z4["omega_positive_hat"]); rigid_wm=abs(a4["omega_negative_abs_hat"]-z4["omega_negative_abs_hat"])
    h4=rigid_phase<2e-7 and rigid_wp<2e-6 and rigid_wm<2e-6
    gates.append(_gate("H4_euclidean_invariance",h4,{"phase_turn_error":rigid_phase,"omega_plus_hat_error":rigid_wp,"omega_minus_hat_error":rigid_wm},
                       "fixed physical channels invariant under rigid translation+rotation"))

    # H5: uniform scale collapse in dimensionless temporal spectrum.
    n5=192 if quick else 384; c5,_=prepare_centerline(data_path=data_path,n=n5)
    a5=compute_dynamic_blind(c5,D=D,force_python=force_python,skip_build=True)
    scale=2.731
    z5=compute_dynamic_blind(c5*scale,D=D*scale,force_python=force_python,skip_build=True)
    e5={"phase_turn_error":_complex_distance_turns(a5.floquet_phase_signed_turns,z5.floquet_phase_signed_turns),
        "omega_plus_hat_error":abs(a5.omega_positive_hat-z5.omega_positive_hat),
        "omega_minus_hat_error":abs(a5.omega_negative_abs_hat-z5.omega_negative_abs_hat)}
    h5=e5["phase_turn_error"]<2e-7 and e5["omega_plus_hat_error"]<2e-6 and e5["omega_minus_hat_error"]<2e-6
    gates.append(_gate("H5_scale_collapse",h5,e5,"dimensionless spectrum invariant under x,D -> lambda x,lambda D"))

    # H6: basis-gauge invariance (physical channels fixed; only transverse coordinate basis rotates).
    phases=[0.0,.37,1.1,2.2]; grows=[]
    for ph in phases:
        r=compute_dynamic_blind(c5,D=D,basis_phase=ph,force_python=force_python,skip_build=True)
        grows.append({"basis_phase_rad":ph,"phase_turns":r.floquet_phase_signed_turns,"omega_plus_hat":r.omega_positive_hat,"omega_minus_hat":r.omega_negative_abs_hat})
    gspread=_max_circular_spread([r["phase_turns"] for r in grows])
    wps=max(r["omega_plus_hat"] for r in grows)-min(r["omega_plus_hat"] for r in grows)
    wms=max(r["omega_minus_hat"] for r in grows)-min(r["omega_minus_hat"] for r in grows)
    h6=gspread<2e-7 and wps<2e-6 and wms<2e-6
    gates.append(_gate("H6_transverse_basis_gauge_invariance",h6,{"phase_spread_turns":gspread,"omega_plus_spread":wps,"omega_minus_spread":wms},
                       "constant normal-basis gauge rotation leaves Floquet spectrum unchanged"))
    write_csv(out/"basis_gauge_sweep.csv",grows)

    # H7: global circulation reversal. Raw signed phase must reverse; scalar defect stays invariant.
    rev=compute_dynamic_blind(c5,D=D,gamma_plus=-1.0,gamma_minus=1.0,force_python=force_python,skip_build=True)
    sign_err=abs(turn_wrap(a5.floquet_phase_signed_turns+rev.floquet_phase_signed_turns))
    scalar_err=abs(a5.floquet_phase_scalar_defect_turns-rev.floquet_phase_scalar_defect_turns)
    swap_wp=abs(a5.omega_positive_hat-rev.omega_negative_abs_hat); swap_wm=abs(a5.omega_negative_abs_hat-rev.omega_positive_hat)
    h7=sign_err<2e-7 and scalar_err<2e-7 and swap_wp<2e-6 and swap_wm<2e-6
    gates.append(_gate("H7_circulation_reversal_covariance",h7,{"signed_phase_antisymmetry_error":sign_err,"scalar_defect_error":scalar_err,"frequency_swap_errors":[swap_wp,swap_wm]},
                       "Gamma->-Gamma swaps counter-propagating modes and reverses signed phase"))

    # H8: finite-difference derivative stability.
    fdvals=[5e-6,1e-5,2e-5,5e-5,1e-4]; fdrows=[]
    for h in fdvals:
        r=compute_dynamic_blind(c5,D=D,fd_step_over_D=h,force_python=force_python,skip_build=True)
        fdrows.append({"fd_step_over_D":h,"phase_turns":r.floquet_phase_signed_turns,"omega_plus_hat":r.omega_positive_hat,"omega_minus_hat":r.omega_negative_abs_hat})
    fdspread=_max_circular_spread([r["phase_turns"] for r in fdrows])
    h8=fdspread<(5e-5 if quick else 1e-5)
    gates.append(_gate("H8_finite_difference_stability",h8,{"phase_spread_turns":fdspread},
                       "phase stable across predeclared central-difference steps"))
    write_csv(out/"finite_difference_sweep.csv",fdrows)

    # H9: resolution convergence; benchmark remains closed during this ladder.
    Ns=[64,96,128,192,256] if quick else [256,384,512,768,1024,1536,2048]
    conv=[]
    for nn in Ns:
        cc,_=prepare_centerline(data_path=data_path,n=nn)
        r=compute_dynamic_blind(cc,D=D,force_python=force_python,skip_build=True)
        conv.append({"n":nn,"phase_turns":r.floquet_phase_signed_turns,"scalar_defect_turns":r.floquet_phase_scalar_defect_turns,
                     "omega_plus_hat":r.omega_positive_hat,"omega_minus_hat":r.omega_negative_abs_hat,
                     "quality_plus":r.positive_quality_re_over_im,"quality_minus":r.negative_quality_re_over_im,
                     "relative_equilibrium_residual":r.relative_equilibrium_residual})
    tail=conv[-1]; prev=conv[-2]
    dphase=_complex_distance_turns(tail["phase_turns"],prev["phase_turns"])
    dwp=abs(tail["omega_plus_hat"]-prev["omega_plus_hat"]); dwm=abs(tail["omega_minus_hat"]-prev["omega_minus_hat"])
    thp=.15 if quick else .005; thw=.4 if quick else .03
    h9=dphase<thp and dwp<thw and dwm<thw
    gates.append(_gate("H9_resolution_convergence",h9,{"tail_phase_turns":dphase,"tail_omega_plus":dwp,"tail_omega_minus":dwm,"last_n":tail["n"]},
                       f"tail phase <{thp} turns and normalized frequency changes <{thw}"))
    write_csv(out/"resolution_convergence.csv",conv)

    # H10: nuisance robustness: core regularisation and physical channel cross-section phase.
    n10=256 if quick else 512; c10,_=prepare_centerline(data_path=data_path,n=n10)
    epsvals=[.025,.05,.10,.20]; erows=[]
    for e in epsvals:
        r=compute_dynamic_blind(c10,D=D,eps_over_D=e,force_python=force_python,skip_build=True)
        erows.append({"eps_over_D":e,"phase_turns":r.floquet_phase_signed_turns,"quality_plus":r.positive_quality_re_over_im,"quality_minus":r.negative_quality_re_over_im})
    cpvals=[0.0,math.pi/4,math.pi/2,3*math.pi/4]; cprows=[]
    for ph in cpvals:
        r=compute_dynamic_blind(c10,D=D,channel_phase=ph,force_python=force_python,skip_build=True)
        cprows.append({"channel_phase_rad":ph,"phase_turns":r.floquet_phase_signed_turns,"relative_equilibrium_residual":r.relative_equilibrium_residual})
    espread=_max_circular_spread([r["phase_turns"] for r in erows]); cpspread=_max_circular_spread([r["phase_turns"] for r in cprows])
    h10=espread<.05 and cpspread<.05
    gates.append(_gate("H10_physical_nuisance_robustness",h10,{"regularization_phase_spread_turns":espread,"channel_orientation_phase_spread_turns":cpspread},
                       "phase spread <0.05 turns under predeclared eps/D and physical cross-section orientation sweeps"))
    write_csv(out/"regularization_sweep.csv",erows); write_csv(out/"channel_phase_sweep.csv",cprows)

    # H11: both selected counter-propagating modes should be predominantly oscillatory.
    qth=.35 if quick else .10
    h11=base.positive_quality_re_over_im<qth and base.negative_quality_re_over_im<qth
    gates.append(_gate("H11_counterpropagating_mode_quality",h11,
                       {"abs_Re_over_abs_Im_positive":base.positive_quality_re_over_im,"abs_Re_over_abs_Im_negative":base.negative_quality_re_over_im,
                        "mu_positive_log_abs":base.mu_positive_log_abs,"mu_negative_log_abs":base.mu_negative_log_abs},
                       f"both |Re lambda|/|Im lambda| < {qth}",
                       "Large growth/decay per eigen-clock period means the phase is not a clean Kelvin clock."))

    # H12: unlike v0.2 pure holonomy, the new temporal eigenphase must not collapse to Tw.
    n12=256 if quick else 1024; c12,_=prepare_centerline(data_path=data_path,n=n12)
    d12=compute_dynamic_blind(c12,D=D,force_python=force_python,skip_build=True)
    ctrl=_v02_clockfree_control(c12,D,force_python=force_python)
    d_tw=_complex_distance_turns(d12.floquet_phase_signed_turns,ctrl["twist"])
    d_dir=_complex_distance_turns(d12.floquet_phase_signed_turns,ctrl["director_principal_turns"])
    h12=d_tw>.05 and d_dir>.05
    gates.append(_gate("H12_dynamic_phase_not_topological_collapse",h12,
                       {"dynamic_phase_turns":d12.floquet_phase_signed_turns,"v0.2_director_turns":ctrl["director_principal_turns"],
                        "Tw":ctrl["twist"],"distance_to_Tw_mod1":d_tw,"distance_to_director_mod1":d_dir,
                        "Lk":ctrl["gauss_linking"],"Wr":ctrl["writhe"]},
                       "dynamic eigenphase differs by >0.05 turns from both Tw and v0.2 clock-free director holonomy"))

    numerical_core=all(g["pass"] for g in gates[:3]) and all(g["pass"] for g in gates[3:])
    if not gates[0]["pass"] or not gates[1]["pass"] or not gates[2]["pass"]:
        verdict="INCONCLUSIVE_IMPLEMENTATION_OR_NUMERICS"
    elif not gates[3]["pass"]:
        verdict="NO_RELATIVE_EQUILIBRIUM__FROZEN_SPECTRUM_ONLY"
    elif not gates[9]["pass"] or not gates[10]["pass"] or not gates[11]["pass"]:
        verdict="DYNAMIC_CLOCK_NOT_ROBUST_ENOUGH_FOR_UNBLINDING_CLAIM"
    elif gates[12]["pass"]:
        verdict="SURVIVES_BLIND_DYNAMIC_PHASE_GATES__READY_FOR_POSTHOC_BENCHMARK"
    else:
        verdict="DYNAMIC_PHASE_COLLAPSES_OR_IS_UNSUPPORTED"
    summary={"audit_name":"SST counter-pulley coupled Kelvin/Floquet blind falsifier v0.3.0",
             "protocol":"ALPHA_CLOSED_DURING_H0_H12","quick":bool(quick),"verdict":verdict,
             "canonical_n":canonical_n,"canonical_blind":blind_payload,"gates":gates,"resolution_ladder":conv}
    write_json(out/"blind_audit_summary.json",summary)
    return summary
