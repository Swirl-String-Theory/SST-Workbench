# Bibliography v0.0.5

```latex
\begin{thebibliography}{9}

\bibitem{EisertCramerPlenio2010}
J.~Eisert, M.~Cramer, and M.~B.~Plenio,
\newblock Area laws for the entanglement entropy,
\newblock \emph{Reviews of Modern Physics} \textbf{82}, 277--306 (2010).
\newblock doi:10.1103/RevModPhys.82.277.

\bibitem{ErnstSumners1987}
C.~Ernst and D.~W.~Sumners,
\newblock The growth of the number of prime knots,
\newblock \emph{Mathematical Proceedings of the Cambridge Philosophical Society}
\textbf{102}, 303--315 (1987).
\newblock doi:10.1017/S0305004100067323.

\bibitem{BuckSimon1999}
G.~Buck and J.~Simon,
\newblock Thickness and crossing number of knots,
\newblock \emph{Topology and its Applications} \textbf{91}, 245--257 (1999).
\newblock doi:10.1016/S0166-8641(97)00211-3.

\bibitem{Weyl1912}
H.~Weyl,
\newblock Das asymptotische Verteilungsgesetz der Eigenwerte linearer partieller Differentialgleichungen,
\newblock \emph{Mathematische Annalen} \textbf{71}, 441--479 (1912).
\newblock doi:10.1007/BF01456804.

\end{thebibliography}
```
