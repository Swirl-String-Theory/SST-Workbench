# A006 v0.5.0e — Diagnostiek van een systematische KnotPlot-sluitingsfout

**Status: DIAGNOSTIEK; geen geometrische reparatie; niet productiegekwalificeerd.** Het oorspronkelijke A006-v0.5.0 en de v0.5.0d-patch blijven ongemoeid.

## Vastgestelde feiten

De zes door de gebruiker aangeleverde `KNOT_*_ORIG.xyz`-bestanden zijn SHA-256-identiek aan de gelijknamige XYZ-bestanden in v0.5.0d. In de numeriek geconstrueerde gesloten polygonen lopen de bovenste trajecten door de plek waar de KnotPlot-screenshots een opening tonen. De numerieke resultaten gelden voor de bestanden vóór het laden en zijn geen bewijs dat KnotPlot deze segmenten werkelijk tekent.

Deze pakketcontrole omvat **48 varianten** (6 knopen × 4 resoluties × origineel/spiegelbeeld): 36 geometriekandidaten en 12 N256-gevallen die in quarantaine blijven. Alle 48 hebben vier bovenliggende passages over `x = 0` en een reguliere cyclische segmentverbinding. De KPT-exports bevatten dezelfde coördinaten en expliciet één gesloten component (`Attr=1`), met exacte binaire terugleescontrole. **KnotPlot zelf kon hier niet worden uitgevoerd.**

## Reproductie in KnotPlot op Windows

1. Pak de ZIP uit en kies de uitgepakte projecthoofdmap als werkmap van KnotPlot (of vervang relatieve paden in de scripts door absolute paden).
2. Laad `KPS/<naam>_XYZ_VS_KPT.kps`. Dit toont eerst de ongewijzigde XYZ-export, zonder `go` of `ago`. Bewaar een screenshot en de uitvoer van `information` en `close`.
3. Laad de bijbehorende `KPS/<naam>_FORCED_CLOSED.kps`. Dit laadt een KPT met exact dezelfde XYZ-punten, geeft `close all` en toont opnieuw `information` en `close`.
4. Als alleen XYZ een opening heeft, wijst dat op de XYZ-import of de gesloten-componentstatus. Als ook de KPT met `close all` een opening toont, terwijl de onafhankelijke grafiek doorloopt, onderzoek dan de renderer, de huidige KnotPlot-instellingen en de coördinaten ná import. Als de opening pas na `ago` ontstaat, onderzoek dan de dynamica in plaats van de generator.

`close = 0.20` in `knotplotrc.kps` is **geen sluitingsopdracht**: het is de minimale benaderingsafstand voor de relaxatiedynamica. De expliciete opdracht voor het sluiten is `close all`.

## Stopcriteria

- v0.5.0d visuele acceptatie: **FAIL**, bevestigd door de screenshots.
- Numerieke bestandssluiting: gecontroleerd, maar onvoldoende voor de productieacceptatie.
- KnotPlot-runtime en getekende verbindingen: **NOT TESTED** in dit pakket.
- N256: in quarantaine houden.
- Geen toepassing op fysische dynamica, Biot–Savart, ropelength, Euler of PKLSA zolang de runtime-gate niet slaagt.
- Knoopidentiteit vraagt meer dan alleen een Alexander-polynoom en determinant.

## Referenties

KnotPlot manual, file format and command documentation: https://knotplot.com/manual/FileFormats.html ; https://knotplot.com/manual/commands.html ; https://knotplot.com/manual/parameters.html
