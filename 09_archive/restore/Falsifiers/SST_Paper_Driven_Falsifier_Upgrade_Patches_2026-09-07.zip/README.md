# SST paper-driven patch bundle

This bundle contains additive `.diff` patches derived from the two paper-inspired upgrade lines discussed on 2026-09-07. The source family/version folders were grounded against the canonical migrated Google Drive Workbench tree before generation.

## Apply model

Each diff is applied **inside the listed base version source directory** (or to a clean copy used to create the target version):

```bat
git apply --check <patch.diff>
git apply <patch.diff>
run_paper_upgrade.cmd
```

The patches intentionally add isolated stages instead of overwriting existing solver files. After a stage is accepted, wire it into the family run chain and bump the package/release metadata as part of the full target release. This preserves hotfixes/revisions such as A035 `v0.2.2-r8` and A008 `v0.1.3-r1`.

## Recommended dependency order

1. D006 shared numerical harness
2. C006 shared Kelvin/Floquet operators
3. A037 symmetry-selection
4. A034 constrained admissibility
5. A029 finite-core mode parity
6. A030 geometric phase/curvature
7. A023 + A031 true Floquet parity
8. A035 + A008 modal symmetry/soft modes
9. A038 certificate orchestration
10. A021 certificate consumer
11. optional A024/A025/A016 controls
12. only after A030 certification: A036/A039/A040 migration guards can be promoted into real releases

See `PATCH_MANIFEST.json` for exact Drive base-folder IDs and SHA-256 hashes.
