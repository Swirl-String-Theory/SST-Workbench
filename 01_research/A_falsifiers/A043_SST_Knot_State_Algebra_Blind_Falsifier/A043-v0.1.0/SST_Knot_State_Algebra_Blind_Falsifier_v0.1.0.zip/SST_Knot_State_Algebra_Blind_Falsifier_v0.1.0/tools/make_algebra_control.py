from pathlib import Path
import numpy as np
# Analytic SO(3) software control ONLY. It is not a physical SST provider and intentionally returns after 2π.
G=np.zeros((3,3,3));
G[0]=[[0,0,0],[0,0,-1],[0,1,0]];G[1]=[[0,0,1],[0,0,0],[-1,0,0]];G[2]=[[0,-1,0],[1,0,0],[0,0,0]]
a=np.array([0,2*np.pi,4*np.pi]);ov=np.array([1,1,1],complex)
Path("demo_data").mkdir(exist_ok=True);np.savez("demo_data/analytic_so3_control.npz",generators=G,angles=a,state_overlap=ov)
print("demo_data/analytic_so3_control.npz")
