# A060 v0.2.0 / v1.0.7 integration candidate

DEVELOPMENT / NOT CERTIFIED. Extract into a new isolated review directory. DO NOT merge over existing SST-Workbench folders: historical v0.2.0/v0.2.1/v0.3.0 and v0.1.0 remain unchanged.

Contains the byte-verified v1.0.7 source, generated candidate instance, four SHA-matched papers, contracts, executable reference/native engineering checks and PDF report. No official FREEZE or scientific run occurred. Private candidate keys and payloads are deliberately omitted; prospective setup remains UNRESOLVED.
