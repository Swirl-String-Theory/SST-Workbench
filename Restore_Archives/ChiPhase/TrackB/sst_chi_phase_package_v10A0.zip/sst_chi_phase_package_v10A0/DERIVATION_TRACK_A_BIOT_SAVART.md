# Derivation note: Track A ring-alpha extraction

## 1. Ring energy convention

The vortex-ring energy is written in the conventional logarithmic form

\[
E(R,a)
=
\frac12 \rho \Gamma^2 R
\left[
\ln\left(\frac{8R}{a}\right)-\alpha
\right].
\]

Therefore

\[
\alpha_{\rm eff}(R/a)
=
\ln\left(\frac{8R}{a}\right)
-
\frac{2E(R,a)}{\rho\Gamma^2R}.
\]

The desired ring-core constant is the thin-ring limit

\[
\alpha
=
\lim_{a/R\to0}\alpha_{\rm eff}(R/a).
\]

## 2. Vorticity energy

For incompressible Euler flow in unbounded space,

\[
E
=
\frac{\rho}{2}\int |\mathbf v|^2\,d^3x
=
\frac{\rho}{8\pi}
\int\!\!\int
\frac{
\boldsymbol\omega(\mathbf x)\cdot\boldsymbol\omega(\mathbf x')
}{
|\mathbf x-\mathbf x'|
}
\,d^3x\,d^3x'.
\]

This is the Track A quantity. It contains no NLSE/GP gradient or density-depletion energy.

## 3. Toroidal geometry

Use a torus with major radius \(R\), minor radius \(a\), local cross-section radius \(r=ax\), and angles \(\theta,\phi\):

\[
\mathbf X(r,\theta,\phi)
=
\bigl((R+r\cos\theta)\cos\phi,\,
      (R+r\cos\theta)\sin\phi,\,
       r\sin\theta\bigr).
\]

The volume element is

\[
dV=(R+r\cos\theta)\,r\,dr\,d\theta\,d\phi.
\]

The vorticity is taken along the toroidal direction \(\hat{\boldsymbol\phi}\).

## 4. Cross-section swirl profile

Let the local tangential profile be

\[
v_\theta(r)=v_{\rm ref} f(x),
\qquad x=\frac{r}{a}.
\]

The corresponding tube vorticity magnitude is

\[
\omega_\phi(r)
=
\frac1r\frac{d}{dr}\left(r v_\theta(r)\right)
=
\frac{v_{\rm ref}}{a}
\left[
f'(x)+\frac{f(x)}{x}
\right].
\]

Boundary normalization \(f(1)=1\) gives

\[
\Gamma=2\pi a\,v_\theta(a)=2\pi a\,v_{\rm ref}.
\]

In the code the default is \(\Gamma=1\), so

\[
v_{\rm ref}=\frac{1}{2\pi a}.
\]

## 5. Axisymmetry reduction

Because the integrand depends on the toroidal angles only through
\(\delta=\phi'-\phi\),

\[
\int_0^{2\pi}\!\!\int_0^{2\pi}F(\phi'-\phi)\,d\phi\,d\phi'
=
2\pi\int_0^{2\pi}F(\delta)\,d\delta.
\]

Also,

\[
\hat{\boldsymbol\phi}(\phi)\cdot \hat{\boldsymbol\phi}(\phi')
=
\cos\delta.
\]

Thus the energy becomes

\[
E
=
\frac{\rho}{4}
\int_0^{2\pi}d\delta
\int_A\!\!\int_A
\frac{
\omega(r)\omega(r')\cos\delta
}{
|\mathbf X(r,\theta,0)-\mathbf X(r',\theta',\delta)|
}
J(r,\theta)J(r',\theta')
\,dr\,d\theta\,dr'\,d\theta',
\]

where

\[
J(r,\theta)=(R+r\cos\theta)r.
\]

This is the integral evaluated by v10A.0.

## 6. Extrapolation

Finite \(\epsilon=a/R\) corrections are fitted as

\[
\alpha_{\rm eff}(\epsilon)
=
\alpha_0
+
A\epsilon^2\ln(1/\epsilon)
+
B\epsilon^2.
\]

The intercept \(\alpha_0\) is the estimated thin-ring constant.

## 7. Beta relation

From v8,

\[
\beta=\alpha-1+q,
\qquad
q=\frac{d\ln a}{d\ln R}.
\]

Therefore:

\[
q=0\Rightarrow \beta=\alpha-1,
\]

\[
q=-\frac12\Rightarrow \beta=\alpha-\frac32.
\]

## 8. Status

This is a CANON-compatible Research Track method for extracting \(\alpha\) from Euler/Biot–Savart vortex mechanics. It is not yet a proof of \(\alpha_{\rm NLS}=1.61\), because NLS/GP energy contains additional core-field terms absent from Track A.
