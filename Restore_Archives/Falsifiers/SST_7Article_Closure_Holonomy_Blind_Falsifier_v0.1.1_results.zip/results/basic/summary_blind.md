# Blind summary

Mode: **basic**

Cases: **49**

## Overall opaque statuses

- INDETERMINATE: 49

A static-centerline-only `INDETERMINATE` is expected: absent phase/volume/probe data are never manufactured from geometry.

Freeze SHA-256: `b8cace996fd648cc12313e22132c3487a191b7de1a9495a0405c0585326a6e6e`
