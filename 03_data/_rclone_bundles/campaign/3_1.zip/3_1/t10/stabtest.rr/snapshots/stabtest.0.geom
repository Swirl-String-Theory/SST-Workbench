LIST {
	{ < stabtest.0.vect }
	{ < stabtest.0.dlen.vect }
	{ < stabtest.0.dVdt.vect }
}
