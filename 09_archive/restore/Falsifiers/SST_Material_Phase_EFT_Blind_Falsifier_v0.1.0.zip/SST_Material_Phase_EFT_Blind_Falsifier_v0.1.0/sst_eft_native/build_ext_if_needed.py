from __future__ import annotations
import argparse, importlib, pathlib, subprocess, sys

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true")
    args=ap.parse_args()
    root=pathlib.Path(__file__).resolve().parents[1]
    if not args.force:
        try:
            importlib.import_module("sst_eft_native._native")
            print("[SST-EFT-NATIVE] native extension already importable")
            return 0
        except Exception:
            pass
    cmd=[sys.executable, "setup.py", "build_ext", "--inplace"]
    print("[SST-EFT-NATIVE] compile:", " ".join(cmd))
    subprocess.check_call(cmd, cwd=root)
    importlib.invalidate_caches()
    mod=importlib.import_module("sst_eft_native._native")
    print("[SST-EFT-NATIVE] OK:", mod.__doc__)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
