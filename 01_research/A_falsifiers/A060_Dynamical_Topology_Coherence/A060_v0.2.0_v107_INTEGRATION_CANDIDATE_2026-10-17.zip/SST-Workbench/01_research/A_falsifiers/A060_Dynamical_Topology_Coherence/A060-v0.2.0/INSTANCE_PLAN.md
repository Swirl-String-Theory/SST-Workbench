# A060 v0.2.0 — exact v1.0.7 instance integration plan

Date: 16 October 2026. Status: DEVELOPMENT / NOT CERTIFIED. Document type: implementation specification, not an executed instance, frozen protocol, or scientific verdict.

## 1. Scope and immutable lineage

Generate a new thin scientific instance using the unmodified CANONICAL_FROZEN framework v1.0.7. M00–M04 remain internal subchecks; retain native G0–G9 IDs and dependencies. The immediate deliverable is analytic implementation qualification, not rejection of the physical null: algebraic controls do not establish a self-confined, dynamically stable, free-standing 3D vortex knot. The physical comparison model remains unforced, incompressible, inviscid 3D Euler flow. Modified-forcing comparisons are explicitly labelled diagnostic controls.

A060 v0.1.0 remains read-only, including its framework v1.0.6 association, reports, outputs, hashes, ledgers and verdicts. Do not regenerate it, copy its PASS statuses into v0.2.0, reinterpret its verdicts, or migrate its results to a different framework. Record an inventory and hashes before integration and verify unchanged bytes afterward. A054 v0.5.1 remains independent; import neither its scientific status nor its providers for this tranche. A045 is a read-only provenance reference pending identity reconciliation.

## 2. Generation target and preconditions

Target: `01_research/A_falsifiers/<verified-existing-A060-family>/A060-v0.2.0/`. The actual family path and canonical registered name are UNRESOLVED until the registry authority is checked. Do not invent or rename that family. If a development folder already occupies this target, preserve and inventory it; never delete it or pass it to a generator that rejects existing destinations. Generate in an empty staging destination, then integrate through an explicit non-overwriting migration.

From the verified `06_templates/SST_Falsifier_Framework/SST_Falsifier_Framework_v1.0.7` root, use the real generator signature:

```bat
python tools\new_falsifier.py A060 <verified_registered_name> <empty_destination> --profile multilibrary_gpu --version v0.2.0
```

`multilibrary_gpu` is the planned full-contract profile; GPU lanes remain screening only. Verify generated profile settings rather than assuming profile name alone enables independent confirmation. Do not downgrade to `minimal` to obtain certification. Resolve destination/name placeholders before execution. This document does not execute the command.

Verify release bytes against `PACKAGE_MANIFEST.json`, `MANIFEST_SHA256.txt` and canonical freeze records; timestamps and the recorded 56 tests alone do not verify the current bytes. The manifest digest and complete release-byte verification are UNRESOLVED. Never patch v1.0.7 in place.

## 3. Files and contracts to generate

Preserve generator-owned launch/bootstrap files: `.sst_framework_root`, `framework_bootstrap.py`, `conftest.py`, `run_instance.py`, `run_all.cmd`, `run_python.py`, `run_python.cmd`. The locator must resolve to exact v1.0.7. An invalid explicit environment override or locator fails closed; a global installed package cannot replace the pin.

| File | Required instance content |
|---|---|
| `falsifier.toml` | A060, verified name, v0.2.0, package `experiment`, planned profile, framework_version `1.0.7`, deterministic seed, backend/source flags. Keep blind enabled. Set report compilation, parent publication and `pdf_required=true` for the required PDF deliverable. |
| `science_contract.json` | Preserve `SST-SCIENCE-CONTRACT-2` schema. Fill research_question, objective, null_hypothesis, alternative_hypothesis, assumptions, symbols with SI units/dimensions, equations with inputs/outputs/dimensional_check, observables, steps linked to formulas and G2, falsification_criteria, edge_cases and predictions. Explicitly separate analytic qualification from physical H0. |
| `source_contract.json` | Preserve `SST-SOURCE-CONTRACT-2`. Fill independent_unit, sources with source_id/catalog_id/version/relative_path/role/independence_family/evidence_class/provenance_family, parser_contract, translator_contract and replication_policy. Four PDFs are theory provenance, not four independent physical providers. Synthetic fields are `synthetic_control`. Missing external providers remain UNRESOLVED; do not insert fictional discovery/confirmation sources. Keep explicit evidence classes, at least two independent groups for cross-source replication, and synthetic_controls_may_close_cross_source=false. |
| `gate_plan.json` | Preserve `SST-GATE-PLAN-2`, G0–G9 questions, enabled states and causal dependencies. Register M00 under G0/G1 and M01–M04 under G2. Do not manufacture completion by disabling unimplemented gates. |
| `blind_policy.json` | Preserve `SST-BLIND-POLICY-2`, owned-source scan, private paths and both nonced commitments. Keep block_reveal_on_unresolved=true and required G3 status PASS or FAIL. Tighten allowed prior modes to CERTIFY for this campaign. No canonical SST constants or particle identifiers in blind scoring. |
| `report/FALSIFIER_REPORT.tex` | Complete scientific protocol: goals, assumptions, equations, definitions, dimensional checks, algorithms, preregistered thresholds, nulls, source roles, gate mapping, exclusions and limitations. Include generated AUTO_SCIENCE_CONTRACT and AUTO_RESULTS conditionally. No incomplete template markers. |
| `experiment/pipeline.py` | Implement `run_scientific_pipeline(root,cfg,ledger,mode)`; explicitly record every required gate with evidence, reason and actual backend authority. Return backend manifest. No silent native fallback. |
| `experiment/` M00–M04 modules | Migrate the working development modules with original filename/hash mapping; preserve equation-to-code traceability. Proposed names, if new adapters are needed: `m00_provenance.py`, `m01_euler.py`, `m02_shear.py`, `m03_projector.py`, `m04_flux.py`. These are planned instance files, not claimed generator output. |
| `native/cpp/` and native binding configuration | Instance-local strict C++ FP64 counterparts to every observable certified by G5. Use shared build machinery. A generic kernel smoke test cannot certify unimplemented M01–M04 algorithms or full dynamics. |
| `tests/` | Instance regression suite covering migration, all analytic controls, edge cases, convergence, backend authority and historical non-overwrite. |
| `private/` | Generator creates fresh OPAQUE_ID_KEY.bin and REVEAL_NONCE.bin. Complete reveal.json and blind_forbidden_terms.txt privately; never publish them in BLIND archives. |
| `preregistration/` | Framework-generated BLIND_TERMS_COMMITMENT.json, REVEAL_COMMITMENT.json and FROZEN_PROTOCOL.json. Never substitute hand-written commitments. |

Add proposed audit files `integration/LINEAGE_LOCK.json`, `integration/MODULE_MIGRATION.json`, `integration/REGISTRY_RECONCILIATION.md`, `integration/IMPLEMENTATION_LOCK.json`, and `integration/UNRESOLVED.json`. Record source/code/test hashes and registry snapshots in these files and bind their digests into the preregistered protocol; extra files are not automatically frozen merely because they exist. No private payload is copied into these public files.

## 4. M00–M04 acceptance map

| Module | Gate | Required production evidence | Current official state |
|---|---|---|---|
| M00 protocol/runtime | G0 | Exact framework/release pin; complete six-file protocol bundle; nonced commitments; consistent runtime; generated instance and matching freeze identity | UNRESOLVED |
| M00 sources/identity | G1 | Recompute all four PDF hashes; authoritative catalog/registry snapshot; parser/translator qualification; evidence classes; source-role qualification; A045 reconciliation | UNRESOLVED |
| M01 exact Euler controls | G2 | Admissible domain masks; epsilon 0, 0.2, 0.5; volume sampling; multiple finite-difference spacings; independent gradient implementation; divergence, momentum and pressure-Poisson residuals | UNRESOLVED — local prechecks only |
| M02 tensor controls | G2 | Trace-free identity, seeded 2500-matrix wedge test, rotation invariance, signed rank-one and rank-two perturbation exponents, nilpotent and zero-tensor handling | UNRESOLVED — local prechecks only |
| M03 projector | G2 | Odd-grid periodic Fourier refinement; explicit zero-mode/mean policy; vorticity-null masks; transverse projection/curl closure; local budget correction and forcing work | UNRESOLVED — local prechecks only |
| M04 flux | G2 | Independent spherical quadrature; angular and scale refinement; 18 affine controls; balanced-vortex cancellation; retained/measured higher-mode remainder for nonaffine fields | UNRESOLVED — local prechecks only |

G2 closes only when all preregistered subchecks execute successfully after G0/G1 prerequisites, with traceable reference evidence. Recorded 6/6 Python tests, 4/4 PDF matches and numerical residuals remain historical development observations. Do not write them into the official ledger as new PASS records.

M01's development tolerances (3e-7 divergence, 2e-7 momentum, 3e-6 Poisson) and M02's 1e-10 wedge tolerance are candidate starting values, not newly certified thresholds. All production grids, masks, sample counts, refinement criteria, norm definitions, seeds, absolute/relative floors, perturbation-fit windows, parity tolerances and pass aggregation must be fixed before FREEZE. Values not established by the source are UNRESOLVED; do not tune them against held-out outcomes. Zero normalized tensors are undefined/masked, not successful zeros. Dimensionless controls must not acquire canonical SST constants through scoring.

## 5. Gate ledger and remaining points

Retain the template dependency chain `G0 -> G1 -> G2 -> G3 -> G4 -> G5 -> G6 -> G7 -> G8 -> G9`. Do not bypass it to promote local native tests to G5 certification. Backend preflight may run earlier as engineering evidence only.

| Gate | Current state | Missing closure evidence |
|---|---|---|
| G0 | UNRESOLVED | Generated instance, verified release/code lock, completed contracts and successful freeze |
| G1 | UNRESOLVED | Authoritative registry, A045 identity resolution, current hashes and qualified registered inputs |
| G2 | UNRESOLVED | Frozen production M01–M04 controls, convergence and independent-method evidence |
| G3 | UNRESOLVED | Producer-qualified blind discovery fields, quantitative statistic/nulls and thresholds |
| G4 | UNRESOLVED | Independent held-out provider, separation and confirmatory rule |
| G5 | UNRESOLVED | Actual strict native FP64 implementation and end-to-end parity for claimed observables |
| G6 | UNRESOLVED | Preregistered enablement and actual SYCL/DD32 screening results; never FP64 certification |
| G7 | UNRESOLVED | Independent provenance-group replication; labels/re-encodings do not establish independence |
| G8 | UNRESOLVED | Qualified 3D Euler stability/confinement provider, temporal/spatial convergence and physical criteria |
| G9 | UNRESOLVED | Eligible sealed blind ledger, integrity and commitment verification, authorized reveal |

Additional UNRESOLVED items: authoritative A060 family/name; exact framework digest and release verification; migration-code identities; A060 v0.1.0 before/after preservation audit; A045 canonical IDs/alias mapping; registry authority and A054/A060 registration; production parameter matrix; discovery/confirmation split; all independent providers; C++ parity scope and thresholds; GPU enablement; physical stability observables and thresholds; exact frozen reveal payload/commitments; report render and visual inspection; output packaging audit. A plan does not close any of these.

For A045, preserve both historical identities and their hashes/paths. Determine whether they are aliases or separate families from authoritative records. If separate, assign distinct canonical identities through an explicit registry change with a legacy alias/migration table; do not silently select one. G1 and FREEZE readiness remain blocked until the ambiguity is resolved. Registry corrections must not modify historical result files.

G9 in an actual BLIND runtime ledger is framework-managed `DEFERRED`; this is phase bookkeeping, not closure. The present plan-level scientific state remains UNRESOLVED. Preserve native SKIP/blocked/DEFERRED serialization where required; never translate them to PASS. Check effective enabled states because the runner derives G4/G5/G6/G7 enablement from configuration as well as gate_plan.json.

## 6. Required execution order and stop rules

Before the sequence: verify lineage/framework bytes and registry authority; generate fresh instance; migrate modules; complete thresholds, source contracts, report, blind payload and code locks. Unknown required scientific definitions block FREEZE. M00–M04 alone cannot complete the full physical campaign; further provider/contract work remains necessary.

1. `run_all.cmd SELFTEST`. The actual v1.0.7 runner executes framework/tests here, not instance/tests. Run instance tests separately with `run_python.cmd -m pytest tests -q`. Archive both results and backend preflight. The recorded 56 framework and 6 development tests are baselines, not substitutes for current execution. Any failed prerequisite stops progression.
2. `run_all.cmd FREEZE`. Only after readiness checks pass. Generate both public nonced commitments and `preregistration/FROZEN_PROTOCOL.json`. Freeze science_contract.json, source_contract.json, gate_plan.json, falsifier.toml, blind_policy.json and report/FALSIFIER_REPORT.tex through the native implementation, including referenced implementation locks. A successful command is a commitment event, not physical certification. Scientific changes afterward require a new version/campaign; do not overwrite frozen history.
3. `run_all.cmd BASIC`. Execute frozen analytic/reference checks at preregistered BASIC settings. Require actual G0/G1 evidence before G2 closure. Downstream gates lacking required evidence remain UNRESOLVED. BASIC cannot authorize reveal or physical conclusions.
4. `run_all.cmd FULL`. Execute registered blind discovery and confirmation only when providers and criteria exist. Record every unresolved/blocked gate honestly. Seal and archive BLIND artifacts before proceeding; the canonical output directory is reused by later modes.
5. `run_all.cmd CERTIFY`. Verify the unchanged protocol; execute strict C++ FP64 certification on its preregistered scope and complete required replication/mechanism checks. Missing native code is UNRESOLVED with explicit reason, never a Python fallback PASS. Archive this mode's sealed BLIND ledger/summary/manifest and environment separately from FULL. Process exit success does not certify gates.
6. `run_all.cmd REVEAL_IF_ALLOWED`. Only after the CERTIFY BLIND snapshot is sealed and independently checked. Verify ledger self-hash, summary-to-ledger binding, manifest self-hash and exact tree, frozen bundle identity, allowed prior mode, G3 PASS/FAIL, and no unresolved required pre-reveal gates. Verify both nonced commitments before disclosure. Scientific FAIL need not prohibit reveal if the frozen policy permits it. Reveal consumes the existing ledger and never reruns science.

With present evidence, progression stops before FREEZE; no reveal is eligible. Unattended `REVEAL_IF_ALLOWED` may return exit 0 while writing a withheld decision; inspect eligible/performed/reason and integrity fields. Inspection of the retrieved runner shows ineligible integrity cases can also reach that withheld branch: a zero exit must never be treated as integrity success. Record integrity failure as an orchestration blocker without patching the frozen framework. G9 must not be written PASS by a wrapper.

## 7. Outputs and acceptance

Use native configured `<name>_v0.2.0-outputs/` inside the instance. Required outputs: GATE_LEDGER.json, RUN_SUMMARY.json, OUTPUT_MANIFEST.json, SOURCE_MANIFEST.json, BACKEND_MANIFEST.json, ENVIRONMENT_PUBLIC.json, REPORT_RENDER.json, copied frozen FALSIFIER_REPORT.tex, generated AUTO_SCIENCE_CONTRACT.tex and AUTO_RESULTS.tex. Publish `A060-v0.2.0_FALSIFIER_REPORT.pdf` beside the instance; visually inspect it. The PDF is derived; the TeX protocol remains frozen. POST_RUN_DISCUSSION.tex is separate post-run interpretation.

Distinct parent archives: `<name>_v0.2.0-outputs_BLIND.zip` and, only on successful authorized reveal, `<name>_v0.2.0-outputs_REVEALED.zip`. Include REVEAL_DECISION.json in the finalized revealed manifest/package. Preserve sealed BLIND archives and mode-specific snapshots before reruns, since new blind runs purge stale reveal artifacts and the v0.2.0 parent PDF. Never point output cleanup at v0.1.0. Public source packages exclude private keys/payloads and generated build/runtime trees.

Acceptance for integration: generated/pinned instance, completed schema-valid contracts, reproducible current tests, auditable mapping and explicit unresolved ledger. Acceptance for certification requires actual gate evidence; this document grants none. Historical A060 v0.1.0 and independent A054 remain unchanged.

## Sources checked

- A060 development implementation plan, 13 October 2026: https://drive.google.com/file/d/1mGgOwfILgA3nGKZYaq00RWNekVfCPRS2/view
- v1.0.7 README: https://drive.google.com/file/d/1zdwo6q6XLOgrSpfmN_s9865SgfeocD-a/view
- v1.0.7 generator: https://drive.google.com/file/d/1F0hFAL6bGz6BfNR7P0xfUdU30mVlxixr/view
- v1.0.7 gate template: https://drive.google.com/file/d/1buS_BgQujSNIKUoFvQW6nC_c4hD1X2Jr/view
- v1.0.7 report contract: https://drive.google.com/file/d/1H8DMYqkNHaK8MdfqIh8wSa8ju0-fLTXr/view
- v1.0.7 runtime runner: https://drive.google.com/file/d/1xgssaE0uzbc8hlaV1xFGBE7T_N8lA61y/view

Source statements are distinguished above from proposed instance file names, stricter campaign policy, and integration acceptance rules. No scientific experiment or certification command was run while preparing this plan.
