# A049 v0.3.0 reveal report

Blind seal: **VERIFIED**
Release mode: **PYTHON_REFERENCE_ONLY**
Pipeline: **PIPELINE_QUALIFIED**
Research question: **SUPPORTED_FOR_REGULARIZED_LINKED_FILAMENT_MICROCELL_ENSEMBLE**
Linking-specific source: **NOT_SUPPORTED**
Master-Factor Wave Closure: **NOT_CLOSED**

## Strict canonical scale map

- candidate c_T/v_circlearrow = 1.480338038223e-01
- candidate c_T = 1.619261294033e+05 m s^-1
- candidate mu = 1.835404996848e+04 Pa (if rho_eff=rho_f)
- c/c_T = 1.851414957578e+03
- target 4/alpha = 5.481439967104e+02
- relative Master-Factor mismatch = 2.377606922066e+00
- target c_T = 5.469228150000e+05 m s^-1

## Geometry density check

- a/R = 0.18
- R = 7.827612055556e-15 m when a=r_c
- densest tested non-overlap spacing = 2.348283616667e-14 m
- target-by-density spacing = 1.043144512488e-14 m
- MF03 = FAIL_TARGET_REQUIRES_CELL_OVERLAP

## Topological persistence

- initial mean Lk = -1.011534845172e+00
- max |Delta Lk| = 1.119242801181e-03
- modulus persistence min = 1.000000000000e+00
- applied shear-stress persistence min = 9.941262935592e-01
- stored shear-energy drift max = 4.233209547243e-02
- linked-vs-unlinked modulus excess = -8.900653981119e-03

The explicit Hopf-linked regularized Biot-Savart microcells retain a positive conservative affine shear curvature and a persistent odd shear stress over the tested interval. However, an unlinked control has nearly the same modulus, so linking itself is not identified as the source. The Master-Factor speed ratio fails at the densest non-overlapping packing, and the density extrapolation would require overlapping cells. No independent bulk propagating transverse pole is established in v0.3.0, so Master-Factor Wave Closure remains NOT_CLOSED.
