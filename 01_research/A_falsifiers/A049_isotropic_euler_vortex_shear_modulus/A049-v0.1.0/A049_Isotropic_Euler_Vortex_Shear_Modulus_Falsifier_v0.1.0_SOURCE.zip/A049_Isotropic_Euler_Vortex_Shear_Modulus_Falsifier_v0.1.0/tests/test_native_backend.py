import os
import pytest
from sst_vortex_shear.sampling import paired_transverse_samples, shear_matrix
from sst_vortex_shear import reference, backend


def test_native_parity_if_requested():
    if os.environ.get("SST_BACKEND", "").lower() != "native":
        pytest.skip("native backend not requested")
    n, w, _, _, _ = paired_transverse_samples(500)
    f = shear_matrix(0.043, "zx")
    assert abs(reference.energy_ratio_general(n,w,f) - backend.energy_ratio_general(n,w,f)) < 1e-12
