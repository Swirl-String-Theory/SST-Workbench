# Literature anchors

This note records external concepts used for the L2 attempt.

- Crofton/integral geometry: line/curve length can be represented by average intersection counts; in Route A this supports only the orientation/projection factor, not the absolute scale of Lambda_L.
- Quantum turbulence: vortex line density is a standard line length per unit volume, with intervortex spacing of order L^{-1/2}; this supports the dimensional interpretation of Lambda_L.
- Weyl law / heat-kernel counting: phase-space mode counting can produce coefficients like V k^3/(6 pi^2), but care is required because angular volume may already be included.
- Cartan torsion: torsion is a vector-valued two-form T(X,Y), which in 3 spatial dimensions has dim(R^3 tensor Lambda^2 R^3)=9 components.
- LQG horizon punctures: useful analogy only; it also warns that puncture degeneracy/Immirzi-like constants are often fixed by entropy matching unless independently derived.
