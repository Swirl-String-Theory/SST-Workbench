@echo off
setlocal
if "%~1"=="" (echo Usage: %~nx0 ^<physical_core_response.npz^> & exit /b 2)
call .venv\Scripts\activate.bat
python run_pipeline.py --config configs\basic.json --profile basic --core-response "%~1" --out SST_Knot_State_Algebra_Blind_Falsifier_v0.1.0-outputs\core_algebra
