from pathlib import Path
import json
import os
import numpy as np

from sst_vortex_shear import reference, backend
from sst_vortex_shear.sampling import paired_transverse_samples, shear_matrix, rotation_matrix

if backend.backend_name() != "native":
    raise SystemExit("SST_BACKEND=native is required for parity qualification")

ROOT = Path(__file__).resolve().parent
BLIND = ROOT.parent / "A049_Isotropic_Euler_Vortex_Shear_Modulus_Falsifier_v0.1.0-outputs" / "BLIND"
CFG = json.loads((ROOT / "configs" / "default.json").read_text(encoding="utf-8"))
tol = float(CFG["tolerances"]["backend_parity_max_abs"])

n, w, _, _, _ = paired_transverse_samples(1200)
errors = []
for plane in CFG["shear_planes"]:
    for g in [0.003, 0.017, 0.061]:
        f = shear_matrix(g, plane)
        r_ref = reference.energy_ratio_general(n, w, f)
        r_nat = backend.energy_ratio_general(n, w, f)
        errors.append(abs(r_ref - r_nat))
q = rotation_matrix(int(CFG["seed"]) + 777)
f = q @ shear_matrix(0.043, "xy") @ q.T
r_ref = reference.energy_ratio_general(n @ q.T, w @ q.T, f)
r_nat = backend.energy_ratio_general(n @ q.T, w @ q.T, f)
errors.append(abs(r_ref - r_nat))
maxerr = max(errors, default=0.0)
result = {"status": "PASS" if maxerr <= tol else "FAIL", "tolerance_max_abs": tol, "max_abs": maxerr, "cases": len(errors)}
(BLIND / "backend_parity_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
