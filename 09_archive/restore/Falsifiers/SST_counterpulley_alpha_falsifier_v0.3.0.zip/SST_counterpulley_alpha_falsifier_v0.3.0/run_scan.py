#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from sst_counterpulley.core import DEFAULT_DATA, prepare_centerline, write_csv, write_json
from sst_counterpulley.dynamics import compute_dynamic_blind

def floats(s): return [float(x) for x in s.split(",") if x.strip()]
def ints(s): return [int(x) for x in s.split(",") if x.strip()]
def main()->int:
    ap=argparse.ArgumentParser(description="Blind coupled-Kelvin N/offset/core sweep; alpha is never imported.")
    ap.add_argument("--data",default=str(DEFAULT_DATA)); ap.add_argument("--n-values",default="128,256,512")
    ap.add_argument("--offsets",default="0.4,0.5,0.6"); ap.add_argument("--eps-values",default="0.025,0.05,0.10")
    ap.add_argument("--force-python",action="store_true"); ap.add_argument("--out-json",default="audit_out/blind_dynamic_grid.json"); ap.add_argument("--out-csv",default="audit_out/blind_dynamic_grid.csv")
    a=ap.parse_args(); rows=[]
    for n in ints(a.n_values):
        c,m=prepare_centerline(data_path=a.data,n=n); D=float(m["D_metadata"])
        for off in floats(a.offsets):
            for eps in floats(a.eps_values):
                r=compute_dynamic_blind(c,D=D,offset_over_D=off,eps_over_D=eps,force_python=a.force_python,skip_build=True)
                d=r.to_dict(); rows.append(d)
    write_json(a.out_json,rows); write_csv(a.out_csv,rows); print(json.dumps({"rows":len(rows),"out_json":a.out_json,"out_csv":a.out_csv},indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
