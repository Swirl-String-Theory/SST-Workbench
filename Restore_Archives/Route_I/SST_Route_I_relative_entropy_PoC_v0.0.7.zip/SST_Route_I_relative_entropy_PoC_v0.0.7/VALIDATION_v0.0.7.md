# Validation v0.0.7

- Python syntax: `PASS`.
- Ten automated theorem and phase gates: `PASS`.
- Hot/cold phase scan: `PASS` away from the transition region.
- Confining candidate region found at beta 0.80 and 0.90.
- Coulomb candidate region found at beta 1.05, 1.10, and 1.20.
- Transitional/metastable behavior found at beta 1.00.
- Quantum coupling reconstruction:
  `abs(sqrt(I_l K_l)/(hbar beta_Q)-1) < 5e-12`.
- Speed identity reconstruction:
  `abs(c_T/(a_star sqrt(K_l/I_l))-1) < 5e-12`.
- Forbidden gravity inputs absent from the blind closure.
- Deterministic full rerun: `PASS`; CSV and JSON outputs are byte-identical.
- LaTeX compilation: `PASS` (two pdflatex passes).
- PDF render inspection: `PASS`; 5 pages, no clipping or overlap observed.

The phase scan is a finite-volume implementation test, not a thermodynamic-limit
proof. The release is intentionally blocked from `CLOSED` status by the absence
of a unique internal beta-selection principle.
