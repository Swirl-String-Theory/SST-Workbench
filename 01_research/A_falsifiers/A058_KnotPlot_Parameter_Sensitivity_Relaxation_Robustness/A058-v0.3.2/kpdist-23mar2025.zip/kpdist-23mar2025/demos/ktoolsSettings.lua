--[[
  
--]]

if ktoolsSettingsRun == nil then
  jhomfly = nil
  jidknot = nil
end

ktoolsSettingsRun = true

