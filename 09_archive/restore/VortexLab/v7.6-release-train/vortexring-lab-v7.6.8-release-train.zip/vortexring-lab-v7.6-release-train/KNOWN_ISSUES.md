# Known issues

## v7.6.7 — startup regression

Status: **fixed in v7.6.8**.

Symptoom: zwart simulatorcanvas; statische HUD/UI blijft zichtbaar.

Oorzaak: een vroege `syncUi()` riep `syncSpecClockQuickControls()` aan, die `typeof ModelLog` gebruikte terwijl de lexicale `const ModelLog` nog in de temporal dead zone stond. Voor een `let`/`const` in de TDZ is zelfs `typeof` niet veilig.
