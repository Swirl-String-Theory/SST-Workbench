import sys
from pathlib import Path
import re

import numpy as np

import matplotlib as mpl
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "processed"
FIGURE_DIR = ROOT / "figures"
SRC_DIR = ROOT / "src" / "gpe_dynamics"
OUTPUT_DIR = ROOT / "outputs"
DEFAULT_CASE_ROOT = OUTPUT_DIR / "Nx = 1000 Ny = 500 dt=0.010 obstacle=100"
SNAPSHOT_RE = re.compile(r"psi_time:([+-]?\d+(?:\.\d+)?)\.npy$")

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


def setup_matplotlib():
    try:
        plt.style.use("physrev")
    except OSError:
        pass
    mpl.rcParams["text.usetex"] = False
    mpl.rcParams["mathtext.fontset"] = "cm"
    mpl.rcParams["xtick.minor.visible"] = False
    mpl.rcParams["ytick.minor.visible"] = False
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)


def load_merged(name: str = "250903_a_merged_obs=100.npy"):
    return np.load(DATA_DIR / "arr_data" / name)


def load_freq_outlier(name: str = "freq_outlier.csv"):
    return np.genfromtxt(DATA_DIR / "arr_data" / name, names=True, dtype=None, encoding=None)


def load_threshold_reynolds_table(name: str = "threshold_reynolds_table.csv"):
    return np.genfromtxt(DATA_DIR / name, delimiter=",", names=True, dtype=None, encoding=None)


def find_case_dir(
    V0: float,
    sigma: float | int,
    speed: float,
    *,
    case_root: Path = DEFAULT_CASE_ROOT,
) -> Path:
    exact = case_root / f"V0={V0:.1f} sigma={int(sigma)} v={speed:.3f} dt = 0.0100 GPU"
    if exact.exists():
        return exact

    matches = sorted(case_root.glob(f"V0={V0:.1f} sigma={int(sigma)} v={speed:.3f} dt = * GPU*"))
    if matches:
        return matches[0]

    available = "\n".join(path.name for path in sorted(case_root.glob("*")))
    raise FileNotFoundError(
        f"Could not find output case for V0={V0:.1f}, sigma={int(sigma)}, v={speed:.3f}.\n"
        f"Searched under: {case_root}\n"
        f"Available cases:\n{available}"
    )


def find_psi_dir(V0: float, sigma: float | int, speed: float, *, case_root: Path = DEFAULT_CASE_ROOT) -> Path:
    return find_case_dir(V0, sigma, speed, case_root=case_root) / "Psi"


def find_force_file(V0: float, sigma: float | int, speed: float, *, case_root: Path = DEFAULT_CASE_ROOT) -> Path:
    return find_case_dir(V0, sigma, speed, case_root=case_root) / "Force" / "force_dt=0.02.txt"


def parse_snapshot_time(path: str | Path) -> float:
    match = SNAPSHOT_RE.search(Path(path).name)
    if match is None:
        raise ValueError(f"Cannot parse psi snapshot time from: {path}")
    return float(match.group(1))


def find_snapshot_file(psi_dir: Path, target_time: float) -> Path:
    files = sorted(psi_dir.glob("psi_time:*.npy"), key=parse_snapshot_time)
    if not files:
        raise FileNotFoundError(f"No psi snapshots found in: {psi_dir}")

    times = np.asarray([parse_snapshot_time(path) for path in files], dtype=float)
    index = int(np.argmin(np.abs(times - float(target_time))))
    return files[index]
