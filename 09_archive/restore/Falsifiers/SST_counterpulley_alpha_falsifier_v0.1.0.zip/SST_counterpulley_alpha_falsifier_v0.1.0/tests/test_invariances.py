from sst_counterpulley.core import prepare_centerline
from sst_counterpulley.physics import compute_blind

def test_global_sign_reversal_python():
    c,m=prepare_centerline(n=48)
    a=compute_blind(c,D=m["D_metadata"],offset_over_D=.35,eps_over_D=.08,force_python=True,skip_build=True)
    b=compute_blind(c,D=m["D_metadata"],offset_over_D=.35,eps_over_D=.08,gamma_plus=-1,gamma_minus=1,force_python=True,skip_build=True)
    assert abs(a.G_energy-b.G_energy)<1e-12
