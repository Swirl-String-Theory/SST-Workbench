@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call run_install.cmd || exit /b 1
echo [SST] Recomputing BASIC conclusions for v0.1.0, v0.1.1 and v0.2.0 from bundled identical inputs...
".venv\Scripts\python.exe" tools\reproduce_history.py --mode basic %*
exit /b %errorlevel%
