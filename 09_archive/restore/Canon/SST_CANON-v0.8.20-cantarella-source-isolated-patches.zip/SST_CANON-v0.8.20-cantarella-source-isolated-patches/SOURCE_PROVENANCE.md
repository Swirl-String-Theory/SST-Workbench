# Bron-naar-patch provenance

Iedere wetenschappelijke bron is verwerkt in precies één inhoudelijke subpatch. De patches zijn sequentieel, maar de inhoudelijke herkomst blijft geïsoleerd.

| Volgorde | Brondocument | SHA-256 bron | Subpatch | SHA-256 subpatch |
|---:|---|---|---|---|
| 0001 | `helicity-forms.pdf` | `5cfb8784420cb3424d827f7eb222ea5295c2dec66c1631a27d05eca63d535f3a` | `patches/0001-helicity-forms-mapping-class.diff` | `8c632c7105b9fbad3cbe57cc3eab61650d077ddbee431fe8c4ce0b44020679f6` |
| 0002 | `isoperimetricproblem.pdf` | `0ea1d1e31c5c6e066fa94d9ef2751723320c00292d7505d081fbaf216e186a18` | `patches/0002-isoperimetric-domain-spectrum.diff` | `0a25f276f134476030d04660d5218390a5d39e50f68c4fc7681fba3621a5b91d` |
| 0003 | `ridgerunner.pdf` | `5f43e551e055d698f1e69a440d7ab0d4f868a47f63980016d79375c62e3b3a18` | `patches/0003-ridgerunner-certification.diff` | `54382e7b3b7559c7c20b9d4670f2a437b83fb63471e1fa39bf01037400aac654` |

De bron-PDF's zijn niet gedupliceerd in dit pakket. De hashes binden iedere subpatch aan het exact geanalyseerde uploadbestand.
