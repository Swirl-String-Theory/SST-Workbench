# SST Route I Relative-Entropy Proof-of-Concept v0.0.3

## Result

Version 0.0.3 closes the v0.0.2 **local affine-scale and modular/KMS gate**
inside the homogeneous quadratic transverse-torsion sector.

The closed chain is

\[
\mathcal S(x)
\longrightarrow
L_\star
=
\frac{1}{|\partial_n\ln\mathcal S|}
\longrightarrow
\text{local Rindler wedge}
\longrightarrow
\text{boost modular flow}
\longrightarrow
\text{KMS/Unruh response}.
\]

Together with v0.0.2,

\[
\widehat\phi
=
L_\star\sqrt{\frac{Z_T}{\hbar}}A,
\qquad
Z_T=\sqrt{\rho_{\!f}K_T}=\rho_{\!f}c_T.
\]

The new physical scale is

\[
L_\star
=
\frac{1}{|\partial_n\ln\mathcal S|}
=
\frac{c_T^2}{a_\chi},
\]

and the local KMS temperature is

\[
T_{\mathrm{KMS}}
=
\frac{\hbar a_\chi}{2\pi c_Tk_B}.
\]

## Run

```bash
python sst_relative_entropy_route1_poc_v0.0.3.py \
  --output-dir output
```

The default local logarithmic Swirl-Clock gradient is

\[
|\partial_n\ln\mathcal S|=1\ \mathrm{m^{-1}},
\]

so \(L_\star=1\ \mathrm m\). A different local clock gradient can be tested:

```bash
python sst_relative_entropy_route1_poc_v0.0.3.py \
  --clock-log-gradient 1000 \
  --output-dir output_gradient_1000
```

The scale is always derived from the clock gradient; it is no longer accepted
as a free normalization argument.

## New v0.0.3 tests

1. Rindler metric reconstruction;
2. local lapse-gradient closure;
3. uniform proper acceleration;
4. modular affine dilation \(U\to e^{-2\pi t}U\);
5. complex-time KMS identity;
6. Unruh--DeWitt detector detailed balance;
7. equality of the two Unruh-temperature formulas.

All earlier tests remain active.

## Outputs

- `audit_report.json` — complete machine-readable audit;
- `convergence.csv` — entropy/focusing convergence;
- `normalization_scale_sweep.csv` — torsion normalization versus scale;
- `kms_scale_sweep.csv` — clock-gradient, acceleration, inverse temperature,
  and KMS results;
- `detailed_balance.csv` — detector detailed-balance certification;
- `rindler_wedge.png` — effective Rindler geometry;
- `kms_detailed_balance.png` — detector detailed balance;
- diagnostic plots inherited from v0.0.2.

## Epistemic boundary

The gate is closed only after imposing the free effective-sector assumptions
listed in `THEOREM_TARGET_v0.0.3.md`. This version does not derive \(K_T\),
\(c_T\), the effective vacuum, or universal monometricity from the complete
nonlinear SST substrate. It also does not derive the entropy-area coefficient,
Newton's constant, or empirical Einstein dynamics.
