from __future__ import annotations
import csv, hashlib, json, pathlib, shutil
from .io import discover_coords, load_coords, sha256_file

def config_hash(cfg):
    return hashlib.sha256(json.dumps(cfg,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def prepare(dataset,outdir,cfg):
    dataset=pathlib.Path(dataset).resolve(); out=pathlib.Path(outdir).resolve(); blind=out/"blind_input"; private=out/"private"
    blind.mkdir(parents=True,exist_ok=True); private.mkdir(parents=True,exist_ok=True)
    accepted=[]; rejected=[]
    for p in discover_coords(dataset):
        try:
            pts=load_coords(p)
            if len(pts)<cfg["min_points_input"]: raise ValueError(f"need >= {cfg['min_points_input']} points")
            accepted.append((sha256_file(p),p,len(pts)))
        except Exception as e: rejected.append((str(p),str(e)))
    accepted.sort(key=lambda x:x[0])
    maprows=[]
    for idx,(h,p,npts) in enumerate(accepted,1):
        bid=f"B{idx:04d}"; dst=blind/f"{bid}.coords{p.suffix.lower()}"; shutil.copy2(p,dst)
        mode_candidates=[p.with_name(p.stem+".modes.csv"), p.with_suffix(".modes.csv")]
        mode_src=next((x for x in mode_candidates if x.exists()),None)
        if mode_src: shutil.copy2(mode_src, blind/f"{bid}.modes.csv")
        maprows.append({"blind_id":bid,"source_path":str(p),"source_sha256":h,"n_input":npts,"blind_file":str(dst.name),"mode_file":f"{bid}.modes.csv" if mode_src else ""})
    with (private/"blind_map.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=maprows[0].keys() if maprows else ["blind_id","source_path","source_sha256","n_input","blind_file","mode_file"]); w.writeheader(); w.writerows(maprows)
    with (private/"rejected.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["source_path","reason"]); w.writerows(rejected)
    lock={"config_sha256":config_hash(cfg),"dataset_root":str(dataset),"accepted":len(accepted),"rejected":len(rejected)}
    (out/"PREANALYSIS_LOCK.json").write_text(json.dumps(lock,indent=2),encoding="utf-8")
    return lock
