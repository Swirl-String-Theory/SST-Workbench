import os
import json
import math
import numpy as np
import trimesh

R = 15.221053514957278
r = 4.843062482031861
a = 3.459330344308472
P = 58.116749784382336
u_lane_min = -0.45600000000000035
u_lane_max = 0.45600000000000035
c_lane = 0.0

def wrap_angle(x):
    return (x + np.pi) % (2 * np.pi) - np.pi

def gamma(u):
    return np.array([
        (R + r * np.cos(3 * u)) * np.cos(2 * u),
        (R + r * np.cos(3 * u)) * np.sin(2 * u),
        r * np.sin(3 * u),
    ], dtype=float)

def dgamma(u):
    return np.array([
        -3 * r * np.sin(3 * u) * np.cos(2 * u) - 2 * (R + r * np.cos(3 * u)) * np.sin(2 * u),
        -3 * r * np.sin(3 * u) * np.sin(2 * u) + 2 * (R + r * np.cos(3 * u)) * np.cos(2 * u),
        3 * r * np.cos(3 * u),
    ], dtype=float)

def ddgamma(u):
    return np.array([
        -9 * r * np.cos(3 * u) * np.cos(2 * u) + 12 * r * np.sin(3 * u) * np.sin(2 * u) - 4 * (R + r * np.cos(3 * u)) * np.cos(2 * u),
        -9 * r * np.cos(3 * u) * np.sin(2 * u) - 12 * r * np.sin(3 * u) * np.cos(2 * u) - 4 * (R + r * np.cos(3 * u)) * np.sin(2 * u),
        -9 * r * np.sin(3 * u)
    ], dtype=float)

def frenet_frame(u):
    g1 = dgamma(u)
    T = g1 / np.linalg.norm(g1)
    g2 = ddgamma(u)
    B = np.cross(g1, g2)
    B = B / np.linalg.norm(B)
    N = np.cross(B, T)
    N = N / np.linalg.norm(N)
    return T, N, B

def X(u, beta):
    _, N, B = frenet_frame(u)
    return gamma(u) + a * (np.cos(beta) * N + np.sin(beta) * B)

def residual(beta, u):
    p = X(u, beta)
    phi = math.atan2(p[1], p[0]) - 2 * np.pi * p[2] / P
    return wrap_angle(phi - c_lane)

def solve_beta_local(us, beta_seed=0.0):
    betas = []
    beta = beta_seed
    for u in us:
        for _ in range(30):
            f = residual(beta, u)
            h = 1e-5
            df = (residual(beta + h, u) - residual(beta - h, u)) / (2 * h)
            if abs(df) < 1e-10:
                break
            step = -f / df
            beta = wrap_angle(beta + step)
            if abs(step) < 1e-10:
                break
        betas.append(beta)
    return np.array(betas)

def lane_window(u):
    if u < u_lane_min or u > u_lane_max:
        return 0.0
    x = (u - u_lane_min) / (u_lane_max - u_lane_min)
    return math.sin(math.pi * x) ** 2

def lane_beta_interp(u, u_samples, beta_samples):
    if u <= u_samples[0]:
        return beta_samples[0]
    if u >= u_samples[-1]:
        return beta_samples[-1]
    return np.interp(u, u_samples, beta_samples)

def build_tube_mesh(nu=420, nb=84, lane_mode=None):
    u_vals = np.linspace(0, 2 * np.pi, nu, endpoint=False)
    b_vals = np.linspace(0, 2 * np.pi, nb, endpoint=False)
    u_lane = np.linspace(u_lane_min, u_lane_max, 800)
    beta_lane = solve_beta_local(u_lane, beta_seed=0.0)

    verts = np.zeros((nu * nb, 3), dtype=float)
    sigma_beta = 0.24
    lane_height = 0.55

    for i, u in enumerate(u_vals):
        _, N, B = frenet_frame(u)
        center = gamma(u)
        lane_u_beta = lane_beta_interp(u, u_lane, beta_lane) if (lane_mode and u_lane_min <= u <= u_lane_max) else None
        w_u = lane_window(u)

        for j, beta in enumerate(b_vals):
            radius = a
            if lane_u_beta is not None:
                db = wrap_angle(beta - lane_u_beta)
                g = math.exp(-0.5 * (db / sigma_beta) ** 2) * w_u
                if lane_mode == "ridge":
                    radius += lane_height * g
                elif lane_mode == "groove":
                    radius -= 0.45 * lane_height * g
            verts[i * nb + j] = center + radius * (math.cos(beta) * N + math.sin(beta) * B)

    faces = []
    for i in range(nu):
        i2 = (i + 1) % nu
        for j in range(nb):
            j2 = (j + 1) % nb
            v00 = i * nb + j
            v10 = i2 * nb + j
            v11 = i2 * nb + j2
            v01 = i * nb + j2
            faces.append([v00, v10, v11])
            faces.append([v00, v11, v01])

    return trimesh.Trimesh(vertices=verts, faces=np.array(faces), process=True)

if __name__ == "__main__":
    smooth = build_tube_mesh(lane_mode=None)
    ridge = build_tube_mesh(lane_mode="ridge")
    groove = build_tube_mesh(lane_mode="groove")
    smooth.export("trefoil_compact_smooth.stl")
    ridge.export("trefoil_compact_local_lane_ridge.stl")
    groove.export("trefoil_compact_local_lane_groove.stl")
    print("Exported STL files.")
