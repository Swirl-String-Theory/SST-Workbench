# KnotPlot 3.1 Trefoil Seed Campaign v0.1.0

Prospective initial-condition campaign for generating genuinely new relaxed
trefoil geometries before the SST Phase-Feedback Delay v0.2 confirmatory test.

The key design change is **seed diversity with one fixed relaxation protocol**.
It does not repeat the old strategy of many force labels applied to essentially
one start geometry.

## Expected location

Place the extracted folder under the KnotPlot workspace, for example:

```text
C:\workspace\projects\SST-Workbench\KnotPlot\
    KnotPlot.lnk
    KnotPlot_3p1_Trefoil_Seed_Campaign_v0.1.0\
```

`run_campaign.py` resolves the sibling `KnotPlot.lnk`. You can override it with
the environment variable `KNOTPLOT_LNK`.

## Full run

```bat
run_all.cmd
```

Stages:

```text
run_00_install.cmd
run_03_selftest.cmd
run_02_verify_preregistration.cmd
run_05_export_base.cmd
run_10_generate_seeds.cmd
run_15_generate_kpc.cmd
run_20_relax.cmd
run_30_analyze.cmd
run_40_pack_outputs.cmd
```

The base stage uses the installed KnotPlot itself:

```text
reset all
load 3.1
refine nbeads 300
centre
fitto mindist 1.05
coords .../base/base_3p1_300.txt
```

KnotPlot's `coords` output is intentionally used because KnotPlot can directly
`load` that ASCII coordinate format again.

## Production output

The phase-delay falsifier can consume:

```text
...\KnotPlot_3p1_Trefoil_Seed_Campaign_v0.1.0\out
```

with files such as:

```text
S001_bishop_helical_i00000.txt
S001_bishop_helical_i01000.txt
S001_bishop_helical_i04000.txt
S001_bishop_helical_i10000.txt
```

After the campaign, `analysis\REPORT.md` reports exact endpoint uniqueness and
novelty against the frozen 10-geometry v0.1.7 registry.

If it reports at least 8 novel unique endpoints, preview the folder with your
Phase-Delay v0.2.x falsifier and only then run its confirmatory chain.
