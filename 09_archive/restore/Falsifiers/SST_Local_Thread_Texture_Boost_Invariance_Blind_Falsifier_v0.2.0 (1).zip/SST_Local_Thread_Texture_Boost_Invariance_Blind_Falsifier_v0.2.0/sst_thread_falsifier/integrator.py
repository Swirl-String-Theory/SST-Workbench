from __future__ import annotations
import numpy as np
from .native_ext.core import biot_savart, segment_biot_savart
from .geometry import metrics


def _velocity(P,t,offsets,gamma,knot_core,bg_vertices,bg_offsets,bg_gammas,bg_core,frame_velocity,
              force_python=False,skip_build=False):
    v=biot_savart(P,offsets,gamma,knot_core,force_python=force_python,skip_build=skip_build)
    if len(bg_vertices):
        B=bg_vertices+t*frame_velocity[None,:]
        v += segment_biot_savart(P,B,bg_offsets,bg_gammas,bg_core,force_python=force_python,skip_build=skip_build)
    v += frame_velocity[None,:]
    return v


def integrate_rk4(points,offsets,gamma,knot_core,bg_vertices,bg_offsets,bg_gammas,bg_core,
                  frame_velocity,dt,n_steps,force_python=False,skip_build=False,record=True):
    P=np.asarray(points,float).copy()
    O=np.asarray(offsets,np.int64)
    B=np.asarray(bg_vertices,float)
    BO=np.asarray(bg_offsets,np.int64)
    BG=np.asarray(bg_gammas,float)
    U=np.asarray(frame_velocity,float)
    dt=float(dt); n_steps=int(n_steps)
    traj=[]
    if record:
        traj.append({"step":0,"t":0.0,**metrics(P,O)})
    for s in range(n_steps):
        t=s*dt
        k1=_velocity(P,t,O,gamma,knot_core,B,BO,BG,bg_core,U,force_python,skip_build)
        k2=_velocity(P+0.5*dt*k1,t+0.5*dt,O,gamma,knot_core,B,BO,BG,bg_core,U,force_python,skip_build)
        k3=_velocity(P+0.5*dt*k2,t+0.5*dt,O,gamma,knot_core,B,BO,BG,bg_core,U,force_python,skip_build)
        k4=_velocity(P+dt*k3,t+dt,O,gamma,knot_core,B,BO,BG,bg_core,U,force_python,skip_build)
        P=P+(dt/6.0)*(k1+2.0*k2+2.0*k3+k4)
        if not np.all(np.isfinite(P)):
            raise FloatingPointError(f"non-finite RK4 state at step {s+1}")
        if record:
            traj.append({"step":s+1,"t":float((s+1)*dt),**metrics(P,O)})
    return P,traj
