# Result summary v0.1.1

## Direct answer

The literal model is mathematically falsified:

\[
oxed{
	ext{flat electron core at atomic height}
+
	ext{single }\Gamma_0	ext{ sprite jump}
}
\]

cannot reproduce the atomic ladder using the current CANON constants.

Strongest failures:

- fixed circulation gives only one stable radius;
- one canonical circulation quantum carries only \(lpha^2/4=1.331284e-05\) atomic action quanta;
- exact \(L=n\hbar\) would require \(4/lpha^2=75115.460282\) core circulation units per \(n\), which is not an integer;
- the naive radius ratio is \(lpha^4/16=1.772317e-10\);
- the literal atomic circumference is 14414.086 times the trefoil core length;
- the factor 15 leaves an additional action deficit of 5007.697.

## What survives

A microscopic core plus a distinct atomic-scale envelope remains viable as a research hypothesis.
The Toroflux deformation can serve as a shape/coupling variable, while the \(n\)-ladder must come
from envelope action variables and real dynamical eigenmodes.
