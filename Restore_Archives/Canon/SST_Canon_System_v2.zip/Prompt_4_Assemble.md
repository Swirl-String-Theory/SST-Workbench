
MODE: INTEGRATION

TASK:
Merge all sections into final LaTeX document.
