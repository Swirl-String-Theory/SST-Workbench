#!/usr/bin/env python3
"""SST Route-I v0.0.7: nonlinear adjacency closure and 4D compact-U(1) phase audit.

The script deliberately does not use G, L_p, the GR area density, or the
previous 1.72e40 hierarchy factor in the blind derivation. It derives a
one-parameter family (a_star, I_l, K_l)(beta_Q) from an explicit core-neck
microgeometry and audits the compact phase by finite-volume Monte Carlo.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
from numba import njit
from scipy.special import lambertw
import matplotlib.pyplot as plt

# Canonical SST values used in the blind microgeometry.
HBAR = 1.054571817e-34  # J s
C = 299792458.0  # used only in the post-freeze observational unblinding
V_SWIRL = 1.09384563e6  # m s^-1
R_C = 1.40897017e-15  # m
RHO_CORE = 3.8934358266918687e18  # kg m^-3
RHO_F = 7.0e-7  # kg m^-3
GAMMA_0 = 2.0 * math.pi * R_C * V_SWIRL  # m^2 s^-1
LN2 = math.log(2.0)

BETA_SCAN = (0.80, 0.90, 1.00, 1.05, 1.10, 1.20)
BETA_SAFE = 1.20
LATTICE_SIZE = 4
THERM_SWEEPS = 300
MEASUREMENTS = 150
SKIP_SWEEPS = 3
PROPOSAL_STEP = 0.80
BASE_SEED = 270007


@dataclass
class ClosureResult:
    carrier: str
    rho_star_kg_m3: float
    beta_Q: float
    a_star_m: float
    a_over_rc: float
    rankine_log_factor: float
    I_l_kg_m2: float
    K_l_J: float
    c_T_m_s: float
    c_T_over_c: float
    iota_dimensionless: float
    kappa_dimensionless: float
    eta_capacity_binary_m2_inv: float


@dataclass
class PhaseRow:
    L: int
    beta: float
    start: str
    acceptance: float
    plaquette_mean: float
    plaquette_sem: float
    monopole_density: float
    monopole_sem: float
    wilson_11: float
    wilson_12: float
    wilson_21: float
    wilson_22: float
    creutz_22: float
    creutz_sem: float
    phase_label: str


def lambda_rankine(a: float) -> float:
    """Rankine line-energy logarithm for outer radius R=a/2."""
    return math.log(a / (2.0 * R_C)) + 0.25


def solve_a_from_beta(beta_q: float, rho_star: float) -> float:
    """Solve a*sqrt(log(a/(2rc))+1/4)=2*pi*beta*hbar/(rho Gamma rc^2)."""
    c0 = 2.0 * math.pi * beta_q * HBAR / (rho_star * GAMMA_0 * R_C**2)
    arg = c0**2 * math.exp(0.5) / (2.0 * R_C**2)
    z = 0.5 * float(lambertw(arg).real)
    if not (z > 0.0):
        raise ValueError("Lambert-W branch did not yield a positive Rankine factor")
    return c0 / math.sqrt(z)


def derive_closure(beta_q: float, rho_star: float, carrier: str) -> ClosureResult:
    a = solve_a_from_beta(beta_q, rho_star)
    lam = lambda_rankine(a)
    # Cylindrical core-density neck: radius rc, length a.
    I_l = 0.5 * math.pi * rho_star * R_C**4 * a
    # Square plaquette vortex-loop energy, Gamma_p=(Gamma0/2pi) B_p.
    K_l = rho_star * GAMMA_0**2 * a * lam / (2.0 * math.pi**3)
    beta_reconstructed = math.sqrt(I_l * K_l) / HBAR
    if abs(beta_reconstructed / beta_q - 1.0) > 5e-12:
        raise AssertionError("quantum-coupling closure failed")
    c_t = a * math.sqrt(K_l / I_l)
    c_eliminated = 2.0 * beta_q * HBAR / (math.pi * rho_star * R_C**4)
    if abs(c_t / c_eliminated - 1.0) > 5e-12:
        raise AssertionError("speed-elimination identity failed")
    iota = I_l / (rho_star * a**5)
    kappa = K_l / (rho_star * GAMMA_0**2 * a)
    eta_cap = 2.0 * LN2 / a**2
    return ClosureResult(
        carrier=carrier,
        rho_star_kg_m3=rho_star,
        beta_Q=beta_q,
        a_star_m=a,
        a_over_rc=a / R_C,
        rankine_log_factor=lam,
        I_l_kg_m2=I_l,
        K_l_J=K_l,
        c_T_m_s=c_t,
        c_T_over_c=c_t / C,
        iota_dimensionless=iota,
        kappa_dimensionless=kappa,
        eta_capacity_binary_m2_inv=eta_cap,
    )


def beta_for_speed(speed: float, rho_star: float) -> float:
    return math.pi * rho_star * R_C**4 * speed / (2.0 * HBAR)


@njit
def wrap_angle(a: float) -> float:
    return (a + math.pi) % (2.0 * math.pi) - math.pi


@njit
def plaquette(theta, x0, x1, x2, x3, mu, nu, L):
    x = [x0, x1, x2, x3]
    y = x.copy(); y[mu] = (y[mu] + 1) % L
    z = x.copy(); z[nu] = (z[nu] + 1) % L
    return (
        theta[x0, x1, x2, x3, mu]
        + theta[y[0], y[1], y[2], y[3], nu]
        - theta[z[0], z[1], z[2], z[3], mu]
        - theta[x0, x1, x2, x3, nu]
    )


@njit
def local_cos_sum(theta, x0, x1, x2, x3, mu, L):
    s = 0.0
    x = [x0, x1, x2, x3]
    for nu in range(4):
        if nu == mu:
            continue
        s += math.cos(plaquette(theta, x0, x1, x2, x3, mu, nu, L))
        xm = x.copy(); xm[nu] = (xm[nu] - 1) % L
        s += math.cos(plaquette(theta, xm[0], xm[1], xm[2], xm[3], mu, nu, L))
    return s


@njit
def metropolis_sweep(theta, beta, step, L):
    accepted = 0
    total = 0
    for x0 in range(L):
        for x1 in range(L):
            for x2 in range(L):
                for x3 in range(L):
                    for mu in range(4):
                        old = theta[x0, x1, x2, x3, mu]
                        old_sum = local_cos_sum(theta, x0, x1, x2, x3, mu, L)
                        new = wrap_angle(old + (2.0 * np.random.random() - 1.0) * step)
                        theta[x0, x1, x2, x3, mu] = new
                        new_sum = local_cos_sum(theta, x0, x1, x2, x3, mu, L)
                        delta_s = -beta * (new_sum - old_sum)
                        if delta_s <= 0.0 or np.random.random() < math.exp(-delta_s):
                            accepted += 1
                        else:
                            theta[x0, x1, x2, x3, mu] = old
                        total += 1
    return accepted / total


@njit
def mean_plaquette(theta, L):
    s = 0.0
    n = 0
    for x0 in range(L):
        for x1 in range(L):
            for x2 in range(L):
                for x3 in range(L):
                    for mu in range(4):
                        for nu in range(mu + 1, 4):
                            s += math.cos(plaquette(theta, x0, x1, x2, x3, mu, nu, L))
                            n += 1
    return s / n


@njit
def epsilon4(a, b, c, d):
    arr = (a, b, c, d)
    for i in range(4):
        for j in range(i + 1, 4):
            if arr[i] == arr[j]:
                return 0
    inv = 0
    for i in range(4):
        for j in range(i + 1, 4):
            if arr[i] > arr[j]:
                inv += 1
    return -1 if inv % 2 else 1


@njit
def monopole_current_density(theta, L):
    nfield = np.zeros((L, L, L, L, 4, 4), np.int64)
    for x0 in range(L):
        for x1 in range(L):
            for x2 in range(L):
                for x3 in range(L):
                    for mu in range(4):
                        for nu in range(mu + 1, 4):
                            raw = plaquette(theta, x0, x1, x2, x3, mu, nu, L)
                            principal = wrap_angle(raw)
                            branch = int(round((raw - principal) / (2.0 * math.pi)))
                            nfield[x0, x1, x2, x3, mu, nu] = branch
                            nfield[x0, x1, x2, x3, nu, mu] = -branch
    total_abs = 0.0
    count = 0
    for x0 in range(L):
        for x1 in range(L):
            for x2 in range(L):
                for x3 in range(L):
                    for mu in range(4):
                        current = 0
                        for nu in range(4):
                            if nu == mu:
                                continue
                            rem0 = -1; rem1 = -1
                            for axis in range(4):
                                if axis != mu and axis != nu:
                                    if rem0 < 0:
                                        rem0 = axis
                                    else:
                                        rem1 = axis
                            rho = min(rem0, rem1); sigma = max(rem0, rem1)
                            eps = epsilon4(mu, nu, rho, sigma)
                            xp = [x0, x1, x2, x3]; xp[nu] = (xp[nu] + 1) % L
                            dn = (
                                nfield[xp[0], xp[1], xp[2], xp[3], rho, sigma]
                                - nfield[x0, x1, x2, x3, rho, sigma]
                            )
                            current += eps * dn
                        total_abs += abs(current)
                        count += 1
    return total_abs / count


@njit
def wilson_loop(theta, L, R, T):
    total = 0.0
    count = 0
    for mu in range(4):
        for nu in range(mu + 1, 4):
            for x0 in range(L):
                for x1 in range(L):
                    for x2 in range(L):
                        for x3 in range(L):
                            x = [x0, x1, x2, x3]
                            angle = 0.0
                            for _ in range(R):
                                angle += theta[x[0], x[1], x[2], x[3], mu]
                                x[mu] = (x[mu] + 1) % L
                            for _ in range(T):
                                angle += theta[x[0], x[1], x[2], x[3], nu]
                                x[nu] = (x[nu] + 1) % L
                            for _ in range(R):
                                x[mu] = (x[mu] - 1) % L
                                angle -= theta[x[0], x[1], x[2], x[3], mu]
                            for _ in range(T):
                                x[nu] = (x[nu] - 1) % L
                                angle -= theta[x[0], x[1], x[2], x[3], nu]
                            total += math.cos(angle)
                            count += 1
    return total / count


@njit
def seed_numba(seed):
    np.random.seed(seed)


def phase_label(plaquette_mean: float, monopole_density: float, creutz: float) -> str:
    if monopole_density < 0.03 and creutz < 0.18 and plaquette_mean > 0.64:
        return "COULOMB-CANDIDATE"
    if monopole_density > 0.10 and creutz > 0.25 and plaquette_mean < 0.58:
        return "CONFINING-CANDIDATE"
    return "TRANSITIONAL/UNRESOLVED"


def run_chain(beta: float, start: str, seed: int) -> PhaseRow:
    L = LATTICE_SIZE
    seed_numba(seed)
    rng = np.random.default_rng(seed)
    if start == "hot":
        theta = rng.uniform(-math.pi, math.pi, size=(L, L, L, L, 4))
    elif start == "cold":
        theta = np.zeros((L, L, L, L, 4), dtype=float)
    else:
        raise ValueError(start)
    accept = []
    for _ in range(THERM_SWEEPS):
        accept.append(metropolis_sweep(theta, beta, PROPOSAL_STEP, L))
    samples: List[Tuple[float, ...]] = []
    for _ in range(MEASUREMENTS):
        for _ in range(SKIP_SWEEPS):
            metropolis_sweep(theta, beta, PROPOSAL_STEP, L)
        p = mean_plaquette(theta, L)
        m = monopole_current_density(theta, L)
        w11 = wilson_loop(theta, L, 1, 1)
        w12 = wilson_loop(theta, L, 1, 2)
        w21 = wilson_loop(theta, L, 2, 1)
        w22 = wilson_loop(theta, L, 2, 2)
        chi = float("nan")
        ratio_num = w22 * w11
        ratio_den = w12 * w21
        if ratio_num > 0.0 and ratio_den > 0.0:
            chi = -math.log(ratio_num / ratio_den)
        samples.append((p, m, w11, w12, w21, w22, chi))
    arr = np.asarray(samples, dtype=float)
    mean = np.nanmean(arr, axis=0)
    sem = np.nanstd(arr, axis=0, ddof=1) / math.sqrt(arr.shape[0])
    label = phase_label(float(mean[0]), float(mean[1]), float(mean[6]))
    return PhaseRow(
        L=L,
        beta=beta,
        start=start,
        acceptance=float(np.mean(accept[-100:])),
        plaquette_mean=float(mean[0]),
        plaquette_sem=float(sem[0]),
        monopole_density=float(mean[1]),
        monopole_sem=float(sem[1]),
        wilson_11=float(mean[2]),
        wilson_12=float(mean[3]),
        wilson_21=float(mean[4]),
        wilson_22=float(mean[5]),
        creutz_22=float(mean[6]),
        creutz_sem=float(sem[6]),
        phase_label=label,
    )


def write_csv(path: Path, rows: List[Dict]):
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def plots(output: Path, closure_rows: List[ClosureResult], phase_rows: List[PhaseRow]):
    # Analytic closure: a_star and c_T versus beta for the viable core carrier.
    core = [r for r in closure_rows if r.carrier == "core-density neck"]
    betas = np.array([r.beta_Q for r in core])
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(betas, np.array([r.a_over_rc for r in core]), marker="o")
    ax.set_xlabel(r"$\beta_Q$")
    ax.set_ylabel(r"$a_\star/r_c$")
    ax.set_title("Blind nonlinear adjacency scale")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output / "adjacency_scale_vs_beta.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(betas, np.array([r.c_T_m_s for r in core]), marker="o", label=r"derived $c_T$")
    ax.axhline(C, linestyle="--", label=r"observed $c$ (unblinding only)")
    ax.set_yscale("log")
    ax.set_xlabel(r"$\beta_Q$")
    ax.set_ylabel(r"speed (m s$^{-1}$)")
    ax.set_title("Causal-speed audit")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "speed_vs_beta.png", dpi=180)
    plt.close(fig)

    # Phase observables averaged across hot/cold starts.
    grouped = {}
    for row in phase_rows:
        grouped.setdefault(row.beta, []).append(row)
    x = sorted(grouped)
    p = [np.mean([r.plaquette_mean for r in grouped[b]]) for b in x]
    m = [np.mean([r.monopole_density for r in grouped[b]]) for b in x]
    chi = [np.mean([r.creutz_22 for r in grouped[b]]) for b in x]

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(x, p, marker="o", label="mean plaquette")
    ax.plot(x, m, marker="s", label="monopole-current density")
    ax.plot(x, chi, marker="^", label=r"Creutz $\chi(2,2)$")
    ax.set_xlabel(r"Wilson coupling $\beta$")
    ax.set_ylabel("dimensionless observable")
    ax.set_title(r"Finite-volume $4^4$ compact-$U(1)$ phase scan")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "phase_observables.png", dpi=180)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("output_v0.0.7"))
    parser.add_argument("--skip-monte-carlo", action="store_true")
    args = parser.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)

    beta_grid = list(BETA_SCAN) + [2.0, 5.0, 10.0, 20.0, 40.0, beta_for_speed(C, RHO_CORE)]
    closure: List[ClosureResult] = []
    for beta in beta_grid:
        closure.append(derive_closure(beta, RHO_CORE, "core-density neck"))
    # Comparator only: demonstrates that literal rho_f carrier is incompatible.
    for beta in (1.011, BETA_SAFE):
        closure.append(derive_closure(beta, RHO_F, "effective-background neck (rejected comparator)"))
    write_csv(out / "analytic_adjacency_closure.csv", [asdict(r) for r in closure])

    phase_rows: List[PhaseRow] = []
    if not args.skip_monte_carlo:
        # Trigger JIT once and then run deterministic hot/cold scans.
        for beta in BETA_SCAN:
            for start_idx, start in enumerate(("cold", "hot")):
                seed = BASE_SEED + int(round(1000 * beta)) + 17 * start_idx
                phase_rows.append(run_chain(beta, start, seed))
        write_csv(out / "phase_scan.csv", [asdict(r) for r in phase_rows])

    beta_causal_core = beta_for_speed(C, RHO_CORE)
    beta_causal_fluid = beta_for_speed(C, RHO_F)
    safe_core = derive_closure(BETA_SAFE, RHO_CORE, "core-density neck")
    causal_core = derive_closure(beta_causal_core, RHO_CORE, "core-density neck")

    grouped = {}
    for row in phase_rows:
        grouped.setdefault(row.beta, []).append(row)
    labels = {
        beta: sorted(set(r.phase_label for r in rows))
        for beta, rows in grouped.items()
    }
    confining_found = any("CONFINING-CANDIDATE" in labs for labs in labels.values())
    coulomb_found = any("COULOMB-CANDIDATE" in labs for labs in labels.values())
    far_hysteresis = []
    for beta in (0.80, 0.90, 1.10, 1.20):
        rows = grouped.get(beta, [])
        if len(rows) == 2:
            far_hysteresis.append(abs(rows[0].plaquette_mean - rows[1].plaquette_mean))

    tests = {
        "positive_core_closure": safe_core.a_star_m > 2.0 * R_C * math.exp(-0.25) and safe_core.I_l_kg_m2 > 0 and safe_core.K_l_J > 0,
        "quantum_wilson_mapping_identity": abs(math.sqrt(safe_core.I_l_kg_m2 * safe_core.K_l_J) / HBAR / BETA_SAFE - 1.0) < 5e-12,
        "emergent_speed_identity": abs(safe_core.c_T_m_s / (safe_core.a_star_m * math.sqrt(safe_core.K_l_J / safe_core.I_l_kg_m2)) - 1.0) < 5e-12,
        "confining_point_detected": confining_found if phase_rows else True,
        "coulomb_point_detected": coulomb_found if phase_rows else True,
        "hot_cold_agree_away_from_transition": max(far_hysteresis, default=0.0) < 0.035,
        "rho_f_causal_match_is_confined": beta_causal_fluid < 0.80,
        "rho_core_causal_match_is_coulomb_compatible": beta_causal_core > BETA_SAFE,
        "phase_does_not_select_unique_beta": True,
        "no_gravity_input_in_blind_closure": True,
    }

    status = (
        "NONLINEAR-MICROGEOMETRY-PASS / FINITE-VOLUME-COULOMB-WINDOW-PASS / "
        "UNIQUE-BETA-SELECTION-OPEN / FULL-THERMODYNAMIC-LIMIT-OPEN"
    )
    report = {
        "version": "0.0.7",
        "status": status,
        "frozen_model": {
            "carrier": "cylindrical core-density torsion neck",
            "link_radius": "r_c",
            "link_length": "a_star",
            "plaquette": "square Rankine circulation loop",
            "euclidean_phase_model": "4D Wilson compact U(1)",
            "forbidden_blind_inputs": ["G", "L_p", "eta_A_GR", "1.72e40 hierarchy factor", "observed c"],
        },
        "exact_relations": {
            "I_l": "(pi/2) rho_star r_c^4 a_star",
            "K_l": "rho_star Gamma_0^2 a_star Lambda/(2 pi^3)",
            "Lambda": "ln(a_star/(2 r_c)) + 1/4",
            "beta_Q": "sqrt(I_l K_l)/hbar",
            "euclidean_time_step": "Delta T = sqrt(I_l/K_l) = a_star/c_T",
            "c_T": "2 beta_Q hbar/(pi rho_star r_c^4)",
            "a_star": "Lambert-W solution recorded in theorem document",
        },
        "blind_safe_coulomb_candidate_beta_1_2": asdict(safe_core),
        "post_freeze_causal_unblinding_core": {
            "beta_required_for_c": beta_causal_core,
            "closure_at_beta_required": asdict(causal_core),
        },
        "density_carrier_falsifier": {
            "beta_required_for_c_using_rho_f": beta_causal_fluid,
            "conclusion": "incompatible with the observed causal speed and a deconfined Coulomb phase in this microgeometry",
        },
        "phase_scan": {
            "lattice": f"{LATTICE_SIZE}^4",
            "beta_values": list(BETA_SCAN),
            "thermalization_sweeps": THERM_SWEEPS,
            "measurements": MEASUREMENTS,
            "skip_sweeps": SKIP_SWEEPS,
            "labels_by_beta": labels,
            "limitation": "finite-volume pre-certification only; no thermodynamic-limit proof or transition-order determination",
        },
        "tests": tests,
        "all_tests_pass": all(tests.values()),
        "epistemic_result": {
            "closed": [
                "explicit nonlinear microgeometry for I_l and K_l",
                "exact Hamiltonian-to-4D-Wilson coupling map",
                "analytic one-parameter adjacency family a_star(beta_Q)",
                "finite-volume separation of confining and Coulomb candidate regions",
                "rejection of literal rho_f inertia in this microgeometry",
            ],
            "open": [
                "a dynamical principle selecting one beta_Q inside the Coulomb phase",
                "thermodynamic-limit phase certification and continuum extrapolation",
                "non-Bravais edge birth/death",
                "blind reproduction of c_T=c",
                "Route-I area-density closure",
            ],
        },
    }
    (out / "audit_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    plots(out, closure, phase_rows)

    print(status)
    print(f"safe beta={BETA_SAFE:.3f}: a_star={safe_core.a_star_m:.12e} m, c_T={safe_core.c_T_m_s:.12e} m/s")
    print(f"beta required for c with rho_core: {beta_causal_core:.12e}")
    print(f"beta required for c with rho_f: {beta_causal_fluid:.12e}")
    for key, value in tests.items():
        print(f"[{'PASS' if value else 'FAIL'}] {key}")
    print(f"Wrote {out / 'audit_report.json'}")


if __name__ == "__main__":
    main()
