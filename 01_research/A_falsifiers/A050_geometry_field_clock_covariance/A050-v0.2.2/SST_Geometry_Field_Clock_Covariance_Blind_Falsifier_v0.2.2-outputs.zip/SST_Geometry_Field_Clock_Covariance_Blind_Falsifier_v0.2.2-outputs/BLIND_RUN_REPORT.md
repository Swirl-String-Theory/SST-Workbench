# BLIND RUN REPORT — v0.2.2

Verdict: `MODAL_PERSISTENCE_NOT_REPRODUCED`

## Gate summary

- Spatial covariance: PASS (4/4)
- Temporal memory reproduced: YES (4/4)
- Temporal memory converged: YES (2/4)
- Modal persistence reproduced: NO (0/4 groups)
- Modal numerical convergence: NO (0 qualified groups)
- Floquet policy: inactive; prior status `INDETERMINATE_NO_RECURRENCE`
- Divergence qualification: PASS
- Spatial resolution qualification: PASS

## Anonymous holdout groups

- H01: `MODAL_PERSISTENCE_GROUP_NOT_CONFIRMED`, branch=None, support=0/5.
- H02: `MODAL_PERSISTENCE_GROUP_NOT_CONFIRMED`, branch=None, support=0/5.
- H03: `MODAL_PERSISTENCE_GROUP_NOT_CONFIRMED`, branch=None, support=0/5.
- H04: `MODAL_PERSISTENCE_GROUP_NOT_CONFIRMED`, branch=3, support=1/5.

## Interpretation boundary

This report is blind. Anonymous holdout groups are not assigned geometry identities here. A confirmed transverse branch is a numerical persistence result under the frozen protocol, not an absolute physical wave-speed claim. Floquet/RPO inference is outside v0.2.2.
