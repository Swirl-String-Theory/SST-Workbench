#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SST chi-phase package v10B.0 — simulation runner.

Runs the full Track B GP/NLSE vortex-ring constant extraction and writes:
  - chi_v10B0_core_constants.csv
  - chi_v10B0_convergence.csv
  - chi_v10B0_profile_comparison.csv
  - chi_v10B0_euler_benchmark.csv
  - chi_v10B0_run_results_summary.txt
"""

import csv
import math
import os
import sys
import time
from pathlib import Path

# ---- ensure local package is importable ----
sys.path.insert(0, str(Path(__file__).parent))
import sst_chi_phase_v10B0_py as v10b

EXPORTS = Path(__file__).parent / "exports"
EXPORTS.mkdir(exist_ok=True)


def write_csv(path: Path, rows: list, fieldnames: list | None = None) -> None:
    if not rows:
        return
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def fmt(x: object, w: int = 22) -> str:
    if isinstance(x, bool):
        return str(x).ljust(w)
    if isinstance(x, float):
        return f"{x:.10e}".ljust(w)
    return str(x).ljust(w)


def run() -> None:
    t0 = time.perf_counter()

    print("SST chi-phase Track B: GP/NLSE vortex-ring constant extraction")
    print("=" * 65)
    print("Solving GP vortex ODE (BVP)...")
    data = v10b.run_track_b(r_left=0.02, r_right=20.0, R_eval=12.0)
    elapsed = time.perf_counter() - t0

    cr = data["core_results"]
    print(f"  BVP success: {data['success']},  nodes: {data['n_nodes_bvp']}")
    print(f"  C1* (axis slope) = {data['C1_star']:.7f}  (Pade: {data['pade_C1_star']:.7f})")
    print()
    print("Core constant decomposition (R_max = 12):")
    print(f"  C_kin   = {cr['C_kin']:.7f}   (KE deficit from density depletion)")
    print(f"  C_grad  = {cr['C_grad']:.7f}   (amplitude gradient energy)")
    print(f"  C_int   = {cr['C_int']:.7f}   (interaction / depletion)")
    print(f"  C_GP    = {cr['C_GP']:.7f}   (total)")
    print()
    print(f"Ring constant (core size a = xi = 1):")
    print(f"  alpha_GP(xi)  = 2 - C_GP = {cr['alpha_GP_a_eq_xi']:.7f}")
    print(f"  beta_GP (q=0) = alpha - 1 = {cr['beta_GP_q0_a_eq_xi']:.7f}")
    print()
    print(f"NLS legacy target (notebook):  alpha = {cr['NLS_legacy_alpha']:.5f}")
    print(f"Difference:                    {cr['delta_alpha_raw']:+.5f}  ({cr['delta_alpha_raw']/cr['NLS_legacy_alpha']*100:+.2f}%)")
    print()
    print(f"Convention analysis:")
    print(f"  To recover alpha = 1.61, effective core radius must be:")
    print(f"  a_eff = {cr['a_eff_to_match_NLS_xi']:.5f} * xi")
    print(f"  This is a CONVENTION gap, not a physics discrepancy.")
    print()
    print(f"Virial ratio C_grad/C_int = {cr['virial_ratio_grad_int']:.5f}")
    print()

    # Convergence table
    print("C_GP convergence with R_max:")
    for row in data["convergence"]:
        print(f"  R_max={row['R_max']:5.1f}: C_GP={row['C_GP']:.7f}  alpha={row['alpha_GP']:.7f}")
    print()

    # Euler benchmark
    print("Euler benchmark (alpha = 2 - C_core):")
    for row in data["euler_benchmark"]:
        ok = "✓" if row["match"] else "✗"
        print(f"  {row['model']:28s}  C={row['C_core_analytic']:.3f}  alpha={row['alpha_formula']:.4f}  {ok}")
    print()

    # Track comparison summary
    print("Track comparison:")
    print(f"  Track A (Euler, Rankine):        alpha_0 = 1.7404  (expected 1.75, -0.6%)")
    print(f"  Track A (Euler, smooth_a0*):     alpha_0 = 1.5047  (60 sigma below NLS 1.61)")
    print(f"  Track B (GP/NLSE, a=xi):         alpha   = {cr['alpha_GP_a_eq_xi']:.4f}")
    print(f"  NLS legacy (notebook):           alpha   = 1.6100  (convention: a=1.29*xi)")
    print()

    # Write CSV exports
    write_csv(EXPORTS / "chi_v10B0_core_constants.csv", [cr])
    write_csv(EXPORTS / "chi_v10B0_convergence.csv", data["convergence"])
    write_csv(EXPORTS / "chi_v10B0_profile_comparison.csv", data["profile"])
    write_csv(EXPORTS / "chi_v10B0_euler_benchmark.csv", data["euler_benchmark"])

    # Write summary text
    summary_lines = [
        "SST chi-phase package v10B.0 summary",
        "=" * 52,
        "",
        "Track: B — GP/NLSE core energy solver",
        "Status: Research Track / CANON-compatible",
        "",
        "Method:",
        "  1. Solve GP vortex ODE (BVP): F'' + F'/r - F/r^2 + F(1-F^2) = 0",
        "  2. Compute e(R)/pi = integral [F^2/r + F'^2 r + (F^2-1)^2 r/4] dr",
        "  3. C_GP = e(R)/pi - ln(R)  as R -> infinity",
        "  4. alpha_GP = 2 - C_GP  (core size a = xi in thin-ring formula)",
        "",
        f"BVP success:    {data['success']}",
        f"BVP nodes:      {data['n_nodes_bvp']}",
        f"C1* (slope at axis): {data['C1_star']:.7e}",
        f"Pade C1*:            {data['pade_C1_star']:.7e}  (Pade error at axis: {(data['pade_C1_star']-data['C1_star'])/data['C1_star']*100:.1f}%)",
        "",
        f"C_GP (R_max=12):  {cr['C_GP']:.7e}",
        f"  C_kin:          {cr['C_kin']:.7e}",
        f"  C_grad:         {cr['C_grad']:.7e}",
        f"  C_int:          {cr['C_int']:.7e}",
        f"  Sum check:      {cr['C_decomp_sum']:.7e}",
        "",
        f"alpha_GP (a=xi):  {cr['alpha_GP_a_eq_xi']:.7e}",
        f"beta_GP  (q=0):   {cr['beta_GP_q0_a_eq_xi']:.7e}",
        "",
        f"NLS legacy alpha: {cr['NLS_legacy_alpha']:.5f}",
        f"Difference:       {cr['delta_alpha_raw']:+.5e}  ({cr['delta_alpha_raw']/cr['NLS_legacy_alpha']*100:+.2f}%)",
        f"a_eff for NLS:    {cr['a_eff_to_match_NLS_xi']:.5f} * xi",
        "",
        "Convention gap diagnosis:",
        "  The difference alpha_GP(xi) - alpha_NLS = +0.258 is a CONVENTION gap.",
        "  alpha_NLS = 1.61 uses effective core radius a_eff = 1.29 * xi",
        "  where F(a_eff) ~ 0.63 (near-half-density point).",
        "  Physics is consistent once the core-radius convention is fixed.",
        "",
        "Track comparison:",
        f"  Track A (Rankine):    alpha0 = 1.7404  (Euler, no GP energy)",
        f"  Track A (smooth_a0*): alpha0 = 1.5047  (Euler, 60 sigma below NLS)",
        f"  Track B (GP, a=xi):   alpha  = {cr['alpha_GP_a_eq_xi']:.4f}",
        f"  NLS legacy:           alpha  = 1.6100  (a = 1.29*xi convention)",
        "",
        f"Elapsed: {elapsed:.2f} s",
    ]

    summary_path = EXPORTS / "chi_v10B0_run_results_summary.txt"
    with open(summary_path, "w") as f:
        f.write("\n".join(summary_lines) + "\n")

    print(f"Exports written to: {EXPORTS}")
    print(f"Elapsed: {elapsed:.2f} s")


if __name__ == "__main__":
    run()
