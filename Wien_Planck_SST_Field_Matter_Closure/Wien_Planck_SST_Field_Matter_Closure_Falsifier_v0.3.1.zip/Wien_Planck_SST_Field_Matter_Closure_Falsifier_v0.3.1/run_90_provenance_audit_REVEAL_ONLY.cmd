@echo off
setlocal EnableExtensions
pushd "%~dp0" || exit /b 1
set "PY=.venv\Scripts\python.exe"
set "OUTROOT=Wien_Planck_SST_Field_Matter_Closure_Falsifier_v0.3.1-outputs"
if not exist "%PY%" (echo ERROR: Run run_00_setup.cmd first. & popd & exit /b 1)
if not exist "%OUTROOT%" mkdir "%OUTROOT%"
"%PY%" -m sst_wp.provenance "%OUTROOT%\provenance_audit_REVEAL_ONLY.json" || exit /b 1
popd
endlocal
