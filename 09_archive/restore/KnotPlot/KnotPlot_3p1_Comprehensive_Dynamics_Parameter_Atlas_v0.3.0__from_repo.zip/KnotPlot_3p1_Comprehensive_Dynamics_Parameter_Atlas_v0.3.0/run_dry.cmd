@echo off
setlocal
cd /d "%~dp0"
python tests\selftest.py
exit /b %ERRORLEVEL%
