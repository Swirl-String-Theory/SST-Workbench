# A045 blind report

Overall: **PIPELINE_QUALIFIED**

HWC basis: **REJECTED_AS_LOCAL_COMPLETE_BASIS**
UWS basis: **STRUCTURALLY_ADMISSIBLE_NOT_VALIDATED_AS_GRAVITY**

## Key measurements

- max |div u| = 2.775558e-15
- HWC equality error = 0.000000e+00
- strain-pair distance = 5.656854e-01
- exact pressure/clock lock relative L2 = 0.000000e+00
- leading weak-speed lock relative L2 = 2.904099e-03
- Poisson reconstruction relative L2 = 2.846161e-16
- nonlocal Phi energy fraction = 6.546745e-02
- ABC curvature RMS = 2.325678e-03
- null curvature RMS = 0.000000e+00
- Riemann pair-symmetry relative L2 = 1.705612e-05
- objectivity maximum relative residual = 1.030454e-15

## Gates

- G01_INCOMPRESSIBILITY: PASS
- G02_HWC_DEGENERACY_FOUND: PASS
- G03_UWS_DISTINGUISHES_PAIR: PASS
- G04_CLOCK_PRESSURE_EXACT_LOCK: PASS
- G05_POISSON_RECONSTRUCTION: PASS
- G06_POISSON_NONLOCALITY: PASS
- G07_METRIC_LORENTZ_SIGNATURE_ABC: PASS
- G08_METRIC_LORENTZ_SIGNATURE_NULL: PASS
- G09_NULL_CURVATURE: PASS
- G10_NONUNIFORM_CURVATURE: PASS
- G11_RIEMANN_PAIR_SYMMETRY: PASS
- G12_OBJECTIVITY: PASS

## Scientific guard

A passing run qualifies only the mathematical/numerical construction. It does not establish that the exploratory metric is physical gravity.
