from pathlib import Path
import sys
from framework_bootstrap import load_framework
ROOT=Path(__file__).resolve().parent
FRAMEWORK_ROOT=load_framework()
from experiment.readiness import require_ready
from sst_falsifier.runner import run_mode
if __name__=='__main__':
    mode=sys.argv[1].upper() if len(sys.argv)>1 else 'BASIC'
    if mode!='SELFTEST': require_ready(ROOT)
    raise SystemExit(run_mode(ROOT,mode))
