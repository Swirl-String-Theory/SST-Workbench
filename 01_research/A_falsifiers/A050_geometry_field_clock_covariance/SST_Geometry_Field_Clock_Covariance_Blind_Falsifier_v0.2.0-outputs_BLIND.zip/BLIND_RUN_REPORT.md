# BLIND RUN REPORT — v0.2.0

Verdict: `TEMPORAL_MEMORY_DETECTED_KELVIN_NOT_RESOLVED`

## Gate summary

- Spatial covariance: PASS (4/4)
- Temporal memory: PASS (4/4)
- Transverse modal gate: NOT RESOLVED (0/4)
- Floquet gate: `INDETERMINATE_NO_RECURRENCE`
- Divergence qualification: PASS
- Resolution qualification: PASS (exponent span=0.583531)

## Family diagnostics

- G0001: spatial exponent=1.848259, null=3.065888, temporal exponent=2.000000, memory steps=1.950775, memory/null=1.827514, modal mode=3, modal fraction=0.335281, phase cycles=0.000000.
- G0002: spatial exponent=1.501571, null=3.026508, temporal exponent=1.841256, memory steps=7.062186, memory/null=7.062186, modal mode=3, modal fraction=0.947515, phase cycles=0.011166.
- G0003: spatial exponent=1.520462, null=3.032560, temporal exponent=2.003232, memory steps=6.057864, memory/null=6.057864, modal mode=2, modal fraction=0.704972, phase cycles=0.034743.
- G0004: spatial exponent=1.838191, null=3.034227, temporal exponent=2.020312, memory steps=7.035255, memory/null=7.035255, modal mode=2, modal fraction=0.770019, phase cycles=0.047780.

## Interpretation boundary

The blind verdict uses only dimensionless internal observables and decorrelated controls. The transverse-mode gate failed its preregistered phase-advance requirement in this run. The Floquet stage did not estimate multipliers because no nontrivial return was detected for the preregistered carrier. These are scientific outcomes, not runtime errors.
