# A069 v0.3.1 / D3H - 2015 historic trefoil static geometry tests

This incremental revision extends A069-v0.3.0 exact controls and D3 E011 static adapter without admitting any historical geometry as physical evidence. **It must be FREEZE-preregistered separately** against framework v1.0.9. `A069-v0.3.0` output/ledger/private commitments are immutable.

## Registered geometry
- `A_Fourier_2015_p32`: `(cos(t)+1.5*cos(2*t), sin(t)-1.5*sin(2*t), .35*sin(3*t))`, `[0,2π)`.
- `B_Torus_2015_p66`: `((2+cos(3*t))*cos(2*t), (2+cos(3*t))*sin(2*t), sin(3*t))`, `[0,2π)` (not double tracing `[0,4π]`).
- Data contain N=600 and N=1200 headerless `x y z` samples, no repeated final point, dimensionless only.
- A and B have three projected transverse crossings of opposite sign but are NOT congruent mirror images. `mirror(A)` and `mirror(B)` are separate parity controls.

## Gates (continuation of frozen v0.3.0 G0-G19)
- G20 SHA-256/exact raw source matching and no terminal duplicate: PASS or FAIL.
- G21 arc-length convergence, periodic closure, and nonzero edge spacing: PASS or FAIL.
- G22 3 XY transverse crossings, over/under sign +3/-3, exact reflected controls: PASS or FAIL.
- G23 finite-core pressure-Poisson / incompressible 3D Euler trajectory: **UNRESOLVED**.
- G24 independent material phase + held-out eigenfrequency: **UNRESOLVED**.

G20-G22 are static geometry diagnostic PASS, not physical qualification. No data from KnotPlot old relaxations, SST-28 negative result, synthetic angular tracer phase, or GP global gauge-phase can be promoted to physical clock evidence. Historical seeds are **not** a second provider for G9, G18, or G19.

## Future physical qualifying sequence
For each seed and reflected copy: choose and preregister a finite-core vorticity field with independently fixed circulation, pressure-Poisson boundary, and inertial frame. First verify `div(v)=0` and curl/pressure residual, then Euler time/space/core convergence, energy, helicity, Kelvin consistency, persistent topology, phase-definition invariance under frame rotation/gauge and blind precommitted holdout frequency. Clock property remains unresolved unless all hold.

### Research references (context, not physical SST proof)
\bibitem{Helmholtz1858} H. Helmholtz (1858), Ueber Integrale der hydrodynamischen Gleichungen, welche den Wirbelbewegungen entsprechen, Journal fuer die reine und angewandte Mathematik **55**, 25--55, https://doi.org/10.1515/crll.1858.55.25.
\bibitem{Saffman1992} P. G. Saffman (1992), Vortex Dynamics, Cambridge University Press, https://doi.org/10.1017/CBO9780511624063.
