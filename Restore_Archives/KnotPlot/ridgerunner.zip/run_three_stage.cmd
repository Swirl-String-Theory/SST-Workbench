@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem run_three_stage.cmd — recommended KnotPlot-seed tightening pipeline
rem
rem Usage:
rem   run_three_stage.cmd path\to\selected_trial.txt
rem   run_three_stage.cmd path\to\n300.txt --verbose
rem
rem Ideal short seed (n300.txt): canonical aliases n300c / n300e / n300p / p300 / u300
rem Other seeds: legacy stacked *_rr_*_{coarse,eqfinal,polish} names (catalog / -rr)
rem
rem Stage 1: -a --EqOn          coarse tighten (residual 0.05, max 10k)
rem Stage 2: -c --EqForceOn     equilateralize + converge (residual 0.01, max 50k)
rem Stage 3: -c --EqOn          unbiased polish (residual 0.01, max 20k)
rem Stage 4: uniform arc-length resample → u300.txt or *_polish_uniform_N300.txt

set "BUNDLE=%~dp0"
set "RR=%BUNDLE%ridgerunner.cmd"
set "ROOT=%BUNDLE%.."
set "RESAMPLE=%ROOT%\resample_closed_knot_txt.py"
set "TO_VECT=%ROOT%\knotplot_txt_to_vect.py"
set "SEED="
set "VERBOSE="
set "FORCE="
set "THREADS="

if "%~1"=="" goto :usage
if /I "%~1"=="-h" goto :usage
if /I "%~1"=="--help" goto :usage
if /I "%~1"=="/?" goto :usage

:parse
if "%~1"=="" goto after_parse
if /I "%~1"=="--verbose" (
  set "VERBOSE=--verbose"
  shift
  goto parse
)
if /I "%~1"=="-v" (
  set "VERBOSE=--verbose"
  shift
  goto parse
)
if /I "%~1"=="--force" (
  set "FORCE=1"
  shift
  goto parse
)
set "ARG=%~1"
if /I "!ARG:~0,10!"=="--Threads=" (
  set "THREADS=!ARG!"
  shift
  goto parse
)
if /I "%~1"=="--Threads" (
  if "%~2"=="" (
    echo ERROR: --Threads requires a value
    goto :usage
  )
  set "THREADS=--Threads=%~2"
  shift
  shift
  goto parse
)
if defined SEED (
  echo ERROR: unexpected argument: %~1
  goto :usage
)
set "SEED=%~f1"
shift
goto parse

:after_parse
if not defined SEED goto :usage

if not exist "%RR%" (
  echo ERROR: ridgerunner.cmd not found: "%RR%"
  exit /b 1
)
if not exist "%SEED%" (
  echo ERROR: seed not found: "%SEED%"
  exit /b 1
)

for %%F in ("%SEED%") do (
  set "SEED_DIR=%%~dpF"
  set "SEED_STEM=%%~nF"
)

set "SHORT=0"
if /I "%SEED_STEM%"=="n300" set "SHORT=1"

if "%SHORT%"=="1" (
  set "A1=%SEED_DIR%n300c.txt"
  set "A2=%SEED_DIR%n300e.txt"
  set "A3=%SEED_DIR%n300p.txt"
  set "A3MET=%SEED_DIR%n300p.metrics.json"
  set "P300=%SEED_DIR%p300.txt"
  set "R4=%SEED_DIR%u300.txt"
  set "LBL1=c"
  set "LBL2=e"
  set "LBL3=p"
  set "IN1=%SEED%"
  set "RR1=%SEED_DIR%n300_rr_010k_c.txt"
  set "IN2=%SEED_DIR%n300c.txt"
  set "RR2=%SEED_DIR%n300c_rr_050k_e.txt"
  set "IN3=%SEED_DIR%n300e.txt"
  set "RR3=%SEED_DIR%n300e_rr_030k_p.txt"
) else (
  set "A1=%SEED_DIR%%SEED_STEM%_rr_010k_coarse.txt"
  set "A2=%SEED_DIR%%SEED_STEM%_rr_010k_coarse_rr_050k_eqfinal.txt"
  set "A3=%SEED_DIR%%SEED_STEM%_rr_010k_coarse_rr_050k_eqfinal_rr_030k_polish.txt"
  set "A3MET=%SEED_DIR%%SEED_STEM%_rr_010k_coarse_rr_050k_eqfinal_rr_030k_polish.metrics.json"
  set "P300="
  set "R4=%SEED_DIR%%SEED_STEM%_rr_010k_coarse_rr_050k_eqfinal_rr_030k_polish_uniform_N300.txt"
  set "LBL1=coarse"
  set "LBL2=eqfinal"
  set "LBL3=polish"
  set "IN1=%SEED%"
  set "RR1=%A1%"
  set "IN2=%A1%"
  set "RR2=%A2%"
  set "IN3=%A2%"
  set "RR3=%A3%"
)

echo.
echo ============================================================
echo Three-stage ridgerunner
echo Seed: %SEED%
if "%SHORT%"=="1" echo Mode: short aliases ^(n300c / n300e / n300p^)
if defined VERBOSE echo Mode: verbose ^(full Rop lines^)
if defined FORCE (echo Mode: force ^(re-run existing checkpoints^)) else (echo Mode: resume ^(skip existing checkpoints^))
if defined THREADS echo Threads: %THREADS%
echo ============================================================

echo.
if not defined FORCE if exist "%A1%" (
  echo [1/3] coarse: skip ^(exists^)
  echo   %A1%
  goto after_coarse
)
echo [1/3] coarse: -a --EqOn -s 10000 --StopResidual=0.05 --label %LBL1%
echo Expect: %A1%
call "%RR%" -a --EqOn -s 10000 --StopResidual=0.05 --label %LBL1% !VERBOSE! !THREADS! "%IN1%"
if errorlevel 1 (
  echo ERROR: stage 1 ^(coarse^) failed
  exit /b 1
)
if not exist "%RR1%" (
  echo ERROR: stage 1 RR output missing: "%RR1%"
  exit /b 1
)
if /I not "%RR1%"=="%A1%" (
  copy /Y "%RR1%" "%A1%" >nul
  if errorlevel 1 (
    echo ERROR: could not write alias "%A1%"
    exit /b 1
  )
)
:after_coarse

echo.
if not defined FORCE if exist "%A2%" (
  echo [2/3] eqfinal: skip ^(exists^)
  echo   %A2%
  goto after_eqfinal
)
if not exist "%A1%" (
  echo ERROR: stage 1 output missing for eqfinal: "%A1%"
  exit /b 1
)
echo [2/3] eqfinal: -c --EqForceOn -s 50000 --StopResidual=0.005 --label %LBL2%
echo Expect: %A2%
call "%RR%" -c --EqForceOn -s 50000 --StopResidual=0.005 --Stop20=0.000001 --label %LBL2% !VERBOSE! !THREADS! "%IN2%"
if errorlevel 1 (
  echo ERROR: stage 2 ^(eqfinal^) failed
  exit /b 1
)
if not exist "%RR2%" (
  echo ERROR: stage 2 RR output missing: "%RR2%"
  exit /b 1
)
if /I not "%RR2%"=="%A2%" (
  copy /Y "%RR2%" "%A2%" >nul
  if errorlevel 1 (
    echo ERROR: could not write alias "%A2%"
    exit /b 1
  )
)
:after_eqfinal

echo.
if not defined FORCE if exist "%A3%" (
  echo [3/3] polish: skip ^(exists^)
  echo   %A3%
  goto after_polish
)
if not exist "%A2%" (
  echo ERROR: stage 2 output missing for polish: "%A2%"
  exit /b 1
)
echo [3/3] polish: -c --EqOn -s 30000 --StopResidual=0.005 --label %LBL3%
echo Expect: %A3%
call "%RR%" -c --EqOn -s 30000 --StopResidual=0.005 --Stop20=0.0000001 --label %LBL3% !VERBOSE! !THREADS! "%IN3%"
if errorlevel 1 (
  echo ERROR: stage 3 ^(polish^) failed
  exit /b 1
)
if not exist "%RR3%" (
  echo ERROR: stage 3 RR output missing: "%RR3%"
  exit /b 1
)
if /I not "%RR3%"=="%A3%" (
  copy /Y "%RR3%" "%A3%" >nul
  if errorlevel 1 (
    echo ERROR: could not write alias "%A3%"
    exit /b 1
  )
)
set "RR3MET=%RR3:.txt=.metrics.json%"
if exist "%RR3MET%" if /I not "%RR3MET%"=="%A3MET%" (
  copy /Y "%RR3MET%" "%A3MET%" >nul
)
:after_polish

if defined P300 (
  copy /Y "%A3%" "%P300%" >nul
  if errorlevel 1 (
    echo ERROR: could not write ladder stem "%P300%"
    exit /b 1
  )
)

echo.
if not defined FORCE if exist "%R4%" (
  echo [4/4] VortexLab uniform resample: skip ^(exists^)
  echo   %R4%
  goto after_uniform
)
echo [4/4] VortexLab uniform resample: N=300 per component
if not exist "%RESAMPLE%" (
  echo ERROR: missing "%RESAMPLE%"
  exit /b 1
)
where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: python not found on PATH
  exit /b 1
)
if "%SHORT%"=="1" (
  python "%RESAMPLE%" "%A3%" --points 300 --output "%R4%"
) else (
  python "%RESAMPLE%" "%A3%" --points 300
)
if errorlevel 1 (
  echo ERROR: uniform resample failed
  exit /b 1
)

if not exist "%R4%" (
  echo ERROR: uniform output missing: "%R4%"
  exit /b 1
)

if exist "%TO_VECT%" (
  python "%TO_VECT%" "%R4%" --overwrite
  if errorlevel 1 (
    echo WARNING: VECT conversion failed for uniform TXT
  )
) else (
  echo WARNING: knotplot_txt_to_vect.py not found; skipped VECT
)
:after_uniform

echo.
echo Done. Catalog pair:
echo   Ridgerunner polish ^(audit^): %A3%
echo   VortexLab uniform N=300:     %R4%
echo Do not re-run Ridgerunner on the uniform file.
exit /b 0

:usage
echo.
echo Usage: run_three_stage.cmd path\to\seed.txt [--verbose] [--force] [--Threads=N]
echo.
echo Ideal seed n300.txt uses short aliases n300c / n300e / n300p / p300 / u300.
echo Other seeds keep legacy stacked *_rr_*_{coarse,eqfinal,polish} names.
echo.
echo Stage 1: -a --EqOn -s 10000 --StopResidual=0.05
echo Stage 2: -c --EqForceOn -s 50000 --StopResidual=0.005 --Stop20=0.000001
echo Stage 3: -c --EqOn -s 30000 --StopResidual=0.005 --Stop20=0.0000001
echo Stage 4: resample_closed_knot_txt.py --points 300
echo.
echo   --verbose / -v   pass through to ridgerunner ^(full Rop lines^)
echo   --force          re-run stages even if checkpoint outputs exist
echo   --Threads=N      native OpenMP thread count ^(capital T^)
echo.
exit /b 1

exit /b 1




