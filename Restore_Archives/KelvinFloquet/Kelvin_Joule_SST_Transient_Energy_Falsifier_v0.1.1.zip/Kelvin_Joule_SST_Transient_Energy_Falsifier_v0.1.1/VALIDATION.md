# Validation status for the generated v0.1.1 package

Generation-environment checks performed before packaging:

- `python -m py_compile` on the Python modules: PASS.
- host C++17 syntax check of `cpp/native.cpp` with the available pybind11 headers: PASS.
- `pytest`: 8 passed, 1 skipped.
- full tiny blind pipeline on synthetic torus-knot data with Python backend: PASS.
- basic demo campaign (circle + trefoil-shaped sampled curve) with Python backend: PASS; 0 energy-gate failures in that smoke run.
- Native/SYCL binary build was **not** executed in the generation environment because `pybind11` was not installed there; native parity is automatically exercised by the included tests once the extension is built on the target machine.

The package contains the original template's hash-based build mechanism and oneAPI device probe, modified for the Kelvin–Joule kernels.


## v0.1.1 maintenance validation

- Fixed DPC++ accessor type-deduction error by using separate accessor declarations.
- Added regression coverage for NumPy environments where `np.trapezoid` exists and `np.trapz` does not.
- The exact Intel Arc/Level Zero runtime still requires execution on the target Windows oneAPI machine.
