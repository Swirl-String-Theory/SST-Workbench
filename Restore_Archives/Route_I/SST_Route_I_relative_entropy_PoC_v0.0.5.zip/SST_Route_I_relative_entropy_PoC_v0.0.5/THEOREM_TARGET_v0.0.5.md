# Theorem Target v0.0.5 — Three-Branch Entropy Budget

## Status

\[
\boxed{\text{PARALLEL RESEARCH TRACK / TWO NO-GO RESULTS / ONE OPEN BRANCH}}
\]

## Shared entropy-rate formulation

For a boundary patch with effective channel density \(n_{\rm ch}\), define

\[
\eta_{\rm cap}=n_{\rm ch}h_{\rm rate},
\qquad
\eta_{\rm rel}=n_{\rm ch}d_{\rm rate}.
\]

Here \(h_{\rm rate}\) is the usable microstate capacity per channel and
\(d_{\rm rate}\) is the relative-distinguishability response per channel. A
reversible area encoding must obey

\[
\eta_{\rm cap}\ge\eta_{\rm rel},
\]

and the ideal Route-I identity requires equality.

## Branch A — collective correlations

For Gaussian coherent shifts with covariance \(C\),

\[
D_C=\frac12\boldsymbol\mu^{\mathsf T}C^{-1}\boldsymbol\mu.
\]

If the excitation lies in an eigenmode of variance \(\lambda_\parallel\),

\[
\chi_{\rm corr}=\frac{D_C}{D_I}=\lambda_\parallel^{-1}.
\]

Closing the full v0.0.4 deficit by this mechanism alone requires

\[
\lambda_\parallel=5.8066\times10^{-41},
\qquad
r=\frac12\ln\chi_{\rm corr}=46.3235,
\]

or approximately \(402.36\,\mathrm{dB}\) variance squeezing. At the canonical
core frequency \(\Omega_0=\mathbf v_{\!\boldsymbol{\circlearrowleft}}/r_c\),
the corresponding conditional oscillator occupation is
\(4.31\times10^{39}\).

However, correlations do not enlarge the cardinality \(q^N\) of a fixed
\(N\)-channel, \(q\)-state alphabet. Therefore they cannot by themselves raise
\(\eta_{\rm cap}\). Any hidden collective modes that do enlarge capacity must
be booked under Branch B or C.

\[
\boxed{\text{A alone: rejected as the capacity closure.}}
\]

## Branch B — internal topological degeneracy

For \(n_\perp\) core piercings,

\[
\eta_A=n_\perp\ln q_{\rm top}.
\]

The required local topological entropy is

\[
\ln q_{\rm top}=1.1937\times10^{40}\ \mathrm{nats/piercing}.
\]

Even under the deliberately generous growth law

\[
q_{\rm top}(C_r)=b^{C_r},
\]

with \(b=10^6\), one needs

\[
C_r\ge8.64\times10^{38}.
\]

The generic thick-knot bound

\[
\operatorname{Rop}(K)\gtrsim2.135\,C_r^{3/4}
\]

then gives a centreline length above \(4.79\times10^{14}\,\mathrm m\) at
thickness \(r_c\). Thus ordinary localized centreline knot-type degeneracy
cannot supply the coefficient.

\[
\boxed{\text{B as centreline knot counting alone: rejected.}}
\]

A distinct internal field/topological alphabet not represented by centreline
crossing complexity remains open, but would be a new microscopic sector.

## Branch C — sub-core boundary sector

For a two-dimensional boundary spectrum with
\(k_{\max}=\pi/\ell_{\rm sub}\), Weyl counting gives

\[
\frac{N}{A}=\frac{g\,k_{\max}^2}{4\pi}
=\frac{g\pi}{4\ell_{\rm sub}^2}.
\]

With \(q\) states per mode,

\[
\eta_A^{\rm sub}
=\frac{g\pi\ln q}{4\ell_{\rm sub}^2}.
\]

The inverse audit for \(g=1,q=2\) requires

\[
\ell_{\rm sub}=2.3851\times10^{-35}\,\mathrm m.
\]

This number is not inserted into the candidate derivations. The script compares
it only after constructing several scales from
\(r_c,\rho_{\!f},\rho_{\rm core},\hbar,c\), and
\(\mathbf v_{\!\boldsymbol{\circlearrowleft}}\). None of the currently
source-motivated candidates closes the target.

\[
\boxed{\text{C: open; target quantified, scale not derived.}}
\]

## Combined conclusion

A diagnostic enhancement allocation may be written

\[
E_{\rm corr}E_{\rm top}E_{\rm sub}=1.7222\times10^{40},
\]

but this is an inverse-problem map, not a fundamental factorization. The
capacity theorem removes pure correlation gain unless the associated modes are
also counted in \(q_{\rm top}\) or \(n_{\rm ch}\). The physically admissible
parallel search is therefore:

\[
\boxed{
\text{derive a sub-core mode density and its internal topological alphabet,}
\quad
\text{then calculate their correlation entropy rate.}
}
\]
