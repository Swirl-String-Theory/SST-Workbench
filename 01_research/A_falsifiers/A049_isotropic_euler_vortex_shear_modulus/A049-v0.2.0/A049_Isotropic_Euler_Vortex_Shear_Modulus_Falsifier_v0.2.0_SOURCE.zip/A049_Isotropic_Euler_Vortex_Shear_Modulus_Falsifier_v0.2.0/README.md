# A049 — Isotropic Euler-Vortex Shear-Modulus Falsifier v0.2.0

Research question:

\[
\boxed{\text{Can an isotropic Euler-vortex microstructure generate a nonzero, conservative transverse shear modulus?}}
\]

v0.2.0 retains the v0.1.0 frozen-in affine/Born result and adds the missing **dynamic persistence gate**. The blind calculation evolves a dealiased periodic 3D incompressible Euler background and simultaneously evolves small tangent-linear transverse helical probes.

## Dynamic model

The background is evolved in rotational form,

\[
\partial_t\mathbf u = \mathcal P(\mathbf u\times\boldsymbol\omega),
\qquad \boldsymbol\omega=\nabla\times\mathbf u,
\]

where \(\mathcal P\) is the divergence-free projector. A perturbation obeys the exact tangent-linear equation

\[
\partial_t\delta\mathbf u
=\mathcal P\!\left(
\delta\mathbf u\times\boldsymbol\omega
+\mathbf u\times\delta\boldsymbol\omega
\right).
\]

The preregistered physical signal is a coherent, weakly damped transverse pole with

\[
\omega(k)\simeq c_T k,
\]

that is direction-independent and helicity-degenerate.

## Gates

The release separates:

1. numerical qualification: incompressibility, base-energy conservation, initial statistical isotropy, RK4 local convergence, and the homogeneous-rest Euler no-wave control;
2. physical hypothesis gates: coherent pole, directional isotropy, helicity degeneracy, approximately linear dispersion, and a coarse-grid sign control;
3. the **Master-Factor Wave Closure Gate**, with blind target

\[
\frac{c_T}{v_*}=\frac12.
\]

The blind configuration contains no \(\alpha\), \(c\), \(r_c\), \(\rho_{\!f}\), \(\mathbf v_{\!\boldsymbol{\circlearrowleft}}\), or SST circulation value.

## Important scope guard

A negative v0.2.0 result is resolution-bounded. It rejects the specific tested isotropic spectral Euler microstructure at the tested scales; it is not a theorem excluding every topological vortex network or continuum limit.

## Run

Python reference campaign:

```bat
run_python.cmd
```

Full Python + C++17/pybind11/OpenMP campaign:

```bat
run_all.cmd
```

Outputs follow the Workbench blind/reveal packaging convention.
