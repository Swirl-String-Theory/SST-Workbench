@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo SST Katlas Source Crawler v0.2.1 - CURATED ONE-CLICK
echo RDF catalog + validation + curated wiki snapshots
echo ============================================================
call run_all.cmd || exit /b 1
call run_fetch_curated.cmd || exit /b 1
echo ============================================================
echo CURATED BUILD DONE
echo ============================================================
