LIST {
	{ < knot_10.1_trial_015k_rr_010k_coarse_rr_050k_eqfinal.10000.vect }
	{ < knot_10.1_trial_015k_rr_010k_coarse_rr_050k_eqfinal.10000.struts.vect }
	{ < knot_10.1_trial_015k_rr_010k_coarse_rr_050k_eqfinal.10000.dlen.vect }
	{ < knot_10.1_trial_015k_rr_010k_coarse_rr_050k_eqfinal.10000.dVdt.vect }
}
