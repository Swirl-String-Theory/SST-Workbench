# Research Track II - EM, gravity, relativity, inertia, and link action

## Slide 1/15 - High-risk bridge pack

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- EM, gravity, relativity, and inertia are tightly constrained.
- They require shared causal structure and source discipline.
- The link action is the current microstructure candidate.

**Single slide message:** EM, gravity, relativity, and inertia are tightly constrained.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 2/15 - Euler-decomposed swirl gravity

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Pressure acceleration is decomposed via Euler terms.
- Probe transport and Magnus-like effects must be separated.
- Dimensional/density checks are mandatory.

**Single slide message:** Pressure acceleration is decomposed via Euler terms.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 3/15 - Hybrid density-source benchmark

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Clock response may depend on density/source structure.
- Benchmarks compare candidate sources.
- No-monopole and boundary checks are required.

**Single slide message:** Clock response may depend on density/source structure.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 4/15 - Swirl-EM normalization by vorticity

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Direct vorticity sources can violate constraints.
- Electric-like fields may arise from time-dependent swirl or link response.
- Normalization remains open.

**Single slide message:** Direct vorticity sources can violate constraints.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 5/15 - Diagnostic modes

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Flame-lock, photonless caustic, and elastic shell tests are diagnostics.
- They probe mechanisms, not direct proof.
- Null hierarchy is required.

**Single slide message:** Flame-lock, photonless caustic, and elastic shell tests are diagnostics.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 6/15 - No-monopole audit

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Smooth compact stresses may fail to produce monopole terms.
- Boundary/singular-core exceptions must be explicit.
- Gravity source claims need this audit.

**Single slide message:** Smooth compact stresses may fail to produce monopole terms.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 7/15 - Atomic gravity and coherence

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Electron envelope may close an atomic gravity layer.
- Condensate/coherence effects are research candidates.
- Signatures require tests.

**Single slide message:** Electron envelope may close an atomic gravity layer.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 8/15 - Relativity emergence ladder

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Primitive substrate is not operational spacetime.
- Vortex atoms reconstruct clocks and rulers.
- Monometricity is a theorem target.

**Single slide message:** Primitive substrate is not operational spacetime.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 9/15 - Analogue metric and WEP

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Effective metrics come from perturbation characteristics.
- Weak equivalence requires universal coupling.
- Analogue success is not Einstein dynamics.

**Single slide message:** Effective metrics come from perturbation characteristics.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 10/15 - Einstein dynamics routes

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Candidate routes: clock action, pressure-source dynamics, emergent effective action.
- Each route has assumptions and falsifiers.
- Full Einstein equations are not closed.

**Single slide message:** Candidate routes: clock action, pressure-source dynamics, emergent effective action.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 11/15 - Cosmological impedance route

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Background density may be approached through impedance logic.
- This remains research.
- Provenance of calibration is critical.

**Single slide message:** Background density may be approached through impedance logic.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 12/15 - Minimal relational link-field action

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Links carry compact phases U_e=exp(i theta_e).
- Plaquette holonomy gives link curvature.
- Action uses link inertia I_l and stiffness K_l.
- IR speed: c_T = a_l sqrt(K_l/I_l).

**Single slide message:** Links carry compact phases U_e=exp(i theta_e).

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 13/15 - Core-torsion impedance matching

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Core response and torsion response may define inertia closure.
- Impedance matching can organize transitions.
- Requires independent coefficients and numerical tests.

**Single slide message:** Core response and torsion response may define inertia closure.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 14/15 - Taylor-column analogues

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Rotating-fluid analogues probe finite-thickness response.
- Parity tests distinguish chiral and achiral response.
- Analogues are diagnostics.

**Single slide message:** Rotating-fluid analogues probe finite-thickness response.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.

## Slide 15/15 - Research II closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Derive link coefficients, source normalization, monometricity, gravity source closure, tensor-speed gates, and bound impedance.

**Single slide message:** Derive link coefficients, source normalization, monometricity, gravity source closure, tensor-speed gates, and bound impedance.

**Source anchors:** EM/Gravity/Relativity/Inertia Research Tracks; Minimal Relational Link-Field Action.

**Visual specification:** Four bridge gates converging on minimal link-action microstructure.

**Do not generate:** Do not present theorem targets as completed derivations.
