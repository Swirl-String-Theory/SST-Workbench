"""Fit the four data sets with sigma(tau) = A * tau^(-1/2)."""

import csv
from pathlib import Path

import numpy as np


base_dir = Path(__file__).resolve().parents[1]
data_dir = base_dir / "data"
results_dir = base_dir / "results"

data_files = {
    "s1_pmt": "fig3_s1_pmt.csv",
    "s1_phototube": "fig3_s1_phototube.csv",
    "ts1_phototube": "fig3_ts1_phototube.csv",
    "ts1_phototube_optimized": "fig3_ts1_phototube_optimized.csv",
}


def read_data(filename):
    tau = []
    allan = []
    lower = []
    upper = []

    with open(data_dir / filename, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            tau.append(float(row["tau_s"]))
            allan.append(float(row["allan_deviation"]))
            lower.append(float(row["errorbar_lower"]))
            upper.append(float(row["errorbar_upper"]))

    return np.array(tau), np.array(allan), np.array(lower), np.array(upper)


def fit_data(tau, allan, lower, upper):
    log_error = (np.log(upper) - np.log(lower)) / 2
    weights = 1 / log_error**2
    log_a = np.sum(weights * (np.log(allan) + 0.5 * np.log(tau))) / np.sum(weights)
    return np.exp(log_a)


def main():
    results_dir.mkdir(exist_ok=True)

    parameter_rows = []
    line_rows = []
    line_tau = np.logspace(0, 4, 200)

    for name, filename in data_files.items():
        tau, allan, lower, upper = read_data(filename)
        amplitude = fit_data(tau, allan, lower, upper)

        parameter_rows.append(
            {
                "dataset_id": name,
                "model": "sigma(tau) = A * tau^(-1/2)",
                "amplitude_A": f"{amplitude:.17g}",
                "fixed_exponent": "-0.5",
                "weighting": "inverse_log_error_variance",
                "n_fit": len(tau),
                "tau_min_s": f"{tau.min():.4f}".rstrip("0").rstrip("."),
                "tau_max_s": f"{tau.max():.4f}".rstrip("0").rstrip("."),
            }
        )

        line_allan = amplitude * line_tau ** (-0.5)
        for i in range(len(line_tau)):
            line_rows.append(
                {
                    "dataset_id": name,
                    "tau_s": f"{line_tau[i]:.17g}",
                    "fitted_allan_deviation": f"{line_allan[i]:.17g}",
                }
            )

    parameter_file = results_dir / "fit_parameters.csv"
    with open(parameter_file, "w", encoding="utf-8", newline="") as f:
        columns = [
            "dataset_id",
            "model",
            "amplitude_A",
            "fixed_exponent",
            "weighting",
            "n_fit",
            "tau_min_s",
            "tau_max_s",
        ]
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(parameter_rows)

    line_file = results_dir / "fit_lines.csv"
    with open(line_file, "w", encoding="utf-8", newline="") as f:
        columns = ["dataset_id", "tau_s", "fitted_allan_deviation"]
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(line_rows)

    for row in parameter_rows:
        print(row["dataset_id"], "A =", row["amplitude_A"], "n =", row["n_fit"])


if __name__ == "__main__":
    main()
