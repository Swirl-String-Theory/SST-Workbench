from __future__ import annotations

from pathlib import Path
import time
import urllib.parse
import urllib.request

from .downloader import USER_AGENT


def fetch_raw_page(katlas_id: str, dest: Path, delay_seconds: float = 0.8) -> str:
    """Fetch one MediaWiki raw source page on demand. Not used for bulk import."""
    query = urllib.parse.urlencode({"title": katlas_id, "action": "raw"})
    url = f"https://katlas.org/index.php?{query}"
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=60) as response:
        text = response.read().decode("utf-8", errors="replace")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8")
    time.sleep(max(0.0, delay_seconds))
    return url
