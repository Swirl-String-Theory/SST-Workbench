# SST emergent-SR calculations — verification scripts

Every numerical and symbolic calculation used in the emergent-SR foundational
discussion, as standalone, self-checking Python scripts. Each script prints its
result and asserts the claim it supports (it exits non-zero if a check fails).
Companion to `SST_emergent_SR_foundational_audit.md`.

## Run

```bash
python3 run_all.py          # runs all scripts, reports PASS/FAIL
# or individually:
python3 s1_boost_algebra.py
```

Requires `numpy` and `sympy` only.

## Script index

| script | audit § | turn | claim verified | status |
|---|---|---|---|---|
| `s1_boost_algebra.py` | §1 | 10 | Galilei `[K,K]=0,[K,P]=im` vs Poincaré `[K,K]~J/c²,[K,P]~H/c²`; İnönü–Wigner `c→∞` contraction. Incompressible ⇒ Galilei ⇒ no γ. | [DERIVED] |
| `s2_sine_gordon_breather.py` | §1 | 10 | A □-governed soliton clock dilates by **exactly** γ and contracts by 1/γ (measured numerically). A Galilean soliton does not. | [DERIVED] |
| `s3_lv_dispersion_scale.py` | §2 | 11–12 | `E_LV=ℏc/ξ=m_eff c²`; Bogoliubov n=2 dispersion; `ξ=r_c→140 MeV` excluded ~11 orders; superluminal sign. | [DERIVED] / [FALSIFIED for ξ=r_c] |
| `s4_parity_lv_coefficients.py` | §3 | 15–16 | `h=v·ω` pseudoscalar; parity-even `F□F` (a_γ≲1e-24, needs full LI) vs parity-odd birefringence (b_γ≲1e-29, needs only parity `⟨h⟩=0`). | [DERIVED] |
| `s5_spherical_designs.py` | §5 | 17 | Cube = spherical 2-design ⇒ isotropic leading photon cone; cube is a 3-design so dim-6 cubic anisotropy survives; icosahedron (5-design) kills it. | [DERIVED] |
| `s6_trefoil_isotropy.py` | §6 | 17–18 | Static trefoil gyration tensor is uniaxial (anisotropic); O-orientation average is exactly isotropic. Mechanism = orientational delocalization, not static sampling. | [DERIVED] / [DERIVED NEGATIVE for static] |
| `s7_crystallographic_restriction.py` | §7 | 19 | Lattice-compatible rotations are n=1,2,3,4,6 only; 5-fold (icosahedral) forbidden ⇒ no icosahedral crystal. | [DERIVED NEGATIVE] |
| `s8_OI_pairing_channels.py` | §7 | 23 | Lowest cubic harmonic l=4, lowest icosahedral l=6 ⇒ continuous O/I superfluid nodes need exotic l≥4 / unphysical l=6 pairing. | [DERIVED NEGATIVE] |

## Notes on scope and honesty

- These scripts verify the **internal logic** of each step. They do not, and cannot,
  establish that SST is correct — several steps are `[DERIVED NEGATIVE]` (a route is
  closed) and the foundational target-space layer remains `[OPEN/UNBUILT]`.
- `s1` and `s2` are the two results previously asserted only on paper; they are now
  reproducible (symbolic algebra and a numerical soliton-clock measurement).
- Two self-corrections from the discussion are encoded in the scripts: `s4` reflects
  the retraction of the "torsion ⇒ birefringence self-undermining" claim (a mode
  carrying helicity ≠ a vacuum with `⟨h⟩≠0`); `s6` reflects that L_K is
  orientation-invariant, so the α-program survives orientational delocalization.
- Physical inputs used: `r_c = 1.40897017e-15 m` (swirl-string core radius),
  CODATA constants, the trefoil ropelength only implicitly (s6 uses a trefoil curve,
  not its certified length). No observed value of α is used anywhere.
