"""
Relational process clocks and the collapse score.

Clock families implemented
--------------------------
tau_Q      (t_c/Q_c) * int |dQ|                unsigned activity clock
tau_Q_sgn  (t_c/Q_c) * (Q(t)-Q(0))             signed flux clock (canon-compatible
                                               with the conserved-current
                                               definition of relational time)
tau_pair   int (dQ/dphi)|dphi| = int sgn(dphi) dQ
                                               FAITHFUL translation of
                                               Barontini Eq. (3): needs a second
                                               clock field phi, CAN decrease
tau_S      t_c * int |dS_spec|                 spectral (nats, no k_B)
tau_F      t_c * int sqrt( sum dp_n^2 / p_n )  Fisher-Rao path length

Score
-----
Every clock is normalised to [0,1] before scoring, so the SST prefactors
(t_c, Q_c) cancel identically. This is verified numerically in check 1.

    E[clock] = int_0^1 Var_runs[ Yhat(tauhat) ] dtauhat

with Yhat z-scored over the pooled ensemble. Lower is better collapse.
Comparing E[tau_Q] against E[t] alone is NOT a test: tau_Q is a monotone
reparametrisation of t and monotone warps generically improve collapse.
The test is against a matched null ensemble of random monotone warps.
"""
from __future__ import annotations

import numpy as np


# ---------------------------------------------------------------------------
# clock constructors
# ---------------------------------------------------------------------------
def cumulative_abs(q: np.ndarray) -> np.ndarray:
    return np.concatenate([[0.0], np.cumsum(np.abs(np.diff(q)))])


def cumulative_signed(q: np.ndarray) -> np.ndarray:
    return q - q[0]


def tau_pair(q: np.ndarray, phi: np.ndarray) -> np.ndarray:
    """
    Faithful discretisation of tau(lambda) = int (dS/dphi) |dphi|
    = int sgn(dphi) dS. Non-monotone by construction when dq and dphi
    disagree in sign -- exactly the 'wiggles' reported in the source paper.
    """
    dq = np.diff(q)
    dphi = np.diff(phi)
    return np.concatenate([[0.0], np.cumsum(np.sign(dphi) * dq)])


def spectral_probs(P: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    P = np.clip(P, 0.0, None) + eps
    return P / P.sum(axis=-1, keepdims=True)


def shannon_nats(P: np.ndarray) -> np.ndarray:
    p = spectral_probs(P)
    return -np.sum(p * np.log(p), axis=-1)


def fisher_rao_path(P: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """Cumulative Fisher-Rao length along the sequence of spectra P[t, n]."""
    p = spectral_probs(P, eps=eps)
    dp = np.diff(p, axis=0)
    mid = 0.5 * (p[1:] + p[:-1])
    ds = np.sqrt(np.sum(dp**2 / np.maximum(mid, eps), axis=1))
    return np.concatenate([[0.0], np.cumsum(ds)])


def bright_dark_energy(P: np.ndarray, n_star: int) -> tuple[np.ndarray, np.ndarray]:
    """Spectral bright/dark partition: bright = modes 1..n_star."""
    return P[:, :n_star].sum(axis=1), P[:, n_star:].sum(axis=1)


# ---------------------------------------------------------------------------
# normalisation and scoring
# ---------------------------------------------------------------------------
def is_monotone(x: np.ndarray, tol: float = 1e-14) -> bool:
    return bool(np.all(np.diff(x) >= -tol))


def normalise_clock(x: np.ndarray) -> np.ndarray | None:
    """Map a monotone clock onto [0,1]. Returns None if unusable."""
    if not is_monotone(x):
        return None
    rng = x[-1] - x[0]
    if not np.isfinite(rng) or rng <= 0:
        return None
    return (x - x[0]) / rng


def zscore_pool(Ys: list[np.ndarray]) -> list[np.ndarray]:
    allv = np.concatenate(Ys)
    mu, sd = allv.mean(), allv.std()
    sd = sd if sd > 0 else 1.0
    return [(y - mu) / sd for y in Ys]


def collapse_score(clocks: list[np.ndarray], Ys: list[np.ndarray], M: int = 200) -> float:
    """
    E = int_0^1 Var_runs[Yhat(tauhat)] dtauhat, evaluated on a common grid.
    clocks must already be normalised to [0,1].
    """
    grid = np.linspace(0.0, 1.0, M)
    stack = []
    for cl, y in zip(clocks, Ys):
        stack.append(np.interp(grid, cl, y))
    A = np.array(stack)
    return float(np.trapezoid(A.var(axis=0), grid))


def multi_observable_score(clocks, obs_dict, M: int = 200) -> dict:
    """Score every observable, plus the mean across observables."""
    out = {}
    for name, Ys in obs_dict.items():
        Yz = zscore_pool(Ys)
        out[name] = collapse_score(clocks, Yz, M=M)
    out["_mean"] = float(np.mean([v for k, v in out.items() if not k.startswith("_")]))
    return out


# ---------------------------------------------------------------------------
# null model: matched random monotone warps
# ---------------------------------------------------------------------------
def effective_dof(x: np.ndarray) -> float:
    """
    Participation ratio of the DCT power spectrum of log(dx/dt). A crude but
    stable measure of how many independent 'knobs' a warp really has; used to
    match the flexibility of the null warps to the candidate clock.
    """
    d = np.diff(x)
    d = np.clip(d, 1e-30, None)
    g = np.log(d)
    g = g - g.mean()
    F = np.abs(np.fft.rfft(g)) ** 2
    if F.sum() <= 0:
        return 1.0
    p = F / F.sum()
    return float(1.0 / np.sum(p**2))


def random_monotone_warp(n: int, dof: float, rng) -> np.ndarray:
    """
    Random strictly increasing warp on [0,1] with roughly `dof` effective
    degrees of freedom: exponentiated smoothed white noise, cumulated.
    """
    n_modes = max(1, int(round(dof)))
    s = np.linspace(0.0, 1.0, n - 1, endpoint=False)
    g = np.zeros(n - 1)
    for k in range(1, n_modes + 1):
        a, b = rng.normal(size=2)
        g += (a * np.cos(2 * np.pi * k * s) + b * np.sin(2 * np.pi * k * s)) / np.sqrt(k)
    g *= 1.0 / max(np.std(g), 1e-12)
    inc = np.exp(g - g.max())
    w = np.concatenate([[0.0], np.cumsum(inc)])
    return w / w[-1]


def null_shared_warp(obs_dict, n_t: int, dof: float, K: int, rng, M: int = 200) -> np.ndarray:
    """
    NULL-A (weak): K draws of a random monotone warp applied identically to
    every run. Answers only 'does *some* monotone reparametrisation help?'.
    """
    scores = np.empty(K)
    n_runs = len(next(iter(obs_dict.values())))
    for k in range(K):
        w = random_monotone_warp(n_t, dof, rng)
        clocks = [w for _ in range(n_runs)]
        scores[k] = multi_observable_score(clocks, obs_dict, M=M)["_mean"]
    return scores


def null_functional_clock(obs_dict, driver_pool: list[list[np.ndarray]], K: int,
                          rng, M: int = 200) -> np.ndarray:
    """
    NULL-B (matched, the one that matters): a random unit functional
    w . Y over the SAME pool of driver signals from which tau_Q is built,
    turned into a per-run activity clock int |d(w.Y)|.

    This is the correct null because tau_Q belongs to exactly this class:
    it is one particular choice of w (a coordinate basis vector). If tau_Q
    does not beat a random w, the SST-specific choice of Q carries no
    information.

    driver_pool[j][i] = driver signal j for run i.
    """
    n_drivers = len(driver_pool)
    n_runs = len(driver_pool[0])
    # z-score each driver over the pooled ensemble so w is scale-free
    zpool = []
    for j in range(n_drivers):
        zpool.append(zscore_pool(driver_pool[j]))

    scores = np.empty(K)
    for k in range(K):
        w = rng.normal(size=n_drivers)
        w /= np.linalg.norm(w)
        clocks = []
        ok = True
        for i in range(n_runs):
            sig = sum(w[j] * zpool[j][i] for j in range(n_drivers))
            cl = normalise_clock(cumulative_abs(sig))
            if cl is None:
                ok = False
                break
            clocks.append(cl)
        scores[k] = multi_observable_score(clocks, obs_dict, M=M)["_mean"] if ok else np.nan
    return scores


def pvalue(observed: float, null: np.ndarray) -> float:
    """One-sided: fraction of null draws at least as good (i.e. as small)."""
    null = null[np.isfinite(null)]
    if null.size == 0:
        return float("nan")
    return float((np.sum(null <= observed) + 1) / (null.size + 1))
