# SST Explicit Closed Vortex-Thread + Boost-Covariance Blind Falsifier v0.2.0

Python/C++17/pybind11 workbench for the revised SST background hypothesis:

1. there is **no globally measurable absolute translational velocity**;
2. nearby sources may organize a **local objective vortex-thread texture**;
3. the background must be represented by actual closed vorticity filaments, not by an arbitrarily prescribed curl-free velocity field;
4. any local knot/link response must arise from the Biot--Savart velocity induced by those explicit threads and from subsequent nonlinear filament evolution.

This release is intentionally a **stress-test model**, not a calibrated Earth/Sun model.  Dataset coordinates are dimensionless unless the user supplies a physical calibration.  Source distances, background circulation ratios and final times are therefore expressed in knot geometric units such as \(R_g\).

## One-click Windows use

Default dataset:

```text
..\..\KnotPlot\knots\final
```

BASIC chain:

```cmd
run_all.cmd
```

or

```cmd
run_all.cmd "C:\workspace\projects\SST-Workbench\KnotPlot\knots\final"
```

Extended fixed-core convergence plus the two prior-release holdouts:

```cmd
run_all_extended.cmd
```

Individual runners:

```cmd
run_install.cmd
run_build_native.cmd
run_selftest.cmd
run_quick.cmd
run_basic.cmd
run_extended.cmd
run_holdout_certification.cmd
run_python_reference.cmd
```

## What changed physically from v0.1.0

v0.1.0 injected two prescribed velocity proxies.  The radial proxy was essentially a potential-flow field and the affine director proxy was a trace-free strain.  Neither represented a background made of actual vortex filaments.  In addition, a one-step response obeyed

\[
\mathbf X_1^{(\mathrm{bg})}-\mathbf X_1^{(0)}
=\Delta t\,\mathbf v_{\mathrm{bg}},
\]

so a non-zero bridge response and near-perfect amplitude linearity were largely built into the experiment.

v0.2.0 removes both proxies.  A source-organized background now consists of closed vortex loops with a local active segment and a remote anti-parallel return segment.  Each loop has zero boundary,

\[
\partial C_a=0,
\]

which is the discrete filament-current analogue of

\[
\nabla\!\cdot\boldsymbol\omega=0.
\]

The local active direction for a source at \(\mathbf X_s\) is constructed as

\[
\mathbf n_a=
\frac{\mathbf q_a-\mathbf X_s}
{|\mathbf q_a-\mathbf X_s|},
\]

while the return flux is moved far from the knot and explicitly convergence-tested.

## Vortex kernels

### Knot self/mutual velocity

The centerline dynamics retain the regularized midpoint Biot--Savart discretization

\[
\mathbf v_i = \frac{\Gamma}{4\pi}
\sum_j
\frac{\Delta\boldsymbol\ell_j\times(\mathbf x_i-\mathbf x_{j+1/2})}
{\left(|\mathbf x_i-\mathbf x_{j+1/2}|^2+a_k^2\right)^{3/2}}.
\]

Unlike v0.1.0, the knot core is fixed in geometric units,

\[
a_k/R_g=\text{constant},
\]

when \(N\) changes.  Spatial refinement therefore changes the discretization rather than silently changing the physical regularization.

### Closed background filaments

Background loops are piecewise-straight and evaluated with the finite straight-segment Biot--Savart formula.  For segment endpoints \(\mathbf A,\mathbf B\),

\[
\mathbf L=\mathbf B-\mathbf A,
\qquad
\mathbf R_1=\mathbf x-\mathbf A,
\qquad
\mathbf R_2=\mathbf x-\mathbf B,
\]

and, away from the core,

\[
\mathbf v_{AB}(\mathbf x)=
\frac{\Gamma}{4\pi}
\frac{\mathbf R_1\times\mathbf R_2}
{|\mathbf R_1\times\mathbf R_2|^2}
\left(
\frac{\mathbf L\cdot\mathbf R_1}{|\mathbf R_1|}
-
\frac{\mathbf L\cdot\mathbf R_2}{|\mathbf R_2|}
\right).
\]

This lets the remote return flux be moved to \(12R_g\), \(24R_g\), \(48R_g\) without requiring thousands of tiny background segments.

## Nonlinear evolution

Every blinded case is evolved with classical RK4:

\[
\frac{d\mathbf X}{dt}
=
\mathbf v_{\rm self}[\mathbf X]
+
\mathbf v_{\rm threads}(\mathbf X,t)
+
\mathbf U_{\rm common}.
\]

For the common-boost case the entire source-attached background translates as

\[
\mathbf B(t)=\mathbf B(0)+\mathbf U_{\rm common}t,
\]

while the same \(\mathbf U_{\rm common}\) is added to the knot velocity.  A genuine common boost must therefore leave the intrinsic final geometry unchanged after rigid alignment.

## Blind protocol

For every resolution the package:

1. discovers and parses the knot/link files;
2. uniformly resamples each closed component in arclength;
3. freezes configuration, thresholds and input SHA-256 hashes in `precommit.json`;
4. generates a hidden shared spherical orientation set;
5. creates opaque numerical case IDs and hashes every `.npz` case;
6. commits the hidden semantic mapping with a salted SHA-256 digest;
7. integrates every case without semantic labels;
8. scores pairwise final shapes while still blind;
9. verifies the semantic commitment;
10. only then emits named gates and source paths.

`secret/semantic_manifest.json` contains the hidden map.  The one-click workflow is a reproducible procedural blind.  For a strict two-operator experiment, move the `secret/` directory away after preparation and restore it only for unblinding.

## Gates

| Gate | Test | Class |
|---|---|---|
| G0 | duplicate zero-background trajectory | structural null |
| G1 | common boost of knot + source-attached bundle | structural covariance null |
| G2 | rigid translation of knot + all background threads | structural covariance null |
| G3 | rigid rotation of knot + all background threads | structural covariance null |
| G4 | every background vorticity filament is a closed cycle | discrete \(\nabla\cdot\boldsymbol\omega=0\) validity |
| G5 | no initial knot/thread near-singular contact | validity gate |
| G6 | local result becomes independent of remote return-flux placement | thread-model limit gate |
| G7 | radial source bundle approaches a parallel bundle as source distance increases | asymptotic thread-model gate |
| G8 | explicit radial-bundle deformation | measured prediction |
| G9 | shared hidden orientation ensemble | measured prediction / topology comparison |
| G10 | parallel-bundle response | measured control |
| G11 | second-source (“Sun”) response | measured control |
| G12 | first + second source response | measured multi-source prediction |

A `PASS` does **not** mean SST gravity has been derived.  It means this explicit closed-thread implementation survives its precommitted covariance, topology and limiting tests.

## Orientation ensemble

Every topology receives the same hidden set of source directions

\[
\{\mathbf n_1,\ldots,\mathbf n_M\}.
\]

The report stores

\[
\bar R=\frac1M\sum_{a=1}^{M}R(\mathbf n_a),
\qquad
A_R=\frac{\sigma_R}{\bar R}.
\]

This removes the v0.1.0 problem that different topologies could be compared after seeing different random source directions.

## Extended numerical certification

`run_extended.cmd` runs

\[
N=128\rightarrow256\rightarrow512
\]

with fixed \(a_k/R_g\), fixed final time and the same blind orientation set.  The orientation-averaged explicit-thread response must change by no more than

\[
2\% \quad \text{for STANDARD\_PASS},
\]

and

\[
0.5\% \quad \text{for CERTIFIED\_PASS}.
\]

`run_holdout_certification.cmd` additionally reruns the two worst v0.1.0 spatial-convergence cases (`link_0.3.1_final.txt` and `torus_6.21_final.txt`) at

\[
N=512\rightarrow1024
\]

and at the highest resolution compares

\[
N_t=8\rightarrow16
\]

for temporal convergence.  These holdouts were selected from the **previous release**, not from v0.2.0 outcomes.

## Earth/Sun labels are not SI calibration

The source labels are mnemonic.  In the supplied configs, for example,

\[
D_{\oplus}=12R_g,
\qquad
D_{\odot}=24R_g,
\]

and the second-source circulation ratio is a stress-test parameter.  These are **not** the physical Earth radius, Earth--Sun distance, or canon-derived vortex-thread flux.  A later release must replace them with a canon-derived source law before an astrophysical claim is possible.

## Output ledger

Each blind run writes:

```text
precommit.json
blind_commitment.json
blind/manifest.json
blind/cases/Cxxxxxx.npz
blind/results/Cxxxxxx.json
blind/results/Cxxxxxx_final.npy
blind_results.json
blind_score.json
secret/semantic_manifest.json
unblinded_report.json
summary.csv
```

Extended and holdout runners also write `extended_summary.json` or `holdout_summary.json`.

## Dimensional convention

For dimensionless input centerlines the geometric velocity scale is

\[
U_g=\frac{|\Gamma|}{4\pi R_g},
\]

and the final integration time is

\[
T=f_T\frac{R_g}{U_g}.
\]

The SST canonical SI constants are recorded as provenance only.  They are not mixed into dimensionless knot data without an explicit mapping between input length units and SI units.
