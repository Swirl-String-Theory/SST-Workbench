#!/usr/bin/env python3
"""
Route-A/L2 photon-gas consistency falsifier.

Purpose
-------
Test whether a Weyl-counting prescription of the form

    density of states × internal degeneracy × extra orientation measure

is admissible.  The control system is the photon gas, whose known result is
obtained from a massless field with two transverse polarizations.  The Weyl
coefficient already integrates propagation directions over the k-sphere.
Multiplying by an extra 4*pi or (4*pi)^2 therefore overcounts.

This is a falsifier for the SST Route-A L2 candidate factor

    g_T = dim(R^3 \otimes Lambda^2 R^3) (4*pi)^2 = 9(4*pi)^2.

The orthodox ingredient dim(R^3 \otimes Lambda^2 R^3)=9 survives; the angular
factor (4*pi)^2 is rejected unless SST derives a separate quantized orientation
cell not already represented by field components or by the Weyl k-sphere.
"""
from __future__ import annotations
import math, json
from pathlib import Path

PI = math.pi

# Photon gas: per-volume angular-frequency density of states
# dN/(V d omega) = g omega^2/(2*pi^2 c^3).
# Energy density coefficient: u = g*pi^2/30 * (kT)^4/(hbar^3 c^3).
# For photons g=2 -> u = pi^2/15 * (kT)^4/(hbar^3 c^3).

def photon_coeff(g: float) -> float:
    return g * PI**2 / 30.0

expected_g_photon = 2.0
expected_coeff = photon_coeff(expected_g_photon)

schemes = [
    {
        "name": "orthodox_photon_Weyl_x_2_polarizations",
        "internal_degeneracy": 2.0,
        "extra_orientation_measure": 1.0,
        "interpretation": "PASS: Weyl k-sphere already supplies propagation directions; internal degeneracy is two transverse polarizations.",
    },
    {
        "name": "invalid_photon_Weyl_x_2_x_4pi",
        "internal_degeneracy": 2.0,
        "extra_orientation_measure": 4.0*PI,
        "interpretation": "FAIL: adds a propagation/orientation solid angle already integrated in Weyl's 4*pi k-sphere.",
    },
    {
        "name": "invalid_photon_Weyl_x_2_x_(4pi)^2",
        "internal_degeneracy": 2.0,
        "extra_orientation_measure": (4.0*PI)**2,
        "interpretation": "FAIL: a squared solid-angle measure overcounts by (4*pi)^2.",
    },
]

for s in schemes:
    g_eff = s["internal_degeneracy"] * s["extra_orientation_measure"]
    coeff = photon_coeff(g_eff)
    s["g_effective"] = g_eff
    s["energy_density_coeff"] = coeff
    s["ratio_to_photon_expected"] = coeff / expected_coeff
    s["pass_photon_control"] = abs(coeff / expected_coeff - 1.0) < 1e-12

# Torsion L2 analogue.
# Paired Weyl baseline coefficient [2/(6*pi^2)]^2.
paired_weyl_base_coeff = (2.0/(6.0*PI**2))**2
cartan_dim = 3 * math.comb(3, 2)  # dim(R^3 \otimes Lambda^2 R^3) = 9
cartan_dim_only_coeff = paired_weyl_base_coeff * cartan_dim
cartan_angular_coeff = paired_weyl_base_coeff * cartan_dim * (4.0*PI)**2
old_trial_coeff = 16.0/PI**2

# Irrep split under SO(3), using Hodge dual of the bivector index maps torsion to a 3x3 matrix:
# trace scalar (1) + antisymmetric vector (3) + symmetric traceless tensor (5).
irrep_split = {"vector_or_antisymmetric": 3, "axial_or_trace_scalar": 1, "symmetric_traceless": 5, "total": 9}

results = {
    "status": "FALSIFIES_EXTRA_ANGULAR_MEASURE_AS_NON_FITTED_DEGENERACY",
    "photon_control": {
        "expected_degeneracy": expected_g_photon,
        "expected_energy_density_coeff_dimensionless": expected_coeff,
        "schemes": schemes,
        "conclusion": "Only internal degeneracy g=2 passes. Extra 4*pi or (4*pi)^2 fails by exactly that factor; therefore an SST torsion count cannot multiply Weyl by angular solid angles unless an independent quantized orientation cell is derived.",
    },
    "routeA_L2_torsion_implication": {
        "paired_weyl_base_coeff": paired_weyl_base_coeff,
        "cartan_dim_R3_tensor_Lambda2_R3": cartan_dim,
        "cartan_dim_only_coeff": cartan_dim_only_coeff,
        "cartan_with_extra_4pi_squared_coeff": cartan_angular_coeff,
        "old_trial_coeff_16_over_pi_squared": old_trial_coeff,
        "dim_only_to_old_trial_ratio": cartan_dim_only_coeff / old_trial_coeff,
        "missing_factor_after_dim9_only": old_trial_coeff / cartan_dim_only_coeff,
        "missing_factor_label": "16*pi^2 = (4*pi)^2",
        "irrep_split_3D_after_Hodge_dual": irrep_split,
        "conclusion": "The integer dim=9 is orthodox as a bulk component count. The (4*pi)^2 factor is not derived and is rejected by the photon-gas control as a generic degeneracy prescription. Horizon-restricted torsion irreps must be derived before any L2 degeneracy can be claimed.",
    },
}

outdir = Path(__file__).resolve().parents[1] / "results"
outdir.mkdir(exist_ok=True)
(outdir / "routeA_L2_photon_gas_falsifier_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")

lines = []
lines.append("# Route-A/L2 photon-gas consistency falsifier")
lines.append("")
lines.append(f"Expected photon degeneracy: g = {expected_g_photon:g}")
lines.append(f"Expected coefficient u/(kT)^4*hbar^3*c^3 = pi^2/15 = {expected_coeff:.16e}")
lines.append("")
for s in schemes:
    lines.append(f"- {s['name']}: ratio={s['ratio_to_photon_expected']:.16e}, pass={s['pass_photon_control']}")
lines.append("")
lines.append("## Route-A/L2 implication")
lines.append(f"paired Weyl baseline coefficient = {paired_weyl_base_coeff:.16e}")
lines.append(f"dim(R^3 tensor Lambda^2 R^3) = {cartan_dim}")
lines.append(f"dim-only coefficient = {cartan_dim_only_coeff:.16e}")
lines.append(f"with extra (4*pi)^2 coefficient = {cartan_angular_coeff:.16e}")
lines.append(f"old trial 16/pi^2 coefficient = {old_trial_coeff:.16e}")
lines.append(f"dim-only / old-trial = {cartan_dim_only_coeff / old_trial_coeff:.16e}")
lines.append(f"missing factor after dim=9 only = {old_trial_coeff / cartan_dim_only_coeff:.16e} = 16*pi^2")
lines.append("")
lines.append("Verdict: extra angular measure fails the photon-gas control; keep dim=9 [ORTHODOX], demote (4*pi)^2 to [NOT DERIVED / measure convention / double-counting risk].")
(outdir / "routeA_L2_photon_gas_falsifier_report.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
print("\n".join(lines))
