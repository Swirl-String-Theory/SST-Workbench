# A050 v0.4.0 BLIND Mechanism-Discrimination Report

**Frozen v0.3.2 status:** `BRANCH_RETAINED_COHERENT_NONSTATIONARITY_SUPPORTED`

**v0.4.0 mechanism status:** `COHERENT_NONSTATIONARITY_MECHANISM_UNRESOLVED`

This campaign does not modify the v0.3.0 verdict or v0.3.2 diagnostic status.

## Fresh holdout branch replication
- Branch gate: **True**
- Retained primary bases: **5/5**

## Mechanism replication
- smooth_chirp: 0/5 replicated bases; source groups=0 -> **False**
- two_tone_beating: 0/5 replicated bases; source groups=0 -> **False**
- phase_slip: 0/5 replicated bases; source groups=0 -> **False**
- rpo_candidate: 0/5 replicated bases; source groups=0 -> **False**
- amplitude_phase_modulation: 0/5 replicated bases; source groups=0 -> **False**

## Passed mechanisms
- none

RPO candidate means recurrence evidence only. Floquet/monodromy remains inactive. Source identities remain reveal-only and no numerical mode is preregistered.
