#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <cmath>
#include <cstdint>
#ifdef _OPENMP
#include <omp.h>
#endif
namespace py=pybind11;
static constexpr double PI=3.141592653589793238462643383279502884;

py::array_t<double> biot_savart(
    py::array_t<double,py::array::c_style|py::array::forcecast> points,
    py::array_t<std::int64_t,py::array::c_style|py::array::forcecast> component_offsets,
    double gamma,double core_radius)
{
    auto P=points.unchecked<2>(); auto O=component_offsets.unchecked<1>();
    if(P.shape(1)!=3) throw std::runtime_error("points must have shape (N,3)");
    const py::ssize_t n=P.shape(0);
    py::array_t<double> out({py::ssize_t(n),py::ssize_t(3)}); auto W=out.mutable_unchecked<2>();
    const double a2=core_radius*core_radius, pref=gamma/(4.0*PI);
    #pragma omp parallel for if(n>64)
    for(py::ssize_t i=0;i<n;++i){
        double vx=0,vy=0,vz=0;
        for(py::ssize_t c=0;c+1<O.shape(0);++c){
            const std::int64_t lo=O(c),hi=O(c+1); if(hi-lo<3) continue;
            for(std::int64_t j=lo;j<hi;++j){
                const std::int64_t k=(j+1<hi)?j+1:lo;
                const double dlx=P(k,0)-P(j,0),dly=P(k,1)-P(j,1),dlz=P(k,2)-P(j,2);
                const double mx=0.5*(P(k,0)+P(j,0)),my=0.5*(P(k,1)+P(j,1)),mz=0.5*(P(k,2)+P(j,2));
                const double rx=P(i,0)-mx,ry=P(i,1)-my,rz=P(i,2)-mz;
                const double den=std::pow(rx*rx+ry*ry+rz*rz+a2,1.5); if(den<=0) continue;
                vx+=(dly*rz-dlz*ry)/den; vy+=(dlz*rx-dlx*rz)/den; vz+=(dlx*ry-dly*rx)/den;
            }
        }
        W(i,0)=pref*vx; W(i,1)=pref*vy; W(i,2)=pref*vz;
    }
    return out;
}

py::array_t<double> segment_biot_savart(
    py::array_t<double,py::array::c_style|py::array::forcecast> targets,
    py::array_t<double,py::array::c_style|py::array::forcecast> vertices,
    py::array_t<std::int64_t,py::array::c_style|py::array::forcecast> component_offsets,
    py::array_t<double,py::array::c_style|py::array::forcecast> gammas,
    double core_radius)
{
    auto X=targets.unchecked<2>(); auto V=vertices.unchecked<2>(); auto O=component_offsets.unchecked<1>(); auto G=gammas.unchecked<1>();
    if(X.shape(1)!=3||V.shape(1)!=3) throw std::runtime_error("targets/vertices must have shape (N,3)");
    if(G.shape(0)+1!=O.shape(0)) throw std::runtime_error("gammas length must equal number of components");
    const py::ssize_t n=X.shape(0); py::array_t<double> out({py::ssize_t(n),py::ssize_t(3)}); auto W=out.mutable_unchecked<2>();
    const double a2=core_radius*core_radius;
    #pragma omp parallel for if(n>64)
    for(py::ssize_t i=0;i<n;++i){
        double vx=0,vy=0,vz=0;
        for(py::ssize_t c=0;c+1<O.shape(0);++c){
            const std::int64_t lo=O(c),hi=O(c+1); if(hi-lo<3) continue; const double pref=G(c)/(4.0*PI);
            for(std::int64_t j=lo;j<hi;++j){
                const std::int64_t k=(j+1<hi)?j+1:lo;
                const double lx=V(k,0)-V(j,0),ly=V(k,1)-V(j,1),lz=V(k,2)-V(j,2);
                const double L2=lx*lx+ly*ly+lz*lz; if(L2<=0) continue;
                const double r1x=X(i,0)-V(j,0),r1y=X(i,1)-V(j,1),r1z=X(i,2)-V(j,2);
                const double r2x=X(i,0)-V(k,0),r2y=X(i,1)-V(k,1),r2z=X(i,2)-V(k,2);
                const double cx=r1y*r2z-r1z*r2y, cy=r1z*r2x-r1x*r2z, cz=r1x*r2y-r1y*r2x;
                const double cr2=cx*cx+cy*cy+cz*cz;
                const double n1=std::sqrt(r1x*r1x+r1y*r1y+r1z*r1z+a2),n2=std::sqrt(r2x*r2x+r2y*r2y+r2z*r2z+a2);
                if(n1<=0||n2<=0) continue;
                const double term=(lx*r1x+ly*r1y+lz*r1z)/n1-(lx*r2x+ly*r2y+lz*r2z)/n2;
                const double den=cr2+a2*L2; if(den<=1e-300) continue;
                const double fac=pref*term/den; vx+=fac*cx; vy+=fac*cy; vz+=fac*cz;
            }
        }
        W(i,0)=vx; W(i,1)=vy; W(i,2)=vz;
    }
    return out;
}

PYBIND11_MODULE(_native,m){
    m.doc()="C++17 vortex-filament kernels for SST thread-bundle blind falsifier v0.2.0";
    m.def("biot_savart",&biot_savart,py::arg("points"),py::arg("component_offsets"),py::arg("gamma")=1.0,py::arg("core_radius")=0.05);
    m.def("segment_biot_savart",&segment_biot_savart,py::arg("targets"),py::arg("vertices"),py::arg("component_offsets"),py::arg("gammas"),py::arg("core_radius")=0.0);
}
