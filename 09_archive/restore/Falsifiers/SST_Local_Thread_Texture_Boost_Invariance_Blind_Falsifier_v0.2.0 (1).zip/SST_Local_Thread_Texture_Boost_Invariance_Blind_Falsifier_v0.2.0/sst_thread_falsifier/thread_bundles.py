from __future__ import annotations
import numpy as np


def unit(v):
    v=np.asarray(v,float)
    n=float(np.linalg.norm(v))
    if not np.isfinite(n) or n <= 0.0:
        raise ValueError("zero/invalid direction")
    return v/n


def orthonormal_basis(n):
    n=unit(n)
    a=np.array([1.0,0.0,0.0]) if abs(n[0]) < 0.8 else np.array([0.0,1.0,0.0])
    e1=unit(np.cross(n,a))
    e2=np.cross(n,e1)
    return e1,e2


def fibonacci_sphere(count, rotation=None):
    count=max(1,int(count))
    ga=np.pi*(3.0-np.sqrt(5.0))
    out=[]
    for k in range(count):
        z=1.0-2.0*(k+0.5)/count
        r=np.sqrt(max(0.0,1.0-z*z))
        phi=k*ga
        out.append([r*np.cos(phi),r*np.sin(phi),z])
    A=np.asarray(out,float)
    if rotation is not None:
        A=A@np.asarray(rotation,float).T
    return A


def _ring_offsets(n_threads, radius, e1, e2, phase=0.0):
    n=max(2,int(n_threads))
    out=[]
    for k in range(n):
        th=phase+2.0*np.pi*k/n
        out.append(radius*(np.cos(th)*e1+np.sin(th)*e2))
    return out


def _rectangle_loop(active_center, direction, half_length, return_offset_vec):
    d=unit(direction)
    c=np.asarray(active_center,float)
    ret=np.asarray(return_offset_vec,float)
    a0=c-half_length*d
    a1=c+half_length*d
    b1=a1+ret
    b0=a0+ret
    # Implicit cyclic closure: a0 -> a1 -> b1 -> b0 -> a0.
    return np.vstack([a0,a1,b1,b0])


def _pack_loops(loops, gammas):
    offsets=[0]
    for q in loops:
        offsets.append(offsets[-1]+len(q))
    return np.vstack(loops).astype(float), np.asarray(offsets,dtype=np.int64), np.asarray(gammas,dtype=float)


def local_source_closed_bundle(center, rg, source_direction, source_distance_rg,
                               n_threads, ring_radius_rg, active_half_length_rg,
                               return_offset_rg, total_gamma, phase=0.0,
                               radial=True):
    """Closed-filament local representation of a source-organized thread bundle.

    The active segment of every loop crosses the local source-facing region.  A remote
    anti-parallel return segment plus two connectors closes the filament exactly, so
    no vorticity line begins or ends at the source.  For ``radial=True`` each active
    direction points along the ray from the source to its local active center.  For
    ``radial=False`` all active directions are parallel to ``source_direction``.
    """
    center=np.asarray(center,float)
    rg=float(rg)
    n=unit(source_direction)
    e1,e2=orthonormal_basis(n)
    source=center-float(source_distance_rg)*rg*n
    ring_r=float(ring_radius_rg)*rg
    half=float(active_half_length_rg)*rg
    retmag=float(return_offset_rg)*rg
    offsets=_ring_offsets(n_threads,ring_r,e1,e2,phase)
    loops=[]
    gs=[]
    g_each=float(total_gamma)/max(1,int(n_threads))
    for off in offsets:
        q=center+off
        d=unit(q-source) if radial else n.copy()
        # Return flux is displaced further outward in the local transverse plane.
        ret_dir=off-d*np.dot(off,d)
        if np.linalg.norm(ret_dir) < 1e-12*max(rg,1.0):
            ret_dir=e1-d*np.dot(e1,d)
        ret_dir=unit(ret_dir)
        loops.append(_rectangle_loop(q,d,half,retmag*ret_dir))
        gs.append(g_each)
    V,O,G=_pack_loops(loops,gs)
    meta={
        "source":source.tolist(),
        "source_direction":n.tolist(),
        "source_distance_rg":float(source_distance_rg),
        "ring_radius_rg":float(ring_radius_rg),
        "active_half_length_rg":float(active_half_length_rg),
        "return_offset_rg":float(return_offset_rg),
        "n_threads":int(n_threads),
        "total_gamma":float(total_gamma),
        "radial":bool(radial),
        "phase":float(phase),
    }
    return V,O,G,meta


def concatenate_bundles(*bundles):
    verts=[]; offsets=[0]; gammas=[]; metas=[]
    for bundle in bundles:
        V,O,G,M=bundle
        V=np.asarray(V,float); O=np.asarray(O,np.int64); G=np.asarray(G,float)
        for a,b,g in zip(O[:-1],O[1:],G):
            q=V[int(a):int(b)]
            verts.append(q)
            offsets.append(offsets[-1]+len(q))
            gammas.append(float(g))
        metas.append(M)
    if not verts:
        return np.zeros((0,3),float),np.array([0],dtype=np.int64),np.zeros((0,),float),metas
    return np.vstack(verts),np.asarray(offsets,dtype=np.int64),np.asarray(gammas,float),metas


def transform_bundle(vertices, translation=None, rotation=None, origin=None):
    V=np.asarray(vertices,float).copy()
    if rotation is not None:
        R=np.asarray(rotation,float)
        o=np.zeros(3) if origin is None else np.asarray(origin,float)
        V=(V-o)@R.T+o
    if translation is not None:
        V=V+np.asarray(translation,float)
    return V


def closure_diagnostics(vertices, offsets, gammas=None):
    V=np.asarray(vertices,float); O=np.asarray(offsets,np.int64)
    if gammas is None:
        gammas=np.ones(max(0,len(O)-1),float)
    G=np.asarray(gammas,float)
    per=[]; worst=0.0; weighted=np.zeros(3,float); total_weighted_length=0.0
    for ci,(a,b) in enumerate(zip(O[:-1],O[1:])):
        q=V[int(a):int(b)]
        if len(q)<3:
            per.append({"component":ci,"valid":False,"closure_vector_norm_over_length":float("inf")})
            worst=float("inf"); continue
        dl=np.roll(q,-1,axis=0)-q
        L=float(np.linalg.norm(dl,axis=1).sum())
        cvec=dl.sum(axis=0)
        rel=float(np.linalg.norm(cvec)/max(L,1e-300))
        worst=max(worst,rel)
        g=float(G[ci]) if ci<len(G) else 1.0
        weighted += g*cvec
        total_weighted_length += abs(g)*L
        per.append({"component":ci,"valid":True,"length":L,"closure_vector":cvec.tolist(),"closure_vector_norm_over_length":rel,"gamma":g})
    wrel=float(np.linalg.norm(weighted)/max(total_weighted_length,1e-300)) if len(per) else 0.0
    return {"component_count":len(per),"per_component":per,"max_closure_vector_norm_over_length":worst,"weighted_boundary_residual":wrel}


def point_segment_distance(points, a, b):
    P=np.asarray(points,float); a=np.asarray(a,float); b=np.asarray(b,float)
    ab=b-a; den=float(np.dot(ab,ab))
    if den<=0: return np.linalg.norm(P-a,axis=1)
    t=np.clip(((P-a)@ab)/den,0.0,1.0)
    Q=a[None,:]+t[:,None]*ab[None,:]
    return np.linalg.norm(P-Q,axis=1)


def minimum_clearance(points, vertices, offsets):
    P=np.asarray(points,float); V=np.asarray(vertices,float); O=np.asarray(offsets,np.int64)
    if len(V)==0: return float("inf")
    best=float("inf")
    for a,b in zip(O[:-1],O[1:]):
        q=V[int(a):int(b)]
        for j in range(len(q)):
            d=point_segment_distance(P,q[j],q[(j+1)%len(q)])
            best=min(best,float(np.min(d)))
    return best
