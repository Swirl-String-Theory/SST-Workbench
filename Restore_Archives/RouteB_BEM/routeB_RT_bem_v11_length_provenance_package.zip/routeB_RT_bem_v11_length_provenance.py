#!/usr/bin/env python3
r"""
routeB_RT_bem_v11_length_provenance.py
======================================

BEMv11 Route-B audit: length provenance and leading-alpha sensitivity.

BEMv10 showed that the finite-correction normalizer gate can pass, while the
remaining bottleneck is the longitudinal length scale.  BEMv11 therefore audits

    L_long(K)

directly from the Brian Gilbert Fourier coefficients, without CODATA alpha and
without using observed fine structure.

For a Fourier curve

    x(t) = sum_I A_I cos(I t) + B_I sin(I t),

BEMv11 computes arclength by the derivative integral

    L = integral_0^{2 pi} ||x'(t)|| dt,

using a periodic trapezoid rule over increasing sample counts.  For comparison
it also computes polygonal chord length.

Outputs
-------
  length_convergence.csv
      Per knot and sample count: derivative-integral length, polygon length,
      database length, relative errors.

  length_extrapolation_fit.csv
      Simple tail fits L_N = L_inf + c N^{-p} for p in {2,4,6,8}.

  alpha_leading_length_audit.csv
      Leading Route-B alpha scale from length:
          alpha_inv_lead = (8 pi / 3) L
      and its sensitivity to database / extrapolated length.

  length_provenance_report.md
      Human-readable report.

No observed alpha is used or compared.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


def parse_id_csv(s: str) -> List[str]:
    return [x.strip() for x in str(s).split(",") if x.strip()]


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: List[str] = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.+-]+", "_", str(s)).strip("_")


def parse_attrs_from_tag(tag: str) -> Dict[str, str]:
    return {m.group(1): m.group(2) for m in re.finditer(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"([^"]*)"', tag)}


def parse_vec3_attr(s: str) -> np.ndarray:
    vals = [float(x.strip()) for x in s.split(",")]
    if len(vals) != 3:
        raise ValueError(f"expected 3-vector, got {s!r}")
    return np.asarray(vals, dtype=float)


def ideal_id_to_name(bid: str) -> str:
    parts = str(bid).split(":")
    if len(parts) >= 3 and parts[2] == "1":
        return f"{parts[0]}_{parts[1]}"
    if len(parts) >= 2:
        return f"{parts[0]}_{parts[1]}"
    return str(bid).replace(":", "_")


def is_xml_ideal(path: Path) -> bool:
    head = path.read_text(encoding="utf-8", errors="replace")[:8192]
    return "<AB " in head and "<Coeff " in head


def parse_xml_ideal_blocks(path: Path) -> Dict[str, Dict[str, Any]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks: Dict[str, Dict[str, Any]] = {}

    for m in re.finditer(r"<AB\b([^>]*)>(.*?)</AB>", text, flags=re.S | re.I):
        attrs = parse_attrs_from_tag(m.group(1))
        bid = attrs.get("Id", f"AB_{len(blocks)+1}")
        body = m.group(2)
        ncomp = int(attrs.get("n", "1").strip() or "1")
        supported = (ncomp == 1 and "<Component" not in body)

        A: Dict[int, np.ndarray] = {}
        B: Dict[int, np.ndarray] = {}
        if supported:
            for cm in re.finditer(r"<Coeff\b([^>]*)/?>", body, flags=re.I):
                ca = parse_attrs_from_tag(cm.group(1))
                if not all(k in ca for k in ("I", "A", "B")):
                    continue
                idx = int(ca["I"])
                A[idx] = parse_vec3_attr(ca["A"])
                B[idx] = parse_vec3_attr(ca["B"])
            supported = bool(A and B)

        def maybe_float(key: str):
            try:
                return float(str(attrs.get(key, "")).strip())
            except Exception:
                return None

        blocks[bid] = {
            "id": bid,
            "name": ideal_id_to_name(bid),
            "conway": attrs.get("Conway", ""),
            "L_database": maybe_float("L"),
            "D_database": maybe_float("D"),
            "n_components": ncomp,
            "supported": supported,
            "A": A,
            "B": B,
            "max_I": max(set(A) | set(B)) if A or B else None,
            "source": "xml_fourier",
        }
    return blocks


def generated_unknot_block() -> Dict[str, Any]:
    return {
        "id": "0:1:1",
        "name": "0_1",
        "conway": "0",
        "L_database": 2.0 * math.pi,
        "D_database": 1.0,
        "n_components": 1,
        "supported": True,
        "A": {1: np.asarray([1.0, 0.0, 0.0], dtype=float)},
        "B": {1: np.asarray([0.0, 1.0, 0.0], dtype=float)},
        "max_I": 1,
        "source": "generated_unit_circle_control",
    }


def load_blocks(path: Path, requested: str, auto_add_unknot: bool = True, max_knots: int = 50) -> Dict[str, Dict[str, Any]]:
    if not is_xml_ideal(path):
        raise ValueError("BEMv11 currently expects a Brian Gilbert XML/Fourier ideal.txt file")

    blocks_by_id = parse_xml_ideal_blocks(path)
    blocks_by_name = {b["name"]: b for b in blocks_by_id.values() if b.get("supported")}
    tokens = parse_id_csv(requested)
    selected: Dict[str, Dict[str, Any]] = {}

    if len(tokens) == 1 and tokens[0].lower() == "all":
        if auto_add_unknot and "0:1:1" not in blocks_by_id:
            b = generated_unknot_block()
            selected[b["name"]] = b
        for b in blocks_by_id.values():
            if b.get("supported"):
                selected[b["name"]] = b
                if len(selected) >= max_knots:
                    break
        return selected

    for token in tokens:
        b = blocks_by_id.get(token) or blocks_by_name.get(token)
        if b is None and auto_add_unknot and token in {"0:1:1", "0_1"}:
            b = generated_unknot_block()
        if b is None:
            raise ValueError(f"requested knot {token!r} not found")
        if not b.get("supported"):
            raise ValueError(f"requested knot {token!r} is unsupported/multi-component")
        selected[b["name"]] = b
    return selected


def eval_curve(block: Dict[str, Any], n: int) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False)
    P = np.zeros((len(t), 3), dtype=float)
    A: Dict[int, np.ndarray] = block["A"]
    B: Dict[int, np.ndarray] = block["B"]
    for I in sorted(set(A) | set(B)):
        P += np.cos(I*t)[:, None] * A.get(I, np.zeros(3))[None, :]
        P += np.sin(I*t)[:, None] * B.get(I, np.zeros(3))[None, :]
    return P


def eval_derivative(block: Dict[str, Any], n: int) -> np.ndarray:
    t = np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False)
    V = np.zeros((len(t), 3), dtype=float)
    A: Dict[int, np.ndarray] = block["A"]
    B: Dict[int, np.ndarray] = block["B"]
    for I in sorted(set(A) | set(B)):
        V += (-I * np.sin(I*t))[:, None] * A.get(I, np.zeros(3))[None, :]
        V += ( I * np.cos(I*t))[:, None] * B.get(I, np.zeros(3))[None, :]
    return V


def length_derivative_trap(block: Dict[str, Any], n: int) -> float:
    if block.get("source") == "generated_unit_circle_control":
        return 2.0 * math.pi
    V = eval_derivative(block, n)
    speed = np.linalg.norm(V, axis=1)
    return float((2.0 * math.pi / n) * np.sum(speed))


def length_polygon(block: Dict[str, Any], n: int) -> float:
    if block.get("source") == "generated_unit_circle_control":
        return 2.0 * math.pi
    P = eval_curve(block, n)
    Q = np.vstack([P, P[0]])
    return float(np.sum(np.linalg.norm(np.diff(Q, axis=0), axis=1)))


def fit_tail(samples: np.ndarray, values: np.ndarray, p: float, min_tail: int) -> Dict[str, Any]:
    if len(samples) < max(3, min_tail):
        return {"status": "SKIP_TOO_FEW_POINTS", "p": p}
    N = samples.astype(float)
    Y = values.astype(float)
    # Use the last min_tail points when available.
    N = N[-min_tail:]
    Y = Y[-min_tail:]
    X = np.column_stack([np.ones_like(N), N ** (-p)])
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    pred = X @ beta
    resid = Y - pred
    rms = float(math.sqrt(np.mean(resid*resid)))
    return {
        "status": "PASS_FIT",
        "p": float(p),
        "tail_points": int(len(N)),
        "N_min_tail": int(np.min(N)),
        "N_max_tail": int(np.max(N)),
        "L_inf": float(beta[0]),
        "c": float(beta[1]),
        "rms": rms,
    }


def leading_alpha_inv_from_length(L: float) -> float:
    return (8.0 * math.pi / 3.0) * L


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ideal", default="ideal.txt")
    ap.add_argument("--outdir", default="outputs_routeB_BEM_v11_length")
    ap.add_argument("--ideal-xml-knot-ids", default="0:1:1,3:1:1,4:1:1")
    ap.add_argument("--target", default="3_1")
    ap.add_argument("--reference", default="0_1")
    ap.add_argument("--samples-list", default="1000,2000,4000,8000,16000,32000")
    ap.add_argument("--tail-powers", default="2,4,6,8")
    ap.add_argument("--tail-points", type=int, default=4)
    ap.add_argument("--max-knots", type=int, default=50)
    ap.add_argument("--no-auto-add-unknot", action="store_true")
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    ideal = Path(args.ideal)
    blocks = load_blocks(ideal, args.ideal_xml_knot_ids, auto_add_unknot=(not args.no_auto_add_unknot), max_knots=args.max_knots)
    sample_counts = [int(x.strip()) for x in args.samples_list.split(",") if x.strip()]
    tail_powers = [float(x.strip()) for x in args.tail_powers.split(",") if x.strip()]

    conv_rows: List[Dict[str, Any]] = []
    for name, block in blocks.items():
        L_db = block.get("L_database")
        for N in sample_counts:
            L_der = length_derivative_trap(block, N)
            L_poly = length_polygon(block, N)
            conv_rows.append({
                "knot": name,
                "id": block.get("id", name),
                "conway": block.get("conway", ""),
                "source": block.get("source", ""),
                "N_samples": N,
                "max_I": block.get("max_I", ""),
                "L_derivative_trap": L_der,
                "L_polygon": L_poly,
                "L_database": L_db if L_db is not None else "",
                "delta_derivative_minus_database": (L_der - float(L_db)) if L_db is not None else "",
                "rel_derivative_minus_database": ((L_der - float(L_db)) / float(L_db)) if L_db is not None and abs(float(L_db)) > 0 else "",
                "delta_polygon_minus_database": (L_poly - float(L_db)) if L_db is not None else "",
                "rel_polygon_minus_database": ((L_poly - float(L_db)) / float(L_db)) if L_db is not None and abs(float(L_db)) > 0 else "",
                "alpha_inv_lead_derivative": leading_alpha_inv_from_length(L_der),
                "alpha_inv_lead_polygon": leading_alpha_inv_from_length(L_poly),
                "status": "ALPHA_BLIND_LENGTH_PROVENANCE",
            })
    write_csv(outdir / "length_convergence.csv", conv_rows)

    # Extrapolation fits per knot, using derivative and polygon.
    fit_rows: List[Dict[str, Any]] = []
    for name in blocks:
        rows = [r for r in conv_rows if r["knot"] == name]
        samples = np.asarray([int(r["N_samples"]) for r in rows], dtype=int)
        for quantity in ["L_derivative_trap", "L_polygon"]:
            values = np.asarray([float(r[quantity]) for r in rows], dtype=float)
            for p in tail_powers:
                fit = fit_tail(samples, values, p, args.tail_points)
                fit.update({
                    "knot": name,
                    "quantity": quantity,
                    "alpha_inv_lead_L_inf": leading_alpha_inv_from_length(fit["L_inf"]) if fit.get("status") == "PASS_FIT" else "",
                })
                fit_rows.append(fit)
    write_csv(outdir / "length_extrapolation_fit.csv", fit_rows)

    # Pick best derivative fit by RMS for target; also report latest sample.
    target = args.target
    if target not in blocks:
        # Allow AB id resolution to display name.
        for name, b in blocks.items():
            if b.get("id") == args.target:
                target = name
    target_rows = [r for r in conv_rows if r["knot"] == target]
    if not target_rows:
        raise ValueError(f"target {args.target!r} not found in selected blocks {list(blocks)}")
    latest = sorted(target_rows, key=lambda r: int(r["N_samples"]))[-1]
    fits_target = [r for r in fit_rows if r.get("knot") == target and r.get("quantity") == "L_derivative_trap" and r.get("status") == "PASS_FIT"]
    best_fit = sorted(fits_target, key=lambda r: float(r.get("rms", "inf")))[0] if fits_target else {}

    L_db = blocks[target].get("L_database")
    L_latest = float(latest["L_derivative_trap"])
    L_inf = float(best_fit["L_inf"]) if best_fit else float("nan")
    alpha_latest = leading_alpha_inv_from_length(L_latest)
    alpha_inf = leading_alpha_inv_from_length(L_inf) if math.isfinite(L_inf) else float("nan")
    alpha_db = leading_alpha_inv_from_length(float(L_db)) if L_db is not None else float("nan")

    audit = {
        "target": target,
        "target_id": blocks[target].get("id", target),
        "L_database": L_db if L_db is not None else "",
        "L_latest_derivative": L_latest,
        "N_latest": int(latest["N_samples"]),
        "L_extrapolated_best": L_inf,
        "best_tail_p": best_fit.get("p", ""),
        "best_tail_rms": best_fit.get("rms", ""),
        "delta_latest_minus_database": (L_latest - float(L_db)) if L_db is not None else "",
        "delta_extrapolated_minus_database": (L_inf - float(L_db)) if L_db is not None and math.isfinite(L_inf) else "",
        "alpha_inv_lead_database": alpha_db,
        "alpha_inv_lead_latest": alpha_latest,
        "alpha_inv_lead_extrapolated": alpha_inf,
        "delta_alpha_latest_minus_database": (alpha_latest - alpha_db) if math.isfinite(alpha_db) else "",
        "delta_alpha_extrapolated_minus_database": (alpha_inf - alpha_db) if math.isfinite(alpha_db) and math.isfinite(alpha_inf) else "",
        "status": "ALPHA_BLIND_LEADING_LENGTH_AUDIT_NO_CODATA",
    }
    write_csv(outdir / "alpha_leading_length_audit.csv", [audit])

    # Report
    lines = []
    lines.append("# BEMv11 length-provenance report")
    lines.append("")
    lines.append("This report is alpha-blind: it does not contain or compare with observed fine structure.")
    lines.append("")
    lines.append("BEMv11 computes arclength directly from Fourier coefficients by")
    lines.append("")
    lines.append(r"\[")
    lines.append(r"L=\int_0^{2\pi}\|\mathbf{x}'(t)\|\,dt.")
    lines.append(r"\]")
    lines.append("")
    lines.append("It then audits the leading Route-B scale")
    lines.append("")
    lines.append(r"\[")
    lines.append(r"\alpha^{-1}_{\rm lead}=\frac{8\pi}{3}L.")
    lines.append(r"\]")
    lines.append("")
    lines.append("## Target summary")
    lines.append("")
    for k, v in audit.items():
        lines.append(f"- `{k}`: `{v}`")
    lines.append("")
    lines.append("## Output files")
    lines.append("")
    lines.append("- `length_convergence.csv`")
    lines.append("- `length_extrapolation_fit.csv`")
    lines.append("- `alpha_leading_length_audit.csv`")
    lines.append("")
    lines.append("## Interpretation")
    lines.append("")
    lines.append("If `L_latest_derivative` and `L_extrapolated_best` do not converge to the database Fourier arclength/provenance value, the leading Route-B alpha scale is not ppm-certified.")
    (outdir / "length_provenance_report.md").write_text("\n".join(lines), encoding="utf-8")

    config = {"args": vars(args)}
    (outdir / "run_config_v11.json").write_text(json.dumps(config, indent=2, sort_keys=True), encoding="utf-8")

    print("="*78)
    print("Route B BEMv11 length-provenance audit complete")
    print("="*78)
    print(f"outdir: {outdir}")
    print(f"target: {target}")
    print(f"L_database: {L_db}")
    print(f"L_latest_derivative: {L_latest}")
    print(f"L_extrapolated_best: {L_inf}")
    print(f"alpha_inv_lead_latest: {alpha_latest}")
    print(f"alpha_inv_lead_extrapolated: {alpha_inf}")
    print("wrote: length_convergence.csv, length_extrapolation_fit.csv, alpha_leading_length_audit.csv, length_provenance_report.md")


if __name__ == "__main__":
    main()
