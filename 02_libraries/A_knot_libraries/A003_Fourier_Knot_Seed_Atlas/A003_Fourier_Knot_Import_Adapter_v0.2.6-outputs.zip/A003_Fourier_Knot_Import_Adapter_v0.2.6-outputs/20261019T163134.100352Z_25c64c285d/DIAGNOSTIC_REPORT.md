# A003 v0.2.6 — framework 1.0.10 diagnostic execution

- Run ID: `20261019T163134.100352Z_25c64c285d`
- Framework: `1.0.10` (CANONICAL_FROZEN)
- G5 independent topological certification: **NOT CERTIFIED**
- G6/PKLSA: **NOT RUN**

| Gate | Measured status | Execution | Scientific qualification | Blocked by |
|---|---|---|---|---|
| G0 | PASS | EXECUTED | QUALIFIED | — |
| G1 | PASS | EXECUTED | QUALIFIED | — |
| G2 | PASS | EXECUTED | QUALIFIED | — |
| G3 | PASS | EXECUTED | QUALIFIED | — |
| G4 | PASS | EXECUTED | QUALIFIED | — |
| G5a | FAIL | EXECUTED | QUALIFIED | — |
| G5b | UNRESOLVED | EXECUTED | DIAGNOSTIC_ONLY | G5a |
| G5c | PASS | EXECUTED | QUALIFIED | — |
| G5d | FAIL | EXECUTED | DIAGNOSTIC_ONLY | G5a, G5b |
| G5e | PASS | EXECUTED | DIAGNOSTIC_ONLY | G5a |
| G5f | FAIL | EXECUTED | DIAGNOSTIC_ONLY | G5a, G5e |
| G6 | UNRESOLVED | NOT_EXECUTED | DIAGNOSTIC_ONLY | G5a |

Scientific negative findings remain negative; diagnostics continue without promoting downstream claims.
The raw crossing detector is independent of pyknotid but is not a complete knot invariant.
