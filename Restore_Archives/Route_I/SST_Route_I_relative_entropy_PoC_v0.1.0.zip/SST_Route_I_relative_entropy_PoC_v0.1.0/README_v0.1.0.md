# SST Route-I Resolved-Knot Action v0.1.0

## Purpose

This package evaluates the next theorem target left by v0.0.8:

\[
I_K=\frac{1}{2\pi}\oint p_K\,dq_K,
\qquad
\Omega_K=\frac{\partial E_K}{\partial I_K},
\qquad
\beta_Q=\frac{I_{\rm cell}}{\hbar}.
\]

It does **not** assume that \(E_K/\omega_K\) is always the action. That identity
holds for a linear oscillator but fails for the frozen Rankine rotor, where

\[
I_{\rm rot}=L_{\rm core}=2E/\Omega.
\]

## Main verdict

\[
\boxed{
\texttt{ACTION-CONVENTION-CLOSED / TOTAL-KNOT-UNIVERSALITY-REJECTED /}
\atop
\texttt{LOCAL-CELL-SELECTOR-CONDITIONAL / DYNAMIC-EIGENMODE-OPEN}
}
\]

## Geometry ladder

1. round ring filament (`0:1:1`);
2. resolved axisymmetric Rankine torus (`0:1:1` plus core profile);
3. ideal trefoil (`3:1:1`);
4. reflected trefoil;
5. ideal figure-eight (`4:1:1`).

The compact geometry file in `geometry/ideal_ladder.xml` is extracted from the
current uploaded `ideal_favorites.txt` and hashed in the audit report.

## Run

```bash
python sst_route1_resolved_knot_action_v0.1.0.py
```

Optional resolution:

```bash
python sst_route1_resolved_knot_action_v0.1.0.py --samples 256
```

The default run writes to `output_v0.1.0/`.

## Principal outputs

- `audit_report.json`: full machine-readable result;
- `action_ladder.csv`: resolved actions and diagnostic proxies;
- `resolution_convergence.csv`: geometry and Biot--Savart refinement;
- `core_radius_sensitivity.csv`: combined knot/action sensitivity table;
- `local_cell_fixed_points.csv`: conditional \(\beta_Q\) roots;
- `total_action_ladder.png`;
- `relative_equilibrium_residuals.png`;
- `local_cell_beta_sensitivity.png`.

## Epistemic scope

The Rankine tube calculation is `[DERIVED-CONDITIONAL]` under:

- uniform circular core profile;
- horn-envelope density used as the carrier-density branch;
- core surface speed \(v_{\!\circlearrowleft}\);
- source centerline thickness scaled by \(r_c\).

The regularized Biot--Savart calculation is a dynamical diagnostic, not a
certified finite-core Euler solution. The local-cell root is a new conditional
selector, not a CANON-level prediction.
