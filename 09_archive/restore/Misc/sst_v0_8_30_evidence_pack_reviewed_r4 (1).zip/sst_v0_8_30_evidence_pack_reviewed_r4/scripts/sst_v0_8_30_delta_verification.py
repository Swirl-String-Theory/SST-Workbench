#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Numerical and source-level verification ledger for the v0.8.28 -> v0.8.30 delta only."""
from __future__ import annotations
import argparse, json, math, re
from pathlib import Path

# Exact/2022 CODATA inputs used by the historical closed-form check.
M_E = 9.1093837139e-31       # kg
C = 299_792_458.0            # m/s exact
ALPHA = 7.2973525643e-3
HBAR = 1.054571817e-34       # J s
TARGET_J = 6.83986e-7        # kg m^-1, rounded historical reconstruction

class Ledger:
    def __init__(self): self.rows=[]
    def check(self, ident, desc, ok, **detail):
        self.rows.append({"id":ident,"desc":desc,"ok":bool(ok),"detail":detail})
        print(f"  [{'PASS' if ok else 'FAIL'}] {ident:<12} {desc}")
    def info(self, ident, desc, **detail):
        self.rows.append({"id":ident,"desc":desc,"ok":None,"detail":detail})
        print(f"  [INFO] {ident:<12} {desc}: {detail}")

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("main")
    ap.add_argument("rt")
    ap.add_argument("--json")
    args=ap.parse_args()
    mt=Path(args.main).read_text(encoding="utf-8", errors="replace")
    rt=Path(args.rt).read_text(encoding="utf-8", errors="replace")
    L=Ledger()
    print("# SST Canon v0.8.30 delta verification")

    L.check("D30-001", "version macro is 0.8.30", r"\newcommand{\canonversion}{0.8.30}" in mt)
    L.check("D30-002", "rho_f is aliased to quasi-static rho_eff^(0)", r"\boxed{\rhoF\equiv\rhoEff}" in mt)
    L.check("D30-003", "rho_sub and rho_f are not canonically identified", "No equality" in mt and "\\rhoSub=\\rhoF" in mt and "is canonical unless" in mt)
    L.check("D30-004", "rotational coefficient uses kg m^-1 role", "\\Jomega" in mt and "kg\\,m^{-1}" in mt)
    L.check("D30-005", "historical VAM expression is not a mass-density derivation", "not define a mass density" in rt)
    L.check("D30-006", "historical source audit is labeled", "subsec:rt_historical_rhof_provenance_audit" in rt)
    L.check("D30-007", "micro-macro bridge requires a squared length", r"\ell_{\omega u}^{2}" in mt and r"\beta_{\omega u}" in mt)
    L.check("D30-008", "Axiom 1 uses rho_sub as material density", r"\rhoSub=\text{constant}>0" in mt)
    L.check("D30-009", "rho_f dependency guard remains present", "[DEPENDENCY GUARD]" in mt)
    L.check("D30-010", "epoch-invariance gate remains in research track", "epoch-invariant" in rt and "present-epoch" in rt)
    L.check("D30-011", "reviewed exact-closure table guard carried forward", "Exact-closure benchmark ledger" in mt and "closure residual" in mt)
    L.check("D30-012", "reviewed omega_c precision correction carried forward", "7.76344066" not in rt and "7.76344071" in rt)

    j = 6*M_E*M_E*C/(ALPHA**5*HBAR)
    rel = abs(j-TARGET_J)/TARGET_J
    L.check("D30-013", "historical closed form reproduces 6.84e-7 kg m^-1", rel < 5e-5, value=j, target=TARGET_J, rel_error=rel)
    # Pure dimension bookkeeping: m_e^2 c / hbar -> kg/m.
    L.check("D30-014", "closed-form dimension is kg m^-1, not kg m^-3", True,
            derivation="(kg^2)(m/s)/(kg m^2/s)=kg/m")

    # The v0.8.30 delta must not claim the value is derived.
    forbidden = ["first-principles derivation of \\rhoF", "\\rhoSub=7.0\\times10^{-7}"]
    L.check("D30-015", "no forbidden promotion of rho_f or rho_sub", not any(x in mt+rt for x in forbidden), forbidden=forbidden)

    graded=[r for r in L.rows if r["ok"] is not None]
    passed=sum(bool(r["ok"]) for r in graded)
    print("\n"+"="*78)
    print(f"RESULT: {passed}/{len(graded)} delta checks passed")
    print("="*78)
    payload={"canon_version":"0.8.30","scope":"v0.8.28-to-v0.8.30 delta","passed":passed,"total":len(graded),"results":L.rows}
    if args.json:
        Path(args.json).write_text(json.dumps(payload,indent=2)+"\n",encoding="utf-8")
        print(f"[wrote {args.json}]")
    return 0 if passed==len(graded) else 1

if __name__=="__main__":
    raise SystemExit(main())
