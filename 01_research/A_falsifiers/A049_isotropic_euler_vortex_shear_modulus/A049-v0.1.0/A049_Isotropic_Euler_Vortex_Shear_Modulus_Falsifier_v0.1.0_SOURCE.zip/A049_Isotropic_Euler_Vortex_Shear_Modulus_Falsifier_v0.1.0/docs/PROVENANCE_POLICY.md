# Provenance and blindness policy

The blind campaign contains only dimensionless Euler/vorticity variables and preregistered numerical tolerances.

Forbidden until the blind tree is sealed:

- fine-structure constant \(\alpha\);
- speed of light \(c\);
- SST core radius \(r_c\);
- SST effective fluid density \(\rho_{\!f}\);
- characteristic swirl speed \(\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}\);
- canonical SST circulation.

The reveal step verifies every sealed hash before loading canonical constants. Python and native backends, when both are run, are recorded separately and parity-qualified.
