# Changelog v0.0.7

## Added

- nonlinear cylindrical core-neck link inertia;
- Rankine square-plaquette stiffness derivation;
- exact isotropic Euclidean mapping
  `beta_Q = sqrt(I_l K_l)/hbar`;
- Lambert-W adjacency solution;
- finite-volume 4D Wilson compact-U(1) Monte Carlo;
- DeGrand--Toussaint monopole-current diagnostic;
- Wilson loops and Creutz ratio;
- explicit density-carrier falsifier;
- post-freeze causal compatibility audit;
- CANON Research-Track patch.

## Changed

- `a_star`, `I_l`, and `K_l` are no longer wholly symbolic: they form an
  analytic family parameterized by `beta_Q`.
- The nonperturbative phase gate is upgraded from a dilute-defect proxy to a
  direct compact-U(1) finite-volume simulation.

## Still open

- unique beta selection;
- thermodynamic-limit phase certification;
- dynamic non-Bravais adjacency;
- blind derivation of `c_T=c`;
- Route-I gravitational area-density closure.
