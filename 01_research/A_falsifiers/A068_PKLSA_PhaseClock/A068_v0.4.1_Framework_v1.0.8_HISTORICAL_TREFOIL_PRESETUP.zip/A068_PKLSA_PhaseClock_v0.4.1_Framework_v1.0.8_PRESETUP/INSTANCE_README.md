# A068 v0.4.1 — Historical 2015 Trefoil Atlas + Euler/RPO/Floquet

This is a **new A068 scientific release candidate**, not a patch to frozen v0.4.0.
The 2015 historical XYZ archive is embedded with all 40 original geometry
files, original v0.1.0 manifest/README/regenerator. Original outer archive
filename was v0.2.0; discrepancy is explicit provenance metadata.

## New science

- Original A064/KnotPlot 47-point trefoil remains the **primary** Euler tube/RPO/Floquet test.
- 2015 model A Fourier (page 32) and model B Torus (page 66) become independent **geometric** seeds and geometry-control families only.
- In G1, verify all 40 archived file hashes, periodic polygon edge regularity, exact reversal/mirror controls; if any check fails, fail closed.
- In G2, BASIC performs 2 short 3D-Euler pilot evolutions (A/B N600). FULL/CERTIFY perform 8 short pilots (A/B N600, N1200, reversed, mirrored). Every pilot is genuine unforced 3D Euler, not a prescribed oscillator. In FULL/CERTIFY, A/B N600 additionally receive an advected material torus, a restricted identity-rotation full-vector endpoint translation candidate screen, and finite-difference-verified tangent-Euler operator. This **is not** full 24-rotation RPO shooting, nor an independent Floquet-frequency prediction. Pilots are **not** physical clock certification.
- Number of independent qualified physical dynamics providers **remains zero**.
- N600 vs N1200 is centerline sampling sensitivity, NOT Euler grid convergence.
- G3 physical clock remains UNRESOLVED until a material vortex, converged global RPO, independently heldout Floquet frequency, mesh/core tests and independent providers qualify.

## Setup

Extract the ZIP on your Windows machine, then run `SETUP_A068.cmd`;
requires local `C:\workspace\projects\SST-Workbench` and SST Falsifier
Framework v1.0.8. The installer refuses overwriting an existing v0.4.1
instance; v0.4.0 and its frozen source remain unchanged.

From the new v0.4.1 instance, execute: `run_all.cmd BASIC`, `run_all.cmd FULL`,
`run_all.cmd CERTIFY`. Expected files include
`HISTORICAL_2015_EULER_MODEL_DIAGNOSTICS.json` and the primary
`EULER_DYNAMICS_RESULTS.json` plus BLIND report and package.

Do not unblind or modify a frozen protocol to bypass gates.
