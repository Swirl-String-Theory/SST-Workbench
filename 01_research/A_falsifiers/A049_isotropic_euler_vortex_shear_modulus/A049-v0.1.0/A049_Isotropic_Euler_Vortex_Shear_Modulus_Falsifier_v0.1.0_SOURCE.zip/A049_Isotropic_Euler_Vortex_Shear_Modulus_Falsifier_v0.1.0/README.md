# A049 — Isotropic Euler-Vortex Shear-Modulus Falsifier v0.1.0

Research question:

\[
\boxed{\text{Can an isotropic Euler-vortex microstructure generate a nonzero, conservative transverse shear modulus?}}
\]

This release uses a deterministic isotropic ensemble of transverse vorticity Fourier modes and the exact incompressible Cauchy affine deformation law. It measures the quadratic kinetic-energy curvature under volume-preserving shear and separately evaluates the **Master-Factor Wave Closure Gate**.

## Critical scope distinction

v0.1.0 tests an **instantaneous/frozen-in affine (Born) modulus**. A positive result does not by itself prove a permanent zero-frequency shear modulus or a propagating electromagnetic-like mode. Full nonlinear Euler persistence/relaxation is explicitly left as the next gate.

## Blind architecture

The blind run has no SST canonical constants. It evaluates

\[
\frac{E(\gamma)}{E_0}=1+A_2\gamma^2+A_4\gamma^4+\cdots
\]

in three shear planes and tests transversality, isotropy, conservative parity, SO(3) objectivity, cycle reversibility and helicity degeneracy.

The orthodox isotropic affine benchmark is

\[
A_2=\frac{2}{15},
\qquad
\frac{\mu_{\rm Born}}{\rho u_{\rm rms}^2}=\frac{2}{15}.
\]

If, and only if, that modulus persists dynamically, the corresponding candidate transverse speed is

\[
\frac{c_T}{u_{\rm rms}}=\sqrt{\frac{2}{15}}.
\]

The preregistered Master-Factor Wave Closure Gate tests

\[
\frac{c_T}{v_*}\stackrel{?}{=}\frac12
\]

without exposing \(\alpha\), \(c\), \(r_c\), \(\rho_{\!f}\), or \(\mathbf{v}_{\!\boldsymbol{\circlearrowleft}}\) to the blind calculation.

## Run

Python reference campaign:

```bat
run_python.cmd
```

Full Python + C++17/pybind11/OpenMP qualification:

```bat
run_all.cmd
```

The full run follows the SST-Workbench blind/reveal pattern: prepare, Python campaign/tests, native build/campaign/tests, parity, seal, reveal, package.

## Outputs

```text
A049_Isotropic_Euler_Vortex_Shear_Modulus_Falsifier_v0.1.0-outputs/
A049_Isotropic_Euler_Vortex_Shear_Modulus_Falsifier_v0.1.0-outputs_BLIND.zip
A049_Isotropic_Euler_Vortex_Shear_Modulus_Falsifier_v0.1.0-outputs_REVEALED.zip
A049_Isotropic_Euler_Vortex_Shear_Modulus_Falsifier_v0.1.0-outputs.zip
```

See `docs/HYPOTHESES.md`, `docs/METHOD.md`, `docs/CANON_TRACE.md`, and `docs/PROVENANCE_POLICY.md`.
