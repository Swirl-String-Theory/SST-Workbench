#!/usr/bin/env bash
set -euo pipefail
PYTHON="${PYTHON:-python3}"

for KID in "3:1:1" "4:1:1" "5:1:1" "5:1:2" "6:1:1" "7:1:1" "7:1:2" "8:1:1" "9:1:1" "9:1:2" "10:1:1" "K11a367" "K11a247"; do
  SAFE="${KID//:/_}"
  "$PYTHON" scripts/sst_ffs_02_filament_projection_ideal.py \
    --curve ideal \
    --ideal-file data/ideal.txt \
    --ideal-id "$KID" \
    --natural-scale \
    --n 4096 \
    --smooth-width 9 \
    --ells 1 2 4 8 13 21 28 34 55 89 \
    --outdir "results_families/02_ideal_${SAFE}"

  "$PYTHON" scripts/sst_ffs_03_attachment_threshold_scan.py \
    --summary-csv "results_families/02_ideal_${SAFE}/sst_ffs_02_summary.csv" \
    --spectrum-csv "results_families/02_ideal_${SAFE}/sst_ffs_02_spectrum.csv" \
    --ells 1 2 4 8 13 21 28 34 55 89 \
    --outdir "results_families/03_threshold_${SAFE}"
done

"$PYTHON" scripts/sst_ffs_04_compare_knot_families.py \
  --family-config data/family_config.csv \
  --results-root results_families \
  --outdir results_families/04_compare

echo "Done. Check results_families/04_compare."
