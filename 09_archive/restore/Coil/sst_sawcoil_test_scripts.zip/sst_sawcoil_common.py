"""
SST SawShape coil common utilities
----------------------------------
Non-GUI utilities for testing 3-phase SawShape/Rodin-like coils with
classical PWM, geometry, Biot-Savart fields, and fR kernel scaling.

This is a classical EM / signal-processing test layer. It does not claim
or assume a real gravitational anomaly.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path
from typing import Iterable, Literal

import numpy as np

MU0 = 4.0 * math.pi * 1e-7
MU0_4PI = 1e-7
V_SWIRL = 1.09384563e6  # m/s, user canonical characteristic swirl speed
RHO_F = 7.0e-7         # kg/m^3, user canonical effective fluid density
RHO_CU_20C = 1.724e-8  # ohm m, copper at ~20 C

Profile = Literal["linear", "exponential", "inverse_exponential"]


@dataclass(frozen=True)
class SawShapeParams:
    slots: int = 40
    step_forward: int = 11
    step_backward: int = -9
    n_pairs: int = 20
    radius_bottom: float = 0.05
    radius_top: float = 0.05
    height: float = 0.0
    profile: Profile = "linear"
    profile_power: float = 2.2
    samples_per_segment: int = 10
    start_slot: int = 0
    phase_offsets: tuple[float, ...] = (0.0, 2.0 * math.pi / 3.0, 4.0 * math.pi / 3.0)
    z_center: float = 0.0


def alternating_skip_indices(slots: int, step_forward: int, step_backward: int,
                             n_pairs: int, start_slot: int = 0) -> np.ndarray:
    """Return 0-based SawShape indices alternating +step_forward and step_backward."""
    idx = int(start_slot) % int(slots)
    seq = [idx]
    for k in range(2 * int(n_pairs)):
        idx = (idx + (step_forward if k % 2 == 0 else step_backward)) % slots
        seq.append(idx)
    return np.asarray(seq, dtype=int)


def radius_profile(s: np.ndarray, rb: float, rt: float, profile: Profile, power: float) -> np.ndarray:
    s = np.asarray(s, dtype=float)
    if profile == "exponential":
        return rb + (rt - rb) * np.power(s, power)
    if profile == "inverse_exponential":
        return rt - (rt - rb) * np.power(s, power)
    return rb + (rt - rb) * s


def sawshape_phase_polyline(params: SawShapeParams, phase_offset: float = 0.0) -> np.ndarray:
    """Build one smooth 3D SawShape phase polyline."""
    slots = params.slots
    seq = alternating_skip_indices(slots, params.step_forward, params.step_backward,
                                   params.n_pairs, params.start_slot)
    base_angles = np.linspace(0.0, 2.0 * math.pi, slots, endpoint=False) - math.pi / 2.0
    n_seg = len(seq) - 1
    samples = max(2, int(params.samples_per_segment))
    s_nodes = np.linspace(0.0, 1.0, n_seg + 1)
    r_nodes = radius_profile(s_nodes, params.radius_bottom, params.radius_top,
                             params.profile, params.profile_power)
    z_nodes = params.z_center + (s_nodes - 0.5) * params.height

    xs, ys, zs = [], [], []
    for k in range(n_seg):
        a0 = base_angles[seq[k]] + phase_offset
        a1 = base_angles[seq[k + 1]] + phase_offset
        # shortest angular interpolation; this makes a smooth physical approximation
        da = (a1 - a0 + math.pi) % (2.0 * math.pi) - math.pi
        u = np.linspace(0.0, 1.0, samples, endpoint=False)
        a = a0 + u * da
        r = r_nodes[k] + u * (r_nodes[k + 1] - r_nodes[k])
        z = z_nodes[k] + u * (z_nodes[k + 1] - z_nodes[k])
        xs.append(r * np.cos(a)); ys.append(r * np.sin(a)); zs.append(z)

    # include final node
    a_end = base_angles[seq[-1]] + phase_offset
    xs.append(np.asarray([r_nodes[-1] * math.cos(a_end)]))
    ys.append(np.asarray([r_nodes[-1] * math.sin(a_end)]))
    zs.append(np.asarray([z_nodes[-1]]))
    return np.column_stack([np.concatenate(xs), np.concatenate(ys), np.concatenate(zs)])


def build_three_phase_sawshape(params: SawShapeParams) -> list[np.ndarray]:
    return [sawshape_phase_polyline(params, off) for off in params.phase_offsets]


def pwm_fourier_unipolar(duty: float, n_harmonics: int, amplitude: float = 1.0) -> np.ndarray:
    """Complex Fourier coefficients for unipolar PWM over [0,duty) with amplitude.

    Returns coefficients c[n] for n=0..n_harmonics such that
    f(t)=sum_n c[n] exp(i 2pi n t)+conj for positive n.
    The magnitude of the real sinusoidal nth harmonic is 2*abs(c[n]).
    """
    d = float(np.clip(duty, 0.0, 1.0))
    n_harmonics = int(n_harmonics)
    c = np.zeros(n_harmonics + 1, dtype=np.complex128)
    c[0] = amplitude * d
    for n in range(1, n_harmonics + 1):
        c[n] = amplitude * np.exp(-1j * math.pi * n * d) * math.sin(math.pi * n * d) / (math.pi * n)
    return c


def three_phase_currents_from_pwm(duty: float, n_harmonics: int, current_peak: float = 1.0) -> np.ndarray:
    """Return harmonic complex currents with 120-degree phase shifts.

    Shape: (3, n_harmonics+1). For phase p and harmonic n:
    I[p,n] = c[n] exp(-i n phase_offset_p).
    """
    c = pwm_fourier_unipolar(duty, n_harmonics, current_peak)
    offsets = np.asarray([0.0, 2.0 * math.pi / 3.0, 4.0 * math.pi / 3.0])
    out = np.zeros((3, n_harmonics + 1), dtype=np.complex128)
    for p, off in enumerate(offsets):
        for n in range(n_harmonics + 1):
            out[p, n] = c[n] * np.exp(-1j * n * off)
    return out


def biot_savart_points(points: np.ndarray, polyline: np.ndarray, current: complex | float = 1.0,
                       softening: float = 1e-5) -> np.ndarray:
    """Biot-Savart field at arbitrary points for a polyline and possibly complex current."""
    pts = np.asarray(points, dtype=float)
    poly = np.asarray(polyline, dtype=float)
    B = np.zeros((pts.shape[0], 3), dtype=np.complex128 if np.iscomplexobj(current) else np.float64)
    p0 = poly[:-1]
    p1 = poly[1:]
    dl = p1 - p0
    mid = 0.5 * (p0 + p1)
    eps2 = float(softening) ** 2
    for dL, m in zip(dl, mid):
        r_vec = pts - m
        r2 = np.sum(r_vec * r_vec, axis=1) + eps2
        r3 = r2 * np.sqrt(r2)
        B += (MU0_4PI * current) * np.cross(np.broadcast_to(dL, r_vec.shape), r_vec) / r3[:, None]
    return B


def make_grid(bounds: float = 0.10, res: int = 21, z: float | None = None) -> tuple[np.ndarray, tuple[np.ndarray, ...]]:
    x = np.linspace(-bounds, bounds, int(res))
    y = np.linspace(-bounds, bounds, int(res))
    if z is None:
        zz = np.linspace(-bounds, bounds, int(res))
        X, Y, Z = np.meshgrid(x, y, zz, indexing="ij")
    else:
        X, Y = np.meshgrid(x, y, indexing="ij")
        Z = np.full_like(X, float(z))
    points = np.column_stack([X.ravel(), Y.ravel(), Z.ravel()])
    return points, (X, Y, Z)


def magnetic_energy_density(B: np.ndarray) -> np.ndarray:
    return np.real(np.sum(B * np.conjugate(B), axis=-1)) / (2.0 * MU0)


def magnetic_pressure_proxy(B: np.ndarray) -> np.ndarray:
    return -magnetic_energy_density(B)


def kernel_x(n: int, f0: float, radius: float, v: float = V_SWIRL) -> float:
    return 2.0 * math.pi * int(n) * float(f0) * float(radius) / float(v)


def frequency_for_x(x: float, n: int, radius: float, v: float = V_SWIRL) -> float:
    return float(x) * float(v) / (2.0 * math.pi * int(n) * float(radius))


def skin_depth_copper(f: float, rho: float = RHO_CU_20C, mu: float = MU0) -> float:
    return math.sqrt(2.0 * rho / (mu * 2.0 * math.pi * float(f)))


def write_csv(path: str | Path, header: Iterable[str], rows: Iterable[Iterable[object]]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    import csv
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(list(header))
        w.writerows(rows)
