# SST Threaded-Hole Substrate v0.2.1 — post-seal reveal

Seal verification: **PASS**.

## Self-confinement
- Carrier-clustered verdict: **INDETERMINATE** — active carriers 0, null carriers 1.

## Pressure / gravity
- Central pressure: **INDETERMINATE_PRESSURE_DEFICIT**.
- Even quadratic pressure law: **INDETERMINATE_PRESSURE_LAW**.
- Source monopole: **INDETERMINATE_OR_WRONG_MONOPOLE**.
- Free exponent: **INDETERMINATE_FREE_EXPONENT**, median ν=0.3375.
- Exponent convergence: **NEEDS_OR_FAILS_FAR_FIELD_CONVERGENCE**; monopole convergence: **NEEDS_OR_FAILS_MONOPOLE_CONVERGENCE**.
- Combined: **GRAVITY_CLOSURE_NOT_SUPPORTED**.

## Thread focusing
- **INDETERMINATE_THREAD_FOCUSING** from active versus passive zero-circulation tracer threads.

## Confirmatory stability
- **CONFIRMATORY_NOT_ESTABLISHED** across 0 preregistered pairs.

## Stability discovery
- 1 carrier minima reported as discovery only.

## Triple gear
- Geometric marker-invariant phase proxy available for 36 conditions; active score lower in 17. No gear ratio was supplied.

Zero-circulation ghost threads are excluded from contact and CFL gates in v0.2.1.
