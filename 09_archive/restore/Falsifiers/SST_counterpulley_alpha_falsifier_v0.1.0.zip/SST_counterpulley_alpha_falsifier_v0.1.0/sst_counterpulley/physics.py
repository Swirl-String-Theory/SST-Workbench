"""Blind hydrodynamic observables.

IMPORTANT: this module contains no fine-structure-constant value.  It can be run and
archived before any alpha benchmark is evaluated.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math
from typing import Any
import numpy as np

from .backend import load_backend
from .geometry import make_counter_channels, polygon_length, resample_closed

@dataclass
class BlindResult:
    n: int
    D: float
    offset_over_D: float
    eps_over_D: float
    gamma_plus: float
    gamma_minus: float
    backend: str
    centerline_length: float
    plus_length: float
    minus_length: float
    H_pp: float
    H_mm: float
    H_pm: float
    E_self_sum: float
    E_cross: float
    E_pair: float
    G_energy: float
    delta_energy_rel: float
    omega_plus_mean_dimless: float
    omega_minus_mean_dimless: float
    omega_relative_mean_dimless: float
    mutual_speed_rms_dimless: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _cross_section_omega(r: np.ndarray, u: np.ndarray, tangent: np.ndarray) -> np.ndarray:
    r2 = np.einsum("ij,ij->i", r, r)
    return np.einsum("ij,ij->i", np.cross(r, u), tangent) / r2


def compute_blind(centerline: np.ndarray, *, D: float,
                  offset_over_D: float = 0.5, eps_over_D: float = 0.05,
                  gamma_plus: float = 1.0, gamma_minus: float = -1.0, phase: float = 0.0,
                  force_python: bool = False, skip_build: bool = False,
                  force_build: bool = False, build_verbose: bool = False) -> BlindResult:
    p = np.ascontiguousarray(centerline, dtype=float)
    if D <= 0:
        raise ValueError("D must be > 0")
    if not (0 < offset_over_D <= 2.0):
        raise ValueError("offset_over_D must be in (0,2]")
    if eps_over_D <= 0:
        raise ValueError("eps_over_D must be > 0")
    offset = offset_over_D * D
    eps = eps_over_D * D
    plus, minus, tangent, normal = make_counter_channels(p, offset, phase=phase)
    # Reparameterize each offset filament independently for stable line-quadrature convergence.
    plus_energy = resample_closed(plus, len(p))
    minus_energy = resample_closed(minus, len(p))
    backend, backend_name = load_backend(force_python=force_python, skip_build=skip_build,
                                         force_build=force_build, build_verbose=build_verbose)
    Hpp = float(backend.interaction_hamiltonian(plus_energy, plus_energy, gamma_plus, gamma_plus, eps))
    Hmm = float(backend.interaction_hamiltonian(minus_energy, minus_energy, gamma_minus, gamma_minus, eps))
    Hpm = float(backend.interaction_hamiltonian(plus_energy, minus_energy, gamma_plus, gamma_minus, eps))
    Eself = Hpp + Hmm
    Ecross = 2.0 * Hpm
    Epair = Eself + Ecross
    if abs(Eself) < 1e-30:
        raise ZeroDivisionError("Self-energy normalization vanished")
    G = Epair / Eself

    # Purely diagnostic mutual-induction rotation/translation measures.
    u_plus = np.asarray(backend.induced_velocity(plus, minus, gamma_minus, eps), dtype=float)
    u_minus = np.asarray(backend.induced_velocity(minus, plus, gamma_plus, eps), dtype=float)
    r_plus = offset * normal
    r_minus = -offset * normal
    om_plus = _cross_section_omega(r_plus, u_plus, tangent)
    om_minus = _cross_section_omega(r_minus, u_minus, tangent)
    # Normalize omega by |Gamma|/(4 pi D^2); speed by |Gamma|/(4 pi D).
    gscale = 0.5 * (abs(gamma_plus) + abs(gamma_minus))
    if gscale <= 0:
        gscale = 1.0
    omega_scale = gscale / (4.0 * math.pi * D * D)
    speed_scale = gscale / (4.0 * math.pi * D)
    rel_omega = 0.5 * (om_plus - om_minus)
    mutual_speed = np.sqrt(0.5 * (np.einsum("ij,ij->i", u_plus, u_plus) + np.einsum("ij,ij->i", u_minus, u_minus)))

    return BlindResult(
        n=len(p), D=float(D), offset_over_D=float(offset_over_D), eps_over_D=float(eps_over_D),
        gamma_plus=float(gamma_plus), gamma_minus=float(gamma_minus), backend=backend_name,
        centerline_length=polygon_length(p), plus_length=polygon_length(plus), minus_length=polygon_length(minus),
        H_pp=Hpp, H_mm=Hmm, H_pm=Hpm, E_self_sum=Eself, E_cross=Ecross, E_pair=Epair,
        G_energy=float(G), delta_energy_rel=float(G - 1.0),
        omega_plus_mean_dimless=float(np.mean(om_plus) / omega_scale),
        omega_minus_mean_dimless=float(np.mean(om_minus) / omega_scale),
        omega_relative_mean_dimless=float(np.mean(rel_omega) / omega_scale),
        mutual_speed_rms_dimless=float(np.sqrt(np.mean(mutual_speed**2)) / speed_scale),
    )
