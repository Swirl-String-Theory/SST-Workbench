from setuptools import setup, Extension
import pybind11

ext_modules = [
    Extension(
        "sst_eft_native._native",
        ["cpp/native.cpp"],
        include_dirs=[pybind11.get_include()],
        language="c++",
        extra_compile_args=["/O2", "/std:c++17"] if __import__("os").name == "nt" else ["-O3", "-std=c++17"],
    )
]

setup(
    name="sst-material-phase-eft-blind-falsifier",
    version="0.1.0",
    packages=["sst_eft", "sst_eft_native"],
    ext_modules=ext_modules,
)
