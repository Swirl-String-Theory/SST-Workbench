# CHANGELOG

## v0.3.0

### Added

- true temporal two-filament `pair_rhs` kernel in C++ and Python;
- central-difference linearisation in the best co-rigid frame;
- pre-registered `m=1` Kelvin Galerkin subspace;
- coupled 4x4 projected temporal generator;
- internally generated counter-propagating eigenmode clock;
- frozen monodromy multipliers and signed relative eigenphase;
- strict H3 relative-equilibrium/Floquet-eligibility gate;
- independent basis-gauge vs physical channel-orientation sweeps;
- H0-H12 blind archive plus separately imported H13 alpha benchmark;
- high-resolution convergence ladder through `N=2048`;
- detection/reporting of preconverged post-hoc near-hits.

### Changed

- v0.2 clock-free holonomy is retained only as a topology-collapse control;
- energy and local phase-clock ansatzes are no longer primary candidates;
- benchmark architecture now requires the blind gate summary to exist before alpha is opened.

### Reference conclusion

- H3 FAIL: current double-trefoil is not a relative equilibrium (`R_rel ~ 0.99895`).
- H10 FAIL: strong core/orientation nuisance dependence.
- H11 FAIL: one counter-propagating mode is not sufficiently oscillatory.
- H12 PASS: the temporal eigenphase is genuinely distinct from ribbon twist.
- H13 FAIL: converged canonical `h_F=-0.14365614` misses the required post-hoc correction by about 22.49%.
