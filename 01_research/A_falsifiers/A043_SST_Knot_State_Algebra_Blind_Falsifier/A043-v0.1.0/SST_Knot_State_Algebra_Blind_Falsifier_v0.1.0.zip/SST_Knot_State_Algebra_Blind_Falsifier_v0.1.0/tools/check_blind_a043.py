from pathlib import Path
import argparse, hashlib, json
from sst_falsifier_core.blind import scan_tree
p=argparse.ArgumentParser();p.add_argument('--denylist',default=None);a=p.parse_args()
# Structural guard: private/reveal material must not be present in the blind source tree.
struct=[]
for x in Path('.').rglob('*'):
    if not x.is_file(): continue
    low=x.as_posix().lower()
    if 'private_reveal.json' in low or '/reveal_private/' in low or '/private/' in low:
        struct.append({'path':x.as_posix(),'reason':'private material in blind tree'})
term_hits=[]; commitment_ok=None
if a.denylist:
    d=Path(a.denylist); expected=Path('DENYLIST_COMMITMENT.sha256').read_text().strip().split()[0]; actual=hashlib.sha256(d.read_bytes()).hexdigest(); commitment_ok=(expected==actual)
    if commitment_ok:
        terms=tuple(t.strip() for t in d.read_text(encoding='utf-8').splitlines() if t.strip())
        term_hits=scan_tree('.',forbidden=terms)
        # Guard/helper docs may name the mechanism but should not contain private target values; no broad whitelist here.
        term_hits=[h for h in term_hits if h['path'] not in {'README.md','PREREGISTRATION.md'}]
else:
    commitment_ok=None
ok=not struct and not term_hits and commitment_ok is not False
print(json.dumps({'ok':ok,'structural_hits':struct,'denylist_checked':bool(a.denylist),'denylist_commitment_ok':commitment_ok,'term_hits':term_hits},indent=2))
raise SystemExit(0 if ok else 1)
