from pathlib import Path
import json, math
from sst_vortex_shear.campaign import verify_seal
from sst_vortex_shear.reveal_constants import C, ALPHA, V_CIRCLEARROW, R_C, RHO_F

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/"A049_Isotropic_Euler_Vortex_Shear_Modulus_Falsifier_v0.2.0-outputs"
BLIND=BASE/"BLIND"; OUT=BASE/"REVEALED"; OUT.mkdir(parents=True,exist_ok=True)
ok,errors=verify_seal(BLIND)
if not ok: raise SystemExit("Blind seal verification failed: "+"; ".join(errors))
py_summary=json.loads((BLIND/"python_backend"/"blind_summary.json").read_text(encoding="utf-8"))
native_path=BLIND/"native_backend"/"blind_summary.json"; parity_path=BLIND/"backend_parity_summary.json"
native=json.loads(native_path.read_text(encoding="utf-8")) if native_path.exists() else None
parity=json.loads(parity_path.read_text(encoding="utf-8")) if parity_path.exists() else None
release_mode="FULL_PYTHON_NATIVE_QUALIFIED" if native is not None and parity is not None and parity.get("status")=="PASS" else "PYTHON_REFERENCE_ONLY"

born_ratio=float(py_summary["static_born"]["candidate_cT_over_urms"])
born_c=born_ratio*V_CIRCLEARROW
born_mu=RHO_F*born_c**2
target_c=0.5*V_CIRCLEARROW
target_mu=RHO_F*target_c**2
master_target=4.0/ALPHA
born_c_over= C/born_c
born_master_rel=abs(born_c_over-master_target)/master_target

dyn=py_summary["dynamic_primary"]
dyn_primary=float(dyn["primary_c_over_urms_median_diagnostic"])
dyn_secondary=float(dyn["secondary_c_over_urms_median_diagnostic"])
dyn_diag=0.5*(dyn_primary+dyn_secondary)
dyn_c_diag=dyn_diag*V_CIRCLEARROW
Gamma=2.0*math.pi*R_C*V_CIRCLEARROW

revealed={
 "catalog_id":"A049","version":"v0.2.0","blind_seal_verified":True,"release_mode":release_mode,
 "blind_pipeline_status":py_summary["pipeline_status"],"research_question_status":py_summary["research_question_status"],
 "dynamic_wave_status":py_summary["dynamic_wave_status"],"master_factor_wave_closure_status":py_summary["master_factor_wave_closure_status"],
 "canonical_constants":{"c_m_s":C,"alpha":ALPHA,"v_circlearrow_m_s":V_CIRCLEARROW,"r_c_m":R_C,"rho_f_kg_m3":RHO_F,"Gamma_m2_s":Gamma},
 "born_carry_forward":{"cT_over_urms":born_ratio,"strict_u_rms_equals_v_circlearrow_cT_m_s":born_c,"strict_mu_Pa":born_mu,"c_over_cT":born_c_over,"target_4_over_alpha":master_target,"relative_master_mismatch":born_master_rel},
 "master_target":{"cT_over_v_circlearrow":0.5,"cT_m_s":target_c,"mu_if_rho_eff_equals_rho_f_Pa":target_mu,"alpha_c_over_4_m_s":ALPHA*C/4.0},
 "dynamic_diagnostic_not_a_qualified_wave":{"primary_median_c_over_urms":dyn_primary,"secondary_median_c_over_urms":dyn_secondary,"combined_naive_c_over_urms":dyn_diag,"combined_naive_c_m_s_under_strict_mapping":dyn_c_diag,"guard":"No probe set qualified as a conservative isotropic transverse pole; these phase-fit speeds are diagnostics only and are not interpreted as a physical c_T."},
 "resolution_diagnostic":{"grid_n":dyn["n"],"spectral_edge_energy_fraction_final":dyn["spectral_edge_energy_fraction_final"],"coarse_same_sign_gate":py_summary["hypothesis_gates"]["H06_COARSE_RESOLUTION_SAME_QUALIFICATION_SIGN"]},
 "interpretation":"The frozen-in Born modulus remains nonzero, but this v0.2.0 Euler persistence run did not produce a universal low-k conservative transverse pole. Therefore the dynamic Master-Factor Wave Closure Gate is not reached, and the overall master closure remains NOT_CLOSED. The negative result is resolution-bounded, not a theorem of impossibility."
}
(OUT/"reveal_summary.json").write_text(json.dumps(revealed,indent=2),encoding="utf-8")
lines=[
 "# A049 v0.2.0 reveal report","", "Blind seal: **VERIFIED**",f"Release mode: **{release_mode}**",
 f"Pipeline: **{py_summary['pipeline_status']}**",f"Research question: **{py_summary['research_question_status']}**",
 f"Dynamic wave: **{py_summary['dynamic_wave_status']}**",f"Master-Factor Wave Closure: **{py_summary['master_factor_wave_closure_status']}**","",
 "## Born carry-forward","",f"- c_T/u_rms = {born_ratio:.12e}",f"- strict-map c_T = {born_c:.12e} m s^-1",f"- strict-map mu = {born_mu:.12e} Pa",f"- c/c_T = {born_c_over:.12e}",f"- target 4/alpha = {master_target:.12e}",f"- relative mismatch = {born_master_rel:.12e}","",
 "## Dynamic persistence","",f"- qualified probes = {dyn['qualified_probe_count']}/{dyn['probe_count']}",f"- primary diagnostic median c/u_rms = {dyn_primary:.12e}",f"- secondary diagnostic median c/u_rms = {dyn_secondary:.12e}",f"- final spectral-edge energy fraction = {dyn['spectral_edge_energy_fraction_final']:.12e}","",
 "## Master target","",f"- target c_T/v_circlearrow = 0.5",f"- target c_T = {target_c:.12e} m s^-1",f"- target mu (if rho_eff=rho_f) = {target_mu:.12e} Pa","",
 "## Interpretation","",revealed["interpretation"]]
(OUT/"reveal_report.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
print(json.dumps(revealed,indent=2))
