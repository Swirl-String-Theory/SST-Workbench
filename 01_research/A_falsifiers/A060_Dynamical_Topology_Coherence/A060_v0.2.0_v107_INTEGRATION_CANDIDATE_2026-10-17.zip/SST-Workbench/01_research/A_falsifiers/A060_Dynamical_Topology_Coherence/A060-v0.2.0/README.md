# A060 v0.2.0 / v1.0.7 integration candidate

DEVELOPMENT / NOT CERTIFIED. Additive delivery dated 17 October 2026; never extract over the historical A060-v0.2.0, v0.2.1, v0.3.0 or v0.1.0 folders. Use an isolated Workbench clone for review.

Generated with the byte-verified frozen v1.0.7 generator, profile multilibrary_gpu. M00 maps to G0/G1; M01-M04 map only to G2. Official scientific G0-G9 remain UNRESOLVED; engineering prechecks are separate.

Windows: install requirements, then `run_all.cmd SELFTEST` (framework tests), `run_python.cmd -m pytest tests -q` (instance tests), `run_precheck.cmd` (analytic engineering controls), and `run_python.cmd -m tools.native_precheck` (partial native tensor controls). Inspect evidence JSON; an exit status alone is not a scientific verdict.

Order after readiness is resolved: SELFTEST -> FREEZE -> BASIC -> FULL -> CERTIFY -> REVEAL_IF_ALLOWED. The generated launcher has one documented instance-local readiness guard; the original generator output is retained under integration/. No framework source was modified. Current FREEZE and science/reveal modes intentionally stop before execution because required production definitions/providers and registry authority remain UNRESOLVED.

The private generator keys are omitted from the public source archive. Generate fresh keys before a future prospective campaign. No private data, freeze commitment or reveal artifact is delivered as scientific evidence. All existing Drive versions and A054 were left unchanged. The v0.3.0 A045/A046 identity map is recorded as a lead pending authoritative registry confirmation.
