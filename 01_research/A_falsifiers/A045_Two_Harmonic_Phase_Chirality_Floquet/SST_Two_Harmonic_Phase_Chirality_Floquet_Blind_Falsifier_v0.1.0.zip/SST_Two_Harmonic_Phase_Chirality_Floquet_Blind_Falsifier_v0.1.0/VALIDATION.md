# Validation status

The Python reference is intended to be executed first. C++/pybind11 source is included but native parity is not certified until the native extension has been compiled and compared against the Python backend at matched `N`, `dt`, phase, and chirality.

Scientific status of v0.1.0: architecture / symmetry pre-falsifier only. Finite-core hydrodynamic certification remains a later gate.
