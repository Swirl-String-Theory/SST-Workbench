#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""Pure-Python backend for SST chi-phase package v7.

v7 compares the v6 smooth-matched closure root against legacy vortex-ring
core constants (alpha, beta), including the old NLS target alpha=1.61,beta=0.61.

Important epistemic status:
- This module does NOT derive physical ring constants alpha_eff,beta_eff from
  the profile.
- It uses the legacy constants as external targets and compares them to the
  smooth-matched shape parameter a0.
- Therefore v7 is a target/comparison package, not a proof of a vortex-ring
  energy constant.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import math
from typing import Dict, List

PHI = (1.0 + math.sqrt(5.0)) / 2.0
A0_STAR = (-13.0 + math.sqrt(385.0)) / 4.0
NLS_ALPHA = 1.61
NLS_BETA = 0.61

@dataclass
class LegacyTarget:
    key: str
    label: str
    alpha: float
    beta: float
    relation: str
    source_status: str

    def to_dict(self) -> Dict[str, object]:
        d = asdict(self)
        d.update(evaluate_at_a0(self.alpha))
        d["a0_minus_a0_star"] = self.alpha - A0_STAR
        d["a0_minus_phi"] = self.alpha - PHI
        d["beta_minus_alpha_minus_1"] = self.beta - (self.alpha - 1.0)
        d["beta_minus_alpha_minus_3_over_2"] = self.beta - (self.alpha - 1.5)
        return d

LEGACY_TARGETS: List[LegacyTarget] = [
    LegacyTarget("solid_core_constant_volume", "solid core, constant volume", 1.75, 0.25, "beta=alpha-3/2", "legacy ring table"),
    LegacyTarget("hollow_core_constant_volume", "hollow core, constant volume", 2.00, 0.50, "beta=alpha-3/2", "legacy ring table"),
    LegacyTarget("hollow_core_constant_pressure", "hollow core, constant pressure", 1.50, 0.50, "beta=alpha-1", "legacy ring table"),
    LegacyTarget("hollow_surface_tension", "hollow core, surface tension", 1.00, 0.00, "beta=alpha-1", "legacy ring table"),
    LegacyTarget("nls_legacy", "Nonlinear Schrodinger / NLS", NLS_ALPHA, NLS_BETA, "beta≈alpha-1", "legacy NLS target"),
]


def smooth_matched_poly(x: float, a0: float) -> float:
    x2 = x * x
    return x * (a0 + (3.0 - 2.0 * a0) * x2 + (a0 - 2.0) * x2 * x2)


def c2_over_v2_smooth(a0: float) -> float:
    # 4 int_0^1 f_a(x)^2 x^3 dx for uniform density.
    return (2.0 * a0 * a0 + 13.0 * a0 + 78.0) / 105.0


def c_over_v_smooth(a0: float) -> float:
    return math.sqrt(c2_over_v2_smooth(a0))


def root_residual(a0: float) -> float:
    return c2_over_v2_smooth(a0) - 1.0


def analytic_root() -> float:
    return A0_STAR


def bisection_root(lo: float = 0.0, hi: float = 3.0, tol: float = 1e-14, max_iter: int = 200) -> float:
    flo = root_residual(lo)
    fhi = root_residual(hi)
    if flo * fhi > 0.0:
        raise ValueError("root not bracketed")
    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        fm = root_residual(mid)
        if abs(fm) < tol or 0.5 * (hi - lo) < tol:
            return mid
        if flo * fm <= 0:
            hi = mid
            fhi = fm
        else:
            lo = mid
            flo = fm
    return 0.5 * (lo + hi)


def evaluate_at_a0(a0: float) -> Dict[str, float]:
    c2 = c2_over_v2_smooth(a0)
    c = math.sqrt(c2)
    return {
        "a0_as_profile_parameter": a0,
        "c2_over_v2": c2,
        "c_over_v": c,
        "closure_residual_c2_minus_1": c2 - 1.0,
        "closure_residual_c_minus_1": c - 1.0,
    }


def special_points() -> List[Dict[str, object]]:
    rows = []
    for key, label, a0 in [
        ("a0_star", "v6 closure root", A0_STAR),
        ("phi", "golden ratio", PHI),
        ("nls_alpha", "legacy NLS alpha", NLS_ALPHA),
        ("nls_beta_plus_1", "legacy NLS beta+1", NLS_BETA + 1.0),
    ]:
        d = {"key": key, "label": label, "a0": a0}
        d.update(evaluate_at_a0(a0))
        d["distance_to_a0_star"] = a0 - A0_STAR
        d["distance_to_phi"] = a0 - PHI
        rows.append(d)
    return rows


def legacy_rows() -> List[Dict[str, object]]:
    return [t.to_dict() for t in LEGACY_TARGETS]


def nearest_targets() -> Dict[str, object]:
    rows = legacy_rows()
    by_a0 = min(rows, key=lambda r: abs(float(r["alpha"]) - A0_STAR))
    by_closure = min(rows, key=lambda r: abs(float(r["closure_residual_c_minus_1"])))
    by_phi = min(rows, key=lambda r: abs(float(r["alpha"]) - PHI))
    return {
        "nearest_alpha_to_a0_star_key": by_a0["key"],
        "nearest_alpha_to_a0_star_alpha": by_a0["alpha"],
        "nearest_alpha_to_a0_star_delta": float(by_a0["alpha"]) - A0_STAR,
        "nearest_closure_key": by_closure["key"],
        "nearest_closure_c_over_v": by_closure["c_over_v"],
        "nearest_closure_error": by_closure["closure_residual_c_minus_1"],
        "nearest_alpha_to_phi_key": by_phi["key"],
        "nearest_alpha_to_phi_alpha": by_phi["alpha"],
        "nearest_alpha_to_phi_delta": float(by_phi["alpha"]) - PHI,
    }


def sweep_a0(a_min: float = 0.5, a_max: float = 2.5, count: int = 801) -> List[Dict[str, float]]:
    rows = []
    for i in range(count):
        a0 = a_min + (a_max - a_min) * i / (count - 1)
        d = {"a0": a0}
        d.update(evaluate_at_a0(a0))
        d["abs_closure_error"] = abs(d["closure_residual_c_minus_1"])
        d["distance_to_phi"] = a0 - PHI
        d["distance_to_nls_alpha"] = a0 - NLS_ALPHA
        rows.append(d)
    return rows
