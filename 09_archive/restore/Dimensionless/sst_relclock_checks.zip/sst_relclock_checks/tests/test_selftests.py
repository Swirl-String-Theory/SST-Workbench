"""
Analytic ground-truth self-tests.

These are the acceptance gates for the suite itself. If any of these fails,
none of the six checks may be reported.
"""
import numpy as np
import pytest

from sstrc import clocks as C
from sstrc import constants as K
from sstrc import dyn, geom


# --------------------------------------------------------------------- geometry
def test_circle_curvature_and_length():
    X = geom.circle(256, R=1.0)
    kap, tau, L = geom.curvature_torsion(X)
    assert abs(L - 2 * np.pi) < 1e-3
    assert np.allclose(kap, 1.0, atol=1e-4)
    assert np.max(np.abs(tau)) < 1e-3


def test_circle_writhe_is_zero():
    assert abs(geom.writhe(geom.circle(256))) < 1e-6


def test_trefoil_writhe_magnitude_and_convergence():
    rows = geom.writhe_convergence(lambda N: geom.torus_knot(N, 2, 3))
    w = rows[-1]["writhe"]
    # T(2,3) in this embedding is left-handed; |Wr| ~ 3.34
    assert 2.5 < abs(w) < 4.0
    assert abs(rows[-1]["delta_vs_prev"]) < 5e-2


def test_calugareanu_integrality_converges():
    """Lk = Wr + Tw must approach the integer -3 for the trefoil.
    This is the joint acceptance gate for BOTH the writhe and the twist code."""
    defects = []
    for N in (96, 192, 384):
        X = geom.resample_uniform(geom.torus_knot(N, 2, 3))
        u = geom.init_material_frame(X)
        lk = geom.writhe(X) + geom.twist(X, u)
        defects.append(abs(lk - round(lk)))
        assert round(lk) == -3, (N, lk)
    assert defects[0] > defects[1] > defects[2]
    assert defects[-1] < 1e-3


def test_integer_twist_offset_is_exact():
    """An integer winding shifts Tw by exactly that integer (so it shifts Lk by
    an integer and cannot affect the Lk-drift measurement of check 2)."""
    X = geom.resample_uniform(geom.torus_knot(192, 2, 3))
    base = geom.twist(X, geom.init_material_frame(X, 0))
    for turns in (1, -2, 3):
        got = geom.twist(X, geom.init_material_frame(X, turns))
        assert abs(got - base - turns) < 1e-9, (turns, got, base)


def test_non_integer_twist_is_rejected():
    X = geom.resample_uniform(geom.torus_knot(96, 2, 3))
    with pytest.raises(ValueError):
        geom.init_material_frame(X, 0.37)


def test_frame_stays_perpendicular():
    X = geom.resample_uniform(geom.torus_knot(128, 2, 3))
    u = geom.init_material_frame(X, 1.0)
    T = geom.edge_tangents(X)
    assert np.max(np.abs(np.einsum("ij,ij->i", u, T))) < 1e-10


def test_parallel_transport_preserves_norm_and_angle():
    rng = np.random.default_rng(0)
    t1 = geom.unit(rng.normal(size=(20, 3)))
    t2 = geom.unit(rng.normal(size=(20, 3)))
    v = np.cross(t1, geom.unit(rng.normal(size=(20, 3))))
    w = geom.parallel_transport(v, t1, t2)
    assert np.allclose(np.linalg.norm(w, axis=1), np.linalg.norm(v, axis=1), atol=1e-12)


# ------------------------------------------------------------------- invariants
def test_enstrophy_scales_as_a_minus_two():
    z1 = dyn.enstrophy(10.0, 0.05, 1.0)
    z2 = dyn.enstrophy(10.0, 0.10, 1.0)
    assert abs(z1 / z2 - 4.0) < 1e-12


def test_circle_translates_without_changing_length():
    """A vortex ring must self-propagate rigidly: length and energy conserved."""
    X = geom.circle(96, R=1.0)
    cfg = dyn.SolverConfig(N=96, a=0.05, steps=200, sample_every=20, cfl=0.25)
    tr = dyn.run(X, cfg)
    assert abs(tr.L[-1] / tr.L[0] - 1.0) < 1e-4
    assert abs(tr.E[-1] / tr.E[0] - 1.0) < 1e-4
    assert abs(tr.Rg[-1] / tr.Rg[0] - 1.0) < 1e-4


def test_linking_is_conserved_while_writhe_and_twist_exchange():
    """The M2 gate. Wr and Tw must both move; their SUM must be frozen at a
    level far below either range."""
    X = geom.resample_uniform(geom.torus_knot(96, 2, 3))
    cfg = dyn.SolverConfig(N=96, a=0.05, steps=400, sample_every=20, cfl=0.0625)
    tr = dyn.run(X, cfg)
    drift = float(np.max(np.abs(tr.Lk - tr.Lk[0])))
    assert np.ptp(tr.Wr) > 1e-3, "vacuous: writhe did not move"
    assert np.ptp(tr.Tw) > 1e-3, "vacuous: twist did not move"
    assert drift < 0.1 * min(np.ptp(tr.Wr), np.ptp(tr.Tw))


def test_linking_drift_converges_under_timestep_refinement():
    X = geom.resample_uniform(geom.torus_knot(96, 2, 3))
    drifts = []
    for cfl in (0.25, 0.0625):
        cfg = dyn.SolverConfig(N=96, a=0.05, steps=400, sample_every=40, cfl=cfl)
        tr = dyn.run(X.copy(), cfg)
        drifts.append(float(np.max(np.abs(tr.Lk - tr.Lk[0]))))
    assert drifts[1] < drifts[0] / 3.0, drifts


# ----------------------------------------------------------------------- clocks
def test_unsigned_clock_is_monotone_signed_is_not():
    q = np.array([0.0, 1.0, 0.5, 2.0, 1.0])
    assert C.is_monotone(C.cumulative_abs(q))
    assert not C.is_monotone(C.cumulative_signed(q))


def test_tau_pair_can_decrease():
    """Faithful Barontini Eq. (3): non-monotone when dq and dphi disagree."""
    q = np.array([0.0, 1.0, 2.0, 3.0])
    phi = np.array([0.0, 1.0, 0.5, 1.5])
    tp = C.tau_pair(q, phi)
    assert np.any(np.diff(tp) < 0)


def test_collapse_score_is_scale_invariant():
    rng = np.random.default_rng(1)
    Ys = [rng.normal(size=50).cumsum() for _ in range(5)]
    cl = [C.normalise_clock(np.arange(50.0)) for _ in range(5)]
    cl2 = [C.normalise_clock(1.234e-21 * np.arange(50.0)) for _ in range(5)]
    e1 = C.collapse_score(cl, C.zscore_pool(Ys))
    e2 = C.collapse_score(cl2, C.zscore_pool(Ys))
    assert abs(e1 - e2) < 1e-12


def test_random_warp_is_monotone_and_normalised():
    rng = np.random.default_rng(2)
    for dof in (1, 4, 12):
        w = C.random_monotone_warp(80, dof, rng)
        assert C.is_monotone(w) and abs(w[0]) < 1e-15 and abs(w[-1] - 1.0) < 1e-12


def test_shannon_and_fisher_agree_on_a_frozen_spectrum():
    P = np.tile(np.array([4.0, 2.0, 1.0, 0.5]), (10, 1))
    assert np.ptp(C.shannon_nats(P)) < 1e-12
    assert C.fisher_rao_path(P)[-1] < 1e-10


# -------------------------------------------------------------------- constants
def test_compton_closure_tautologies_close():
    k = K.build_constants()
    for row in K.tautology_ledger(k):
        assert abs(row["rel_residual"]) < 1e-12, row["quantity"]


def test_canon_r_c_anchor_is_off_in_ninth_digit():
    """Regression guard for canon patch 0004."""
    k = K.build_constants()
    row = [d for d in K.anchor_deviations(k) if d["quantity"] == "r_c"][0]
    assert row["status"] == "MISMATCH"
    assert row["first_wrong_significant_digit"] == 9


def test_single_codata_release_declared():
    assert "CODATA" in K.build_constants().release.upper()


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
