# Changelog v0.0.2

- Added exact derivation of `Phi_T = sqrt(Z_T) A`.
- Added quantum normalization `varphi_T = sqrt(Z_T/hbar) A`.
- Added dimensionless affine normalization `phi_hat = L_* varphi_T`.
- Added action, Hamiltonian, symplectic, and round-trip tests.
- Added configurable `--normalization-length-scale`.
- Added configurable `--torsion-stiffness` to test non-calibrated proposals.
- Added `normalization_scale_sweep.csv`.
- Added a core-scale linear-strain warning rather than silently identifying the
  normalized pulse with a literal core displacement.
