@echo off
setlocal EnableExtensions
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
pushd "%~dp0"
set "OUT=Gate2_Trefoil_FullField_v0.2.0-outputs"
echo [1/4] Software tests
python -m pytest -q tests > "%OUT%\pytest.log" 2>&1
if errorlevel 1 goto :fail
type "%OUT%\pytest.log"
echo [2/4] Full-field volume-preserving continuation (isolated trefoil, q=0)
python src\continuation.py --resume --stages 20:2:2 32:4:4 40:5:1 --out "%OUT%\continuation"
if errorlevel 1 goto :fail
echo [3/4] Frozen independent verification (no refit in acceptance metric)
python src\verify_independent.py --search "%OUT%\continuation\stage_3_n40_m5\search.json" --grids 24 32 40 48 64 --box-control
if errorlevel 1 goto :fail
echo [4/4] Evidence-first gate assessment
python src\assess.py --search "%OUT%\continuation\stage_3_n40_m5\search.json" --holdout "%OUT%\continuation\stage_3_n40_m5\holdout.json" --out "%OUT%"
if errorlevel 1 goto :fail
echo Run completed. See %OUT%\G2_STATUS.md
popd
exit /b 0
:fail
echo Computation failed with exit code %errorlevel%.
popd
exit /b 1
