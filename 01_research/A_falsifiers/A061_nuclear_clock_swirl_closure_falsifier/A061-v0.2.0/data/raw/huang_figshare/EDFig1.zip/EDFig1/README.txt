EDFig1 B-line data
==================

Files
-----
- source_data/EDFig1_B_line_source_data.csv: 27 points with detuning_kHz,
  normalized_signal and 1-sigma statistical_error. 
- EDFig1_plot.py: regenerates derived_data/ and results/.
- requirements.txt: Python dependencies.

Fit
---
Peak-normalized data are fit by unweighted nonlinear least squares. The main
model is an independent-center double Lorentzian plus offset over the full
range. The central model is a single Lorentzian plus offset over |x| <= 102 kHz.
Error bars are displayed but not used as weights.

Parameter errors are 1-sigma OLS standard errors from
RSS/(N-p) * pseudoinverse(J.T @ J), with no extra chi-square multiplier.

Run
---
    python EDFig1_plot.py
