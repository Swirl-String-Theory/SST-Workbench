# A055 Blind Topological Particle Spectrum Falsifier v0.1.2

A numerical/topological qualification release for the 82-object blind knot/link spectrum campaign.

## Key fixes

- topology-preserving planar PD routing instead of random outer lanes;
- periodic smooth closed-component geometry;
- fixed-arclength segment-to-segment thickness/contact measurement;
- unregularized Gauss linking/writhe, separated from regularized Neumann energy;
- Hopf/Solomon/Borromean link calibration before a production run;
- empirical-p-space global look-elsewhere correction;
- explicit mass-fit effect-size gate.

The atlas remains fully self-contained in `data/atlas_pd.json`.

## Windows production run

```bat
run_all.cmd full
```

To stop before reveal:

```bat
run_blind_only.cmd full
```

## Outputs

The standard Workbench naming convention is preserved:

- `A055_Blind_Topological_Particle_Spectrum_Falsifier_v0.1.2-outputs/`
- `...-outputs_BLIND.zip`
- `...-outputs_REVEALED.zip`
- `...-outputs.zip`

v0.1.2 is still a PD-derived screening campaign.  PKLSA/finite-core vortex dynamics belongs to v0.2.0.
