# BEMv14 multigrid report

This wrapper runs BEMv14 over multiple independent grid families.

## Why this matters

A single grid can only show intra-family stability. Multiple grids test whether the same normalizer and blind budget survive across independent discretization choices.

## Per-grid selected normalizers

- `paired_coarse`: normalizer `M_Lcert2`, stability `FAIL_NOT_ENOUGH_GRID`, mean `137.14740500920567`, CV `0.0`
- `paired_medium`: normalizer `M_Lcert2`, stability `FAIL_NOT_ENOUGH_GRID`, mean `137.14740500920567`, CV `0.0`
- `cartesian_small`: normalizer `M_Lcert2`, stability `FAIL_NOT_ENOUGH_GRID`, mean `137.14740500920567`, CV `0.0`

## Cross-grid consensus

- `M_Lcert2`: selected by `3` grid families; gate `PASS_CROSS_GRID_CONSENSUS`; aggregate CV `0.0`

## Files

- `multigrid_run_manifest.csv`
- `multigrid_selected_normalizers.csv`
- `multigrid_budget_aggregate.csv`
- `multigrid_consensus_summary.csv`
- `multigrid_report.md`