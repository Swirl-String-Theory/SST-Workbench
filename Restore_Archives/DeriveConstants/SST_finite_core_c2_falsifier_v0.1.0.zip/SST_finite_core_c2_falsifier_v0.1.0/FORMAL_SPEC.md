# Formal specification

The blind stage evaluates one declared nondimensional finite-core functional

\[
\mathcal F[f]=2\pi\int r\left[\frac{\kappa}{2}(f')^2+
\frac{n^2f^2}{2(r^2+a^2)}+\frac{\beta}{4}(f^2-f_\infty^2)^2+
\frac{\zeta}{2}g(r)(f-f_{\rm pref})^2\right]dr.
\]

It constructs the amplitude and transverse second variations from the same
functional. A centerline/cell operator and a scalarized contact-stress Hessian
are supplied independently. For a separable shell perturbation, the full
quadratic operators are Kronecker sums. The configured estimator returns

\[
w_\perp=\frac{Q_\perp}{Q_\parallel},\qquad
\sigma=\sigma_{\rm vol}+\langle P_\perp\rangle w_\perp,
\qquad
c_2=\frac{\sigma}{4\chi_R^2}.
\]

Default geometric conventions are

\[
\sigma_{\rm vol}=3,\qquad \langle P_\perp\rangle=\frac23,
\qquad \chi_R=2.
\]

These are explicit model inputs. They are not inferred from the comparison
target. The scientific claim survives only when:

1. the blind source/configuration contains no target leakage;
2. the profile solver converges;
3. contact and cell Hessians come from independent scientific outputs rather
   than bundled demonstration data;
4. grid convergence and profile/contact robustness pass preregistered bands;
5. no parameter is optimised against the target;
6. both derived coefficients land in the preregistered target band.

A target match without gates 1--5 is classified as inconclusive, not a result.
