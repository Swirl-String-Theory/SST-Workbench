from __future__ import annotations

import hashlib
import importlib.machinery
import json
import os
import shutil
import subprocess
import sys
import sysconfig
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CPP = ROOT / "cpp" / "hornkernels.cpp"
PKG = ROOT / "sst_horn"
BUILD = ROOT / "build"
STAMP = BUILD / "hornkernels.stamp.json"


def _hash_files(paths: list[Path]) -> str:
    h = hashlib.sha256()
    for path in paths:
        h.update(str(path.relative_to(ROOT)).encode())
        h.update(b"\0")
        h.update(path.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def extension_path() -> Path:
    suffix = sysconfig.get_config_var("EXT_SUFFIX") or importlib.machinery.EXTENSION_SUFFIXES[0]
    return PKG / ("_hornkernels" + suffix)


def have_pybind11() -> bool:
    try:
        subprocess.check_output([sys.executable, "-m", "pybind11", "--includes"], text=True)
        return True
    except Exception:
        return False


def build_if_needed(force: bool = False, verbose: bool = True) -> bool:
    """Build the pybind11 extension only if C++ source or build metadata changed.

    Returns True if a compiled extension is present after the call, False otherwise.
    If pybind11 or a compiler is unavailable, no exception is raised; callers may use
    the NumPy fallback backend.
    """
    out = extension_path()
    BUILD.mkdir(exist_ok=True)
    compiler = os.environ.get("CXX") or shutil.which("c++") or shutil.which("g++") or shutil.which("clang++")
    if not compiler or not have_pybind11():
        if verbose:
            print("[sst_horn] pybind11 or C++ compiler unavailable; using NumPy fallback.", file=sys.stderr)
        return out.exists()

    src_hash = _hash_files([CPP])
    meta = {
        "hash": src_hash,
        "python": sys.version,
        "compiler": compiler,
        "ext_suffix": out.suffix,
    }
    if not force and out.exists() and STAMP.exists():
        try:
            old = json.loads(STAMP.read_text())
            if old.get("hash") == src_hash and old.get("compiler") == compiler:
                if verbose:
                    print("[sst_horn] C++ extension is up to date.", file=sys.stderr)
                return True
        except Exception:
            pass

    try:
        includes = subprocess.check_output([sys.executable, "-m", "pybind11", "--includes"], text=True).split()
        cflags = sysconfig.get_config_var("CFLAGS") or ""
        cmd = [
            compiler,
            "-O3",
            "-std=c++17",
            "-shared",
            "-fPIC",
            *includes,
            str(CPP),
            "-o",
            str(out),
        ]
        if verbose:
            print("[sst_horn] building:", " ".join(cmd), file=sys.stderr)
        subprocess.check_call(cmd, cwd=str(ROOT))
        STAMP.write_text(json.dumps(meta, indent=2))
        return out.exists()
    except Exception as exc:
        if verbose:
            print(f"[sst_horn] build failed: {exc}; using NumPy fallback.", file=sys.stderr)
        return out.exists()


if __name__ == "__main__":
    ok = build_if_needed(force="--force" in sys.argv)
    raise SystemExit(0 if ok else 1)
