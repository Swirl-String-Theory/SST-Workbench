#!/usr/bin/env python3
"""G2 diagnostic: full 3-D Euler vorticity residual of G1 compact trefoil.

No SST constants, no smoothing kernel, no artificial damping.
The best rigid z-translation and rotation and a continuous internal twist
are fitted in least squares. This is NOT a full-field Newton Euler solver;
passing a low-dimensional least-squares test does not prove an equilibrium.

Free-space Biot--Savart: doubled FFT *linear convolution* of midpoint-quad
1/r^3 kernel (zero diagonal by odd symmetry). Finite-box truncation and
midpoint singular-cell error are measured by refinement, not presumed zero.
"""
from __future__ import annotations
import argparse, hashlib, json, os, sys, time
from pathlib import Path
import numpy as np
from scipy import fft as fft
from scipy.optimize import minimize_scalar

ROOT=Path(__file__).resolve().parents[1]
# Vendored verified G1 analytic trefoil constructor; not NPZ projected grid.
sys.path.insert(0,str(ROOT/'src'))
import g1_seed as seed


def curl4(a,dx):
    """Periodic fourth-order central stencil; operands compact in grid interior."""
    deriv=lambda v,j:(np.roll(v,2,axis=j)-8*np.roll(v,1,axis=j)+8*np.roll(v,-1,axis=j)-np.roll(v,-2,axis=j))/(12*dx)
    return np.stack((deriv(a[2],1)-deriv(a[1],2), deriv(a[0],2)-deriv(a[2],0),deriv(a[1],0)-deriv(a[0],1)))


def div4(a,dx):
    d=np.zeros_like(a[0])
    for j in range(3):
        d+=(np.roll(a[j],2,axis=j)-8*np.roll(a[j],1,axis=j)+8*np.roll(a[j],-1,axis=j)-np.roll(a[j],-2,axis=j))/(12*dx)
    return d


def free_space_velocity(omegas, dx, workers=2):
    """Two or more omega fields, all via same free-space sampled convolution."""
    n=omegas[0].shape[1]; nn=2*n; shape=(nn,nn,nn)
    inds=np.arange(nn,dtype=np.float64)
    rr=np.where(inds<n,inds,inds-nn)*dx
    rx=rr[:,None,None]; ry=rr[None,:,None]; rz=rr[None,None,:]
    rr2=rx*rx+ry*ry+rz*rz
    inv=np.zeros(shape,dtype=np.float64)
    np.power(rr2,-1.5,out=inv,where=rr2>0)
    inv*=dx**3/(4*np.pi)
    k=[fft.rfftn(r*inv,workers=workers) for r in (rx,ry,rz)]
    del inv,rr2
    out=[]
    for w in omegas:
        wh=[]
        for a in w:
            q=np.zeros(shape,dtype=np.float64)
            q[:n,:n,:n]=a
            wh.append(fft.rfftn(q,workers=workers))
        v=[]
        for i in range(3):
            j=(i+1)%3; h=(i+2)%3
            # (omega x r)_i = omega_j*r_h-omega_h*r_j
            vh=wh[j]*k[h]-wh[h]*k[j]
            v.append(fft.irfftn(vh,s=shape,workers=workers)[:n,:n,:n].copy())
        out.append(np.stack(v))
    return out


def analysis(n, box=4., qmin=-2.,qmax=2., optimize=True,workers=2):
    start=time.perf_counter()
    l0=seed.curve_length()
    w0,dx=seed.make_cartesian_grid(n,l0,0,box=box,samples=4096)
    w1,_=seed.make_cartesian_grid(n,l0,1,box=box,samples=4096)
    wd=w1-w0
    del w1
    v0,vd=free_space_velocity([w0,wd],dx,workers)
    f0=curl4(np.cross(v0,w0,axisa=0,axisb=0,axisc=0),dx)
    f1=curl4(np.cross(v0,wd,axisa=0,axisb=0,axisc=0)+np.cross(vd,w0,axisa=0,axisb=0,axisc=0),dx)
    f2=curl4(np.cross(vd,wd,axisa=0,axisb=0,axisc=0),dx)
    er=np.zeros_like(w0);er[2]=1.
    coords=(np.arange(n)+.5)*dx-box/2
    # rotation rigid velocity e_z x x = (-y,x,0)
    vr=np.zeros_like(w0);vr[0]=-coords[None,:,None];vr[1]=coords[:,None,None]
    A0=curl4(np.cross(er,w0,axisa=0,axisb=0,axisc=0),dx)
    A1=curl4(np.cross(er,wd,axisa=0,axisb=0,axisc=0),dx)
    B0=curl4(np.cross(vr,w0,axisa=0,axisb=0,axisc=0),dx)
    B1=curl4(np.cross(vr,wd,axisa=0,axisb=0,axisc=0),dx)
    # evaluate over whole box, zero outside source, so normalizations consistent
    def fit(q):
        F=f0+q*f1+(q*q)*f2
        A=A0+q*A1
        B=B0+q*B1
        aa=float(np.sum(A*A));ab=float(np.sum(A*B));bb=float(np.sum(B*B))
        af=float(np.sum(A*F));bf=float(np.sum(B*F))
        mat=np.array([[aa,ab],[ab,bb]])
        rhs=np.array([af,bf]);
        U,O=np.linalg.lstsq(mat,rhs,rcond=1e-13)[0]
        rr=F-U*A-O*B
        enorm=float(np.sqrt(np.mean(np.sum(rr*rr,axis=0))))
        fnorm=float(np.sqrt(np.mean(np.sum(F*F,axis=0))))
        gnorm=float(np.sqrt(np.mean(np.sum((U*A+O*B)**2,axis=0))))
        # l0^4 / Gamma^2 dimensionless curl(u x omega) scaling
        factor=l0**4/seed.GAMMA**2
        return {'q':float(q),'U_z':float(U),'Omega_z':float(O),
          'residual_Rstar':enorm*factor,'forcing_Rstar':fnorm*factor,
          'relative_residual':enorm/max(fnorm,1e-30),
          'balanced_relative_residual':enorm/max(fnorm,gnorm,1e-30),
          'residual_rms':enorm,'forcing_rms':fnorm,
          'matrix_condition':float(np.linalg.cond(mat)),
          'coefficients_dimensionless':{'U_z*L0/Gamma':float(U*l0/seed.GAMMA),
            'Omega_z*L0^2/Gamma':float(O*l0**2/seed.GAMMA)}}
    cases={str(q):fit(q) for q in (0,1)}
    scan=[fit(float(q)) for q in np.linspace(qmin,qmax,17)]
    opt=None
    if optimize:
        so=minimize_scalar(lambda q:fit(q)['residual_Rstar'],bounds=(qmin,qmax),method='bounded',options={'xatol':1e-5})
        opt=fit(float(so.x))
        opt['scalar_search_success']=bool(so.success)
        opt['method']='bounded scalar twist optimization plus exact least squares in U_z,Omega_z'
    # raw divergence checks, no Hodge projection used to manufacture stationarity
    div0=div4(w0,dx)
    div1=div4(w0+wd,dx)
    # fixed dimensionless test box, store d* RMS and outside-source flux boundary
    stats={'n':n,'dx':dx,'box':box,'L0':l0,'cases':cases,'scan':scan,'optimized':opt,
     'divergence':{'q0_rms_Dstar':float(np.sqrt(np.mean(div0**2))*l0**3/seed.GAMMA),
       'q1_rms_Dstar':float(np.sqrt(np.mean(div1**2))*l0**3/seed.GAMMA)},
     'runtime_seconds':time.perf_counter()-start}
    return stats


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--grids',nargs='+',type=int,default=[32,48,64])
    ap.add_argument('--box',type=float,default=4.)
    ap.add_argument('--qmin',type=float,default=-2.)
    ap.add_argument('--qmax',type=float,default=2.)
    ap.add_argument('--output-dir',default='Gate2_Trefoil_Relative_Equilibrium_v0.1.0-outputs')
    ap.add_argument('--no-optimize',action='store_true')
    ap.add_argument('--workers',type=int,default=2)
    args=ap.parse_args()
    out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)
    records=[]
    for n in args.grids:
        print('Gate2 3D free-space n=',n,flush=True)
        r=analysis(n,args.box,args.qmin,args.qmax,not args.no_optimize,args.workers)
        path=out/f'grid_n{n}.json';path.write_text(json.dumps(r,indent=2)+'\n')
        print('  q0:',r['cases']['0']['relative_residual'], 'q1:',r['cases']['1']['relative_residual'],
              'best:',r['optimized']['relative_residual'] if r['optimized'] else None,
              'seconds=',r['runtime_seconds'],flush=True)
        records.append({'n':n,'q0':r['cases']['0'],'q1':r['cases']['1'],'opt':r['optimized'], 'divergence':r['divergence']})
    digest=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report={'status':'G2_NOT_QUALIFIED_UNLESS_A_CONVERGED_ZERO_RESIDUAL_IS_DEMONSTRATED',
      'method':'direct free-space finite-core midpoint Biot-Savart velocity; fourth-order FD curl, least squares U/Omega and bounded q scan',
      'original_analytic_G1_seed':True,'sst_constants_used':False,
      'source_sha256':digest,'g1_source_sha256':hashlib.sha256(Path(seed.__file__).read_bytes()).hexdigest(),
      'config':vars(args),'grid_results':records,
      'limitations':['Stationary relative-equilibrium equation tested, not solved as infinite-dimensional PDE.',
       'Only one fixed torus centerline alpha=.35 and core radius a=.20.','Scalar q optimization is NOT full field Newton-Krylov.',
       'Unregularized midpoint Biot-Savart is not exact for finite grid.',
       'Derivative of sampled smooth field not identical to analytic continuum curl.',
       'No spectral or nonlinear stability analysis is performed.',
       'No background cores in G2, consistent with isolated G2 scope.']}
    (out/'gate2_assessment.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Assessment saved',out/'gate2_assessment.json',flush=True)

if __name__=='__main__':main()
