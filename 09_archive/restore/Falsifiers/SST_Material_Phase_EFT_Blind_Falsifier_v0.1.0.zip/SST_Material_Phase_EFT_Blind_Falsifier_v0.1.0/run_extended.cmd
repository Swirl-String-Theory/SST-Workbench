@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "DATA=%~1"
if "%DATA%"=="" if exist "..\..\KnotPlot\knots\final" set "DATA=..\..\KnotPlot\knots\final"
if "%DATA%"=="" if exist "..\KnotPlot\knots\final" set "DATA=..\KnotPlot\knots\final"
if "%DATA%"=="" if exist "..\..\..\KnotPlot\knots\final" set "DATA=..\..\..\KnotPlot\knots\final"
if "%DATA%"=="" set "DATA=..\..\KnotPlot\knots\final"
call "cmd\_RUN_CAMPAIGN.cmd" "config\extended.json" "%DATA%" "outputs\extended"
