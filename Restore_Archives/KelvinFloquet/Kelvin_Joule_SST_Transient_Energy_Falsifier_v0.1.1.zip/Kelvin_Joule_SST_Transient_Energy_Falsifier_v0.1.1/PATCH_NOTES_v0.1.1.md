# Kelvin–Joule SST Transient Energy Falsifier v0.1.1

This maintenance release fixes the two failures observed in the Windows/Intel oneAPI run log.

## Fixed

1. **Intel DPC++/SYCL compile failure** in `cpp/native.cpp`.
   - Read and write SYCL accessors were declared in one comma-separated `auto` declaration.
   - DPC++ correctly rejects this because read and write accessors are different C++ types.
   - All SYCL accessors are now separate declarations, matching the supplied GPU/SYCL audit template style.

2. **NumPy 2.5+ crash** in `kelvin_duration`.
   - `getattr(np, "trapezoid", np.trapz)` evaluated `np.trapz` eagerly even when `np.trapezoid` exists.
   - NumPy 2.5 may no longer expose `np.trapz`, causing `AttributeError`.
   - The fallback is now resolved lazily.

## Compatibility

- Python 3.14
- NumPy 1.26 through current 2.x API shapes
- pybind11 2.11+ / 3.x
- Intel oneAPI `icpx -fsycl`
- OpenMP fallback
- Python fallback

No scientific gate thresholds or SST physical assumptions were changed in this maintenance release.
