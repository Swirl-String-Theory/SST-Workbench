# Reference Python-fallback run

Generated during package construction in an environment without `pybind11`.

- Numerical/protocol gates H0-H6: PASS in the full fallback run.
- H7 nuisance robustness: FAIL.
- H8 first-order suppression: PASS.
- H9 parameter-free alpha hit: FAIL.
- H10 no-tuned-in-core rescue: FAIL.
- Scoped verdict: `FALSIFIED_OR_UNSUPPORTED_SIMPLE_COUNTERPULLEY_ENERGY_MAPPING`.

This folder is **not** a native C++ validation. Re-run `run_full.cmd` after `install_requirements.cmd` and `build_native.cmd` on the target Windows machine; H1 then becomes a genuine native-vs-Python parity test.
