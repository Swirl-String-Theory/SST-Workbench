#!/usr/bin/env python3
"""
s6_trefoil_isotropy.py  —  AUDIT §6  (conversation turns 17-18)

CLAIM UNDER TEST
    (a) A STATIC trefoil is anisotropic: its gyration (2nd-moment) tensor is
        uniaxial (two equal eigenvalues, one different) -> it has a C3 axis.
        So "a 3D wiggly knot samples directions isotropically" is FALSE.
    (b) The WORKING mechanism is quantum orientational delocalization: averaging
        the uniaxial tensor over the chiral cubic group O (24 proper rotations)
        gives an EXACTLY isotropic tensor -> isotropic rank-2 metric.
        Chirality is preserved (O = proper rotations) and L_K is orientation-invariant.

STATUS: (a) [DERIVED NEGATIVE for static-trefoil isotropy]
        (b) [DERIVED, conditional on exact O lattice symmetry]
"""
import numpy as np, itertools

# ---- (a) static trefoil gyration tensor ----
t = np.linspace(0, 2*np.pi, 20000, endpoint=False)
x = np.sin(t) + 2*np.sin(2*t)
y = np.cos(t) - 2*np.cos(2*t)
z = -np.sin(3*t)
r = np.stack([x, y, z], 1); r -= r.mean(0)
ds = np.linalg.norm(np.gradient(r, axis=0), axis=1)
G = np.einsum('a,ai,aj->ij', ds, r, r)/ds.sum()
ev = np.sort(np.linalg.eigvalsh(G)); ev_norm = ev/ev.mean()
print("="*64)
print("(a) STATIC trefoil gyration tensor")
print("="*64)
print(f"eigenvalues (mean-normalized) = {np.round(ev_norm,4)}")
print(f"anisotropy max/min            = {ev.max()/ev.min():.3f}   (isotropic = 1.000)")
# uniaxial: two eigenvalues close, one distinct; and NOT isotropic
assert ev.max()/ev.min() > 2.0
print(">>> uniaxial & anisotropic -> static knot is NOT isotropic. [DERIVED NEGATIVE]")

# ---- (b) O-orientation average ----
mats=[]
for perm in itertools.permutations(range(3)):
    P=np.eye(3)[list(perm)]
    for sx in(1,-1):
        for sy in(1,-1):
            for sz in(1,-1):
                R=P@np.diag([sx,sy,sz])
                if abs(np.linalg.det(R)-1)<1e-9: mats.append(R)
mats=np.array(mats); assert len(mats)==24
M = np.diag(ev)                                   # uniaxial trefoil tensor
Mavg = np.mean([R@M@R.T for R in mats], axis=0)
ev_avg = np.linalg.eigvalsh(Mavg); ev_avg = ev_avg/ev_avg.mean()
print("\n"+"="*64)
print("(b) O-orientation-averaged tensor (24 proper cubic rotations)")
print("="*64)
print(f"eigenvalues (mean-normalized) = {np.round(ev_avg,6)}")
print(f"anisotropy max/min            = {ev_avg.max()/ev_avg.min():.6f}   (claim 1.000000)")
assert abs(ev_avg.max()/ev_avg.min() - 1.0) < 1e-9
print(">>> exactly isotropic. Mechanism = orientational quantum delocalization, NOT static sampling.")
print(">>> proper rotations preserve chirality; L_K is orientation-invariant (alpha-program survives).")
print("\nALL §6 CHECKS PASSED.")
