# Changelog

## v0.2.0 — SST Knot Library umbrella release

### Added
- Offline SHA-256 verified KAtlas snapshot for `3_1`, `4_1`, `6_2`, `7_4`.
- Explicit topology status model: CERTIFIED / MISMATCH / UNVERIFIED / NOT_REGISTERED / ERROR.
- Optional provider discovery for pyknotid, Spherogram, SnapPy, KnotPlot and Ridgerunner.
- Optional pyknotid space-curve certification adapter.
- Optional Spherogram/SnapPy reference cross-checks.
- Generic Artin braid closure geometry generator and KAtlas-braid seeds.
- `7_4` Lissajous independent seed.
- Multi-component VECT reader/writer.
- KnotPlot 1.0 LOCD/LOCF binary reader; quantized LOCS/LOCC reject-by-default safety policy.
- Unified `load_geometry`, `make_knot_record`, dataset scanner and falsifier entry policies.
- `inspect`, `scan-dataset`, `registry`, `providers`, `crosscheck-reference`, `braid-info`, and `seed-from-topology` CLI commands.
- Source-byte hashes, canonical geometry hashes and registry provenance in knot records.

### Preserved
- v0.1.3 geometry API under `sst_knotlib`.
- C++17/OpenMP native geometry kernels.
- byte-exact blind campaign commitments.

### Policy change
A topology inferred from a filename is never considered certified. This is intentional and may expose previous datasets as `UNVERIFIED` until an independent topology provider is run.
