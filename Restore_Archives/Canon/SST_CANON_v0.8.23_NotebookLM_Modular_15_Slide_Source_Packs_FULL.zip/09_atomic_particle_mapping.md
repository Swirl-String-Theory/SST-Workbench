# Atomic bridge and particle-candidate mapping

## Slide 1/15 - Atomic bridge is downstream

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Atomic structure is emergent bridge layer.
- It uses circulation corrections on a known binding baseline.
- It must obey spectroscopy and QED constraints.

**Single slide message:** Atomic structure is emergent bridge layer.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 2/15 - Baseline Hamiltonian

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Start from known atomic Hamiltonian structure.
- SST enters through controlled correction terms.
- Bridge must preserve tested spectra.

**Single slide message:** Start from known atomic Hamiltonian structure.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 3/15 - Legacy soft-core regularization

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Soft-core terms were useful historically/computationally.
- They are not fundamental unless derived.
- Ad-hoc potentials must be demoted.

**Single slide message:** Soft-core terms were useful historically/computationally.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 4/15 - SST circulation correction

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Circulation changes effective interaction terms.
- Corrections need unit and spectroscopy checks.
- They link carrier structure to atomic observables.

**Single slide message:** Circulation changes effective interaction terms.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 5/15 - Circulation source chain

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Trace from circulation sector to effective atomic parameter.
- Every link needs status/provenance.
- Prevents hiding e or alpha in bridge coefficients.

**Single slide message:** Trace from circulation sector to effective atomic parameter.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 6/15 - Branch structure

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Multiple topological/dynamical branches may exist.
- Labels must remain distinct.
- Mode selection and stability decide relevance.

**Single slide message:** Multiple topological/dynamical branches may exist.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 7/15 - Electron trefoil under binding

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Electron-trefoil identity is preserved under ordinary binding in the model.
- Binding dresses rather than erases the core.
- Precision constraints remain mandatory.

**Single slide message:** Electron-trefoil identity is preserved under ordinary binding in the model.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 8/15 - Atomic consistency requirement

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Predicted corrections must remain within spectroscopic limits.
- Large excluded corrections fail the bridge.
- No observable channel leaves the model weak.

**Single slide message:** Predicted corrections must remain within spectroscopic limits.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 9/15 - Internal mode hypothesis

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Internal modes can couple to atomic transitions.
- Gaps suppress unwanted effects.
- Ungapped coupled modes are dangerous.

**Single slide message:** Internal modes can couple to atomic transitions.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 10/15 - Generic coupling structure

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Coupling strength controls visibility.
- Symmetry can suppress channels.
- Bridge terms need explicit form.

**Single slide message:** Coupling strength controls visibility.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 11/15 - Particle-candidate mapping

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Knot assignments are candidate mappings.
- Mappings must separate topology, geometry, charge, mass, stability.
- Quark-like twist knots remain research.

**Single slide message:** Knot assignments are candidate mappings.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 12/15 - Hydrodynamic exchange and Pauli barrier

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Exchange may mimic repulsion/exclusion.
- Pauli-like behavior needs phase/topology derivation.
- It remains research.

**Single slide message:** Exchange may mimic repulsion/exclusion.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 13/15 - Composite analogues

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Gear, Borromean, and quark-like analogues are topology-first candidates.
- Mass/charge assignments require independent closure.
- They are useful but not locked.

**Single slide message:** Gear, Borromean, and quark-like analogues are topology-first candidates.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 14/15 - Atomic falsifier ladder

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Excluded spectral deviations.
- Unstable internal modes.
- Electron identity fails under binding.
- No independent source normalization.

**Single slide message:** Excluded spectral deviations.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.

## Slide 15/15 - Atomic closing

**Narrative purpose:** Use this source page as one intended slide with a focused, non-repeating narrative angle.

**Evidence that must appear:**
- Particle identity is the last step, not the first slogan.
- Atomic bridge is promising only if spectroscopy, stability, and source normalization align.

**Single slide message:** Particle identity is the last step, not the first slogan.

**Source anchors:** Atomic Bridge Model; Particle-Candidate Mapping Layer; Spectroscopic Constraints.

**Visual specification:** Layered diagram: carrier -> bridge Hamiltonian -> atom -> observable.

**Do not generate:** Do not claim full Standard Model derivation.
