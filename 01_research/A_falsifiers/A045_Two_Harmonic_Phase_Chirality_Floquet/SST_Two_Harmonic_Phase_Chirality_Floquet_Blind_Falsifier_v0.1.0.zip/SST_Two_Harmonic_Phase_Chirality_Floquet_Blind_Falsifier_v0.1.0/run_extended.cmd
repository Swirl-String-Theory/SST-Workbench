@echo off
setlocal
cd /d "%~dp0"
if not exist .venv py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -q numpy
python -m sst_thpcf.campaign --config configs\extended.json --backend python --root . --package
endlocal
