# Gate 1 — Trefoil Euler seed independent numerical prequalification (v0.1.0)

**Scientific status: NUMERIC_PREQUALIFICATION_NOT_CERTIFIED**. This is not a proof of global reach, Euler relative equilibrium, or stability. It does not use SST-specific physical constants.

## Reproduce

Requires Python 3.11+ with `numpy` and `scipy`.

```bash
python -m pip install numpy scipy
python Gate1_Trefoil_Independent_v0.1.0.py --grids 64 128 --q 0 --output Gate1_Trefoil_Independent_v0.1.0-outputs/q0_results.json
python Gate1_Trefoil_Independent_v0.1.0.py --grids 64 128 --q 1 --output Gate1_Trefoil_Independent_v0.1.0-outputs/q1_results.json
```

Running this script is the ONLY tested operation. No SST constants, empirical scale, knot identity-to-particle fit, physical force or stability fit are included. Numeric scales R0=1 and Gamma0=1 are unit choices. `q=0,1` are independent test values. The specific R0=1, alpha0=.35, a0=.2, ETA_C=.95, bump parameter 2 were taken from the supplied research draft as *dimensionless chosen parameters*, not as derived optima.

## Findings

- Direct numerical curvature optimization: `kappa_max=1.25533624475 / R0`, minimum local curvature radius `0.796599320845 R0`.
- Every pair `(phi, phi+pi)` is doubly critical with chord length `2 alpha R0 = 0.7 R0` (verified analytically and to floating-point accuracy). Thus `reach <= 0.35 R0`. No certified *lower* reach bound has been established. The original claim `reach=0.282098` was not reproduced.
- Curve length `L0/R0=14.2705590613`.
- Torus-surface normal is used as the periodic frame. This frame has Gauss self-linking approximately `Lk=-6`. Different framings can yield different integer self-linking numbers; `q` must transform accordingly. `N=1024` yields `Wr=-3.2567178832`, `Tw=-2.7432806029`, `Wr+Tw=-5.9999984861`, `Lk=-6.0000000000`.
- Cross-sectional circulation is checked by independent Gauss-Legendre numeric quadrature on nine cross sections; its max relative error is approximately `2.22e-16`. This flux check evaluates the analytical local profile, not values sampled back from the full 3D grid.
- Differential field vorticity construction is analytically divergence-free. Independent Cartesian central-difference divergence at 5 interior points decreases quadratically as step shrinks 1e-3 / 1e-4 / 1e-5. This does not establish the behavior of a discretized Euler solver.

### Discretized 3D field: blocked

| q | N^3 | spectral dimensionless max D* | spectral dimensionless RMS D* | sampled free-space helicity H | candidate reference |
|---|---:|---:|---:|---:|---:|
| 0 | 64^3 | 120375.592 | 8408.019 | -5.888422837 | -6 |
| 0 | 128^3 | 59944.237 | 3075.468 | -5.965102993 | -6 |
| 1 | 64^3 | 117764.122 | 8317.606 | -4.933387380 | -5 |
| 1 | 128^3 | 59106.638 | 3036.655 | -4.977565580 | -5 |

These D* residuals are **not** acceptable for a qualified 3D discretization. The estimated rates from two resolutions are insufficient to conclude convergence. In particular, the strong normalization L0^3 and finite radius/transition resolution can produce large spectral residuals. No `PASS` is asserted.

The helicity operator in the script uses a zero-padded 2N-grid FFT convolution with sampled unregularized free-space Biot-Savart kernel. Singular-cell midpoint (`K(0)=0`), finite Cartesian sampling, and nearest-curve interpolation introduce convergence errors. The numbers are not direct proofs of exact finite-core helicity, and no grid-extrapolated error bound is claimed.

## Gating and limitations

- **G1 geometry**: numerical curvature checks and upper reach bound established; *no rigorous global reach certificate*. An `a0=.2` tube cannot be certified globally injective from an upper bound alone.
- **G1 vector field**: smooth solenoidal *analytical* construction verified locally. Cartesian grid divergence is not qualified.
- **G1 circulation**: quadrature of analytic cross sections passed to high accuracy, but must be rechecked after mesh projection/remapping.
- **G1 helicity**: two-grid helicity trends are encouraging; absolute convergence, boundary and kernel convergence gates remain open.
- **G2/G3/G4**: no relative Euler equilibrium solved, no eigenmodes or linear semigroup tested, no back-reacting background cores integrated, no stability claims.

## Errors in pasted original script

1. The text reports `kappa_max=3.421088` and `reach=0.282098`, but its own executable `curvature_at_phi()` and `compute_certified_reach(n_grid=14)` report ~`1.255336` and a `0.35` *candidate* instead.
2. `(phi,phi+pi)` is a continuous double-critical family, contradicting the proposed finite classification of isolated crossing families.
3. Multistart SciPy `root()` is not an interval-verified global root isolation proof; de-duplicating roots by distance can also erase distinct root pairs.
4. The provided source includes no 3D Cartesian field sampling, grid divergence, cross-section circulation check or Biot-Savart helicity integral, despite claiming all five Gate-1 steps.
5. The original `Gauss Lk` at 512 samples and a narrow .02 offset has non-negligible numerical quadrature error; frame choices differ from this script and should not be silently mixed.

## Source material / references

Gonzalez, O. and Maddocks, J. H. (1999), *Global curvature, thickness, and the ideal shapes of knots*, PNAS 96:4769–4773, doi:10.1073/pnas.96.9.4769.

Moffatt, H. K. and Ricca, R. L. (1992), *Helicity and the Călugăreanu invariant*, Proc. R. Soc. Lond. A 439:411–429, doi:10.1098/rspa.1992.0159.
