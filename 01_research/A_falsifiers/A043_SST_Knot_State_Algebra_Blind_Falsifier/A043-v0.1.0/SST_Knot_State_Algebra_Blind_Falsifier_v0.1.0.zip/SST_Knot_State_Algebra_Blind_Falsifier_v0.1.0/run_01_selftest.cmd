@echo off
setlocal
call .venv\Scripts\activate.bat
python -m pytest -q || exit /b 1
if defined SST_PRIVATE_DENYLIST (
  python tools\check_blind_a043.py --denylist "%SST_PRIVATE_DENYLIST%" || exit /b 1
) else (
  python tools\check_blind_a043.py || exit /b 1
  echo NOTE - target denylist not supplied; structural blind guard only. Set SST_PRIVATE_DENYLIST for full contamination scan.
)
