@echo off
setlocal
cd /d "%~dp0"
set "INPUT=%~1"
if "%INPUT%"=="" set "INPUT=..\KnotPlot\KnotPlot_3p1_MultiDynamics_Relaxation_Matrix_v0.1.0"
set "PRESET=%~2"
if "%PRESET%"=="" set "PRESET=basic"
call run_all_blind.cmd "%INPUT%" "%PRESET%"
set RC=%ERRORLEVEL%
if %RC% EQU 1 exit /b 1
call run_40_reveal.cmd || exit /b 1
exit /b %RC%
