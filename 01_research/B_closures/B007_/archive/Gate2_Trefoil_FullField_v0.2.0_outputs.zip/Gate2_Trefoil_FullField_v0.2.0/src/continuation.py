"""Isovortical multiresolution/multimode continuation driver, restartable.
Never transfers rasterized/projected vorticity. Transfers only exact diffeomorphism
coefficients and re-evaluates the closed-form reference field at each new grid.
"""
import argparse,hashlib,json,subprocess,sys,time
from pathlib import Path

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stages',nargs='+',default=['20:2:2','32:4:4','40:5:1'],help='grid:modes:iterations')
    parser.add_argument('--q',type=float,default=0)
    parser.add_argument('--box',type=float,default=4.4)
    parser.add_argument('--resume',action='store_true',help='Reuse a stage only if its parent hash and configuration agree')
    parser.add_argument('--out',default=str(Path(__file__).resolve().parents[1]/'Gate2_Trefoil_FullField_v0.2.0-outputs/continuation'))
    args=parser.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    prev='';records=[]
    for ix,spec in enumerate(args.stages):
        n,modes,niter=[int(v) for v in spec.split(':')]
        child=out/f'stage_{ix+1}_n{n}_m{modes}';child.mkdir(exist_ok=True)
        cmd=[sys.executable,str(Path(__file__).with_name('full_field.py')),'--n',str(n),'--modes',str(modes),'--iterations',str(niter),'--q',str(args.q),'--box',str(args.box),'--out',str(child)]
        if prev:cmd+=['--start-from',prev]
        existing=child/'search.json'
        reuse=False
        if args.resume and existing.exists():
            state_old=json.loads(existing.read_text())
            c=state_old['config']
            parent_hash=hashlib.sha256(Path(prev).read_bytes()).hexdigest() if prev else None
            reuse=(c['n']==n and c['modes']==modes and c['q']==args.q and c['box']==args.box
                   and state_old.get('restart_parent_sha256')==parent_hash)
        if not reuse:subprocess.run(cmd,check=True)
        else:print('RESUME validated existing',existing,flush=True)
        prev=str(existing)
        state=json.loads(Path(prev).read_text())
        records.append({'stage':ix+1,'n':n,'modes':modes,'iterations':niter,'prior_search_file':records[-1]['search_file'] if records else None,
                        'search_file':prev,'relative_residual':state['trace'][-1]['relative_residual'],
                        'Rstar':state['trace'][-1]['Rstar']})
    (out/'stages.json').write_text(json.dumps({'q_fixed':args.q,'box':args.box,'stages':records,'final_search':prev,'status':'CONTINUATION_CANDIDATE_NOT_A_EULER_CERTIFICATE'},indent=2)+'\n')
    print('Completed research continuation; final frozen candidate:',prev,flush=True)
if __name__=='__main__':main()
