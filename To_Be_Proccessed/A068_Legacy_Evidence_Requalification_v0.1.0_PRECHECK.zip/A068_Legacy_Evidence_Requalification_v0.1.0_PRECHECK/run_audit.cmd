@echo off
setlocal
if "%~1"=="" (
  echo Usage: run_audit.cmd C:\workspace\projects\SST-Workbench
  exit /b 2
)
python "%~dp0src\a068_audit.py" --workbench "%~1" --out "%~dp0outputs\local_audit"
exit /b %ERRORLEVEL%
