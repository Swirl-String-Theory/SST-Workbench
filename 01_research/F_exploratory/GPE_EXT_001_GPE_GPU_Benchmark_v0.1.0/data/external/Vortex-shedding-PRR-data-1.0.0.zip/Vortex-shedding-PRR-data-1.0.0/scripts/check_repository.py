"""Lightweight integrity checks for the public release package."""

from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def require(path: Path):
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def main():
    merged = np.load(require(ROOT / "data/processed/arr_data/250903_a_merged_obs=100.npy"))
    freq_outlier = require(ROOT / "data/processed/arr_data/freq_outlier.csv")
    threshold_table = require(ROOT / "data/processed/threshold_reynolds_table.csv")
    sample = np.load(require(ROOT / "data/sample_output/V0=0.9_sigma20_v0.400/psi_time_7030_crop.npy"))
    plotting_dir = require(ROOT / "plotting")

    checks = {
        "merged data shape": merged.shape,
        "freq outlier file": freq_outlier.name,
        "threshold table": threshold_table.name,
        "sample psi crop shape": sample.shape,
        "plotting scripts": sorted(path.name for path in plotting_dir.glob("plot_*.py")),
    }
    for label, value in checks.items():
        print(f"{label}: {value}")

    if merged.shape[1] != 14:
        raise RuntimeError("Unexpected merged-data column count.")
    if sample.shape != (200, 600):
        raise RuntimeError("Unexpected sample output shape.")

    print("Repository data checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
