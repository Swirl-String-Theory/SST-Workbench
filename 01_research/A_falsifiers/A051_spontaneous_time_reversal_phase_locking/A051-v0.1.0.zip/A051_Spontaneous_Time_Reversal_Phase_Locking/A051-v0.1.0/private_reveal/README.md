# Private reveal area

No private target constants are required by A051 v0.1.0. This directory is excluded from the blind output archive and is reserved for future identity mapping only.
