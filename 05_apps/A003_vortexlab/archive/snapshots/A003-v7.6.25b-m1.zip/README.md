# VortexLab modularisatie M1

Bron: `vortexring-lab-v7.6.25b.html`  
Wetenschappelijke versie: **7.6.25b**  
Architectuurmijlpaal: **M1 — parity-safe extraction**

## Wat is gewijzigd

- HTML staat in `apps/web/index.html`.
- CSS staat bytegetrouw in `apps/web/styles/vortexlab.css`.
- De bestaande browserruntime staat bytegetrouw in `apps/web/src/legacy/vortexlab-runtime.js`.
- Three.js en KaTeX worden lokaal uit `apps/web/vendor` geladen.
- Ideal-, Fseries- en KnotPlot-catalogi staan in `apps/web/data`.
- Er is een eerste contractpackage en een proces-geïsoleerde SSTcore-adapterskeleton toegevoegd.

## Wat is nadrukkelijk niet gewijzigd

Geen enkele formule, solverfunctie, gate, catalogusentry of UI-eventhandler is herschreven. M1 verandert alleen bestandsgrenzen en laadpaden.

## Starten

```bash
npm start
```

Open daarna `http://127.0.0.1:4173`.

## WebGL / discrete GPU (Arc A770)

De renderer vraagt `powerPreference: 'high-performance'`. De actieve adapter staat in de HUD (**WebGL GPU**), in `console` als `[VortexLab WebGL]`, en in `window.VL_ACTIVE_GPU`.

WebGL kiest geen GPU bij naam. Op Windows 11: **Instellingen → Systeem → Beeldscherm → Grafische instellingen** → voeg Chrome/Edge/Firefox toe → **Hoge prestaties** → **Intel Arc A770** → browser volledig herstarten. Zonder die OS-voorkeur kan de Intel iGPU actief blijven.

## Pariteit controleren

```bash
npm run check
```

De verificatie controleert de SHA-256 van de geëxtraheerde runtime, CSS, catalogi en lokale vendorbestanden.

## Volgende mijlpaal

M2 splitst `src/legacy/vortexlab-runtime.js` per domein met expliciete dependencies, maar alleen nadat de browserbenchmarks van M1 dezelfde resultaten geven als v7.6.25b.
