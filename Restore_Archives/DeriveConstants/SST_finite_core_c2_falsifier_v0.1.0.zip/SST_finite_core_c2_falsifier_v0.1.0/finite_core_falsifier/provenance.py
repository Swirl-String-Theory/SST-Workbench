from __future__ import annotations

from pathlib import Path
from typing import Iterable
import re


DEFAULT_FORBIDDEN = [
    r"\balpha\b",
    r"fine[- ]?structure",
    r"137\.0",
    r"0\.231978",
    r"3\.711655",
    r"1\.0675",
    r"epsilon[_ ]?0",
    r"codata",
]


def scan_text_files(paths: Iterable[Path], patterns: list[str] | None = None) -> list[dict[str, str]]:
    pats = [re.compile(p, re.IGNORECASE) for p in (patterns or DEFAULT_FORBIDDEN)]
    hits: list[dict[str, str]] = []
    for path in paths:
        text = path.read_text(encoding="utf-8", errors="replace")
        for line_no, line in enumerate(text.splitlines(), start=1):
            for pat in pats:
                if pat.search(line):
                    hits.append({"path": str(path), "line": str(line_no), "pattern": pat.pattern, "text": line.strip()[:240]})
    return hits
