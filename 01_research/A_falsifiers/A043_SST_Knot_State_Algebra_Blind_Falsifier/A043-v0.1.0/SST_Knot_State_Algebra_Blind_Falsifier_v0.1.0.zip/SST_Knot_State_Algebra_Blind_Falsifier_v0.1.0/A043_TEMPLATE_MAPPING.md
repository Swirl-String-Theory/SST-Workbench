# Template -> A043 specialization

The generic infrastructure was retained unchanged in `sst_falsifier_core/`. A043 specializes only scientific contracts:

- `sources.py`: PKLSA + A002 + Fremlin/Gilbert/Katlas/KnotPlot discovery.
- `invariants.py`: blind-safe external invariant providers.
- `rational_lane.py`: whole preregistered twist-family adjacency; generic low-denominator scan.
- `dynamics.py`: regularized Biot-Savart relative-equilibrium screening, GPU parity, CPU resolution certificate.
- `algebra.py`: physical-generator commutator closure and 2π/4π state test.
- `reveal.py`: commitment-verified historical comparison after sealing.

This is the intended pattern for future falsifiers: infrastructure remains stable; hypothesis-bearing modules and preregistration change under a new version/protocol hash.
