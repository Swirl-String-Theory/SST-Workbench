@echo off
setlocal EnableExtensions
cd /d "%~dp0"
python archive_previous_run.py || exit /b 1
python kpc_audit.py || exit /b 1
call run_all.cmd || exit /b %ERRORLEVEL%
call run_analyze.cmd
exit /b %ERRORLEVEL%
