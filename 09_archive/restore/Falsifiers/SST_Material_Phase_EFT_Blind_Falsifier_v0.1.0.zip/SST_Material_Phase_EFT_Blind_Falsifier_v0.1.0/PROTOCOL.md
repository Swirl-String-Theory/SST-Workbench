# Blind protocol v0.1.0

1. Thresholds are fixed in `config/basic.json` or `config/extended.json` before any geometry is analyzed.
2. `run_prepare.py` hashes accepted source files, sorts by SHA-256, copies them to blind IDs `B0001...`, and writes `PREANALYSIS_LOCK.json`.
3. `run_blind.py` refuses to run if the config hash differs from the lock.
4. The analysis sees only blind IDs and copied coordinate data. Source names/topology labels remain under `private/blind_map.csv`.
5. `LOCKED_VERDICTS.json` is written before reveal.
6. `run_reveal.py` refuses to reveal until locked verdicts exist.

## Verdict semantics

- `G1 PASS/FAIL`: empirical static centerline reparameterization robustness proxy.
- `G2 STRUCTURAL_PASS/FAIL`: estimator invariance under a comoving time-independent phase gauge; **not** evidence for a physical SST phase field.
- `G3 PASS/FAIL`: empirical convergence of dimensionless derivative invariants and curvature spectral tail.
- `G4 STRUCTURAL_PASS/FAIL`: discrete closed-loop operator-redundancy identities.
- `G5 PASS/FAIL`: empirical low-k dispersion only when a sidecar mode table exists. Otherwise `NOT_TESTED_NO_MODE_TABLE`.

A static relaxed-knot dataset can therefore at most earn `PARTIAL_STATIC_PASS_NO_MODE_DATA`.
